#!/bin/sh
set -eu
ROOTFS_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/../rootfs" && pwd)"
OUT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/../dist" && pwd)"
mkdir -p "$OUT_DIR"

[ -x "$ROOTFS_DIR/init" ] || { echo "ERRO: rootfs/init não é executável"; exit 1; }
[ -x "$ROOTFS_DIR/bin/busybox" ] || {
  echo "ERRO: rootfs/bin/busybox ausente ou não executável."
  echo "Coloque um busybox em rootfs/bin/busybox (chmod +x)."
  exit 1
}

mkdir -p "$ROOTFS_DIR/sbin" "$ROOTFS_DIR/etc" "$ROOTFS_DIR/etc/init.d" "$ROOTFS_DIR/lib/bk" "$ROOTFS_DIR/var/log" "$ROOTFS_DIR/run" "$ROOTFS_DIR/tmp"
chmod 1777 "$ROOTFS_DIR/tmp" 2>/dev/null || :

ln -sf /bin/busybox "$ROOTFS_DIR/sbin/init"

# Instalar applets (se suportado) para ter getty, mount, etc.
"$ROOTFS_DIR/bin/busybox" --install -s "$ROOTFS_DIR/bin" 2>/dev/null || :
"$ROOTFS_DIR/bin/busybox" --install -s "$ROOTFS_DIR/sbin" 2>/dev/null || :

OUT="$OUT_DIR/initramfs.cpio.gz"
(
  cd "$ROOTFS_DIR"
  find . -print0 | cpio --null -ov --format=newc 2>/dev/null | gzip -9 > "$OUT"
)
echo "OK: $OUT"
