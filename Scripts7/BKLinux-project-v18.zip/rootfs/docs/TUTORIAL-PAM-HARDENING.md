# Tutorial – PAM Hardening (BKLinux)

## Objetivo
Endurecer autenticação sem usar Display Manager pesado, mantendo o fluxo console e o xlogin minimalista.

## Pacotes
- `linux-pam`
- `shadow` (compilado com suporte a PAM)
- `pam-config-min` (default)
- `pam-config-hardened` (opcional)

## Como ativar o hardening
```sh
bk install pam-config-hardened
```

## O que muda
- PAM adiciona `pam_env`, `pam_limits` e `pam_faillock` (lockout por tentativas)
- cria arquivos em `/etc/security/*`

## Ajustes
Edite `/etc/security/faillock.conf` e `/etc/security/limits.conf`.

## Observação sobre bloat
Políticas de senha fortes (pwquality) são opcionais e ficam fora do base por padrão.
