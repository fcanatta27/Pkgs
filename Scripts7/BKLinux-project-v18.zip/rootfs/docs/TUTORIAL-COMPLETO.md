# BKLinux – Tutorial Completo e Distro-grade

## 0) Conceitos
- `bk-wrap` constrói pacotes em `/var/BK/packages/<pkg>` e gera tarballs em `/var/BK/out`
- Cache binário (reuso): `/var/3Blinux/cache` (automaticamente via bk-wrap)
- `bk-profile` instala conjuntos (base, desktop-xorg, notebook)

## 1) Requisitos do host
Ferramentas mínimas:
- gcc, g++, make, bash
- tar, xz, gzip, bzip2
- curl ou wget
- cpio + gzip (initramfs)
- sfdisk + mkfs.ext4 (instalador)

Recomendados:
- python3 (para mesa e alguns builds)
- meson + ninja (para mesa)

## 2) Preparar sysroot
Exemplo:
  mkdir -p /mnt/bklinux-root
  export DESTDIR=/mnt/bklinux-root

## 3) Construir toolchain
  bk-profile install toolchain

## 4) Instalar base (boot real)
  bk-profile install base

## 5) Cache binário
- Se um tarball existir em `/var/3Blinux/cache`, o `bk-wrap` reutiliza e pula o build.
- Após um build bem-sucedido, o tarball é copiado para o cache automaticamente.

## 6) Gerar initramfs
Depois de instalar o kernel (pacote linux) no sysroot:
  KVER="$(ls -1 /mnt/bklinux-root/lib/modules | head -n1)"
  /mnt/bklinux-root/usr/sbin/mkinitramfs -k "$KVER" -r /mnt/bklinux-root -o /mnt/bklinux-root/boot/initramfs-$KVER.cpio.gz

## 7) Desktop (Xorg)
Instale após o base:
  bk-profile install desktop-xorg

Configure autologin + startx (opcional) no seu /etc/init.d/display e /etc/bk/display.conf.

## 8) Notebook (wifi/battery/backlight)
  bk-profile install notebook

- Wifi: iw + wpa_supplicant + dhcpcd
- Battery: acpid (eventos ACPI)
- Backlight: brightnessctl

## 9) Instalador semi-automático
ATENÇÃO: destrutivo. Exige DISK explícito.
Exemplo UEFI:
  DISK=/dev/nvme0n1 EFI=1 ROOTFS=ext4 HOSTNAME=bklinux bk-install-system

Após instalar, entre no chroot e instale o GRUB (dependendo do modo):
  bk-chroot enter /mnt/bklinux-root
  grub-install ...
  grub-mkconfig -o /boot/grub/grub.cfg

## 10) Logs e troubleshooting
- Logs de build: `/var/BK/logs/`
- Saída de tarballs: `/var/BK/out/`
- Cache: `/var/3Blinux/cache`

## Desktop: ativar autologin + startx (somente se você quiser)
Edite `/etc/bk/display.conf` no sysroot:
  ENABLE=1
  MODE=startx
  USER=user
  AUTOLOGIN=1

Se o BusyBox getty não suportar `-a`, o autologin não será aplicado; neste caso o startx pode iniciar após login em tty1 via `/etc/profile.d/bklinux-startx.sh`.

## Novos blocos (v12)
### Base: toolchain de build “sem surpresas”
Instale o profile base e você já terá:
- autotools: m4 + autoconf + automake + libtool
- build core: make + pkg-config
- linguagens: python3 (3.14.x) + rust/cargo (1.92.x)

### Desktop Xorg fechado (típico)
O profile desktop inclui:
- xkeyboard-config + xkbcomp
- libXfixes, libXi, libXcursor, libXinerama, libXtst, libXdamage, libXcomposite, libXpresent
- libepoxy, libxshmfence, libXfont2

### Mesa com LLVM (opcional)
Para habilitar LLVM em mesa (Gallium mais completo):
- descomente e instale no desktop:
  - zstd
  - llvm
- O pacote mesa tenta detectar `llvm` via pkg-config e ativa automaticamente.


## Fontes
Veja `docs/TUTORIAL-FONTES.md` para configuração completa de fontconfig/TTY/Nerd/Emoji.

## Login (separado do display)
O BKLinux agora separa a política de login em `/etc/bk/login.conf`.

### A) Autologin apenas no console (sem gráfico)
Edite `/etc/bk/login.conf`:
  CONSOLE_AUTOLOGIN=1
  CONSOLE_USER=user
  GRAPHICAL_LOGIN=0

No próximo boot, tty1 fará autologin (se `getty` suportar `-a`). Nenhum X será iniciado automaticamente.

### B) Login gráfico minimalista (opcional e separado)
Edite `/etc/bk/login.conf`:
  CONSOLE_AUTOLOGIN=0
  GRAPHICAL_LOGIN=1
  GRAPHICAL_MODE=xlogin
  GRAPHICAL_VT=7
  DEFAULT_USER=user

Isso inicia `xinit` no `tty7` e apresenta um login em `xterm`:
- você escolhe o usuário
- autentica com senha via `su`
- após autenticar, inicia o WM (JWM) no mesmo DISPLAY.

Observação: isto é um login minimalista. Para um “login gráfico” com política corporativa/PAM, use util-linux login + PAM.

## Endurecendo login (PAM + shadow) sem Display Manager pesado
Instale no profile base:
- linux-pam
- shadow
- pam-config-min

Isso habilita login/su/passwd via shadow com suporte a PAM.

Arquivos:
- /etc/pam.d/login
- /etc/pam.d/system-auth
- /etc/pam.d/su

## Base Users (usuário/grupos/credenciais)
O pacote `base-users` cria, no primeiro boot, um usuário padrão e grupos essenciais.

### Config
`/etc/bk/users.conf`:
- `DEFAULT_USER=user`
- `DEFAULT_GROUPS="wheel,audio,video,input,plugdev,netdev"`
- `CREATE_DEFAULT_USER=1`

### Senha
O usuário é criado com senha bloqueada. Defina:
```sh
passwd user
```

### Auditoria
Para checar estrutura dos pacotes (sem compilar):
```sh
bk-audit /
```

## Auditoria distro-grade de dependências (v18)
- **Grafo de dependências**: `docs/DEPS-graph.dot`
- **Relatório**: `docs/AUDITORIA-DEPS-v18.md`
- **Ferramenta no sistema instalado**: `bk-deps-audit` (gera em `/var/log/bk-audit/`)

Uso:
  bk-deps-audit

Para renderizar o grafo no host:
  dot -Tpng deps.dot -o deps.png
