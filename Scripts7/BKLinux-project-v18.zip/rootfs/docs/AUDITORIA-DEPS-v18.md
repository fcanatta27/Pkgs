# BKLinux – Auditoria DEPS (v18)

## Resumo de correções automáticas

- **acpid**: adicionados DEPS = `gcc, make`
- **autoconf**: adicionados DEPS = `gcc, make`
- **automake**: adicionados DEPS = `gcc, make`
- **bash**: adicionados DEPS = `gcc, make`
- **binutils**: adicionados DEPS = `gcc, make`
- **brightnessctl**: adicionados DEPS = `gcc, make`
- **btrfs-progs**: adicionados DEPS = `gcc, make`
- **busybox**: adicionados DEPS = `make`
- **cmake**: adicionados DEPS = `gcc, make`
- **coreutils**: adicionados DEPS = `gcc, make`
- **dhcpcd**: adicionados DEPS = `gcc, make`
- **e2fsprogs**: adicionados DEPS = `gcc, make`
- **eudev**: adicionados DEPS = `gcc, make`
- **expat**: adicionados DEPS = `gcc, make`
- **findutils**: adicionados DEPS = `gcc, make`
- **fontconfig**: adicionados DEPS = `gcc, make`
- **freetype**: adicionados DEPS = `gcc, make`
- **gawk**: adicionados DEPS = `gcc, make`
- **gcc**: adicionados DEPS = `bash, make`
- **gcc-stage1**: adicionados DEPS = `bash, gcc, make`
- **glibc**: adicionados DEPS = `gcc, make`
- **glibc-bootstrap**: adicionados DEPS = `gcc, make`
- **grep**: adicionados DEPS = `gcc, make`
- **grub**: adicionados DEPS = `gcc, make`
- **harfbuzz**: adicionados DEPS = `pkg-config`
- **icu**: adicionados DEPS = `gcc, make`
- **iproute2**: adicionados DEPS = `gcc, make`
- **iw**: adicionados DEPS = `gcc, make`
- **jwm**: adicionados DEPS = `gcc, make`
- **kbd**: adicionados DEPS = `gcc, make`
- **kmod**: adicionados DEPS = `gcc, make`
- **libdrm**: adicionados DEPS = `gcc, make`
- **libepoxy**: adicionados DEPS = `pkg-config`
- **libevdev**: adicionados DEPS = `gcc, make`
- **libffi**: adicionados DEPS = `gcc, make`
- **libinput**: adicionados DEPS = `pkg-config`
- **libtool**: adicionados DEPS = `gcc, make`
- **libx11**: adicionados DEPS = `gcc, make`
- **libxau**: adicionados DEPS = `gcc, make`
- **libxcb**: adicionados DEPS = `gcc, make`
- **libxcomposite**: adicionados DEPS = `gcc, make`
- **libxcursor**: adicionados DEPS = `gcc, make`
- **libxdamage**: adicionados DEPS = `gcc, make`
- **libxdmcp**: adicionados DEPS = `gcc, make`
- **libxext**: adicionados DEPS = `gcc, make`
- **libxfixes**: adicionados DEPS = `gcc, make`
- **libxfont2**: adicionados DEPS = `gcc, make`
- **libxi**: adicionados DEPS = `gcc, make`
- **libxinerama**: adicionados DEPS = `gcc, make`
- **libxpresent**: adicionados DEPS = `gcc, make`
- **libxrandr**: adicionados DEPS = `gcc, make`
- **libxrender**: adicionados DEPS = `gcc, make`
- **libxshmfence**: adicionados DEPS = `gcc, make`
- **libxtst**: adicionados DEPS = `gcc, make`
- **linux**: adicionados DEPS = `gcc, make`
- **linux-headers**: adicionados DEPS = `make`
- **linux-pam**: adicionados DEPS = `gcc, make`
- **m4**: adicionados DEPS = `gcc, make`
- **make**: adicionados DEPS = `gcc`
- **mesa**: adicionados DEPS = `meson, ninja, python3`
- **misc-fixed**: adicionados DEPS = `gcc, make`
- **mtdev**: adicionados DEPS = `gcc, make`
- **noto-emoji**: adicionados DEPS = `python3`
- **openbox**: adicionados DEPS = `gcc, make`
- **openssl**: adicionados DEPS = `gcc, make`
- **pixman**: adicionados DEPS = `gcc, make`
- **pkg-config**: adicionados DEPS = `gcc, make`
- **pkgconf**: adicionados DEPS = `gcc, make`
- **python3**: adicionados DEPS = `gcc, make`
- **sed**: adicionados DEPS = `gcc, make`
- **setxkbmap**: adicionados DEPS = `gcc, make`
- **shadow**: adicionados DEPS = `gcc, make`
- **terminus-font**: adicionados DEPS = `make`
- **util-linux**: adicionados DEPS = `gcc, make`
- **wayland**: adicionados DEPS = `gcc, make`
- **wayland-protocols**: adicionados DEPS = `gcc, make`
- **wpa_supplicant**: adicionados DEPS = `gcc, make`
- **xauth**: adicionados DEPS = `gcc, make`
- **xcb-proto**: adicionados DEPS = `gcc, make`
- **xcb-util**: adicionados DEPS = `gcc, make`
- **xcb-util-cursor**: adicionados DEPS = `gcc, make`
- **xcb-util-image**: adicionados DEPS = `gcc, make`
- **xcb-util-keysyms**: adicionados DEPS = `gcc, make`
- **xcb-util-renderutil**: adicionados DEPS = `gcc, make`
- **xcb-util-wm**: adicionados DEPS = `gcc, make`
- **xf86-input-libinput**: adicionados DEPS = `gcc, make`
- **xf86-video-amdgpu**: adicionados DEPS = `gcc, make`
- **xf86-video-fbdev**: adicionados DEPS = `gcc, make`
- **xf86-video-intel**: adicionados DEPS = `gcc, make`
- **xf86-video-nouveau**: adicionados DEPS = `gcc, make`
- **xf86-video-vesa**: adicionados DEPS = `gcc, make`
- **xhost**: adicionados DEPS = `gcc, make`
- **xinit**: adicionados DEPS = `gcc, make`
- **xinput**: adicionados DEPS = `gcc, make`
- **xkbcomp**: adicionados DEPS = `gcc, make`
- **xkeyboard-config**: adicionados DEPS = `gcc, make`
- **xmessage**: adicionados DEPS = `gcc, make`
- **xorg-server**: adicionados DEPS = `gcc, make`
- **xorgproto**: adicionados DEPS = `gcc, make`
- **xrandr**: adicionados DEPS = `gcc, make`
- **xset**: adicionados DEPS = `gcc, make`
- **xsetroot**: adicionados DEPS = `gcc, make`
- **xterm**: adicionados DEPS = `gcc, make`
- **xz**: adicionados DEPS = `gcc, make`
- **zlib**: adicionados DEPS = `gcc, make`
- **zstd**: adicionados DEPS = `gcc, make`

## Relatório por pacote

### acpid
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### autoconf
- DEPS declaradas: `m4`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### automake
- DEPS declaradas: `autoconf`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### base-files
- DEPS declaradas: `(vazio)`
- Comandos mapeados: (nenhum)

### base-users
- DEPS declaradas: `shadow`
- Comandos mapeados: (nenhum)

### bash
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### binutils
- DEPS declaradas: `linux-headers`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### brightnessctl
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### btrfs-progs
- DEPS declaradas: `zlib`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### busybox
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `make`
- Comandos mapeados (amostra): `make->make`

### ca-certificates
- DEPS declaradas: `openssl`
- Comandos mapeados: (nenhum)

### cmake
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### console-setup
- DEPS declaradas: `kbd, terminus-font`
- Comandos mapeados: (nenhum)

### coreutils
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### dejavu-fonts
- DEPS declaradas: `(vazio)`
- Comandos mapeados: (nenhum)

### dhcpcd
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### display-manager
- DEPS declaradas: `init-services, xinit, xorg-server, openbox`
- Comandos mapeados: (nenhum)

### e2fsprogs
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### eudev
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### expat
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### findutils
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### font-awesome
- DEPS declaradas: `(vazio)`
- Comandos mapeados: (nenhum)

### font-defaults
- DEPS declaradas: `fontconfig`
- Comandos mapeados: (nenhum)

### fontconfig
- DEPS declaradas: `freetype`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### freetype
- DEPS declaradas: `zlib`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### gawk
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### gcc
- DEPS declaradas: `glibc`
- **DEPS adicionadas automaticamente**: `bash, make`
- Comandos mapeados (amostra): `bash->bash, make->make`

### gcc-stage1
- DEPS declaradas: `binutils, glibc-bootstrap`
- **DEPS adicionadas automaticamente**: `bash, gcc, make`
- Comandos mapeados (amostra): `bash->bash, gcc->gcc, make->make`

### glibc
- DEPS declaradas: `gcc-stage1`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### glibc-bootstrap
- DEPS declaradas: `linux-headers`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### grep
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### grub
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### harfbuzz
- DEPS declaradas: `freetype, icu, meson, ninja`
- **DEPS adicionadas automaticamente**: `pkg-config`
- Comandos mapeados (amostra): `meson->meson, ninja->ninja, pkg-config->pkg-config`

### icu
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### init-services
- DEPS declaradas: `base-files`
- Comandos mapeados: (nenhum)

### iproute2
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### iw
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### jwm
- DEPS declaradas: `libx11, libxext, libxrender, libxrandr, libxcursor`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### jwm-defaults
- DEPS declaradas: `jwm, xdg-menu`
- Comandos mapeados: (nenhum)

### kbd
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### kmod
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libdrm
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libepoxy
- DEPS declaradas: `mesa, meson, ninja`
- **DEPS adicionadas automaticamente**: `pkg-config`
- Comandos mapeados (amostra): `meson->meson, ninja->ninja, pkg-config->pkg-config`

### liberation-fonts
- DEPS declaradas: `(vazio)`
- Comandos mapeados: (nenhum)

### libevdev
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libffi
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libinput
- DEPS declaradas: `libevdev, mtdev, eudev, meson, ninja`
- **DEPS adicionadas automaticamente**: `pkg-config`
- Comandos mapeados (amostra): `meson->meson, ninja->ninja, pkg-config->pkg-config`

### libtool
- DEPS declaradas: `autoconf, automake`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libx11
- DEPS declaradas: `xorgproto, libxcb`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxau
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxcb
- DEPS declaradas: `xcb-proto, libxau, libxdmcp`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxcomposite
- DEPS declaradas: `libXfixes, libXdamage, libx11, xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxcursor
- DEPS declaradas: `libxrender, libXfixes, libx11`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxdamage
- DEPS declaradas: `libXfixes, libx11, xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxdmcp
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxext
- DEPS declaradas: `libx11, xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxfixes
- DEPS declaradas: `libx11, xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxfont2
- DEPS declaradas: `freetype, fontconfig, xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxi
- DEPS declaradas: `libx11, xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxinerama
- DEPS declaradas: `libx11, xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxpresent
- DEPS declaradas: `libx11, xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxrandr
- DEPS declaradas: `libx11, xorgproto, libxrender`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxrender
- DEPS declaradas: `libx11, xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxshmfence
- DEPS declaradas: `xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### libxtst
- DEPS declaradas: `libXi, libx11, xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### linux
- DEPS declaradas: `linux-headers, kmod`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### linux-headers
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `make`
- Comandos mapeados (amostra): `make->make`

### linux-pam
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### llvm
- DEPS declaradas: `cmake, ninja, python3, zstd`
- Comandos mapeados (amostra): `cmake->cmake, ninja->ninja, python3->python3`

### login-policy
- DEPS declaradas: `base-files`
- Comandos mapeados: (nenhum)

### m4
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### make
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### mesa
- DEPS declaradas: `libdrm`
- **DEPS adicionadas automaticamente**: `meson, ninja, python3`
- Comandos mapeados (amostra): `meson->meson, ninja->ninja, python3->python3`

### meson
- DEPS declaradas: `python3`
- Comandos mapeados (amostra): `python3->python3`

### misc-fixed
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### mkinitramfs
- DEPS declaradas: `base-files, busybox`
- Comandos mapeados: (nenhum)

### mtdev
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### nerd-fonts-jetbrainsmono
- DEPS declaradas: `(vazio)`
- Comandos mapeados: (nenhum)

### nerd-fonts-symbols
- DEPS declaradas: `(vazio)`
- Comandos mapeados: (nenhum)

### ninja
- DEPS declaradas: `python3`
- Comandos mapeados (amostra): `python3->python3`

### noto-emoji
- DEPS declaradas: `fontconfig`
- **DEPS adicionadas automaticamente**: `python3`
- Comandos mapeados (amostra): `python3->python3`

### noto-fonts
- DEPS declaradas: `fontconfig`
- Comandos mapeados: (nenhum)

### openbox
- DEPS declaradas: `libx11`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### openssl
- DEPS declaradas: `zlib`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### pam-config-hardened
- DEPS declaradas: `linux-pam, shadow`
- Comandos mapeados: (nenhum)

### pam-config-min
- DEPS declaradas: `linux-pam, shadow`
- Comandos mapeados: (nenhum)

### pixman
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### pkg-config
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### pkgconf
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### python3
- DEPS declaradas: `libffi, expat`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### rfkill
- DEPS declaradas: `util-linux`
- Comandos mapeados: (nenhum)

### rust
- DEPS declaradas: `(vazio)`
- Comandos mapeados: (nenhum)

### sed
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### setxkbmap
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### shadow
- DEPS declaradas: `linux-pam`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### terminus-font
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `make`
- Comandos mapeados (amostra): `make->make`

### ttf-droid
- DEPS declaradas: `(vazio)`
- Comandos mapeados: (nenhum)

### util-linux
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### wayland
- DEPS declaradas: `expat, libffi`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### wayland-protocols
- DEPS declaradas: `wayland`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### wpa_supplicant
- DEPS declaradas: `openssl`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xauth
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xcb-proto
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xcb-util
- DEPS declaradas: `libxcb`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xcb-util-cursor
- DEPS declaradas: `xcb-util, xcb-util-renderutil, xcb-util-image, xcb-util-keysyms`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xcb-util-image
- DEPS declaradas: `xcb-util`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xcb-util-keysyms
- DEPS declaradas: `xcb-util`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xcb-util-renderutil
- DEPS declaradas: `xcb-util`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xcb-util-wm
- DEPS declaradas: `xcb-util`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xdg-menu
- DEPS declaradas: `(vazio)`
- Comandos mapeados: (nenhum)

### xf86-input-libinput
- DEPS declaradas: `libinput, xorg-server`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xf86-video-amdgpu
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xf86-video-fbdev
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xf86-video-intel
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xf86-video-nouveau
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xf86-video-vesa
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xhost
- DEPS declaradas: `libx11, xorgproto`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xinit
- DEPS declaradas: `libx11, xorg-server`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xinput
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xkbcomp
- DEPS declaradas: `libx11, xkeyboard-config`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xkeyboard-config
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xlogin-min
- DEPS declaradas: `xinit, xorg-server, xterm, xhost, jwm`
- Comandos mapeados: (nenhum)

### xmessage
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xorg-server
- DEPS declaradas: `pixman, libx11, libxext, libxrender, libxrandr`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xorgproto
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xrandr
- DEPS declaradas: `libxrandr`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xset
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xsetroot
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xterm
- DEPS declaradas: `libx11`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### xz
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### zlib
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`

### zstd
- DEPS declaradas: `(vazio)`
- **DEPS adicionadas automaticamente**: `gcc, make`
- Comandos mapeados (amostra): `gcc->gcc, make->make`
