# BKLinux – Tutorial de Fontes (Fontconfig + TTY + Nerd/Emoji)

## 1) Onde as fontes ficam
### Sistema
- `/usr/share/fonts/` (fontes do sistema)
  - `dejavu/`, `liberation/`, `noto/`, `noto-emoji/`, `nerd-fonts/`, `fontawesome/`, `droid/`, etc.

### Usuário
- `~/.local/share/fonts/` (por usuário, sem root)

## 2) Fontconfig: cache e inspeção
Após instalar fontes novas:
- Regerar cache:
  - `fc-cache -rv`
- Listar fontes instaladas:
  - `fc-list | less`
- Ver qual fonte será usada para uma família:
  - `fc-match sans-serif`
  - `fc-match serif`
  - `fc-match monospace`
  - `fc-match emoji`

## 3) Defaults do BKLinux
O pacote `font-defaults` instala:
- `/etc/fonts/local.conf` (aliases padrão)
- `/etc/fonts/conf.d/99-bklinux-enable-bitmaps.conf` (permite bitmap fonts)

Aliases recomendados:
- sans-serif -> Noto Sans -> DejaVu Sans -> Liberation Sans
- serif      -> Noto Serif -> DejaVu Serif -> Liberation Serif
- monospace  -> JetBrainsMono Nerd Font -> DejaVu Sans Mono -> Liberation Mono
- emoji      -> Noto Color Emoji

Para alterar defaults:
1) Edite `/etc/fonts/local.conf`
2) Rode `fc-cache -rv`

## 4) Fontes para terminal/TTY
### Terminal no X
Escolha uma fonte monospace no seu terminal (xterm, etc.) ou via `~/.Xresources`.

### TTY (console puro, sem X)
O BKLinux usa `console-setup`:
- Config: `/etc/bk/console.conf`
  - `FONT=ter-132n` (exemplo)
  - `KEYMAP=br-abnt2` (opcional)

Aplicar manualmente:
- `setfont /usr/share/consolefonts/ter-132n.psf.gz`

## 5) Nerd Fonts e Font Awesome
- Nerd Fonts fornecem ícones para terminais e editores.
- Font Awesome fornece ícones para apps e temas.

Após instalar:
- `fc-cache -rv`
- Selecione “JetBrainsMono Nerd Font” no terminal/editor.

## 6) Emoji
- `noto-emoji` instala `NotoColorEmoji.ttf`.
- Para apps GTK/Qt, você normalmente precisa de harfbuzz/icu para shaping/render mais completo.

Verificar:
- `fc-match emoji`
