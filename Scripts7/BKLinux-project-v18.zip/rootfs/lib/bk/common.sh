#!/bin/sh
# BKLinux - utilidades comuns (POSIX sh)

is_tty() { [ -t 1 ] && [ -z "${NO_COLOR:-}" ]; }
c_reset() { is_tty && printf '\033[0m' || :; }
c_red()   { is_tty && printf '\033[31m' || :; }
c_grn()   { is_tty && printf '\033[32m' || :; }
c_ylw()   { is_tty && printf '\033[33m' || :; }
c_blu()   { is_tty && printf '\033[34m' || :; }
c_cyn()   { is_tty && printf '\033[36m' || :; }

log_stage() { c_cyn; printf '[BK] '; c_blu; printf '%s' "$1"; c_reset; printf '\n'; }
log_ok()    { c_grn; printf '[OK] '; c_reset; printf '%s\n' "$1"; }
log_warn()  { c_ylw; printf '[WARN] '; c_reset; printf '%s\n' "$1" >&2; }
log_err()   { c_red; printf '[ERRO] '; c_reset; printf '%s\n' "$1" >&2; }
die() { log_err "$1"; exit "${2:-1}"; }

safe_mkdir() { d="$1"; m="${2:-0755}"; [ -d "$d" ] || mkdir -p "$d" || return 1; chmod "$m" "$d" 2>/dev/null || :; }
need_cmd() { command -v "$1" >/dev/null 2>&1 || die "Comando ausente: $1"; }


\
# ---- Helpers adicionais (v5) ----
now_ts() { date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date; }

require_cmd() {
  for c in "$@"; do
    command -v "$c" >/dev/null 2>&1 || die "Comando necessário ausente: $c"
  done
}

color_tag() {
  # color_tag <NAME> <VERSION>
  c_cyn; printf '%s' "$1"; c_reset; printf '-'; c_grn; printf '%s' "$2"; c_reset
}

fetch_url() {
  # optional: export SHA256=... before calling

  # fetch_url <url> <out>
  url="$1"; out="$2"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL -o "$out" "$url"
    return $?
  fi
  if command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
    return $?
  fi
  die "Sem curl/wget para download"
}

sha512_check_file() {
  # sha512_check_file <file> <sha512sum>
  f="$1"; sum="$2"
  command -v sha512sum >/dev/null 2>&1 || return 0
  got="$(sha512sum "$f" 2>/dev/null | awk '{print $1}' || true)"
  [ -n "$got" ] && [ "$got" = "$sum" ]
}



verify_sha256() {
  file="$1"
  want="$2"
  [ -n "$want" ] || return 0
  command -v sha256sum >/dev/null 2>&1 || die "sha256sum ausente para validar $file"
  got="$(sha256sum "$file" | awk '{print $1}')"
  [ "$got" = "$want" ] || die "SHA256 mismatch: $file (got $got want $want)"
}
