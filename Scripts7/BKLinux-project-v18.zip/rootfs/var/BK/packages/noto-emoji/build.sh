#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar gzip python3

fetch_url "$URL" "$SRCROOT/src.tar.gz"
tar -xf "$SRCROOT/src.tar.gz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "noto-emoji-*" | head -n1)"
[ -n "$src" ] || die "src noto-emoji não encontrado"

# Fonte color emoji principal (OTF/TTF no repo varia; pegamos a mais comum)
install -d "$STAGEROOT/usr/share/fonts/noto" "$STAGEROOT/usr/share/fonts/noto-emoji"
f=""
for cand in "$src/fonts/NotoColorEmoji.ttf" "$src/fonts/NotoColorEmoji.ttf" "$src/fonts/NotoColorEmoji.ttf"; do
  [ -f "$cand" ] && f="$cand" && break
done
# fallback: procurar por *Emoji*.ttf
if [ -z "$f" ]; then
  f="$(find "$src" -maxdepth 3 -type f -name "*Emoji*.ttf" | head -n1 || true)"
fi
[ -n "$f" ] || die "NotoColorEmoji.ttf não encontrado no repo"
install -m 0644 "$f" "$STAGEROOT/usr/share/fonts/noto-emoji/NotoColorEmoji.ttf"

bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
