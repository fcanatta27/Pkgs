#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
install -d "$STAGEROOT/usr/bin" "$STAGEROOT/etc/init.d"
install -m 0755 "$PKGDIR/files/usr/bin/bk-xlogin" "$STAGEROOT/usr/bin/bk-xlogin"
install -m 0755 "$PKGDIR/files/etc/init.d/xlogin" "$STAGEROOT/etc/init.d/xlogin"
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
