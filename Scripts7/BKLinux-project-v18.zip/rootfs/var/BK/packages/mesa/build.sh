#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar xz python3

fetch_url "$URL" "$SRCROOT/src.tar.xz"
tar -xf "$SRCROOT/src.tar.xz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "mesa-*" | head -n1)"
[ -n "$src" ] || die "src mesa não encontrado"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
# build com meson (necessita meson+ninja no host/sysroot)
command -v meson >/dev/null 2>&1 || die "meson necessário para mesa"
command -v ninja >/dev/null 2>&1 || die "ninja necessário para mesa"
LLVM_OPT="false"
if pkg-config --exists llvm 2>/dev/null; then LLVM_OPT="true"; fi
meson setup "$src" build -Dprefix=/usr -Dlibdir=lib -Dplatforms=x11 -Dgallium-drivers= -Dvulkan-drivers= -Dllvm=$LLVM_OPT
ninja -C build
DESTDIR="$STAGEROOT" ninja -C build install
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
