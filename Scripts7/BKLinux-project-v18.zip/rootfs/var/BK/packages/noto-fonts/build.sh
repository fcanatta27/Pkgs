#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd unzip install

# Este pacote instala um conjunto básico Noto (Sans/Serif/Mono).
# Se o URL acima falhar (mudança upstream), substitua em pkg.conf por um asset real.

fetch_url "$URL" "$SRCROOT/noto.zip" || die "download Noto falhou: ajuste URL no pkg.conf"
mkdir -p "$SRCROOT/unzip"
unzip -q "$SRCROOT/noto.zip" -d "$SRCROOT/unzip" || die "unzip falhou"

install -d "$STAGEROOT/usr/share/fonts/noto"
# copia quaisquer ttf/otf encontrados
find "$SRCROOT/unzip" -type f \( -name "*.ttf" -o -name "*.otf" \) -maxdepth 3 | while IFS= read -r f; do
  install -m 0644 "$f" "$STAGEROOT/usr/share/fonts/noto/$(basename "$f")"
done

bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
