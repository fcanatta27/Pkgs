#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
install -d "$STAGEROOT/etc/pam.d" "$STAGEROOT/etc/security"
install -m 0644 "$PKGDIR/files/etc/pam.d/system-auth" "$STAGEROOT/etc/pam.d/system-auth"
install -m 0644 "$PKGDIR/files/etc/pam.d/login" "$STAGEROOT/etc/pam.d/login"
install -m 0644 "$PKGDIR/files/etc/pam.d/system-auth" "$STAGEROOT/etc/pam.d/su"
install -m 0644 "$PKGDIR/files/etc/security/limits.conf" "$STAGEROOT/etc/security/limits.conf"
install -m 0644 "$PKGDIR/files/etc/security/pam_env.conf" "$STAGEROOT/etc/security/pam_env.conf"
install -m 0644 "$PKGDIR/files/etc/security/faillock.conf" "$STAGEROOT/etc/security/faillock.conf"
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
