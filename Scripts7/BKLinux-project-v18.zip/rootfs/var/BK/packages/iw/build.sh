#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/iw.tar.xz"
tar -xf "$SRCROOT/iw.tar.xz" -C "$SRCROOT"
cd "$SRCROOT"/iw-*
make -j"$JOBS" PREFIX=/usr
make DESTDIR="$STAGEROOT" PREFIX=/usr install
bk pack iw "$VERSION" "$STAGEROOT" "$OUTROOT"
