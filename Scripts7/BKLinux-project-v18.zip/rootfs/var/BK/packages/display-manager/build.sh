#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"

# conf + profile hook
install -d "$STAGEROOT/etc/bk" "$STAGEROOT/etc/profile.d" 2>/dev/null || :
install -m 0644 "$PKGDIR/files/etc/bk/display.conf" "$STAGEROOT/etc/bk/display.conf"
install -m 0644 "$PKGDIR/files/etc/profile.d/bklinux-startx.sh" "$STAGEROOT/etc/profile.d/bklinux-startx.sh"

# sobrescreve /etc/init.d/display com a versão atual (melhorada)
install -d "$STAGEROOT/etc/init.d" 2>/dev/null || :
install -m 0755 "$PKGDIR/files/etc/init.d/display" "$STAGEROOT/etc/init.d/display"

bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
