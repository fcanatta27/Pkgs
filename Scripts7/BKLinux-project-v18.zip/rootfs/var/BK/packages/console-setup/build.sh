#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
install -d "$STAGEROOT/etc/bk" "$STAGEROOT/etc/init.d"
install -m 0644 "$PKGDIR/files/etc/bk/console.conf" "$STAGEROOT/etc/bk/console.conf"
install -m 0755 "$PKGDIR/files/etc/init.d/console-setup" "$STAGEROOT/etc/init.d/console-setup"
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
