#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"

# instalar arquivos
cd "$PKGDIR/files"
find . -type f ! -name '.keep' -print | while IFS= read -r f; do
  dst="$STAGEROOT/${f#./}"
  mkdir -p "$(dirname "$dst")" 2>/dev/null || :
  mode=0644
  case "$f" in
    */mkinitramfs|*/init) mode=0755 ;;
  esac
  install -m "$mode" "$f" "$dst"
done

bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
