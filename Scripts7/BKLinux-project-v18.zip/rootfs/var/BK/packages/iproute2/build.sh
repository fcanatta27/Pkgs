#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar gzip
fetch_url "$URL" "$SRCROOT/iproute2.tar.gz"
tar -xf "$SRCROOT/iproute2.tar.gz" -C "$SRCROOT"
cd "$SRCROOT"/iproute2-*
# usa /usr, sem systemd
./configure 2>/dev/null || :
make -j"$JOBS" PREFIX=/usr LIBDIR=/lib
make DESTDIR="$STAGEROOT" PREFIX=/usr LIBDIR=/lib install
bk pack iproute2 "$VERSION" "$STAGEROOT" "$OUTROOT"
