#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar xz cmake ninja python3

fetch_url "$URL" "$SRCROOT/src.tar.xz"
tar -xf "$SRCROOT/src.tar.xz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "llvm-project-*.src" | head -n1)"
[ -n "$src" ] || die "src llvm-project não encontrado"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
cmake -G Ninja -S "$src/llvm" -B build   -DCMAKE_INSTALL_PREFIX=/usr -DCMAKE_INSTALL_LIBDIR=lib   -DLLVM_ENABLE_PROJECTS="clang;lld"   -DLLVM_TARGETS_TO_BUILD="X86"   -DLLVM_ENABLE_TERMINFO=OFF   -DLLVM_ENABLE_ZSTD=ON
ninja -C build
DESTDIR="$STAGEROOT" ninja -C build install
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
