#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar gzip make gcc

fetch_url "$URL" "$SRCROOT/src.tgz"
tar -xf "$SRCROOT/src.tgz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 2 -type d -path "*/icu/source" | head -n1)"
[ -n "$src" ] || die "src icu/source não encontrado"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$src/runConfigureICU" Linux --prefix=/usr --libdir=/lib
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
