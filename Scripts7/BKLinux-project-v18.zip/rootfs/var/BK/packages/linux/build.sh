#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz

fetch_url "$URL" "$SRCROOT/linux.tar.xz"
tar -xf "$SRCROOT/linux.tar.xz" -C "$SRCROOT"
cd "$SRCROOT"/linux-*

# Config padrão; você pode colocar um .config em files/ e copiar antes
make mrproper
make defconfig

make -j"$JOBS"
make INSTALL_MOD_PATH="$STAGEROOT" modules_install
mkdir -p "$STAGEROOT/boot" 2>/dev/null || :
cp -f arch/x86/boot/bzImage "$STAGEROOT/boot/vmlinuz-$VERSION" 2>/dev/null || die "bzImage não encontrado"
cp -f System.map "$STAGEROOT/boot/System.map-$VERSION" 2>/dev/null || :
cp -f .config "$STAGEROOT/boot/config-$VERSION" 2>/dev/null || :

bk pack linux "$VERSION" "$STAGEROOT" "$OUTROOT"
