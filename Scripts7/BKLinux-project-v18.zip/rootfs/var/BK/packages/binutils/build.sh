#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/binutils.tar.xz"
tar -xf "$SRCROOT/binutils.tar.xz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/binutils-*/configure --prefix=/usr --libdir=/lib --disable-multilib
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack binutils "$VERSION" "$STAGEROOT" "$OUTROOT"
