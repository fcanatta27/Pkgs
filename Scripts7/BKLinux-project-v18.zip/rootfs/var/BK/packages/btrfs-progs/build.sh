#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/btrfs.tar.xz"
tar -xf "$SRCROOT/btrfs.tar.xz" -C "$SRCROOT"
cd "$SRCROOT"/btrfs-progs-*
make -j"$JOBS" prefix=/usr libdir=/lib
make DESTDIR="$STAGEROOT" prefix=/usr libdir=/lib install
bk pack btrfs-progs "$VERSION" "$STAGEROOT" "$OUTROOT"
