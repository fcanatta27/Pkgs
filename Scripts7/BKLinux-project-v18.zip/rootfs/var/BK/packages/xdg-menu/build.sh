#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
install -d "$STAGEROOT/usr/bin" "$STAGEROOT/etc/jwm"
install -m 0755 "$PKGDIR/files/usr/bin/bk-xdg-menu" "$STAGEROOT/usr/bin/bk-xdg-menu"
# gera menu inicial no build (será regenerado no boot ou pelo usuário)
"$STAGEROOT/usr/bin/bk-xdg-menu" OUT="$STAGEROOT/etc/jwm/menu.xml" 2>/dev/null || :
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
