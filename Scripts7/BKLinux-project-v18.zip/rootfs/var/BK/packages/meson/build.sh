#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar gzip python3

fetch_url "$URL" "$SRCROOT/src.tar.gz"
tar -xf "$SRCROOT/src.tar.gz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "meson-*" | head -n1)"
[ -n "$src" ] || die "src meson não encontrado"

# Preferir pip se existir; fallback para 'python3 setup.py install' quando disponível
if python3 -m pip --version >/dev/null 2>&1; then
  python3 -m pip install --no-deps --prefix="$STAGEROOT/usr" "$src"
elif [ -f "$src/setup.py" ]; then
  (cd "$src" && python3 setup.py install --prefix=/usr --root="$STAGEROOT")
else
  die "pip ou setup.py necessário para instalar meson"
fi

bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
