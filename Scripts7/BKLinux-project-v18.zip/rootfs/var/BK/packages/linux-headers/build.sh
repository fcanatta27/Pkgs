#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make tar xz
fetch_url "$URL" "$SRCROOT/linux.tar.xz"
tar -xf "$SRCROOT/linux.tar.xz" -C "$SRCROOT"
cd "$SRCROOT"/linux-*
make mrproper
make headers_install INSTALL_HDR_PATH="$STAGEROOT/usr"
bk pack linux-headers "$VERSION" "$STAGEROOT" "$OUTROOT"
