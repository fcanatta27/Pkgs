#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/glibc.tar.xz"
tar -xf "$SRCROOT/glibc.tar.xz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/glibc-*/configure --prefix=/usr --libdir=/lib --disable-multilib libc_cv_slibdir=/lib
make install-bootstrap-headers=yes DESTDIR="$STAGEROOT" install-headers
mkdir -p "$STAGEROOT/lib"
touch "$STAGEROOT/lib/ld-linux-x86-64.so.2"
bk pack glibc-bootstrap "$VERSION" "$STAGEROOT" "$OUTROOT"
