#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar gzip install

fetch_url "$URL" "$SRCROOT/src.tar.gz"
tar -xf "$SRCROOT/src.tar.gz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "liberation-fonts-*" | head -n1)"
[ -n "$src" ] || die "src liberation-fonts não encontrado"
install -d "$STAGEROOT/usr/share/fonts/liberation"
# fontes podem estar em 'ttf' ou 'fonts/ttf'
if [ -d "$src/ttf" ]; then
  cp -a "$src/ttf/." "$STAGEROOT/usr/share/fonts/liberation/"
elif [ -d "$src/fonts/ttf" ]; then
  cp -a "$src/fonts/ttf/." "$STAGEROOT/usr/share/fonts/liberation/"
fi
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
