#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/src.tar.xz"
tar -xf "$SRCROOT/src.tar.xz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "xinput-*" | head -n1)"
[ -n "$src" ] || die "src não encontrado: xinput-*"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$src/configure" --prefix=/usr --libdir=/lib --sysconfdir=/etc --localstatedir=/var
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
