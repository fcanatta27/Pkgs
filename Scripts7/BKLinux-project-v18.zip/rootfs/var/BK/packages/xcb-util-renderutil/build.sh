#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/src.tar.xz"
tar -xf "$SRCROOT/src.tar.xz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/xcb-util-renderutil-*/configure --prefix=/usr --libdir=/lib 
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
