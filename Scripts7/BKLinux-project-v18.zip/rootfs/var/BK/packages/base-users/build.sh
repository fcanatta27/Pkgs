#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
install -d "$STAGEROOT/etc/bk" "$STAGEROOT/etc/init.d" "$STAGEROOT/var/lib/bk" "$STAGEROOT/etc/skel"
install -m 0644 "$PKGDIR/files/etc/bk/users.conf" "$STAGEROOT/etc/bk/users.conf"
install -m 0755 "$PKGDIR/files/etc/init.d/base-users" "$STAGEROOT/etc/init.d/base-users"
install -m 0644 "$PKGDIR/files/etc/skel/.profile" "$STAGEROOT/etc/skel/.profile"
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
