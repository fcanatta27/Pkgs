# Tornando BKLinux utilizável para desktop (notas práticas)

Este projeto fornece scripts para:
- montar devpts e /dev/shm
- iniciar udev/eudev (se disponível), ou fallback mdev
- iniciar dbus (se disponível)
- iniciar seatd/elogind (se disponível)
- tentar iniciar um display manager (lightdm/sddm/gdm), ou orientar `startx`

## O que você ainda precisa instalar (fora do escopo do init)
Para ter desktop de verdade, você precisa de pacotes reais:
- glibc (ou musl) + toolchain
- Xorg + drivers de vídeo (mesa, modesetting, etc.)
- um window manager/desktop (xfce, lxde, openbox, etc.)
- dbus, elogind/seatd, fontconfig, fonts, etc.

Os scripts aqui são "best effort": se um componente não existir, o boot não falha.

## Recomendação
Primeiro valide em QEMU com serial (`console=ttyS0`). Depois valide em máquina real.

## Desktop (Xorg) – sanity set, JWM e fontes

O profile `desktop-xorg` inclui um conjunto mínimo de utilitários de “sanidade” do Xorg:
`xauth`, `xset`, `setxkbmap`, `xinput`, `xsetroot`, `xmessage`.

Também inclui um WM leve (`jwm`) e fontes adicionais (Font Awesome + Nerd Fonts Symbols + JetBrainsMono Nerd).

### Como ativar JWM no startx

Por padrão, o `jwm` é usado via `/etc/skel/.xinitrc`. Você pode:

- Sobrescrever por usuário: `~/.xinitrc`
- Ou escolher sessão via variável: `BK_XSESSION=jwm|openbox|xterm`

### Drivers de vídeo (fallback + específicos)

O profile instala drivers Xorg clássicos (quando disponíveis): `xf86-video-vesa`, `xf86-video-fbdev`, `xf86-video-intel`, `xf86-video-amdgpu`, `xf86-video-nouveau`.
O driver `modesetting` já vem do Xorg Server e é o fallback moderno.

### Console (TTY) – fontes

Inclui `kbd` (fornece `setfont`) + `terminus-font` + serviço `console-setup`.
Edite `/etc/vconsole.conf` para selecionar o `FONT=` desejado.
