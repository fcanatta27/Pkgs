#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/util-linux.tar.xz"
tar -xf "$SRCROOT/util-linux.tar.xz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/util-linux-*/configure --prefix=/usr --libdir=/lib --disable-use-tty-group --without-systemd --disable-su --disable-login
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack util-linux "$VERSION" "$STAGEROOT" "$OUTROOT"
