#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/shadow.tar.xz"
tar -xf "$SRCROOT/shadow.tar.xz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/shadow-*/configure --prefix=/usr --libdir=/lib --sysconfdir=/etc --disable-subids
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack shadow "$VERSION" "$STAGEROOT" "$OUTROOT"
