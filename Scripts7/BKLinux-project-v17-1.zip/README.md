# BKLinux - scripts essenciais de init (BusyBox init)

Este pacote entrega scripts essenciais para tornar o **BusyBox init** utilizável em um sistema mínimo:

- `/init` (initramfs) entrega controle ao `/sbin/init` (BusyBox)
- `/etc/inittab` com sysinit + consoles (tty1/ttyS0) + shutdown
- `/etc/init.d/rcS` (boot): mounts, mdev, syslog, rede opcional, serviços básicos
- `/etc/init.d/rcK` (shutdown): termina serviços, desmonta FS
- `/etc/init.d/functions` (helper POSIX sh) para start/stop/status
- serviços em `/etc/init.d/`:
  - `mdev`
  - `syslog`
  - `network` (udhcpc, opcional)
  - `seed` (dirs e permissões mínimas)
  - `autorepair` (chama /sbin/bk-autorepair, se existir)
  - `rc.local` (gancho do usuário)

## O que estes scripts fazem é **mitigar classes comuns de bugs** (ordem de boot, race conditions,
faltas de /dev, permissões, ausência de ferramentas) com validações e *fallbacks*.

## Uso
Coloque estes arquivos na sua rootfs (ou initramfs). Garanta que exista `busybox` em `/bin/busybox`
e que `/sbin/init` aponte para ele (symlink).

Em um initramfs, use `rdinit=/init` e este `/init` chamará `/sbin/init`.
