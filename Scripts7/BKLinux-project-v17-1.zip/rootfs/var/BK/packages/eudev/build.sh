#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar gzip
fetch_url "$URL" "$SRCROOT/eudev.tar.gz"
tar -xf "$SRCROOT/eudev.tar.gz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/eudev-*/configure --prefix=/usr --libdir=/lib --sbindir=/usr/bin --disable-manpages
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack eudev "$VERSION" "$STAGEROOT" "$OUTROOT"
