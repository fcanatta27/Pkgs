#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/zlib.tar.xz"
tar -xf "$SRCROOT/zlib.tar.xz" -C "$SRCROOT"
cd "$SRCROOT"/zlib-*
make -j"$JOBS"
make DESTDIR="$STAGEROOT" prefix=/usr libdir=/lib install
bk pack zlib "$VERSION" "$STAGEROOT" "$OUTROOT"
