#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz

fetch_url "$URL" "$SRCROOT/src.tar.xz"
tar -xf "$SRCROOT/src.tar.xz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "Python-*" | head -n1)"
[ -n "$src" ] || die "src Python não encontrado"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$src/configure" --prefix=/usr --libdir=/lib --enable-shared --with-ensurepip=install
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
ln -sf python3 "$STAGEROOT/usr/bin/python" 2>/dev/null || :
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
