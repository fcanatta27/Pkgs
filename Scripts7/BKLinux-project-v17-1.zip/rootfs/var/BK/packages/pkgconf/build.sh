#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/pkgconf.tar.xz"
tar -xf "$SRCROOT/pkgconf.tar.xz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/pkgconf-*/configure --prefix=/usr --libdir=/lib --with-pkg-config-dir=/usr/lib/pkgconfig:/usr/share/pkgconfig
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
# compat: pkg-config
ln -sf pkgconf "$STAGEROOT/usr/bin/pkg-config" 2>/dev/null || :
bk pack pkgconf "$VERSION" "$STAGEROOT" "$OUTROOT"
