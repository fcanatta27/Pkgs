#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar gzip install

fetch_url "$URL" "$SRCROOT/src.tar.gz"
tar -xf "$SRCROOT/src.tar.gz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "dejavu-fonts-*" | head -n1)"
[ -n "$src" ] || die "src dejavu não encontrado"
install -d "$STAGEROOT/usr/share/fonts"
cp -a "$src/ttf" "$STAGEROOT/usr/share/fonts/dejavu" 2>/dev/null || cp -a "$src/fonts/ttf" "$STAGEROOT/usr/share/fonts/dejavu" 2>/dev/null || :
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
