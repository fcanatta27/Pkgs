#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make tar bzip2

fetch_url "$URL" "$SRCROOT/busybox.tar.bz2"
tar -xf "$SRCROOT/busybox.tar.bz2" -C "$SRCROOT"
cd "$SRCROOT"/busybox-*

# Config padrão (defconfig) + ajustes úteis p/ initramfs/desktop base
make defconfig
# garante features básicas (best-effort)
# você pode substituir por um .config em files/ depois
make -j"$JOBS"
make CONFIG_PREFIX="$STAGEROOT" install

# Link /bin/sh -> ash (se não existir)
mkdir -p "$STAGEROOT/bin" "$STAGEROOT/sbin" "$STAGEROOT/usr/bin" "$STAGEROOT/usr/sbin" 2>/dev/null || :
[ -e "$STAGEROOT/bin/sh" ] || ln -s busybox "$STAGEROOT/bin/sh" 2>/dev/null || :

bk pack busybox "$VERSION" "$STAGEROOT" "$OUTROOT"
