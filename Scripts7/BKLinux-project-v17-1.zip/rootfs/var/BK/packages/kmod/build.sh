#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/kmod.tar.xz"
tar -xf "$SRCROOT/kmod.tar.xz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/kmod-*/configure --prefix=/usr --libdir=/lib --bindir=/usr/bin --sbindir=/usr/bin
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
# compat links
ln -sf kmod "$STAGEROOT/usr/bin/modprobe" 2>/dev/null || :
ln -sf kmod "$STAGEROOT/usr/bin/lsmod" 2>/dev/null || :
ln -sf kmod "$STAGEROOT/usr/bin/insmod" 2>/dev/null || :
ln -sf kmod "$STAGEROOT/usr/bin/rmmod" 2>/dev/null || :
bk pack kmod "$VERSION" "$STAGEROOT" "$OUTROOT"
