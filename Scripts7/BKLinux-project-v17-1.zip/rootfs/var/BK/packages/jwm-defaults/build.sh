#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
install -d "$STAGEROOT/etc/skel" "$STAGEROOT/etc/jwm"
install -m 0755 "$PKGDIR/files/etc/skel/.xinitrc" "$STAGEROOT/etc/skel/.xinitrc"
install -m 0644 "$PKGDIR/files/etc/jwm/system.jwmrc" "$STAGEROOT/etc/jwm/system.jwmrc"
install -m 0644 "$PKGDIR/files/etc/jwm/theme.jwmrc" "$STAGEROOT/etc/jwm/theme.jwmrc"
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
