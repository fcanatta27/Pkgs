#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"

install -d "$STAGEROOT/etc/fonts" "$STAGEROOT/etc/fonts/conf.d" "$STAGEROOT/usr/share/fontconfig/conf.avail"
install -m 0644 "$PKGDIR/files/etc/fonts/local.conf" "$STAGEROOT/etc/fonts/local.conf"
install -m 0644 "$PKGDIR/files/usr/share/fontconfig/conf.avail/99-bklinux-enable-bitmaps.conf" "$STAGEROOT/usr/share/fontconfig/conf.avail/99-bklinux-enable-bitmaps.conf"

# symlink para conf.d
ln -sf /usr/share/fontconfig/conf.avail/99-bklinux-enable-bitmaps.conf "$STAGEROOT/etc/fonts/conf.d/99-bklinux-enable-bitmaps.conf" 2>/dev/null || :

bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
