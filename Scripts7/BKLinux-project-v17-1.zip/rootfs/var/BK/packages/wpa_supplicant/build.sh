#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar gzip
fetch_url "$URL" "$SRCROOT/wpa.tar.gz"
tar -xf "$SRCROOT/wpa.tar.gz" -C "$SRCROOT"
cd "$SRCROOT"/wpa_supplicant-*/wpa_supplicant
cp defconfig .config
# minimal: openssl, nl80211
echo "CONFIG_TLS=openssl" >> .config
echo "CONFIG_DRIVER_NL80211=y" >> .config
make -j"$JOBS"
install -d "$STAGEROOT/usr/sbin" "$STAGEROOT/etc/wpa_supplicant" 2>/dev/null || :
install -m 0755 wpa_supplicant "$STAGEROOT/usr/sbin/"
bk pack wpa_supplicant "$VERSION" "$STAGEROOT" "$OUTROOT"
