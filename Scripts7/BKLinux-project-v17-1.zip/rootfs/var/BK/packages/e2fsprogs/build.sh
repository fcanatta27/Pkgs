#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar gzip
fetch_url "$URL" "$SRCROOT/e2fsprogs.tar.gz"
tar -xf "$SRCROOT/e2fsprogs.tar.gz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/e2fsprogs-*/configure --prefix=/usr --libdir=/lib --sysconfdir=/etc --enable-elf-shlibs
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack e2fsprogs "$VERSION" "$STAGEROOT" "$OUTROOT"
