#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
# rfkill vem do util-linux; este pacote só cria link/alias se rfkill existir.
mkdir -p "$STAGEROOT/usr/sbin" "$STAGEROOT/usr/bin" 2>/dev/null || :
if [ -x /usr/sbin/rfkill ]; then
  install -m 0755 /usr/sbin/rfkill "$STAGEROOT/usr/sbin/rfkill"
elif [ -x /usr/bin/rfkill ]; then
  install -m 0755 /usr/bin/rfkill "$STAGEROOT/usr/bin/rfkill"
else
  die "rfkill não encontrado (instale util-linux completo com rfkill)"
fi
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
