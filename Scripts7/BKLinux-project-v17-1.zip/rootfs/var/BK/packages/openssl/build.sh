#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar gzip perl
fetch_url "$URL" "$SRCROOT/openssl.tar.gz"
tar -xf "$SRCROOT/openssl.tar.gz" -C "$SRCROOT"
cd "$SRCROOT"/openssl-*
# shared + /lib
./Configure linux-x86_64 --prefix=/usr --openssldir=/etc/ssl --libdir=/lib shared zlib
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install_sw
bk pack openssl "$VERSION" "$STAGEROOT" "$OUTROOT"
