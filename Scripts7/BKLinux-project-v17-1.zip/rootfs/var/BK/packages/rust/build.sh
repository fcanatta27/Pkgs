#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar xz sh

fetch_url "$URL" "$SRCROOT/rust.tar.xz"
tar -xf "$SRCROOT/rust.tar.xz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "rust-*" | head -n1)"
[ -n "$src" ] || die "src rust não encontrado"
sh "$src/install.sh" --prefix=/usr --destdir="$STAGEROOT" --disable-ldconfig
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
