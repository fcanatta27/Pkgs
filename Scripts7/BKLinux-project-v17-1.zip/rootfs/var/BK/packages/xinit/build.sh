#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz

fetch_url "$URL" "$SRCROOT/src.tar.xz"
tar -xf "$SRCROOT/src.tar.xz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/xinit-*/configure --prefix=/usr --libdir=/lib 
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install

# BKLinux: permitir hooks em /etc/X11/xinit/xinitrc.d/*.sh
install -d "$STAGEROOT/etc/X11/xinit/xinitrc.d" 2>/dev/null || :
cat > "$STAGEROOT/etc/X11/xinit/xinitrc" <<'EORC'
#!/bin/sh
# xinitrc padrão BKLinux (com suporte a /etc/X11/xinit/xinitrc.d)
# POSIX sh.
# - Executa hooks (*.sh) em ordem lexical.
# - Usa ~/.xinitrc se existir e for executável.
# - Caso contrário, tenta /etc/skel/.xinitrc como fallback.
set -eu

HOOKDIR=/etc/X11/xinit/xinitrc.d
if [ -d "$HOOKDIR" ]; then
  for f in "$HOOKDIR"/*.sh; do
    [ -f "$f" ] || continue
    # shellcheck disable=SC1090
    . "$f" || :
  done
fi

if [ -x "$HOME/.xinitrc" ]; then
  exec "$HOME/.xinitrc"
fi

if [ -f /etc/skel/.xinitrc ]; then
  # executa com sh para não depender de permissão x no skel
  exec sh /etc/skel/.xinitrc
fi

exec xterm
EORC
chmod 0755 "$STAGEROOT/etc/X11/xinit/xinitrc"

bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
