# /etc/profile.d/bklinux-startx.sh
# Inicia startx automaticamente após login em tty1 quando configurado
conf="/etc/bk/display.conf"
[ -f "$conf" ] || return 0
. "$conf" 2>/dev/null || return 0
[ "${ENABLE:-0}" = "1" ] || return 0
[ "${MODE:-}" = "startx" ] || return 0
[ "${AUTOLOGIN:-0}" = "0" ] || return 0
# Só em console local (tty1)
tty="$(tty 2>/dev/null || echo "")"
[ "$tty" = "/dev/tty1" ] || return 0
# Evitar loops
[ -n "${DISPLAY:-}" ] && return 0
[ -n "${SSH_TTY:-}" ] && return 0
[ -f "/run/.bklinux.startx.done" ] && return 0
mkdir -p /run 2>/dev/null || :
: > /run/.bklinux.startx.done
exec startx >/dev/null 2>&1
