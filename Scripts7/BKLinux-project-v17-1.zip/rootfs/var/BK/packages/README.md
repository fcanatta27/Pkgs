# BK Packages

Cada pacote fica em:

/var/BK/packages/<nome>/
  - pkg.conf   (metadata e deps)
  - build.sh   (constrói e gera tarball BK)
  - files/     (patches/configs/scripts auxiliares)

Use:
  bk-wrap list
  bk-wrap build <nome>
  bk-wrap install <nome>
