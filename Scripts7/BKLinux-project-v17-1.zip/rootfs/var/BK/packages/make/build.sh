#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar gzip
fetch_url "$URL" "$SRCROOT/src.tar.gz"
tar -xf "$SRCROOT/src.tar.gz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "make-*" | head -n1)"
[ -n "$src" ] || die "src não encontrado: make-*"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$src/configure" --prefix=/usr --libdir=/lib 
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
