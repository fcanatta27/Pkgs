#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
install -d "$STAGEROOT/etc/bk" "$STAGEROOT/etc/init.d"
install -m 0644 "$PKGDIR/files/etc/bk/login.conf" "$STAGEROOT/etc/bk/login.conf"
install -m 0755 "$PKGDIR/files/etc/init.d/login-policy" "$STAGEROOT/etc/init.d/login-policy"
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
