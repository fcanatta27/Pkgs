#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
install -d "$STAGEROOT/etc/pam.d"
install -m 0644 "$PKGDIR/files/etc/pam.d/system-auth" "$STAGEROOT/etc/pam.d/system-auth"
install -m 0644 "$PKGDIR/files/etc/pam.d/login" "$STAGEROOT/etc/pam.d/login"
install -m 0644 "$PKGDIR/files/etc/pam.d/system-auth" "$STAGEROOT/etc/pam.d/su"
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
