#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar gzip

fetch_url "$URL" "$SRCROOT/src.tar.gz"
tar -xf "$SRCROOT/src.tar.gz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "cmake-*" | head -n1)"
[ -n "$src" ] || die "src cmake não encontrado"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$src/bootstrap" --prefix=/usr --parallel="$JOBS"
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
