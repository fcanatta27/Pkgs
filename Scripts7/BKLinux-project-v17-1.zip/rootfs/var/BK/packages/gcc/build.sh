#!/bin/sh
# build.sh - GCC 15.2.0 (BKLinux)
#
# Requer (host/build):
# - um compilador C++ funcional (bootstrap), make, bash, sed, awk, grep, tar, xz
# - libs/prereqs: GMP, MPFR, MPC (via contrib/download_prerequisites)
# - opcional: isl, zlib, texinfo (para docs)
#
# Saída: gera tarball BK em $OUTROOT: gcc-15.2.0.tar.gz
#
set -eu
. /lib/bk/common.sh

NAME=gcc
VER=15.2.0
URL="https://gcc.gnu.org/pub/gcc/releases/gcc-${VER}/gcc-${VER}.tar.xz"

require_cmd tar xz make awk sed grep

# Diretórios providos pelo bk-wrap:
: "${SRCROOT:?}"
: "${BUILDROOT:?}"
: "${STAGEROOT:?}"
: "${OUTROOT:?}"
: "${JOBS:=1}"

log_stage "[$NAME] versão $VER"
log_stage "[$NAME] baixando tarball"
mkdir -p "$SRCROOT" "$BUILDROOT" "$STAGEROOT" 2>/dev/null || :

TARBALL="$SRCROOT/gcc-${VER}.tar.xz"
if [ ! -f "$TARBALL" ]; then
  fetch_url "$URL" "$TARBALL"
fi
log_ok "[$NAME] tarball: $TARBALL"

# Extrair fontes
SRCDIR="$SRCROOT/gcc-${VER}"
if [ ! -d "$SRCDIR" ]; then
  log_stage "[$NAME] extraindo"
  tar -xf "$TARBALL" -C "$SRCROOT"
fi

# Baixar prerequisites oficiais (GMP/MPFR/MPC) via script do GCC
log_stage "[$NAME] prerequisites (GMP/MPFR/MPC)"
( cd "$SRCDIR" && \
  if [ -x ./contrib/download_prerequisites ]; then
    ./contrib/download_prerequisites
  else
    die "Script contrib/download_prerequisites não encontrado"
  fi
)

# Build out-of-tree
BD="$BUILDROOT/gcc-build"
mkdir -p "$BD" 2>/dev/null || :
cd "$BD"

# Opções recomendadas para desktop (sem multilib por padrão)
# Ajuste conforme sua arquitetura/objetivo.
PREFIX="/usr"
SYSLIBDIR="lib"

# Se x86_64, muita gente usa lib; se você preferir lib64, ajuste SYSLIBDIR.
# Exemplo para lib64:
#   SYSLIBDIR="lib64"

log_stage "[$NAME] configurando"
# GCC exige bash em alguns scripts, mas mantemos /bin/sh chamando bash quando necessário.
# Se seu /bin/bash não existir ainda, crie/instale antes de compilar GCC.
if ! command -v bash >/dev/null 2>&1; then
  die "bash é necessário para construir GCC. Instale bash no host/base."
fi

# Configurar
"$SRCDIR/configure" \
  --prefix="$PREFIX" \
  --libdir="$PREFIX/$SYSLIBDIR" \
  --disable-multilib \
  --disable-bootstrap \
  --enable-languages=c,c++,fortran,objc,obj-c++ \
  --enable-shared \
  --enable-threads=posix \
  --enable-__cxa_atexit \
  --enable-initfini-array \
  --with-system-zlib \
  --disable-nls

log_stage "[$NAME] compilando (-j$JOBS)"
make -j"$JOBS"

log_stage "[$NAME] instalando em STAGE"
# Instala em staging para empacotar
make DESTDIR="$STAGEROOT" install-strip

# Sanidade mínima: garantir que gcc existe
[ -x "$STAGEROOT/$PREFIX/bin/gcc" ] || die "gcc não foi instalado no staging"

# Empacotar via bk pack usando staging como raiz
# Criar um diretório fonte contendo apenas o conteúdo final (sem DESTDIR prefix extra)
# Aqui STAGEROOT já tem /usr/..., então pack direto do STAGEROOT.
log_stage "[$NAME] empacotando (BK)"
bk pack "$NAME" "$VER" "$STAGEROOT" "$OUTROOT"

log_ok "[$NAME] pronto"
