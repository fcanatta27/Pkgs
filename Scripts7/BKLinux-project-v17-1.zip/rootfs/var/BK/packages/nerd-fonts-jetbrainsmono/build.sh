#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar xz install

fetch_url "$URL" "$SRCROOT/jb.tar.xz"
mkdir -p "$SRCROOT/unpack"
tar -xf "$SRCROOT/jb.tar.xz" -C "$SRCROOT/unpack"
install -d "$STAGEROOT/usr/share/fonts/nerd-fonts"
find "$SRCROOT/unpack" -type f \( -name "*.ttf" -o -name "*.otf" \) | while IFS= read -r f; do
  install -m 0644 "$f" "$STAGEROOT/usr/share/fonts/nerd-fonts/$(basename "$f")"
done
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
