#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz bash
fetch_url "$URL" "$SRCROOT/gcc.tar.xz"
tar -xf "$SRCROOT/gcc.tar.xz" -C "$SRCROOT"
cd "$SRCROOT"/gcc-*
./contrib/download_prerequisites
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/gcc-*/configure --prefix=/usr --libdir=/lib --disable-multilib --enable-languages=c --disable-bootstrap
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install-strip
bk pack gcc-stage1 "$VERSION" "$STAGEROOT" "$OUTROOT"
