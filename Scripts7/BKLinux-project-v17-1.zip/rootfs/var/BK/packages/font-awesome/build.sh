#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd unzip install

fetch_url "$URL" "$SRCROOT/fa.zip"
mkdir -p "$SRCROOT/unzip"
unzip -q "$SRCROOT/fa.zip" -d "$SRCROOT/unzip" || die "unzip falhou"

install -d "$STAGEROOT/usr/share/fonts/fontawesome"
find "$SRCROOT/unzip" -type f \( -name "*.otf" -o -name "*.ttf" \) | while IFS= read -r f; do
  install -m 0644 "$f" "$STAGEROOT/usr/share/fonts/fontawesome/$(basename "$f")"
done
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
