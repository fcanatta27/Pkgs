#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar gzip

fetch_url "$URL" "$SRCROOT/bash.tar.gz"
tar -xf "$SRCROOT/bash.tar.gz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/bash-*/configure --prefix=/usr --libdir=/lib --without-bash-malloc
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
# default sh -> bash (opcional; você pode preferir busybox ash)
mkdir -p "$STAGEROOT/bin" 2>/dev/null || :
ln -sf /usr/bin/bash "$STAGEROOT/bin/bash" 2>/dev/null || :
bk pack bash "$VERSION" "$STAGEROOT" "$OUTROOT"
