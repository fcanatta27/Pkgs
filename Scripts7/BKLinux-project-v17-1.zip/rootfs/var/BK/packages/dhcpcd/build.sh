#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar xz
fetch_url "$URL" "$SRCROOT/dhcpcd.tar.xz"
tar -xf "$SRCROOT/dhcpcd.tar.xz" -C "$SRCROOT"
cd "$SRCROOT"/dhcpcd-*
./configure --prefix=/usr --libdir=/lib --sbindir=/usr/sbin
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack dhcpcd "$VERSION" "$STAGEROOT" "$OUTROOT"
