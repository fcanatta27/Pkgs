#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar gzip

fetch_url "$URL" "$SRCROOT/src.tgz"
tar -xf "$SRCROOT/src.tgz" -C "$SRCROOT"
mkdir -p "$BUILDROOT"
cd "$BUILDROOT"
"$SRCROOT"/xterm-*/configure --prefix=/usr --libdir=/lib
make -j"$JOBS"
make DESTDIR="$STAGEROOT" install
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
