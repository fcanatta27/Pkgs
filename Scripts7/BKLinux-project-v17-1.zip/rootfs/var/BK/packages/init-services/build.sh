#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"

# Instala scripts de init
for f in $(cd "$PKGDIR/files" && find etc/init.d -type f); do
  src="$PKGDIR/files/$f"
  dst="$STAGEROOT/$f"
  mkdir -p "$(dirname "$dst")" 2>/dev/null || :
  # functions fica 0644; demais 0755
  mode=0755
  [ "$(basename "$f")" = "functions" ] && mode=0644
  install -m "$mode" "$src" "$dst"
done

bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
