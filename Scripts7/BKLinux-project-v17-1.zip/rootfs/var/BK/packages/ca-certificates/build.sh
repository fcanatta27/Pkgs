#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd install

fetch_url "$URL" "$SRCROOT/cacert.pem"
mkdir -p "$STAGEROOT/etc/ssl/certs" "$STAGEROOT/usr/share/ca-certificates" 2>/dev/null || :
install -m 0644 "$SRCROOT/cacert.pem" "$STAGEROOT/etc/ssl/certs/ca-certificates.crt"
bk pack ca-certificates "$VERSION" "$STAGEROOT" "$OUTROOT"
