#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar gzip install

fetch_url "$URL" "$SRCROOT/src.tar.gz"
tar -xf "$SRCROOT/src.tar.gz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "fonts-android-*" | head -n1)"
[ -n "$src" ] || die "src fonts-android não encontrado"

install -d "$STAGEROOT/usr/share/fonts/droid"
find "$src" -type f \( -name "*.ttf" -o -name "*.otf" \) | while IFS= read -r f; do
  install -m 0644 "$f" "$STAGEROOT/usr/share/fonts/droid/$(basename "$f")"
done
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
