#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar gzip python3

fetch_url "$URL" "$SRCROOT/src.tar.gz"
tar -xf "$SRCROOT/src.tar.gz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "ninja-*" | head -n1)"
[ -n "$src" ] || die "src ninja não encontrado"
cd "$src"

python3 configure.py --bootstrap
install -d "$STAGEROOT/usr/bin"
install -m 0755 ninja "$STAGEROOT/usr/bin/ninja"

bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
