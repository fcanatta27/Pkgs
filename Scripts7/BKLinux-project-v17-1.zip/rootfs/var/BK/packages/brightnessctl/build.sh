#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd make gcc tar gzip

fetch_url "$URL" "$SRCROOT/src.tar.gz"
tar -xf "$SRCROOT/src.tar.gz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "brightnessctl-*" | head -n1)"
[ -n "$src" ] || die "src brightnessctl não encontrado"
make -C "$src" -j"$JOBS"
install -d "$STAGEROOT/usr/bin"
install -m 0755 "$src/brightnessctl" "$STAGEROOT/usr/bin/"
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
