#!/bin/sh
# base-files - estrutura base do sistema
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"

# Estrutura
for d in \
  bin sbin lib usr usr/bin usr/sbin usr/lib etc etc/init.d etc/bk \
  var var/log var/lib var/cache var/tmp \
  run tmp root home mnt proc sys dev dev/pts dev/shm; do
  mkdir -p "$STAGEROOT/$d" 2>/dev/null || :
done
chmod 0755 "$STAGEROOT" 2>/dev/null || :
chmod 1777 "$STAGEROOT/tmp" "$STAGEROOT/var/tmp" 2>/dev/null || :

# Arquivos templates
cd "$PKGDIR/files"
# copiar mantendo paths
find . -type f ! -name '.keep' -print | while IFS= read -r f; do
  dst="$STAGEROOT/${f#./}"
  mkdir -p "$(dirname "$dst")" 2>/dev/null || :
  install -m 0644 "$f" "$dst"
done

# permissões especiais
chmod 0644 "$STAGEROOT/etc/passwd" "$STAGEROOT/etc/group" 2>/dev/null || :

bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
