#!/bin/sh
set -eu
. /lib/bk/common.sh
. "$PKGDIR/pkg.conf"
require_cmd tar xz make install

fetch_url "$URL" "$SRCROOT/src.tar.xz"
tar -xf "$SRCROOT/src.tar.xz" -C "$SRCROOT"
src="$(find "$SRCROOT" -maxdepth 1 -type d -name "terminus-font-*" | head -n1)"
[ -n "$src" ] || die "src terminus-font não encontrado"
make -C "$src" -j"$JOBS" psf
install -d "$STAGEROOT/usr/share/consolefonts"
find "$src" -type f -name "*.psf.gz" | while IFS= read -r f; do
  install -m 0644 "$f" "$STAGEROOT/usr/share/consolefonts/$(basename "$f")"
done
bk pack "$NAME" "$VERSION" "$STAGEROOT" "$OUTROOT"
