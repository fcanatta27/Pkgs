Cache binário BK em /var/3Blinux/cache
