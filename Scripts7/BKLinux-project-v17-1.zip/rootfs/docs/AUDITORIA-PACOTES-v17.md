# Auditoria de pacotes BK (v17)
Gerado em: 2026-01-14T14:26:16.897509Z
Total pacotes: 132

## Achados (heurística)
- **gcc**: build.sh missing set -eu 

## Ações aplicadas no v17
- Adicionado `base-users` e integração no boot.
- Adicionado `pam-config-hardened` opcional.
- Fixados URLs/versões de fontes sensíveis.
