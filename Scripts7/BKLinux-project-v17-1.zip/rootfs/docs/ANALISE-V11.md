# ANÁLISE (v11) – O que falta para o BKLinux ficar “realmente funcional” (desktop completo)

Este projeto já cobre:
- toolchain (linux-headers/binutils/gcc/glibc)
- base-files + init-services + mkinitramfs
- rede básica (dhcpcd + wpa_supplicant + iw)
- udev coldplug melhorado + rules mínimas
- profiles base/desktop/notebook
- cache binário (/var/3Blinux/cache)
- instalador semi-automático (bk-install-system)

## Pontos que ainda faltam para um desktop 100% “plug and play”
### 1) Dependências do Xorg-server (árvore mais ampla)
O Xorg-server, dependendo das opções e do hardware, costuma exigir mais bibliotecas X11/Font/XKB.
No v11 eu fechei o bloco pedido (expat/libffi/wayland/meson/ninja/xcb-util*/fonts adicionais), mas ainda podem faltar, conforme a configuração:
- libXfixes, libXi, libXcursor, libXinerama, libXtst, libXdamage, libXcomposite, libXpresent, libepoxy, libxshmfence, libXfont2, xkbcomp, xkeyboard-config, etc.

### 2) Mesa (GL) com aceleração real
Mesa normalmente requer:
- meson+ninja (incluídos) e python3
- várias libs opcionais: zstd, llvm, libunwind, libdrm (incluída), expat (incluída)
Sem essas, você ainda pode ter Xorg funcional, mas sem aceleração completa.

### 3) Sessão de desktop
O profile usa Openbox + xterm como sessão mínima.
Para “desktop moderno” faltaria:
- compositor (picom) opcional
- gerenciador de rede (opcional; atualmente é scripts + wpa_supplicant)
- áudio (alsa/pipewire), bluetooth, printing, etc.

### 4) Boot: GRUB instalação final
O pacote grub compila e instala arquivos, mas o passo `grub-install` é inerentemente dependente do modo (UEFI/BIOS) e do disco real.

## O que foi feito para “integrar no boot”
- Pacote `display-manager`:
  - cria `/etc/bk/display.conf` (ENABLE=0 por padrão)
  - adiciona `/etc/profile.d/bklinux-startx.sh` para modo autologin+startx (somente quando configurado)
  - substitui `/etc/init.d/display` com lógica segura:
    - só tenta autologin se configurado e se getty suportar `-a`
    - caso contrário, não força autologin e deixa startx acontecer após login

## Recomendação objetiva para estabilizar desktop
1) adicionar pacote `xkeyboard-config` + `xkbcomp`
2) adicionar libs X11 que o Xorg geralmente exige (listadas acima)
3) adicionar `alsa-utils` ao base/notebook (somente se você quiser áudio)
