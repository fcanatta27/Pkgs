# BKLinux – Auditoria v16 (login endurecido)

## Login seguro sem DM pesado
Pacotes adicionados:
- linux-pam (1.7.1)
- shadow (4.19.0) com --with-libpam
- pam-config-min (configs mínimas em /etc/pam.d)
- util-linux (ferramentas complementares; login/su desabilitados aqui para evitar conflito)

O xlogin-min foi ajustado para preferir `login` se existir; caso contrário usa `su`.

## O que ainda é recomendado
- Fixar checksums por pacote (URL pode mudar).
- Completar base-users (usuários/grupos) e garantir senhas (`passwd` do shadow).
- Se quiser políticas PAM mais fortes: adicionar módulos (faillock, limits, env) e arquivos /etc/security/*.
