# Perfil base BKLinux (boot real)

Este perfil agora inclui:
- `base-files` (estrutura /etc + templates)
- `init-services` (scripts /etc/init.d usados pelo rcS)
- `mkinitramfs` (gerador POSIX + template /init)

## Instalação no sysroot (host)
Exemplo:
  mkdir -p /mnt/bklinux-root
  export DESTDIR=/mnt/bklinux-root

  bk-profile install base

## Gerar initramfs
Assumindo kernel 6.8 instalado no sysroot:

  /mnt/bklinux-root/usr/sbin/mkinitramfs -k 6.8 -r /mnt/bklinux-root -o /mnt/bklinux-root/boot/initramfs-6.8.cpio.gz

## Boot
1. Ajuste `/mnt/bklinux-root/etc/fstab`
2. Instale GRUB (modo BIOS/UEFI conforme seu disco):
   - `grub-install ...`
   - `grub-mkconfig -o /boot/grub/grub.cfg`
