# mkinitramfs (BKLinux)

Pacote `mkinitramfs` instala:
- `/usr/sbin/mkinitramfs`
- template de `/init` em `/usr/share/bklinux/initramfs/init`

## Uso (no host)
Assumindo sysroot em /mnt/bklinux-root e kernel 6.8:

  mkinitramfs -k 6.8 -r /mnt/bklinux-root -o /mnt/bklinux-root/boot/initramfs-6.8.cpio.gz

Depois ajuste o GRUB para apontar para:
- vmlinuz-6.8
- initramfs-6.8.cpio.gz
