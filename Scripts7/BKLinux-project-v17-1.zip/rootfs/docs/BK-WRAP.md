# bk-wrap (v5)

Wrapper de build para BKLinux.

## Estrutura de pacotes
`/var/BK/packages/<pkg>/`

- `pkg.conf` (opcional): NAME, VERSION, URL, SHA512, DEPS
- `build.sh` (obrigatório): constrói e gera tarball BK (via `bk pack`)
- `files/`: patches/configs/scripts auxiliares

## Comandos
- `bk-wrap list`
- `bk-wrap info <pkg>`
- `bk-wrap build <pkg>`
- `bk-wrap install <pkg>`
- `bk-wrap clean <pkg>`

## Diretórios
- work: `/var/BK/work/<pkg>/`
- out:  `/var/BK/out/`
- logs: `/var/BK/logs/`

## Observação importante (GCC)
Construir GCC exige um compilador C/C++ prévio (bootstrap) e `bash`.
O script usa `contrib/download_prerequisites` do GCC para obter GMP/MPFR/MPC.
