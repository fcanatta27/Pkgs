# Análise e correções (v7)

## Problemas reais encontrados

1. **Cadeia de toolchain ausente no projeto**: não existiam os pacotes `linux-headers`, `binutils`, `glibc-bootstrap`, `gcc-stage1`, `glibc` (necessários para "construir do zero").

2. **Bug funcional no `bk-wrap` (ordem de dependências)**: a resolução DFS podia executar o pacote antes das dependências.

3. **Build scripts incompletos/ inválidos**: vários `build.sh` chamavam `fetch_url "$URL"` e `bk pack ... "$VERSION"` sem definir `URL`/`VERSION`. Isso quebrava em tempo de execução.

4. **Perfil `base` não incluía toolchain**: o profile apontava só para userland, impossibilitando uma construção do zero consistente.


## Correções aplicadas

- Integrei a cadeia de toolchain completa (x86_64, /lib): `linux-headers`, `binutils`, `glibc-bootstrap`, `gcc-stage1`, `glibc`.

- Ajustei `bk-wrap` para exportar variáveis do `pkg.conf` (`NAME`, `VERSION`, `URL`, `SHA512`, `DEPS`) para o ambiente do build.

- Padronizei os `build.sh` para **sempre** carregar `pkg.conf` via `. "$PKGDIR/pkg.conf"` quando usam `URL`/`VERSION`.

- Criei profile `toolchain` e reescrevi profile `base` com toolchain no topo.

- Ajustei `gcc` para depender de `glibc`.


## O que ainda depende do seu ambiente (sem suposições)

- Alguns pacotes (ex.: `openssl`, `grub`, `linux`) podem exigir ferramentas no host (perl, bison/flex, etc.) dependendo do host. Os scripts falham com log claro.

- `grub-install` é sempre específico do layout/UEFI/BIOS; o pacote compila, mas a instalação do bootloader é uma etapa manual.

- Kernel: `make defconfig` é genérico. Para notebook real, você provavelmente vai usar `.config` próprio em `files/`.
