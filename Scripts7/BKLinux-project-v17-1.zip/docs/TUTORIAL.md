# Tutorial completo (do zero) - BusyBox init + rcS/rcK

Este guia assume que você quer um sistema mínimo com initramfs (raiz no RAM) e **BusyBox init**.

## 1) Pré-requisitos

Você precisa de:
- Um **kernel Linux** (bzImage)
- Um **BusyBox** preferencialmente **estático** (evita dependência de glibc no initramfs)
- Ferramentas no host: `cpio`, `gzip`, `qemu-system-x86_64` (para testes)

## 2) Estrutura de arquivos (o que importa)

- `/init`  
  É o primeiro processo do initramfs (rdinit=/init). Faz mounts básicos e chama `/sbin/init`.

- `/sbin/init`  
  É o **BusyBox init** (PID 1). Ele lê `/etc/inittab`.

- `/etc/inittab`  
  Define:
  - `::sysinit:/etc/init.d/rcS` (boot)
  - `::shutdown:/etc/init.d/rcK` (desligamento)
  - `getty` em `tty1` e `ttyS0`

- `/etc/init.d/rcS`  
  Orquestra o boot chamando scripts modulares:
  - `seed` (dirs/perms + /dev mínimo)
  - `mdev` (popula /dev via BusyBox mdev)
  - `syslog` (syslogd/klogd)
  - `network` (udhcpc opcional)
  - `autorepair` (bk-autorepair)

- `/etc/init.d/rcK`  
  Para serviços e desmonta FS.

## 3) Colocar BusyBox

Coloque o binário em:
- `rootfs/bin/busybox` e marque como executável.

Depois gere o symlink (o script já faz isso):
- `/sbin/init -> /bin/busybox`

## 4) Gerar initramfs

No diretório do projeto:
```sh
cd tools
./gen_initramfs.sh
```

O arquivo final fica em:
- `dist/initramfs.cpio.gz`

## 5) Testar em QEMU (serial)

Exemplo:
```sh
qemu-system-x86_64 -m 512 -kernel bzImage \
  -initrd dist/initramfs.cpio.gz \
  -append "console=ttyS0 rdinit=/init" -nographic
```

Se tudo estiver OK:
- você verá logs do `rcS`
- terá um console em `/dev/ttyS0`

## 6) Fluxo de boot (o que acontece)

1. Kernel executa `/init`
2. `/init` monta `/proc`, `/sys`, tenta `/dev`
3. `/init` chama `/sbin/init`
4. BusyBox init lê `/etc/inittab` e executa `rcS`
5. `rcS` monta `/run`, cria base do FS, popula /dev, inicia logs e rede (se habilitada)
6. init inicia `getty` em tty1 e ttyS0

## 7) Principais causas de “init inutilizável” e como estes scripts evitam

- **Sem /dev/console**: o `/init` cria fallback com `mknod`.
- **Sem /proc ou /sys**: mounts são tentados cedo e repetidos no `rcS`.
- **Sem /tmp com 1777**: `seed` ajusta permissões.
- **Sem getty**: inittab inclui shell de fallback `::respawn:-/bin/sh`.
- **Sem syslogd/klogd**: `syslog` degrada com warning, sem quebrar boot.
- **Race /dev incompleto**: `seed` cria nós mínimos e `mdev -s` repovoa.

## 8) Customização rápida

- Desabilitar rede: comente `run_script network` em `rcS`
- Trocar interface: exporte `IFACE=ens3` no ambiente, ou adapte `network`
- Comandos extras: edite `/etc/init.d/rc.local`

## 9) Próximos passos (quando você sair do mínimo)

- pivot_root/switch_root para uma root real em disco
- fsck/mount de /, /home etc.
- login (shadow) e permissões
- udev (se sair do BusyBox)
- Xorg/desktop (isso já é outro estágio, com mais dependências)
