# Guia detalhado do wrapper `lfs-chroot-build`

Este documento explica, em detalhes, como funciona o script
`lfs-chroot-build`, por que ele foi escrito dessa forma e quais recursos
de shell (Bash) ele utiliza. A ideia é servir como material de estudo para
você entender e modificar o wrapper com segurança.

---

## 1. Visão geral

O arquivo do wrapper fica, no projeto, em:

```text
project/lfs-scripts-chroot/lfs-chroot-build
```

A proposta do `lfs-chroot-build` é:

- rodar, **dentro do chroot**, os scripts de construção dos pacotes
  do capítulo 8 do LFS;
- manter um **registro de quais pacotes já foram construídos**;
- permitir retomar a construção a partir do primeiro pacote pendente;
- ser fácil de estender: basta adicionar scripts novos em
  `lfs-scripts-chroot/` e listar o nome no array `STEPS`.

Depois de instalado no chroot em `/usr/local/sbin`, o fluxo típico é:

```bash
(lfs chroot) root:/# lfs-chroot-build list
(lfs chroot) root:/# lfs-chroot-build build
(lfs chroot) root:/# lfs-chroot-build continue
(lfs chroot) root:/# lfs-chroot-build redo texinfo-7.2
```

---

## 2. Cabeçalho, shebang e comentários

As primeiras linhas do script são:

```bash
#!/usr/bin/env bash
#
# lfs-chroot-build
#
# Mini-wrapper inteligente para construir pacotes do capítulo 8 do LFS
# dentro do chroot, usando os scripts em lfs-scripts-chroot.
```

- `#!/usr/bin/env bash` é o **shebang**. Ele diz ao sistema que o script
  deve ser executado com o Bash.
- Os comentários `#` servem para documentar o que o script faz.
- Em seguida, há um bloco de **uso** explicando comandos e opções, que
  funciona como uma documentação embutida.

Logo depois, temos:

```bash
set -euo pipefail
```

Essas opções tornam o Bash mais seguro:

- `-e` faz o script abortar se algum comando retorna status diferente de 0
  (erro), exceto em alguns casos específicos.
- `-u` faz o script abortar se usar uma variável não definida.
- `-o pipefail` faz com que o status de uma pipeline (`cmd1 | cmd2`)
  seja considerado erro se QUALQUER comando da pipeline falhar.

---

## 3. Verificação de root e definição de caminhos

O script quer ser executado somente como `root` dentro do chroot:

```bash
if [ "$(id -u)" -ne 0 ]; then
    echo "ERRO: lfs-chroot-build deve ser executado como root dentro do chroot." >&2
    exit 1
fi
```

- `id -u` retorna o UID do usuário. Se não for 0, não é root.
- `>&2` redireciona a mensagem para o stderr.
- `exit 1` encerra o script com código de erro.

Depois, define:

```bash
SCRIPTS_DIR="${LFS_CHROOT_SCRIPTS:-/project/lfs-scripts-chroot}"
STATE_DIR="${LFS_CHROOT_STATE_DIR:-/var/lib/lfs-chroot-build}"
STATE_FILE="${STATE_DIR}/installed.steps"

mkdir -p "${STATE_DIR}"
```

- `SCRIPTS_DIR` é o diretório onde estão os scripts de pacote,
  por padrão `/project/lfs-scripts-chroot`.
  - Você pode sobrescrever com a variável de ambiente
    `LFS_CHROOT_SCRIPTS`.
- `STATE_DIR` é onde fica o estado (quais passos já rodaram),
  por padrão `/var/lib/lfs-chroot-build`.
- `STATE_FILE` é o arquivo que armazena os nomes dos passos concluídos.
- `mkdir -p` garante que o diretório existe (se não existir, cria).

---

## 4. Array `STEPS`: ordem dos pacotes

O trecho:

```bash
STEPS=(
  "gettext-0.26"
  "bison-3.8.2"
  "perl-5.42.0"
  "Python-3.14.2"
  "texinfo-7.2"
  "util-linux-2.41.3"
)
```

define um **array de Bash** com a lista de passos (pacotes) em ordem.

- Cada string corresponde a um script `NOME.sh` em `SCRIPTS_DIR`.
  - Ex.: `"gettext-0.26"` corresponde a `gettext-0.26.sh`.
- A ordem aqui representa a ordem do capítulo 8 do LFS, até Util-linux.
- Para adicionar novos pacotes mais tarde, basta incluir o nome no array,
  mantendo a sequência que o livro recomenda.

---

## 5. Funções de log com cores

O script define cores se a saída é um terminal:

```bash
if [ -t 1 ]; then
    C_RESET=$'\033[0m'
    C_OK=$'\033[1;32m'
    C_WARN=$'\033[1;33m'
    C_ERR=$'\033[1;31m'
    C_INFO=$'\033[1;34m'
else
    C_RESET=""
    C_OK=""
    C_WARN=""
    C_ERR=""
    C_INFO=""
fi

log()  { printf '%b[%s]%b %s\n' "$C_INFO" "$1" "$C_RESET" "$2"; }
ok()   { printf '%b[OK]%b   %s\n'  "$C_OK"   "$C_RESET" "$1"; }
warn() { printf '%b[WARN]%b %s\n' "$C_WARN" "$C_RESET" "$1"; }
err()  { printf '%b[FAIL]%b %s\n' "$C_ERR"  "$C_RESET" "$1"; }
```

- `-t 1` testa se o descritor de arquivo 1 (stdout) é um terminal.
- Se for, são definidas sequências ANSI para cores; senão, as cores ficam vazias.
- As funções `log`, `ok`, `warn`, `err` formatam mensagens com prefixos
  e cores:

  - `[OK]`   → verde
  - `[WARN]` → amarelo
  - `[FAIL]` → vermelho
  - `[INFO]` → azul

Isso ajuda a identificar rapidamente o que está acontecendo.

---

## 6. Funções auxiliares para passos

```bash
step_script_path() {
    local step="$1"
    echo "${SCRIPTS_DIR}/${step}.sh"
}
```

- Gera o caminho completo do script de um passo (por ex. `gettext-0.26`).

```bash
is_step_known() {
    local step="$1"
    local s
    for s in "${STEPS[@]}"; do
        if [ "${s}" = "${step}" ]; then
            return 0
        fi
    done
    return 1
}
```

- Verifica se um nome de passo está no array `STEPS`.
- `return 0` em shell significa “verdadeiro”; `return 1`, “falso”.

```bash
is_step_done() {
    local step="$1"
    if [ -f "${STATE_FILE}" ] && grep -qxF "${step}" "${STATE_FILE}" 2>/dev/null; then
        return 0
    fi
    return 1
}
```

- Verifica se o passo já foi registrado como concluído em `STATE_FILE`.
- `grep -qxF` procura uma linha exata com o nome do passo.

```bash
mark_step_done() {
    local step="$1"
    if ! is_step_done "${step}"; then
        echo "${step}" >> "${STATE_FILE}"
    fi
}
```

- Marca um passo como concluído, adicionando o nome no `STATE_FILE`
  se ele ainda não estiver lá.

```bash
unmark_step() {
    local step="$1"
    if [ -f "${STATE_FILE}" ]; then
        grep -vxF "${step}" "${STATE_FILE}" > "${STATE_FILE}.tmp" || true
        mv -f "${STATE_FILE}.tmp" "${STATE_FILE}"
    fi
}
```

- Remove um passo do arquivo de estado (usado pelo comando `redo`).

---

## 7. Comandos de alto nível: list, status, run_step

```bash
cmd_list() {
    echo "Passos do capítulo 8 conhecidos por este wrapper:"
    local s
    for s in "${STEPS[@]}"; do
        if is_step_done "${s}"; then
            printf "  %-20s : DONE\n" "${s}"
        else
            printf "  %-20s : TODO\n" "${s}"
        fi
    done
}
```

- Lista todos os passos com status `DONE` ou `TODO`.

```bash
cmd_status() {
    local total={#STEPS[@]}
    local done=0
    local s
    for s in "${STEPS[@]}"; do
        if is_step_done "${s}"; then
            done=$((done+1))
        fi
    done
    local todo=$((total-done))
    log "STATUS" "Pacotes capítulo 8: total=${total}, feitos=${done}, faltando=${todo}"
}
```

- Mostra um resumo da progressão.

A função principal para executar um passo é:

```bash
run_step() {
    local step="$1"

    if ! is_step_known "${step}"; then
        err "Passo desconhecido: ${step}"
        echo "Use 'lfs-chroot-build list' para ver a lista de passos conhecidos." >&2
        exit 1
    fi

    local script
    script="$(step_script_path "${step}")"

    if [ ! -x "${script}" ]; then
        err "Script não encontrado ou não executável: ${script}"
        echo "Verifique se o projeto foi extraído em /project ou ajuste LFS_CHROOT_SCRIPTS." >&2
        exit 1
    fi

    log "STEP" "Executando ${step} via ${script}"
    "${script}"
    mark_step_done "${step}"
    ok "Passo concluído: ${step}"
}
```

- Garante que o passo é conhecido.
- Garante que o script existe e é executável.
- Executa o script.
- Marca o passo como concluído.

---

## 8. Comandos `build`, `continue`, `step`, `redo`

```bash
cmd_build() {
    local s
    for s in "${STEPS[@]}"; do
        if is_step_done "${s}"; then
            warn "Pulando ${s}: já marcado como DONE."
            continue
        fi
        run_step "${s}"
    done
    cmd_status
}
```

- Percorre todos os passos na ordem.
- Pula os que já estão feitos.
- Executa os demais e, ao final, chama `cmd_status`.

```bash
cmd_continue() {
    local s
    for s in "${STEPS[@]}"; do
        if ! is_step_done "${s}"; then
            log "CONTINUE" "Primeiro passo pendente: ${s}"
            # Roda esse e os próximos
            local start_found=0
            for s2 in "${STEPS[@]}"; do
                if [ "${s2}" = "${s}" ]; then
                    start_found=1
                fi
                if [ "${start_found}" -eq 1 ] && ! is_step_done "${s2}"; then
                    run_step "${s2}"
                fi
            done
            cmd_status
            return 0
        fi
    done
    ok "Todos os passos já estão marcados como DONE."
    cmd_status
}
```

- Encontra o primeiro passo `TODO`.
- Executa esse passo e todos os seguintes que também estiverem pendentes.
- Se todos os passos já estão `DONE`, apenas informa.

```bash
cmd_step() {
    local step="${1:-}"
    if [ -z "${step}" ]; then
        err "Uso: lfs-chroot-build step NOME_DO_PASSO"
        exit 1
    fi
    if is_step_done "${step}"; then
        warn "Passo ${step} já está marcado como DONE. Rodando mesmo assim."
    fi
    run_step "${step}"
}
```

- Executa um passo específico, mesmo se estiver `DONE`.

```bash
cmd_redo() {
    local step="${1:-}"
    if [ -z "${step}" ]; then
        err "Uso: lfs-chroot-build redo NOME_DO_PASSO"
        exit 1
    fi
    unmark_step "${step}"
    run_step "${step}"
}
```

- Desmarca e executa o passo, efetivamente reconstruindo o pacote.

---

## 9. Função `usage` e parsing de comandos

```bash
usage() {
    cat <<EOF
Uso: lfs-chroot-build <comando>

Comandos:
  list                - Lista passos conhecidos e status DONE/TODO
  build               - Constrói todos os passos em ordem
  continue            - Continua a partir do primeiro passo não concluído
  step NOME           - Executa apenas o passo NOME (mesmo se já DONE)
  redo NOME           - Marca NOME como não concluído e executa
  status              - Mostra resumo geral

Variáveis úteis:
  LFS_CHROOT_SCRIPTS  - Caminho para os scripts (default: /project/lfs-scripts-chroot)
  LFS_CHROOT_STATE_DIR- Caminho para o estado (default: /var/lib/lfs-chroot-build)
  LFS_SKIP_TESTS      - Se =1, scripts de pacote devem pular 'make check'
EOF
}
```

No final, o script trata o comando:

```bash
cmd="${1:-}"

case "${cmd}" in
    list)     shift; cmd_list "$@" ;;
    build)    shift; cmd_build "$@" ;;
    continue) shift; cmd_continue "$@" ;;
    step)     shift; cmd_step "$@" ;;
    redo)     shift; cmd_redo "$@" ;;
    status)   shift; cmd_status "$@" ;;
    -h|--help|"")
        usage
        ;;
    *)
        err "Comando desconhecido: ${cmd}"
        usage
        exit 1
        ;;
esac
```

- Lê o primeiro argumento como comando.
- Chama uma função específica para cada comando.
- Se não houver comando ou se o comando for `--help`, mostra o uso.
- Se o comando for desconhecido, mostra erro + uso.

---

## 10. Por que foi construído assim?

Algumas decisões importantes:

1. **Idempotência via arquivo de estado**

   - Manter `installed.steps` permite rodar o wrapper muitas vezes sem
     “quebrar” o build. Ele simplesmente pula o que já foi feito.
   - Isso é útil se você interromper o build (erro, reboot, etc.).

2. **Separação de responsabilidades**

   - Cada pacote tem seu próprio script `NOME.sh`, fiel ao livro.
   - O wrapper apenas orquestra:
     - ordem,
     - repetição,
     - retomar de onde parou.

3. **Flexibilidade usando variáveis de ambiente**

   - Você pode alterar `LFS_CHROOT_SCRIPTS` e `LFS_CHROOT_STATE_DIR`
     sem editar o script, o que facilita testes e customizações.

4. **Uso de arrays e funções em Bash**

   - Arrays (`STEPS`) deixam o código mais organizado que uma lista
     “hard-coded” em if/else.
   - Funções pequenas (`is_step_done`, `run_step`) facilitam leitura
     e manutenção.

5. **Mensagens claras com cores**

   - Ajuda a identificar erros e avisos rapidamente, especialmente em
     builds longos.

Se você quiser experimentar, pode criar um wrapper seu a partir deste, mudar
a ordem dos pacotes ou adicionar novos passos, sempre mantendo a lógica de
registro de estado e idempotência.

---

## 11. Próximos estudos sugeridos

Para aprofundar em shell e no próprio wrapper, você pode:

- Estudar:
  - `man bash`
  - seções sobre arrays, funções, redirecionamento, retorno de status;
- Ler o script com calma e tentar:
  - adicionar um novo comando (por exemplo, `clean` para limpar estado);
  - logar timestamps nas mensagens;
  - registrar também o horário em que cada pacote foi concluído.

Com isso, você terá um entendimento sólido tanto do projeto quanto de Bash,
o que é extremamente útil para qualquer customização avançada de LFS.
