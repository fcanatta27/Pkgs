#!/usr/bin/env bash
#
# Script de construção LFS (capítulo 8, dentro do chroot).
#
# Este script supõe:
#   - Você já está dentro do chroot LFS (por exemplo, via bin/lfs-chroot).
#   - Os sources estão em /sources (padrão do livro) ou em $LFS_SOURCES.
#
# Uso sugerido (dentro do chroot):
#   (lfs chroot) root:/# cd /sources
#   (lfs chroot) root:/sources# /project/lfs-scripts-chroot/THIS_SCRIPT.sh
#
# Para pular testes de 'make check', defina:
#   export LFS_SKIP_TESTS=1
#
set -euo pipefail

SRC_DIR="${LFS_SOURCES:-/sources}"

find_tarball() {
    local base="$1"
    local exts=(tar.xz tar.gz tar.bz2)
    local e
    for e in "${exts[@]}"; do
        if [ -f "${SRC_DIR}/${base}.${e}" ]; then
            echo "${SRC_DIR}/${base}.${e}"
            return 0
        fi
    done
    echo "ERRO: não encontrei tarball para ${base} em ${SRC_DIR}" >&2
    exit 1
}

PKG_NAME="gettext-0.26"
TARBALL="$(find_tarball "${PKG_NAME}")"

cd "${SRC_DIR}"
rm -rf "${PKG_NAME}"
tar -xf "${TARBALL}"
cd "${PKG_NAME}"

./configure --prefix=/usr    \
            --disable-static \
            --docdir=/usr/share/doc/gettext-0.26

make

if [ "${LFS_SKIP_TESTS:-0}" != "1" ]; then
    make check
fi

make install
chmod -v 0755 /usr/lib/preloadable_libintl.so

echo "Gettext-0.26 instalado conforme o capítulo 8 do LFS (development)."
