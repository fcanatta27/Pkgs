#!/usr/bin/env bash
#
# Script de construção LFS (capítulo 8, dentro do chroot).
#
# Este script supõe:
#   - Você já está dentro do chroot LFS (por exemplo, via bin/lfs-chroot).
#   - Os sources estão em /sources (padrão do livro) ou em $LFS_SOURCES.
#
# Uso sugerido (dentro do chroot):
#   (lfs chroot) root:/# cd /sources
#   (lfs chroot) root:/sources# /project/lfs-scripts-chroot/THIS_SCRIPT.sh
#
# Para pular testes de 'make check', defina:
#   export LFS_SKIP_TESTS=1
#
set -euo pipefail

SRC_DIR="${LFS_SOURCES:-/sources}"

find_tarball() {
    local base="$1"
    local exts=(tar.xz tar.gz tar.bz2)
    local e
    for e in "${exts[@]}"; do
        if [ -f "${SRC_DIR}/${base}.${e}" ]; then
            echo "${SRC_DIR}/${base}.${e}"
            return 0
        fi
    done
    echo "ERRO: não encontrei tarball para ${base} em ${SRC_DIR}" >&2
    exit 1
}

PKG_NAME="perl-5.42.0"
TARBALL="$(find_tarball "${PKG_NAME}")"

cd "${SRC_DIR}"
rm -rf "${PKG_NAME}"
tar -xf "${TARBALL}"
cd "${PKG_NAME}"

# Segue exatamente as recomendações do LFS 8.44 (Perl-5.42.0)
export BUILD_ZLIB=False
export BUILD_BZIP2=0

sh Configure -des                                          \
             -D prefix=/usr                                \
             -D vendorprefix=/usr                          \
             -D privlib=/usr/lib/perl5/5.42/core_perl      \
             -D archlib=/usr/lib/perl5/5.42/core_perl      \
             -D sitelib=/usr/lib/perl5/5.42/site_perl      \
             -D sitearch=/usr/lib/perl5/5.42/site_perl     \
             -D vendorlib=/usr/lib/perl5/5.42/vendor_perl  \
             -D vendorarch=/usr/lib/perl5/5.42/vendor_perl \
             -D man1dir=/usr/share/man/man1                \
             -D man3dir=/usr/share/man/man3                \
             -D pager="/usr/bin/less -isR"                 \
             -D useshrplib                                 \
             -D usethreads

make

if [ "${LFS_SKIP_TESTS:-0}" != "1" ]; then
    TEST_JOBS="$(nproc)" make test_harness
fi

make install
unset BUILD_ZLIB BUILD_BZIP2

echo "Perl-5.42.0 instalado conforme o capítulo 8 do LFS (development)."
