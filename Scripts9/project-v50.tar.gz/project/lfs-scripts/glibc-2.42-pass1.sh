\
    #!/usr/bin/env bash
    #
    # Glibc-2.42 (cross, capítulo 5.5)

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="glibc-2.42-pass1"

    PKG_NAME="glibc-2.42"
    PKG_TARBALL="${PKG_NAME}.tar.xz"
    GLIBC_URL_DEFAULT="https://ftp.gnu.org/gnu/libc/${PKG_TARBALL}"
    : "${GLIBC_SRC_URL:=${GLIBC_URL_DEFAULT}}"

    GLIBC_FHS_PATCH="glibc-2.42-fhs-1.patch"
    GLIBC_FHS_URL_DEFAULT="https://www.linuxfromscratch.org/patches/lfs/development/${GLIBC_FHS_PATCH}"
    : "${GLIBC_FHS_URL:=${GLIBC_FHS_URL_DEFAULT}}"

    for tb url in \
        "${PKG_TARBALL} ${GLIBC_SRC_URL}" \
        "${GLIBC_FHS_PATCH} ${GLIBC_FHS_URL}"
    do
        set -- ${tb}
        tarball="$1"
        src="$2"
        if [ ! -f "${LFS_SRCDIR}/${tarball}" ]; then
            echo "Baixando ${tarball}..."
            curl -L -C - -o "${LFS_SRCDIR}/${tarball}" "${src}"
        fi
    done

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    case "$(uname -m)" in
        i?86)
            ln -sfv ld-linux.so.2 "${LFS_ROOTFS}/lib/ld-lsb.so.3"
        ;;
        x86_64)
            mkdir -p "${LFS_ROOTFS}/lib64"
            ln -sfv ../lib/ld-linux-x86-64.so.2 "${LFS_ROOTFS}/lib64"
            ln -sfv ../lib/ld-linux-x86-64.so.2 "${LFS_ROOTFS}/lib64/ld-lsb-x86-64.so.3"
        ;;
    esac

    patch -Np1 -i "${LFS_SRCDIR}/${GLIBC_FHS_PATCH}"

    mkdir -v build
    cd       build

    echo "rootsbindir=/usr/sbin" > configparms

    ../configure                             \
        --prefix=/usr                        \
        --host="${LFS_TGT}"                  \
        --build="$(../scripts/config.guess)" \
        --disable-nscd                       \
        libc_cv_slibdir=/usr/lib             \
        --enable-kernel=5.4

    MAKEFLAGS_SAVE="${MAKEFLAGS:-}"
    unset MAKEFLAGS
    make -j1

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    if [ -n "${MAKEFLAGS_SAVE:-}" ]; then
        export MAKEFLAGS="${MAKEFLAGS_SAVE}"
    else
        unset MAKEFLAGS || true
    fi

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    if [ -x "${LFS_ROOTFS}/usr/bin/ldd" ]; then
        sed '/RTLDLIST=/s@/usr@@g' -i "${LFS_ROOTFS}/usr/bin/ldd"
    fi

    echo "Glibc-2.42 instalada em ${LFS_ROOTFS} (cross, capítulo 5)."
