#!/usr/bin/env bash
#
# Script de construção do Bison-3.8.2 (capítulo 8, dentro do chroot).
#
# Pré-requisitos:
#   - Estar dentro do chroot LFS.
#   - Sources do LFS em /sources ou apontados via $LFS_SOURCES.
#
# Uso:
#   (chroot) root:/# cd /sources
#   (chroot) root:/sources# /project/lfs-scripts-chroot/bison-3.8.2.sh
#
# Para pular testes:
#   export LFS_SKIP_TESTS=1
#

set -euo pipefail

SRC_DIR="${LFS_SOURCES:-/sources}"

find_tarball() {
    local base="$1"
    local exts=(tar.xz tar.gz tar.bz2)
    local e
    for e in "${exts[@]}"; do
        if [ -f "${SRC_DIR}/${base}.${e}" ]; then
            echo "${SRC_DIR}/${base}.${e}"
            return 0
        fi
    done
    echo "Tarball não encontrado para base=${base} em ${SRC_DIR}" >&2
    return 1
}

main() {
    local tarball srcdir
    tarball="$(find_tarball bison-3.8.2)"

    echo "[Bison] Extraindo ${tarball}..."
    rm -rf bison-3.8.2
    tar -xf "${tarball}"
    srcdir="bison-3.8.2"
    cd "${srcdir}"

    ./configure --prefix=/usr \
                --docdir=/usr/share/doc/bison-3.8.2

    make

    if [ "${LFS_SKIP_TESTS:-0}" != "1" ]; then
        echo "[Bison] Executando 'make check'..."
        make check || echo "[AVISO] Testes do Bison retornaram erro; verifique os logs."
    else
        echo "[Bison] Testes pulados (LFS_SKIP_TESTS=1)."
    fi

    make install

    echo "[OK] Bison-3.8.2 instalado conforme o capítulo 8 (ajustado ao fluxo do projeto)."
}

main "$@"
