#!/usr/bin/env bash
#
# Script de construção do Gettext-0.26 (capítulo 8, dentro do chroot).
#
# Pré-requisitos:
#   - Estar dentro do chroot LFS.
#   - Sources do LFS em /sources ou apontados via $LFS_SOURCES.
#
# Uso:
#   (chroot) root:/# cd /sources
#   (chroot) root:/sources# /project/lfs-scripts-chroot/gettext-0.26.sh
#
# Para pular testes:
#   export LFS_SKIP_TESTS=1
#

set -euo pipefail

SRC_DIR="${LFS_SOURCES:-/sources}"

find_tarball() {
    local base="$1"
    local exts=(tar.xz tar.gz tar.bz2)
    local e
    for e in "${exts[@]}"; do
        if [ -f "${SRC_DIR}/${base}.${e}" ]; then
            echo "${SRC_DIR}/${base}.${e}"
            return 0
        fi
    done
    echo "Tarball não encontrado para base=${base} em ${SRC_DIR}" >&2
    return 1
}

main() {
    local tarball srcdir
    tarball="$(find_tarball gettext-0.26)"

    echo "[Gettext] Extraindo ${tarball}..."
    rm -rf gettext-0.26
    tar -xf "${tarball}"
    srcdir="gettext-0.26"
    cd "${srcdir}"

    ./configure --prefix=/usr \
                --disable-static \
                --docdir=/usr/share/doc/gettext-0.26

    make

    if [ "${LFS_SKIP_TESTS:-0}" != "1" ]; then
        echo "[Gettext] Executando 'make check' (pode demorar)..."
        make check || echo "[AVISO] Testes do Gettext retornaram erro; verifique os logs."
    else
        echo "[Gettext] Testes pulados (LFS_SKIP_TESTS=1)."
    fi

    make install

    # Ajuste típico do LFS para a lib preloadable, se existir
    if [ -f /usr/lib/preloadable_libintl.so ]; then
        chmod -v 0755 /usr/lib/preloadable_libintl.so
    fi

    echo "[OK] Gettext-0.26 instalado conforme o capítulo 8 (ajustado ao fluxo do projeto)."
}

main "$@"
