\
    #!/usr/bin/env bash
    #
    # Ncurses-6.5 (ferramenta temporária) - baseado em LFS 6.3

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="ncurses-6.5-temp"

    PKG_NAME="ncurses-6.5"
    PKG_TARBALL="${PKG_NAME}.tar.gz"
    NCURSES_URL_DEFAULT="https://ftp.gnu.org/gnu/ncurses/${PKG_TARBALL}"
    : "${NCURSES_SRC_URL:=${NCURSES_URL_DEFAULT}}"

    if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
        echo "Baixando ${PKG_TARBALL}..."
        curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${NCURSES_SRC_URL}"
    fi

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    mkdir -v build
    pushd build
      ../configure --prefix=/tools AWK=gawk
      make -C include
      make -C progs tic
      install -v -m755 progs/tic "${LFS_ROOTFS}/tools/bin/tic"
    popd

    ./configure --prefix=/usr                \
                --host="${LFS_TGT}"          \
                --build="$(./config.guess)"  \
                --mandir=/usr/share/man      \
                --with-manpage-format=normal \
                --with-shared                \
                --without-normal             \
                --with-cxx-shared            \
                --without-debug              \
                --without-ada                \
                --disable-stripping          \
                AWK=gawk

    make

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    ln -sv libncursesw.so "${LFS_DESTDIR}/usr/lib/libncurses.so"

    if [ -f "${LFS_DESTDIR}/usr/include/curses.h" ]; then
        sed -e 's/^#if.*XOPEN.*$/#if 1/' -i "${LFS_DESTDIR}/usr/include/curses.h"
    fi

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    echo "Ncurses-6.5 (temporário) instalado em ${LFS_ROOTFS}."
