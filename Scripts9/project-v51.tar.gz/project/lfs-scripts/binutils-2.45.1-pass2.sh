\
    #!/usr/bin/env bash
    #
    # Binutils-2.45.1 - Passagem 2 (ferramenta temporária final)
    #
    # LFS: capítulo 6 (Binutils Pass 2), adaptado para DESTDIR + ${LFS_ROOTFS}.

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="binutils-2.45.1-pass2"

    PKG_NAME="binutils-2.45.1"
    PKG_TARBALL="${PKG_NAME}.tar.xz"
    BINUTILS_URL_DEFAULT="https://ftp.gnu.org/gnu/binutils/${PKG_TARBALL}"
    : "${BINUTILS_SRC_URL:=${BINUTILS_URL_DEFAULT}}"

    if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
        echo "Baixando ${PKG_TARBALL}..."
        curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${BINUTILS_SRC_URL}"
    fi

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    mkdir -v build
    cd       build

    ../configure           \
        --prefix=/usr      \
        --build="$(../config.guess)" \
        --host="${LFS_TGT}" \
        --disable-nls      \
        --enable-default-hash-style=gnu \
        --enable-new-dtags

    make

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    # Ajuste de ld, como no LFS (capítulo 8 normalmente, aqui simplificado para sysroot)
    rm -f "${LFS_DESTDIR}/usr/lib/libbfd.la"  || true
    rm -f "${LFS_DESTDIR}/usr/lib/libctf.la"  || true

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    echo "Binutils-2.45.1 Pass 2 instalado em ${LFS_ROOTFS}."
