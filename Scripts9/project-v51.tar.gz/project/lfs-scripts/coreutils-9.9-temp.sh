\
    #!/usr/bin/env bash
    #
    # Coreutils-9.9 (ferramenta temporária) - LFS 6.5

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="coreutils-9.9-temp"

    PKG_NAME="coreutils-9.9"
    PKG_TARBALL="${PKG_NAME}.tar.xz"
    COREUTILS_URL_DEFAULT="https://ftp.gnu.org/gnu/coreutils/${PKG_TARBALL}"
    : "${COREUTILS_SRC_URL:=${COREUTILS_URL_DEFAULT}}"

    if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
        echo "Baixando ${PKG_TARBALL}..."
        curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${COREUTILS_SRC_URL}"
    fi

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    ./configure --prefix=/usr                      \
                --host="${LFS_TGT}"                \
                --build="$(build-aux/config.guess)" \
                --enable-install-program=hostname

    make

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    mv -v "${LFS_DESTDIR}/usr/bin/chroot"              "${LFS_DESTDIR}/usr/sbin"
    mkdir -pv "${LFS_DESTDIR}/usr/share/man/man8"
    mv -v "${LFS_DESTDIR}/usr/share/man/man1/chroot.1" "${LFS_DESTDIR}/usr/share/man/man8/chroot.8"
    sed -i 's/"1"/"8"/'                                "${LFS_DESTDIR}/usr/share/man/man8/chroot.8"

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    echo "Coreutils-9.9 (temporário) instalado em ${LFS_ROOTFS}."
