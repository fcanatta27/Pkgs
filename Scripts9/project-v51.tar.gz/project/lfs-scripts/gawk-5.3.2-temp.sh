\
    #!/usr/bin/env bash
    #
    # Gawk-5.3.2 (ferramenta temporária) - LFS 6.9

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="gawk-5.3.2-temp"

    PKG_NAME="gawk-5.3.2"
    PKG_TARBALL="${PKG_NAME}.tar.xz"
    GAWK_URL_DEFAULT="https://ftp.gnu.org/gnu/gawk/${PKG_TARBALL}"
    : "${GAWK_SRC_URL:=${GAWK_URL_DEFAULT}}"

    if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
        echo "Baixando ${PKG_TARBALL}..."
        curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${GAWK_SRC_URL}"
    fi

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    sed -i 's/extras//' Makefile.in

    ./configure --prefix=/usr \
                --host="${LFS_TGT}" \
                --build="$(build-aux/config.guess)"

    make

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    echo "Gawk-5.3.2 (temporário) instalado em ${LFS_ROOTFS}."
