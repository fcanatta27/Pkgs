#!/usr/bin/env bash
#
# Script de construção do Util-linux-2.41.3 (capítulo 8, dentro do chroot).
#
# Pré-requisitos:
#   - Estar dentro do chroot LFS.
#   - Sources em /sources ou apontados por $LFS_SOURCES.
#
# Uso:
#   (chroot) root:/# cd /sources
#   (chroot) root:/sources# /project/lfs-scripts-chroot/util-linux-2.41.3.sh
#
# Para pular testes:
#   export LFS_SKIP_TESTS=1
#
set -euo pipefail

SRC_DIR="${LFS_SOURCES:-/sources}"

find_tarball() {
    local base="$1"
    local exts=(tar.xz tar.gz tar.bz2)
    local e
    for e in "${exts[@]}"; do
        if [ -f "${SRC_DIR}/${base}.${e}" ]; then
            echo "${SRC_DIR}/${base}.${e}"
            return 0
        fi
    done
    echo "Tarball não encontrado para base=${base} em ${SRC_DIR}" >&2
    return 1
}

main() {
    local tarball srcdir
    tarball="$(find_tarball util-linux-2.41.3)"

    echo "[Util-linux] Extraindo ${tarball}..."
    rm -rf util-linux-2.41.3
    tar -xf "${tarball}"
    srcdir="util-linux-2.41.3"
    cd "${srcdir}"

    # Desabilitar ferramentas que conflitam com outros pacotes ou não são desejadas
    ./configure ADJTIME_PATH=/var/lib/hwclock/adjtime \
                --bindir=/usr/bin                     \
                --sbindir=/usr/sbin                   \
                --libdir=/usr/lib                     \
                --docdir=/usr/share/doc/util-linux-2.41.3 \
                --enable-chfn-chsh                    \
                --enable-login                        \
                --enable-nls                          \
                --enable-write                        \
                --disable-setpriv                     \
                --disable-runuser                     \
                --disable-makeinstall-chown           \
                --without-python                      \
                --without-systemd                     \
                --without-systemdsystemunitdir

    make

    if [ "${LFS_SKIP_TESTS:-0}" != "1" ]; then
        echo "[Util-linux] Os testes são sensíveis ao ambiente e geralmente executados manualmente."
        echo "[Util-linux] Consulte o livro LFS se quiser rodar 'make check'."
    else
        echo "[Util-linux] Testes pulados (LFS_SKIP_TESTS=1)."
    fi

    make install

    echo "[OK] Util-linux-2.41.3 instalado conforme o capítulo 8 (ajustado ao fluxo do projeto)."
}

main "$@"
