#!/usr/bin/env bash
#
# Script de construção do Texinfo-7.2 (capítulo 8, dentro do chroot).
#
# Pré-requisitos:
#   - Estar dentro do chroot LFS.
#   - Sources em /sources ou apontados por $LFS_SOURCES.
#
# Uso:
#   (chroot) root:/# cd /sources
#   (chroot) root:/sources# /project/lfs-scripts-chroot/texinfo-7.2.sh
#
# Para pular testes:
#   export LFS_SKIP_TESTS=1
#
set -euo pipefail

SRC_DIR="${LFS_SOURCES:-/sources}"

find_tarball() {
    local base="$1"
    local exts=(tar.xz tar.gz tar.bz2)
    local e
    for e in "${exts[@]}"; do
        if [ -f "${SRC_DIR}/${base}.${e}" ]; then
            echo "${SRC_DIR}/${base}.${e}"
            return 0
        fi
    done
    echo "Tarball não encontrado para base=${base} em ${SRC_DIR}" >&2
    return 1
}

main() {
    local tarball srcdir
    tarball="$(find_tarball texinfo-7.2)"

    echo "[Texinfo] Extraindo ${tarball}..."
    rm -rf texinfo-7.2
    tar -xf "${tarball}"
    srcdir="texinfo-7.2"
    cd "${srcdir}"

    ./configure --prefix=/usr

    make

    if [ "${LFS_SKIP_TESTS:-0}" != "1" ]; then
        echo "[Texinfo] Executando 'make check'..."
        make check || echo "[AVISO] Testes do Texinfo retornaram erro; verifique logs."
    else
        echo "[Texinfo] Testes pulados (LFS_SKIP_TESTS=1)."
    fi

    make install

    echo "[OK] Texinfo-7.2 instalado conforme o capítulo 8 (ajustado ao fluxo do projeto)."
}

main "$@"
