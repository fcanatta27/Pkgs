#!/usr/bin/env bash
#
# Script de construção do Python-3.14.2 (capítulo 8, dentro do chroot).
#
# Pré-requisitos:
#   - Estar dentro do chroot LFS.
#   - Sources em /sources ou apontados por $LFS_SOURCES.
#
# Uso:
#   (chroot) root:/# cd /sources
#   (chroot) root:/sources# /project/lfs-scripts-chroot/Python-3.14.2.sh
#
# Para pular testes:
#   export LFS_SKIP_TESTS=1
#
set -euo pipefail

SRC_DIR="${LFS_SOURCES:-/sources}"

find_tarball() {
    local base="$1"
    local exts=(tar.xz tar.gz tar.bz2)
    local e
    for e in "${exts[@]}"; do
        if [ -f "${SRC_DIR}/${base}.${e}" ]; then
            echo "${SRC_DIR}/${base}.${e}"
            return 0
        fi
    done
    echo "Tarball não encontrado para base=${base} em ${SRC_DIR}" >&2
    return 1
}

main() {
    local tarball srcdir builddir
    tarball="$(find_tarball python-3.14.2)"

    echo "[Python] Extraindo ${tarball}..."
    rm -rf python-3.14.2
    tar -xf "${tarball}"
    srcdir="python-3.14.2"
    cd "${srcdir}"

    # Ajuste recomendados pelo LFS para garantir reprodutibilidade/env
    ./configure --prefix=/usr           \
                --enable-shared         \
                --with-system-expat     \
                --with-system-ffi       \
                --enable-optimizations  \
                --with-ensurepip=yes

    make

    if [ "${LFS_SKIP_TESTS:-0}" != "1" ]; then
        echo "[Python] Executando teste de sanidade (make test) - pode demorar."
        # O livro recomenda rodar como usuário não-root; aqui apenas deixamos opcional.
        make test || echo "[AVISO] Testes do Python retornaram erro; verifique logs."
    else
        echo "[Python] Testes pulados (LFS_SKIP_TESTS=1)."
    fi

    make install

    # Instala documentação HTML se disponível
    local doc_tar="${SRC_DIR}/python-3.14.2-docs-html.tar.bz2"
    if [ -f "${doc_tar}" ]; then
        echo "[Python] Instalando documentação HTML..."
        install -v -dm755 /usr/share/doc/python-3.14.2/html
        tar --strip-components=1  \
            --no-same-owner       \
            --no-same-permissions \
            -C /usr/share/doc/python-3.14.2/html \
            -xvf "${doc_tar}"
    fi

    echo "[OK] Python-3.14.2 instalado conforme o capítulo 8 (ajustado ao fluxo do projeto)."
}

main "$@"
