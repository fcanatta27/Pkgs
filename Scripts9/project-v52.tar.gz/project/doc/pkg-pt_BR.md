# Tutorial do gerenciador `pkg`

Este documento explica, em detalhes, como funciona o gerenciador de pacotes
`pkg`, como escrever `Buildfile`s, como administrar pacotes de forma
inteligente (incluindo dependências, ciclo de dependências, uninstall seguro)
e todo o fluxo de trabalho típico.

---

## 1. Conceito geral

O `pkg` foi pensado como um gerenciador simples e **transparente**:

- Os pacotes são definidos por um arquivo `Buildfile`.
- Cada pacote fica em um diretório:

  ```text
  /var/packages/<categoria>/<programa>/
      Buildfile
      .md5sum
      outros-arquivos-locais…
  ```

- O `Buildfile` define:
  - `name`, `version`, `release`
  - `source` (arquivos remotos e locais)
  - a função `build()` que efetivamente compila e instala o pacote
    em um diretório temporário `$PKG`.

O `pkg` cuida de:

- baixar fontes (`source`),
- gerar/verificar checksums `.md5sum`,
- montar diretório de build (`$SRC`) e destino (`$PKG`),
- rodar `build()`,
- aplicar `strip` opcional em binários/libraries,
- gerar o pacote final `.tar.xz`,
- instalar o pacote no sistema,
- registrar dependências e arquivos instalados,
- resolver dependências com detecção de ciclo,
- impedir uninstall se outros pacotes dependem do alvo.

---

## 2. Layout de diretórios

Por padrão, o `pkg` usa:

```text
PKG_ROOT       = /var/packages
PKG_BUILD_ROOT = /var/cache/pkg/build
PKG_SRC_CACHE  = /var/cache/pkg/sources   # reservado para evoluções futuras
PKG_STATE_DIR  = /var/lib/pkg
```

Isso resulta em:

```text
/var/packages/<categoria>/<programa>/
    Buildfile
    .md5sum
    (arquivos locais declarados em 'source')

/var/cache/pkg/build/<name>-<version>/
    src/   -> $SRC (onde os sources são colocados)
    pkg/   -> $PKG (instalação "fake root")

/var/lib/pkg/installed/
    <name>-<version>-<release>.files  -> lista de arquivos instalados
    <name>-<version>-<release>.deps   -> dependências diretas do pacote
```

Você pode sobrescrever esses diretórios exportando variáveis de ambiente
antes de chamar o `pkg`, por exemplo:

```bash
export PKG_ROOT=/mnt/lfs/var/packages
export PKG_BUILD_ROOT=/mnt/lfs/var/cache/pkg/build
```

---

## 3. Anatomia de um `Buildfile`

Um exemplo real com fonte remota, arquivo local e dependência:

```bash
# Description: Ferramenta de exemplo que usa libpng e zlib
# URL: https://exemplo.org
# Depends on: zlib libpng

name=exemplo
version=1.0.0
release=1

source=(
  $name-$version.tar.xz::https://exemplo.com.br/$name/$name-$version.tar.xz
  config-customizada
)

build() {
    cd $name-$version

    ./configure \
        --prefix=/usr

    make
    make DESTDIR=$PKG install

    # Arquivo local adicional (do lado do Buildfile, listado em 'source')
    install -D -m 0644 "$SRC/config-customizada" \
        "$PKG/etc/exemplo/config-customizada"
}
```

Pontos importantes:

- `# Depends on:`  
  O `pkg` lê essa linha para resolver dependências. Nesse exemplo,
  o pacote depende de `zlib` e `libpng`.

- `source=()`  
  Lista de items:
  - `nome_local::URL` → baixa da URL e salva como `nome_local`.
  - `URL` pura → baixa e usa o basename como nome do arquivo.
  - `arquivo_local` → arquivo existente no mesmo diretório do `Buildfile`.

- `$SRC`  
  Diretório onde o `pkg` copia **todos** os items de `source`.
  Dentro do `build()`, você sempre acessa os arquivos a partir do `$SRC`.

- `$PKG`  
  Diretório de "root falso" onde o pacote é instalado.  
  Tudo que cair em `$PKG` será empacotado no `.tar.xz` final.

---

## 4. Geração e verificação de checksums (`pkg -g`)

Dentro do diretório do pacote:

```bash
cd /var/packages/libs/exemplo
pkg -g
```

Fluxo:

1. Lê o `Buildfile` para obter a variável `source`.
2. Baixa arquivos remotos se ainda não existirem.
3. Verifica se todos os arquivos locais listados em `source` existem.
4. Gera `.md5sum` com uma linha por arquivo:

   ```text
   <hash>  <arquivo>
   ```

Sempre que você editar algum arquivo local presente em `source` ou
o tarball remoto mudar, é preciso regenerar:

```bash
pkg -g
# ou durante o build, com update forçado:
pkg -uf exemplo
```

Durante o build, o `pkg`:

- lê `.md5sum`,
- recalcula o md5 de cada arquivo,
- se qualquer valor não bater, aborta com erro de mismatch.

---

## 5. Comandos principais e fluxos

### 5.1. `pkg -b` (build sem instalar)

Há dois modos:

1. **Dentro do diretório do pacote**:

   ```bash
   cd /var/packages/libs/exemplo
   pkg -b
   ```

   - Usa o `Buildfile` do diretório atual.
   - Faz verificação de `.md5sum`.
   - Monta `$SRC` e `$PKG`, roda `build()`.
   - Aplica `strip` otimizado (a menos que use `--no-strip`).
   - Gera `exemplo-1.0.0-1.tar.xz` no próprio diretório.

2. **De qualquer lugar, apontando o nome**:

   ```bash
   pkg -b exemplo
   ```

   - Localiza `/var/packages/*/exemplo/Buildfile`.
   - Faz o mesmo processo acima.
   - Se você adicionar `-d` e/ou `-i`, ele usa a lógica de dependências (ver abaixo).

### 5.2. `pkg -b` com dependências e instalação

Quando você está **no diretório do pacote**:

```bash
cd /var/packages/libs/exemplo

# Construir o pacote + dependências, sem instalar
pkg -b -d

# Construir o pacote + dependências, e instalar na sequência
pkg -b -d -i
```

- `-d` ativa resolução de dependências:
  - Lê `# Depends on:` do próprio `Buildfile`.
  - Resolve transitoriamente (zlib, libpng, e dependências deles, etc.).
  - Detecta ciclos (detalhes na seção 7).
  - Gera uma ordem topológica: primeiro dependências, por último `exemplo`.

- `-i` quando usado junto com `-b` significa:
  - **instalar** os pacotes após o build.
  - Dependências só são instaladas se ainda não estiverem instaladas.
  - O pacote alvo pode ser reinstalado (útil para rebuild).

Todos os pacotes construídos têm tarball `.tar.xz` gerado e, quando instalados,
têm seus arquivos listados em:

```text
/var/lib/pkg/installed/<name>-<version>-<release>.files
```

e dependências diretas em:

```text
/var/lib/pkg/installed/<name>-<version>-<release>.deps
```

### 5.3. `pkg --no-strip`

Por padrão, o `pkg` faz um strip otimizado nos executáveis/bibliotecas ELF
dentro de `$PKG`:

- Localiza arquivos executáveis e `.so*`.
- Usa `file` para checar se o arquivo é ELF.
- Aplica `strip --strip-unneeded` ignorando erros.

Isso reduz o tamanho dos pacotes sem (em geral) quebrar os binários.

Se você quiser **desabilitar** o strip:

```bash
pkg --no-strip -b
pkg --no-strip -b exemplo
pkg --no-strip -b -d -i
```

---

## 6. Instalação e atualização (`pkg -i`, `pkg -u`, `pkg -uf`)

### 6.1. `pkg -i nome` – build + install com dependências

```bash
pkg -i exemplo
```

Fluxo, em alto nível:

1. Resolve dependências com detecção de ciclo.
2. Para cada pacote na ordem:

   - Se está instalado e não for o alvo principal, é pulado.
   - Chama `do_build_in_dir`, que:
     - verifica `.md5sum`,
     - monta `$SRC` e `$PKG`,
     - executa `build()`,
     - aplica strip (a menos que `--no-strip`),
     - gera `<nome>-<versão>-<release>.tar.xz` no diretório do pacote.
   - Calcula `pkg_id` (`nome-versao-release`).
   - Lê `# Depends on:` e grava `<pkg_id>.deps`.
   - Instala o tarball na raiz (`/`) e grava `<pkg_id>.files`.

3. Ao final, `exemplo` está instalado com seu banco de dados atualizado.

### 6.2. `pkg -i -d /caminho/do/diretorio`

Este modo é usado **dentro do diretório do pacote** quando você já tem
o binário pronto em outro lugar (por exemplo, um repositório de pacotes):

```bash
cd /var/packages/libs/exemplo
pkg -i -d /mnt/repo-bin
```

Fluxo:

1. Lê o `Buildfile` atual para obter `name`, `version` e `release`.
2. Procura pelo arquivo:

   ```text
   /mnt/repo-bin/exemplo-1.0.0-1.tar.xz
   ```

3. Lê `# Depends on:` e grava `exemplo-1.0.0-1.deps`.
4. Instala esse tarball no sistema e grava `exemplo-1.0.0-1.files`.

Esse fluxo é ideal para:

- instalar a partir de um repositório offline,
- testar instalação de um pacote gerado em outra máquina.

### 6.3. `pkg -u nome` e `pkg -uf nome`

- `pkg -u nome`:

  ```bash
  pkg -u exemplo
  ```

  - Rebuilda **sempre** o pacote alvo `exemplo`.
  - Dependências só são rebuildadas se não estiverem instaladas.
  - Reinstala `exemplo` por cima.

- `pkg -uf nome`:

  ```bash
  pkg -uf exemplo
  ```

  - Antes do build, força regeneração de `.md5sum` (equivalente a `pkg -g`).
  - Depois realiza o fluxo de `-u`.

---

## 7. Resolução de dependências e detecção de ciclos

### 7.1. Como são lidas as dependências

Em cada `Buildfile`, a linha:

```bash
# Depends on: zlib libpng
```

é interpretada como:

- `zlib` e `libpng` são **nomes de pacotes** que o `pkg` pode procurar
  em `/var/packages/*/<nome>/Buildfile`.

Os nomes listados compõem a dependência **direta**. Dependências indiretas
(da dependência da dependência) são resolvidas automaticamente.

### 7.2. Exemplo de ciclo de dependência

Suponha:

- `A/Buildfile`:

  ```bash
  # Depends on: B
  ```

- `B/Buildfile`:

  ```bash
  # Depends on: C
  ```

- `C/Buildfile`:

  ```bash
  # Depends on: A
  ```

Quando você rodar:

```bash
pkg -i A
```

O `pkg` irá:

- começar em `A`, visitar `B`, depois `C`;
- ao tentar visitar novamente `A` (que já está na “pilha” de resolução),
  detectará o ciclo e abortará com uma mensagem do tipo:

```text
[ERR]  Ciclo de dependências detectado envolvendo o pacote 'A'.
[ERR]  Cadeia atual: A B C -> A
```

Isso evita loops infinitos e builds inconsistentes.

---

## 8. Uninstall seguro com checagem de dependentes

Quando você instala um pacote, o `pkg` grava:

- `nome-versao-release.deps`: dependências diretas
- `nome-versao-release.files`: arquivos instalados

Então, ao remover:

```bash
pkg -r exemplo
```

O `pkg`:

1. Localiza `exemplo-*.files`.
2. Procura em todos os arquivos `.deps` quais pacotes dependem de `exemplo`.
3. Se encontrar dependentes, aborta com mensagem:

   ```text
   [ERR]  Não é seguro remover 'exemplo': outros pacotes dependem dele:
     - outro-pacote-1.2.3-1
     - mais-um-2.0.0-1
   [ERR]  Remova primeiro os dependentes acima ou use uma estratégia de remoção forçada (não implementada).
   ```

4. Só prossegue com a remoção se **não houver dependentes**.

Ao remover, ele:

- tenta apagar todos os caminhos listados em `.files`;
- remove também o `.deps` do pacote;
- tenta remover diretórios vazios relacionados, sem forçar nada agressivo.

---

## 9. Exemplo completo de fluxo com dependências

### 9.1. Pacotes: `zlib`, `libpng`, `exemplo`

- `zlib/Buildfile` (simplificado):

  ```bash
  # Description: Biblioteca de compressão
  # Depends on:

  name=zlib
  version=1.3.1
  release=1
  source=(zlib-$version.tar.xz::https://zlib.net/zlib-$version.tar.xz)

  build() {
      cd zlib-$version
      ./configure --prefix=/usr
      make
      make DESTDIR=$PKG install
  }
  ```

- `libpng/Buildfile`:

  ```bash
  # Description: Biblioteca PNG
  # Depends on: zlib

  name=libpng
  version=1.6.44
  release=1
  source=(libpng-$version.tar.xz::https://download.sourceforge.net/libpng/libpng-$version.tar.xz)

  build() {
      cd libpng-$version
      ./configure --prefix=/usr
      make
      make DESTDIR=$PKG install
  }
  ```

- `exemplo/Buildfile` (já mostrado antes):

  ```bash
  # Depends on: zlib libpng
  ...
  ```

### 9.2. Construindo tudo sem instalar (binários apenas)

```bash
pkg -b exemplo
```

Resultado:

- Binários gerados:
  - `zlib-1.3.1-1.tar.xz`
  - `libpng-1.6.44-1.tar.xz`
  - `exemplo-1.0.0-1.tar.xz`

(na ordem correta, em seus respectivos diretórios).

### 9.3. Construindo + instalando tudo a partir do diretório de `exemplo`

```bash
cd /var/packages/libs/exemplo
pkg -b -d -i
```

- Resolve dependências (`zlib`, `libpng`).
- Gera todos os tarballs.
- Instala `zlib` e `libpng` se ainda não instalados.
- Instala `exemplo`.
- Atualiza os arquivos `.files` e `.deps` em `/var/lib/pkg/installed`.

---

## 10. Dicas finais de administração

- Sempre mantenha seus `Buildfile`s versionados (git ou similar).
- Use `pkg -g` sempre que mexer em arquivos locais de `source`.
- Use `pkg --no-strip` se estiver depurando problemas de binário.
- Use `pkg -b nome` para gerar apenas os pacotes binários para depois
  montar um repositório offline.
- Use `pkg -i -d /repo` dentro do diretório do pacote para testar instalação
  a partir de um repositório pronto.

Com isso, você tem um fluxo completo de:

1. Definição de pacote (`Buildfile`).
2. Verificação de integridade (`.md5sum`).
3. Build controlado com strip opcional.
4. Resolução de dependências com detecção de ciclo.
5. Instalação e atualização com registro detalhado.
6. Uninstall seguro com checagem de dependentes.

