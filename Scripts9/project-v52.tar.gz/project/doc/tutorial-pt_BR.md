# 3bLinux / LFS – Guia Completo do Projeto

Este documento explica em detalhes **todo o fluxo** do projeto: preparação do host,
uso dos wrappers de build, `pkg`, scripts de chroot, sanity-checks, kernel/initramfs,
ISO, instalador, modo live e rootfs.

> AVISO: este projeto é avançado. Leia com calma, entenda cada etapa e sempre
> tenha backup dos seus dados antes de rodar qualquer script que mexa em disco.

---

## 1. Visão geral do projeto

O projeto implementa:

- Um fluxo automatizado de construção do **Linux From Scratch (LFS)**.
- Uma distro mínima própria chamada **3bLinux**, baseada no LFS.
- Uma cadeia de ferramentas:

  - `lfs-build`, `lfs-full-build`, scripts de capítulos 5/6/7/8.
  - `pkg` (gerenciamento de pacotes com Buildfile e dependências).
  - Scripts de sanity-check (toolchain e pós-capítulo 8).
  - Scripts de chroot.
  - Kernel + initramfs automáticos.
  - Gerador de ISO: `3blinux-make-iso`.
  - Instalador interativo: `3blinux-installer`.
  - Gerador de rootfs limpo: `3blinux-make-rootfs`.
  - Ferramentas auxiliares: `lfs-gen-fstab`, `3blinux-live-menu`.

Estrutura relevante:

```text
project/
  rootfs/              -> raiz do sistema 3bLinux (instalado)
    var/packages/lfs/  -> Buildfiles do pkg
    usr/local/sbin/    -> scripts principais (lfs-build-kernel, etc.)
  etc/                 -> configs "modelo" para o sistema final
  tools/               -> scripts para ISO, instalador, rootfs
  doc/
    tutorial-pt_BR.md  -> este guia
```

---

## 2. Preparação do host

### 2.1 Requisitos básicos

No host onde você vai rodar o build do LFS:

- Kernel Linux relativamente recente (>= 6.x recomendado).
- Ferramentas de desenvolvimento:
  - `gcc`, `g++`, `make`, `binutils`, `bash`, `coreutils`, `tar`, `xz`, `gzip`, `bzip2`, `sed`, `grep`, `awk`, `patch`, etc.
- Ferramentas extras:
  - `curl`, `git`, `rsync`, `parted`, `e2fsprogs`, `grub2`, `xorriso` e/ou `grub-mkrescue`.

Crie um usuário dedicado `lfs` (no host):

```bash
groupadd lfs
useradd -s /bin/bash -g lfs -m -k /dev/null lfs
passwd lfs
```

Dê ao usuário `lfs` apenas as permissões necessárias para build em `/tmp` e acesso ao diretório do projeto.

---

## 3. Layout do projeto e variáveis principais

### 3.1 Diretório `project/`

- `project/rootfs` – será a raiz do sistema 3bLinux.
- `project/etc` – templates de configuração para o sistema final.
- `project/tools` – scripts de alto nível (ISO, instalador, rootfs).
- `project/rootfs/var/packages/lfs` – coleção de pacotes gerenciados pelo `pkg`.

O projeto foi desenhado para trabalhar com:

- `LFS_ROOTFS` apontando para `project/rootfs`.
- Build temporário em `/tmp` (directório de trabalho e `destdir`).

---

## 4. Ferramentas de build inicial (toolchain, temporários)

### 4.1 Wrappers de build (`lfs-build`, `lfs-full-build`)

Os wrappers (instalados em `/bin` dentro do rootfs) controlam:

- Download de fontes com `curl` (HTTP/HTTPS/Git, com retomada).
- Execução de scripts de construção na ordem do livro LFS.
- Registro de logs separados por pacote e por fase.
- Recomeço após falha (não recompila o que já está marcado como OK, a menos que você limpe).

Uso típico (no host, como usuário `lfs`):

```bash
export LFS_ROOTFS=/caminho/para/project/rootfs
lfs-full-build
```

O `lfs-full-build` conduz:

1. Toolchain temporário (cap. 5/6).
2. Toolchain final (cap. 7/8, guiado por scripts em `lfs-scripts` e `lfs-scripts-chroot`).
3. Invoca sanity-checks em pontos críticos.

### 4.2 Sanity-check inicial (toolchain)

Script típico (nome pode ser `lfs-sanity-check` ou similar):

- Garante que:
  - `cc` aponta para `gcc`.
  - Diretórios de ferramentas temporárias (`/tools`, `/tmp/rootfs/tools`) estão no lugar certo.
  - Bibliotecas e headers das etapas pass1/pass2 estão consistentes.

Problemas comuns:

- Versão errada de `binutils`/`gcc` do host interferindo.
- `PATH` não isolado (incluindo diretórios do host indevidamente).

Solução:

- Verificar se o wrapper exporta corretamente `PATH` com prioridade para toolchain LFS.
- Rodar novamente o script de construção do pacote que falhou, após limpar o diretório de build específico (ou usar a opção de limpeza do wrapper).

---

## 5. `pkg` – sistema de pacotes

### 5.1 Conceito de `Buildfile`

Cada pacote é definido em:

```text
/var/packages/lfs/<nome>/Buildfile
```

Exemplo simplificado:

```sh
# Description: Exemplo
# URL: https://exemplo.org
# Depends on: zlib

name=exemplo
version=1.0.0
release=1

source=(
  exemplo-$version.tar.xz::https://exemplo.org/src/exemplo-$version.tar.xz
)

build() {
    set -e
    : "${SRC:?}"
    : "${PKG:?}"

    cd "$SRC"
    tar -xf "exemplo-$version.tar.xz"
    cd "exemplo-$version"

    ./configure --prefix=/usr
    make
    make DESTDIR="$PKG" install
}
```

### 5.2 Variáveis e fluxo interno

- `source=(...)`
  - URLs ou arquivos locais.
  - `nome::url` renomeia o tarball baixado.
- `$SRC`
  - Diretório de trabalho do pacote.
- `$PKG`
  - Diretório temporário que simula a raiz (`/`) para empacotamento.
- `.md5sum`
  - Gerado por `pkg -g`, guarda os hashes dos itens de `source`.

### 5.3 Comandos principais do `pkg`

- `pkg -g` – baixa fontes (se necessário) e gera `.md5sum`.
- `pkg -b <pacote>` – resolve dependências, verifica `.md5sum`, constrói, instala em `$PKG`, faz strip e gera o tarball binário.
- `pkg -b -d -i` (dentro do diretório do pacote)
  - Constrói e instala na sequência, útil durante desenvolvimento do Buildfile.
- `pkg -i <pacote>`
  - Instala a partir do cache binário.
- `pkg -i -d /caminho/dir`
  - Instala a partir de um diretório alternativo contendo pacotes binários.
- Uninstall
  - Usa o registro interno de arquivos instalados para remover pacotes.
  - Bloqueia remoção se houver dependentes (detecção de dependências/ciclos).

### 5.4 Possíveis problemas e debug

- **Erro de checksum**:
  - Rodar `pkg -g` para regenerar `.md5sum`.
  - Em seguida `pkg -b` novamente.
- **Ciclo de dependências**:
  - O `pkg` detecta e aborta.
  - Resolver simplificando ou quebrando o ciclo (rever `# Depends on:` dos Buildfiles).
- **Build falhando**:
  - Ver logs criados por fase (o wrapper de build separa logs por pacote/fase).
  - Ajustar o `build()` do `Buildfile` e tentar `pkg -b -d` dentro do diretório.

---

## 6. Scripts de chroot e etapas do capítulo 7/8

### 6.1 Chroot

Há um script de chroot que:

- Monta `/proc`, `/sys`, `/dev`, `/run` adequadamente.
- Entra no chroot de forma idempotente.

Problemas comuns:

- Montagens antigas presas → scripts de unmount/troubleshooting podem ser necessários.
- `chroot` falhando por falta de `/bin/bash` dentro de `rootfs`.

### 6.2 `lfs-chroot-build` e scripts de capítulo 8

Dentro do chroot:

- Existem scripts em `lfs-scripts-chroot` para cada grupo de pacotes (Gettext, Bison, Perl, Python, Util-linux etc.).
- `lfs-chroot-build` (ou wrapper equivalente) executa na ordem correta.

Sanity-check pós capítulo 8:

- Script dedicado que:
  - Verifica binários principais (`bash`, `coreutils`, `gcc`, `ld`, `systemd-free stack`).
  - Garante que não há dependência não desejada do `/tools`/host.
  - Se tudo OK, o tutorial considera que você está pronto para seguir para kernel, bootscripts e finalização.

---

## 7. Kernel, initramfs e fstab

### 7.1 `lfs-build-kernel`

Local:

```text
/usr/local/sbin/lfs-build-kernel
```

Função:

- Compila o kernel a partir de `/usr/src/linux`.
- Instala módulos.
- Copia:
  - `/boot/vmlinuz-<versão>`
  - `/boot/System.map-<versão>`
  - `/boot/config-<versão>`
- Gera `initramfs-<versão>.img` com suporte a:

  - Modo **normal** (`root=` ou `/dev/sda2`).
  - Modo **live** (`3blinux=live` + `iso_label=3BLINUX`).
  - Modo **installer** (`3blinux=installer` + `iso_label=3BLINUX`).

Debug:

- Se o boot cair em shell do initramfs:
  - Verificar se o `blkid` está presente.
  - Conferir se o label da ISO é realmente `3BLINUX`.
  - Checar linha de comando do kernel em `/proc/cmdline`.

### 7.2 `lfs-gen-fstab`

Local:

```text
/usr/local/sbin/lfs-gen-fstab
```

Gera:

- `/etc/fstab` usando:
  - `UUID` do root.
  - Entradas para swap, `proc`, `sysfs`, `devpts`, `tmpfs`, `devtmpfs`.

Se falhar:

- Verificar se `blkid` está instalado.
- Preencher `/etc/fstab` manualmente.

---

## 8. ISO, Live Mode e Installer

### 8.1 `3blinux-make-iso`

Local:

```text
project/tools/3blinux-make-iso
```

Uso típico:

```bash
ROOT_DIR=/mnt/3blinux-root ISO_NAME=3blinux-1.0-minimal.iso tools/3blinux-make-iso
```

- Copia o sistema de `ROOT_DIR` para um `WORK_DIR` temporário.
- Gera `boot/grub/grub.cfg` com duas entradas:
  - **3bLinux Live** → `3blinux=live`
  - **3bLinux Installer** → `3blinux=installer`
- Tenta usar `grub-mkrescue` para criar a ISO.

Problemas comuns:

- `grub-mkrescue` não instalado → instalar os pacotes `grub2` e `xorriso`.
- Kernel/initramfs inexistentes em `/boot` → rodar `lfs-build-kernel` primeiro.

### 8.2 Modo Live – `3blinux-live-menu`

Dentro do sistema live (carregado da ISO):

```text
/usr/local/sbin/3blinux-live-menu
```

O initramfs, em modo `3blinux=live`, após montar a ISO, faz:

```sh
switch_root /run/iso /usr/local/sbin/3blinux-live-menu
```

O script:

- Tenta usar `dialog` ou `whiptail` para mostrar um menu TUI.
- Se não encontrar, usa um menu de texto simples no terminal.
- Opções do menu:
  1. Iniciar instalador (`3blinux-installer`).
  2. Abrir shell root.
  3. Continuar boot normal com `/sbin/init`.
  4. Reiniciar.
  5. Desligar.

Problemas / debug:

- Falta de `dialog`/`whiptail`:
  - O script cai automaticamente no menu simples (texto).
- Se `3blinux-installer` não estiver em `/usr/local/sbin`:
  - Verifique se o rootfs usado para gerar a ISO estava completo.

### 8.3 `3blinux-installer`

Local:

```text
project/tools/3blinux-installer
(embutido também em /usr/local/sbin dentro do rootfs)
```

Fluxo:

1. Lista discos com `lsblk`.
2. Pergunta o disco alvo (`/dev/sdX`).
3. Confirmação com `SIM`.
4. Particionamento automatizado opcional (GPT + EFI + root).
5. `mkfs.ext4` e `mkfs.vfat` (se você confirmar).
6. Monta root em `DEST_ROOT` (default `/mnt/3blinux-target`).
7. Copia o sistema via `rsync`.
8. Configura:
   - `hostname`.
   - layout de teclado (`/etc/sysconfig/console`).
   - locale (`/etc/locale.conf`).
   - usuário principal (grupo `wheel` etc).
   - senhas de usuário e root.
   - sudo para `%wheel`.
9. Gera `fstab` via `lfs-gen-fstab`.
10. Instala GRUB2:
   - UEFI: `grub-install --target=x86_64-efi`.
   - BIOS: `grub-install --target=i386-pc`.
11. Configura `grub.cfg` com `root=UUID=...`.

Debug:

- Se a instalação falhar no particionamento:
  - Particione manualmente com `parted`/`fdisk` e retome o instalador escolhendo “não” para o auto-particionamento.
- Se o GRUB não bootar:
  - Verificar `root=` e o UUID em `grub.cfg`.
  - Conferir se kernel/initramfs realmente existem em `/boot`.

### 8.4 `3blinux-make-rootfs`

Local:

```text
project/tools/3blinux-make-rootfs
```

Uso:

```bash
ROOT_DIR=/mnt/3blinux-root OUT=3blinux-rootfs.tar.xz tools/3blinux-make-rootfs
```

- Gera um tarball `.tar.xz` contendo apenas o rootfs, sem:
  - `dev`, `proc`, `sys`, `run`, `tmp`, `lost+found`.
  - scripts de instalador/ISO.
- Útil para:
  - Chroot manual.
  - Contêiner.
  - Base para imagem customizada.

---

## 9. Configurações em `/etc` e `.skel`

### 9.1 Perfil da distro

Arquivos:

```text
/etc/os-release
/etc/3blinux-release
/etc/issue
```

Identificam o sistema como **3bLinux 1.0 (development)**.

### 9.2 SysVinit e bootscripts

- `/etc/inittab` – runlevel padrão 3, integração com bootscripts LFS.
- `/etc/sysconfig/rc.site` – controla verbosidade, cores etc.
- `/etc/sysconfig/console` – keymap/font do console.
- `/etc/sysconfig/clock` – `UTC` e `ZONE`.

### 9.3 Rede

- `/etc/sysconfig/ifconfig.eth0` – por padrão DHCP em `eth0`.
- `/etc/sysconfig/network` – `HOSTNAME="3blinux"` e opcional `GATEWAY`.
- `/etc/hosts` e `/etc/resolv.conf` – templates básicos.

### 9.4 Fonts e aparência

- `/etc/fonts/local.conf` – prioriza:
  - Noto.
  - DejaVu.
  - Bitstream Vera.
  - Font Awesome.
  - Terminus (para monospace).

### 9.5 `.skel` (para novos usuários)

- `/etc/skel/.bashrc` – prompt colorido, bash-completion, less/man coloridos.
- `/etc/skel/.vimrc` – Vim com:
  - numeração relativa.
  - indentação inteligente.
  - netrw como explorer.
  - mappings úteis de janelas.

---

## 10. Dicas de debug e problemas típicos

### 10.1 Builds falhando no meio

- Sempre verifique:
  - Logs separados por fase (wrapper de build e/ou `pkg`).
  - Versão do pacote LFS (link do `source` no Buildfile).
- Use `PKG_SKIP_TESTS=1 pkt -b <pacote>` quando a suíte de testes for frágil, mas apenas se tiver confiança.

### 10.2 Toolchain “contaminado”

Indícios:

- `which gcc` aponta para gcc do host.
- `ldd` de binários dentro do chroot mostrando libs do host.

Ação:

- Verifique `PATH` e configure wrappers de build para priorizar `/tools` e/ou `LFS_ROOTFS`.
- Recompile as partes críticas do toolchain.

### 10.3 Boot via ISO falhando

- Checar:
  - Se o label da ISO é `3BLINUX`.
  - Se o kernel foi compilado com drivers necessários (controlador de disco/USB/CD).
  - Saída do initramfs (mensagens “Initramfs: ...”).

### 10.4 Instalador parando no meio

- Verifique o log:
  - `/var/log/3blinux-installer.log`.
- Se `rsync` falhar:
  - Problema de permissões ou partição montada como read-only.
- Se `grub-install` falhar:
  - Conferir se o destino (`/dev/sdX` ou `/boot/efi`) está correto.

---

## 11. Resumo

Se você:

1. Preparou o host com as ferramentas corretas.
2. Rodou o fluxo de build (toolchain → sistema base).
3. Passou pelos sanity-checks.
4. Gerou kernel + initramfs com `lfs-build-kernel`.
5. Usou `3blinux-make-iso` para gerar uma ISO.
6. Bootou em `3bLinux Live` e executou o instalador (via TUI ou diretamente).
7. Verificou `/etc/fstab`, `/etc/sysconfig/*` e `/boot/grub/grub.cfg`.

Então você terá:

- Um sistema **3bLinux** funcional, bootável, com pacotes gerenciados por `pkg`, pronto para ser seu laboratório de LFS e base para uma distro própria.



## 12. Orquestrador de build completo

Use `tools/3blinux-orchestrator` no host para executar todo o fluxo automaticamente:
build → kernel/initramfs → rootfs → ISO → teste.

---

## 12. Orquestrador: 3blinux-orchestrator

Para facilitar ainda mais, o projeto fornece um **orquestrador** que encadeia
todas as etapas principais:

1. Build do sistema (toolchain + base).
2. Kernel + initramfs (dentro do rootfs).
3. Geração da ISO mínima.
4. Geração do rootfs tarball limpo.
5. (Opcional) Teste em QEMU.

### 12.1 Localização e conceito

Script:

```text
project/tools/3blinux-orchestrator
```

Ele assume que você está no diretório `project/` e que `rootfs/` é o root do
sistema 3bLinux.

### 12.2 Uso básico

Pipeline completo, com todas as etapas:

```bash
cd project
./tools/3blinux-orchestrator
```

Ele:

- Tenta encontrar um wrapper de build (`lfs-full-build`) no projeto ou no PATH.
- Roda o `lfs-build-kernel` dentro do rootfs via `chroot`.
- Chama `3blinux-make-iso` para gerar uma ISO em `out/`.
- Chama `3blinux-make-rootfs` para gerar um tarball de rootfs em `out/`.
- Se configurado, dispara um teste em QEMU.

### 12.3 Opções de linha de comando

O orquestrador aceita as seguintes opções:

```text
--skip-build     Pula a etapa de construção do sistema.
--skip-kernel    Pula a etapa de kernel + initramfs.
--skip-iso       Pula geração da ISO.
--skip-rootfs    Pula geração do rootfs tarball.

--only-iso       Executa apenas a geração da ISO
                 (implica pular build, kernel e rootfs).
--only-rootfs    Executa apenas a geração do rootfs tarball
                 (implica pular build, kernel e ISO).

-h, --help       Mostra ajuda e sai.
```

Exemplos:

```bash
# Apenas ISO (assume que kernel/initramfs e rootfs já existem):
./tools/3blinux-orchestrator --only-iso

# Apenas rootfs tarball (sem mexer em kernel/ISO):
./tools/3blinux-orchestrator --only-rootfs

# Pular apenas build (útil se o sistema já foi construído manualmente antes):
./tools/3blinux-orchestrator --skip-build
```

### 12.4 Variáveis de ambiente

Algumas variáveis podem ajustar o comportamento:

```text
PROJECT_DIR      Diretório raiz do projeto (padrão: diretório atual).
ROOTFS_DIR       Diretório do rootfs (padrão: PROJECT_DIR/rootfs).
TOOLS_DIR        Diretório com scripts (padrão: PROJECT_DIR/tools).
OUT_DIR          Diretório de saída (padrão: PROJECT_DIR/out).

ISO_NAME         Nome do arquivo ISO (padrão: 3blinux-1.0-minimal.iso).
ROOTFS_TARBALL   Nome do tar.gz de rootfs (padrão: 3blinux-rootfs.tar.xz).

QEMU_DISK_IMAGE  Imagem qcow2 ou similar para teste em QEMU.
QEMU_RAM_MB      Memória em MB para QEMU (padrão: 1024).
```

### 12.5 Logs por etapa (`out/logs/`)

O orquestrador cria um diretório de logs:

```text
project/out/logs/
```

Arquivos principais:

- `orchestrator.log` – log geral do orquestrador (resumo das ações).
- `step1-build.log` – tudo que foi impresso na etapa de build.
- `step2-kernel.log` – saída do `lfs-build-kernel`.
- `step3-iso.log` – saída do `3blinux-make-iso`.
- `step4-rootfs.log` – saída do `3blinux-make-rootfs`.
- `step5-qemu.log` – saída do QEMU (se usado).

Sempre que uma etapa falhar, o orquestrador indica qual log consultar, por
exemplo:

```text
[orchestrator] Veja detalhes em: out/logs/step2-kernel.log
[orchestrator] ERRO: Falha em lfs-build-kernel (consulte o log).
```

Isso torna o debug muito mais simples, pois cada etapa tem o seu log dedicado.

### 12.6 Idempotência e reexecução

O orquestrador foi escrito para ser:

- **Seguro para reexecução**:
  - Rodar o script novamente sobrescreve ISO e rootfs tarball em `out/` (sem
    acumular lixo).
  - Se você quiser refazer apenas uma parte, use as flags `--skip-*` ou
    `--only-*`.
- **Maximamente automático**:
  - Descobre automaticamente o `lfs-full-build` (no projeto ou no PATH).
  - Usa `chroot` quando disponível para compilar o kernel dentro do rootfs.
  - Cria automaticamente `out/` e `out/logs/` se não existirem.

Fluxos típicos:

```bash
# Construir tudo do zero (build + kernel + ISO + rootfs):
./tools/3blinux-orchestrator

# Regerar apenas a ISO após ajustar configs em /etc, sem rebuild:
./tools/3blinux-orchestrator --only-iso

# Gerar só o rootfs tarball a partir de um rootfs já montado:
ROOTFS_DIR=/mnt/3blinux-root \
OUT_DIR=/tmp/artefatos \
./tools/3blinux-orchestrator --only-rootfs
```

Se algo der errado em qualquer etapa, a primeira coisa a fazer é:

1. Ler `out/logs/orchestrator.log` para ver o resumo.
2. Abrir o log da etapa específica (por exemplo, `step3-iso.log`).
3. Corrigir o problema (pacote faltando, ferramenta ausente, etc.).
4. Reexecutar o orquestrador com as flags apropriadas.

---

Com o orquestrador, o `3bLinux` deixa de ser apenas um conjunto de scripts
isolados e passa a ser um **pipeline completo** de construção de uma mini
distro: da toolchain até a ISO de instalação pronta para teste em VM ou
hardware real.
