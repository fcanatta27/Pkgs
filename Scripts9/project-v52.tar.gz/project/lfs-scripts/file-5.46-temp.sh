\
    #!/usr/bin/env bash
    #
    # File-5.46 (ferramenta temporária) - LFS 6.7

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="file-5.46-temp"

    PKG_NAME="file-5.46"
    PKG_TARBALL="${PKG_NAME}.tar.gz"
    FILE_URL_DEFAULT="https://astron.com/pub/file/${PKG_TARBALL}"
    : "${FILE_SRC_URL:=${FILE_URL_DEFAULT}}"

    if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
        echo "Baixando ${PKG_TARBALL}..."
        curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${FILE_SRC_URL}"
    fi

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    mkdir -v build
    pushd build
      ../configure --disable-bzlib      \
                   --disable-libseccomp \
                   --disable-xzlib      \
                   --disable-zlib
      make
    popd

    ./configure --prefix=/usr --host="${LFS_TGT}" --build="$(./config.guess)"
    make FILE_COMPILE="$(pwd)/build/src/file"

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    rm -f "${LFS_ROOTFS}/usr/lib/libmagic.la" || true

    echo "File-5.46 (temporário) instalado em ${LFS_ROOTFS}."
