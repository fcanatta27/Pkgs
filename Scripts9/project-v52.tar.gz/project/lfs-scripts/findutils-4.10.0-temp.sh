\
    #!/usr/bin/env bash
    #
    # Findutils-4.10.0 (ferramenta temporária) - LFS 6.8

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="findutils-4.10.0-temp"

    PKG_NAME="findutils-4.10.0"
    PKG_TARBALL="${PKG_NAME}.tar.xz"
    FINDUTILS_URL_DEFAULT="https://ftp.gnu.org/gnu/findutils/${PKG_TARBALL}"
    : "${FINDUTILS_SRC_URL:=${FINDUTILS_URL_DEFAULT}}"

    if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
        echo "Baixando ${PKG_TARBALL}..."
        curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${FINDUTILS_SRC_URL}"
    fi

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    ./configure --prefix=/usr \
                --localstatedir=/var/lib/locate \
                --host="${LFS_TGT}" \
                --build="$(build-aux/config.guess)"

    make

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    echo "Findutils-4.10.0 (temporário) instalado em ${LFS_ROOTFS}."
