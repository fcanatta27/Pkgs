\
    #!/usr/bin/env bash
    #
    # Binutils-2.45.1 - Passagem 1 (cross toolchain)
    # LFS: capítulo 5.2 (adaptado para DESTDIR + ${LFS_ROOTFS})

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="binutils-2.45.1-pass1"

    PKG_NAME="binutils-2.45.1"
    PKG_TARBALL="${PKG_NAME}.tar.xz"
    BINUTILS_URL_DEFAULT="https://ftp.gnu.org/gnu/binutils/${PKG_TARBALL}"
    : "${BINUTILS_SRC_URL:=${BINUTILS_URL_DEFAULT}}"

    if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
        echo "Baixando ${PKG_TARBALL}..."
        curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${BINUTILS_SRC_URL}"
    fi

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    mkdir -v build
    cd       build

    ../configure \
        --prefix=/tools \
        --with-sysroot="${LFS}" \
        --target="${LFS_TGT}" \
        --disable-nls \
        --enable-gprofng=no \
        --disable-werror \
        --enable-new-dtags \
        --enable-default-hash-style=gnu

    make

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    echo "Binutils-2.45.1 Pass 1 instalado em ${LFS_ROOTFS}/tools."
