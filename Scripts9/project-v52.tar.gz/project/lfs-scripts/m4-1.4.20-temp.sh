\
    #!/usr/bin/env bash
    #
    # M4-1.4.20 (ferramenta temporária) - LFS 6.2

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="m4-1.4.20-temp"

    PKG_NAME="m4-1.4.20"
    PKG_TARBALL="${PKG_NAME}.tar.xz"
    M4_URL_DEFAULT="https://ftp.gnu.org/gnu/m4/${PKG_TARBALL}"
    : "${M4_SRC_URL:=${M4_URL_DEFAULT}}"

    if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
        echo "Baixando ${PKG_TARBALL}..."
        curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${M4_SRC_URL}"
    fi

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    ./configure --prefix=/usr \
                --host="${LFS_TGT}" \
                --build="$(build-aux/config.guess)"

    make

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    echo "M4-1.4.20 (temporário) instalado em ${LFS_ROOTFS}."
