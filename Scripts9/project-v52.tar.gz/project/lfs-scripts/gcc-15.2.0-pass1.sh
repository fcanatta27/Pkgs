\
    #!/usr/bin/env bash
    #
    # GCC-15.2.0 - Passagem 1 (cross toolchain)
    # LFS: capítulo 5.3 (adaptado para DESTDIR + ${LFS_ROOTFS})

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="gcc-15.2.0-pass1"

    PKG_NAME="gcc-15.2.0"
    PKG_TARBALL="${PKG_NAME}.tar.xz"

    MPFR_TARBALL="mpfr-4.2.2.tar.xz"
    GMP_TARBALL="gmp-6.3.0.tar.xz"
    MPC_TARBALL="mpc-1.3.1.tar.gz"

    GCC_URL_DEFAULT="https://gcc.gnu.org/pub/gcc/releases/gcc-15.2.0/${PKG_TARBALL}"
    MPFR_URL_DEFAULT="https://ftp.gnu.org/gnu/mpfr/${MPFR_TARBALL}"
    GMP_URL_DEFAULT="https://ftp.gnu.org/gnu/gmp/${GMP_TARBALL}"
    MPC_URL_DEFAULT="https://ftp.gnu.org/gnu/mpc/${MPC_TARBALL}"

    : "${GCC_SRC_URL:=${GCC_URL_DEFAULT}}"
    : "${MPFR_SRC_URL:=${MPFR_URL_DEFAULT}}"
    : "${GMP_SRC_URL:=${GMP_URL_DEFAULT}}"
    : "${MPC_SRC_URL:=${MPC_URL_DEFAULT}}"

    for tb url in \
        "${PKG_TARBALL} ${GCC_SRC_URL}" \
        "${MPFR_TARBALL} ${MPFR_SRC_URL}" \
        "${GMP_TARBALL}  ${GMP_SRC_URL}"  \
        "${MPC_TARBALL}  ${MPC_SRC_URL}"
    do
        set -- ${tb}
        tarball="$1"
        src="$2"
        if [ ! -f "${LFS_SRCDIR}/${tarball}" ]; then
            echo "Baixando ${tarball}..."
            curl -L -C - -o "${LFS_SRCDIR}/${tarball}" "${src}"
        fi
    done

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    tar -xf "${LFS_SRCDIR}/${MPFR_TARBALL}"
    mv -v mpfr-4.2.2 mpfr

    tar -xf "${LFS_SRCDIR}/${GMP_TARBALL}"
    mv -v gmp-6.3.0 gmp

    tar -xf "${LFS_SRCDIR}/${MPC_TARBALL}"
    mv -v mpc-1.3.1 mpc

    case "$(uname -m)" in
      x86_64)
        sed -e '/m64=/s/lib64/lib/' -i.orig gcc/config/i386/t-linux64
      ;;
    esac

    mkdir -v build
    cd       build

    ../configure                  \
        --target="${LFS_TGT}"     \
        --prefix=/tools           \
        --with-glibc-version=2.42 \
        --with-sysroot="${LFS}"   \
        --with-newlib             \
        --without-headers         \
        --enable-default-pie      \
        --enable-default-ssp      \
        --disable-nls             \
        --disable-shared          \
        --disable-multilib        \
        --disable-threads         \
        --disable-libatomic       \
        --disable-libgomp         \
        --disable-libquadmath     \
        --disable-libssp          \
        --disable-libvtv          \
        --disable-libstdcxx       \
        --enable-languages=c,c++

    make all-gcc
    make all-target-libgcc

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install-gcc
    make DESTDIR="${LFS_DESTDIR}" install-target-libgcc

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    echo "GCC-15.2.0 Pass 1 instalado em ${LFS_ROOTFS}/tools."
