\
    #!/usr/bin/env bash
    #
    # Xz-5.8.2 (ferramenta temporária) - LFS 6.16
    #
    # Construído como ferramenta temporária em /usr dentro do sysroot ($LFS_ROOTFS),
    # usando DESTDIR + cópia via common.sh.

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="xz-5.8.2-temp"

    PKG_NAME="xz-5.8.2"
    PKG_TARBALL="${PKG_NAME}.tar.xz"
    XZ_URL_DEFAULT="https://tukaani.org/xz/${PKG_TARBALL}"
    : "${XZ_SRC_URL:=${XZ_URL_DEFAULT}}"

    if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
        echo "Baixando ${PKG_TARBALL}..."
        curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${XZ_SRC_URL}"
    fi

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}" || tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    ./configure --prefix=/usr \
                --host="${LFS_TGT}" \
                --build="$(./config.guess)" \
                --disable-static

    make

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    echo "Xz-5.8.2 (temporário) instalado em ${LFS_ROOTFS}."
