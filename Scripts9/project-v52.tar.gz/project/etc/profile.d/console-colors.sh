# /etc/profile.d/console-colors.sh - tema básico de console

# Prompt colorido para root e usuários normais
case "$UID" in
  0)
    PS1='\[\e[1;31m\]\u@\h\[\e[0m\]:\[\e[1;34m\]\w\[\e[0m\]\$ '
    ;;
  *)
    PS1='\[\e[1;32m\]\u@\h\[\e[0m\]:\[\e[1;34m\]\w\[\e[0m\]\$ '
    ;;
esac

# LS colorido (se dircolors presente)
if command -v dircolors >/dev/null 2>&1; then
  if [ -r /etc/dircolors ]; then
    eval "$(dircolors -b /etc/dircolors)"
  fi
fi

alias ls='ls --color=auto'
alias ll='ls -alF'
alias la='ls -A'
