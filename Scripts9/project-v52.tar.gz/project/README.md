\
    # project - Scripts LFS (Binutils/GCC Pass 1)

    Este projeto contém:

    - `rootfs/` — raiz vazia para referência (o rootfs real é `/tmp/rootfs` em tempo de execução).
    - `lfs-scripts/` — scripts de construção do Binutils/GCC Pass 1.
    - `bin/` — wrapper `lfs-build` para orquestrar downloads, builds e uninstall.
    - `doc/` — documentação em português (`tutorial-pt_BR.md`).

    Veja `doc/tutorial-pt_BR.md` para instruções completas de uso.


Pacotes cobertos atualmente (toolchain inicial + temporários):

- Binutils 2.45.1 (Pass 1)
- GCC 15.2.0 (Pass 1 + libstdc++)
- Linux API Headers 6.18.5
- Glibc 2.42 (Pass 1)
- m4 1.4.20 (temporário)
- ncurses 6.5 (temporário)
- bash 5.3 (temporário)
- coreutils 9.9 (temporário)
- diffutils 3.12 (temporário)
- file 5.46 (temporário)
