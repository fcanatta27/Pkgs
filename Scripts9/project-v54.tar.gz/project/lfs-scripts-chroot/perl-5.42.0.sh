#!/usr/bin/env bash
#
# Script de construção do Perl-5.42.0 (capítulo 8, dentro do chroot).
#
# Pré-requisitos:
#   - Estar dentro do chroot LFS.
#   - Pacotes básicos (zlib, bzip2, etc.) já instalados conforme o LFS.
#   - Sources em /sources ou apontados via $LFS_SOURCES.
#
# Uso:
#   (chroot) root:/# cd /sources
#   (chroot) root:/sources# /project/lfs-scripts-chroot/perl-5.42.0.sh
#
# Para pular testes:
#   export LFS_SKIP_TESTS=1
#

set -euo pipefail

SRC_DIR="${LFS_SOURCES:-/sources}"

find_tarball() {
    local base="$1"
    local exts=(tar.xz tar.gz tar.bz2)
    local e
    for e in "${exts[@]}"; do
        if [ -f "${SRC_DIR}/${base}.${e}" ]; then
            echo "${SRC_DIR}/${base}.${e}"
            return 0
        fi
    done
    echo "Tarball não encontrado para base=${base} em ${SRC_DIR}" >&2
    return 1
}

main() {
    local tarball srcdir
    tarball="$(find_tarball perl-5.42.0)"

    echo "[Perl] Extraindo ${tarball}..."
    rm -rf perl-5.42.0
    tar -xf "${tarball}"
    srcdir="perl-5.42.0"
    cd "${srcdir}"

    # O LFS organiza os diretórios de biblioteca do Perl por versão.
    # Aqui seguimos o padrão aproximado do livro, ajustando para 5.42.0.
    local version="5.42"
    local archdir="/usr/lib/perl5/${version}/core_perl"
    local privlib="/usr/lib/perl5/${version}/core_perl"
    local sitelib="/usr/lib/perl5/${version}/site_perl"
    local sitearch="/usr/lib/perl5/${version}/site_perl"
    local vendorlib="/usr/lib/perl5/${version}/vendor_perl"
    local vendorarch="/usr/lib/perl5/${version}/vendor_perl"

    sh Configure -des \
        -Dprefix=/usr \
        -Dvendorprefix=/usr \
        -Dprivlib="${privlib}" \
        -Darchlib="${archdir}" \
        -Dsitelib="${sitelib}" \
        -Dsitearch="${sitearch}" \
        -Dvendorlib="${vendorlib}" \
        -Dvendorarch="${vendorarch}" \
        -Dman1dir=/usr/share/man/man1 \
        -Dman3dir=/usr/share/man/man3 \
        -Dpager="/usr/bin/less -isR" \
        -Duseshrplib \
        -Dusethreads

    make

    if [ "${LFS_SKIP_TESTS:-0}" != "1" ]; then
        echo "[Perl] Executando 'make test_harness' (pode demorar bastante)..."
        TEST_JOBS="$(nproc)" make test_harness || echo "[AVISO] Testes do Perl retornaram erro; verifique os logs."
    else
        echo "[Perl] Testes pulados (LFS_SKIP_TESTS=1)."
    fi

    make install

    # Limpeza conforme recomendações usuais do LFS (remover .packlist, arquivos de build)
    find /usr/lib/perl5 -name .packlist -delete || true
    find /usr/lib/perl5 -name perllocal.pod -delete || true

    unset BUILD_ZLIB BUILD_BZIP2 || true

    echo "[OK] Perl-5.42.0 instalado conforme o capítulo 8 (ajustado ao fluxo do projeto)."
}

main "$@"
