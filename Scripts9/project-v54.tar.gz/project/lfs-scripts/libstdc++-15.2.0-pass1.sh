\
    #!/usr/bin/env bash
    #
    # Libstdc++ a partir do GCC-15.2.0 (capítulo 5.6)

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="libstdc++-15.2.0-pass1"

    PKG_NAME="gcc-15.2.0"
    PKG_TARBALL="${PKG_NAME}.tar.xz"
    GCC_URL_DEFAULT="https://gcc.gnu.org/pub/gcc/releases/gcc-15.2.0/${PKG_TARBALL}"
    : "${GCC_SRC_URL:=${GCC_URL_DEFAULT}}"

    if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
        echo "Baixando ${PKG_TARBALL}..."
        curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${GCC_SRC_URL}"
    fi

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    mkdir -v build
    cd       build

    ../libstdc++-v3/configure      \
        --host="${LFS_TGT}"        \
        --build="$(../config.guess)" \
        --prefix=/usr              \
        --disable-multilib         \
        --disable-nls              \
        --disable-libstdcxx-pch    \
        --with-gxx-include-dir=/tools/"${LFS_TGT}"/include/c++/15.2.0

    make

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    rm -f "${LFS_ROOTFS}/usr/lib"/lib{stdc++{,exp,fs},supc++}.la || true

    echo "Libstdc++ (GCC 15.2.0, capítulo 5) instalada em ${LFS_ROOTFS}."
