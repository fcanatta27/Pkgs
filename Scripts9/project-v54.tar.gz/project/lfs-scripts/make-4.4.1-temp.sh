\
    #!/usr/bin/env bash
    #
    # Make-4.4.1 (ferramenta temporária) - LFS 6.12

    set -euo pipefail

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    . "${SCRIPT_DIR}/common.sh"

    STEP_ID="make-4.4.1-temp"

    PKG_NAME="make-4.4.1"
    PKG_TARBALL="${PKG_NAME}.tar.gz"
    MAKE_URL_DEFAULT="https://ftp.gnu.org/gnu/make/${PKG_TARBALL}"
    : "${MAKE_SRC_URL:=${MAKE_URL_DEFAULT}}"

    if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
        echo "Baixando ${PKG_TARBALL}..."
        curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${MAKE_SRC_URL}"
    fi

    cd "${LFS_WORKDIR}"
    rm -rf "${PKG_NAME}"
    tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
    cd "${PKG_NAME}"

    ./configure --prefix=/usr \
                --host="${LFS_TGT}" \
                --build="$(build-aux/config.guess)"

    make

    reset_destdir
    make DESTDIR="${LFS_DESTDIR}" install

    register_installed_files "${STEP_ID}"
    sync_destdir_to_rootfs

    echo "Make-4.4.1 (temporário) instalado em ${LFS_ROOTFS}."
