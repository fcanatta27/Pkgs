#!/bin/sh
# Apply rootfs scripts to a mounted target root (e.g., /mnt/root)
set -eu
TARGET="${1:-}"
[ -n "$TARGET" ] || { echo "usage: $0 /path/to/mounted-root" >&2; exit 1; }
[ -d "$TARGET" ] || { echo "target not found: $TARGET" >&2; exit 1; }

copy() {
  src="$1"; dst="$2"; mode="$3"
  mkdir -p "$(dirname "$TARGET/$dst")"
  cp "$src" "$TARGET/$dst"
  chmod "$mode" "$TARGET/$dst"
}

copy rootfs/etc/inittab /etc/inittab 0644
copy rootfs/etc/rc.d/rcS /etc/rc.d/rcS 0755
copy rootfs/etc/rc.d/rcK /etc/rc.d/rcK 0755
copy rootfs/etc/udhcpc/default.script /etc/udhcpc/default.script 0755
copy rootfs/etc/hostname /etc/hostname 0644
copy rootfs/etc/passwd /etc/passwd 0644
copy rootfs/etc/group /etc/group 0644
copy rootfs/etc/fstab /etc/fstab 0644

# init.d
mkdir -p "$TARGET/etc/init.d"
cp -a rootfs/etc/init.d/. "$TARGET/etc/init.d/"
chmod 0755 "$TARGET/etc/init.d/"* 2>/dev/null || true

# mypkg
mkdir -p "$TARGET/usr/bin"
cp -a mypkg/mypkg "$TARGET/usr/bin/mypkg"
chmod 0755 "$TARGET/usr/bin/mypkg"

echo "Applied rootfs scripts and mypkg to $TARGET"
