Projeto: Linux do zero (BusyBox init + initramfs + mypkg)
========================================================

Este kit entrega:
- initramfs funcional (scripts) com /init + mypkg dentro do initramfs
- diretório /repo no initramfs para bootstrap offline por pacotes binários
- rootfs scripts: /etc/inittab, /etc/rc.d/rcS, /etc/rc.d/rcK
- init scripts essenciais em /etc/init.d (syslog, dbus, seatd)
- mypkg monolítico POSIX sh (fonte + binário offline)

Observação importante
---------------------
Eu não consigo embutir binários (BusyBox, kernel, glibc) neste ambiente. Portanto, este kit é “funcional” no sentido de:
- os scripts, caminhos e integrações estão corretos;
- basta você colocar os binários esperados (BusyBox no initramfs; busybox/glibc/etc no root real).
O objetivo é te dar uma base operacional e coerente para você compilar o userland.

Parte A — Initramfs
------------------

### 1) Estrutura do initramfs
Veja `initramfs/`:
- `initramfs/init` : script de boot inicial
- `initramfs/bin/mypkg` : gerenciador mypkg dentro do initramfs
- `initramfs/repo/` : repositório offline de pacotes binários (*.pkg.tar)
- `initramfs/etc/profile` : conveniência para shell

Você deve fornecer:
- `initramfs/bin/busybox` (recomendado estático)
Depois:
  (cd initramfs && ./bin/busybox --install -s)

### 2) Fluxo do /init
1. monta /proc, /sys
2. monta /dev (devtmpfs ou fallback)
3. lê cmdline:
   - root=... (obrigatório recomendado)
   - earlyshell=1 (debug)
   - bootstrap=0 (desliga instalação offline)
4. monta root real em /newroot
5. se bootstrap ativo: instala pacotes em /repo para /newroot usando:
      mypkg --root /newroot bininstall /repo/*.pkg.tar
6. move /proc /sys /dev /run para /newroot
7. switch_root para /sbin/init (no root real)

Parte B — RootFS (busybox init)
-------------------------------

### 1) /etc/inittab
Entregue em `rootfs/etc/inittab`:
- sysinit: /etc/rc.d/rcS
- getty em tty1..tty6
- ctrlaltdel reboot
- shutdown: /etc/rc.d/rcK

### 2) rcS (serviços essenciais)
Entregue em `rootfs/etc/rc.d/rcS`:
- garante /proc /sys /dev
- monta /run e /tmp como tmpfs
- cria /var/log /var/run /var/lock
- seta hostname
- sysctl (se existir)
- mdev -s (dispositivos)
- mount -a (se existir fstab)
- syslogd/klogd (se existir)
- loopback
- DHCP via udhcpc (se existir)
- dbus-daemon --system (se existir)
- seatd (se existir)
- executa /etc/init.d/S??* start

### 3) rcK (shutdown)
Para serviços:
- executa /etc/init.d/K??* stop
- sync

Parte C — mypkg (gerenciador de programas)
------------------------------------------

### 1) Onde ficam recipes
No sistema alvo:
  /usr/src/mypkg/recipes/*.sh

Formato do recipe (POSIX sh):
  pkgname=...
  pkgver=...
  srcurl=...
  sha256=...
  deps="dep1 dep2"
  build(){ ... }
  package(){ ... }  # deve instalar em $DESTDIR

### 2) Comandos
Fonte:
- `mypkg build <pkg>`
- `mypkg install <pkg>`
- `mypkg upgrade <pkg|all>`

Binário offline:
- `mypkg binpack <pkg> [out.pkg.tar]`
- `mypkg bininstall <pkg.pkg.tar>`

Gerência:
- `mypkg list`
- `mypkg search <texto>`
- `mypkg info <pkg>`
- `mypkg remove <pkg>` (com prevenção de remover dependências e bloqueio em /etc)

### 3) Banco de dados
Em:
  /var/lib/mypkg/pkgs/<name>/
    meta   (name=, version=)
    deps   (um por linha)
    files  (manifesto de arquivos/symlinks, paths absolutos)
    timestamp
E índice:
  /var/lib/mypkg/installed

### 4) Segurança do uninstall
`mypkg remove`:
- recusa manifestos com paths não absolutos
- recusa “/”
- recusa qualquer coisa em “/etc”
- impede remover um pacote se outro instalado depender dele

Parte D — Bootstrap offline com /repo no initramfs
--------------------------------------------------

Objetivo: primeiro boot sem internet, instalando “o mínimo que falta” no root real.

1) No seu host de build, você gera pacotes binários:
   - monte um sysroot/chroot que consiga buildar pacotes
   - coloque recipes em /usr/src/mypkg/recipes
   - rode: mypkg binpack <pkg> out.pkg.tar

2) Copie os *.pkg.tar para `initramfs/repo/` antes de gerar o initramfs final.

3) No boot, o /init vai executar:
     mypkg --root /newroot bininstall /repo/*.pkg.tar

4) Para desabilitar, use cmdline:
     bootstrap=0

Parte E — Como aplicar este kit ao seu disco/root real
------------------------------------------------------

1) Copie os arquivos de rootfs do kit para seu root real (ex.: montado em /mnt/root):
   - /mnt/root/etc/inittab
   - /mnt/root/etc/rc.d/rcS
   - /mnt/root/etc/rc.d/rcK
   - /mnt/root/etc/udhcpc/default.script
   - /mnt/root/etc/init.d/*

2) Instale o `mypkg` no root real:
   - /mnt/root/usr/bin/mypkg (use o arquivo em `mypkg/mypkg`)

3) Garanta que no root real exista:
   - /sbin/init (busybox init)
   - /bin/sh (busybox)
   - glibc e loader dinâmico (se seu userland for dinâmico)
   - utilitários mínimos: tar, gzip/xz, make, gcc etc. conforme seu modo de build

Parte F — Próximas evoluções (desktop de verdade)
-------------------------------------------------

Para “desktop funcional” de verdade, normalmente você vai querer empacotar:
- mesa/Wayland compositor (ex.: sway/river/hyprland) OU Xorg
- libdrm, mesa, seatd/elogind, libinput
- dbus, polkit, NetworkManager
- áudio: pipewire + wireplumber
- fontes, locale, timezone, ca-certificates
- um display manager (opcional) ou startx/startwayland via tty

Este kit já prepara o alicerce (dbus + seatd opcional + rede básica).


Notas de correções (jan/2026)
----------------------------
- Corrigido bug de sintaxe no loop do bootstrap (/repo/*.pkg.tar).
- mypkg agora separa manifesto de arquivos e diretórios; o uninstall remove arquivos e tenta remover diretórios vazios depois.
- Remoção em ordem reversa agora é feita via tac/awk diretamente (sem sh -c frágil).
- bininstall não depende mais de tar --exclude; remove metadados antes de extrair para ROOT.
- udhcpc script agora converte netmask (subnet) para prefix length para uso com iproute2.
- rcS foi ajustado para montar devpts e /dev/shm e evitar duplicidade de inicialização; serviços ficam em /etc/init.d.
