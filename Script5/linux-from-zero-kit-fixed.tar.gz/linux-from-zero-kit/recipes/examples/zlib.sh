pkgname=zlib
pkgver=1.3.1
srcurl="https://zlib.net/zlib-$pkgver.tar.gz"
sha256="" # fill it

deps=""

build() {
  ./configure --prefix=/usr
  make
}

package() {
  make DESTDIR="$DESTDIR" install
}
