Recipes
=======

Put your recipes in /usr/src/mypkg/recipes on the target system.
This kit includes examples under `recipes/examples/`.

A recipe is a POSIX sh file with:
  pkgname=
  pkgver=
  srcurl=
  sha256=   (recommended)
  deps=     (space-separated, optional)
  build() { ... }
  package() { ... }   # must install into $DESTDIR

