Initramfs tree (scripts only)
===========================

This kit ships scripts and configuration. You must provide:
- a BusyBox binary at initramfs/bin/busybox (static recommended)
- kernel modules (optional) if you need them early
- (optional) a minimal static 'tar' inside busybox; busybox tar is enough

After placing busybox:
  chmod +x initramfs/bin/busybox
  (cd initramfs && ./bin/busybox --install -s)

Then build initramfs:
  (cd initramfs && find . -print0 | cpio --null -ov --format=newc | gzip -9 > ../initramfs.cpio.gz)

Boot kernel with:
  initrd=initramfs.cpio.gz root=/dev/XXX rw

Notes:
- This initramfs includes /bin/mypkg and /repo for offline bootstrap into the real root.
- Kernel cmdline: bootstrap=0 disables offline install; earlyshell=1 drops to shell.
