Offline binary repository
========================

Place here one or more binary packages produced by `mypkg binpack ...`:

  *.pkg.tar

These are tar archives containing the target filesystem paths AND a metadata file
inside: .mypkg/meta, .mypkg/deps, .mypkg/files.

On first boot, initramfs /init will attempt:
  mypkg --root /newroot bininstall /repo/*.pkg.tar

You can disable it by adding kernel cmdline:
  bootstrap=0
