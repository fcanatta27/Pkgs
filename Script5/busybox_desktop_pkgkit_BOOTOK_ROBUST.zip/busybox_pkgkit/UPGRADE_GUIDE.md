# GUIA DE UPGRADE SEGURO

## Princípios
- Nunca atualize tudo de uma vez
- Sempre valide com revdep
- Tenha rollback possível

## Procedimento recomendado

### 1. Snapshot / backup
- btrfs: snapshot do subvol root
- ext4: backup de /etc e /var/lib/pkg

### 2. Atualizar um pacote
pkg install pacote-novo.pkg.xz

### 3. Validar
revdep report
revdep missing-libs --all

### 4. Reboot controlado
- se falhar, use initramfs + pkg para rollback

## Ordem segura de upgrades
1. libc
2. toolchain
3. mesa
4. xorg/wayland
5. pipewire
6. firefox

Nunca misture versões incompatíveis.

## Rollback
- btrfs: voltar snapshot
- pkg: reinstalar versão anterior
