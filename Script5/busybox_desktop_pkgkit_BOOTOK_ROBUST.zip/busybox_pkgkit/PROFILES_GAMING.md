# PROFILE — GAMING LIMPO (Steam + Vulkan, sem inchar)

Objetivo: habilitar jogos (Steam/Proton), Vulkan e drivers, mantendo o sistema enxuto.

## Pré-requisitos (base)
Assume que você já tem o perfil `PROFILES_DESKTOP_MIN.md` aplicado.

## Gráficos e Vulkan
- mesa-llvm               (recomendado para drivers/stack Vulkan completo)
- vulkan-icd-loader       (se você separar loader do mesa)
- spirv-tools             (conforme build da sua stack)
- libdrm
- libglvnd

## 32-bit (opcional, necessário para muitos jogos/Steam)
Se você pretende rodar Steam tradicional e jogos 32-bit:
- runtime compat 32-bit da libc (ex.: glibc-multilib) OU um prefixo/container 32-bit
- mesa 32-bit (se você mantiver multilib)

Se você NÃO quer multilib:
- prefira Flatpak/containers para Steam (mais pesado) OU
- use jogos nativos 64-bit / Lutris com prefixos controlados.

## Steam / Proton
Escolha um caminho:

### A) Steam nativo (mais direto, pode exigir multilib)
- steam
- (dependências de runtime do steam: gtk3, nss, nspr, etc.)
- proton (se separado)
- gamemode (opcional)

### B) Steam via sandbox (limpo e controlado)
- bubblewrap (bwrap)  (para sandbox leve)
- steam (rodando com bwrap + bind mounts controlados)
Vantagem: reduz risco e mantém rootfs mais limpo.

## Áudio e input
- pipewire-min
- wireplumber
- alsa-lib
- libinput (se aplicável ao seu stack)

## Performance (opcional, não-bloat)
- gamemode (Feral)  (ajusta governor/perf durante o jogo)
- mangohud          (overlay de métricas; opcional)
- gamescope         (se você usar Wayland ou quiser frame pacing; opcional)

## Checklist rápido pós-instalação
- `vulkaninfo` funciona
- `glxinfo` (ou equivalente) mostra aceleração
- Steam inicia e baixa runtime
- áudio ok no PipeWire
