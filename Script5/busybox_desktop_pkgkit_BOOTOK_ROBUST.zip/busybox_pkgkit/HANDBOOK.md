# BUSYBOX DESKTOP PKGKIT — HANDBOOK

## 1. Objetivo do projeto
Este projeto fornece um sistema Linux mínimo, auditável e estável, baseado em BusyBox,
shell POSIX e um gerenciador de pacotes próprio.

O foco é simplicidade operacional, controle total do sistema e manutenção de longo prazo.

## 2. Filosofia
- Simplicidade acima de automação
- Falhas levam a shell, nunca a travamento
- Tudo é reproduzível do zero

## 3. Componentes
- BusyBox
- pkg
- revdep
- init / initramfs
- desktop mínimo (Mesa, Xorg/Wayland, PipeWire)

## 4. Fluxo de construção
1. Toolchain
2. Rootfs base
3. Sistema de pacotes
4. Desktop mínimo
5. Validação

## 5. Manutenção
- Atualizações controladas
- Auditoria com revdep
- Backups simples

Fim do Handbook.


## Perfis oficiais
- Desktop mínimo recomendado
- Laptop
- Modo imutável
- Guia de upgrade seguro


## Extensões avançadas
- Profile Gaming: PROFILES_GAMING.md
- Kernel mínimo: KERNEL_GUIDE_MIN.md
- Snapshot+upgrade: tools/snapshot-upgrade.sh
- Hardening: HARDENING_DESKTOP.md
