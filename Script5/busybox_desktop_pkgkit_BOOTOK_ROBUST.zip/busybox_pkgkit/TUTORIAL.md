# BusyBox Desktop + pkgkit (POSIX) — Kit completo (revisado)

Este kit fornece uma base **auditável** e **minimalista** para um sistema desktop de uso diário, usando:

- **BusyBox init** (`/etc/inittab` + `rcS`/`rcK` + scripts `S*`)
- **pkgkit**: gerenciador de pacotes em **um único script POSIX** (`/sbin/pkg`)
- **initramfs** com `/init` e `pkg` disponível para resgate/instalação

## 1) O que este kit resolve

- Boot funcional com BusyBox init e serviços essenciais.
- Instalação/upgrade/removal de pacotes em formato `.pkg.xz`.
- Registro local de arquivos instalados e política segura para `/etc` (conffiles):
  - nunca sobrescreve config diferente; cria `.pkgnew`
  - `remove` preserva `/etc`; `remove --purge` remove configs **somente se não modificadas**
- Recuperação via initramfs: shell de resgate e `pkg` disponível.

## 2) Estrutura do projeto (no sistema alvo)

Arquivos principais:
- `/etc/inittab`
- `/etc/init.d/rcS`
- `/etc/init.d/rcK`
- `/etc/init.d/S*` (serviços)
- `/sbin/pkg`

Banco de dados do pkg:
- `/var/lib/pkg/db/<nome>/{meta,files,conffiles,hashes}`

Cache local:
- `/var/cache/pkg/pkgs/<nome>-<versao>.pkg.xz`

## 3) Instalar o kit em um rootfs alvo (TARGET)

Suponha que seu rootfs alvo esteja montado em `/mnt/target`:

```sh
./install-kit.sh /mnt/target
```

Depois ajuste o usuário do startx:
```sh
echo "SEUUSUARIO" > /mnt/target/etc/X11/startx-user
```

Crie diretórios necessários:
```sh
mkdir -p /mnt/target/var/lib/pkg/db /mnt/target/var/cache/pkg/pkgs /mnt/target/var/log /mnt/target/run
```

## 4) initramfs

O arquivo `initramfs/init`:
- monta `/proc`, `/sys`, `/dev`, `/dev/pts`, `/run`
- tenta montar `root=` e dar `switch_root`
- se falhar, abre shell de resgate

Uso típico no resgate:
```sh
mount /dev/sdXn /mnt
pkg install /mnt/repo/algum-pacote.pkg.xz
```

## 5) Como empacotar programas com `pkg`

### 5.1 Conceito: staging (DESTDIR)

Você **nunca instala diretamente** no sistema real durante o build.
Você instala em um diretório staging (ex.: `/tmp/pkgroot`) e empacota.

Exemplo estrutura:
```
/tmp/pkgroot/
  usr/bin/meuprog
  usr/share/meuprog/...
  etc/meuprog.conf
```

### 5.2 `pkg pack`

```sh
pkg pack --name meuprog --version 1.0.0 --root /tmp/pkgroot --deps "libX11 zlib" --desc "Meu programa" --strip
```

Isso cria:
- `/var/cache/pkg/pkgs/meuprog-1.0.0.pkg.xz`

### 5.3 `pkg install` (múltiplos pacotes)

```sh
pkg install a.pkg.xz b.pkg.xz c.pkg.xz
```

### 5.4 Conffiles e `.pkgnew`

Qualquer arquivo regular dentro de `etc/` no pacote é tratado como conffile.
Se o arquivo já existe e for diferente, o novo vai para:
- `/etc/arquivo.pkgnew`

Você decide o merge.

### 5.5 `pkg upgrade` (upgrade inteligente)

```sh
pkg upgrade meuprog-1.1.0.pkg.xz
```

- instala por cima
- remove órfãos do pacote antigo **fora de /etc**
- nunca remove arquivos compartilhados por outro pacote (com base no DB)

### 5.6 `pkg remove` e `--purge`

Remoção padrão preserva `/etc`:
```sh
pkg remove meuprog
```

Purge tenta remover configs **somente se não modificadas**:
```sh
pkg remove meuprog --purge
```

### 5.7 `pkg check` (auditoria)

```sh
pkg check
pkg check --missing-only
pkg check --fix-perms
```

- detecta arquivos ausentes
- detecta `.pkgnew` em `/etc`
- `--fix-perms` restaura de forma **segura** via cache (respeita conffiles e nunca instala `.pkgmeta` no `/`)

### 5.8 `pkg search` (repo local)

```sh
pkg search firefox --repo /mnt/repo
```

Busca por `NAME/VERSION/DESC` lendo `.pkgmeta/meta` de cada pacote no diretório.

## 6) Serviços de desktop incluídos

- `S20dbus`: `dbus-daemon --system`
- `S30audio`: PipeWire/WirePlumber (preferencial) ou PulseAudio (fallback)
- `S40network`: DHCP básico (udhcpc) — recomendado substituir por NetworkManager/ConnMan
- `S50xorg`: startx simples no tty1 com usuário definido em `/etc/X11/startx-user`

### Recomendação para uso diário
- Troque `S40network` por um serviço real:
  - `NetworkManager` (mais completo) ou `ConnMan` (mais simples)
- Considere usar um display manager (LightDM, SDDM) quando estiver estável.

## 7) Limitações conhecidas (deliberadas)

- Sem assinatura/criptografia de pacotes (recomendado adicionar depois)
- Conflitos de arquivos: “último instalado vence”
- Sem hooks (pre/post) — simples por design

## 8) Próximos incrementos recomendados

- Assinatura de pacotes (minisign) e verificação antes de instalar
- Política opcional `--fail-on-conflict`
- Um formato de “repo index” local (catálogo) para acelerar `search`

## 5.9 `pkg why` (quem depende)

```sh
pkg why mesa
```

Imprime uma lista de pacotes instalados que declaram o pacote informado em `DEPS`.


## Templates de meta (DEPS prontos)

Veja `METAS_PRONTOS/` para templates `.meta` de pacotes grandes e variantes.


## Chroot seguro para usar o pkg

Script: `tools/chroot-pkg.sh`

Exemplos:
```sh
# entrar no chroot
tools/chroot-pkg.sh enter /mnt/target

# executar pkg dentro do chroot
tools/chroot-pkg.sh pkg /mnt/target install /repo/mesa-min-*.pkg.xz

# desmontar pseudo-fs
tools/chroot-pkg.sh umount /mnt/target
```


## Revdep (integridade e dependências reversas)

Script: `tools/revdep`

Exemplos:
```sh
# reverse deps (quem depende)
tools/revdep why mesa-min

# reverse deps recursivo (cadeia)
tools/revdep rwhy mesa-min

# dono de um arquivo pelo DB do pkg
tools/revdep owners /usr/lib/libGL.so.1

# arquivos do DB que não existem no filesystem
tools/revdep missing-files

# symlinks quebrados (baseado no DB)
tools/revdep broken-links

# bibliotecas faltantes (ELF NEEDED) — retorna exit 2 se achar problemas
tools/revdep missing-libs --all

# relatório resumido
tools/revdep report

# escopo por pacote
tools/revdep report --pkg firefox-min
```

Dica: rode `tools/revdep report` dentro do chroot do rootfs alvo para validar o conjunto instalado.

# bibliotecas faltantes (ELF NEEDED) — retorna exit 2 se houver problemas
tools/revdep missing-libs --all

# checar apenas um pacote
tools/revdep report --pkg firefox-min

# relatório geral (files + links + libs)
tools/revdep report
```

Dica: execute dentro do chroot (via `tools/chroot-pkg.sh`) para checar o rootfs alvo antes do boot.

### Revdep — comandos avançados

```sh
# arquivos não pertencentes a nenhum pacote (unowned)
tools/revdep unowned-files

# fecho de dependências (para preparar initramfs / bundles)
tools/revdep dep-closure firefox-min
```

## initramfs (boot robusto)

O `initramfs/init` agora suporta `root=/dev/...`, `root=UUID=...`, `root=LABEL=...`, `rootfstype=`, `rootflags=`, `ro/rw`, `rootdelay=`.

Requisitos recomendados no initramfs:
- busybox com: `mount`, `switch_root`, `chroot`, `mdev` (opcional), `sh`
- `blkid` (para usar UUID/LABEL)
- `pkg` (opcional) para resgate/instalação

Exemplo de cmdline do kernel:
```text
root=UUID=xxxx-xxxx rootfstype=ext4 ro rootwait
```

### initramfs: btrfs subvol e autoroot

- Para btrfs subvol: use `rootfstype=btrfs` e `rootflags=subvol=@` (ou `subvolid=...`).
- Se `root=` não for informado, o initramfs tentará `autoroot` montando partições em modo leitura e procurando `/sbin/init`.

Exemplos:
```text
root=UUID=XXXX rootfstype=btrfs rootflags=subvol=@ ro rootwait

# autoroot (sem root=; recomendado apenas em ambientes controlados)
rootfstype=ext4 ro rootwait
```

## Ferramentas: mkinitramfs e backup de rootfs

### mkinitramfs
```sh
tools/mkinitramfs.sh --out /boot/initramfs.img --busybox /usr/bin/busybox --extra-bin /sbin/blkid --include-pkg /sbin/pkg --compress xz
```

### Backup funcional do rootfs
```sh
tools/mkrootfs-backup.sh --root /mnt/rootfs --outdir /backups --name mysys
```

## Modo imutável: promover staging e limpar snapshots

```sh
# promover staging para @root
tools/promote-root.sh --device /dev/nvme0n1p2 --top /mnt/btrfs --staging .snapshots/@root-stage-YYYYMMDD-HHMMSS

# depois do boot ok:
tools/promote-root.sh boot-ok

# manter apenas os últimos 10 snapshots
tools/snapshot-retention.sh --device /dev/nvme0n1p2 --top /mnt/btrfs --keep 10
```

## GRUB: menu de snapshots

```sh
# gera entradas em /boot/grub/custom.cfg (btrfs snapshots)
tools/grub-snapshots.sh --device /dev/nvme0n1p2 --top /mnt/btrfs \
  --uuid XXXX-XXXX --kernel /boot/vmlinuz --initrd /boot/initramfs.img \
  --out /boot/grub/custom.cfg --limit 20 --extra "ro rootwait"
```


## Boot OK automático (gancho de produção)

O `rcS` inicia um watcher em background que marca `BOOT_OK` quando existir login em `tty1` (getty) ou um display manager ativo. Timeout em `BOOT_OK_TIMEOUT` (padrão 120s). Log: `/var/log/boot-ok-hook.log`.

## Self-heal (base do sistema)

Se pacotes essenciais estiverem ausentes em `/var/lib/pkg/db/` e existir um repositório local (`/boot/pkgrepo` ou `/var/cache/pkgrepo`), o boot tenta instalar automaticamente usando `pkg`.


### BOOT_OK_MODE (robusto)
- `BOOT_OK_MODE=tty`: marca somente quando TTY login funcional estiver pronto (tty1 + getty + /bin/sh + /etc/passwd).
- `BOOT_OK_MODE=x`: marca somente quando X estiver pronto (socket `/tmp/.X11-unix/X0` e Xorg detectado).
- `BOOT_OK_MODE=either` (padrão): marca quando qualquer um dos dois estiver pronto.
- Timeout: `BOOT_OK_TIMEOUT` (padrão 180s).
