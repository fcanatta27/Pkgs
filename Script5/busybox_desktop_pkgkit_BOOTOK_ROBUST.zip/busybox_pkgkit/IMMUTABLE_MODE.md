# MODO IMUTÁVEL (OPCIONAL) — ROOT QUASE READ-ONLY

## 1. Por que usar modo imutável
Modo imutável reduz erros e “drift” do sistema:
- evita modificações acidentais em `/usr`, `/bin`, `/lib`, `/sbin`
- torna upgrades previsíveis (via snapshot/staging)
- facilita rollback confiável

Você ainda terá áreas RW para configuração e estado:
- `/etc` (configurações)
- `/var` (cache, DB do pkg, logs, spool)

## 2. Modelo recomendado (Btrfs subvolumes)
Use um único filesystem Btrfs com subvolumes:

- `@root`  → **sistema** (quase imutável)
- `@etc`   → configurações (rw)
- `@var`   → estado (rw)
- `@home`  → usuário (rw)
- `.snapshots` → snapshots (rw, administração)

### Montagens recomendadas (fstab)
Exemplo (substitua UUID):

- `/` montado como `@root` em **ro**
- `/etc` montado como `@etc` em **rw**
- `/var` montado como `@var` em **rw**
- `/home` montado como `@home` em **rw**

Exemplo conceptual:
- UUID=XXXX  /     btrfs  subvol=@root,ro,compress=zstd:3  0 0
- UUID=XXXX  /etc  btrfs  subvol=@etc,rw,compress=zstd:3   0 0
- UUID=XXXX  /var  btrfs  subvol=@var,rw,compress=zstd:3   0 0
- UUID=XXXX  /home btrfs  subvol=@home,rw,compress=zstd:3  0 0

## 3. Como criar do zero (passo a passo)
Assumindo o disco já particionado (ex.: /dev/nvme0n1p2):

1) Criar filesystem:
- mkfs.btrfs -f /dev/nvme0n1p2

2) Montar top-level:
- mount -t btrfs /dev/nvme0n1p2 /mnt

3) Criar subvolumes:
- btrfs subvolume create /mnt/@root
- btrfs subvolume create /mnt/@etc
- btrfs subvolume create /mnt/@var
- btrfs subvolume create /mnt/@home
- mkdir -p /mnt/.snapshots

4) Desmontar e montar layout final:
- umount /mnt
- mount -t btrfs -o subvol=@root,ro /dev/nvme0n1p2 /mnt
- mkdir -p /mnt/etc /mnt/var /mnt/home
- mount -t btrfs -o subvol=@etc,rw /dev/nvme0n1p2 /mnt/etc
- mount -t btrfs -o subvol=@var,rw /dev/nvme0n1p2 /mnt/var
- mount -t btrfs -o subvol=@home,rw /dev/nvme0n1p2 /mnt/home

Agora você instala o sistema em `/mnt` (via chroot e pkg).

## 4. Como funciona o upgrade (conceito operacional)
Como `/` está ro, você NÃO aplica upgrades direto no root ativo.

Fluxo robusto:
1) criar snapshot ro de `@root` (rollback)
2) criar staging RW (snapshot de `@root`)
3) montar staging em /mnt/stage
4) bind/mountar `@etc` e `@var` dentro do staging
5) executar `pkg install ...` dentro do staging
6) validar com `revdep report`
7) promover staging para virar o novo `@root`

O script `tools/snapshot-upgrade.sh` (modo immutable) automatiza 1–6 e imprime os passos para 7.

## 5. Como fazer rollback
Rollback típico (pós-boot com problema):
- boot no initramfs (shell) ou em um live USB
- montar o top-level btrfs
- trocar `@root` atual por um snapshot anterior

Se você mantém o snapshot ro em `.snapshots`, a troca é apenas renomear subvolumes.

## 6. Armadilhas comuns
- Esquecer de montar `/etc` e `/var` no staging: você perde DB do pkg e configs.
- Misturar upgrades de libc/toolchain sem snapshot.
- Usar autoroot em produção (prefira root=UUID).
- Deixar /home dentro de @root (separe).

## 7. Recomendação prática
Para desktop diário:
- use root=UUID e rootfstype=btrfs
- rootflags=subvol=@root,ro
- mantenha `.snapshots` com retenção simples (ex.: últimos 10 snapshots)

