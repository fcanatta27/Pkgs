#!/bin/sh
set -eu
# Instala este kit em um TARGET (rootfs montado)
# Uso: ./install-kit.sh /mnt/target

TARGET="${1:-}"
[ -n "$TARGET" ] || { echo "Uso: $0 /caminho/target" >&2; exit 2; }
[ -d "$TARGET" ] || { echo "Target inexistente: $TARGET" >&2; exit 1; }

install -D -m 0755 pkgkit/sbin/pkg "$TARGET/sbin/pkg"
install -D -m 0644 busybox_rootfs/etc/inittab "$TARGET/etc/inittab"
install -D -m 0755 busybox_rootfs/etc/init.d/rcS "$TARGET/etc/init.d/rcS"
install -D -m 0755 busybox_rootfs/etc/init.d/rcK "$TARGET/etc/init.d/rcK"

for f in busybox_rootfs/etc/init.d/S*; do
  install -D -m 0755 "$f" "$TARGET/etc/init.d/$(basename "$f")"
done

install -D -m 0644 busybox_rootfs/etc/hostname "$TARGET/etc/hostname"
install -D -m 0644 busybox_rootfs/etc/sysctl.conf "$TARGET/etc/sysctl.conf"
install -D -m 0644 busybox_rootfs/etc/fstab "$TARGET/etc/fstab"
install -D -m 0644 busybox_rootfs/etc/X11/startx-user "$TARGET/etc/X11/startx-user"

install -D -m 0644 busybox_rootfs/etc/pkg/pkg.conf "$TARGET/etc/pkg/pkg.conf"
mkdir -p "$TARGET/var/lib/pkg/db" "$TARGET/var/cache/pkg/pkgs" "$TARGET/var/log" "$TARGET/run"

echo "OK: kit instalado em $TARGET"
