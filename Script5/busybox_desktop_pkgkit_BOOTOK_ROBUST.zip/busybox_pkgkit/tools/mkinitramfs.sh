#!/bin/sh
# mkinitramfs.sh — gera initramfs completo e inteligente (BusyBox + /init do projeto)
#
# Melhorias:
# - copia libs via readelf/ldd quando disponíveis
# - inclui /init do projeto (UUID/LABEL, btrfs subvol, autoroot)
# - permite incluir firmware e módulos (opcional, como arquivos brutos)
#
# Uso:
#   tools/mkinitramfs.sh --out /boot/initramfs.img --busybox /usr/bin/busybox \
#     --extra-bin /sbin/blkid --include-bin /sbin/pkg --compress xz
#
set -eu

die(){ echo "Erro: $*" >&2; exit 1; }
note(){ echo "==> $*" >&2; }
need(){ command -v "$1" >/dev/null 2>&1 || die "comando necessário não encontrado: $1"; }

OUT=""
BUSYBOX=""
INIT_REL="initramfs/init"
COMPRESS="xz"
WORK=""
EXTRAS=""
FILES=""

while [ $# -gt 0 ]; do
  case "$1" in
    --out) OUT="${2:-}"; shift 2 ;;
    --busybox) BUSYBOX="${2:-}"; shift 2 ;;
    --init) INIT_REL="${2:-}"; shift 2 ;;
    --compress) COMPRESS="${2:-}"; shift 2 ;;
    --extra-bin|--include-bin) EXTRAS="${EXTRAS} ${2:-}"; shift 2 ;;
    --include-file) FILES="${FILES} ${2:-}"; shift 2 ;;
    -h|--help)
      cat <<EOF
Uso:
  $0 --out /boot/initramfs.img --busybox /path/busybox [--init initramfs/init]
     [--extra-bin /sbin/blkid] [--include-bin /sbin/pkg]
     [--include-file /lib/firmware/...] [--compress xz|gzip|none]
EOF
      exit 0
      ;;
    *) die "opção inválida: $1" ;;
  esac
done

[ -n "$OUT" ] || die "--out é obrigatório"
[ -n "$BUSYBOX" ] || die "--busybox é obrigatório"
[ -x "$BUSYBOX" ] || die "busybox não executável: $BUSYBOX"

need find
need cpio

case "$COMPRESS" in
  xz) need xz ;;
  gzip) need gzip ;;
  none) ;;
  *) die "compress inválido: $COMPRESS" ;;
esac

WORK="$(mktemp -d -t mkinitramfs.XXXXXX)"
trap 'rm -rf "$WORK"' EXIT

mkdir -p "$WORK"/{bin,sbin,proc,sys,dev,etc,run,tmp,newroot,lib,usr/lib}
chmod 0755 "$WORK" "$WORK"/bin "$WORK"/sbin
chmod 1777 "$WORK"/tmp

cp -f "$BUSYBOX" "$WORK/bin/busybox"
chmod 0755 "$WORK/bin/busybox"

note "Instalando symlinks do BusyBox..."
( cd "$WORK/bin" && ./busybox --install -s )

INIT_SRC="$INIT_REL"
if [ -f "$(dirname "$0")/../$INIT_REL" ]; then
  INIT_SRC="$(dirname "$0")/../$INIT_REL"
fi
[ -f "$INIT_SRC" ] || die "init não encontrado: $INIT_SRC"
cp -f "$INIT_SRC" "$WORK/init"
chmod 0755 "$WORK/init"

copy_file(){
  f="$1"
  [ -f "$f" ] || die "arquivo não existe: $f"
  dest="$WORK$f"
  mkdir -p "$(dirname "$dest")"
  cp -f "$f" "$dest"
}

# Extract NEEDED libs via readelf if possible
needed_libs(){
  bin="$1"
  if command -v readelf >/dev/null 2>&1; then
    readelf -d "$bin" 2>/dev/null | awk '/NEEDED/{gsub(/\[|\]/,"",$5); print $5}'
    return 0
  fi
  if command -v ldd >/dev/null 2>&1; then
    ldd "$bin" 2>/dev/null | awk '/=>/{print $3} /^[\/].*\.so/{print $1}' | sed '/^$/d'
    return 0
  fi
  return 1
}

find_lib_path(){
  name="$1"
  for d in /lib /usr/lib /lib64 /usr/lib64; do
    [ -d "$d" ] || continue
    if [ -f "$d/$name" ]; then
      echo "$d/$name"
      return 0
    fi
  done
  return 1
}

copy_bin(){
  b="$1"
  [ -x "$b" ] || die "binário não executável: $b"
  dest="$WORK$b"
  mkdir -p "$(dirname "$dest")"
  cp -f "$b" "$dest"
  chmod 0755 "$dest"

  # copia libs (best-effort)
  if libs="$(needed_libs "$b" 2>/dev/null || true)"; then
    for l in $libs; do
      case "$l" in
        linux-vdso.so.*|ld-linux*.so.*) continue ;;
      esac
      if [ -f "$l" ]; then
        copy_file "$l" 2>/dev/null || true
      else
        p="$(find_lib_path "$l" 2>/dev/null || true)"
        [ -n "$p" ] && copy_file "$p" 2>/dev/null || true
      fi
    done
  fi
}

for b in $EXTRAS; do
  copy_bin "$b"
done

for f in $FILES; do
  copy_file "$f"
done

if [ -f /etc/resolv.conf ]; then
  mkdir -p "$WORK/etc"
  cp -f /etc/resolv.conf "$WORK/etc/resolv.conf" 2>/dev/null || true
fi

note "Gerando cpio..."
( cd "$WORK" && find . -print0 | cpio --null -ov --format=newc ) > "$OUT.tmp"

note "Comprimindo: $COMPRESS"
case "$COMPRESS" in
  xz) xz -T0 -c "$OUT.tmp" > "$OUT" ;;
  gzip) gzip -c "$OUT.tmp" > "$OUT" ;;
  none) mv -f "$OUT.tmp" "$OUT" ;;
esac
rm -f "$OUT.tmp" 2>/dev/null || true
note "Initramfs criado: $OUT"
