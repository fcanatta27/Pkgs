#!/bin/sh
# mkrootfs-backup.sh — cria backup funcional de um rootfs (tar + xz) com segurança (POSIX)
#
# Melhorias:
# - suporte a arquivo de exclusões (--exclude-file)
# - checagem para evitar backup de / ao vivo
# - manifest + sha256 opcional
#
# Uso:
#   tools/mkrootfs-backup.sh --root /mnt/rootfs --outdir /backups --name mysys
#   tools/mkrootfs-backup.sh --root /mnt/rootfs --outdir /backups --name mysys --exclude-file /path/excludes.txt
#
set -eu

die(){ echo "Erro: $*" >&2; exit 1; }
note(){ echo "==> $*" >&2; }
need(){ command -v "$1" >/dev/null 2>&1 || die "comando necessário não encontrado: $1"; }

ROOT=""
OUTDIR="."
NAME="rootfs"
DO_SHA=1
EXCFILE=""

while [ $# -gt 0 ]; do
  case "$1" in
    --root) ROOT="${2:-}"; shift 2 ;;
    --outdir) OUTDIR="${2:-}"; shift 2 ;;
    --name) NAME="${2:-}"; shift 2 ;;
    --exclude-file) EXCFILE="${2:-}"; shift 2 ;;
    --no-sha) DO_SHA=0; shift ;;
    -h|--help)
      cat <<EOF
Uso:
  $0 --root /mnt/rootfs --outdir /backups --name mysys [--exclude-file excludes.txt] [--no-sha]
EOF
      exit 0
      ;;
    *) die "opção inválida: $1" ;;
  esac
done

[ -n "$ROOT" ] || die "--root é obrigatório"
[ -d "$ROOT" ] || die "rootfs não existe: $ROOT"
[ -d "$OUTDIR" ] || die "outdir não existe: $OUTDIR"

case "$ROOT" in
  /) die "recusado: não faça backup do / ao vivo; monte o rootfs em /mnt e use --root /mnt" ;;
esac

need tar
need xz
need find
if [ -n "$EXCFILE" ]; then
  [ -f "$EXCFILE" ] || die "exclude-file não existe: $EXCFILE"
fi
if [ "$DO_SHA" -eq 1 ]; then
  command -v sha256sum >/dev/null 2>&1 || DO_SHA=0
fi

ts="$(date +%Y%m%d-%H%M%S)"
archive="$OUTDIR/${NAME}-${ts}.tar.xz"
manifest="$OUTDIR/${NAME}-${ts}.manifest.txt"
sums="$OUTDIR/${NAME}-${ts}.sha256sums.txt"

note "Gerando manifest..."
( cd "$ROOT" && find . -xdev -print ) | sed 's#^\./##' > "$manifest"

note "Criando tar.xz (excluindo pseudo-fs e caches)..."
# exclusões padrão
tar_args="
  --numeric-owner --xattrs --xattrs-include=*   --exclude=./proc --exclude=./sys --exclude=./dev   --exclude=./run --exclude=./tmp --exclude=./mnt --exclude=./media   --exclude=./lost+found   --exclude=./var/cache --exclude=./var/tmp --exclude=./var/run   --exclude=./swapfile
"

if [ -n "$EXCFILE" ]; then
  tar -C "$ROOT" -c $tar_args --exclude-from="$EXCFILE" . | xz -T0 -c > "$archive"
else
  # shellcheck disable=SC2086
  tar -C "$ROOT" -c $tar_args . | xz -T0 -c > "$archive"
fi

note "Backup criado: $archive"
note "Manifest: $manifest"

if [ "$DO_SHA" -eq 1 ]; then
  note "Gerando sha256sums..."
  ( cd "$OUTDIR" && sha256sum "$(basename "$archive")" "$(basename "$manifest")" ) > "$sums"
  note "Checksums: $sums"
fi

note "Dica de restauração:"
cat <<EOF >&2
  # montar partição destino em /mnt
  tar -C /mnt -xJf "$archive"
EOF
