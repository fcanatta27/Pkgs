#!/bin/sh
# chroot-pkg.sh — entrar em chroot e executar pkg com segurança (POSIX)
#
# Uso:
#   chroot-pkg.sh enter /caminho/do/rootfs [--] [comando...]
#   chroot-pkg.sh pkg   /caminho/do/rootfs <args...>     (executa /sbin/pkg dentro do chroot)
#   chroot-pkg.sh shell /caminho/do/rootfs               (abre /bin/sh no chroot)
#   chroot-pkg.sh umount /caminho/do/rootfs              (desmonta pseudo-fs)
#
# Segurança:
# - recusa TARGET="/" ou vazio
# - monta apenas pseudo-fs necessários
# - verifica se já está montado antes de montar
# - desmonta em ordem segura
#
set -eu

die(){ echo "Erro: $*" >&2; exit 1; }
note(){ echo "==> $*" >&2; }

is_root(){
  [ "$(id -u)" -eq 0 ] 2>/dev/null
}

is_mounted(){
  mp="$1"
  [ -r /proc/mounts ] || return 1
  grep -q " $mp " /proc/mounts 2>/dev/null
}

need_dir(){
  [ -d "$1" ] || die "diretório não existe: $1"
}

safe_target(){
  t="$1"
  [ -n "$t" ] || die "TARGET vazio"
  case "$t" in
    /) die "recusado: TARGET não pode ser /" ;;
  esac
  # normaliza sem barras finais
  while [ "${t%/}" != "$t" ]; do t="${t%/}"; done
  echo "$t"
}

mount_one(){
  # $1=type $2=src $3=target $4=opts(optional)
  fstype="$1"; src="$2"; tgt="$3"; opts="${4:-}"
  mkdir -p "$tgt"
  if is_mounted "$tgt"; then
    return 0
  fi
  if [ -n "$opts" ]; then
    mount -t "$fstype" -o "$opts" "$src" "$tgt"
  else
    mount -t "$fstype" "$src" "$tgt"
  fi
}

bind_one(){
  # $1=src $2=target
  src="$1"; tgt="$2"
  mkdir -p "$tgt"
  if is_mounted "$tgt"; then
    return 0
  fi
  mount --bind "$src" "$tgt" 2>/dev/null || mount -o bind "$src" "$tgt"
}

mount_chroot(){
  target="$1"

  # pseudo-fs
  mount_one proc proc "$target/proc"
  mount_one sysfs sysfs "$target/sys"
  # /dev: prefer bind (se host tem devtmpfs) para compatibilidade
  bind_one /dev "$target/dev"
  mount_one devpts devpts "$target/dev/pts"
  mount_one tmpfs tmpfs "$target/run" "mode=0755"
  mount_one tmpfs tmpfs "$target/tmp" "mode=1777"

  # DNS (opcional, útil para downloads no chroot)
  if [ -f /etc/resolv.conf ]; then
    mkdir -p "$target/etc"
    if [ ! -e "$target/etc/resolv.conf" ]; then
      cp -f /etc/resolv.conf "$target/etc/resolv.conf" 2>/dev/null || true
    fi
  fi
}

umount_chroot(){
  target="$1"
  # desmonta em ordem reversa; ignora falhas
  for mp in "$target/dev/pts" "$target/dev" "$target/run" "$target/tmp" "$target/proc" "$target/sys"; do
    if is_mounted "$mp"; then
      umount "$mp" 2>/dev/null || umount -l "$mp" 2>/dev/null || true
    fi
  done
}

cmd="${1:-}"
[ -n "$cmd" ] || die "uso: chroot-pkg.sh <enter|pkg|shell|umount> <TARGET> ..."

target="$(safe_target "${2:-}")"
need_dir "$target"
is_root || die "precisa ser root"

case "$cmd" in
  enter)
    shift 2
    mount_chroot "$target"
    if [ "${1:-}" = "--" ]; then shift; fi
    if [ "$#" -gt 0 ]; then
      exec chroot "$target" "$@"
    else
      exec chroot "$target" /bin/sh
    fi
    ;;
  shell)
    mount_chroot "$target"
    exec chroot "$target" /bin/sh
    ;;
  pkg)
    shift 2
    mount_chroot "$target"
    [ -x "$target/sbin/pkg" ] || die "pkg não encontrado/executável em $target/sbin/pkg"
    exec chroot "$target" /sbin/pkg "$@"
    ;;
  umount)
    umount_chroot "$target"
    ;;
  *)
    die "comando inválido: $cmd"
    ;;
esac
