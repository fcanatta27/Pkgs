#!/bin/sh
# grub-snapshots.sh — gera entradas de GRUB para snapshots btrfs do @root (POSIX)
#
# Objetivo:
# - listar snapshots em <TOP>/.snapshots
# - gerar menuentries em /boot/grub/custom.cfg (ou arquivo indicado)
# - cada entrada aponta rootflags=subvol=.snapshots/<snapshot>
#
# Requisitos:
# - btrfs
# - acesso ao /boot e ao arquivo grub
#
# Uso:
#   tools/grub-snapshots.sh --device /dev/XXX --top /mnt/btrfs \
#     --uuid XXXX-XXXX --kernel /boot/vmlinuz --initrd /boot/initramfs.img \
#     --out /boot/grub/custom.cfg --limit 20 --extra "ro rootwait"
#
# Observação:
# - Em sistemas com múltiplos kernels, gere para o kernel desejado.
#
set -eu

die(){ echo "Erro: $*" >&2; exit 1; }
note(){ echo "==> $*" >&2; }
need(){ command -v "$1" >/dev/null 2>&1 || die "comando necessário não encontrado: $1"; }

DEVICE=""
TOP="/mnt/btrfs"
UUID=""
KERNEL="/boot/vmlinuz"
INITRD="/boot/initramfs.img"
OUT="/boot/grub/custom.cfg"
LIMIT=20
EXTRA="ro rootwait"
TITLE_PREFIX="Snapshot"

mounted_here(){
  mp="$1"
  grep -q " $mp " /proc/mounts 2>/dev/null
}

mount_top(){
  mkdir -p "$TOP"
  if mounted_here "$TOP"; then
    return 0
  fi
  mount -t btrfs "$DEVICE" "$TOP"
  trap 'umount_top' EXIT
}

umount_top(){
  if mounted_here "$TOP"; then
    umount "$TOP" 2>/dev/null || umount -l "$TOP" 2>/dev/null || true
  fi
}

while [ $# -gt 0 ]; do
  case "$1" in
    --device) DEVICE="${2:-}"; shift 2 ;;
    --top) TOP="${2:-}"; shift 2 ;;
    --uuid) UUID="${2:-}"; shift 2 ;;
    --kernel) KERNEL="${2:-}"; shift 2 ;;
    --initrd) INITRD="${2:-}"; shift 2 ;;
    --out) OUT="${2:-}"; shift 2 ;;
    --limit) LIMIT="${2:-}"; shift 2 ;;
    --extra) EXTRA="${2:-}"; shift 2 ;;
    --title-prefix) TITLE_PREFIX="${2:-}"; shift 2 ;;
    -h|--help)
      cat <<EOF
Uso:
  $0 --device /dev/XXX --top /mnt/btrfs --uuid UUID --kernel /boot/vmlinuz --initrd /boot/initramfs.img \
     --out /boot/grub/custom.cfg --limit 20 --extra "ro rootwait"
EOF
      exit 0
      ;;
    *) die "opção inválida: $1" ;;
  esac
done

need mount
need umount
need btrfs

[ -b "$DEVICE" ] || die "device inválido: $DEVICE"
[ -n "$UUID" ] || die "--uuid é obrigatório (para root=UUID=...)"
[ -f "$KERNEL" ] || die "kernel não encontrado: $KERNEL"
[ -f "$INITRD" ] || die "initrd não encontrado: $INITRD"

case "$LIMIT" in ''|*[!0-9]*) die "--limit deve ser número" ;; esac
[ "$LIMIT" -ge 1 ] || die "--limit deve ser >= 1"

mount_top

SNAPS="$TOP/.snapshots"
[ -d "$SNAPS" ] || die "não existe: $SNAPS"

# lista snapshots de @root (filtra)
list_rel="$(btrfs subvolume list -o "$SNAPS" 2>/dev/null | awk '{print $NF}' | sed 's#^\./##' | sort -r)"

tmp="$(mktemp -t grubshots.XXXXXX)"
trap 'rm -f "$tmp"' EXIT

count=0
for rel in $list_rel; do
  name="$(basename "$rel")"
  case "$name" in
    *@root*|@root* ) ;;
    *) continue ;;
  esac
  case "$name" in
    *@etc*|@var*|*stage* ) continue ;;
  esac
  echo "$rel" >> "$tmp"
  count=$((count+1))
  [ "$count" -ge "$LIMIT" ] && break
done

note "Escrevendo: $OUT"
mkdir -p "$(dirname "$OUT")"
{
  echo "# Autogerado por tools/grub-snapshots.sh em $(date)"
  echo ""
  while IFS= read -r rel; do
    [ -n "$rel" ] || continue
    title="${TITLE_PREFIX}: $rel"
    echo "menuentry '$title' {"
    echo "  linux $KERNEL root=UUID=$UUID rootfstype=btrfs rootflags=subvol=.snapshots/$rel $EXTRA"
    echo "  initrd $INITRD"
    echo "}"
    echo ""
  done < "$tmp"
} > "$OUT"

note "OK. Rode update-grub/grub-mkconfig conforme seu fluxo de boot."
