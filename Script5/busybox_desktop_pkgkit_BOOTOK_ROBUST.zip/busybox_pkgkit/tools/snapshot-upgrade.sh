#!/bin/sh
# snapshot-upgrade.sh — snapshot + upgrade seguro (btrfs) usando pkgkit + revdep
#
# Suporta layouts:
# (A) simple: root rw em /
# (B) immutable: subvols separados @root (ro), @etc (rw), @var (rw)
#
# Modo immutable (resumo):
# - cria snapshots pré-upgrade
# - cria staging rw (snapshot de @root) em .snapshots/
# - monta staging e monta @etc/@var dentro do staging
# - aplica upgrades via pkg dentro do staging
# - roda revdep report no staging
# - imprime caminho do staging para promoção via tools/promote-root.sh
#
# Uso (simple):
#   tools/snapshot-upgrade.sh --mode simple --mount / --pkgs /repo/updates
#
# Uso (immutable):
#   tools/snapshot-upgrade.sh --mode immutable --device /dev/XXX --top /mnt/btrfs \
#     --root-subvol @root --etc-subvol @etc --var-subvol @var --pkgs /repo/updates
#
# Dica:
# - Use nomes de pacotes/arquivos ordenados para controlar a ordem do upgrade.
#
set -eu

die(){ echo "Erro: $*" >&2; exit 1; }
note(){ echo "==> $*" >&2; }
need(){ command -v "$1" >/dev/null 2>&1 || die "comando necessário não encontrado: $1"; }
is_root(){ [ "$(id -u)" -eq 0 ] 2>/dev/null; }

MODE="simple"
MOUNTPOINT="/"
PKGDIR=""
INSTALL_LIST=""

# immutable-specific
DEVICE=""
TOP="/mnt/btrfs"
ROOT_SUBVOL="@root"
ETC_SUBVOL="@etc"
VAR_SUBVOL="@var"

usage(){
  cat <<EOF
Uso:
  $0 --mode simple --mount / --pkgs /repo/updates
  $0 --mode simple --mount / --install a.pkg.xz b.pkg.xz

  $0 --mode immutable --device /dev/XXX --top /mnt/btrfs \
     --root-subvol @root --etc-subvol @etc --var-subvol @var --pkgs /repo/updates
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --mode) MODE="${2:-}"; shift 2 ;;
    --mount) MOUNTPOINT="${2:-}"; shift 2 ;;
    --pkgs) PKGDIR="${2:-}"; shift 2 ;;
    --install) shift; INSTALL_LIST="$*"; break ;;
    --device) DEVICE="${2:-}"; shift 2 ;;
    --top) TOP="${2:-}"; shift 2 ;;
    --root-subvol) ROOT_SUBVOL="${2:-}"; shift 2 ;;
    --etc-subvol) ETC_SUBVOL="${2:-}"; shift 2 ;;
    --var-subvol) VAR_SUBVOL="${2:-}"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) die "opção inválida: $1" ;;
  esac
done

is_root || die "precisa ser root"
need btrfs
need mount
need umount
need chroot
need pkg
need revdep

ts="$(date +%Y%m%d-%H%M%S)"

do_install_host(){
  if [ -n "$INSTALL_LIST" ]; then
    note "Instalando lista explícita (host)..."
    # shellcheck disable=SC2086
    pkg install $INSTALL_LIST
    return 0
  fi
  [ -n "$PKGDIR" ] || die "informe --pkgs <dir> ou --install <pkgs...>"
  [ -d "$PKGDIR" ] || die "diretório não existe: $PKGDIR"
  note "Instalando pacotes do diretório: $PKGDIR"
  for p in "$PKGDIR"/*.pkg.xz; do
    [ -f "$p" ] || continue
    pkg install "$p"
  done
}

mounted_here(){
  mp="$1"
  grep -q " $mp " /proc/mounts 2>/dev/null
}

mount_top(){
  mkdir -p "$TOP"
  if mounted_here "$TOP"; then
    return 0
  fi
  mount -t btrfs "$DEVICE" "$TOP"
}

umount_top(){
  if mounted_here "$TOP"; then
    umount "$TOP" 2>/dev/null || umount -l "$TOP" 2>/dev/null || true
  fi
}

simple_mode(){
  [ -d "$MOUNTPOINT" ] || die "mount inválido: $MOUNTPOINT"

  snap_dir="$MOUNTPOINT/.snapshots"
  mkdir -p "$snap_dir"
  snap_name="root-pre-upgrade-$ts"
  snap_path="$snap_dir/$snap_name"

  note "Criando snapshot (ro) do root montado em $MOUNTPOINT: $snap_path"
  btrfs subvolume snapshot -r "$MOUNTPOINT" "$snap_path"

  note "Aplicando upgrades..."
  do_install_host

  note "Auditoria pós-upgrade (revdep report)..."
  revdep report || true

  note "Upgrade concluído. Snapshot criado em: $snap_path"
}

immutable_mode(){
  [ -n "$DEVICE" ] || die "modo immutable requer --device"
  [ -b "$DEVICE" ] || die "device inválido: $DEVICE"
  mount_top
  trap 'umount_top' EXIT

  snaps=".snapshots"
  mkdir -p "$TOP/$snaps"

  root_snap_rel="$snaps/${ROOT_SUBVOL}-ro-pre-$ts"
  etc_snap_rel="$snaps/${ETC_SUBVOL}-rw-pre-$ts"
  var_snap_rel="$snaps/${VAR_SUBVOL}-rw-pre-$ts"
  stage_rel="$snaps/${ROOT_SUBVOL}-stage-$ts"

  note "Criando snapshot ro de $ROOT_SUBVOL -> $root_snap_rel"
  btrfs subvolume snapshot -r "$TOP/$ROOT_SUBVOL" "$TOP/$root_snap_rel"

  if [ -d "$TOP/$ETC_SUBVOL" ]; then
    note "Criando snapshot rw de $ETC_SUBVOL -> $etc_snap_rel"
    btrfs subvolume snapshot "$TOP/$ETC_SUBVOL" "$TOP/$etc_snap_rel"
  fi
  if [ -d "$TOP/$VAR_SUBVOL" ]; then
    note "Criando snapshot rw de $VAR_SUBVOL -> $var_snap_rel"
    btrfs subvolume snapshot "$TOP/$VAR_SUBVOL" "$TOP/$var_snap_rel"
  fi

  note "Criando staging RW (snapshot de $ROOT_SUBVOL) -> $stage_rel"
  btrfs subvolume snapshot "$TOP/$ROOT_SUBVOL" "$TOP/$stage_rel"

  STAGEMNT="/mnt/stage"
  mkdir -p "$STAGEMNT"
  if ! mounted_here "$STAGEMNT"; then
    mount -t btrfs -o "subvol=$stage_rel" "$DEVICE" "$STAGEMNT"
  fi

  mkdir -p "$STAGEMNT/etc" "$STAGEMNT/var"
  if [ -d "$TOP/$ETC_SUBVOL" ]; then
    mount -t btrfs -o "subvol=$ETC_SUBVOL" "$DEVICE" "$STAGEMNT/etc"
  fi
  if [ -d "$TOP/$VAR_SUBVOL" ]; then
    mount -t btrfs -o "subvol=$VAR_SUBVOL" "$DEVICE" "$STAGEMNT/var"
  fi

  note "Aplicando upgrades dentro do staging (chroot)..."
  if [ -n "$INSTALL_LIST" ]; then
    # shellcheck disable=SC2086
    chroot "$STAGEMNT" /sbin/pkg install $INSTALL_LIST
  else
    [ -n "$PKGDIR" ] || die "informe --pkgs ou --install"
    for p in "$PKGDIR"/*.pkg.xz; do
      [ -f "$p" ] || continue
      chroot "$STAGEMNT" /sbin/pkg install "$p"
    done
  fi

  note "Rodando revdep report no staging..."
  chroot "$STAGEMNT" /bin/sh -c "PATH=/bin:/sbin:/usr/bin:/usr/sbin revdep report" || true

  note "Desmontando staging..."
  umount "$STAGEMNT/etc" 2>/dev/null || true
  umount "$STAGEMNT/var" 2>/dev/null || true
  umount "$STAGEMNT" 2>/dev/null || umount -l "$STAGEMNT" 2>/dev/null || true

  note "Upgrade aplicado no staging: $stage_rel"
  note "Promova com:"
  echo "  tools/promote-root.sh --device $DEVICE --top $TOP --staging $stage_rel" >&2
}

case "$MODE" in
  simple) simple_mode ;;
  immutable) immutable_mode ;;
  *) die "mode inválido: $MODE" ;;
esac
