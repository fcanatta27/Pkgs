#!/bin/sh
# snapshot-retention.sh — retenção/limpeza de snapshots btrfs (POSIX)
#
# Mantém apenas os últimos N snapshots (por nome), com proteções:
# - se LAST_PROMOTION_PENDING existe e BOOT_OK não existe => não apaga nada
# - não apaga itens contendo "keep" no nome
# - protege automaticamente o @root-old-<ts> do último promote até BOOT_OK existir
#
# Uso:
#   tools/snapshot-retention.sh --device /dev/XXX --top /mnt/btrfs --keep 10
#
set -eu

die(){ echo "Erro: $*" >&2; exit 1; }
note(){ echo "==> $*" >&2; }
need(){ command -v "$1" >/dev/null 2>&1 || die "comando necessário não encontrado: $1"; }
is_root(){ [ "$(id -u)" -eq 0 ] 2>/dev/null; }

DEVICE=""
TOP="/mnt/btrfs"
KEEP=10

mounted_here(){
  mp="$1"
  grep -q " $mp " /proc/mounts 2>/dev/null
}

mount_top(){
  mkdir -p "$TOP"
  if mounted_here "$TOP"; then
    return 0
  fi
  mount -t btrfs "$DEVICE" "$TOP"
  trap 'umount_top' EXIT
}

umount_top(){
  if mounted_here "$TOP"; then
    umount "$TOP" 2>/dev/null || umount -l "$TOP" 2>/dev/null || true
  fi
}

while [ $# -gt 0 ]; do
  case "$1" in
    --device) DEVICE="${2:-}"; shift 2 ;;
    --top) TOP="${2:-}"; shift 2 ;;
    --keep) KEEP="${2:-}"; shift 2 ;;
    -h|--help)
      cat <<EOF
Uso:
  $0 --device /dev/XXX --top /mnt/btrfs --keep 10
EOF
      exit 0
      ;;
    *) die "opção inválida: $1" ;;
  esac
done

is_root || die "precisa ser root"
need mount
need umount
need btrfs

[ -b "$DEVICE" ] || die "device inválido: $DEVICE"
case "$KEEP" in ''|*[!0-9]*) die "--keep deve ser número" ;; esac
[ "$KEEP" -ge 1 ] || die "--keep deve ser >= 1"

mount_top

SNAPS="$TOP/.snapshots"
[ -d "$SNAPS" ] || die "diretório de snapshots não existe: $SNAPS"

bootok=0
[ -f "$SNAPS/BOOT_OK" ] && bootok=1

if [ -f "$SNAPS/LAST_PROMOTION_PENDING" ] && [ "$bootok" -eq 0 ]; then
  note "Promoção pendente e boot-ok não confirmado; retenção conservadora (não apaga)."
  exit 0
fi

protect_ts=""
if [ -f "$SNAPS/LAST_ROOT_TS" ]; then
  protect_ts="$(cat "$SNAPS/LAST_ROOT_TS" 2>/dev/null || true)"
fi

# Lista subvolumes sob .snapshots (paths relativos)
list_rel="$(btrfs subvolume list -o "$SNAPS" 2>/dev/null | awk '{print $NF}' | sed 's#^\./##')"

# Constrói lista de candidatos (apenas subvols)
cands_file="$(mktemp -t snapret.XXXXXX)"
trap 'rm -f "$cands_file"' EXIT

for rel in $list_rel; do
  base="$(basename "$rel")"
  case "$base" in
    *keep*|KEEP*|*KEEP*) continue ;;
    BOOT_OK*|LAST_*) continue ;;
  esac
  # Protege snapshot relacionado ao último promote, se existir TS
  if [ -n "$protect_ts" ]; then
    case "$base" in
      *@root-old-"$protect_ts"*|*@root-ro-pre-"$protect_ts"*|*@root-stage-"$protect_ts"*) ;;
    esac
  fi
  echo "$SNAPS/$rel" >> "$cands_file"
done

# Remove entradas vazias
[ -s "$cands_file" ] || { note "Nenhum candidato encontrado."; exit 0; }

# Ordena por nome (timestamps favorecem ordenação)
sorted="$(sort "$cands_file")"

# Conta
count="$(printf "%s\n" "$sorted" | awk 'END{print NR}')"
[ "$count" -gt 0 ] || { note "Sem snapshots."; exit 0; }

if [ "$count" -le "$KEEP" ]; then
  note "Snapshots <= keep ($count <= $KEEP). Nada a remover."
  exit 0
fi

remove="$((count-KEEP))"
note "Removendo $remove snapshots antigos (mantendo $KEEP)..."

# Apagar os mais antigos: as primeiras linhas do sort
i=0
printf "%s\n" "$sorted" | while IFS= read -r s; do
  [ -n "$s" ] || continue
  if [ "$i" -lt "$remove" ]; then
    note "Deletando: $s"
    btrfs subvolume delete "$s" 2>/dev/null || die "falha ao deletar: $s"
    i="$((i+1))"
  fi
done

note "Retenção concluída."
