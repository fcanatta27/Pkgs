# CHECKLIST DE PRODUÇÃO — DESKTOP DIÁRIO

## Boot
- root=UUID configurado
- initramfs testado
- fallback funcional

## Sistema
- revdep report limpo
- sem arquivos órfãos
- permissões corretas

## Desktop
- Xorg/Wayland inicia
- áudio e vídeo funcionam
- navegador funcional

Sistema pronto para uso diário.
