# BOOK — Construindo e Mantendo um Desktop Minimalista com BusyBox + pkgkit

Este livro é um guia completo, com foco em:
- instalar e manter seu sistema como OS principal (dev, jogos, mídia)
- manter o sistema enxuto (sem bloat)
- boot confiável (init + initramfs)
- upgrades seguros (snapshots, auditoria)
- troubleshooting prático

## Sumário
1. Visão geral do sistema
2. Estrutura do projeto
3. Boot: initramfs e init
4. Filesystem e layout recomendado (Btrfs imutável)
5. Sistema de pacotes (pkg)
6. Auditoria e integridade (revdep)
7. Perfis: desktop mínimo, laptop, gaming
8. Upgrades seguros e rollback
9. Hardening prático
10. Troubleshooting por sintomas
11. Rotina de manutenção

---

## 1. Visão geral
Você possui quatro pilares:
- BusyBox: base do userspace inicial, init, core utils
- init scripts: serviços essenciais em ordem previsível
- pkg: instala/remove/upgrade pacotes com DB em /var/lib/pkg/db
- revdep: auditoria (deps reversas, libs faltantes, arquivos órfãos)

Objetivo: previsibilidade e controle.

---

## 2. Estrutura do projeto (o que importa)
- `pkgkit/sbin/pkg`: gerenciador de pacotes
- `tools/`: scripts operacionais (chroot, mkinitramfs, backup, snapshot-upgrade)
- `initramfs/init`: init do initramfs (root=UUID, btrfs subvol, autoroot opcional)
- `busybox_rootfs/`: rootfs base com /etc/inittab e init scripts
- `PROFILES_*.md`: listas e decisões de pacote

---

## 3. Boot (initramfs) — como funciona de verdade
### 3.1 Fluxo do initramfs
1) monta pseudo-fs: /proc /sys /dev /run
2) lê /proc/cmdline:
   - root= (UUID/LABEL/ /dev/...)
   - rootfstype=
   - rootflags= (inclui subvol/subvolid para btrfs)
3) espera o dispositivo aparecer (rootwait/rootdelay)
4) monta o root em /newroot
5) switch_root para /sbin/init do root real
6) se falhar: shell de resgate

### 3.2 Exemplo de cmdline (Btrfs subvol)
```
root=UUID=XXXX rootfstype=btrfs rootflags=subvol=@root,ro rootwait
```

### 3.3 Autoroot (fallback)
Se `root=` não vier definido, o initramfs pode tentar montar partições em ro e procurar `/sbin/init`.
Use apenas em ambiente controlado. Para laptop/desktop principal, prefira `root=UUID`.

### 3.4 Problemas comuns no boot
- “root não aparece”
  - driver do storage não está no kernel
  - initramfs sem mdev/devtmpfs
- “UUID não resolve”
  - initramfs sem blkid
- “btrfs subvol falha”
  - subvol não existe ou rootflags errado
  - fallback subvolid=5 pode ajudar para diagnosticar

---

## 4. Layout recomendado (imutável) — como e por quê
Leia também `IMMUTABLE_MODE.md`.

Resumo:
- `@root` em ro: sistema
- `@etc` rw: configurações
- `@var` rw: estado (db do pkg, logs, cache controlado)
- upgrades via staging + promoção

---

## 5. pkg — como não quebrar seu sistema
### 5.1 Conceitos
- `DEPS=` é lista de pacotes (runtime)
- DB local: /var/lib/pkg/db/<pacote>/{files,meta}
- remoção é bloqueada se for dependência de outro (reverse deps)

### 5.2 Regras práticas
- não misture upgrades grandes sem snapshot
- atualize por camadas (libc -> toolchain -> mesa -> desktop)
- após cada upgrade: `revdep report`

---

## 6. revdep — auditoria que pega problemas reais
Comandos principais:
- `revdep report`: visão geral
- `revdep missing-libs --all`: ELFs com libs faltantes (mais importante)
- `revdep unowned-files`: sujeira fora do pkg (instalações manuais)
- `revdep dep-closure <pkg>`: fecho de deps para montar bundles/initramfs

---

## 7. Perfis (mínimo, laptop, gaming)
- Desktop mínimo: veja `PROFILES_DESKTOP_MIN.md`
- Laptop: veja `PROFILES_LAPTOP.md`
- Gaming limpo: veja `PROFILES_GAMING.md`

Recomendação: comece no desktop mínimo, estabilize, depois adicione gaming.

---

## 8. Upgrades seguros (imutável e simples)
### 8.1 Simples (root rw)
- snapshot ro
- pkg install
- revdep report

### 8.2 Imutável
Use `tools/snapshot-upgrade.sh --mode immutable` para:
- snapshot ro do @root
- staging rw para upgrade
- validação
- promoção manual do staging para virar o novo @root

---

## 9. Hardening prático
Leia `HARDENING_DESKTOP.md`.
O foco é:
- sysctl básicos (kptr_restrict etc.)
- seccomp e namespaces quando fizer sentido
- sandbox leve com bwrap para apps expostos (Steam/browser)

---

## 10. Troubleshooting por sintomas
### “X não inicia”
- confirme drm/kms e permissões em /dev/dri
- confirme mesa e libs: `revdep missing-libs --all`
- rode Xorg com log e revise /var/log

### “Sem áudio”
- pipewire e wireplumber rodando?
- ALSA detecta placa?
- `revdep report` para libs faltantes

### “Steam não abre”
- geralmente é multilib ou libs gtk/nss
- prefira modo sandbox ou use runtime 32-bit se decidir multilib

### “Upgrade quebrou tudo”
- btrfs rollback para snapshot
- ou reinstale versões anteriores via pkg no initramfs

---

## 11. Rotina mínima de manutenção
Semanal:
- backup de /etc e /var/lib/pkg
- `revdep report`
- update do navegador e stack gráfica se necessário

Mensal:
- atualizar toolchain se realmente necessário
- limpar snapshots antigos

---

Fim.


## Ferramentas adicionais (imutável)

### Promoção atômica do staging
Use `tools/promote-root.sh` para promover um staging (gerado pelo snapshot-upgrade.sh modo immutable) para virar o novo `@root`.

Exemplo:
```sh
tools/promote-root.sh --device /dev/nvme0n1p2 --top /mnt/btrfs --staging .snapshots/@root-stage-YYYYMMDD-HHMMSS
# reboot
# após boot ok:
tools/promote-root.sh boot-ok
```

### Retenção/limpeza de snapshots
Use `tools/snapshot-retention.sh` para manter apenas os últimos N snapshots.

Exemplo:
```sh
tools/snapshot-retention.sh --device /dev/nvme0n1p2 --top /mnt/btrfs --keep 10
```


## GRUB: entradas de snapshots (rollback pelo menu)
Use `tools/grub-snapshots.sh` para gerar entradas em `/boot/grub/custom.cfg` apontando para snapshots btrfs.

Exemplo:
```sh
tools/grub-snapshots.sh --device /dev/nvme0n1p2 --top /mnt/btrfs \
  --uuid XXXX-XXXX --kernel /boot/vmlinuz --initrd /boot/initramfs.img \
  --out /boot/grub/custom.cfg --limit 20 --extra "ro rootwait"
```


## Produção: BOOT_OK automático e self-heal

- BOOT_OK automático: watcher no `rcS` marca `BOOT_OK` quando TTY login ou DM estiverem ativos.
- Self-heal: se essenciais faltarem e houver repositório local, instala via `pkg`.


### BOOT_OK mais robusto
O gancho de boot suporta `BOOT_OK_MODE` (tty/x/either) e validações:
- TTY: /dev/tty1 + getty + /bin/sh + /etc/passwd
- X: socket X11 (`/tmp/.X11-unix/X0`) + Xorg (pidfile ou processo)
