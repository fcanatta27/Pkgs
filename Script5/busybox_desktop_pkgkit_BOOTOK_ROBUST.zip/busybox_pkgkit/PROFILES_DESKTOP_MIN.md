# PROFILE — DESKTOP MÍNIMO RECOMENDADO

Objetivo: desktop funcional, estável e leve para uso diário
(desenvolvimento, navegação, mídia, jogos leves).

## Pacotes base
- filesystem
- busybox
- init
- pkg
- ca-certificates
- tzdata

## Runtime base
- musl ou glibc
- zlib
- zstd
- libgcc
- libstdc++

## Gráficos
- mesa-min
- libdrm
- libglvnd
- libx11
- libxcb
- libxext
- libxrandr
- libxinerama
- libxpresent
- libxshmfence

## Display server (escolha UM)
### Xorg
- xorg-server-min
- xinit
- xrandr
- xsetroot

### Wayland
- wayland-core
- wayland-protocols
- libxkbcommon-core
- wlroots (opcional)

## Áudio/Vídeo
- pipewire-min
- wireplumber
- alsa-lib

## Fontes
- fontconfig
- freetype
- noto-fonts-core

## Utilitários essenciais
- bash (opcional)
- nano ou vim
- less
- procps
- iproute2
- util-linux

## Navegador
- firefox-min

## Desenvolvimento
- git
- gcc
- make
- pkg-config
- cmake (opcional)

Este conjunto fornece um desktop completo sem bloat.
