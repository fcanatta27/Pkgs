#!/bin/sh
# build-gcc.sh — template POSIX para construir e empacotar GCC com pkgkit
#
# Objetivo:
# - Baixar o source do GCC (opcional)
# - Verificar MD5 (obrigatório quando SRC_MD5 for definido)
# - Construir out-of-tree
# - Instalar em staging (DESTDIR)
# - Empacotar com /sbin/pkg (pkgkit)
#
# Requer (host de build):
# - sh, tar, make, sed, awk
# - um compilador C funcional no host (gcc/clang)
# - dependências de build do GCC: gmp, mpfr, mpc, zlib, bison, flex (varia por versão)
# - wget OU curl para download (se usar SRC_URL)
# - md5sum (busybox md5sum serve)
#
set -eu

# ====== CONFIGURÁVEL ======
PKGNAME="gcc"
PKGVER="${PKGVER:-14.2.0}"

# Fonte
SRC_TAR="${SRC_TAR:-gcc-${PKGVER}.tar.xz}"
SRCDIR="${SRCDIR:-gcc-${PKGVER}}"
SRC_URL="${SRC_URL:-}"      # ex.: https://ftp.gnu.org/gnu/gcc/gcc-14.2.0/gcc-14.2.0.tar.xz
SRC_MD5="${SRC_MD5:-}"      # ex.: <md5 do tarball>  (recomendado)

# Tripla alvo e sysroot:
# - Para cross: TARGET_TRIPLE e SYSROOT devem apontar para seu rootfs alvo (sysroot).
# - Para build nativo dentro de chroot do alvo: SYSROOT="/" e TARGET_TRIPLE vazio (ou tripla nativa).
TARGET_TRIPLE="${TARGET_TRIPLE:-x86_64-linux-musl}"
SYSROOT="${SYSROOT:-/opt/your-sysroot}"   # AJUSTE

# Prefixo final no sistema alvo:
PREFIX="${PREFIX:-/usr}"

# Diretórios
WORK="${WORK:-/tmp/build}"
SRCWORK="$WORK/src"
BUILDDIR="$WORK/build-gcc"
STAGE="$WORK/pkgroot-gcc"     # DESTDIR para empacotar
REPO="${REPO:-/repo}"         # repositório local de .pkg.xz (opcional)

# Dependências declaradas no seu pkg (ajuste conforme seu sistema)
DEPS="${DEPS:-musl zlib gmp mpfr mpc}"

# Opções
JOBS="${JOBS:-$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)}"
CFLAGS="${CFLAGS:--O2 -pipe}"
CXXFLAGS="${CXXFLAGS:--O2 -pipe}"
LANGS="${LANGS:-c,c++}"

# Hardening útil (ajustável)
ENABLE_PIE="${ENABLE_PIE:-1}"
ENABLE_SSP="${ENABLE_SSP:-1}"

die(){ echo "Erro: $*" >&2; exit 1; }
msg(){ echo "==> $*" >&2; }

need(){ command -v "$1" >/dev/null 2>&1 || die "comando ausente: $1"; }

fetch(){
  # $1=url $2=out
  url="$1"; out="$2"
  [ -n "$url" ] || die "SRC_URL vazio"
  if command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  elif command -v curl >/dev/null 2>&1; then
    curl -L -o "$out" "$url"
  else
    die "precisa de wget ou curl para download"
  fi
}

check_md5(){
  # $1=file $2=md5
  f="$1"; want="$2"
  [ -r "$f" ] || die "arquivo não encontrado para md5: $f"
  [ -n "$want" ] || return 0
  command -v md5sum >/dev/null 2>&1 || die "md5sum ausente (instale busybox md5sum ou coreutils)"
  got="$(md5sum "$f" | awk '{print $1}')"
  [ "$got" = "$want" ] || die "md5 inválido: esperado $want, obtido $got"
}

clean_dir(){
  d="$1"
  [ -n "$d" ] || return 0
  rm -rf "$d" 2>/dev/null || true
  mkdir -p "$d"
}

# ====== CHECAGENS ======
need tar
need make
need sed
need awk
need pkg

mkdir -p "$WORK" "$SRCWORK" "$REPO"

# ====== BAIXAR SOURCE (opcional) ======
if [ ! -r "$SRC_TAR" ]; then
  [ -n "$SRC_URL" ] || die "source não encontrado: $SRC_TAR (defina SRC_URL para baixar)"
  msg "Baixando: $SRC_URL -> $SRC_TAR"
  fetch "$SRC_URL" "$SRC_TAR"
fi

# ====== VERIFICAR MD5 (se definido) ======
if [ -n "$SRC_MD5" ]; then
  msg "Verificando MD5"
  check_md5 "$SRC_TAR" "$SRC_MD5"
else
  msg "Aviso: SRC_MD5 não definido; sem verificação de integridade"
fi

# ====== EXTRAÇÃO DETERMINÍSTICA ======
msg "Extraindo fontes em $SRCWORK"
clean_dir "$SRCWORK"
tar -xf "$SRC_TAR" -C "$SRCWORK"
[ -d "$SRCWORK/$SRCDIR" ] || die "diretório de fonte esperado não existe: $SRCWORK/$SRCDIR"

# ====== BUILD OUT-OF-TREE ======
msg "Preparando build dir"
clean_dir "$BUILDDIR"
clean_dir "$STAGE"

cd "$BUILDDIR"

# ====== CONFIGURE ======
msg "Configurando GCC $PKGVER"
cfg_flags=""
[ "$ENABLE_PIE" -eq 1 ] && cfg_flags="$cfg_flags --enable-default-pie"
[ "$ENABLE_SSP" -eq 1 ] && cfg_flags="$cfg_flags --enable-default-ssp"

# Nota: Para build estritamente nativo em chroot do target, você pode omitir --target e --with-sysroot.
"$SRCWORK/$SRCDIR/configure" \
  --target="$TARGET_TRIPLE" \
  --prefix="$PREFIX" \
  --with-sysroot="$SYSROOT" \
  --disable-multilib \
  --disable-nls \
  --enable-languages="$LANGS" \
  --with-system-zlib \
  $cfg_flags \
  CFLAGS="$CFLAGS" \
  CXXFLAGS="$CXXFLAGS"

# ====== BUILD ======
msg "Compilando (jobs=$JOBS)"
make -j"$JOBS"

# ====== INSTALL (DESTDIR) ======
msg "Instalando em staging (DESTDIR=$STAGE)"
make DESTDIR="$STAGE" install

# ====== LIMPEZA DO PACOTE ======
msg "Limpando staging"
rm -rf "$STAGE/$PREFIX/share/info" 2>/dev/null || true
rm -rf "$STAGE/$PREFIX/share/man" 2>/dev/null || true
rm -rf "$STAGE/$PREFIX/share/doc" 2>/dev/null || true
find "$STAGE" -name '*.la' -delete 2>/dev/null || true

# ====== EMPACOTAMENTO COM pkg ======
msg "Empacotando com pkg"
pkg pack \
  --name "$PKGNAME" \
  --version "$PKGVER" \
  --root "$STAGE" \
  --deps "$DEPS" \
  --desc "GNU Compiler Collection ($LANGS) para $TARGET_TRIPLE" \
  --strip

PKGOUT="/var/cache/pkg/pkgs/${PKGNAME}-${PKGVER}.pkg.xz"
if [ -r "$PKGOUT" ]; then
  msg "Copiando pacote para repo: $REPO"
  cp -f "$PKGOUT" "$REPO/" || true
  echo "OK: $REPO/$(basename "$PKGOUT")"
else
  msg "Pacote criado no cache padrão; verifique /var/cache/pkg/pkgs"
fi
