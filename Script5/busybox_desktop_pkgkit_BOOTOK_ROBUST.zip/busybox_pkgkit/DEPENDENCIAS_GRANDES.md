# Dependências reais — pacotes grandes (lista prática)

Estas listas são **referências de runtime** (não build-deps) para você definir `DEPS=` no meta dos seus pacotes.
Elas refletem o que distribuições de referência costumam exigir e o que, na prática, é necessário para as funções mais comuns.

Observação importante:
- As páginas de pacotes usadas como base são do Arch Linux (glibc e, em alguns casos, systemd). Você pode substituir:
  - `glibc` -> sua libc (musl ou glibc)
  - `systemd-libs/libudev` -> `eudev` (libudev) em sistemas sem systemd

## Mesa (OpenGL/Vulkan userspace)
Base (mínimo típico):
- libc, `zlib`, `zstd`
- `libdrm`
- `libelf`
- `libglvnd`
- X11: `libx11`, `libxcb`, `libxext`, `libxxf86vm`, `libxshmfence`
- `llvm-libs` (quando Mesa usa LLVM para drivers)
- Wayland: `wayland` (para suporte Wayland/EGL)
- `expat`
- `spirv-tools` (alguns caminhos de Vulkan/spirv)

Opcional/funções:
- `lm_sensors` (monitoramento)
- `vulkan-icd-loader` (se você separar loader)

Fonte: dependências do pacote mesa no Arch. citeturn0search0

## Xorg (servidor X)
Para um Xorg funcional (mínimo típico):
- libc
- `libdrm`
- `libepoxy`
- `libpciaccess`
- `pixman`
- `libx11`, `libxau`, `libxdmcp`
- `libxfont2`
- `xkeyboard-config`, `xorg-xkbcomp`, `xorg-setxkbmap`
- `libunwind` (em algumas builds)
- `libtirpc` (em algumas builds)
- `dbus` (recomendado)

Fonte: pacote xorg-server e xorg-server-common no Arch. citeturn0search3turn0search11

## Wayland (core)
Wayland (biblioteca/protocolo base) normalmente precisa de:
- libc
- `expat`
- `libffi`
- `libxml2`
- cursores padrão (`default-cursors`)

Fonte: pacote wayland no Arch. citeturn1search1

Wayland-protocols:
- pacote de arquivos de protocolo; tipicamente requerido por compositores/toolkits.
Fonte: wayland-protocols no Arch. citeturn1search2

## libxkbcommon (teclas/keyboard)
Base:
- libc
- `libxml2`
- `xkeyboard-config`
Opcionais:
- `wayland` e `libxkbcommon-x11` (para ferramentas interativas específicas)

Fonte: libxkbcommon no Arch. citeturn1search3

## PipeWire (áudio/vídeo)
PipeWire mínimo prático em desktop:
- libc
- `dbus`
- `glib2`
- `alsa-lib`
- `libudev` (em sistemas sem systemd, use `eudev` para fornecer libudev)
- `ncurses` e `readline` (dependendo da build)

Opcionais por feature:
- bluetooth (`bluez-libs`)
- gstreamer plugin (`gst-plugin-pipewire`)

Fonte: pacote pipewire no Arch. citeturn0search2

## FFmpeg
FFmpeg tende a ter dependências extensas devido a codecs/hwaccel.
Sugestão: empacotar em variantes:
- `ffmpeg-core` (mínimo) e `ffmpeg-full` (tudo)

Fonte: dependências do pacote ffmpeg no Arch. citeturn1search0

## Firefox
Firefox normalmente depende de:
- `gtk3`/toolkit
- `nss`, `nspr`
- `alsa-lib`
- `ffmpeg`
- `mesa`/`libglvnd`
- `fontconfig`, `freetype`
- `dbus`

Fonte: pacote firefox no Arch. citeturn0search9
