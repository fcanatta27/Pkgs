# GUIA — KERNEL MÍNIMO RECOMENDADO (DESKTOP + GAMING)

Este guia lista opções de kernel recomendadas para um desktop moderno, mantendo o kernel enxuto.
O objetivo é: boot confiável, GPU/DRM, áudio, input, rede, namespaces/seccomp para hardening.

## 1. Base e boot
- CONFIG_64BIT=y (se x86_64)
- CONFIG_BLK_DEV_INITRD=y
- CONFIG_DEVTMPFS=y
- CONFIG_DEVTMPFS_MOUNT=y (opcional; initramfs também monta)
- CONFIG_TMPFS=y
- CONFIG_TMPFS_POSIX_ACL=y (opcional)

## 2. Filesystems
Escolha o que você usa (não habilite tudo):
### ext4
- CONFIG_EXT4_FS=y

### btrfs (se usar subvol/snapshot)
- CONFIG_BTRFS_FS=y
- CONFIG_BTRFS_FS_POSIX_ACL=y (opcional)

## 3. Device/Storage (comuns)
- CONFIG_SCSI=y (muitos discos passam por SCSI layer)
- CONFIG_BLK_DEV_NVME=y (se NVMe)
- CONFIG_ATA=y (se SATA)
- CONFIG_MD=y (somente se usar RAID/LVM; caso contrário, não)

## 4. Rede
- CONFIG_NET=y
- CONFIG_INET=y
- CONFIG_IPV6=y (opcional, mas recomendado)
- driver da sua NIC (Intel e1000e/igc/iwlwifi etc.)

## 5. Input
- CONFIG_INPUT=y
- CONFIG_INPUT_EVDEV=y
- CONFIG_HID=y
- CONFIG_HID_GENERIC=y
- drivers do seu touchpad/teclado se necessário

## 6. Gráficos (DRM/KMS)
- CONFIG_DRM=y
- CONFIG_DRM_KMS_HELPER=y
- driver da sua GPU:
  - Intel: CONFIG_DRM_I915=y
  - AMD:   CONFIG_DRM_AMDGPU=y
  - Nvidia: normalmente via módulo externo (não entra aqui)

## 7. Som
- CONFIG_SND=y
- CONFIG_SND_PCM=y
- CONFIG_SND_TIMER=y
- ALSA SoC apenas se necessário (laptops específicos)
- driver HDA comum:
  - CONFIG_SND_HDA_INTEL=y
  - CONFIG_SND_HDA_CODEC_REALTEK=y (exemplo; depende do hardware)

## 8. Energia (laptop)
- CONFIG_ACPI=y
- CONFIG_ACPI_BATTERY=y
- CONFIG_ACPI_BUTTON=y
- CONFIG_CPU_FREQ=y
- driver cpufreq do seu CPU (intel_pstate/amd_pstate)
- CONFIG_SUSPEND=y
- CONFIG_HIBERNATION=y (opcional)

## 9. Segurança/hardening (baixo custo)
- CONFIG_SECCOMP=y
- CONFIG_SECCOMP_FILTER=y
- CONFIG_NAMESPACES=y
- CONFIG_USER_NS=y (se você quiser sandbox sem root; veja hardening)
- CONFIG_PID_NS=y
- CONFIG_NET_NS=y
- CONFIG_UTS_NS=y
- CONFIG_IPC_NS=y
- CONFIG_CGROUPS=y (muitos runtimes/sandbox usam)
- CONFIG_CGROUP_BPF=y (opcional)
- CONFIG_BPF=y (necessário para algumas ferramentas; endureça no sysctl)
- CONFIG_BPF_SYSCALL=y (opcional; se habilitar, desabilite unprivileged BPF via sysctl)

## 10. Redução de superfície (recomendação)
Desabilite se não usa:
- bluetooth (CONFIG_BT)
- wifi (se desktop cabeado)
- webcams (CONFIG_MEDIA_SUPPORT)
- firewire, thunderbolt, etc.

## 11. Checklist de validação
- boot com initramfs
- GPU acelera (mesa/vulkan)
- áudio funciona (pipewire/alsa)
- suspend/resume (laptop)
