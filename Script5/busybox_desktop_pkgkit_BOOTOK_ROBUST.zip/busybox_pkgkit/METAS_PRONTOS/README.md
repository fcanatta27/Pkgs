# Metas prontos (templates)

Arquivos `.meta` aqui são **templates** para você copiar para `.pkgmeta/meta` durante o `pkg pack`.

Notas:
- Substitua `VERSION_AQUI` pela versão real.
- Ajuste nomes de pacotes para coincidir com os nomes que você usa no seu repositório.
- `DEPS=` é lista separada por espaços (formato exato esperado pelo pkgkit).

Sugestão de convenção:
- Use variantes com sufixo `-min` / `-full` / `-core` / `-llvm` para reduzir ambiguidade.
