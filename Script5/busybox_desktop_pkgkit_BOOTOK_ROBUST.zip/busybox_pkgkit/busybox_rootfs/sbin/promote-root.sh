#!/bin/sh
# promote-root.sh — promove um staging btrfs para virar @root com segurança (POSIX)
#
# Inclui:
# - trava (flock se disponível; fallback lockdir)
# - checagens de device/top/staging
# - promoção por rename atômico dentro do mesmo filesystem
# - comando `boot-ok` para confirmar boot e liberar retenção
#
# Uso:
#   tools/promote-root.sh --device /dev/XXX --top /mnt/btrfs --staging .snapshots/@root-stage-...
#   tools/promote-root.sh boot-ok   # grava BOOT_OK no top-level (.snapshots)
#
set -eu

die(){ echo "Erro: $*" >&2; exit 1; }
note(){ echo "==> $*" >&2; }
need(){ command -v "$1" >/dev/null 2>&1 || die "comando necessário não encontrado: $1"; }
is_root(){ [ "$(id -u)" -eq 0 ] 2>/dev/null; }

LOCK="/run/pkgkit-promote.lock"
LOCKDIR="/run/pkgkit-promote.lockdir"

lock_acquire(){
  if command -v flock >/dev/null 2>&1; then
    exec 9>"$LOCK"
    flock -n 9 || die "lock ocupado: já existe promoção em andamento"
    return 0
  fi
  if mkdir "$LOCKDIR" 2>/dev/null; then
    trap 'rmdir "$LOCKDIR" 2>/dev/null || true' EXIT
    return 0
  fi
  die "lock ocupado: já existe promoção em andamento"
}

mounted_here(){
  mp="$1"
  grep -q " $mp " /proc/mounts 2>/dev/null
}

mount_top(){
  mkdir -p "$TOP"
  if mounted_here "$TOP"; then
    return 0
  fi
  mount -t btrfs "$DEVICE" "$TOP"
  trap 'umount_top' EXIT
}

umount_top(){
  if mounted_here "$TOP"; then
    umount "$TOP" 2>/dev/null || umount -l "$TOP" 2>/dev/null || true
  fi
}

validate_root_tree(){
  d="$1"
  [ -d "$d" ] || return 1
  [ -x "$d/sbin/init" ] || return 1
  return 0
}

resolve_path(){
  p="$1"
  case "$p" in
    /*) echo "$p" ;;
    *) echo "$TOP/$p" ;;
  esac
}

# Detecta device btrfs atual (para boot-ok automático)
detect_btrfs_device(){
  # tenta achar a entrada btrfs do root
  awk '$3=="btrfs"{print $1; exit}' /proc/mounts 2>/dev/null || true
}

mark_boot_ok(){
  # Monta top-level e grava BOOT_OK em <top>/.snapshots, liberando retenção.
  is_root || die "precisa ser root"
  need mount
  need umount

  dev="$(detect_btrfs_device)"
  [ -n "$dev" ] || die "não foi possível detectar device btrfs via /proc/mounts"
  TOPMNT="/mnt/btrfs-top"
  mkdir -p "$TOPMNT"
  if ! mounted_here "$TOPMNT"; then
    mount -t btrfs -o subvolid=5 "$dev" "$TOPMNT"
  fi
  mkdir -p "$TOPMNT/.snapshots"
  echo "ok $(date)" > "$TOPMNT/.snapshots/BOOT_OK"
  rm -f "$TOPMNT/.snapshots/LAST_PROMOTION_PENDING" 2>/dev/null || true
  umount "$TOPMNT" 2>/dev/null || umount -l "$TOPMNT" 2>/dev/null || true
  note "BOOT_OK gravado."
  exit 0
}

cmd="${1:-}"
if [ "$cmd" = "boot-ok" ]; then
  mark_boot_ok
fi

DEVICE=""
TOP="/mnt/btrfs"
STAGING=""

while [ $# -gt 0 ]; do
  case "$1" in
    --device) DEVICE="${2:-}"; shift 2 ;;
    --top) TOP="${2:-}"; shift 2 ;;
    --staging) STAGING="${2:-}"; shift 2 ;;
    -h|--help)
      cat <<EOF
Uso:
  $0 --device /dev/XXX --top /mnt/btrfs --staging <path>
  $0 boot-ok
EOF
      exit 0
      ;;
    *) die "opção inválida: $1" ;;
  esac
done

is_root || die "precisa ser root"
need mount
need umount
need btrfs

[ -b "$DEVICE" ] || die "device inválido: $DEVICE"
[ -n "$STAGING" ] || die "--staging é obrigatório"

lock_acquire
mount_top

ts="$(date +%Y%m%d-%H%M%S)"
stg_abs="$(resolve_path "$STAGING")"
root_abs="$TOP/@root"

[ -d "$root_abs" ] || die "subvol @root não encontrado: $root_abs"
[ -d "$stg_abs" ] || die "staging não encontrado: $stg_abs"

# Checagem real: @root montado RW em algum mountpoint?
if awk '$3=="btrfs" && $4 ~ /rw/ && $0 ~ /subvol=@root/ {found=1} END{exit !found}' /proc/mounts 2>/dev/null; then
  die "@root está montado RW; recusei para evitar inconsistência"
fi

note "Validando staging..."
validate_root_tree "$stg_abs" || die "staging inválido: falta /sbin/init executável"

note "Promovendo staging -> @root (renomes atômicos)..."
old_abs="$TOP/@root-old-$ts"
[ ! -e "$old_abs" ] || die "já existe: $old_abs"

mv "$root_abs" "$old_abs"
mv "$stg_abs" "$root_abs"

mkdir -p "$TOP/.snapshots"
echo "pending $(date)" > "$TOP/.snapshots/LAST_PROMOTION_PENDING" 2>/dev/null || true
echo "$ts" > "$TOP/.snapshots/LAST_ROOT_TS" 2>/dev/null || true

note "Promoção concluída."
note "Antigo @root: $old_abs"
note "Novo @root:   $root_abs"
note "Após boot OK, rode: tools/promote-root.sh boot-ok"
