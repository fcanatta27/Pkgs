# BUILD_TUTORIAL — SISTEMA DO ZERO

1. Compilar toolchain
2. Criar rootfs mínimo
3. Instalar pkg
4. Criar pacotes base
5. Montar initramfs
6. Instalar desktop mínimo
7. Validar com revdep

Sistema simples, previsível e estável.
