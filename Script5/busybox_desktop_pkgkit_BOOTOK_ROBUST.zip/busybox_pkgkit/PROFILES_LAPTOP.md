# PROFILE — LAPTOP

Objetivo: economia de energia, estabilidade e conforto.

## Energia
- acpid
- tlp (opcional)
- powertop (diagnóstico)

## Backlight
- xbacklight ou brightnessctl

## Suspend / Resume
- elogind ou seatd
- kernel com CONFIG_SUSPEND

## Rede
- wpa_supplicant
- dhcpcd

## Recomendado
- root=UUID (não autoroot)
- modo imutável
- swap zram

Laptop pronto para uso diário.
