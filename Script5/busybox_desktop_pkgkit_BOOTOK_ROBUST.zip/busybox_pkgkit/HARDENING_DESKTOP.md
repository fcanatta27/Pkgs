# HARDENING — DESKTOP (seccomp + namespaces leves)

Objetivo: elevar segurança do desktop sem inflar o sistema.

## 1. Sysctl recomendado (baixo risco)
Crie `/etc/sysctl.d/99-hardening.conf`:

- kernel.kptr_restrict=2
- kernel.dmesg_restrict=1
- fs.protected_symlinks=1
- fs.protected_hardlinks=1
- kernel.unprivileged_bpf_disabled=1
- net.core.bpf_jit_harden=2 (se disponível)

## 2. Namespaces leves (sandbox)
Para sandboxes sem root, você pode habilitar USER namespaces:
- kernel.unprivileged_userns_clone=1 (quando disponível)
Risco: aumenta superfície. Se preferir segurança máxima, deixe desabilitado e use sandbox com privilégios controlados.

## 3. seccomp
seccomp depende de suporte no kernel:
- CONFIG_SECCOMP=y
- CONFIG_SECCOMP_FILTER=y

Uso prático:
- browsers e runtimes modernos costumam usar seccomp quando disponível.

## 4. Sandbox recomendado (mínimo)
### bubblewrap (bwrap)
- pequeno, direto, usa namespaces
- útil para isolar Steam/Proton e apps expostos

Exemplo conceitual:
- bind /home
- bind /tmp
- bind /usr (ro)
- dev mínimo

Obs: isso é opcional; não é necessário para um sistema mínimo, mas é o melhor custo/benefício para hardening sem bloat.

## 5. Permissões e práticas
- use usuário não-root
- limite serviços no boot
- evite daemons que não usa
- mantenha /etc sob controle (pkg + revisão de .pkgnew)

## 6. Auditoria contínua (revdep)
- revdep report
- revdep unowned-files
- revdep missing-libs --all

Isso detecta problemas reais e evita "drift" do sistema.
