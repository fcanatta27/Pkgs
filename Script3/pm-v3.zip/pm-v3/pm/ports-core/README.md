Ports Core (Toolchain) Repository
================================

Este repositório fornece um conjunto "core" de ports focado em toolchain e dependências mínimas,
para uso com o `pm` (POSIX shell).

Conteúdo:
- core.world: ordem sugerida de bootstrap (libs -> headers -> binutils -> gcc -> glibc)
- ports/core/*: definições de ports.

Uso (exemplo):
  export PM_PORTS=/usr/src/ports-core/ports
  pm build core.world
  pm install core.world

Observações:
- glibc requer headers do kernel em /usr/include (instale linux-headers primeiro).
- gcc aqui é focado em c/c++, sem multilib e sem isl (Graphite) para reduzir dependências.
