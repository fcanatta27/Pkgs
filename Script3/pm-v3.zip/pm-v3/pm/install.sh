#!/bin/sh
set -eu
ROOT="${1:-/}"
install -d "$ROOT/usr/sbin" "$ROOT/etc/pm/repos.d" "$ROOT/var/lib/pm" "$ROOT/var/cache/pm" "$ROOT/var/log/pm"
install -m 0755 "$(dirname "$0")/usr/sbin/pm" "$ROOT/usr/sbin/pm"
[ -f "$ROOT/etc/pm/config" ] || install -m 0644 "$(dirname "$0")/etc/pm/config" "$ROOT/etc/pm/config"
[ -f "$ROOT/etc/pm/repos.d/local.repo" ] || install -m 0644 "$(dirname "$0")/etc/pm/repos.d/local.repo" "$ROOT/etc/pm/repos.d/local.repo"
echo "Installed posix-pm into $ROOT"
