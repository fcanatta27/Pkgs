# posix-pm (v2)

A simple, robust **POSIX /bin/sh** package manager designed for the posix-rootfs-builder system.

## Model
- Build in a temporary directory under `/tmp` (mktemp).
- Install into **DESTDIR** for packaging.
- Create a package tarball with a manifest.
- Install into `/` by extracting the package tarball.
- Maintain an on-disk database for:
  - installed packages and versions
  - file ownership (which package owns which file)
  - dependency graph
  - build/install logs
- Cache:
  - sources in `/var/cache/pm/distfiles`
  - built packages in `/var/cache/pm/packages`
  - build trees in `/var/cache/pm/build` (optional retention)

## Directories
- `/etc/pm/`: config + repos
- `/var/lib/pm/`: database (installed + owners + state)
- `/var/cache/pm/`: distfiles + packages + build
- `/var/log/pm/`: logs

## Repo / port format
A repo is a directory containing ports:
- `<repo>/ports/<name>/version`
- `<repo>/ports/<name>/sources`
- `<repo>/ports/<name>/checksums` (sha256 + filename)
- `<repo>/ports/<name>/deps` (one dependency name per line; `#` comments ok)
- `<repo>/ports/<name>/build` (POSIX sh; defines `pkg_prepare/pkg_build/pkg_install`)

## Safety / protections
- Refuses to remove protected directories/paths: `/`, `/etc`, `/bin`, `/sbin`, `/lib*`, `/usr`, `/var`, `/dev`, `/proc`, `/sys`, `/run`, `/boot`.
- Removal deletes **only** files listed in the package manifest and owned by the target package.
- Prevents removing a package that is required by others unless `--force` is used.
- Detects dependency cycles during resolution.

License: MIT

## New in v2
- Optional `pkg_post_install()` hook executed after install.
- `--dry-run` planning mode.
- Colored, readable output for search/info/install.
- Full tutorial in `docs/TUTORIAL.md`.
