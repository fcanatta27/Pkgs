# posix-pm tutorial (v2)

This guide assumes you are inside your newly built system (or chroot) and have a ports repository available.

## 1) Install posix-pm

Extract the tarball and run:

```sh
tar -xzf posix-pm-v2.tar.gz
cd posix-pm-v2
./install.sh /
```

This installs:
- `/usr/sbin/pm`
- `/etc/pm/config`
- `/etc/pm/repos.d/local.repo`
and creates state directories under `/var/lib/pm`, `/var/cache/pm`, `/var/log/pm`.

## 2) Configure repositories

Edit `/etc/pm/repos.d/local.repo`:

```ini
type=dir
name=local
path=/usr/src/ports
```

Your repository should look like:

```
/usr/src/ports/
  ports/
    zlib/
      version
      sources
      checksums
      deps
      build
```

You can add more `.repo` files under `/etc/pm/repos.d/`.

## 3) Port format essentials

Every port must install into `$DESTDIR`:

- Good:
  - `make DESTDIR="$DESTDIR" install`
  - `ninja -C build install DESTDIR="$DESTDIR"`
- Bad:
  - writing directly to `/usr`, `/etc`, or `/`

### Optional post-install hook

A port `build` script may define:

```sh
pkg_post_install() {
  # runs AFTER the package is installed into /
  :
}
```

It runs during `pm install` after extraction/registration. Use it only for safe actions
like creating users/groups, updating caches, or enabling services by creating links.

## 4) Common workflow

### Search
```sh
pm search zlib
```

### Inspect a package
```sh
pm info zlib
```

### Dry-run install plan
```sh
pm -n install wlroots
# or
pm --dry-run install wlroots
```

### Build and install
```sh
pm install zlib
```

Packages are cached in:
- sources: `/var/cache/pm/distfiles`
- packages: `/var/cache/pm/packages`

### List installed
```sh
pm list
```

### Upgrade
```sh
pm upgrade --all
```

### Verify files still exist
```sh
pm verify zlib
```

### Find file owner
```sh
pm owns /usr/lib/libz.so.1
```

### Remove safely
```sh
pm remove zlib
```

If other packages depend on it, removal is refused unless forced:
```sh
pm remove --force zlib
```

## 5) Troubleshooting

- Build logs: `/var/log/pm/build/<pkg>.log`
- Install logs: `/var/log/pm/install/<pkg>.log`
- Remove logs: `/var/log/pm/remove/<pkg>.log`

If a build fails, check:
- `checksums` match
- required host build tools exist (gcc/make or meson/ninja for some ports)
- dependencies are declared in `deps`

## 6) Reproducibility & cleanliness

- Do not embed host paths in ports.
- Prefer `/usr` prefixes.
- Keep post-install hooks idempotent.
