# Port format

A port directory must contain:
- version
- sources
- checksums (sha256 + filename)
- build (POSIX sh defining pkg_prepare/pkg_build/pkg_install)

Optional:
- deps (one dependency name per line)

Rules:
- build MUST install into $DESTDIR (never directly into /).
- Any hardcoded host paths are forbidden; use standard prefixes (/usr, /etc, /var).
