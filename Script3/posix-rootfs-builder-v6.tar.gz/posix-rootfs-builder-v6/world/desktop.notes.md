# Desktop profile notes

`world/base.world` stays minimal and stable. Desktop stacks evolve quickly and are maintained as an optional layer.

This repository revision provides the **profile contract** (world file + notes + build driver script). Implementing
the full desktop ports is a large iteration (mesa/drivers in particular are hardware-dependent). The recommended
approach is to add those ports under `ports/desktop/` incrementally.


## Implemented minimal stack (v6)
This repo includes ports for the minimal Wayland stack under `ports/desktop/`.

## Enabling services
Seeded service scripts: `/etc/init.d/service/seatd` and `/etc/init.d/service/pipewire` (pipewire is usually per-user; this is a minimal system instance).
