# POSIX RootFS Builder v6 (x86_64 + glibc + BusyBox init + SysV-style runlevels + eudev)

This version evolves the project to be **more automated and “init-complete”**, while keeping
the build system **POSIX /bin/sh**.

## Highlights (v6)
- **BusyBox init** as PID 1, with:
  - **SysV-style runlevels**: `S`, `2`, `3` (and `0`/`6` for shutdown/reboot hooks)
  - `rc` dispatcher to execute `K*` then `S*` scripts in `/etc/rc?.d`
  - `telinit` support (BusyBox) via `/sbin/telinit` if enabled in BusyBox config
- **Service framework**:
  - Service scripts live in `/etc/init.d/service/<name>` with `start|stop|restart|status`
  - A unified helper `/lib/rc/common` handles pidfiles, logging, and start/stop semantics
  - `/sbin/service <name> <action>` convenience wrapper
- **rc.local** included and called from rcS for user customization.
- Desktop-proof base packages (same as v3): `eudev`, `util-linux`, `shadow`, plus crypto/download stack.

## Build
```sh
./tools/doctor.sh
./tools/update-checksums.sh
./tools/stageA-build.sh
sudo ./tools/stageB-finalize-and-package.sh
```

## Runlevel model
- Default runlevel is configured in `/etc/default/runlevel` (default: `3`)
- Boot:
  - BusyBox init runs `/etc/init.d/rc S`
  - `rc` then runs `/etc/init.d/rcS` (mounts, udev coldplug) and then transitions to runlevel 3
- Runlevels:
  - `S`: early boot / essential base
  - `2`: multi-user (no “desktop” assumptions)
  - `3`: multi-user + “desktop-ready” services (still minimal here; you can extend)

## Determinism notes
- The builder uses a controlled environment (LC_ALL, TZ, umask, SOURCE_DATE_EPOCH).
- Packaging uses sorted file lists and normalized mtimes/owners where supported by tar.

License: MIT


## Fixes in v6-fixed
- Ensure `/lib64` exists for glibc loader on x86_64.
- Remove non-portable fractional sleep in rc helpers.
- Improve udev/syslog service robustness.


## Purity model

This project is designed to be **runtime-clean** and **install-clean**, while remaining **host-built**:

- **Runtime-clean**: The resulting rootfs does not depend on the host filesystem at runtime. After build, the system runs
  using only binaries and libraries present inside the rootfs.
- **Install-clean**: Packages are installed into a per-port `DESTDIR` and then merged into the rootfs. No target files are
  installed into the host.
- **Host-built (non-hermetic build)**: Compilation uses the host toolchain (e.g., `gcc`, `ld`, `ar`). This avoids LFS-style
  bootstrap complexity. The host can influence *what is built* (feature autodetection), but it should not pollute *what is installed*.

Practical implications:
- You can treat the output as a clean “base image” for a package manager to take over.
- If you require hermetic / bit-for-bit reproducibility, you would need a dedicated sysroot toolchain and stricter
  feature detection controls (see the optional cross-build mode below).

### What the purity checker enforces

`tools/purity-check.sh` runs objective checks against a built `out/rootfs`:
- verifies ELF **interpreter** points to target paths (e.g., `/lib64/ld-linux-x86-64.so.2`);
- scans ELF `RPATH/RUNPATH` for host paths;
- searches text/config for common host path leaks (e.g., `/home/`, `/usr/include`, `/mnt/`, `$PWD`);
- validates symlinks do not escape the rootfs (no `..` traversal to host).

It does not try to guarantee full hermeticity; it detects the most common real-world leak vectors.



## Optional desktop profile (keeps base immutable)

The base world (`world/base.world`) remains minimal and stable. Desktop functionality is layered via an optional profile:

- `world/desktop.world`: desktop stack packages (dbus, elogind/seatd, pipewire, wayland, compositor, etc.)
- `world/desktop.notes.md`: rationale and implementation notes

This keeps Stage A “base” unchanged and allows you to iterate on desktop concerns independently.



## Optional cross-build mode (without changing the base design)

The default build is native (host toolchain). An optional cross mode is provided as a **design** + environment contract:
- set `CROSS_PREFIX` (e.g., `x86_64-linux-gnu-`), `SYSROOT`, and `TARGET_TRIPLE`
- the builder exports `CC`, `CXX`, `AR`, `RANLIB`, `STRIP`, `LD` accordingly
- ports that honor standard Autoconf variables will build against the sysroot

See `docs/cross-build.md` for the operational model and limitations.


## Desktop ports (implemented in ports/desktop)

This release implements a minimal Wayland stack as desktop profile (ports in `ports/desktop/`).
Host build deps are assumed (meson, ninja, python3, pkgconf).

### GPU target selection (mesa)
Set `MESA_GALLIUM_DRIVERS` and optionally `MESA_VULKAN_DRIVERS` before building desktop.
