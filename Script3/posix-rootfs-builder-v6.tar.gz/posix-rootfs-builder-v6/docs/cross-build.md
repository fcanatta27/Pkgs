# Optional cross-build mode (design)

This project is host-built by default. Cross-building is optional and does not change the base design.

## Environment contract
Set these variables before running Stage A:

- TARGET_TRIPLE (example: x86_64-linux-gnu)
- CROSS_PREFIX (example: x86_64-linux-gnu-)
- SYSROOT (example: /opt/sysroots/x86_64-linux-gnu)

The builder exports tool variables:

- CC=${CROSS_PREFIX}gcc --sysroot=$SYSROOT
- CXX=${CROSS_PREFIX}g++ --sysroot=$SYSROOT
- AR=${CROSS_PREFIX}ar
- RANLIB=${CROSS_PREFIX}ranlib
- STRIP=${CROSS_PREFIX}strip
- LD=${CROSS_PREFIX}ld

Ports that follow Autoconf conventions will generally work.

## Limitations
- Some packages require cross patches (especially libc and device stacks).
- True hermetic builds require more controls than this provides.

## Recommended workflow
1) Build base natively to validate ports.
2) Introduce cross mode for a subset once your sysroot toolchain works.
3) Run tools/purity-check.sh on the resulting rootfs.
