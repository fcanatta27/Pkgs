# Desktop profile implementation

Desktop ports live under `ports/desktop/` and are built by `tools/build-desktop.sh`.

## Host build dependencies
- meson
- ninja
- python3
- pkgconf

These are treated like gcc/binutils: host-provided, not installed into the target rootfs.

## Target runtime
- base world provides libc, init, udev, etc.
