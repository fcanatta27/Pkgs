#!/bin/sh
# POSIX static audit: look for common portability pitfalls and missing executables.
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail=0

check_exec() {
  f="$1"
  [ -f "$f" ] || return 0
  # if it starts with #! ensure executable bit
  head -n 1 "$f" | grep -q '^#!' || return 0
  [ -x "$f" ] || { echo "NOT EXECUTABLE: $f"; fail=1; }
}

# Check scripts
find "$ROOT" -type f -name "*.sh" -o -path "$ROOT/rootfs-seed/etc/init.d/*" -o -path "$ROOT/rootfs-seed/sbin/*" -o -path "$ROOT/ports/base/*/build" | while read -r f; do
  check_exec "$f"
done

# Grep for bashisms we know about
if grep -RIn -- 'sed -i' "$ROOT" >/dev/null 2>&1; then
  echo "FOUND sed -i (non-POSIX):"
  grep -RIn -- 'sed -i' "$ROOT" || true
  fail=1
fi
if grep -RIn -- 'sleep 0\.' "$ROOT" >/dev/null 2>&1; then
  echo "FOUND fractional sleep (may be non-POSIX):"
  grep -RIn -- 'sleep 0\.' "$ROOT" || true
  fail=1
fi

exit "$fail"

[ -x "$ROOT/tools/purity-check.sh" ] || { echo "MISSING: tools/purity-check.sh"; exit 1; }

[ -d "$ROOT/ports/desktop" ] || { echo "MISSING: ports/desktop"; exit 1; }
