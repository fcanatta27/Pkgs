#!/bin/sh
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
. "$ROOT/tools/config.sh"
. "$ROOT/tools/lib/common.sh"
. "$ROOT/tools/lib/builder.sh"

ensure_rootfs_layout "$ROOTFS"

note "Seeding base configs + init framework"
# Copy rootfs seed tree
( cd "$ROOT/rootfs-seed" && tar -cf - . ) | ( cd "$ROOTFS" && tar -xf - )

# Base configs
cat >"$ROOTFS/etc/hostname" <<'EOF'
minibase
EOF
cat >"$ROOTFS/etc/hosts" <<'EOF'
127.0.0.1 localhost minibase
::1       localhost
EOF
cat >"$ROOTFS/etc/resolv.conf" <<'EOF'
# Managed by DHCP (udhcpc) or user.
EOF
cat >"$ROOTFS/etc/fstab" <<'EOF'
proc  /proc proc  nosuid,noexec,nodev 0 0
sysfs /sys  sysfs nosuid,noexec,nodev 0 0
tmpfs /run  tmpfs nosuid,nodev,mode=0755 0 0
tmpfs /tmp  tmpfs nosuid,nodev,mode=1777 0 0
devtmpfs /dev devtmpfs mode=0755,nosuid 0 0
EOF
cat >"$ROOTFS/etc/default/runlevel" <<'EOF'
3
EOF

# Minimal accounts
cat >"$ROOTFS/etc/passwd" <<'EOF'
root:x:0:0:root:/root:/bin/sh
EOF
cat >"$ROOTFS/etc/group" <<'EOF'
root:x:0:
tty:x:5:
adm:x:4:
EOF
: >"$ROOTFS/etc/shadow" || true
chmod 600 "$ROOTFS/etc/shadow" 2>/dev/null || true

# BusyBox init configuration (runlevel dispatch + watchdog)
cat >"$ROOTFS/etc/inittab" <<'EOF'
::sysinit:/etc/init.d/rc S
::respawn:/sbin/getty -L 115200 tty1 vt100
::respawn:/sbin/init-monitor
::ctrlaltdel:/sbin/reboot
::shutdown:/etc/init.d/rcK
EOF

# udhcpc script
mkdir -p "$ROOTFS/usr/share/udhcpc"
cat >"$ROOTFS/usr/share/udhcpc/default.script" <<'EOF'
#!/bin/sh
[ -n "$interface" ] || exit 0
case "$1" in
  deconfig) ip addr flush dev "$interface" 2>/dev/null || true ;;
  renew|bound)
    ip addr flush dev "$interface" 2>/dev/null || true
    ip addr add "$ip/$mask" dev "$interface" 2>/dev/null || true
    [ -n "$router" ] && ip route replace default via "$router" dev "$interface" 2>/dev/null || true
    if [ -n "$dns" ]; then
      : > /etc/resolv.conf
      for s in $dns; do echo "nameserver $s" >> /etc/resolv.conf; done
    fi
    ;;
esac
exit 0
EOF
chmod +x "$ROOTFS/usr/share/udhcpc/default.script"

note "Building world"
[ -f "$WORLD_FILE" ] || die "world file not found: $WORLD_FILE"
while IFS= read -r line; do
  case "$line" in ""|\#*) continue ;; esac
  build_port "$line"
done <"$WORLD_FILE"

note "Stage A complete. Rootfs: $ROOTFS"
