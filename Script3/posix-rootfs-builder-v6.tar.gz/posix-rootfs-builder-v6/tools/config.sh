#!/bin/sh
: "${ARCH:=x86_64}"
: "${TARGET:=x86_64-linux-gnu}"

: "${OUT:=$PWD/out}"
: "${ROOTFS:=$OUT/rootfs}"
: "${DISTFILES:=$OUT/distfiles}"
: "${BUILDDIR:=$OUT/build}"
: "${LOGDIR:=$OUT/logs}"
: "${PKGDIR:=$OUT/pkg}"
: "${WORLD_FILE:=$PWD/world/base.world}"

: "${JOBS:=}"
: "${CFLAGS:=-O2 -pipe}"
: "${CXXFLAGS:=-O2 -pipe}"
: "${LDFLAGS:=}"

: "${SOURCE_DATE_EPOCH:=1704067200}"
: "${SUDO:=sudo}"

export ARCH TARGET OUT ROOTFS DISTFILES BUILDDIR LOGDIR PKGDIR WORLD_FILE JOBS CFLAGS CXXFLAGS LDFLAGS SOURCE_DATE_EPOCH SUDO


# Optional cross-build knobs (empty by default)
: "${TARGET_TRIPLE:=${TARGET}}"
: "${CROSS_PREFIX:=}"
: "${SYSROOT:=}"

if [ -n "$CROSS_PREFIX" ] && [ -n "$SYSROOT" ]; then
  : "${CC:=${CROSS_PREFIX}gcc --sysroot=$SYSROOT}"
  : "${CXX:=${CROSS_PREFIX}g++ --sysroot=$SYSROOT}"
  : "${AR:=${CROSS_PREFIX}ar}"
  : "${RANLIB:=${CROSS_PREFIX}ranlib}"
  : "${STRIP:=${CROSS_PREFIX}strip}"
  : "${LD:=${CROSS_PREFIX}ld}"
else
  : "${CC:=gcc}"
  : "${CXX:=g++}"
  : "${AR:=ar}"
  : "${RANLIB:=ranlib}"
  : "${STRIP:=strip}"
  : "${LD:=ld}"
fi

export TARGET_TRIPLE CROSS_PREFIX SYSROOT CC CXX AR RANLIB STRIP LD
