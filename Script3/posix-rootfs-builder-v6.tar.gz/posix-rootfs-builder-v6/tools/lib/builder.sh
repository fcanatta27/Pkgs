#!/bin/sh
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
. "$ROOT/tools/config.sh"
. "$ROOT/tools/lib/common.sh"

need_cmd tar; need_cmd awk; need_cmd sed; need_cmd grep; need_cmd patch; need_cmd make

mkdir -p "$OUT" "$ROOTFS" "$DISTFILES" "$BUILDDIR" "$LOGDIR" "$PKGDIR"

port_path(){ printf '%s' "$ROOT/ports/base/$1"; }

load_meta(){
  port="$1"
  pdir="$(port_path "$port")"
  [ -d "$pdir" ] || die "unknown port: $port"
  VERSION="$(cat "$pdir/version")"
  SOURCE_URL="$(cat "$pdir/sources")"
  SHA256="$(awk '{print $1}' "$pdir/checksums")"
  export VERSION SOURCE_URL SHA256
}

prepare_env(){
  export LC_ALL=C TZ=UTC
  umask 022
  export MAKEFLAGS="-j$(make_jobs)"
  export CFLAGS CXXFLAGS LDFLAGS SOURCE_DATE_EPOCH
  export CC CXX AR RANLIB STRIP LD
  export ROOTFS DISTFILES BUILDDIR LOGDIR PKGDIR
}

build_port(){
  port="$1"
  load_meta "$port"
  pdir="$(port_path "$port")"
  bdir="$BUILDDIR/$port"
  src="$bdir/src"
  log="$LOGDIR/$port.log"
  tb="$DISTFILES/$(basename "$SOURCE_URL")"

  note "Building $port-$VERSION"
  mkdir -p "$bdir" "$src"
  : >"$log"

  fetch_url "$SOURCE_URL" "$tb" >>"$log" 2>&1 || die "fetch failed (see $log)"
  got="$(sha256_file "$tb")"
  [ "$SHA256" != "TODO" ] || die "$port: checksums not set; run ./tools/update-checksums.sh"
  [ "$got" = "$SHA256" ] || die "$port: checksum mismatch: expected $SHA256 got $got"

  rm -rf "$src"/*
  unpack_tarball "$tb" "$src" >>"$log" 2>&1 || die "unpack failed (see $log)"
  top="$(ls -1 "$src" | head -n 1 || true)"
  if [ -n "$top" ] && [ -d "$src/$top" ]; then SRCTREE="$src/$top"; else SRCTREE="$src"; fi
  export SRCTREE

  DESTDIR="$PKGDIR/$port"
  rm -rf "$DESTDIR"; mkdir -p "$DESTDIR"
  export DESTDIR

  prepare_env

  (
    set -eu
    . "$pdir/build"
    : "${pkg_prepare:=pkg_prepare}"
    : "${pkg_build:=pkg_build}"
    : "${pkg_install:=pkg_install}"
    $pkg_prepare
    $pkg_build
    $pkg_install
  ) >>"$log" 2>&1 || die "$port failed (see $log)"

  ensure_rootfs_layout "$ROOTFS"
  copytree "$DESTDIR" "$ROOTFS"

  note "OK: $port"
}
