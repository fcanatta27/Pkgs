#!/bin/sh
set -eu
die(){ printf '%s\n' "ERROR: $*" >&2; exit 1; }
note(){ printf '%s\n' "==> $*" >&2; }
need_cmd(){ command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"; }

sha256_file(){
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}'
  elif command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | awk '{print $1}'
  else die "sha256sum or shasum not found"
  fi
}

fetch_url(){
  url="$1"; out="$2"
  [ -f "$out" ] && return 0
  mkdir -p "$(dirname "$out")"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 -o "$out.tmp" "$url" || die "download failed: $url"
    mv "$out.tmp" "$out"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out.tmp" "$url" || die "download failed: $url"
    mv "$out.tmp" "$out"
  else
    die "curl or wget required for downloads"
  fi
}

tar_supports(){
  # tar_supports --flag
  tar --help 2>/dev/null | grep -q -- "$1"
}

unpack_tarball(){
  tb="$1"; dest="$2"; mkdir -p "$dest"
  case "$tb" in
    *.tar.gz|*.tgz) tar -xzf "$tb" -C "$dest" ;;
    *.tar.xz)       tar -xJf "$tb" -C "$dest" ;;
    *.tar.bz2)      tar -xjf "$tb" -C "$dest" ;;
    *.tar)          tar -xf "$tb" -C "$dest" ;;
    *.tar.zst)
      if tar_supports '--zstd'; then tar --zstd -xf "$tb" -C "$dest"
      else
        need_cmd zstd
        zstd -dc "$tb" | tar -xf - -C "$dest"
      fi
      ;;
    *) die "unknown archive format: $tb" ;;
  esac
}

make_jobs(){
  if [ -n "${JOBS:-}" ]; then printf '%s' "$JOBS"
  elif command -v nproc >/dev/null 2>&1; then nproc
  else printf '1'
  fi
}

copytree(){ src="$1"; dst="$2"; (cd "$src" && tar -cf - .) | (mkdir -p "$dst" && cd "$dst" && tar -xf -); }

ensure_rootfs_layout(){
  r="$1"
  mkdir -p "$r"/{bin,sbin,dev,proc,sys,run,tmp,var,root,home,boot,lib,lib64}
  mkdir -p "$r"/usr/{bin,sbin,lib,lib64,share}
  mkdir -p "$r"/etc/{init.d,network,ssl,ssl/certs,udev,udev/rules.d,default}
  mkdir -p "$r"/etc/init.d/service
  mkdir -p "$r"/etc/{rcS.d,rc2.d,rc3.d,rc0.d,rc6.d}
  mkdir -p "$r"/lib/rc
  mkdir -p "$r"/var/{log,run,lib}
  chmod 1777 "$r/tmp"
}

in_mounts(){
  mp="$1"
  [ -r /proc/mounts ] || return 1
  awk '{print $2}' /proc/mounts | grep -qx "$mp"
}
