#!/bin/sh
# tools/build-desktop.sh
# Build the optional desktop profile on top of an existing base rootfs.

set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
. "$ROOT/tools/config.sh"
. "$ROOT/tools/lib/common.sh"
. "$ROOT/tools/lib/builder.sh"

WORLD_FILE="$ROOT/world/desktop.world"
export WORLD_FILE

note "Building desktop profile using $WORLD_FILE"
note "Desktop uses host meson/ninja/python3/pkgconf."
[ -d "$ROOTFS" ] || die "Base rootfs missing at $ROOTFS. Build base first (tools/stageA-build.sh)."

while IFS= read -r line; do
  case "$line" in ""|\#*) continue ;; esac
  if [ -d "$ROOT/ports/desktop/$line" ]; then
    build_port "$line"
  elif [ -d "$ROOT/ports/base/$line" ]; then
    build_port "$line"
  else
    die "Desktop port not implemented yet: $line (create ports/desktop/$line or ports/base/$line)"
  fi
done <"$WORLD_FILE"
note "Desktop profile build complete."
