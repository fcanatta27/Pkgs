#!/bin/sh
# tools/purity-check.sh
# Objective checks for host path leaks and ELF correctness in a built rootfs.
# POSIX /bin/sh.

set -eu

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ROOTFS="${ROOTFS:-$ROOT/out/rootfs}"

fail=0
say(){ printf '%s\n' "$*" >&2; }
bad(){ say "FAIL: $*"; fail=1; }
ok(){ say "OK: $*"; }

[ -d "$ROOTFS" ] || { bad "ROOTFS not found: $ROOTFS (build first)"; exit 2; }

# 1) Symlink escape checks: reject symlinks that traverse outside (contain '..' components)
if find "$ROOTFS" -type l -print | while read -r l; do
  t="$(readlink "$l" 2>/dev/null || true)"
  case "$t" in
    *'..'*)
      printf '%s -> %s\n' "$l" "$t"
      ;;
  esac
done | grep -q .; then
  bad "Symlinks containing '..' detected (possible rootfs escape)."
else
  ok "No suspicious symlink targets containing '..'"
fi

# 2) Host path leak patterns in config-like files
patterns='(/home/|/Users/|/mnt/|/media/|/private/|/opt/|/usr/include|/usr/local|/var/tmp|/tmp/|'"$PWD"')'
if find "$ROOTFS" -type f \( -name '*.pc' -o -name '*.la' -o -name '*.conf' -o -name '*.sh' -o -name '*.service' -o -name '*.rules' -o -name '*.xml' -o -name '*.ini' -o -name '*.desktop' \) -print \
  | while read -r f; do
      grep -nE "$patterns" "$f" 2>/dev/null | sed "s|^|$f:|"
    done | grep -q .; then
  bad "Potential host path leaks found in config-like files (review output above)."
else
  ok "No host-path patterns found in config-like files"
fi

# 3) ELF checks (if readelf is available)
if command -v readelf >/dev/null 2>&1; then
  # 3a) Interpreter must be an in-rootfs path (starts with /lib or /lib64)
  if find "$ROOTFS" -type f -perm -0100 -print | while read -r f; do
      head -c 4 "$f" 2>/dev/null | grep -q "$(printf '\177ELF')" || continue
      interp="$(readelf -l "$f" 2>/dev/null | awk '/Requesting program interpreter/ {gsub(/\[|\]/,"",$NF); print $NF; exit}')"
      [ -n "$interp" ] || continue
      case "$interp" in
        /lib/*|/lib64/*) : ;;
        *) printf '%s: %s\n' "$f" "$interp" ;;
      esac
    done | grep -q .; then
    bad "ELF interpreter paths not under /lib or /lib64 detected."
  else
    ok "ELF interpreter paths look sane"
  fi

  # 3b) RPATH/RUNPATH must not point to host paths
  if find "$ROOTFS" -type f -perm -0100 -print | while read -r f; do
      head -c 4 "$f" 2>/dev/null | grep -q "$(printf '\177ELF')" || continue
      rp="$(readelf -d "$f" 2>/dev/null | awk '/RPATH|RUNPATH/ {print $0}')"
      [ -n "$rp" ] || continue
      echo "$rp" | grep -E '/home/|/Users/|/usr/local|/opt/|/mnt/|/private/' >/dev/null 2>&1 && printf '%s: %s\n' "$f" "$rp"
    done | grep -q .; then
    bad "ELF RPATH/RUNPATH contains host-like paths."
  else
    ok "No host-like paths in ELF RPATH/RUNPATH"
  fi
else
  say "WARN: readelf not found; skipping ELF interpreter/RPATH checks"
fi

# 4) .la files warning
if find "$ROOTFS" -type f -name '*.la' -print | grep -q .; then
  say "WARN: libtool .la files present; these often leak build paths and are usually safe to delete."
fi

if [ "$fail" -eq 0 ]; then
  ok "Purity check passed."
  exit 0
fi
bad "Purity check failed."
exit 1
