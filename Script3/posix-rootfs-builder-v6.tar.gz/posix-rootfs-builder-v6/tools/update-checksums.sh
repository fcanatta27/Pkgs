#!/bin/sh
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
. "$ROOT/tools/config.sh"
. "$ROOT/tools/lib/common.sh"
mkdir -p "$DISTFILES"
for pdir in "$ROOT/ports/base"/*; do
  [ -d "$pdir" ] || continue
  name="$(basename "$pdir")"
  url="$(cat "$pdir/sources")"
  file="$DISTFILES/$(basename "$url")"
  note "Fetching $name"
  fetch_url "$url" "$file"
  sum="$(sha256_file "$file")"
  printf '%s  %s\n' "$sum" "$(basename "$url")" >"$pdir/checksums"
done
note "Done. Checksums updated."
