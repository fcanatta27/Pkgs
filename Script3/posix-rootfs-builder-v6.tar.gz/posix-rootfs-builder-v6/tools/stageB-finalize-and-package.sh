#!/bin/sh
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
. "$ROOT/tools/config.sh"
. "$ROOT/tools/lib/common.sh"

ART="$OUT/artifacts"
PKGS="$ART/packages"
mkdir -p "$ART" "$PKGS"
[ -d "$ROOTFS" ] || die "ROOTFS not found; run stageA first"

if [ "$(id -u)" -ne 0 ]; then
  note "Re-running with sudo for privileged operations..."
  exec ${SUDO:-sudo} sh "$0"
fi

ensure_rootfs_layout "$ROOTFS"

note "Mounting proc/sys/dev into rootfs"
in_mounts "$ROOTFS/proc" || mount -t proc proc "$ROOTFS/proc"
in_mounts "$ROOTFS/sys"  || mount -t sysfs sys "$ROOTFS/sys"
in_mounts "$ROOTFS/dev"  || mount -t devtmpfs dev "$ROOTFS/dev" || true

[ -e "$ROOTFS/dev/null" ] || mknod -m 666 "$ROOTFS/dev/null" c 1 3 || true
[ -e "$ROOTFS/dev/console" ] || mknod -m 600 "$ROOTFS/dev/console" c 5 1 || true

note "Chroot sanity checks"
chroot "$ROOTFS" /bin/sh -eu -c '
echo "chroot OK"
command -v sh >/dev/null
command -v init >/dev/null || true
# glibc cache
if command -v ldconfig >/dev/null 2>&1; then ldconfig || true; fi
# init scripts exist
[ -x /etc/init.d/rc ] && [ -x /etc/init.d/rcS ]
'

note "Packaging per-port payloads"
for d in "$PKGDIR"/*; do
  [ -d "$d" ] || continue
  p="$(basename "$d")"
  (cd "$d" && find . -print | LC_ALL=C sort | tar -cf "$PKGS/$p.tar" -T -)
done

note "Packaging rootfs deterministically"
ROOT_TAR="$ART/rootfs.tar"
# Try to use GNU tar normalization if available; otherwise fall back to a plain tar.
if tar_supports '--mtime' && tar_supports '--numeric-owner'; then
  (cd "$ROOTFS" && find . -print | LC_ALL=C sort | tar --mtime="@${SOURCE_DATE_EPOCH}" --owner=0 --group=0 --numeric-owner -cf "$ROOT_TAR" -T -)
else
  (cd "$ROOTFS" && find . -print | LC_ALL=C sort | tar -cf "$ROOT_TAR" -T -)
fi

if command -v zstd >/dev/null 2>&1; then
  zstd -q -f "$ROOT_TAR" -o "$ART/rootfs.tar.zst"
  rm -f "$ROOT_TAR"
elif command -v xz >/dev/null 2>&1; then
  xz -c -9 "$ROOT_TAR" >"$ART/rootfs.tar.xz"
  rm -f "$ROOT_TAR"
else
  gzip -c -9 "$ROOT_TAR" >"$ART/rootfs.tar.gz"
  rm -f "$ROOT_TAR"
fi

note "Unmounting proc/sys/dev"
umount "$ROOTFS/proc" || true
umount "$ROOTFS/sys" || true
umount "$ROOTFS/dev" || true

note "Stage B complete. Artifacts: $ART"
