# sysvinit-smart-plus (POSIX)

Um conjunto “SysVinit moderno” para sistemas sem systemd: estrutura limpa, scripts consistentes, **serviços essenciais** e um gerenciador simples (`svc`) com diagnóstico.

## 1) O que é instalado

- `/lib/sysvinit-smart/common.sh`  
  Biblioteca comum: log em `/var/log/rc.log`, leitura segura de configs (`KEY=value`), pidfile helpers, etc.

- `/etc/rc.d/rc.S`  
  Early boot: monta proc/sys/run/dev, carrega modules-load, sysctl (se existir), hostname, mount -a, syslog/klogd, e roda `rcS.d`.

- `/etc/rc.d/rc`  
  Runner de runlevel: executa `rcN.d/S*` (default N=3).

- `/etc/init.d/<serviço>`  
  Serviços com interface padrão: `start|stop|restart|status`.

- `/bin/svc`  
  Gerenciador: list/start/stop/restart/status, enable/disable, **plan**, **doctor**, **enable-all**, **log**.

- `/etc/sysconfig/*.conf`  
  Configs declarativas (sem `eval`).

## 2) Instalação

No host:

```sh
sudo ./sysvinit-smart-setup.sh /mnt/seu-rootfs
```

Dentro do sistema (ou chroot):

```sh
svc doctor
svc list
svc plan 3
```

## 3) Integração com SysVinit (inittab)

Garanta que seu `/etc/inittab` chame:

```
id:3:initdefault:
si::sysinit:/etc/rc.d/rc.S
l3:3:wait:/etc/rc.d/rc 3
```

## 4) Serviços incluídos

### Runlevel S (rcS.d)
- `mountfs`: `mount -a`
- `mdev`: device manager (busybox) opcional
- `urandom`: seed de entropia em `/var/lib/random-seed`
- `sysctl`: aplica `/etc/sysctl.conf` (se existir)

### Runlevel 3 (rc3.d)
- `wpa`: Wi‑Fi via `wpa_supplicant`
- `network`: DHCP (udhcpc/dhclient) ou estático via `ip`
- `firewall`: `MODE=allow` (default) ou `basic` (drop input, libera loopback/established/icmp/ssh)
- `sshd`: OpenSSH ou Dropbear (não derruba boot se não existir)
- `timesync`: ntpd/sntp/chronyd (best-effort)
- `cron`: busybox `crond` ou `cronie`

## 5) Configuração (sysconfig)

### `/etc/sysconfig/network.conf`
DHCP:
```
IFACE=
USE_DHCP=1
WAIT_LINK=1
WAIT_TIMEOUT=10
DNS1=1.1.1.1
DNS2=8.8.8.8
```

Estático:
```
IFACE=enp3s0
USE_DHCP=0
STATIC_IP=192.168.1.50/24
GATEWAY=192.168.1.1
DNS1=1.1.1.1
DNS2=8.8.8.8
```

### `/etc/sysconfig/wifi.conf`
```
IFACE=wlan0
WPA_CONF=/etc/wpa_supplicant.conf
DRIVER=nl80211,wext
```

Crie `/etc/wpa_supplicant.conf`:
```
ctrl_interface=/run/wpa_supplicant
update_config=1
network={
  ssid="SSID"
  psk="SENHA"
}
```

### `/etc/sysconfig/sshd.conf`
```
MODE=auto
PORT=22
PERMIT_ROOT=yes
```

### `/etc/sysconfig/timesync.conf`
```
MODE=auto
SERVER=pool.ntp.org
```

### `/etc/sysconfig/firewall.conf`
```
MODE=allow
SSH_PORT=22
```

## 6) Comandos do svc

- Listar:
```sh
svc list
```

- Start/stop:
```sh
svc start network
svc start wpa
svc status sshd
```

- Planejar ordem (rc3.d):
```sh
svc plan 3
```

- Diagnóstico:
```sh
svc doctor
svc log
```

- Habilitar automaticamente serviços que declaram `Default-Start: 3`:
```sh
svc enable-all 3
```

## 7) Troubleshooting rápido

- Wi‑Fi:
  - configure `IFACE=` explicitamente.
  - cheque driver: `dmesg | tail`
- DHCP:
  - confirme `udhcpc` (busybox) ou instale `dhclient`.
- SSH:
  - instale `openssh` ou `dropbear` (o serviço não instala pacotes; só inicia se existir).

## Licença
MIT (veja `LICENSE`).
