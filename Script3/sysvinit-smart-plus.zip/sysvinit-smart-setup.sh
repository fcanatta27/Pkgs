#!/bin/sh
# sysvinit-smart-setup.sh - installs sysvinit-smart-plus into a target rootfs
set -eu

TARGET="${1:-}"
[ -n "$TARGET" ] || { echo "Uso: $0 /caminho/para/rootfs"; exit 2; }
case "$TARGET" in /*) : ;; *) echo "TARGET deve ser absoluto"; exit 2 ;; esac

copy() {
  src="$1"; dst="$2"; mode="$3"
  mkdir -p "$(dirname "$dst")"
  cp -f "$src" "$dst"
  chmod "$mode" "$dst" 2>/dev/null || true
}

BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

# Core
mkdir -p "$TARGET/lib/sysvinit-smart" "$TARGET/bin" "$TARGET/etc/rc.d" "$TARGET/etc/init.d" "$TARGET/etc/rc.d/rcS.d" "$TARGET/etc/rc.d/rc3.d" "$TARGET/etc/sysconfig" "$TARGET/run" "$TARGET/var/log" "$TARGET/var/lib"
copy "$BASE_DIR/rootfs/lib/sysvinit-smart/common.sh" "$TARGET/lib/sysvinit-smart/common.sh" 0755
copy "$BASE_DIR/rootfs/bin/svc" "$TARGET/bin/svc" 0755
copy "$BASE_DIR/rootfs/etc/rc.d/rc.S" "$TARGET/etc/rc.d/rc.S" 0755
copy "$BASE_DIR/rootfs/etc/rc.d/rc" "$TARGET/etc/rc.d/rc" 0755

# Services
for s in mountfs mdev urandom sysctl network wpa firewall sshd timesync cron; do
  copy "$BASE_DIR/rootfs/etc/init.d/$s" "$TARGET/etc/init.d/$s" 0755
done

# Sysconfig templates (do not overwrite if exists)
[ -f "$TARGET/etc/sysconfig/rc.conf" ] || cat > "$TARGET/etc/sysconfig/rc.conf" <<'EOF'
# rc.conf
# Log path for init/system scripts
RC_LOG=/var/log/rc.log
EOF

[ -f "$TARGET/etc/sysconfig/network.conf" ] || cat > "$TARGET/etc/sysconfig/network.conf" <<'EOF'
# Rede: DHCP por padrão
IFACE=
USE_DHCP=1
WAIT_LINK=1
WAIT_TIMEOUT=10
STATIC_IP=
GATEWAY=
DNS1=1.1.1.1
DNS2=8.8.8.8
EOF

[ -f "$TARGET/etc/sysconfig/wifi.conf" ] || cat > "$TARGET/etc/sysconfig/wifi.conf" <<'EOF'
# Wi-Fi via wpa_supplicant
IFACE=
WPA_CONF=/etc/wpa_supplicant.conf
DRIVER=nl80211,wext
EOF

[ -f "$TARGET/etc/sysconfig/sshd.conf" ] || cat > "$TARGET/etc/sysconfig/sshd.conf" <<'EOF'
# sshd.conf
MODE=auto
PORT=22
# yes|no|prohibit-password
PERMIT_ROOT=yes
EOF

[ -f "$TARGET/etc/sysconfig/timesync.conf" ] || cat > "$TARGET/etc/sysconfig/timesync.conf" <<'EOF'
# timesync.conf
MODE=auto
SERVER=pool.ntp.org
EOF

[ -f "$TARGET/etc/sysconfig/firewall.conf" ] || cat > "$TARGET/etc/sysconfig/firewall.conf" <<'EOF'
# firewall.conf
# allow|basic
MODE=allow
SSH_PORT=22
EOF

# Enable essentials
ln -sf ../init.d/mountfs "$TARGET/etc/rc.d/rcS.d/S10mountfs" 2>/dev/null || true
ln -sf ../init.d/mdev "$TARGET/etc/rc.d/rcS.d/S12mdev" 2>/dev/null || true
ln -sf ../init.d/urandom "$TARGET/etc/rc.d/rcS.d/S14urandom" 2>/dev/null || true
ln -sf ../init.d/sysctl "$TARGET/etc/rc.d/rcS.d/S16sysctl" 2>/dev/null || true

ln -sf ../init.d/network "$TARGET/etc/rc.d/rc3.d/S20network" 2>/dev/null || true
ln -sf ../init.d/firewall "$TARGET/etc/rc.d/rc3.d/S25firewall" 2>/dev/null || true
ln -sf ../init.d/sshd "$TARGET/etc/rc.d/rc3.d/S30sshd" 2>/dev/null || true
ln -sf ../init.d/timesync "$TARGET/etc/rc.d/rc3.d/S35timesync" 2>/dev/null || true
ln -sf ../init.d/cron "$TARGET/etc/rc.d/rc3.d/S40cron" 2>/dev/null || true
ln -sf ../init.d/wpa "$TARGET/etc/rc.d/rc3.d/S15wpa" 2>/dev/null || true

echo "OK: sysvinit-smart-plus instalado em $TARGET"
echo "Comandos: chroot ...; svc doctor; svc list; svc plan; svc start network"
