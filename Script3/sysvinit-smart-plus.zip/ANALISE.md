# Análise detalhada do pacote enviado (sysvinit-smart.zip)

## 1) Estrutura existente (arquivo enviado)
O zip contém:

- `rootfs/bin/svc`:
  - comandos: list/start/stop/restart/status/enable/disable/enabled/boot/runlevel
  - enable cria `S<prio><nome>` em `rc3.d`

- `rootfs/etc/rc.d/rc.S`:
  - monta proc/sys/run/devtmpfs/devpts
  - carrega modules-load
  - seta hostname
  - `mount -a`
  - inicia syslogd/klogd
  - executa `rcS.d/S*`

- `rootfs/etc/rc.d/rc`:
  - executa `rcN.d/S*`
  - tenta usar `/bin/svc` quando presente

- Serviços em `/etc/init.d`:
  - `mountfs`, `network`, `wpa`, `sshd`, `cron`

- `sysvinit-smart-setup.sh`:
  - instala arquivos e cria symlinks essenciais em `rcS.d` e `rc3.d`

## 2) Pontos fortes
- POSIX sh e scripts curtos.
- `svc` dá uma camada de gestão mais amigável (enable/disable + start/stop).
- `network` e `wpa` cobrem o mínimo para rede em um sistema pequeno.
- SSH com fallback (OpenSSH ou Dropbear) evita falha dura no boot.

## 3) Problemas reais e riscos encontrados (e como foram corrigidos no “plus”)

### 3.1 Logs e observabilidade fracos
**Antes:** mensagens em stdout/stderr; sem log persistente padrão.  
**Agora:** `/lib/sysvinit-smart/common.sh` escreve também em `/var/log/rc.log` (best-effort) e permite configurar via `/etc/sysconfig/rc.conf`.

### 3.2 Leitura de config sem padronização e sem “metadados”
**Antes:** cada serviço lê config do seu jeito (shell `. conf` em alguns pontos), o que pode virar risco se o arquivo contiver conteúdo inesperado.  
**Agora:** leitura de configs é **KEY=value** via parser `cfg_get` (sem `eval`).  
Além disso, adicionamos headers “LSB-ish” (`Provides`, `Required-Start`, `Default-Start`) para inspeção e automação.

### 3.3 PID files inconsistentes
**Antes:** alguns scripts tentavam descobrir PID com `ps | awk`, o que falha em busybox/ps minimalista, e pode pegar PID errado.  
**Agora:** padronizamos: quando possível, usamos `-P pidfile` (wpa_supplicant, dropbear) e mantemos PIDfile com helpers (`read_pidfile`, `write_pidfile`).  

### 3.4 Wi‑Fi e IP: ordem e comportamento
**Antes:** `wpa` e `network` eram independentes; dependendo do uso, a ordem precisava ser manual.  
**Agora:** `wpa` fica com prioridade antes, mas “network” continua sendo o serviço que sobe IP.  
Também adicionamos `WAIT_LINK` e `WAIT_TIMEOUT` para reduzir falhas comuns de link “late”.

### 3.5 Serviços essenciais faltando
**Antes:** faltavam serviços típicos de base para estabilidade/segurança:
- sysctl no boot
- seed de entropia
- timesync
- firewall básico opcional
- mdev (para sistemas muito pequenos sem udev)

**Agora:** adicionamos `sysctl`, `urandom`, `timesync`, `firewall`, `mdev`.

## 4) Resultado
O “sysvinit-smart-plus” é uma evolução direta:
- melhor logging
- mais serviços essenciais
- configs seguras (sem eval)
- execução mais previsível
- diagnósticos (`svc doctor`, `svc plan`, `svc log`)

