Conteúdo para ser instalado no rootfs (use sysvinit-smart-setup.sh).
