#!/bin/sh
# /lib/sysvinit-smart/common.sh - POSIX helpers
set -eu

RC_LOG_DEFAULT="/var/log/rc.log"

ts() { date +"%Y-%m-%d %H:%M:%S"; }

rc_log_path() {
  # Allow override via /etc/sysconfig/rc.conf (KEY=value)
  conf="/etc/sysconfig/rc.conf"
  if [ -f "$conf" ]; then
    p=$(cfg_get "$conf" RC_LOG 2>/dev/null || true)
    [ -n "${p:-}" ] && { printf '%s\n' "$p"; return 0; }
  fi
  printf '%s\n' "$RC_LOG_DEFAULT"
}

log() {
  msg="$*"
  printf '%s %s\n' "$(ts)" "$msg" >&2
  # Best-effort file log (avoid failing boot)
  lp=$(rc_log_path)
  ( umask 022; mkdir -p "$(dirname "$lp")" 2>/dev/null || true
    printf '%s %s\n' "$(ts)" "$msg" >>"$lp" 2>/dev/null || true
  ) || true
}

die() { log "ERROR: $*"; exit 1; }

need_root() { [ "$(id -u)" -eq 0 ] || die "Precisa de root (use sudo)."; }
have() { command -v "$1" >/dev/null 2>&1; }

ensure_dir() {
  d="$1"; mode="${2:-0755}"
  [ -n "$d" ] || die "ensure_dir: caminho vazio"
  [ -d "$d" ] || mkdir -p "$d"
  chmod "$mode" "$d" 2>/dev/null || true
}

# Read key=val config safely (no eval). Accepts KEY=value. Ignores comments/blank.
cfg_get() {
  file="$1"; key="$2"
  [ -f "$file" ] || return 1
  awk -v k="$key" '
    BEGIN{FS="="}
    /^[[:space:]]*#/ {next}
    /^[[:space:]]*$/ {next}
    {
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $1)
      if ($1==k) {
        $1=""; sub(/^=/,"");
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", $0)
        print $0; exit 0
      }
    }' "$file"
}

# LSB-ish header parser for init scripts (best-effort)
# Example lines:
#   # Provides: network
#   # Required-Start: mountfs
#   # Default-Start: 3
hdr_get() {
  file="$1"; field="$2"
  [ -f "$file" ] || return 1
  awk -v f="$field" '
    BEGIN{IGNORECASE=1}
    /^[[:space:]]*#[[:space:]]*[^:]+:/{
      line=$0
      sub(/^[[:space:]]*#[[:space:]]*/,"",line)
      split(line,a,":")
      key=a[1]
      gsub(/[[:space:]]+/,"",key)
      if (tolower(key)==tolower(f)) {
        sub(/^[^:]+:[[:space:]]*/,"",line)
        gsub(/^[[:space:]]+|[[:space:]]+$/,"",line)
        print line; exit 0
      }
    }' "$file"
}

# PID helpers
pid_alive() { p="$1"; [ -n "$p" ] || return 1; kill -0 "$p" 2>/dev/null; }

read_pidfile() {
  f="$1"
  [ -f "$f" ] || return 1
  p=$(cat "$f" 2>/dev/null || true)
  case "$p" in ''|*[!0-9]*) return 1 ;; *) printf '%s\n' "$p"; return 0 ;; esac
}

write_pidfile() {
  f="$1"; p="$2"
  ensure_dir "$(dirname "$f")" 0755
  ( umask 022; printf '%s\n' "$p" > "$f" ) 2>/dev/null || true
}

# start-stop-daemon helpers (fallback)
ssd_start() {
  pidfile="$1"; shift
  if have start-stop-daemon; then
    start-stop-daemon --start --background --make-pidfile --pidfile "$pidfile" --exec "$1" -- "$@"
  else
    "$@" &
    write_pidfile "$pidfile" "$!"
  fi
}

ssd_stop() {
  pidfile="$1"
  if have start-stop-daemon; then
    start-stop-daemon --stop --pidfile "$pidfile" --retry=TERM/5/KILL/5
  else
    p=$(read_pidfile "$pidfile" 2>/dev/null || true)
    [ -n "$p" ] && kill "$p" 2>/dev/null || true
  fi
}

wait_for_link() {
  iface="$1"; timeout="${2:-10}"
  [ -n "$iface" ] || return 1
  have ip || return 0
  i=0
  while [ "$i" -lt "$timeout" ]; do
    state=$(ip -o link show "$iface" 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="state"){print $(i+1); exit}}')
    [ "$state" = "UP" ] && return 0
    i=$((i+1)); sleep 1
  done
  return 0
}
