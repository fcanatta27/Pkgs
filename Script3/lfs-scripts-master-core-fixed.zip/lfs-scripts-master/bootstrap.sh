#!/usr/bin/env bash
set -euo pipefail

# bootstrap.sh
# Builds temporary toolchain and base system using ports/Pkgfiles.
# This version uses the shell-based pkg* tools shipped in ./files (pkgmk/pkgadd/pkginfo/pkgrm/pkgget).

_buildtoolchain() {
	if [ "$(id -u)" = 0 ]; then
		echo "temporary toolchain must be built as a regular user" >&2
		exit 1
	fi

	export BOOTSTRAP=1
	export LFS_TGT=x86_64-lfs-linux-gnu
	export LFS_TGT32=i686-lfs-linux-gnu

	mkdir -p "${LFS}${TOOLS}" "${sourcedir}"
	rm -f "${TOOLS}"
	ln -sf "${LFS}${TOOLS}" "${TOOLS}"

	_install_tools_into_tools_prefix

	cat > /tmp/bootstrap.conf << EOF
export MAKEFLAGS=-j$(nproc)
PKGMK_SOURCE_DIR=${sourcedir}
PKGMK_PACKAGE_DIR=/tmp/lfs-pkg
. ${PWD}/files/pkgmk.bootstrap
EOF

	for i in ${toolchainpkg}; do
		[ -f "${TOOLS}/${i}" ] && continue
		cd "ports/core/${i%-pass*}"
		mkdir -p /tmp/lfs-pkg
		export tcpkg="$i"
		# -d download sources, -i install, -s strip, -c clean, -f force
		pkgmk -d -i -s -c -f -C /tmp/bootstrap.conf
		rm -rf /tmp/lfs-pkg
		cd - >/dev/null 2>&1
		touch "${TOOLS}/${i}"
	done
	rm -f /tmp/bootstrap.conf

	local tmppwd=$PWD
	cd "${LFS}"
	rm -f "${tmppwd}/toolchain.tar.xz"
	XZ_DEFAULTS='-T0' tar -cvJpf "${tmppwd}/toolchain.tar.xz" .
	cd "${tmppwd}"

	echo
	echo "toolchain build completed"
}

_compressrootfs() {
	local tmppwd=$PWD
	cd "${LFS}"
	rm -f "${tmppwd}/lfs-rootfs.tar.xz"
	XZ_DEFAULTS='-T0' tar \
		--exclude='./var/lib/pkg/rejected' \
		--exclude=".${TOOLS}" \
		--exclude='./tmp/*' \
		--exclude='./dev/*' \
		--exclude='./sys/*' \
		--exclude='./proc/*' \
		--exclude='./run/*' \
		-cvJpf "${tmppwd}/lfs-rootfs.tar.xz" .
	cd "${tmppwd}"

	echo
	echo "base rootfs compressed: ${tmppwd}/lfs-rootfs.tar.xz"
}

_buildbase() {
	if [ "$(id -u)" != 0 ]; then
		echo "base must be built as root" >&2
		exit 1
	fi

	_install_tools_into_tools_prefix

	if [ ! -d "${LFS}/var/lib/pkgdb" ]; then
		mkdir -pv "${LFS}/bin" "${LFS}/usr/lib" "${LFS}/usr/bin" "${LFS}/etc" "${LFS}/dev"
		for i in bash cat chmod dd echo ln mkdir pwd rm stty; do
			ln -svf "${TOOLS}/bin/${i}" "${LFS}/bin"
		done
		for i in env install perl printf touch; do
			ln -svf "${TOOLS}/bin/${i}" "${LFS}/usr/bin"
		done
		ln -svf bash "${LFS}/bin/sh"
		ln -svf /proc/self/mounts "${LFS}/etc/mtab"

		cat ports/core/aaa_filesystem/passwd > "${LFS}/etc/passwd"
		cat ports/core/aaa_filesystem/group > "${LFS}/etc/group"

		# pkgdb (our shell pkg* database)
		mkdir -p "${LFS}/var/lib/pkgdb/packages" "${LFS}/var/lib/pkgdb/files"
		mkdir -p "${LFS}/${pkgmkpkg}" "${LFS}/${pkgmksrc}" "${packagedir}"
	fi

	# ports tree
	rm -rf "${LFS}/usr/ports/core"
	mkdir -p "${LFS}/usr/ports/core"
	cp -r ports/core/* "${LFS}/usr/ports/core"

	# install pkgget wrapper in tools (used inside chroot as needed)
	install -m755 files/pkgin "${TOOLS}/bin/pkgin"

	# pkgmk config
	mkdir -p "${LFS}/var/lib/pkgmk"
	if [ -f ports/core/pkgutils/extension ]; then
		cp ports/core/pkgutils/extension "${LFS}/var/lib/pkgmk/extension"
	fi
	cat > "${LFS}/tmp/pkgmk.conf" << EOF
export CFLAGS="-O2 -march=x86-64 -pipe"
export CXXFLAGS="\${CFLAGS}"
export JOBS=$(nproc)
export MAKEFLAGS="-j \${JOBS}"
PKGMK_SOURCE_DIR="/${pkgmksrc}"
PKGMK_PACKAGE_DIR="/${pkgmkpkg}"
PKGMK_WORK_DIR="/tmp/pkgmk-\${name}"
[ -f /var/lib/pkgmk/extension ] && . /var/lib/pkgmk/extension
EOF

	local lfspath="/bin:/usr/bin:/sbin:/usr/sbin"
	if [ "${1:-}" != "rebuild" ]; then
		lfspath="${lfspath}:${TOOLS}/bin:${TOOLS}/sbin"
	fi

	mountfs
	for i in ${basepkg}; do
		if [ "${1:-}" != "rebuild" ]; then
			# skip if already installed inside LFS
			if chroot "${LFS}" env -i PATH="${lfspath}" pkginfo -i | awk '{print $1}' | grep -qx "${i}"; then
				continue
			fi
			# build and install inside chroot using pkgmk/pkgadd
			chroot "${LFS}" env -i PATH="${lfspath}" pkgin -d "${i}" -i -s -f -m -C /tmp/pkgmk.conf || { umountfs; exit 1; }
			pkgadd -r "${LFS}" -f "$(ls -1 "${packagedir}/${i}"#* 2>/dev/null | tail -n1)" || { umountfs; exit 1; }
		else
			# rebuild via pkgget (depinst) if present
			chroot "${LFS}" env -i PATH="${lfspath}" pkgget depinst "${i}" --upgrade-deps || { umountfs; exit 1; }
		fi
	done
	umountfs

	echo
	echo "base system build completed"
}

_install_tools_into_tools_prefix() {
	mkdir -p "${TOOLS}/bin" "${TOOLS}/sbin"
	install -m755 files/pkgmk "${TOOLS}/bin/pkgmk"
	install -m755 files/pkginfo "${TOOLS}/bin/pkginfo"
	install -m755 files/pkgget "${TOOLS}/bin/pkgget"
	install -m755 files/pkgin "${TOOLS}/bin/pkgin"
	install -m755 files/pkgupdate "${TOOLS}/bin/pkgupdate"
	install -m755 files/pkgmk.bootstrap "${TOOLS}/bin/pkgmk.bootstrap"

	install -m755 files/pkgadd "${TOOLS}/sbin/pkgadd"
	install -m755 files/pkgrm "${TOOLS}/sbin/pkgrm"

	export PATH="${TOOLS}/bin:${TOOLS}/sbin:${PATH}"
}

mountfs() {
	umountfs || true
	mkdir -p "${LFS}/dev" "${LFS}/run" "${LFS}/proc" "${LFS}/sys" "${LFS}/dev/pts"
	mount --bind /dev "${LFS}/dev"
	mount -t devpts devpts "${LFS}/dev/pts" -o gid=5,mode=620
	mount -t proc proc "${LFS}/proc"
	mount -t sysfs sysfs "${LFS}/sys"
	mount -t tmpfs tmpfs "${LFS}/run"

	if [ -h "${LFS}/dev/shm" ]; then
		mkdir -p "${LFS}/$(readlink "${LFS}/dev/shm")"
	fi

	mkdir -p "${LFS}/${pkgmksrc}" "${LFS}/${pkgmkpkg}"
	mount --bind "${sourcedir}" "${LFS}/${pkgmksrc}"
	mount --bind "${packagedir}" "${LFS}/${pkgmkpkg}"
}

umountfs() {
	unmount "${LFS}/dev/pts" || true
	unmount "${LFS}/dev" || true
	unmount "${LFS}/run" || true
	unmount "${LFS}/proc" || true
	unmount "${LFS}/sys" || true
	unmount "${LFS}/${pkgmkpkg}" || true
	unmount "${LFS}/${pkgmksrc}" || true
}

unmount() {
	local mnt="$1"
	[ -e "${mnt}" ] || return 0
	while mountpoint -q "${mnt}" 2>/dev/null; do
		umount "${mnt}" 2>/dev/null || break
	done
}

export LFS=/tmp/lfs-rootfs
export TOOLS=/tmp/lfs-tools
export LC_ALL=C
export PATH="${TOOLS}/bin:${TOOLS}/sbin:${PATH}"

toolchainpkg="binutils-pass1 gmp mpfr mpc gcc-pass1 linux-headers glibc gcc-pass2 binutils-pass2 libxcrypt gcc-pass3 m4
	ncurses bash bison bzip2 coreutils diffutils file findutils gawk gettext grep gzip make patch perl python
	sed tar texinfo xz openssl ca-certificates curl libarchive"

# NOTE: you may adjust basepkg to match your ports set.
basepkg="aaa_filesystem linux-headers man-pages glibc tzdata zlib bzip2 xz file ncurses readline m4 bc binutils libxcrypt
	gmp mpfr mpc attr acl shadow gcc pkgconf libcap sed psmisc iana-etc bison flex pcre2 grep bash dash
	libtool gdbm gperf expat inetutils perl perl-xml-parser intltool autoconf automake openssl kmod gettext elfutils
	libffi sqlite python coreutils check diffutils gawk findutils groff less gzip zstd iptables libtirpc iproute2 kbd
	libpipeline make patch man-db tar texinfo vim procps-ng util-linux e2fsprogs sysklogd eudev which
	libarchive ca-certificates curl pkgutils prt-get httpup linux-pam ports prt-utils runit runit-rc signify"

sourcedir="${PWD}/sources"
packagedir="${PWD}/packages"
pkgmkpkg="var/cache/pkg/packages"
pkgmksrc="var/cache/pkg/sources"

if [ "${1:-}" = "" ]; then
	cat << EOF
Usage:
  $0 <option>

Options:
  1  build temporary toolchain (as regular user)
  2  build base system (as root)
  3  rebuild base system (as root, using final system itself)
  4  compress base rootfs
EOF
	exit 0
fi

case "$1" in
	1) _buildtoolchain ;;
	2) _buildbase ;;
	3) _buildbase rebuild ;;
	4) _compressrootfs ;;
	*) echo "unknown option: $1" >&2; exit 2 ;;
esac
