# sysvinit-smart (POSIX)

Este pacote adiciona um “SysVinit moderno” sem systemd: organização clara, scripts consistentes e um gerenciador simples de serviços (`svc`).

Objetivos:
- POSIX sh
- pouca repetição (biblioteca comum + scripts pequenos)
- comportamento previsível e logs claros
- serviços essenciais, incluindo **Wi‑Fi** e **SSH**

## Visão geral da estrutura

Após instalação no rootfs:

- `/lib/sysvinit-smart/common.sh`  
  Funções utilitárias (log, leitura de config, pidfile, helpers).

- `/etc/rc.d/rc.S`  
  Boot “early”: monta proc/sys/run/dev, carrega módulos, hostname, `mount -a`, syslog/klogd, e roda `rcS.d`.

- `/etc/rc.d/rc`  
  Runner de runlevel: executa `rcN.d` (por padrão N=3). Se existir `/bin/svc`, usa o `svc` para resolver links.

- `/etc/init.d/<serviço>`  
  Serviços com interface padrão: `start|stop|restart|status`.

- `/bin/svc`  
  Gerenciador: `list`, `start`, `stop`, `restart`, `status`, `enable`, `disable`, `enabled`, `boot`, `runlevel`.

- `/etc/sysconfig/*.conf`  
  Configuração declarativa (`KEY=value`).

## Instalação (no seu chroot/rootfs)

1) Copie este pacote para o host e rode:

```sh
sudo ./sysvinit-smart-setup.sh /mnt/seu-rootfs
```

2) Garanta que o SysVinit esteja instalado e que `/sbin/init` aponte para o init correto.

3) Garanta que seu `inittab` chame o rc.S e o rc do runlevel 3. Exemplo:

```
id:3:initdefault:
si::sysinit:/etc/rc.d/rc.S
l3:3:wait:/etc/rc.d/rc 3
```

## Usando o `svc`

### Listar serviços
```sh
svc list
```

### Iniciar/parar/ver status
```sh
svc start network
svc status wpa
svc restart sshd
svc stop cron
```

### Habilitar/desabilitar no boot
Por padrão, habilita em runlevel 3:

```sh
svc enable sshd
svc disable sshd
svc enabled sshd
```

Você pode especificar o runlevel:
```sh
svc enable network 3
```

### Rodar sequência de boot manualmente
Útil em chroot ou depuração:

```sh
svc boot
```

Ou executar apenas um runlevel:
```sh
svc runlevel 3
```

## Configuração dos serviços

### Rede: `/etc/sysconfig/network.conf`

DHCP (padrão):
```
IFACE=
USE_DHCP=1
DNS1=1.1.1.1
DNS2=8.8.8.8
```

IP estático:
```
IFACE=enp3s0
USE_DHCP=0
STATIC_IP=192.168.1.50/24
GATEWAY=192.168.1.1
DNS1=1.1.1.1
DNS2=8.8.8.8
```

### Wi‑Fi: `/etc/sysconfig/wifi.conf`

```
IFACE=wlan0
WPA_CONF=/etc/wpa_supplicant.conf
```

E crie `/etc/wpa_supplicant.conf` (exemplo):

```
ctrl_interface=/run/wpa_supplicant
update_config=1

network={
  ssid="NOME_DA_REDE"
  psk="SENHA"
}
```

Observação: o serviço `wpa` só autentica a rede. Em seguida, o serviço `network` fornece IP (DHCP/estático).

### SSH: `/etc/sysconfig/sshd.conf`

```
PORT=22
ALLOW_ROOT=1
```

O serviço `sshd` suporta:
- **OpenSSH** (`/usr/sbin/sshd`)
- **Dropbear** (`dropbear`)

Se nenhum estiver instalado, o serviço não falha o boot; apenas informa.

## Serviços incluídos

- `mountfs` (rcS): `mount -a`
- `wpa` (runlevel 3): Wi‑Fi via `wpa_supplicant`
- `network` (runlevel 3): DHCP (udhcpc/dhclient) ou estático via `ip`
- `sshd` (runlevel 3): OpenSSH ou Dropbear
- `cron` (runlevel 3): `crond` (busybox) ou `cronie` (se existir)

## Solução de problemas

1) Serviço “não inicia”
- Verifique se o binário existe: `command -v <binário>`
- Rode em foreground manualmente (ex.: `wpa_supplicant -i wlan0 -c /etc/wpa_supplicant.conf`)

2) Wi‑Fi não detecta interface
- Configure `IFACE=` explicitamente em `wifi.conf`.

3) DHCP não obtém IP
- Verifique se `udhcpc` existe (busybox) ou instale `dhclient`.
- Confira o link do driver e `dmesg`.

## Design e segurança

- Scripts usam `set -eu`.
- `svc` é idempotente (enable/disable não duplicam links).
- PIDfiles em `/run` quando possível.
- Configs são lidas sem `eval` (parser simples `KEY=value`).

## Licença
MIT (veja `LICENSE`).
