Conteúdo a ser copiado para o rootfs (via sysvinit-smart-setup.sh).
