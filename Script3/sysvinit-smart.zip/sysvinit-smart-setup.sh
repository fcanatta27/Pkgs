#!/bin/sh
# sysvinit-smart-setup.sh - installs sysvinit-smart into a target rootfs
set -eu

TARGET="${1:-}"
[ -n "$TARGET" ] || { echo "Uso: $0 /caminho/para/rootfs"; exit 2; }
case "$TARGET" in /*) : ;; *) echo "TARGET deve ser absoluto"; exit 2 ;; esac

# Install paths:
#  /lib/sysvinit-smart/common.sh
#  /bin/svc
#  /etc/rc.d/{rc.S,rc}
#  /etc/init.d/* services
#  /etc/rc.d/rcS.d and rc3.d symlinks
#  /etc/sysconfig/* templates

copy() {
  src="$1"; dst="$2"; mode="$3"
  mkdir -p "$(dirname "$dst")"
  cp -f "$src" "$dst"
  chmod "$mode" "$dst" 2>/dev/null || true
}

BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

copy "$BASE_DIR/rootfs/lib/sysvinit-smart/common.sh" "$TARGET/lib/sysvinit-smart/common.sh" 0755
copy "$BASE_DIR/rootfs/bin/svc" "$TARGET/bin/svc" 0755

mkdir -p "$TARGET/etc/rc.d" "$TARGET/etc/init.d" "$TARGET/etc/rc.d/rcS.d" "$TARGET/etc/rc.d/rc3.d" "$TARGET/etc/sysconfig" "$TARGET/run" "$TARGET/var/log" "$TARGET/var/spool/cron"

copy "$BASE_DIR/rootfs/etc/rc.d/rc.S" "$TARGET/etc/rc.d/rc.S" 0755
copy "$BASE_DIR/rootfs/etc/rc.d/rc" "$TARGET/etc/rc.d/rc" 0755

for s in mountfs network wpa sshd cron; do
  copy "$BASE_DIR/rootfs/etc/init.d/$s" "$TARGET/etc/init.d/$s" 0755
done

# Default sysconfig templates (do not overwrite if exists)
if [ ! -f "$TARGET/etc/sysconfig/network.conf" ]; then
  cat > "$TARGET/etc/sysconfig/network.conf" <<'EOF'
# Rede: DHCP por padrão
IFACE=
USE_DHCP=1
STATIC_IP=
GATEWAY=
DNS1=1.1.1.1
DNS2=8.8.8.8
EOF
fi

if [ ! -f "$TARGET/etc/sysconfig/wifi.conf" ]; then
  cat > "$TARGET/etc/sysconfig/wifi.conf" <<'EOF'
# Wi-Fi via wpa_supplicant
# IFACE= (opcional; autodetect melhor esforço)
IFACE=
WPA_CONF=/etc/wpa_supplicant.conf
EOF
fi

if [ ! -f "$TARGET/etc/sysconfig/sshd.conf" ]; then
  cat > "$TARGET/etc/sysconfig/sshd.conf" <<'EOF'
PORT=22
ALLOW_ROOT=1
EOF
fi

# Enable essential services for runlevel 3
ln -sf ../init.d/mountfs "$TARGET/etc/rc.d/rcS.d/S10mountfs"
ln -sf ../init.d/wpa "$TARGET/etc/rc.d/rc3.d/S15wpa" 2>/dev/null || true
ln -sf ../init.d/network "$TARGET/etc/rc.d/rc3.d/S20network"
ln -sf ../init.d/sshd "$TARGET/etc/rc.d/rc3.d/S30sshd" 2>/dev/null || true
ln -sf ../init.d/cron "$TARGET/etc/rc.d/rc3.d/S40cron" 2>/dev/null || true

echo "OK: sysvinit-smart instalado em $TARGET"
echo "Dica: use 'svc list' e 'svc enable|disable|start|stop|status'"
