#!/bin/sh
# lib/common.sh - POSIX helpers for sysvinit-smart
set -eu

ts() { date +"%Y-%m-%d %H:%M:%S"; }
log() { printf '%s %s\n' "$(ts)" "$*" >&2; }
die() { log "ERROR: $*"; exit 1; }

need_root() { [ "$(id -u)" -eq 0 ] || die "Precisa de root (use sudo)."; }
have() { command -v "$1" >/dev/null 2>&1; }

ensure_dir() {
  d="$1"; mode="${2:-0755}"
  [ -n "$d" ] || die "ensure_dir: caminho vazio"
  [ -d "$d" ] || mkdir -p "$d"
  chmod "$mode" "$d" 2>/dev/null || true
}

# Read key=val config safely (no eval); simplistic but robust:
# Accepts lines like KEY=value, ignores comments/blank, trims spaces.
cfg_get() {
  file="$1"; key="$2"
  [ -f "$file" ] || return 1
  awk -v k="$key" '
    BEGIN{FS="="}
    /^[[:space:]]*#/ {next}
    /^[[:space:]]*$/ {next}
    {
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $1)
      if ($1==k) {
        $1=""; sub(/^=/,""); 
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", $0)
        print $0; exit 0
      }
    }' "$file"
}

# PID helpers
pid_alive() {
  p="$1"
  [ -n "$p" ] || return 1
  kill -0 "$p" 2>/dev/null
}

read_pidfile() {
  f="$1"
  [ -f "$f" ] || return 1
  p=$(cat "$f" 2>/dev/null || true)
  case "$p" in
    ''|*[!0-9]*) return 1 ;;
    *) printf '%s\n' "$p"; return 0 ;;
  esac
}

# Minimal start-stop-daemon fallback:
# - If start-stop-daemon exists, use it.
# - Else, use sh + background and write pidfile if possible.
ssd_start() {
  pidfile="$1"; shift
  if have start-stop-daemon; then
    start-stop-daemon --start --background --make-pidfile --pidfile "$pidfile" --exec "$1" -- "$@"
  else
    # shellcheck disable=SC2091
    "$@" &
    echo $! > "$pidfile"
  fi
}

ssd_stop() {
  pidfile="$1"
  if have start-stop-daemon; then
    start-stop-daemon --stop --pidfile "$pidfile" --retry=TERM/5/KILL/5
  else
    p=$(read_pidfile "$pidfile" 2>/dev/null || true)
    [ -n "$p" ] && kill "$p" 2>/dev/null || true
  fi
}
