#!/bin/sh
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
. "$ROOT/tools/config.sh"
. "$ROOT/tools/lib/common.sh"
. "$ROOT/tools/lib/builder.sh"

ensure_rootfs_layout "$ROOTFS"

note "Seeding base configuration files"
mkdir -p "$ROOTFS/etc" "$ROOTFS/etc/init.d" "$ROOTFS/etc/udev/rules.d" "$ROOTFS/var/log" "$ROOTFS/var/run"

cat >"$ROOTFS/etc/hostname" <<'EOF'
minibase
EOF

cat >"$ROOTFS/etc/hosts" <<'EOF'
127.0.0.1 localhost minibase
::1       localhost
EOF

cat >"$ROOTFS/etc/resolv.conf" <<'EOF'
# Managed by DHCP (udhcpc) or user.
EOF

cat >"$ROOTFS/etc/fstab" <<'EOF'
proc  /proc proc  nosuid,noexec,nodev 0 0
sysfs /sys  sysfs nosuid,noexec,nodev 0 0
tmpfs /run  tmpfs nosuid,nodev,mode=0755 0 0
tmpfs /tmp  tmpfs nosuid,nodev,mode=1777 0 0
devtmpfs /dev devtmpfs mode=0755,nosuid 0 0
EOF

# Minimal accounts (shadow tools can modify later)
cat >"$ROOTFS/etc/passwd" <<'EOF'
root:x:0:0:root:/root:/bin/sh
EOF
cat >"$ROOTFS/etc/group" <<'EOF'
root:x:0:
tty:x:5:
adm:x:4:
EOF
: >"$ROOTFS/etc/shadow" || true
chmod 600 "$ROOTFS/etc/shadow" 2>/dev/null || true

# BusyBox init configuration
cat >"$ROOTFS/etc/inittab" <<'EOF'
::sysinit:/etc/init.d/rcS
::respawn:/sbin/getty -L 115200 tty1 vt100
::respawn:/sbin/init-monitor
::ctrlaltdel:/sbin/reboot
::shutdown:/etc/init.d/rcK
EOF

# rcS: essential services
cat >"$ROOTFS/etc/init.d/rcS" <<'EOF'
#!/bin/sh
PATH=/bin:/sbin:/usr/bin:/usr/sbin
export PATH

mount -t proc proc /proc 2>/dev/null || true
mount -t sysfs sys /sys 2>/dev/null || true
mount -t devtmpfs dev /dev 2>/dev/null || true
mkdir -p /run /tmp /var/log /var/run
chmod 1777 /tmp

# hostname
[ -f /etc/hostname ] && hostname "$(cat /etc/hostname)" 2>/dev/null || true

# Start udev (eudev)
if command -v udevd >/dev/null 2>&1; then
  udevd --daemon
  # coldplug
  if command -v udevadm >/dev/null 2>&1; then
    udevadm trigger --action=add --type=subsystems
    udevadm trigger --action=add --type=devices
    udevadm settle --timeout=30 || true
  fi
fi

# Load modules directory if present
if command -v modprobe >/dev/null 2>&1; then
  modprobe -a loop ext4 2>/dev/null || true
fi

# Syslog (BusyBox)
if command -v syslogd >/dev/null 2>&1; then
  syslogd -n -O /var/log/messages &
fi
if command -v klogd >/dev/null 2>&1; then
  klogd -n &
fi

# Networking
if command -v ip >/dev/null 2>&1; then
  ip link set lo up 2>/dev/null || true
  IFACE="$(ip -o link show | awk -F': ' '{print $2}' | grep -E '^(e|en|eth|wl)[^:]*$' | head -n1 || true)"
  if [ -n "$IFACE" ]; then
    ip link set "$IFACE" up 2>/dev/null || true
    if command -v udhcpc >/dev/null 2>&1; then
      udhcpc -i "$IFACE" -q -t 5 -T 3 -s /usr/share/udhcpc/default.script || true
    fi
  fi
fi

# NTP (BusyBox)
if command -v ntpd >/dev/null 2>&1; then
  ntpd -n -q -p pool.ntp.org >/dev/null 2>&1 || true
  ntpd -n -p pool.ntp.org &
fi

# Local customizations
[ -x /etc/init.d/rc.local ] && /etc/init.d/rc.local || true

echo "Boot complete."
EOF
chmod +x "$ROOTFS/etc/init.d/rcS"

cat >"$ROOTFS/etc/init.d/rcK" <<'EOF'
#!/bin/sh
# Shutdown script
sync
EOF
chmod +x "$ROOTFS/etc/init.d/rcK"

# udhcpc script
mkdir -p "$ROOTFS/usr/share/udhcpc"
cat >"$ROOTFS/usr/share/udhcpc/default.script" <<'EOF'
#!/bin/sh
[ -n "$interface" ] || exit 0
case "$1" in
  deconfig) ip addr flush dev "$interface" 2>/dev/null || true ;;
  renew|bound)
    ip addr flush dev "$interface" 2>/dev/null || true
    ip addr add "$ip/$mask" dev "$interface" 2>/dev/null || true
    [ -n "$router" ] && ip route replace default via "$router" dev "$interface" 2>/dev/null || true
    if [ -n "$dns" ]; then
      : > /etc/resolv.conf
      for s in $dns; do echo "nameserver $s" >> /etc/resolv.conf; done
    fi
    ;;
esac
exit 0
EOF
chmod +x "$ROOTFS/usr/share/udhcpc/default.script"

# init-monitor watchdog
cat >"$ROOTFS/sbin/init-monitor" <<'EOF'
#!/bin/sh
# Minimal watchdog: restarts essential daemons if they die.
PATH=/bin:/sbin:/usr/bin:/usr/sbin
LOG=/var/log/init-monitor.log
mkdir -p /var/log /var/run

is_running() {
  # $1 = process name substring
  ps | awk '{print $0}' | grep -v grep | grep -q "$1"
}

start_syslog() {
  if command -v syslogd >/dev/null 2>&1 && ! is_running "syslogd"; then
    syslogd -n -O /var/log/messages &
  fi
  if command -v klogd >/dev/null 2>&1 && ! is_running "klogd"; then
    klogd -n &
  fi
}

start_udev() {
  if command -v udevd >/dev/null 2>&1 && ! is_running "udevd"; then
    udevd --daemon
    command -v udevadm >/dev/null 2>&1 && udevadm trigger --action=add --type=devices && udevadm settle --timeout=30 || true
  fi
}

start_ntp() {
  if command -v ntpd >/dev/null 2>&1 && ! is_running "ntpd"; then
    ntpd -n -p pool.ntp.org &
  fi
}

while :; do
  start_udev
  start_syslog
  start_ntp
  sleep 10
done
EOF
chmod +x "$ROOTFS/sbin/init-monitor"

note "Building world"
[ -f "$WORLD_FILE" ] || die "world file not found: $WORLD_FILE"
while IFS= read -r line; do
  case "$line" in ""|\#*) continue ;; esac
  build_port "$line"
done <"$WORLD_FILE"

note "Stage A complete. Rootfs: $ROOTFS"
