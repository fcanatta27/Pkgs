#!/bin/sh
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
. "$ROOT/tools/config.sh"
. "$ROOT/tools/lib/common.sh"
note "Host commands"
missing=0
for c in sh awk sed grep tar make patch gcc g++ ld ar ranlib strip bison flex perl python3; do
  if command -v "$c" >/dev/null 2>&1; then printf '  OK: %s\n' "$c"
  else printf '  MISSING: %s\n' "$c"; missing=1
  fi
done
[ "$missing" -eq 0 ] || note "Some commands missing; builds may fail."
note "Ports referenced by world"
[ -f "$WORLD_FILE" ] || die "missing world file: $WORLD_FILE"
while IFS= read -r line; do
  case "$line" in ""|\#*) continue;; esac
  [ -d "$ROOT/ports/base/$line" ] || die "missing port: $line"
done <"$WORLD_FILE"
note "OK"
