#!/bin/sh
: "${ARCH:=x86_64}"
: "${TARGET:=x86_64-linux-gnu}"

: "${OUT:=$PWD/out}"
: "${ROOTFS:=$OUT/rootfs}"
: "${DISTFILES:=$OUT/distfiles}"
: "${BUILDDIR:=$OUT/build}"
: "${LOGDIR:=$OUT/logs}"
: "${PKGDIR:=$OUT/pkg}"
: "${WORLD_FILE:=$PWD/world/base.world}"

: "${JOBS:=}"
: "${CFLAGS:=-O2 -pipe}"
: "${CXXFLAGS:=-O2 -pipe}"
: "${LDFLAGS:=}"

: "${SOURCE_DATE_EPOCH:=1704067200}"
: "${SUDO:=sudo}"

export ARCH TARGET OUT ROOTFS DISTFILES BUILDDIR LOGDIR PKGDIR WORLD_FILE JOBS CFLAGS CXXFLAGS LDFLAGS SOURCE_DATE_EPOCH SUDO
