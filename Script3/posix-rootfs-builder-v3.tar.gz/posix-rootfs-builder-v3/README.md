# POSIX RootFS Builder v3 (x86_64 + glibc + BusyBox init + eudev + util-linux + shadow)

This project builds a **bootable, desktop-ready base** Linux root filesystem (rootfs) using the **host toolchain**
(Stage A), then optionally finalizes and packages deterministically (Stage B).

Key choices:
- Arch: **x86_64**
- libc: **glibc**
- Base userland + init: **BusyBox** (PID 1 via `busybox init`)
- Device management: **eudev** (udev-compatible, better for desktop than BusyBox mdev)
- Core system utilities: **util-linux**
- User/login management: **shadow**
- Network bootstrap: BusyBox `udhcpc` + `iproute2`
- Logging: BusyBox `syslogd` + `klogd` (minimal syslog)
- Time sync: BusyBox `ntpd` (minimal NTP)

## What you get
- `out/rootfs/` with:
  - BusyBox installed and configured as init
  - `/etc/inittab` + `rcS/rcK` + essential service scripts
  - eudev service scripts and udev rules directory
  - util-linux tools for mounts/blkid/uuid
  - shadow tools for useradd/login/passwd, plus default configs
  - crypto/download stack: zlib + openssl + ca-certificates + curl
  - archives: tar + xz + zstd
- `out/artifacts/` (Stage B):
  - deterministic `rootfs.tar.zst` (or `.tar.xz` / `.tar.gz`)
  - `packages/*.tar` per-port payload tarballs

## Reproducibility controls
- Controlled env: `LC_ALL=C`, `TZ=UTC`, `umask 022`, `SOURCE_DATE_EPOCH` default.
- Ports install to per-port `DESTDIR` and are merged into rootfs.
- Deterministic packaging: sorted file lists, normalized mtimes and ownership.

## Quick start
```sh
./tools/doctor.sh
./tools/update-checksums.sh
./tools/stageA-build.sh
sudo ./tools/stageB-finalize-and-package.sh
```

## Boot wiring
This builds rootfs; you still need a kernel + bootloader/initramfs as you prefer.
BusyBox init expects `/etc/inittab` and runs `/etc/init.d/rcS`.

## Services included (BusyBox init + watchdog)
- udev daemon + coldplug: `udevd` + `udevadm trigger/settle`
- syslog: `syslogd` + `klogd`
- NTP: `ntpd`
- DHCP: `udhcpc` (first detected interface)
- getty on tty1
- `init-monitor` watchdog: periodically checks essential daemons and restarts if needed

License: MIT
