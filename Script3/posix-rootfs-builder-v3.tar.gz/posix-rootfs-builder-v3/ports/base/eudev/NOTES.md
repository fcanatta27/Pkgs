eudev provides udevd/udevadm for device management. rcS starts udevd and performs coldplug via udevadm.
