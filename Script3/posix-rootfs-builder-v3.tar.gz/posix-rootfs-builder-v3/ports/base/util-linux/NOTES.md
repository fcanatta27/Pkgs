util-linux is configured to avoid setuid tools by default; adjust configure flags if you need su/runuser.
