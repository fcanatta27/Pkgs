\
#!/usr/bin/env bash
set -euo pipefail

# Package: Zip
# Version: 3.0
#
# Dependencies (build/runtime) aproximadas:
#   - gcc, make
#   - libc (glibc)
#
# Flags / opções de compilação:
#   - Não possui ./configure tradicional; usa Makefile específico (unix/Makefile)
#   - Para ver opções: consulte o arquivo unix/Makefile e a saída de:
#       make -f unix/Makefile help        (se disponível)
#
# Este script segue o padrão 3bLinux:
#   - Usa BK_* para diretórios/URLs
#   - Usa BK_STAGE_ROOT como destino temporário (DESTDIR)
#   - Idempotente: pode ser reexecutado; build e stage ficam em /tmp/bk-build

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-Zip-3.0}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

: "${BK_ZIP_URL:=https://downloads.sourceforge.net/infozip/zip30.tar.gz}"

SRC_TAR="$BK_DOWNLOAD_DIR/zip-3.0.tar.gz"
SRC_DIR="$BK_BUILD_DIR/src"
BUILD_DIR="$BK_BUILD_DIR/build"

fetch(){
  local url="$1" out="$2"
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then
    info "  Usando tarball em cache: $(b "$out")"
    return 0
  fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then
    curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    die "nem curl nem wget encontrados"
  fi
}

prepare(){
  bl "=== Zip-3.0: prepare ==="
  mkdir -p "$BK_DOWNLOAD_DIR" "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR"
  fetch "$BK_ZIP_URL" "$SRC_TAR"
  rm -rf "$SRC_DIR" "$BUILD_DIR"
  mkdir -p "$SRC_DIR" "$BUILD_DIR"
  tar -xf "$SRC_TAR" -C "$SRC_DIR" --strip-components=1
}

build(){
  bl "=== Zip-3.0: build ==="
  cd "$SRC_DIR"
  # Build estilo "generic" para Unix
  make -f unix/Makefile generic -j"$BK_JOBS"
}

install(){
  bl "=== Zip-3.0: install (stage em $BK_STAGE_ROOT) ==="
  cd "$SRC_DIR"
  mkdir -p "$BK_STAGE_ROOT/usr/bin" "$BK_STAGE_ROOT/usr/share/man/man1"
  # Não há regra DESTDIR padrão nos Makefiles clássicos do zip; instalamos manualmente.
  install -m 0755 zip "$BK_STAGE_ROOT/usr/bin/zip"
  # Manpage se existir
  if [ -f man/zip.1 ]; then
    install -m 0644 man/zip.1 "$BK_STAGE_ROOT/usr/share/man/man1/zip.1"
  fi
}

main(){
  prepare
  build
  install

  bl "=== Summary $(b Zip-3.0) ==="
  info "  Staged root: $(b "$BK_STAGE_ROOT")"
  info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin")"
  info "  Manpages.. : $(b "$BK_STAGE_ROOT/usr/share/man")"
}

main "$@"
