\
#!/usr/bin/env bash
set -euo pipefail

# Package: pciutils
# Version: 3.14.0
#
# Dependencies (build/runtime) aproximadas:
#   - gcc, make, pkg-config
#   - zlib
#   - libkmod (opcional, dependendo das flags)
#
# Flags / opções de compilação:
#   - Makefile próprio, com opções como:
#       PREFIX=/usr
#       SBINDIR=/usr/sbin
#       SHARED=yes/no
#       ZLIB=yes/no
#   - Consulte o Makefile para detalhes adicionais.
#
# Padrão 3bLinux:
#   - Usa BK_STAGE_ROOT como DESTDIR
#   - Build em /tmp/bk-build
#   - Idempotente (pode ser reexecutado)

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-pciutils-3.14.0}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

: "${BK_PCIUTILS_URL:=https://www.kernel.org/pub/software/utils/pciutils/pciutils-3.14.0.tar.xz}"

SRC_TAR="$BK_DOWNLOAD_DIR/pciutils-3.14.0.tar.xz"
SRC_DIR="$BK_BUILD_DIR/src"
BUILD_DIR="$BK_BUILD_DIR/build"

fetch(){
  local url="$1" out="$2"
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then
    info "  Usando tarball em cache: $(b "$out")"
    return 0
  fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then
    curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    die "nem curl nem wget encontrados"
  fi
}

prepare(){
  bl "=== pciutils-3.14.0: prepare ==="
  mkdir -p "$BK_DOWNLOAD_DIR" "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR"
  fetch "$BK_PCIUTILS_URL" "$SRC_TAR"
  rm -rf "$SRC_DIR" "$BUILD_DIR"
  mkdir -p "$SRC_DIR" "$BUILD_DIR"
  tar -xf "$SRC_TAR" -C "$SRC_DIR" --strip-components=1
}

build(){
  bl "=== pciutils-3.14.0: build ==="
  cd "$SRC_DIR"
  make PREFIX=/usr SBINDIR=/usr/sbin SHARED=yes ZLIB=yes -j"$BK_JOBS"
}

install(){
  bl "=== pciutils-3.14.0: install (stage em $BK_STAGE_ROOT) ==="
  cd "$SRC_DIR"
  make PREFIX=/usr SBINDIR=/usr/sbin SHARED=yes ZLIB=yes DESTDIR="$BK_STAGE_ROOT" install install-lib
}

main(){
  prepare
  build
  install

  bl "=== Summary $(b pciutils-3.14.0) ==="
  info "  Staged root: $(b "$BK_STAGE_ROOT")"
  info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/sbin")"
  info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
}

main "$@"
