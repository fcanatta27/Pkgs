    #!/usr/bin/env bash
    set -euo pipefail

    # Package: Papirus-Icon-Theme
    # Version: git
    #
    # Tipo: icon/cursor theme
    #
    # Dependências (conceituais):
    #   - Nenhuma dependência binária forte; requer um ambiente gráfico funcional.
#
    # Flags / opções:
    #   - Este pacote apenas instala arquivos em /usr/share/icons
#
    # Padrão 3bLinux: BK_STAGE_ROOT como DESTDIR

    b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
    bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
    info(){ echo "$*"; }
    die(){ echo "ERROR: $*" >&2; exit 1; }

    : "${BK_JOBS:=1}"
    : "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
    : "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-Papirus-Icon-Theme}}"
    : "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

    : "${BK_PAPIRUS_ICON_URL:=https://example.invalid/papirus-icon-theme.tar.gz}"

    SRC_DIR="$BK_BUILD_DIR/src"

    url_basename(){ local u="$1"; u="${u%%\?*}"; echo "$(basename "$u")"; }

    fetch(){
      mkdir -p "$BK_DOWNLOAD_DIR"
      local url="${BK_PAPIRUS_ICON_URL}" base out
      base="$(url_basename "$url")"
      out="$BK_DOWNLOAD_DIR/$base"
      if [ -s "$out" ]; then info "  Usando tarball em cache: $(b "$out")"; echo "$out"; return 0; fi
      info "  Baixando: $(b "$url")"
      if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
      elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
      else die "nem curl nem wget encontrados"; fi
      echo "$out"
    }

    prepare(){
      bl "=== Papirus-Icon-Theme-git: prepare ==="
      rm -rf "$SRC_DIR"
      mkdir -p "$SRC_DIR"
      local tarball
      tarball="$(fetch)"
      tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1 || tar -xf "$tarball" -C "$SRC_DIR" || die "falha ao extrair"
    }

    build(){
      bl "=== Papirus-Icon-Theme-git: build (assets only) ==="
      : # nada a compilar
    }

    install(){
      bl "=== Papirus-Icon-Theme-git: install (stage em $BK_STAGE_ROOT) ==="
      local dest="/usr/share/icons"
      mkdir -p "$BK_STAGE_ROOT$dest"
      # copia diretórios de tema/ícones do source para o DESTDIR
      # você pode ajustar se o upstream tiver subdiretórios específicos.
      shopt -s dotglob nullglob
      for item in "$SRC_DIR"/*; do
        cp -a "$item" "$BK_STAGE_ROOT$dest/"
      done
    }

    main(){
      prepare
      build
      install
      bl "=== Summary $(b Papirus-Icon-Theme-git) ==="
      info "  Instalado em: $(b "$BK_STAGE_ROOT/usr/share/icons")"
    }

    main "$@"
