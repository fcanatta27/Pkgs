#!/usr/bin/env bash
set -euo pipefail

# Package: x264
# Version: 20250815
#
# Dependencies (host / build) aproximadas:
#   - bash, coreutils, findutils, grep, sed, gawk
#   - tar, xz, gzip, bzip2
#   - make, gcc, pkg-config
#   - curl ou wget
#
# Dependencies (runtime) aproximadas:
#   - libc (glibc), libstdc++, zlib, libgcc
#   - bibliotecas específicas deste pacote (use ldd no binário instalado)
#
# Flags suportadas (ambiente padrão do 3bLinux):
#   BK_JOBS           : paralelismo do make (default 1)
#   BK_DOWNLOAD_DIR   : diretório de cache de tarballs (default /tmp/bk-src)
#   BK_BUILD_DIR      : diretório base de build da receita
#   BK_STAGE_ROOT     : DESTDIR para instalação (conteúdo que será empacotado)
#   BK_*_URL          : URL do tarball da receita (quando definido)
#   BK_*_CONFIG_EXTRA : flags extras passadas para ./configure/meson/cmake/etc.
#
# Flags completas do programa:
#   Consulte:
#     - ./configure --help        (projetos autotools)
#     - meson configure           (projetos Meson)
#     - cmake -LH                 (projetos CMake)
#     - --help do binário final   (opções em tempo de execução)

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-x264-20250815}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
: "${BK_X264_GIT_URL:=https://code.videolan.org/videolan/x264.git}"
: "${BK_X264_GIT_REF:=master}"

SRC_DIR="$BK_BUILD_DIR/src"

bl "=== Construção $(b x264-20250815) ==="
info "  Git URL....: $(b "$BK_X264_GIT_URL")"
info "  Git ref....: $(b "$BK_X264_GIT_REF")"
info "  Build dir..: $(b "$BK_BUILD_DIR")"
info "  Stage root.: $(b "$BK_STAGE_ROOT")"

mkdir -p "$BK_DOWNLOAD_DIR" "$BK_BUILD_DIR" "$BK_STAGE_ROOT"

if [ ! -d "$SRC_DIR/.git" ]; then
  rm -rf "$SRC_DIR"
  git clone "$BK_X264_GIT_URL" "$SRC_DIR"
fi

cd "$SRC_DIR"
git fetch --all
git checkout "$BK_X264_GIT_REF"

./configure --prefix=/usr --enable-shared
make -j"$BK_JOBS"
make DESTDIR="$BK_STAGE_ROOT" install

bl "=== Summary x264-20250815 ==="
info "  Staged root: $(b "$BK_STAGE_ROOT")"
