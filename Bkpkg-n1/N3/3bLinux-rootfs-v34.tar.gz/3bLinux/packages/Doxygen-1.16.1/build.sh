\
#!/usr/bin/env bash
set -euo pipefail

# Package: Doxygen
# Version: 1.16.1
#
# Dependencies (build/runtime) aproximadas:
#   - cmake
#   - python3 (opcional)
#   - flex, bison (para alguns caminhos de build, dependendo do tarball)
#
# Flags / opções de compilação (cmake):
#   - -Dbuild_wizard=OFF|ON
#   - -Duse_libclang=OFF|ON
#   - -Dbuild_doc=OFF|ON
#
# Fonte oficial (SourceForge release):
#   https://sourceforge.net/projects/doxygen/files/rel-1.16.1/

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-Doxygen-1.16.1}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

: "${BK_DOXYGEN_URL:=https://sourceforge.net/projects/doxygen/files/rel-1.16.1/doxygen-1.16.1.src.tar.gz/download}"

SRC_TAR="$BK_DOWNLOAD_DIR/Doxygen-1.16.1.tar.gz"
SRC_DIR="$BK_BUILD_DIR/src"
BUILD_DIR="$BK_BUILD_DIR/build"

fetch(){
  local url="$BK_DOXYGEN_URL" out="$SRC_TAR"
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then info "  Usando tarball em cache: $(b "$out")"; return 0; fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
  else die "nem curl nem wget encontrados"; fi
}

prepare(){
  bl "=== Doxygen-1.16.1: prepare ==="
  mkdir -p "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR" "$BK_DOWNLOAD_DIR"
  fetch
  rm -rf "$SRC_DIR" "$BUILD_DIR"
  mkdir -p "$SRC_DIR" "$BUILD_DIR"
  tar -xf "$SRC_TAR" -C "$SRC_DIR" --strip-components=1
}

build(){
  bl "=== Doxygen-1.16.1: build ==="
  cd "$BUILD_DIR"
  cmake -G "Unix Makefiles" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX=/usr \
    -Dbuild_doc=OFF \
    "$SRC_DIR"
  make -j"$BK_JOBS"
}

install(){
  bl "=== Doxygen-1.16.1: install (stage em $BK_STAGE_ROOT) ==="
  cd "$BUILD_DIR"
  make DESTDIR="$BK_STAGE_ROOT" install
}

main(){
  prepare
  build
  install
  bl "=== Summary $(b Doxygen-1.16.1) ==="
  info "  Staged root: $(b "$BK_STAGE_ROOT")"
  info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin/doxygen")"
}

main "$@"
