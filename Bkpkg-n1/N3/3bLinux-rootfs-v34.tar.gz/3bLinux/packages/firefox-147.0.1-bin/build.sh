\
#!/usr/bin/env bash
set -euo pipefail

# Package: firefox-bin
# Version: 147.0.1 (pré-compilado)
#
# Dependencies (runtime aproximadas):
#   - gtk+3
#   - dbus
#   - fontconfig, freetype, libX11, libXrender, libXt, libxcb, libXdamage, libXcomposite, libXfixes
#   - alsa-lib ou pipewire/pulseaudio
#   - libstdc++ recente
#
# Flags / opções:
#   - Apenas instala o tarball binário fornecido pela Mozilla
#   - Caminho alvo: /opt/firefox-147.0.1 + symlink /usr/bin/firefox

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-firefox-147.0.1-bin}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

# Exemplo de URL (ajuste se necessário)
: "${BK_FIREFOX_BIN_URL:=https://download.mozilla.org/?product=firefox-147.0.1&os=linux64&lang=en-US}"

SRC_DIR="$BK_BUILD_DIR/src"

url_basename(){ local u="$1"; u="${u%%\?*}"; echo "$(basename "$u")"; }

fetch(){
  mkdir -p "$BK_DOWNLOAD_DIR"
  local url="$BK_FIREFOX_BIN_URL" base out
  base="$(url_basename "$url")"
  [ -n "$base" ] || base="firefox-147.0.1.tar.bz2"
  out="$BK_DOWNLOAD_DIR/$base"
  if [ -s "$out" ]; then
    info "  Usando tarball em cache: $(b "$out")"
    echo "$out"; return 0
  fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
  else die "nem curl nem wget encontrados"; fi
  echo "$out"
}

prepare(){
  bl "=== firefox-147.0.1-bin: prepare ==="
  rm -rf "$SRC_DIR"
  mkdir -p "$SRC_DIR"
  local tarball
  tarball="$(fetch)"
  tar -xf "$tarball" -C "$SRC_DIR"
}

install(){
  bl "=== firefox-147.0.1-bin: install ==="
  local dest="$BK_STAGE_ROOT/opt/firefox-147.0.1"
  mkdir -p "$dest"
  if [ -d "$SRC_DIR/firefox" ]; then
    cp -a "$SRC_DIR/firefox/." "$dest/"
  else
    # alguns tarballs já extraem como firefox/
    cp -a "$SRC_DIR/." "$dest/"
  fi
  mkdir -p "$BK_STAGE_ROOT/usr/bin"
  ln -sf /opt/firefox-147.0.1/firefox "$BK_STAGE_ROOT/usr/bin/firefox"
}

main(){
  prepare
  install
  bl "=== Summary firefox-147.0.1-bin ==="
  info "  Binário em: $BK_STAGE_ROOT/opt/firefox-147.0.1"
  info "  Wrapper:    $BK_STAGE_ROOT/usr/bin/firefox"
}

main "$@"
