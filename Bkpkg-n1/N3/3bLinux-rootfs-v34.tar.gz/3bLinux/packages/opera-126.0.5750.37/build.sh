\
#!/usr/bin/env bash
set -euo pipefail

# Package: opera-stable
# Version: 126.0.5750.37 (binário .deb)
#
# Dependencies (runtime):
#   - gtk3, nss, nspr, libx11, libxcb, libxss, libxrandr, libdrm, mesa
#
# Flags:
#   - BK_OPERA_DEB_URL (default: ftp.opera.com)

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-opera-126.0.5750.37}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
: "${BK_OPERA_DEB_URL:=https://ftp.opera.com/pub/opera/desktop/126.0.5750.37/linux/opera-stable_126.0.5750.37_amd64.deb}"

SRC_DIR="$BK_BUILD_DIR/src"

url_basename(){ local u="$1"; u="${u%%\?*}"; echo "$(basename "$u")"; }

fetch(){
  mkdir -p "$BK_DOWNLOAD_DIR"
  local url="$BK_OPERA_DEB_URL" base out
  base="$(url_basename "$url")"
  out="$BK_DOWNLOAD_DIR/$base"
  if [ -s "$out" ]; then
    info "  Usando cache: $(b "$out")"
    echo "$out"; return 0
  fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
  else die "nem curl nem wget"; fi
  echo "$out"
}

prepare(){
  bl "=== opera-126.0.5750.37: prepare ==="
  rm -rf "$SRC_DIR"
  mkdir -p "$SRC_DIR"
  local deb
  deb="$(fetch)"
  command -v ar >/dev/null 2>&1 || die "ar não encontrado (binutils)"
  ( cd "$SRC_DIR" && ar x "$deb" )
  mkdir -p "$SRC_DIR/data"
  tar -xf "$SRC_DIR/data.tar."* -C "$SRC_DIR/data"
}

install(){
  bl "=== opera-126.0.5750.37: install (stage) ==="
  cp -a "$SRC_DIR/data/." "$BK_STAGE_ROOT/"
}

main(){ prepare; install; bl "=== Summary opera ==="; info "  Staged: $BK_STAGE_ROOT"; }
main "$@"
