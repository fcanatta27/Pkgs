\
#!/usr/bin/env bash
set -euo pipefail

# Package: chromium
# Version: rolling (blueprint)
#
# Dependencies (build):
#   - python3, git
#   - clang/llvm, lld
#   - ninja, pkg-config
#   - nodejs (algumas partes)
#   - gn (vem no depot_tools)
#
# Flags / opções:
#   - GN args podem ser passadas via BK_GN_ARGS (string)
#
# Observação:
#   Chromium é extremamente pesado para compilar. Este script é um blueprint
#   no padrão 3bLinux; você precisará preparar depot_tools e caches.

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-chromium}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
: "${BK_DEPOT_TOOLS:=/opt/depot_tools}"
: "${BK_GN_ARGS:=is_official_build=true use_sysroot=false proprietary_codecs=true ffmpeg_branding=Chrome}"

SRC_DIR="$BK_BUILD_DIR/src"
OUT_DIR="$BK_BUILD_DIR/out/Release"

prepare(){
  bl "=== chromium: prepare ==="
  mkdir -p "$BK_BUILD_DIR"
  [ -d "$BK_DEPOT_TOOLS" ] || die "depot_tools não encontrado em $BK_DEPOT_TOOLS"
  export PATH="$BK_DEPOT_TOOLS:$PATH"
  mkdir -p "$SRC_DIR"
  if [ ! -d "$SRC_DIR/.git" ]; then
    fetch --nohooks chromium || die "fetch chromium falhou"
  fi
  cd "$SRC_DIR"
  gclient sync
}

build(){
  bl "=== chromium: build ==="
  cd "$SRC_DIR"
  gn gen "$OUT_DIR" --args="$BK_GN_ARGS"
  ninja -C "$OUT_DIR" -j"$BK_JOBS" chrome
}

install(){
  bl "=== chromium: install (stage em $BK_STAGE_ROOT) ==="
  mkdir -p "$BK_STAGE_ROOT/opt/chromium"
  cp -a "$OUT_DIR/." "$BK_STAGE_ROOT/opt/chromium/"
  mkdir -p "$BK_STAGE_ROOT/usr/bin"
  ln -sf /opt/chromium/chrome "$BK_STAGE_ROOT/usr/bin/chromium" || true
}

main(){ prepare; build; install; bl "=== Summary chromium ==="; info "  Staged: $BK_STAGE_ROOT"; }
main "$@"
