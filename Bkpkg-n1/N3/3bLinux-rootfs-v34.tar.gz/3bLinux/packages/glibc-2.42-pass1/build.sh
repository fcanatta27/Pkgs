#!/usr/bin/env bash
set -euo pipefail

# Package: glibc
# Version: 2.42
#
# Dependencies (host / build) aproximadas:
#   - bash, coreutils, findutils, grep, sed, gawk
#   - tar, xz, gzip, bzip2
#   - make, gcc, pkg-config
#   - curl ou wget
#
# Dependencies (runtime) aproximadas:
#   - libc (glibc), libstdc++, zlib, libgcc
#   - bibliotecas específicas deste pacote (use ldd no binário instalado)
#
# Flags suportadas (ambiente padrão do 3bLinux):
#   BK_JOBS           : paralelismo do make (default 1)
#   BK_DOWNLOAD_DIR   : diretório de cache de tarballs (default /tmp/bk-src)
#   BK_BUILD_DIR      : diretório base de build da receita
#   BK_STAGE_ROOT     : DESTDIR para instalação (conteúdo que será empacotado)
#   BK_*_URL          : URL do tarball da receita (quando definido)
#   BK_*_CONFIG_EXTRA : flags extras passadas para ./configure/meson/cmake/etc.
#
# Flags completas do programa:
#   Consulte:
#     - ./configure --help        (projetos autotools)
#     - meson configure           (projetos Meson)
#     - cmake -LH                 (projetos CMake)
#     - --help do binário final   (opções em tempo de execução)

b(){ tput bold 2>/dev/null||true; printf '%s' "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; printf '%s
' "$*"; tput sgr0 2>/dev/null||true; }
info(){ printf '%s
' "$*"; }
die(){ printf 'ERROR: %s
' "$*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-glibc-2.42-pass1}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
: "${BK_TARGET:?BK_TARGET não definido (ex: x86_64-3blinux-gnu)}"

: "${BK_GLIBC_URL:=https://ftp.gnu.org/gnu/glibc/glibc-2.42.tar.xz}"
: "${BK_GLIBC_CONFIG_EXTRA:=}"
: "${BK_GLIBC_DISABLE_WERROR:=1}"

TAR="$BK_DOWNLOAD_DIR/glibc-2.42.tar.xz"
SRC="$BK_BUILD_DIR/src"
BUILD="$BK_BUILD_DIR/build"

fetch(){
  local url="$1" out="$2"
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then
    info "  Using cached source: $out"
    return 0
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 --output "$out" "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    die "need curl or wget"
  fi
}

bl "=== Build $(b glibc) $(b 2.42-pass1) ==="
info "  Name.......: $(b "${BK_PKG_NAME:-glibc}")"
info "  Version....: $(b "${BK_PKG_VERSION:-2.42-pass1}")"
info "  Recipe.....: ${BK_RECIPE:-glibc-2.42-pass1}"
info "  Target.....: $(b "$BK_TARGET")"
info "  Download...: $(b "$BK_GLIBC_URL")"
info "  Download dir: $(b "$BK_DOWNLOAD_DIR")"
info "  Build dir..: $(b "$BK_BUILD_DIR")"
info "  Stage root.: $(b "$BK_STAGE_ROOT")"

mkdir -p "$BK_DOWNLOAD_DIR" "$BK_BUILD_DIR" "$BK_STAGE_ROOT"
fetch "$BK_GLIBC_URL" "$TAR"

rm -rf "$SRC" "$BUILD"
mkdir -p "$SRC" "$BUILD"
tar -xf "$TAR" -C "$SRC" --strip-components=1

cd "$BUILD"

WERROR_FLAG=""
if [ "$BK_GLIBC_DISABLE_WERROR" = "1" ]; then
  WERROR_FLAG="--disable-werror"
fi

"$SRC/configure" \
  --prefix=/usr \
  --host="$BK_TARGET" \
  --build="$("$SRC/scripts/config.guess")" \
  --disable-profile \
  --enable-kernel=4.19 \
  --without-selinux \
  $WERROR_FLAG \
  $BK_GLIBC_CONFIG_EXTRA

make -j"$BK_JOBS"
make DESTDIR="$BK_STAGE_ROOT" install

bl "=== Summary $(b glibc 2.42-pass1) ==="
info "  Staged root: $(b "$BK_STAGE_ROOT")"
info "  usr dir....: $(b "$BK_STAGE_ROOT/usr")"
