\
#!/usr/bin/env bash
set -euo pipefail

# Package: UDisks
# Version: 2.11.0
#
# Dependencies (build/runtime) aproximadas:
#   - glib2, gobject-introspection
#   - polkit, libblockdev, libatasmart (dependendo da config)
#   - systemd-logind / elogind (para integrações de sessão)
#   - meson, ninja, pkg-config
#
# Flags / opções de compilação (meson):
#   - -Dsystemdsystemunitdir=...
#   - -Dlibmount=enabled/disabled
#   - -Davailable-modules=...
#
# Este script supõe um setup simples:
#   - prefix=/usr
#   - buildtype=release

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-UDisks-2.11.0}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

: "${BK_UDISKS_URL:=https://github.com/storaged-project/udisks/archive/refs/tags/udisks-2.11.0.tar.gz}"

SRC_TAR="$BK_DOWNLOAD_DIR/UDisks-2.11.0.tar.gz"
SRC_DIR="$BK_BUILD_DIR/src"
BUILD_DIR="$BK_BUILD_DIR/build"

fetch(){
  local url="$BK_UDISKS_URL" out="$SRC_TAR"
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then
    info "  Usando tarball em cache: $(b "$out")"
    return 0
  fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then
    curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    die "nem curl nem wget encontrados"
  fi
}

prepare(){
  bl "=== UDisks-2.11.0: prepare ==="
  mkdir -p "$BK_DOWNLOAD_DIR" "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR"
  fetch
  rm -rf "$SRC_DIR" "$BUILD_DIR"
  mkdir -p "$SRC_DIR" "$BUILD_DIR"
  tar -xf "$SRC_TAR" -C "$SRC_DIR" --strip-components=1
}

build(){
  bl "=== UDisks-2.11.0: build ==="
  cd "$SRC_DIR"
  meson setup "$BUILD_DIR" \
    --prefix=/usr \
    --buildtype=release
  ninja -C "$BUILD_DIR" -j"$BK_JOBS"
}

install(){
  bl "=== UDisks-2.11.0: install (stage em $BK_STAGE_ROOT) ==="
  cd "$SRC_DIR"
  DESTDIR="$BK_STAGE_ROOT" ninja -C "$BUILD_DIR" install
}

main(){
  prepare
  build
  install

  bl "=== Summary $(b UDisks-2.11.0) ==="
  info "  Staged root: $(b "$BK_STAGE_ROOT")"
  info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin")"
  info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
}

main "$@"
