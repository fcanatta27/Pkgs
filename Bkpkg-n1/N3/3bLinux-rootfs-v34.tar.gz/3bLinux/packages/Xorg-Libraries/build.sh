\
#!/usr/bin/env bash
set -euo pipefail

# Package group: Xorg Libraries
#
# Este script é um orquestrador para as bibliotecas do Xorg.
# A ideia é:
#   - definir uma lista de receitas de libs (por exemplo, libX11, libXrender, libXt, etc.)
#   - chamar os respectivos build.sh em ordem
#
# Por padrão, a lista vem de BK_XORG_LIBS (variável de ambiente) ou
# de um arquivo /etc/3bLinux/xorg-libs.list, um pacote por linha.

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }

: "${BK_XORG_LIBS:=}"

ROOT_PACKAGES_DIR="${BK_PACKAGES_DIR:-/packages}"

load_default_list(){
  if [ -n "$BK_XORG_LIBS" ]; then
    printf '%s\n' "$BK_XORG_LIBS"
    return 0
  fi
  if [ -f /etc/3bLinux/xorg-libs.list ]; then
    grep -v '^[[:space:]]*#' /etc/3bLinux/xorg-libs.list | sed '/^[[:space:]]*$/d'
    return 0
  fi
  return 1
}

main(){
  bl "=== Xorg Libraries: orchestrator ==="
  local libs
  libs=$(load_default_list || true)
  if [ -z "$libs" ]; then
    info "Nenhuma lista de libs definida (BK_XORG_LIBS ou /etc/3bLinux/xorg-libs.list)."
    info "Ajuste conforme necessário. Nada a fazer."
    exit 0
  fi

  echo "$libs" | while read -r pkg; do
    [ -z "$pkg" ] && continue
    bl ">>> Build Xorg lib: $pkg"
    if [ -x "$ROOT_PACKAGES_DIR/$pkg/build.sh" ]; then
      ( cd "$ROOT_PACKAGES_DIR/$pkg" && ./build.sh )
    else
      info "  [SKIP] build.sh não encontrado em $ROOT_PACKAGES_DIR/$pkg"
    fi
  done
}

main "$@"
