Estado interno do bk (bk-build-base, etc.)
