#!/bin/sh
# 3bLinux init hook: 30-dbus.sh
# Inicia dbus-daemon --system se disponível.

set -eu

if command -v dbus-daemon >/dev/null 2>&1; then
  if [ ! -S /run/dbus/system_bus_socket ]; then
    echo "[3binit] iniciando dbus-daemon..."
    dbus-daemon --system --nopidfile || true
  fi
fi
