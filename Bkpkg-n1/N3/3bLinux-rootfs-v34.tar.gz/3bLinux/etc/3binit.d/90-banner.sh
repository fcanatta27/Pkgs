#!/bin/sh
# 3bLinux init hook: 90-banner.sh
set -eu
if [ -f /etc/issue ]; then
  cat /etc/issue 2>/dev/null || true
fi
