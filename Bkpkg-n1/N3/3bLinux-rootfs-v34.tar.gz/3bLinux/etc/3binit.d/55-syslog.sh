#!/bin/sh
# 3bLinux init hook: 55-syslog.sh
# Inicia syslog básico (BusyBox syslogd/klogd) se disponível.
set -eu

# cria /var/log se faltar
mkdir -p /var/log 2>/dev/null || true

if command -v syslogd >/dev/null 2>&1; then
  # -n: não daemoniza (pode travar o boot), então rodamos em background sem -n
  # -O: arquivo
  syslogd -O /var/log/messages 2>/dev/null || true
fi

if command -v klogd >/dev/null 2>&1; then
  klogd 2>/dev/null || true
fi

# salva dmesg inicial
if command -v dmesg >/dev/null 2>&1; then
  dmesg > /var/log/dmesg 2>/dev/null || true
fi
