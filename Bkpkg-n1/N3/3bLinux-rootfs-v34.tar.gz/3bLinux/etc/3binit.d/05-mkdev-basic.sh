#!/bin/sh
# 3bLinux init hook: 05-mkdev-basic.sh
# Garante diretórios em /dev e permissões mínimas.
set -eu

mkdir -p /dev/pts /dev/shm 2>/dev/null || true
chmod 0755 /dev 2>/dev/null || true
chmod 0755 /dev/pts 2>/dev/null || true
chmod 1777 /dev/shm 2>/dev/null || true

# nós mínimos (se não existirem)
[ -c /dev/console ] || mknod -m 600 /dev/console c 5 1 2>/dev/null || true
[ -c /dev/null ] || mknod -m 666 /dev/null c 1 3 2>/dev/null || true
