#!/bin/sh
# 3bLinux init hook: 45-modules-load.sh
# Carrega módulos listados em /etc/modules-load.d/*.conf e /etc/modules (se existir).
set -eu

# modprobe pode vir do kmod ou busybox (às vezes)
command -v modprobe >/dev/null 2>&1 || exit 0

load_file() {
  f="$1"
  [ -f "$f" ] || return 0
  while IFS= read -r line; do
    case "$line" in
      ""|\#*) continue ;;
    esac
    modprobe "$line" 2>/dev/null || true
  done < "$f"
}

if [ -d /etc/modules-load.d ]; then
  for f in /etc/modules-load.d/*.conf; do
    [ -f "$f" ] || continue
    load_file "$f"
  done
fi

load_file /etc/modules
