#!/bin/sh
# 3bLinux init hook: 60-random-seed.sh
# Melhor esforço para restaurar/salvar seed de entropia.
set -eu

SEED=/var/lib/random-seed
mkdir -p /var/lib 2>/dev/null || true
if [ -c /dev/urandom ]; then
  if [ -f "$SEED" ]; then
    cat "$SEED" > /dev/urandom 2>/dev/null || true
  fi
  dd if=/dev/urandom of="$SEED" bs=512 count=1 2>/dev/null || true
  chmod 0600 "$SEED" 2>/dev/null || true
fi
