#!/bin/sh
# 3bLinux init hook: 15-ldconfig.sh
# Regera cache do linker dinâmico (se disponível).
set -eu

if command -v ldconfig >/dev/null 2>&1; then
  ldconfig 2>/dev/null || true
fi
