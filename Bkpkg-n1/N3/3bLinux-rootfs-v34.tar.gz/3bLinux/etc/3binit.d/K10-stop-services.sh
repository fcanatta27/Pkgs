\
#!/usr/bin/env bash
set -euo pipefail

# /etc/3binit.d/K10-stop-services.sh
#
# Hook de shutdown para parar serviços conhecidos antes do desligamento.
#
# Este script pode ser chamado múltiplas vezes sem causar problemas
# (idempotente), pois apenas tenta parar serviços se estiverem rodando.
#
# Argumento:
#   $1 = ação (reboot|poweroff)  [apenas informativo; pode ser usado se desejar]

ACTION="${1:-poweroff}"

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }

stop_service() {
  local name="$1"
  if command -v pkill >/dev/null 2>&1; then
    pkill -TERM -x "$name" 2>/dev/null || true
  elif command -v killall >/dev/null 2>&1; then
    killall "$name" 2>/dev/null || true
  elif command -v pidof >/dev/null 2>&1; then
    local pids
    pids=$(pidof "$name" 2>/dev/null || true)
    [ -n "$pids" ] && kill $pids 2>/dev/null || true
  fi
}

bl "[K10] Parando serviços para ação: $ACTION"

# Exemplos de serviços comuns:
for svc in dbus-daemon NetworkManager dhcpcd ntpd syslogd klogd; do
  stop_service "$svc"
done

exit 0
