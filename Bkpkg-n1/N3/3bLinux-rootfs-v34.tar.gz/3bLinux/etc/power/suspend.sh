#!/usr/bin/env bash
# Hook suspend 3bLinux
sv stop NetworkManager || true
sv stop bluetooth || true
