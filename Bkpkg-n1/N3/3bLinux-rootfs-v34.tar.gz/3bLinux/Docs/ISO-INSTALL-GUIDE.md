\
# 3bLinux - ISO, Instalador (bk-install) e Rootfs Tarball (bk-mkiso)

Este documento explica:

- Como gerar um **tarball de rootfs** do 3bLinux
- Como gerar uma **ISO bootável** contendo kernel + initramfs + rootfs tarball
- Como **instalar** o sistema em disco usando `bk-install`

Ferramentas principais:

- `bk-mkiso`  – cria tarball de rootfs e ISO
- `bk-install` – instalador em modo texto, rodando a partir da ISO ou de um live

---

## 1) Tarball de Rootfs com `bk-mkiso tarball`

O tarball é a base da instalação: é o snapshot do rootfs que será restaurado no disco de destino.

### 1.1) Recomendação

Entre em chroot no seu rootfs 3bLinux (para evitar misturar host com rootfs):

```sh
chroot /path/para/3bLinux /bin/bash
```

Neste ambiente:

- `/` é o rootfs do 3bLinux
- `/bin`, `/etc`, etc. são do 3bLinux

### 1.2) Criar o tarball

```sh
bk-mkiso tarball
```

Isso irá:

- Usar root = `/`
- Criar (por padrão) algo como:

```text
/var/3bLinux/rootfs-YYYYMMDD-HHMMSS.tar.gz
```

### 1.3) Parâmetros opcionais

```sh
bk-mkiso tarball --root / --output /var/3bLinux/rootfs-installer.tar.gz
```

- `--root`   : diretório raiz a ser empacotado (default `/`)
- `--output` : caminho do tarball (default: `/var/3bLinux/rootfs-<timestamp>.tar.gz`)

Exclusões automáticas (pseudo-fs e afins):

- `/proc`, `/sys`, `/dev`, `/run`, `/tmp`, `/mnt`, `/media`, `/lost+found`

---

## 2) ISO bootável com `bk-mkiso iso`

A ISO contém:

- kernel (vmlinuz)
- initramfs
- rootfs tarball (para o instalador)

### 2.1) Requisitos

- `grub-mkrescue`
- `xorriso`
- kernel + initramfs prontos em `/boot`:

Exemplo mínimo esperado:

- `/boot/vmlinuz`
- `/boot/initramfs.img`

### 2.2) Gerar ISO a partir do tarball

Após criar o tarball:

```sh
bk-mkiso iso --tarball /var/3bLinux/rootfs-installer.tar.gz
```

Se você não informar `--tarball`, o script tenta localizar um padrão:

- `/var/3bLinux/rootfs-installer.tar.gz`
- ou `/var/3bLinux/rootfs-<timestamp>.tar.gz`

Ele então:

1. Cria uma árvore temporária:

```text
/tmp/bk-mkiso.XXXXXX/iso/
  boot/
    vmlinuz
    initramfs.img
    grub/grub.cfg
  installer/
    rootfs.tar.gz
```

2. Gera ISO com:

```sh
grub-mkrescue -o /var/3bLinux/3bLinux-YYYYMMDD-HHMMSS.iso /tmp/bk-mkiso.XXXXXX/iso
```

(com caminho de saída padrão em `/var/3bLinux`, a menos que você use `--output`)

### 2.3) Parâmetros

```sh
bk-mkiso iso \
  --kernel /boot/vmlinuz-3bLinux \
  --initrd /boot/initramfs-3bLinux.img \
  --tarball /var/3bLinux/rootfs-installer.tar.gz \
  --output /var/3bLinux/3bLinux-installer.iso
```

- `--kernel` : caminho do kernel (default `/boot/vmlinuz`)
- `--initrd` : caminho do initramfs (default `/boot/initramfs.img`)
- `--tarball`: caminho do rootfs tarball
- `--output` : caminho da ISO (default `/var/3bLinux/3bLinux-<timestamp>.iso`)

O `grub.cfg` incluído é simples:

```cfg
set default=0
set timeout=5

menuentry "3bLinux (installer)" {
  linux /boot/vmlinuz root=/dev/ram0 console=ttyS0
  initrd /boot/initramfs.img
}
```

---

## 3) Instalação com `bk-install`

Depois de gerar a ISO, você pode:

- gravar em pendrive
- ou usar diretamente com QEMU.

Ao bootar pela ISO, o kernel e o initramfs sobem, e você deve ter disponível:

- `/installer/rootfs.tar.gz` (adicionado pelo bk-mkiso iso)
- `/bin/bk-install` (dentro do rootfs da imagem, se você incluir o 3bLinux live na ISO)

> Observação: a ISO criada por `bk-mkiso iso` já coloca o rootfs tarball em
> `installer/rootfs.tar.gz`. O ambiente live que você usar deve expor esse
> caminho para o `bk-install`.

### 3.1) Execução básica

No ambiente live (via ISO), execute:

```sh
bk-install
```

Ele entra em modo interativo:

1. Lista discos e partições detectadas (`lsblk`)
2. Pergunta:
   - **partição raiz** (ex: `/dev/sda2`)
   - **partição EFI** (opcional, ex: `/dev/sda1`)
3. Tenta localizar o tarball automaticamente em:
   - `/installer/rootfs/base.tar.gz`
   - `/installer/rootfs.tar.gz`
   - `/var/3bLinux/rootfs-installer.tar.gz`
4. Se não encontrar, pergunta o caminho do tarball.

Depois, mostra um resumo:

- raiz
- EFI
- target mountpoint (default `/mnt/3bLinux`)
- tarball usado
- hostname (default `3bLinux`)

Pedirá confirmação (a menos que `BK_INSTALL_FORCE=1` no ambiente).

### 3.2) O que o `bk-install` faz

Na sequência:

1. **Formatação opcional**:
   - se `FORMAT_ROOT=1` (default), pede confirmação e faz `mkfs.ext4 -F` na partição raiz.
   - se `FORMAT_EFI=1` e tiver EFI, pede confirmação e faz `mkfs.vfat -F32`.

2. **Montagem**:
   - `mount ROOT_DEV -> TARGET`
   - `mount EFI_DEV -> TARGET/boot/efi` (se informado)

3. **Extração do rootfs**:
   - `tar -xpf <tarball> -C $TARGET`

4. **Montagem de pseudo-fs**:
   - `proc`, `sys`, `dev`, `run` dentro do `$TARGET`

5. **/etc/resolv.conf**:
   - copia do ambiente live se existir.

6. **Geração de `/etc/fstab`**:
   - usa `blkid` para obter UUID da raiz e EFI
   - escreve entradas padrão para `/` e `/boot/efi`, mais `/tmp` em tmpfs.

7. **Pós-instalação em chroot**:
   - cria script `/tmp/bk-post-install.sh` dentro do target com:
     - definição de hostname
     - `bk-reparo full` (se existir)
     - criação de `/etc/hosts` mínimo, se faltando
     - instalação de GRUB:
       - modo EFI se `/sys/firmware/efi` existir
       - caso contrário, modo BIOS no próprio ROOT_DEV
       - geração de `grub.cfg` se `grub-mkconfig` existir

   - executa:

```sh
chroot "$TARGET" /bin/sh /tmp/bk-post-install.sh
```

8. **Limpeza**:
   - remove o script de pós-instalação
   - desmonta recursivamente o `TARGET` (`umount -R`)

No fim: “Instalação concluída. Você pode reiniciar e bootar o novo sistema.”

### 3.3) Modo não-interativo

Você pode alimentar tudo pela linha de comando, por exemplo:

```sh
BK_INSTALL_FORCE=1 \
bk-install \
  --root-dev /dev/sda2 \
  --efi-dev /dev/sda1 \
  --target /mnt/3bLinux \
  --tarball /installer/rootfs.tar.gz \
  --hostname meu-3blinux \
  --no-format-root \
  --no-format-efi
```

Isso evita perguntas, útil para automação/CI.

---

## 4) Fluxo completo resumido

1. Monte/prepare o rootfs do 3bLinux (chroot ou sistema real).
2. Gere o tarball:

   ```sh
   bk-mkiso tarball --output /var/3bLinux/rootfs-installer.tar.gz
   ```

3. Gere ISO usando esse tarball:

   ```sh
   bk-mkiso iso --tarball /var/3bLinux/rootfs-installer.tar.gz
   ```

4. Boot pela ISO em máquina real ou QEMU.

5. No live, rode:

   ```sh
   bk-install
   ```

6. Siga os passos para apontar partições e instalar.

---

## 5) Dicas de debug

- Se o GRUB falhar dentro do chroot:
  - certifique-se de que o pacote `grub2` está instalado no rootfs.
  - confirme que `/proc` e `/sys` estão montados dentro do chroot.

- Se o root não monta na primeira vez:
  - verifique `/etc/fstab` no sistema instalado:
    - UUID correto?
    - tipo de filesystem correto (ext4/btrfs etc.)?

- Em casos de quebra, você pode:
  - montar manualmente a raiz novamente
  - chrootar
  - rodar `bk-reparo full`
  - reinstalar o GRUB manualmente.

\
---

## Atualizações (bundle v20)

- `bk-install` agora:
  - aceita BK_INSTALL_ROOT_DEV / BK_INSTALL_EFI_DEV para uso não-interativo;
  - descobre automaticamente o disco físico (sda, nvme0n1, etc.) para instalar GRUB em modo BIOS (não usa mais a partição para grub-install);
  - garante criação de /boot e /boot/efi antes da montagem se necessário.

- `bk-mkiso` agora:
  - usa exclusões relativas corretas ao gerar o tarball (proc/*, sys/*, dev/*, ...), evitando incluir pseudo-filesystems;
  - encontra automaticamente o tarball mais recente rootfs-*.tar.gz, se você não informar o caminho manualmente.
