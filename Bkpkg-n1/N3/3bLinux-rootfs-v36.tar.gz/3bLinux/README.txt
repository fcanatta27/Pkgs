3bLinux (rootfs scaffold)

Este diretório é o root filesystem (ROOTFS) do seu sistema 3bLinux.
Tudo criado aqui é destinado a ir para a imagem final do sistema.

Ferramentas incluídas (dentro do rootfs):
  /bin/bk          Orquestrador de builds e pacotes (usa scripts em packages/*)
  /bin/bk-chroot   Helper para operar o rootfs via chroot (init/mount/enter/run/pkg)
  /bin/bk-package  Ferramenta de pacotes: pack/install/uninstall/list/files/verify

Store de pacotes (por padrão):
  <ROOTFS>/var/3bLinux
Banco de dados de pacotes instalados:
  <ROOTFS>/var/lib/3bLinux/pkg

Uso rápido (host):
  # Inicializar esqueleto do rootfs
  sudo ./3bLinux/bin/bk-chroot init
  sudo ./3bLinux/bin/bk-chroot status

  # Entrar no chroot
  sudo ./3bLinux/bin/bk-chroot enter

Empacotamento manual:
  ./3bLinux/bin/bk-chroot pkg pack busybox ./staging/busybox --version 1.0
  sudo ./3bLinux/bin/bk-chroot pkg install busybox:1.0
  sudo ./3bLinux/bin/bk-chroot pkg uninstall busybox

Fluxo de build com recipes (exemplo binutils pass1):
  ./3bLinux/bin/bk list-recipes
  ./3bLinux/bin/bk build binutils-2.45.1-pass1

Notas de segurança:
- bk-package uninstall não remove nada sob /etc, a menos que --purge-etc seja usado.
- bk-chroot recusa operar com --rootfs "/" para evitar danos ao host.
