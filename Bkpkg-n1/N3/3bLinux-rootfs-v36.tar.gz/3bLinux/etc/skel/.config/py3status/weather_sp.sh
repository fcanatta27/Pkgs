#!/usr/bin/env bash
# ~/.config/py3status/weather_sp.sh
# Clima para São Paulo, Brasil, usando wttr.in

set -euo pipefail

curl -m 2 -fsSL "https://wttr.in/Sao_Paulo?format=1" || echo "n/a"
