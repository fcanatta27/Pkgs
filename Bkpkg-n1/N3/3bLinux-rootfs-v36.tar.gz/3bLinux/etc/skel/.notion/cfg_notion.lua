\
-- notion config (3bLinux) - stub
-- Edite conforme sua preferência. Exemplo mínimo para garantir que o notion sobe.
