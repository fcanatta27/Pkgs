# /etc/profile.d/3blinux.sh
umask 022
# Alias globais simples
alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'
