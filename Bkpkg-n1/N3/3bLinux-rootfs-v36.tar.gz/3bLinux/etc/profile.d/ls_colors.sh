# 3bLinux default LS_COLORS
# Pastas, symlinks, executáveis, arquivos especiais, etc.

export LS_COLORS="di=01;34:ln=01;36:so=01;35:pi=33:ex=01;32:bd=01;33:cd=01;33:su=01;37;41:sg=01;30;43:tw=01;30;42:ow=01;34;42:or=40;31;01:mi=01;05;37;41"
