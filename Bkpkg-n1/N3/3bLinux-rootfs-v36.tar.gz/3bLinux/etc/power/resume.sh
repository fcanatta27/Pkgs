#!/usr/bin/env bash
# Hook resume 3bLinux
sv start NetworkManager || true
sv start bluetooth || true
