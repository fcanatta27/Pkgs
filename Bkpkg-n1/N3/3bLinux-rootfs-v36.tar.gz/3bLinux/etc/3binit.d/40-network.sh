#!/bin/sh
# 3bLinux init hook: 40-network.sh
# Traz rede para cima usando NetworkManager ou dhcpcd.

set -eu

# Se NetworkManager estiver presente, preferir
if command -v NetworkManager >/dev/null 2>&1; then
  echo "[3binit] iniciando NetworkManager..."
  NetworkManager >/var/log/NetworkManager.log 2>&1 &
  exit 0
fi

# Fallback: dhcpcd na interface default
if command -v dhcpcd >/dev/null 2>&1; then
  dev="$(ip route 2>/dev/null | awk '/default/ {print $5; exit}')"
  if [ -n "${dev:-}" ]; then
    echo "[3binit] iniciando dhcpcd em $dev..."
    dhcpcd "$dev" || true
  fi
fi
