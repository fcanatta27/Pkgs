#!/bin/sh
# 3bLinux init hook: 75-fsck-placeholder.sh
# Placeholder para fsck em boots futuros (quando houver util-linux/e2fsprogs).
set -eu
# Exemplo futuro:
#   fsck -A -T -a
