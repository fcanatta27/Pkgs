#!/bin/sh
# 3bLinux init hook: 70-rc-local.sh
# Executa /etc/rc.local se for executável.
set -eu

if [ -x /etc/rc.local ]; then
  /etc/rc.local || true
fi
