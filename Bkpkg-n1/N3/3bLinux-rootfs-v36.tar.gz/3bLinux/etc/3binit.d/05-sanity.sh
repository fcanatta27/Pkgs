#!/bin/sh
# 3bLinux init hook: 05-sanity.sh
# Saneamento inicial: diretórios, permissões e arquivos críticos.

set -eu

mkdir -p /proc /sys /dev /run /tmp /var /var/log /var/run /var/lock 2>/dev/null || true
chmod 1777 /tmp 2>/dev/null || true

# /etc mínimo
[ -d /etc ] || mkdir -p /etc
[ -f /etc/mtab ] || : > /etc/mtab 2>/dev/null || true

# DNS básico se faltando
if [ ! -f /etc/resolv.conf ]; then
  echo "nameserver 1.1.1.1" > /etc/resolv.conf
  echo "nameserver 8.8.8.8" >> /etc/resolv.conf
fi

# Hostname default
if [ ! -f /etc/hostname ]; then
  echo "3bLinux" > /etc/hostname
fi
hostname "$(cat /etc/hostname 2>/dev/null || echo 3bLinux)" 2>/dev/null || true
