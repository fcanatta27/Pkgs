#!/bin/sh
# 3bLinux init hook: 70-ntp.sh
# Inicia ntpd se instalado.

set -eu

if command -v ntpd >/dev/null 2>&1; then
  echo "[3binit] iniciando ntpd..."
  ntpd -g -u ntp:ntp || true
fi
