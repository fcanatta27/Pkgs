#!/bin/sh
# 3bLinux init hook: 95-services-local.sh
# Ponto para iniciar serviços locais em /etc/3bservices.d (opcional).
set -eu

dir=/etc/3bservices.d
[ -d "$dir" ] || exit 0

for f in "$dir"/*.sh; do
  [ -x "$f" ] || continue
  "$f" start 2>/dev/null || true
done
