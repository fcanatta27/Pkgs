#!/bin/sh
# 3bLinux init hook: 12-locale.sh
# Aplica /etc/locale.conf se existir.
set -eu

if [ -f /etc/locale.conf ]; then
  # shellcheck disable=SC1091
  . /etc/locale.conf 2>/dev/null || true
fi
