#!/bin/sh
# 3bLinux init hook: 80-supervisor.sh
# Inicia bk-supervise (se existir) para manter serviços vivos.

set -eu

if [ -x /bin/bk-supervise ] && [ -r /etc/bk-supervisor.conf ]; then
  echo "[3binit] iniciando bk-supervise..."
  /bin/bk-supervise start >/var/log/bk-supervise.boot.log 2>&1 &
fi
