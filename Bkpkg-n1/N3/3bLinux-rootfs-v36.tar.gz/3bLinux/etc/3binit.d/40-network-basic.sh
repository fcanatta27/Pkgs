#!/bin/sh
# 3bLinux init hook: 40-network-basic.sh
# Sobe loopback e (opcional) DHCP em interface padrão se udhcpc existir.
set -eu

if command -v ip >/dev/null 2>&1; then
  ip link set lo up 2>/dev/null || true
elif command -v ifconfig >/dev/null 2>&1; then
  ifconfig lo 127.0.0.1 up 2>/dev/null || true
fi

# DHCP opcional (BusyBox udhcpc)
IFACE="${3BLINUX_IFACE:-}"
if [ -z "$IFACE" ]; then
  # tenta escolher a primeira interface não-loopback
  if command -v ip >/dev/null 2>&1; then
    IFACE="$(ip -o link show | awk -F': ' '{print $2}' | grep -v '^lo$' | head -n1 || true)"
  fi
fi

if [ -n "$IFACE" ] && command -v udhcpc >/dev/null 2>&1; then
  udhcpc -i "$IFACE" -q -t 5 -T 3 2>/dev/null || true
fi
