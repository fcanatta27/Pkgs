\
# 3bLinux — Guia completo (toolchain -> sistema -> ISO -> QEMU)

Este documento descreve um caminho **do zero** até um sistema 3bLinux:
- Toolchain **pass1 / pass2 / final**
- Construção da base (userland + libs + serviços)
- Configuração do init (PID 1) e hooks
- Geração de **initramfs + kernel + ISO**
- Boot no **QEMU** e login funcional

> Convenções:
> - Este repositório/rootfs é o diretório `3bLinux/`.
> - O comando principal é **`./bin/bk`**.
> - As receitas estão em **`./packages/<pacote>/build.sh`**.
> - Builds vão para `/tmp/bk-build/...` e fontes para `/tmp/bk-src/...`.
> - O conteúdo instalado para empacotar vai para **`$BK_STAGE_ROOT`**.

---

## 0) Pré-requisitos no host (máquina de build)

Você precisa de um host Linux com:
- bash, coreutils, tar, xz/gzip/bzip2
- gcc, make, binutils
- curl ou wget
- ideal: `git`, `patch`, `bison`, `flex`, `python3`
- espaço livre (20GB+ recomendado, dependendo do que for construir)

---

## 1) Extraindo o bundle e entrando no rootfs

```bash
tar -xzf 3bLinux-rootfs-vXX.tar.gz
cd 3bLinux
```

Verifique:
```bash
./bin/bk --help || true
ls packages | head
```

---

## 2) Toolchain: pass1 -> pass2 -> final

A ordem exata pode variar, mas a lógica geral é:

### 2.1) Linux headers

Constrói headers do kernel para a libc e toolchain:
```bash
./bin/bk build linux-6.18.2-headers
```

### 2.2) Binutils pass1

```bash
./bin/bk build binutils-2.45.1-pass1
```

### 2.3) GCC pass1

```bash
./bin/bk build gcc-15.2.0-pass1
```

### 2.4) glibc pass1

```bash
./bin/bk build glibc-2.42-pass1
```

### 2.5) libstdc++ pass1

```bash
./bin/bk build libstdc++-pass1
```

### 2.6) Binutils pass2

```bash
./bin/bk build binutils-2.45.1-pass2
```

### 2.7) GCC pass2

```bash
./bin/bk build gcc-pass2
```

### 2.8) glibc final

```bash
./bin/bk build glibc-2.42
```

### 2.9) GCC final

```bash
./bin/bk build gcc-15.2.0
```

### 2.10) Binutils final

```bash
./bin/bk build Binutils-2.45.1
```

---

## 3) Construindo a base para login (userland + libs + serviços)

Você pode construir manualmente pacote por pacote, ou usar o orquestrador:

```bash
./bin/bk-build-base
```

O `bk-build-base`:
- segue uma ordem recomendada (toolchain -> base -> libs -> boot/rede)
- pula automaticamente receitas que não existam no seu tree
- para ao primeiro erro (fail-fast)

---

## 4) Configuração do init e hooks

O 3bLinux usa:
- `init` como PID 1 (shell)
- hooks em `/etc/3binit.d/*.sh`

Hooks relevantes:
- `05-sanity.sh` cria diretórios essenciais, hostname, resolv.conf
- `20-eudev.sh` inicia udevd e popula /dev via trigger
- `30-dbus.sh` inicia dbus system bus
- `40-network.sh` sobe NetworkManager ou dhcpcd
- `70-ntp.sh` sincroniza tempo se ntpd existir
- `80-supervisor.sh` inicia bk-supervise (mantém serviços vivos)

---

## 5) Criando usuário e habilitando sudo

Depois do sistema básico construído (shadow instalado), crie usuário:

```bash
# cria usuário, home, copia /etc/skel, define senha e habilita sudo
./bin/bk-user-create fernando --sudo
```

Se quiser setar senha não-interativa:
```bash
./bin/bk-user-create fernando --sudo --password "SenhaForteAqui"
```

---

## 6) Criando initramfs

Exemplo genérico (depende do seu script bk-initramfs já existente):

```bash
# dentro do rootfs:
./bin/bk-initramfs
```

O initramfs deve conter:
- /init
- /bin/busybox e links
- módulos mínimos (se necessário)
- scripts e configs essenciais

---

## 7) Kernel

Construa o kernel:
```bash
./bin/bk build linux-6.18.2
```

Instale/extraia:
- `bzImage` (x86_64) ou equivalente
- módulos em `/lib/modules/<versão>`

---

## 8) Criando ISO bootável (GRUB + xorriso)

Pré-requisitos:
- `grub2` e `xorriso` construídos
- kernel e initramfs prontos

Estrutura típica de ISO:
```text
iso/
  boot/
    grub/
      grub.cfg
    vmlinuz
    initramfs.img
```

Exemplo de `grub.cfg` (simples):
```cfg
set default=0
set timeout=3

menuentry "3bLinux" {
  linux /boot/vmlinuz root=/dev/ram0 console=ttyS0
  initrd /boot/initramfs.img
}
```

Gerando ISO:
```bash
mkdir -p iso/boot/grub
cp /boot/vmlinuz iso/boot/vmlinuz
cp /boot/initramfs.img iso/boot/initramfs.img
cp grub.cfg iso/boot/grub/grub.cfg

grub-mkrescue -o 3bLinux.iso iso
```

Se `grub-mkrescue` não estiver disponível, use `xorriso` com os parâmetros adequados do seu GRUB build.

---

## 9) Boot no QEMU

Exemplo (serial + 1GB RAM):
```bash
qemu-system-x86_64 \
  -m 1024 \
  -cdrom 3bLinux.iso \
  -nographic \
  -serial mon:stdio
```

Se você estiver usando disco:
```bash
qemu-system-x86_64 \
  -m 2048 \
  -drive file=disk.img,format=raw \
  -kernel vmlinuz \
  -initrd initramfs.img \
  -append "console=ttyS0 root=/dev/sda rw" \
  -nographic
```

---

## 10) Checklist de “sistema pronto”

- `init` sobe e chama hooks
- `udev` ativo (`/dev` populado)
- `dbus` socket em `/run/dbus/system_bus_socket`
- rede sobe (NetworkManager ou dhcpcd)
- `syslog` funcionando (`/var/log/*`)
- login com usuário normal (`bk-user-create`)
- prompt e git configurados (bashrc + /etc/gitconfig)
- supervisor mantendo serviços vivos (`bk-supervise`)

---

## 11) Dicas de debug

- Logs:
  - `/var/log/bk-supervise.log`
  - `/var/log/bk-supervise.boot.log`
  - logs do sistema em `/var/log/*`
- Rodar supervisor em modo debug:
  ```bash
  bk-supervise once
  bk-supervise status
  ```

- Testar hooks manualmente:
  ```bash
  sh -x /etc/3binit.d/40-network.sh
  ```

