# Lab 02 – Shell Intermediário
Objetivo: entender scripts do 3bLinux.

- set -euo pipefail
- funções
- variáveis BK_*
- leitura de arquivos

Exercício:
Leia /etc/bk-supervisor.enable.
