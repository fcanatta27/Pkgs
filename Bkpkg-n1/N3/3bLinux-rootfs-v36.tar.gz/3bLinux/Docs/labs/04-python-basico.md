# Lab 04 – Python Básico
Objetivo: automação.

- print, variáveis
- loops
- leitura de arquivos

Exercício:
Liste serviços enabled via Python.
