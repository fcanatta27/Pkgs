# Primeiros Passos no 3bLinux

1. Instalação:
   bk-install

2. Criar usuário:
   bk-user-create

3. Verificar serviços:
   sv status

4. Login gráfico (LightDM)

5. Desktop XFCE pronto.
