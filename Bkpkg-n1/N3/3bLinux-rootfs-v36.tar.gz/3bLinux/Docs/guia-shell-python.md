# Guia de Shell Script e Python para o 3bLinux

Este guia é dividido em três níveis:

- **Iniciante** – primeiros passos, comandos básicos
- **Intermediário** – funções, tratamento de erros, organização
- **Avançado** – padrões usados no próprio 3bLinux, boas práticas e integração

O objetivo é que você consiga:

1. Ler e entender os scripts existentes do 3bLinux
2. Escrever seus próprios scripts de manutenção e automação
3. Evoluir o projeto com segurança

---

## 1. Parte Iniciante – Shell Script

### 1.1 Onde o shell é usado no 3bLinux

- Scripts de inicialização (`/sbin/init`, `/bin/bk-init-*`)
- Scripts de supervisão (`/bin/bk-supervise`, `sv`)
- Scripts de build de pacotes (`/packages/*/build.sh`)
- Utilitários de manutenção (`bk-reparo`, `bk-refresh-desktop`, etc.)

### 1.2 Execução básica

Um script shell geralmente começa com:

```sh
#!/usr/bin/env bash
```

Isso indica que o script deve ser executado com o `bash`.

Para criar e executar:

```sh
echo '#!/usr/bin/env bash
echo "Olá 3bLinux"' > /tmp/ola.sh
chmod +x /tmp/ola.sh
/tmp/ola.sh
```

### 1.3 Variáveis simples

```sh
NOME="3bLinux"
echo "Olá, $NOME"
```

- Sem espaço antes/depois do `=`
- Para ler do usuário:

```sh
read -r NOME
```

### 1.4 Testes e if

```sh
if [ -f /etc/hostname ]; then
  echo "Hostname existe"
else
  echo "Hostname não existe"
fi
```

### 1.5 Laços

```sh
for f in *.sh; do
  echo "Script: $f"
done
```

### 1.6 Funções básicas

```sh
diga_ola(){
  echo "Olá do 3bLinux"
}

diga_ola
```

---

## 2. Parte Intermediária – Shell Script no estilo 3bLinux

Os scripts do 3bLinux seguem um padrão para serem:

- Previsíveis
- Fáceis de debugar
- Compatíveis entre si

### 2.1 Cabeçalho padrão

```sh
#!/usr/bin/env bash
set -euo pipefail

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
die(){ echo "ERROR: $*" >&2; exit 1; }
```

- `set -euo pipefail`:
  - `-e`: para se algo falhar, o script para
  - `-u`: usar variável não setada dá erro
  - `-o pipefail`: erros em pipelines não são ignorados

- `b` / `bl`: escrevem em negrito, quando o terminal suporta

### 2.2 Organização em funções

Os scripts de build seguem:

```sh
prepare(){
  bl "=== prepare ==="
  # baixar fontes, preparar diretórios
}

build(){
  bl "=== build ==="
  # compilar
}

install(){
  bl "=== install ==="
  # instalar em $BK_STAGE_ROOT
}

main(){
  prepare
  build
  install
}

main "$@"
```

Esse padrão facilita:

- Reaproveitar partes
- Rodar só uma etapa (por exemplo, só `prepare` para debug)

### 2.3 Variáveis padrão BK_*

Nos scripts do 3bLinux você verá muitos `: "${VAR:=valor}"`:

```sh
: "${BK_JOBS:=1}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-meu-pacote}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
```

Significado:

- Se a variável **não existe**, recebe o valor padrão
- Se já existe (por quem chamou), o script respeita

Isso permite que o mesmo script rode:

- De forma “standalone”
- Dentro de um orquestrador maior (`bk-build-base`, `bk-build-xorg`, etc.)

---

## 3. Parte Avançada – Shell Script no 3bLinux

### 3.1 Supervisão de serviços (`bk-supervise` + `sv`)

Conceitos usados:

- `read_conf` lendo `|`-separado (`name|cmd|wd|user|...`)
- `pidfile` por serviço
- Loops periódicos (check de saúde)
- Integração com `is_service_enabled` e `/etc/bk-supervisor.enable`

Ao estudar `bk-supervise`, repare em:

- Uso de `while IFS= read -r line`
- Split de campos com `IFS='|' read -r ...`
- Funções como `start_one`, `stop_one`, `is_running_pid`

### 3.2 init / bk-init-*

Scripts de init:

- Cuidam de montar sistemas de arquivos
- Iniciar serviços em ordem
- Lidar com shutdown e reboot

Padrões importantes:

- Dividir passos em funções bem nomeadas
- Manter logs em `/var/log`
- Nunca repetir lógica; reutilizar funções compartilhadas

### 3.3 Boas práticas que o 3bLinux segue

- Nunca fazer `rm -rf /` (sempre checar diretórios)
- Sempre validar parâmetros de entrada
- Usar mensagens claras de erro (`die "mensagem"`)
- Manter scripts idempotentes (rodar duas vezes não quebra nada)

---

## 4. Python – Iniciante ao Avançado

Python é usado (ou pode ser usado) em:

- Scripts avançados de build
- Ferramentas de análise e geração de arquivos
- Integração com APIs e formatação de dados

### 4.1 Iniciante – Sintaxe básica

Exemplo:
```python
print("Olá 3bLinux")

x = 10
y = 20
print("Soma:", x + y)
```

### 4.2 Estruturas de controle

```python
for i in range(5):
    print("i =", i)

if x > 5:
    print("maior que 5")
else:
    print("menor ou igual a 5")
```

### 4.3 Funções

```python
def soma(a, b):
    return a + b

print(soma(2, 3))
```

---

## 5. Python Intermediário – Aplicado ao 3bLinux

### 5.1 Manipular arquivos de texto

```python
from pathlib import Path

p = Path("/etc/hostname")
conteudo = p.read_text(encoding="utf-8")
print(conteudo)
```

Escrever:

```python
p.write_text("3bLinux
", encoding="utf-8")
```

### 5.2 Geração de arquivos a partir de modelos

Python é excelente para:

- Gerar configurações repetitivas
- Elaborar listas grandes de pacotes
- Manter consistência

Exemplo simples:

```python
services = ["dbus", "NetworkManager", "lightdm"]
lines = ["# /etc/bk-supervisor.enable"]
for s in services:
    lines.append(f"{s}=yes")
Path("bk-supervisor.enable").write_text("\n".join(lines) + "\n", encoding="utf-8")
```

---

## 6. Python Avançado – Ideias para o 3bLinux

Algumas coisas que você pode fazer em Python para evoluir o projeto:

1. **Gerador de recipes**:
   - Ler uma lista de pacotes/versões
   - Gerar automaticamente `packages/<nome>/build.sh` com o template padrão

2. **Validador de consistência**:
   - Percorrer `/packages` e verificar:
     - se todos os scripts têm `set -euo pipefail`
     - se todos definem `BK_STAGE_ROOT`
     - se todos imprimem resumo no final

3. **Ferramentas de QA**:
   - Script que monta um chroot, executa testes básicos dos programas
   - Gera um relatório em `/Docs/relatorios/tests-YYYYMMDD.md`

---

## 7. Como praticar usando o próprio 3bLinux

### 7.1 Shell

- Clone seu repositório de configs (ou use `/etc` diretamente em uma VM)
- Crie scripts em `~/bin` para tarefas pessoais
- Estude os scripts existentes (`bk-*`, `init`, recipes em `/packages`)

### 7.2 Python

- Use um virtualenv (quando disponível)
- Experimente scripts em `/usr/local/src` ou `$HOME/projetos`
- Automatize algo real (por exemplo: geração de listas, logs ou configs)

---

## 8. Conclusão

- O 3bLinux foi pensado para ser **didático e hackável**
- Shell script continua sendo a “cola” principal do sistema
- Python é uma excelente arma para automação e geração de conteúdo

Comece pelo nível iniciante, leia os scripts reais do sistema e vá aos poucos
refatorando e criando novas ferramentas. O próprio 3bLinux é um “laboratório”
perfeito para você aprender e praticar.
