# Manutenção e Recuperação – 3bLinux

## Ferramentas

- bk-reparo
- bk-init-reparo
- bk-install

## Recuperar boot

```sh
bk-init-reparo --all
```

## Recriar initramfs

```sh
bk-initramfs
```

## Reinstalar desktop

```sh
bk-build-xorg
bk-build-xfce4
bk-build-browsers
```

## Atualizações seguras

Sempre prefira:

```sh
bk-update upgrade
```

Evite sobrescrever manualmente arquivos do sistema.
