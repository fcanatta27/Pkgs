\
# 3bLinux - Repositório de pacotes (bk-repo / bk-update)

Ferramentas:
- bk-repo   : organiza pacotes produzidos pelo bk-package em um repositório local
- bk-update : usa o repositório para listar/atualizar pacotes instalados

## Configuração

Edite: /etc/bk-repo.conf

Principais variáveis:
- BK_REPO_ROOT          (default: /var/3bLinux/repo)
- BK_REPO_STORE         (default: /var/3bLinux)
- BK_REPO_CHANNEL_DEFAULT (stable|unstable|both)
- BK_REPO_SYNC_CMD      (default: rsync -av --delete)
- BK_REPO_REMOTE_STABLE   (ex: user@host:/srv/3blinux/stable)
- BK_REPO_REMOTE_UNSTABLE (ex: user@host:/srv/3blinux/unstable)

## Uso típico

### 1) Inicializar layout

```sh
bk-repo init
```

Cria:
- /var/3bLinux/repo/stable/{pkgs,index}
- /var/3bLinux/repo/unstable/{pkgs,index}

### 2) Adicionar pacotes produzidos

Supondo que você já tenha pacotes .tar.gz criados pelo bk-package em /var/3bLinux:

```sh
# canal stable
bk-repo add --channel stable coreutils-9.9
bk-repo add --channel stable bash-5.3

# canal unstable
bk-repo add --channel unstable gcc-15.2.0
```

Ou passando arquivos diretamente:

```sh
bk-repo add-file --channel stable /var/3bLinux/coreutils-9.9.tar.gz
```

Isso copia para:
- /var/3bLinux/repo/stable/pkgs/*.tar.gz
e regenera o índice.

### 3) Sincronizar com repositório remoto

Após configurar BK_REPO_REMOTE_STABLE/UNSTABLE em /etc/bk-repo.conf:

```sh
bk-repo sync --channel stable
bk-repo sync --channel unstable
```

### 4) Atualizar e fazer upgrade de pacotes

No sistema cliente:

```sh
# sincroniza do remoto para o repositório local (depende do seu BK_REPO_SYNC_CMD)
bk-update update

# lista pacotes disponíveis no canal (por default, stable)
bk-update list

# lista pacotes instalados (usa DB de /var/lib/3bLinux/pkg)
bk-update installed

# faz upgrade de todos os pacotes instalados que tenham versão mais nova no repo
bk-update upgrade
```

