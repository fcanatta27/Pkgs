\
#!/usr/bin/env bash
set -euo pipefail

# Package: firefox
# Version: 147.0.1 (fonte)
#
# Dependencies (build/runtime aproximadas):
#   - rustc (>= 1.70+)
#   - clang/llvm
#   - nodejs, python3, pip
#   - gtk+3, dbus, libX11, libxcb, libXrender, libXt, fontconfig, freetype
#   - yasm/nasm
#
# Flags / opções:
#   - Usa ./mach build/install
#   - Este script é um blueprint; ajuste conforme o seu toolchain

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-firefox-147.0.1}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

: "${BK_FIREFOX_SRC_URL:=https://archive.mozilla.org/pub/firefox/releases/147.0.1/source/firefox-147.0.1.source.tar.xz}"

SRC_DIR="$BK_BUILD_DIR/src"
OBJ_DIR="$BK_BUILD_DIR/obj"

url_basename(){ local u="$1"; u="${u%%\?*}"; echo "$(basename "$u")"; }

fetch(){
  mkdir -p "$BK_DOWNLOAD_DIR"
  local url="$BK_FIREFOX_SRC_URL" base out
  base="$(url_basename "$url")"
  [ -n "$base" ] || base="firefox-147.0.1.source.tar.xz"
  out="$BK_DOWNLOAD_DIR/$base"
  if [ -s "$out" ]; then
    info "  Usando tarball em cache: $(b "$out")"
    echo "$out"; return 0
  fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
  else die "nem curl nem wget encontrados"; fi
  echo "$out"
}

prepare(){
  bl "=== firefox-147.0.1: prepare ==="
  rm -rf "$SRC_DIR" "$OBJ_DIR"
  mkdir -p "$SRC_DIR" "$OBJ_DIR"
  local tarball
  tarball="$(fetch)"
  tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
}

build(){
  bl "=== firefox-147.0.1: build ==="
  cd "$SRC_DIR"
  cat > .mozconfig <<EOF
mk_add_options MOZ_OBJDIR="$OBJ_DIR"
ac_add_options --prefix=/usr
ac_add_options --enable-application=browser
ac_add_options --disable-debug
ac_add_options --enable-optimize
EOF
  ./mach build -j"$BK_JOBS"
}

install(){
  bl "=== firefox-147.0.1: install (stage em $BK_STAGE_ROOT) ==="
  cd "$SRC_DIR"
  DESTDIR="$BK_STAGE_ROOT" ./mach install
}

main(){
  prepare
  build
  install
  bl "=== Summary firefox-147.0.1 ==="
  info "  Staged root: $BK_STAGE_ROOT"
}

main "$@"
