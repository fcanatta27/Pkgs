\
        #!/usr/bin/env bash
        set -euo pipefail

        # Package: GLU
        # Version: 9.0.3
        #
        # Dependencies (build/runtime) aproximadas:
        #   - mesa (headers GL)
        #   - libX11 (para build X11 se habilitado)
        #   - meson/ninja OU autotools (depende do tarball)
        #
        # Flags / opções:
        #   - Meson: opções variam conforme o projeto
        #   - Autotools: ./configure --prefix=/usr

        b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
        bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
        info(){ echo "$*"; }
        die(){ echo "ERROR: $*" >&2; exit 1; }

        : "${BK_JOBS:=1}"
        : "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
        : "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-GLU-9.0.3}}"
        : "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

        : "${BK_GLU_URL:=https://mesa.freedesktop.org/archive/glu-9.0.3.tar.xz}"

        SRC_DIR="$BK_BUILD_DIR/src"
        BUILD_DIR="$BK_BUILD_DIR/build"

        url_basename(){ local u="$1"; u="${u%%\?*}"; echo "$(basename "$u")"; }

        fetch(){
          mkdir -p "$BK_DOWNLOAD_DIR"
          local url="$BK_GLU_URL" base out
          base="$(url_basename "$url")"
          out="$BK_DOWNLOAD_DIR/$base"
          if [ -s "$out" ]; then info "  Usando tarball em cache: $(b "$out")"; echo "$out"; return 0; fi
          info "  Baixando: $(b "$url")"
          if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
          elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
          else die "nem curl nem wget encontrados"; fi
          echo "$out"
        }

        prepare(){
          bl "=== GLU-9.0.3: prepare ==="
          rm -rf "$SRC_DIR" "$BUILD_DIR"
          mkdir -p "$SRC_DIR" "$BUILD_DIR"
          local tarball
          tarball="$(fetch)"
          tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
        }

        build(){
          bl "=== GLU-9.0.3: build ==="
          if [ -f "$SRC_DIR/meson.build" ] && command -v meson >/dev/null 2>&1; then
            bl "  Usando meson/ninja"
            meson setup "$BUILD_DIR" --prefix=/usr --buildtype=release
            ninja -C "$BUILD_DIR" -j"$BK_JOBS"
            return 0
          fi
          bl "  Usando autotools (fallback)"
          cd "$SRC_DIR"
          ./configure --prefix=/usr
          make -j"$BK_JOBS"
        }

        install(){
          bl "=== GLU-9.0.3: install (stage em $BK_STAGE_ROOT) ==="
          if [ -f "$SRC_DIR/meson.build" ] && [ -f "$BUILD_DIR/build.ninja" ]; then
            DESTDIR="$BK_STAGE_ROOT" ninja -C "$BUILD_DIR" install
          else
            cd "$SRC_DIR"
            make DESTDIR="$BK_STAGE_ROOT" install
          fi
        }

        main(){
          prepare
          build
          install
          bl "=== Summary $(b GLU-9.0.3) ==="
          info "  Staged root: $(b "$BK_STAGE_ROOT")"
          info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
          info "  Headers... : $(b "$BK_STAGE_ROOT/usr/include")"
        }

        main "$@"
