#!/usr/bin/env bash
set -euo pipefail

# Package: libyajl
# Version: 2.1.0
#
# Tipo: JSON parser library
#
# Dependências (conceituais):
#   - toolchain C
#   - libc
#   - pkg-config (para detectar)
#
# Flags / opções suportadas (conceituais):
#   - opções padrão de ./configure
#
# Padrão 3bLinux: BK_STAGE_ROOT como DESTDIR

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
die(){ echo "ERROR: $*" >&2; exit 1; }
info(){ echo "  $*" >&2; }

: "${BK_JOBS:=1}"
: "${BK_BUILD_DIR:=/tmp/bk-build/libyajl-2.1.0}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/stage}"
: "${BK_SRC_ARCHIVES:=/var/3bLinux/src}"
: "${BK_DOWNLOAD_CMD:=curl -L}"

PKG_NAME="libyajl"
PKG_VERSION="2.1.0"
PKG_TARBALL="yajl-2.1.0.tar.gz"
PKG_URL="https://github.com/lloyd/yajl/archive/refs/tags/2.1.0.tar.gz"

prepare() {
  bl "=== $(b "$PKG_NAME-$PKG_VERSION"): prepare ==="
  mkdir -p "$BK_BUILD_DIR" "$BK_STAGE_ROOT" "$BK_SRC_ARCHIVES"
  cd "$BK_BUILD_DIR"
  if [ ! -f "$BK_SRC_ARCHIVES/$PKG_TARBALL" ]; then
    info "Baixando fonte: $PKG_URL"
    $BK_DOWNLOAD_CMD "$PKG_URL" -o "$BK_SRC_ARCHIVES/$PKG_TARBALL"
  fi
  rm -rf src
  mkdir -p src
  tar -xf "$BK_SRC_ARCHIVES/$PKG_TARBALL" -C src --strip-components=1 || tar -xf "$BK_SRC_ARCHIVES/$PKG_TARBALL" -C src || die "falha ao extrair"
}

build() {
  bl "=== $(b "$PKG_NAME-$PKG_VERSION"): build ==="
  cd "$BK_BUILD_DIR/src"
  ./configure --prefix=/usr \    --sysconfdir=/etc \    --localstatedir=/var
  make -j"$BK_JOBS"
}

install() {
  bl "=== $(b "$PKG_NAME-$PKG_VERSION"): install (DESTDIR=$BK_STAGE_ROOT) ==="
  cd "$BK_BUILD_DIR/src"
  make DESTDIR="$BK_STAGE_ROOT" install
}

main() {
  prepare
  build
  install
  bl "=== Summary $(b "$PKG_NAME-$PKG_VERSION") ==="
  info "  Stage em: $(b "$BK_STAGE_ROOT")"
}

main "$@"
