\
#!/usr/bin/env bash
set -euo pipefail

# Package: palemoon
# Version: 33.6.0 (blueprint)
#
# Dependencies (build):
#   - python3, nodejs (algumas ferramentas)
#   - clang/llvm ou gcc
#   - autoconf-2.13 (sim, frequentemente)
#   - nasm/yasm
#   - gtk+2/3 dependendo da config
#
# Observação:
#   Pale Moon usa a plataforma UXP e o processo é específico.
#   Este script fornece estrutura padrão 3bLinux e pontos de extensão.

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-palemoon-33.6.0}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
: "${BK_PALEMOON_URL:=https://www.palemoon.org/archived.shtml}"  # defina URL do source tarball

SRC_DIR="$BK_BUILD_DIR/src"

prepare(){
  bl "=== palemoon-33.6.0: prepare ==="
  mkdir -p "$SRC_DIR"
  info "  Defina BK_PALEMOON_URL para o tarball fonte exato do 33.6.0."
  die "blueprint: URL fonte não configurada"
}

main(){ prepare; }
main "$@"
