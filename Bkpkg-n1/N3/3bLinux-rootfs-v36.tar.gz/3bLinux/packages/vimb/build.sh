\
#!/usr/bin/env bash
set -euo pipefail

# Package: vimb
# Version: 3.7 (exemplo)
#
# Dependencies:
#   - gtk3
#   - webkit2gtk
#   - gcc, make, pkg-config
#
# Flags:
#   - PREFIX=/usr make

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-vimb}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
: "${BK_VIMB_URL:=https://github.com/fanglingsu/vimb/archive/refs/tags/3.7.tar.gz}"

SRC_DIR="$BK_BUILD_DIR/src"

url_basename(){ local u="$1"; u="${u%%\?*}"; echo "$(basename "$u")"; }
fetch(){
  mkdir -p "$BK_DOWNLOAD_DIR"
  local out="$BK_DOWNLOAD_DIR/$(url_basename "$BK_VIMB_URL")"
  if [ -s "$out" ]; then echo "$out"; return 0; fi
  if command -v curl >/dev/null 2>&1; then curl -L "$BK_VIMB_URL" -o "$out"
  elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$BK_VIMB_URL"
  else die "nem curl nem wget"; fi
  echo "$out"
}

prepare(){
  bl "=== vimb: prepare ==="
  rm -rf "$SRC_DIR"
  mkdir -p "$SRC_DIR"
  tar -xf "$(fetch)" -C "$SRC_DIR" --strip-components=1
}

build(){
  bl "=== vimb: build ==="
  cd "$SRC_DIR"
  make -j"$BK_JOBS"
}

install(){
  bl "=== vimb: install (stage) ==="
  cd "$SRC_DIR"
  make PREFIX=/usr DESTDIR="$BK_STAGE_ROOT" install
}

main(){ prepare; build; install; bl "=== Summary vimb ==="; }
main "$@"
