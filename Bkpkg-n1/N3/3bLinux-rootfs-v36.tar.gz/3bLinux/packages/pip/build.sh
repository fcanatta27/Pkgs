#!/usr/bin/env bash
set -euo pipefail

# Package: pip
# Version: 24.0
#
# Tipo: gerenciador de pacotes Python (pip)
#
# Dependências (conceituais):
#   - python3
#   - wheel (opcional para build)
#
# Flags / opções suportadas:
#   - instalação via pip usando --root=$BK_STAGE_ROOT
#
# Observação:
#   - Este script assume conectividade à internet ou cache local de pacotes.

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
die(){ echo "ERROR: $*" >&2; exit 1; }
info(){ echo "  $*" >&2; }

: "${BK_BUILD_DIR:=/tmp/bk-build/pip-24.0}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/stage}"

prepare(){
  bl "=== $(b pip-24.0): prepare ==="
  mkdir -p "$BK_BUILD_DIR" "$BK_STAGE_ROOT"
}

build(){
  bl "=== $(b pip-24.0): build (download wheel) ==="
  cd "$BK_BUILD_DIR"
  python3 -m pip download pip==24.0 -d .
  local whl
  whl="$(ls pip-24.0-*.whl | head -n1)"
  [ -n "$whl" ] || die "wheel do pip não encontrado"
  info "Usando wheel: $whl"
}

install(){
  bl "=== $(b pip-24.0): install (DESTDIR=$BK_STAGE_ROOT) ==="
  cd "$BK_BUILD_DIR"
  local whl
  whl="$(ls pip-24.0-*.whl | head -n1)"
  python3 -m pip install --no-deps --root "$BK_STAGE_ROOT" "$whl"
}

main(){
  prepare
  build
  install
  bl "=== Summary $(b pip-24.0) ==="
  info "  Stage em: $(b "$BK_STAGE_ROOT")"
}

main "$@"
