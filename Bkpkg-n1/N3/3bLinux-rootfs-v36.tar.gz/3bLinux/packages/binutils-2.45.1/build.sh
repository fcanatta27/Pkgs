#!/usr/bin/env bash
set -euo pipefail

# Package: binutils
# Version: 2.45.1
#
# Dependencies (host / build) aproximadas:
#   - bash, coreutils, findutils, grep, sed, gawk
#   - tar, xz, gzip, bzip2
#   - make, gcc, pkg-config
#   - curl ou wget
#
# Dependencies (runtime) aproximadas:
#   - libc (glibc), libstdc++, zlib, libgcc
#   - bibliotecas específicas deste pacote (use ldd no binário instalado)
#
# Flags suportadas (ambiente padrão do 3bLinux):
#   BK_JOBS           : paralelismo do make (default 1)
#   BK_DOWNLOAD_DIR   : diretório de cache de tarballs (default /tmp/bk-src)
#   BK_BUILD_DIR      : diretório base de build da receita
#   BK_STAGE_ROOT     : DESTDIR para instalação (conteúdo que será empacotado)
#   BK_*_URL          : URL do tarball da receita (quando definido)
#   BK_*_CONFIG_EXTRA : flags extras passadas para ./configure/meson/cmake/etc.
#
# Flags completas do programa:
#   Consulte:
#     - ./configure --help        (projetos autotools)
#     - meson configure           (projetos Meson)
#     - cmake -LH                 (projetos CMake)
#     - --help do binário final   (opções em tempo de execução)

IFS=$'\n\t'

BOLD="\033[1m"
RESET="\033[0m"
GREEN="\033[32m"
BLUE="\033[34m"
YELLOW="\033[33m"

bold() { printf "${BOLD}%s${RESET}\n" "$*"; }
info() { printf "%s\n" "$*"; }
note() { printf "%b%s%b\n" "$YELLOW" "$*" "$RESET"; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || { printf "ERRO: comando obrigatório não encontrado: %s\n" "$1" >&2; exit 1; }; }

# Defaults razoáveis usando as variáveis exportadas pelo orquestrador bk.
: "${BK_PKG_NAME:=binutils}"
: "${BK_PKG_VERSION:=2.45.1-pass1}"
: "${BK_RECIPE:=binutils-2.45.1-pass1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE}/build}"
: "${BK_STAGE_ROOT:=/tmp/bk-build/${BK_RECIPE}/root}"
: "${BK_JOBS:=$(nproc 2>/dev/null || echo 1)}"
: "${BK_TARGET:=$(uname -m)-linux-gnu}"
: "${BK_BINUTILS_CONFIG_EXTRA:=}"
: "${BK_BINUTILS_DISABLE_NLS:=1}"
: "${BK_KEEP_SOURCE:=0}"

SRC_VERSION_PURE="2.45.1"
TARBALL="binutils-${SRC_VERSION_PURE}.tar.xz"
SRC_URL="https://ftp.gnu.org/gnu/binutils/${TARBALL}"

SRC_BASE="${BK_BUILD_DIR%/}/src"
SRC_DIR="${SRC_BASE}/binutils-${SRC_VERSION_PURE}"
BUILD_DIR="${BK_BUILD_DIR%/}/build-pass1"

bold "=== Construção ${BK_PKG_NAME} ${BK_PKG_VERSION} (pass1) ==="
info "  Nome.......: ${BOLD}${BK_PKG_NAME}${RESET}"
info "  Versão.....: ${BOLD}${BK_PKG_VERSION}${RESET} (fonte: ${SRC_VERSION_PURE})"
info "  Recipe.....: ${BK_RECIPE}"
info "  Alvo.......: ${BOLD}${BK_TARGET}${RESET}"
info "  Download...: ${BOLD}${SRC_URL}${RESET}"
info "  Download dir: ${BOLD}${BK_DOWNLOAD_DIR}${RESET}"
info "  Build dir..: ${BOLD}${BUILD_DIR}${RESET}"
info "  Stage root.: ${BOLD}${BK_STAGE_ROOT}${RESET}"
info "  Jobs.......: ${BK_JOBS}"

# Garantir diretórios básicos
mkdir -p "${BK_DOWNLOAD_DIR}" "${SRC_BASE}" "${BUILD_DIR}" "${BK_STAGE_ROOT}"

# 1. Download do tarball
note "[1/4] Verificando tarball em cache..."
need_cmd sha256sum
if [[ ! -f "${BK_DOWNLOAD_DIR}/${TARBALL}" ]]; then
  note "Tarball não encontrado; tentando baixar em: ${BK_DOWNLOAD_DIR}/${TARBALL}"
  if command -v wget >/dev/null 2>&1; then
    wget -O "${BK_DOWNLOAD_DIR}/${TARBALL}" "${SRC_URL}"
  elif command -v curl >/dev/null 2>&1; then
    curl -L "${SRC_URL}" -o "${BK_DOWNLOAD_DIR}/${TARBALL}"
  else
    printf "ERRO: nem wget nem curl estão disponíveis para download.\n" >&2
    exit 1
  fi
else
  note "Tarball já está em cache: ${BK_DOWNLOAD_DIR}/${TARBALL}"
fi

# (Opcional) Aqui poderíamos validar SHA256 se tivéssemos o valor oficial.

# 2. Preparar árvore de fontes e build
note "[2/4] Preparando fontes e diretórios de build..."
rm -rf "${SRC_DIR}" "${BUILD_DIR}" "${BK_STAGE_ROOT}"/*
mkdir -p "${SRC_BASE}" "${BUILD_DIR}" "${BK_STAGE_ROOT}"

tar -xf "${BK_DOWNLOAD_DIR}/${TARBALL}" -C "${SRC_BASE}"

# 3. Configuração e compilação
note "[3/4] Configurando e compilando binutils (pass1)..."
need_cmd make

cd "${BUILD_DIR}"

CONFIG_NLS=""
if [[ "${BK_BINUTILS_DISABLE_NLS}" = "1" ]]; then
  CONFIG_NLS="--disable-nls"
fi

"${SRC_DIR}/configure" \
  --prefix=/usr \
  --target="${BK_TARGET}" \
  --with-sysroot \
  ${CONFIG_NLS} \
  --disable-werror \
  ${BK_BINUTILS_CONFIG_EXTRA}

make -j"${BK_JOBS}"

# 4. Instalação em /tmp (DESTDIR)
note "[4/4] Instalando em DESTDIR (stage root)..."
make DESTDIR="${BK_STAGE_ROOT}" install

# Opcional: ajustes típicos de pass1 poderiam ser feitos aqui (strip, remoção de docs, etc.)

bold "=== Resumo da construção ${BK_PKG_NAME} ${BK_PKG_VERSION} ==="
info "  Stage root (DESTDIR): ${BOLD}${BK_STAGE_ROOT}${RESET}"
info "  Binários principais (dentro do pacote):"
info "    ${BOLD}${BK_STAGE_ROOT}/usr/bin/ar${RESET} (se presente)"
info "    ${BOLD}${BK_STAGE_ROOT}/usr/bin/ld${RESET} (ou variantes, conforme alvo)"
info "    ${BOLD}${BK_STAGE_ROOT}/usr/bin/nm${RESET}"

if [[ "${BK_KEEP_SOURCE}" != "1" ]]; then
  rm -rf "${SRC_DIR}"
fi

bold "Build finalizado com sucesso para ${BK_PKG_NAME} ${BK_PKG_VERSION}."
