    #!/usr/bin/env bash
    set -euo pipefail

    # Package: Xfconf
    # Version: 4.20.0
    #
    # Dependencies (build/runtime) aproximadas:
    #   - glib2
#   - dbus
#   - libxfce4util
#
    # Flags / opções de compilação:
    #   - ./configure --prefix=/usr --sysconfdir=/etc
#
    # Padrão 3bLinux:
    #   - BK_STAGE_ROOT como DESTDIR
    #   - build em /tmp/bk-build
    #   - idempotente (reexecutável)

    b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
    bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
    info(){ echo "$*"; }
    die(){ echo "ERROR: $*" >&2; exit 1; }

    : "${BK_JOBS:=1}"
    : "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
    : "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-Xfconf-4.20.0}}"
    : "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

    : "${BK_XFCONF_URL:=https://archive.xfce.org/src/xfce/xfconf/4.20/xfconf-4.20.0.tar.bz2}"

    SRC_DIR="$BK_BUILD_DIR/src"
    BUILD_DIR="$BK_BUILD_DIR/build"

    url_basename() {
      local u="$1"
      u="${u%%\?*}"
      echo "$(basename "$u")"
    }

    fetch(){
      mkdir -p "$BK_DOWNLOAD_DIR"
      local url="${BK_XFCONF_URL}"
      local base
      base="$(url_basename "$url")"
      local out="$BK_DOWNLOAD_DIR/$base"
      if [ -s "$out" ]; then
        info "  Usando tarball em cache: $(b "$out")"
        echo "$out"
        return 0
      fi
      info "  Baixando: $(b "$url")"
      if command -v curl >/dev/null 2>&1; then
        curl -L "$url" -o "$out"
      elif command -v wget >/dev/null 2>&1; then
        wget -O "$out" "$url"
      else
        die "nem curl nem wget encontrados"
      fi
      echo "$out"
    }

    prepare(){
      bl "=== Xfconf-4.20.0: prepare ==="
      mkdir -p "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR"
      rm -rf "$SRC_DIR" "$BUILD_DIR"
      mkdir -p "$SRC_DIR" "$BUILD_DIR"
      local tarball
      tarball="$(fetch)"
      tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
    }

    build(){
      bl "=== Xfconf-4.20.0: build ==="
      cd "$SRC_DIR"
      ./configure --prefix=/usr --sysconfdir=/etc
      make -j"$BK_JOBS"
    }

    install(){
      bl "=== Xfconf-4.20.0: install (stage em $BK_STAGE_ROOT) ==="
      cd "$SRC_DIR"
      make DESTDIR="$BK_STAGE_ROOT" install
    }

    main(){
      prepare
      build
      install
      bl "=== Summary $(b Xfconf-4.20.0) ==="
      info "  Staged root: $(b "$BK_STAGE_ROOT")"
      info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin")"
      info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
      info "  Headers... : $(b "$BK_STAGE_ROOT/usr/include")"
      info "  Data...... : $(b "$BK_STAGE_ROOT/usr/share")"
    }

    main "$@"
