    #!/usr/bin/env bash
    set -euo pipefail

    # Package: libpng
    # Version: 1.6.50
    #
    # Dependencies (build/runtime) aproximadas:
    #   - zlib
#
    # Flags / opções de compilação:
    #   - ./configure --prefix=/usr
#
    # Padrão 3bLinux:
    #   - BK_STAGE_ROOT como DESTDIR
    #   - build em /tmp/bk-build
    #   - idempotente (reexecutável)

    b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
    bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
    info(){ echo "$*"; }
    die(){ echo "ERROR: $*" >&2; exit 1; }

    : "${BK_JOBS:=1}"
    : "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
    : "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-libpng-1.6.50}}"
    : "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

    : "${BK_LIBPNG_URL:=https://download.sourceforge.net/libpng/libpng-1.6.50.tar.xz}"

    SRC_DIR="$BK_BUILD_DIR/src"
    BUILD_DIR="$BK_BUILD_DIR/build"

    url_basename() {
      local u="$1"
      u="${u%%\?*}"
      echo "$(basename "$u")"
    }

    fetch(){
      mkdir -p "$BK_DOWNLOAD_DIR"
      local url="${BK_LIBPNG_URL}"
      local base
      base="$(url_basename "$url")"
      local out="$BK_DOWNLOAD_DIR/$base"
      if [ -s "$out" ]; then
        info "  Usando tarball em cache: $(b "$out")"
        echo "$out"
        return 0
      fi
      info "  Baixando: $(b "$url")"
      if command -v curl >/dev/null 2>&1; then
        curl -L "$url" -o "$out"
      elif command -v wget >/dev/null 2>&1; then
        wget -O "$out" "$url"
      else
        die "nem curl nem wget encontrados"
      fi
      echo "$out"
    }

    prepare(){
      bl "=== libpng-1.6.50: prepare ==="
      mkdir -p "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR"
      rm -rf "$SRC_DIR" "$BUILD_DIR"
      mkdir -p "$SRC_DIR" "$BUILD_DIR"
      local tarball
      tarball="$(fetch)"
      tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
    }

    build(){
      bl "=== libpng-1.6.50: build ==="
      cd "$SRC_DIR"
      ./configure --prefix=/usr
      make -j"$BK_JOBS"
    }

    install(){
      bl "=== libpng-1.6.50: install (stage em $BK_STAGE_ROOT) ==="
      cd "$SRC_DIR"
      make DESTDIR="$BK_STAGE_ROOT" install
    }

    main(){
      prepare
      build
      install
      bl "=== Summary $(b libpng-1.6.50) ==="
      info "  Staged root: $(b "$BK_STAGE_ROOT")"
      info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin")"
      info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
      info "  Headers... : $(b "$BK_STAGE_ROOT/usr/include")"
      info "  Data...... : $(b "$BK_STAGE_ROOT/usr/share")"
    }

    main "$@"
