\
#!/usr/bin/env bash
set -euo pipefail

# Package: brave-browser
# Version: 1.86.139 (binário)
#
# Dependencies (runtime):
#   - gtk3, nss, nspr, libx11, libxcb, libxss, libxrandr, libdrm, mesa
#
# Flags:
#   - BK_BRAVE_URL (zip/tar oficial/mirror)

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-brave-1.86.139}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
: "${BK_BRAVE_URL:=https://sourceforge.net/projects/brave-browser.mirror/files/v1.86.139/brave-browser-1.86.139-linux-amd64.zip/download}"

SRC_DIR="$BK_BUILD_DIR/src"

fetch(){
  mkdir -p "$BK_DOWNLOAD_DIR"
  local out="$BK_DOWNLOAD_DIR/brave-browser-1.86.139-linux-amd64.zip"
  if [ -s "$out" ]; then
    info "  Usando cache: $(b "$out")"
    echo "$out"; return 0
  fi
  info "  Baixando: $(b "$BK_BRAVE_URL")"
  if command -v curl >/dev/null 2>&1; then curl -L "$BK_BRAVE_URL" -o "$out"
  elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$BK_BRAVE_URL"
  else die "nem curl nem wget"; fi
  echo "$out"
}

prepare(){
  bl "=== brave-1.86.139: prepare ==="
  rm -rf "$SRC_DIR"
  mkdir -p "$SRC_DIR"
  local zipf
  zipf="$(fetch)"
  command -v unzip >/dev/null 2>&1 || die "unzip não encontrado"
  unzip -q "$zipf" -d "$SRC_DIR"
}

install(){
  bl "=== brave-1.86.139: install (stage) ==="
  mkdir -p "$BK_STAGE_ROOT/opt"
  # o zip geralmente contém um diretório brave-browser/
  local dir
  dir="$(find "$SRC_DIR" -maxdepth 2 -type d -name 'brave*' | head -n1 || true)"
  [ -n "$dir" ] || die "não encontrei diretório brave no zip"
  cp -a "$dir" "$BK_STAGE_ROOT/opt/brave-1.86.139"
  mkdir -p "$BK_STAGE_ROOT/usr/bin"
  ln -sf /opt/brave-1.86.139/brave-browser "$BK_STAGE_ROOT/usr/bin/brave" || true
}

main(){ prepare; install; bl "=== Summary brave ==="; info "  Staged: $BK_STAGE_ROOT"; }
main "$@"
