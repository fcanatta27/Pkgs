    #!/usr/bin/env bash
    set -euo pipefail

    # Package: ristretto
    # Version: 0.13.4
    #
    # Dependencies (build/runtime) aproximadas:
    #   - gtk+3
#   - exo
#   - libxfce4ui
#   - gdk-pixbuf
#
    # Flags / opções (configure/make):
    #   - ./configure --prefix=/usr
#
    # Padrão 3bLinux: BK_STAGE_ROOT como DESTDIR

    b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
    bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
    info(){ echo "$*"; }
    die(){ echo "ERROR: $*" >&2; exit 1; }

    : "${BK_JOBS:=1}"
    : "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
    : "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-ristretto-0.13.4}}"
    : "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

    : "${BK_RISTRETTO_URL:=https://archive.xfce.org/src/apps/ristretto/0.13/ristretto-0.13.4.tar.bz2}"

    SRC_DIR="$BK_BUILD_DIR/src"

    url_basename(){ local u="$1"; u="${u%%\?*}"; echo "$(basename "$u")"; }

    fetch(){
      mkdir -p "$BK_DOWNLOAD_DIR"
      local url="${BK_RISTRETTO_URL}"
      local base out
      base="$(url_basename "$url")"
      out="$BK_DOWNLOAD_DIR/$base"
      if [ -s "$out" ]; then info "  Usando tarball em cache: $(b "$out")"; echo "$out"; return 0; fi
      info "  Baixando: $(b "$url")"
      if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
      elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
      else die "nem curl nem wget encontrados"; fi
      echo "$out"
    }

    prepare(){
      bl "=== ristretto-0.13.4: prepare ==="
      rm -rf "$SRC_DIR"
      mkdir -p "$SRC_DIR"
      local tarball
      tarball="$(fetch)"
      tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
    }

    build(){
      bl "=== ristretto-0.13.4: build ==="
      cd "$SRC_DIR"
      ./configure --prefix=/usr
      make -j"$BK_JOBS"
    }

    install(){
      bl "=== ristretto-0.13.4: install (stage em $BK_STAGE_ROOT) ==="
      cd "$SRC_DIR"
      make DESTDIR="$BK_STAGE_ROOT" install
    }

    main(){
      prepare
      build
      install
      bl "=== Summary $(b ristretto-0.13.4) ==="
      info "  Staged root: $(b "$BK_STAGE_ROOT")"
      info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin")"
      info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
    }

    main "$@"
