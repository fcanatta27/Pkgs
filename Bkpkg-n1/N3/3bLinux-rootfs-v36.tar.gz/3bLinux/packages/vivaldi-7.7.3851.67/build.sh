\
#!/usr/bin/env bash
set -euo pipefail

# Package: vivaldi-stable
# Version: 7.7.3851.67 (binário .deb)
#
# Dependencies (runtime):
#   - gtk3, nss, nspr, libx11, libxcb, libxss, libxrandr, libdrm, mesa
#
# Flags:
#   - BK_VIVALDI_DEB_URL (ajuste para o download oficial da versão)

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-vivaldi-7.7.3851.67}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
: "${BK_VIVALDI_DEB_URL:=https://vivaldi.com/download/archive/?platform=linux}"  # defina a URL direta do .deb

SRC_DIR="$BK_BUILD_DIR/src"

fetch(){
  mkdir -p "$BK_DOWNLOAD_DIR"
  local url="$BK_VIVALDI_DEB_URL"
  local out="$BK_DOWNLOAD_DIR/vivaldi_7.7.3851.67_amd64.deb"
  if [ -s "$out" ]; then
    info "  Usando cache: $(b "$out")"
    echo "$out"; return 0
  fi
  info "  Baixando (ajuste BK_VIVALDI_DEB_URL para URL direta do .deb): $(b "$url")"
  if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
  else die "nem curl nem wget"; fi
  echo "$out"
}

prepare(){
  bl "=== vivaldi-7.7.3851.67: prepare ==="
  rm -rf "$SRC_DIR"
  mkdir -p "$SRC_DIR"
  local deb
  deb="$(fetch)"
  command -v ar >/dev/null 2>&1 || die "ar não encontrado (binutils)"
  ( cd "$SRC_DIR" && ar x "$deb" )
  mkdir -p "$SRC_DIR/data"
  tar -xf "$SRC_DIR/data.tar."* -C "$SRC_DIR/data"
}

install(){
  bl "=== vivaldi-7.7.3851.67: install (stage) ==="
  cp -a "$SRC_DIR/data/." "$BK_STAGE_ROOT/"
}

main(){ prepare; install; bl "=== Summary vivaldi ==="; info "  Staged: $BK_STAGE_ROOT"; }
main "$@"
