    #!/usr/bin/env bash
    set -euo pipefail

    # Package: xfce4-indicator-plugin
    # Version: 2.4.0
    #
    # Dependencies (build/runtime) aproximadas:
    #   - libindicator (dep externa)
#   - gtk+3
#   - xfce4-panel
#
    # Flags / opções (configure/make):
    #   - ./configure --prefix=/usr
#
    # Padrão 3bLinux: BK_STAGE_ROOT como DESTDIR

    b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
    bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
    info(){ echo "$*"; }
    die(){ echo "ERROR: $*" >&2; exit 1; }

    : "${BK_JOBS:=1}"
    : "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
    : "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-xfce4-indicator-plugin-2.4.0}}"
    : "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

    : "${BK_XFCE4_INDICATOR_URL:=https://archive.xfce.org/src/panel-plugins/xfce4-indicator-plugin/2.4/xfce4-indicator-plugin-2.4.0.tar.bz2}"

    SRC_DIR="$BK_BUILD_DIR/src"

    url_basename(){ local u="$1"; u="${u%%\?*}"; echo "$(basename "$u")"; }

    fetch(){
      mkdir -p "$BK_DOWNLOAD_DIR"
      local url="${BK_XFCE4_INDICATOR_URL}"
      local base out
      base="$(url_basename "$url")"
      out="$BK_DOWNLOAD_DIR/$base"
      if [ -s "$out" ]; then info "  Usando tarball em cache: $(b "$out")"; echo "$out"; return 0; fi
      info "  Baixando: $(b "$url")"
      if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
      elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
      else die "nem curl nem wget encontrados"; fi
      echo "$out"
    }

    prepare(){
      bl "=== xfce4-indicator-plugin-2.4.0: prepare ==="
      rm -rf "$SRC_DIR"
      mkdir -p "$SRC_DIR"
      local tarball
      tarball="$(fetch)"
      tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
    }

    build(){
      bl "=== xfce4-indicator-plugin-2.4.0: build ==="
      cd "$SRC_DIR"
      ./configure --prefix=/usr
      make -j"$BK_JOBS"
    }

    install(){
      bl "=== xfce4-indicator-plugin-2.4.0: install (stage em $BK_STAGE_ROOT) ==="
      cd "$SRC_DIR"
      make DESTDIR="$BK_STAGE_ROOT" install
    }

    main(){
      prepare
      build
      install
      bl "=== Summary $(b xfce4-indicator-plugin-2.4.0) ==="
      info "  Staged root: $(b "$BK_STAGE_ROOT")"
      info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin")"
      info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
    }

    main "$@"
