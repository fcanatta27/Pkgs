\
#!/usr/bin/env bash
set -euo pipefail

# Package: Xorg-Server
# Version: 21.1.21
#
# Dependencies (build/runtime) (simplificado):
#   - xorgproto, util-macros
#   - libX11, libXext, libXfont2, pixman, libxcb, libXau, libXdmcp
#   - libdrm (para modesetting/DRI), mesa (para GLX se habilitado)
#   - libepoxy (GLX), libunwind (opcional), systemd/elogind (opcional)
#
# Flags / opções de compilação (configure):
#   - --enable-glx / --disable-glx
#   - --enable-dri / --disable-dri
#   - --enable-dri2 / --disable-dri2
#   - --enable-dri3 / --disable-dri3
#   - --enable-xwayland (se aplicável)
#   - --with-default-font-path=...
#
# Nota:
#   Ajuste os --enable-* conforme seu stack (Mesa/DRM/etc).

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-Xorg-Server-21.1.21}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

: "${BK_XORG_SERVER_URL:=https://www.x.org/pub/individual/xserver/xorg-server-21.1.21.tar.xz}"

SRC_TAR="$BK_DOWNLOAD_DIR/Xorg-Server-21.1.21.tar.xz"
SRC_DIR="$BK_BUILD_DIR/src"
BUILD_DIR="$BK_BUILD_DIR/build"

fetch(){
  local url="$BK_XORG_SERVER_URL" out="$SRC_TAR"
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then info "  Usando tarball em cache: $(b "$out")"; return 0; fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
  else die "nem curl nem wget encontrados"; fi
}

prepare(){
  bl "=== Xorg-Server-21.1.21: prepare ==="
  mkdir -p "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR" "$BK_DOWNLOAD_DIR"
  fetch
  rm -rf "$SRC_DIR" "$BUILD_DIR"
  mkdir -p "$SRC_DIR" "$BUILD_DIR"
  tar -xf "$SRC_TAR" -C "$SRC_DIR" --strip-components=1
}

build(){
  bl "=== Xorg-Server-21.1.21: build ==="
  cd "$SRC_DIR"
  ./configure --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --enable-glx \
    --enable-dri \
    --enable-dri2 \
    --enable-dri3 \
    --enable-xorg \
    --disable-xvfb \
    --disable-xnest \
    --disable-xdmcp \
    --with-default-font-path=/usr/share/fonts/misc,/usr/share/fonts/TTF,/usr/share/fonts/OTF,/usr/share/fonts/Type1,/usr/share/fonts/100dpi,/usr/share/fonts/75dpi
  make -j"$BK_JOBS"
}

install(){
  bl "=== Xorg-Server-21.1.21: install (stage em $BK_STAGE_ROOT) ==="
  cd "$SRC_DIR"
  make DESTDIR="$BK_STAGE_ROOT" install
}

main(){
  prepare
  build
  install
  bl "=== Summary $(b Xorg-Server-21.1.21) ==="
  info "  Staged root: $(b "$BK_STAGE_ROOT")"
  info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin")"
  info "  Xorg...... : $(b "$BK_STAGE_ROOT/usr/bin/Xorg")"
}

main "$@"
