\
#!/usr/bin/env bash
set -euo pipefail

# Package: Mesa
# Version: 25.3.1
#
# Dependencies (simplificado):
#   - LLVM/clang (para alguns drivers)
#   - libdrm, wayland, X11, etc. (dependendo dos drivers)
#   - meson, ninja, pkg-config
#
# Este script fornece um setup básico para drivers Gallium e GLX,
# devendo ser ajustado conforme o hardware/stack gráfico desejado.

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-Mesa-25.3.1}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

: "${BK_MESA_URL:=https://mesa.freedesktop.org/archive/mesa-25.3.1.tar.xz}"

SRC_TAR="$BK_DOWNLOAD_DIR/mesa-25.3.1.tar.xz"
SRC_DIR="$BK_BUILD_DIR/src"
BUILD_DIR="$BK_BUILD_DIR/build"

fetch(){
  local url="$BK_MESA_URL" out="$SRC_TAR"
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then
    info "  Usando tarball em cache: $(b "$out")"
    return 0
  fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then
    curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    die "nem curl nem wget encontrados"
  fi
}

prepare(){
  bl "=== Mesa-25.3.1: prepare ==="
  mkdir -p "$BK_DOWNLOAD_DIR" "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR"
  fetch
  rm -rf "$SRC_DIR" "$BUILD_DIR"
  mkdir -p "$SRC_DIR" "$BUILD_DIR"
  tar -xf "$SRC_TAR" -C "$SRC_DIR" --strip-components=1
}

build(){
  bl "=== Mesa-25.3.1: build ==="
  cd "$SRC_DIR"
  meson setup "$BUILD_DIR" \
    --prefix=/usr \
    --buildtype=release
  ninja -C "$BUILD_DIR" -j"$BK_JOBS"
}

install(){
  bl "=== Mesa-25.3.1: install (stage em $BK_STAGE_ROOT) ==="
  cd "$SRC_DIR"
  DESTDIR="$BK_STAGE_ROOT" ninja -C "$BUILD_DIR" install
}

main(){
  prepare
  build
  install

  bl "=== Summary $(b Mesa-25.3.1) ==="
  info "  Staged root: $(b "$BK_STAGE_ROOT")"
  info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
}

main "$@"
