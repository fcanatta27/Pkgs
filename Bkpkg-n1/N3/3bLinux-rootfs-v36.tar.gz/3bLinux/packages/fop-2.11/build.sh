\
#!/usr/bin/env bash
set -euo pipefail

# Package: fop
# Version: 2.11
#
# Dependencies:
#   - Java (JRE/JDK)
#   - Ant (para build a partir do código-fonte)
#
# Este script fornece apenas um esqueleto simples,
# assumindo que o tarball já vem com binários pré-buildados
# ou que você ajustará o processo de build com Ant conforme necessário.

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-fop-2.11}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

: "${BK_FOP_URL:=https://downloads.apache.org/fop/binaries/fop-2.11-bin.tar.gz}"

SRC_TAR="$BK_DOWNLOAD_DIR/fop-2.11.tar.gz"
SRC_DIR="$BK_BUILD_DIR/src"

fetch(){
  local url="$BK_FOP_URL" out="$SRC_TAR"
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then
    info "  Usando tarball em cache: $(b "$out")"
    return 0
  fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then
    curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    die "nem curl nem wget encontrados"
  fi
}

prepare(){
  bl "=== fop-2.11: prepare ==="
  mkdir -p "$BK_DOWNLOAD_DIR" "$BK_BUILD_DIR" "$SRC_DIR"
  fetch
  rm -rf "$SRC_DIR"
  mkdir -p "$SRC_DIR"
  tar -xf "$SRC_TAR" -C "$SRC_DIR" --strip-components=1
}

install(){
  bl "=== fop-2.11: install (stage em $BK_STAGE_ROOT) ==="
  mkdir -p "$BK_STAGE_ROOT/opt/fop-2.11"
  cp -a "$SRC_DIR"/* "$BK_STAGE_ROOT/opt/fop-2.11/"
  mkdir -p "$BK_STAGE_ROOT/usr/bin"
  cat > "$BK_STAGE_ROOT/usr/bin/fop" <<'EOF'
#!/usr/bin/env sh
exec java -jar /opt/fop-2.11/fop.jar "$@"
EOF
  chmod 0755 "$BK_STAGE_ROOT/usr/bin/fop"
}

main(){
  prepare
  install

  bl "=== Summary $(b fop-2.11) ==="
  info "  Staged root: $(b "$BK_STAGE_ROOT")"
  info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin/fop")"
}

main "$@"
