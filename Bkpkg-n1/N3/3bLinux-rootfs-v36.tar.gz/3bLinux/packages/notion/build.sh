\
#!/usr/bin/env bash
set -euo pipefail

# Package: notion
# Version: 4.0.2 (exemplo)
#
# Dependencies:
#   - X11 libs
#   - lua (em algumas builds)
#   - gcc, make, pkg-config

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-notion-4.0.2}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

: "${BK_NOTION_URL:=https://github.com/raboof/notion/archive/refs/tags/4.0.2.tar.gz}"

SRC_DIR="$BK_BUILD_DIR/src"

url_basename(){ local u="$1"; u="${u%%\?*}"; echo "$(basename "$u")"; }

fetch(){
  mkdir -p "$BK_DOWNLOAD_DIR"
  local url="$BK_NOTION_URL" base out
  base="$(url_basename "$url")"
  out="$BK_DOWNLOAD_DIR/$base"
  if [ -s "$out" ]; then
    info "  Usando tarball em cache: $(b "$out")"
    echo "$out"; return 0
  fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
  else die "nem curl nem wget encontrados"; fi
  echo "$out"
}

prepare(){
  bl "=== notion: prepare ==="
  rm -rf "$SRC_DIR"
  mkdir -p "$SRC_DIR"
  local tarball
  tarball="$(fetch)"
  tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
}

build(){
  bl "=== notion: build ==="
  cd "$SRC_DIR"
  ./configure --prefix=/usr
  make -j"$BK_JOBS"
}

install(){
  bl "=== notion: install (stage em $BK_STAGE_ROOT) ==="
  cd "$SRC_DIR"
  make DESTDIR="$BK_STAGE_ROOT" install
}

main(){
  prepare
  build
  install
  bl "=== Summary notion ==="
  info "  Staged root: $BK_STAGE_ROOT"
}

main "$@"
