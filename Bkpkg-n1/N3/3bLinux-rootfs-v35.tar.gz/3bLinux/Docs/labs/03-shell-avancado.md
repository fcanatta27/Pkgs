# Lab 03 – Shell Avançado
Objetivo: compreender init e serviços.

- init do 3bLinux
- bk-supervise
- sv

Exercício:
Desative e reative um serviço.
