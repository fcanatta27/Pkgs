# Lab 01 – Shell Básico
Objetivo: aprender a usar o terminal no 3bLinux.

Conteúdo:
- ls, cp, mv, rm, cat
- permissões (chmod, chown)
- PATH e scripts

Exercício:
Crie ~/bin/ola.sh e execute.
