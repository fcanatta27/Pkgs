\
# Guia 3bLinux: do zero até XFCE4 pronto

Este documento descreve o fluxo recomendado para ir **do zero** até um
desktop **XFCE4 completo** usando as ferramentas do 3bLinux:

- `bk-init`
- `bk-init-reparo`
- `bk-reparo`
- `bk-build-xorg`
- `bk-build-xfce4`
- `bk-supervise` + `bk-supervisor.conf`

## 1. Preparar o rootfs base

1. Monte o rootfs do 3bLinux em algum diretório (exemplo `/mnt/3bLinux`).
2. Chroot usando o helper `bk`/`bk-chroot` que já fazem o bind dos pseudo-fs.

Dentro do host:

```bash
# Exemplo (ajuste caminhos):
mkdir -p /mnt/3bLinux
tar -xvf 3bLinux-rootfs-v26.tar.gz -C /mnt/3bLinux
# agora você tem /mnt/3bLinux/3bLinux como rootfs
```

Depois, use o wrapper que você já definiu (por exemplo):

```bash
cd /mnt/3bLinux/3bLinux
bin/bk-chroot   # entra no chroot com /dev,/proc,/sys montados
```

> Se não estiver usando `bk-chroot`, certifique-se de fazer os binds
> manualmente: `/dev`, `/proc`, `/sys`, `/run` e o que mais precisar.

## 2. Inicializar estrutura mínima com bk-init

Dentro do chroot (3bLinux):

```bash
bk-init
```

O que `bk-init` faz:

- Garante diretórios básicos (`/bin`, `/sbin`, `/etc`, `/usr`, `/var`, `/tmp`).
- Cria `/etc/profile` com PATH e prompt padrão.
- Cria `/etc/passwd` e `/etc/group` mínimos (root).
- Cria estrutura de store `/var/3bLinux` e `/var/lib/3bLinux/pkg`.

Você pode rodar `bk-init` quantas vezes quiser (idempotente).

## 3. Verificar e reparar base com bk-init-reparo

Ainda dentro do chroot:

```bash
bk-init-reparo
```

Ou, se quiser apenas ver o que seria feito:

```bash
bk-init-reparo --dry-run
```

`bk-init-reparo` verifica e corrige:

- Estrutura de diretórios (`/tmp`, `/var/tmp`, `/var/log` etc.) e sticky bit.
- Presença de `/sbin/init` (linkando para `busybox` se necessário).
- Presença de `/initramfs/init` básico para uso em initramfs.
- Estrutura mínima de `/boot/grub` (stub de `grub.cfg` se ainda não existir).

Se quiser evitar tocar no GRUB dentro do rootfs:

```bash
bk-init-reparo --no-grub
```

## 4. Saúde geral do sistema com bk-reparo

Use o `bk-reparo` para fazer sanity-check geral:

```bash
bk-reparo check        # só verifica
bk-reparo full         # verifica e corrige (core + perms + serviços)
```

O que é verificado/corrigido:

- Diretórios básicos e permissões (incluindo `1777` em `/tmp` e `/var/tmp`).
- `init` presente e executável.
- Serviços essenciais presentes:
  - udev (eudev)
  - dbus-daemon
  - NetworkManager ou dhcpcd
  - ntpd (se instalado)
- Arquivos de config essenciais:
  - `/etc/NetworkManager/NetworkManager.conf` (stub seguro)
  - `/etc/ntp.conf` (se `ntpd` existir)
  - diretório `/etc/3binit.d` para hooks de init
  - diretório `/etc/3bservices.d` para serviços

Além disso, `bk-reparo` registra log em:

```text
/var/log/bk-reparo.log
```

## 5. Construir e configurar Xorg com bk-build-xorg

Com a base ok, construa o Xorg completo:

```bash
bk-build-xorg
```

O que o script faz:

1. Garante listas padrão:

   - `/etc/3bLinux/xorg-libs.list`
   - `/etc/3bLinux/xorg-apps.list`

2. Constrói, na ordem correta (via `bk`):

   - libs Xorg (bundle `Xorg-Libraries`)
   - DRM/Mesa:
     - `Libdrm-2.4.131`
     - `Mesa-25.3.1`
   - fontes e libs de render:
     - `FreeType-2.14.1`
     - `Fontconfig-2.17.1`
   - servidor Xorg:
     - `Xorg-Server-21.1.21`
   - aplicações básicas:
     - `Xorg-Applications`
     - fontes X e bitmaps (font-*, xbitmaps, etc.)

3. Cria configuração padrão do Xorg em:

   ```text
   /etc/X11/xorg.conf.d/00-keyboard.conf
   /etc/X11/xorg.conf.d/30-touchpad.conf
   ```

   Com teclado ABNT2 e touchpad libinput com tap habilitado.

Depois do `bk-build-xorg`, você já deve ter:

- Binários X (`/usr/bin/Xorg`, `xinit`, etc.).
- Bibliotecas X.
- Config de entrada teclado/touchpad.

## 6. Construir XFCE4 + LightDM com bk-build-xfce4

Agora, construa o desktop XFCE4 completo:

```bash
bk-build-xfce4
```

O que este script faz:

1. **Garante Xorg:**

   - Se `bk-build-xorg` existir, chama antes de tudo.
   - Senão, assume que Xorg já está pronto.

2. **Constrói libs centrais XFCE:**

   - `libxfce4util-4.20.1`
   - `Xfconf-4.20.0`
   - `libxfce4ui-4.20.2`
   - `Exo-4.20.0`
   - `Garcon-4.20.0`
   - `libxfce4windowing-4.20.5`

3. **Constrói o core da sessão XFCE:**

   - `xfce4-panel-4.20.6`
   - `xfce4-session-4.20.3`
   - `Xfdesktop-4.20.1`
   - `Xfwm4-4.20.0`
   - `xfce4-settings-4.20.3`
   - `xfce4-power-manager-4.20.0`

4. **Constrói componentes de arquivo/imagens/terminal:**

   - `thunar-4.20.6`
   - `thunar-volman-4.20.0`
   - `tumbler-4.20.1`
   - `xfce4-appfinder-4.20.0`
   - `xfce4-terminal-1.1.5`
   - `ristretto-0.13.4`

5. **Notificações:**

   - `notification-daemon-3.20.0`
   - `xfce4-notifyd-0.9.7`

6. **Plugins de painel:**

   - `xfce4-genmon-plugin-4.3.0` (para CPU/MEM custom)
   - `xfce4-netload-plugin-1.5.0`
   - `xfce4-systemload-plugin-1.4.0`
   - `xfce4-weather-plugin-0.10.1`
   - `xfce4-whiskermenu-plugin-2.10.0`
   - `xfce4-mpc-plugin-0.6.0`
   - `xfce4-docklike-plugin-0.5.0`
   - (opcionais) `xfce4-dockbarx-plugin-0.7.2` e `xfce4-indicator-plugin-2.4.0`, se as receitas estiverem presentes.

7. **Temas GTK, ícones e cursores:**

   Temas GTK:

   - `vimix-gtk-themes-git`
   - `WhiteSur-Gtk-Theme`
   - `Catppuccin-GTK`
   - `Orchis-Gtk-Theme`
   - `Dracula-GTK`

   Ícones:

   - `WhiteSur-Icon-Theme`
   - `Papirus-Icon-Theme`
   - `Vimix-Icon-Theme`

   Cursores:

   - `Phinger-Cursors`
   - `Capitaine-Cursors`
   - `Notwaita-Cursor`
   - `Bibata-Cursor`

   Todos instalados em:

   - `/usr/share/themes`
   - `/usr/share/icons`

8. **Supervisor / serviços essenciais:**

   `bk-build-xfce4` chama `ensure_supervisor_entries`, que garante
   em `/etc/bk-supervisor.conf` as linhas:

   - `lightdm` (display manager)
   - `udisksd` (gerenciamento de volumes)
   - `polkitd` (autorização)
   - `upowerd` (energia/bateria)

   Essas entradas são idempotentes (só são adicionadas se não existirem).

9. **Configura LightDM:**

   - Ajusta `/etc/lightdm/lightdm.conf` para:

     - `greeter-session=lightdm-gtk-greeter`
     - `user-session=xfce`
     - `session-wrapper=/usr/bin/startxfce4`

10. **Configura /etc/skel para novos usuários:**

    O projeto já traz:

    - `~/.local/bin/xfce-genmon-cpu.sh` e `xfce-genmon-mem.sh`
    - `~/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml`
    - `~/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-whiskermenu-plugin.xml`

    Isso cria um painel inicial com:

    - Whisker menu estilizado “3bLinux”
    - CPU/MEM coloridos (via Genmon)
    - Netload + Systemload
    - Systray + relógio

Ao final, o script imprime:

```text
=== bk-build-xfce4: concluído ===
XFCE4 + LightDM prontos. Ao bootar com bk-init + bk-supervise, o desktop deve subir.
```

## 7. Boot real: init + supervisor + LightDM

Com tudo construído, o fluxo de boot típico é:

1. Kernel + initramfs sobem.
2. `init` do 3bLinux monta o rootfs, pseudo-fs, e executa hooks de `/etc/3binit.d`.
3. O hook `80-supervisor.sh` chama `bk-supervise` apontando para `/etc/bk-supervisor.conf`.
4. `bk-supervise` traz à vida (e mantém vivos):

   - `dbus-daemon`
   - `NetworkManager` (ou `dhcpcd`)
   - `syslogd` (se configurado)
   - `udisksd`
   - `polkitd`
   - `upowerd`
   - `lightdm`

5. O LightDM mostra o greeter, já com sessão XFCE disponível.

Se algo estiver estranho:

- Use `bk-reparo full` para checar diretórios/permissões/configs.
- Use `bk-init-reparo` para reconstruir estrutura de init/initramfs.
- Verifique `/var/log/bk-reparo.log` e os logs do supervisor/syslog.

## 8. Dicas finais

- Você pode ajustar os URLs reais dos temas/ícones/cursores via variáveis `BK_*_URL` em cada recipe.
- Se quiser um “preset” diferente de XFCE (por exemplo, com Openbox), você pode criar um `bk-build-openbox` no mesmo padrão.
- O guia aqui foca em `bk-build-xorg` + `bk-build-xfce4`, mas a base (toolchain, libs, etc.) já foi criada anteriormente pelos outros scripts de construção.

Bom hacking com o 3bLinux e XFCE!
