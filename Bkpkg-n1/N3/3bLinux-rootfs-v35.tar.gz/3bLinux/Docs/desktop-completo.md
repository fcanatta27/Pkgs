# 3bLinux – Desktop Completo

Este documento descreve como o 3bLinux entrega um desktop completo,
do boot até o uso diário.

## Sessões gráficas

O sistema oferece múltiplas sessões via LightDM e startx:

- XFCE4
- i3
- bspwm
- dwm
- cwm
- spectrwm
- notion

Arquivos ficam em:

- /usr/share/xsessions/*.desktop
- /usr/bin/bk-xsession

## LightDM

LightDM detecta automaticamente as sessões X11.
Você pode trocar no menu de login.

## startx

Sem LightDM:

```sh
3BLINUX_SESSION=xfce4 startx
3BLINUX_SESSION=i3 startx
```

Ou escolha interativamente.

## Navegadores

Use:

```sh
bk-build-browsers
```

Isso instala:

- Firefox (binário)
- Opera
- Vivaldi
- Brave

E cria symlinks em /usr/bin automaticamente.

## Manutenção

- bk-update: atualiza pacotes
- bk-reparo: sanity-check completo
- bk-init-reparo: reparo de boot/init

## Prevenção de problemas

- Nunca edite /usr diretamente; use scripts
- Sempre use bk-build-* para stacks grandes
- Revise /etc/bk-supervisor.conf antes de habilitar serviços

## Problemas comuns

- Tela preta após login:
  - Verifique ~/.xinitrc
  - Teste startx manualmente
- Sem rede:
  - Confirme NetworkManager/dhcpcd no supervisor
