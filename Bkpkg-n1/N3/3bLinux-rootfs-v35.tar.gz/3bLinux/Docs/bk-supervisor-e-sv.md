# Gerenciamento de Serviços no 3bLinux
## Arquivo `/etc/bk-supervisor.enable` e comando `sv`

Este documento explica:

- Como habilitar e desabilitar serviços com `/etc/bk-supervisor.enable`
- Como usar o comando `sv` no dia a dia
- Exemplos de perfis de serviços (desktop completo vs. sistema minimal)

---

## 1. Conceitos básicos

O 3bLinux usa um supervisor de serviços chamado **bk-supervise**, que:

- Lê a lista de serviços em `/etc/bk-supervisor.conf`
- Mantém processos críticos vivos (restart automático)
- Integra com o `init` e com o `bk-init-monitor`

Para facilitar o controle fino dos serviços, existem dois componentes principais:

1. Arquivo de configuração de enable/disable:
   - `/etc/bk-supervisor.enable`

2. Comando de controle rápido:
   - `sv`

---

## 2. Arquivo `/etc/bk-supervisor.enable`

Este arquivo define **quais serviços o supervisor deve gerenciar automaticamente**.

Formato:

```ini
# /etc/bk-supervisor.enable - liga/desliga serviços (yes/no)

syslogd=yes
klogd=yes
udevd=yes
dbusd=yes
NetworkManager=yes
dhcpcd=no
lightdm=yes
...
```

### Regras importantes

- Uma linha por serviço, formato `nome=valor`
- `nome` deve ser exatamente o nome usado em `/etc/bk-supervisor.conf` (primeiro campo da linha)
- `valor` pode ser:
  - `yes`, `on`, `true`, `1` → serviço habilitado
  - `no`, `off`, `false`, `0` → serviço desabilitado
- Se um serviço **não aparecer** no arquivo:
  - É tratado como **habilitado por padrão**, para manter compatibilidade

### Efeito prático

- Serviços **habilitados** são monitorados e (re)iniciados automaticamente
- Serviços **desabilitados** são completamente ignorados pelo loop automático

> Importante: você ainda pode operar um serviço manualmente via `sv start/stop/restart`
> mesmo que ele esteja marcado como `no` – o arquivo controla apenas o **perfil automático**.

---

## 3. Comando `sv` – uso diário

O comando `sv` é um wrapper simples por cima do `bk-supervise`.

### 3.1 Ver status de todos os serviços

```sh
sv status
```

Saída típica:

```text
bk-supervise: status
  dbusd running pid=123 enabled=yes
  NetworkManager running pid=456 enabled=yes
  dhcpcd stopped enabled=no
  lightdm running pid=789 enabled=yes
```

### 3.2 Ver status de um serviço específico

```sh
sv status dbus
sv status NetworkManager
```

Mostra apenas a linha do serviço alvo.

### 3.3 Iniciar um serviço manualmente

```sh
sv start dbus
sv start NetworkManager
sv start lightdm
```

Isso chama internamente `bk-supervise start-one <serviço>`.

### 3.4 Parar um serviço

```sh
sv stop dbus
sv stop NetworkManager
```

### 3.5 Reiniciar um serviço

```sh
sv restart dbus
sv restart NetworkManager
```

---

## 4. Ajustando perfis de serviços

Você pode usar `/etc/bk-supervisor.enable` para definir perfis diferentes.

### 4.1 Perfil Desktop Completo

Objetivo: tudo que é necessário para usar o 3bLinux como desktop gráfico diário.

Exemplo de arquivo:

```ini
# /etc/bk-supervisor.enable

syslogd=yes
klogd=yes

udevd=yes
eudev-trigger=yes

dbusd=yes
NetworkManager=yes
dhcpcd=no

ntpd=yes

lightdm=yes

rsyslogd=no  # se existir em paralelo ao syslogd antigo

# áudio / mídia (se houver serviços específicos):
pipewire=yes
wireplumber=yes
pulseaudio=no
```

Características:

- Usa NetworkManager (dhcpcd apenas como fallback, se você quiser)
- Usa LightDM como display manager
- Usa dbus como barramento central
- Mantém logs e udev sempre ativos

### 4.2 Perfil Minimal (servidor ou console puro)

Objetivo: sistema leve, apenas console, sem desktop.

Exemplo:

```ini
# /etc/bk-supervisor.enable

syslogd=yes
klogd=yes

udevd=yes
eudev-trigger=yes

dbusd=no

NetworkManager=no
dhcpcd=yes

ntpd=yes

lightdm=no
```

Características:

- Sem LightDM
- Sem desktop
- Sem barramento de sessão (dbus pode ser acionado manualmente se necessário)
- dhcpcd controla a rede de forma simples

> Dica: você pode manter múltiplas versões do arquivo, como
> `/etc/bk-supervisor.enable.desktop` e `/etc/bk-supervisor.enable.minimal`
> e alternar com `cp` + `sv restart <serviços>` ou reboot.

---

## 5. Fluxos práticos

### 5.1 Ativar LightDM e XFCE num sistema console

1. Edite `/etc/bk-supervisor.enable` e coloque:

   ```ini
   lightdm=yes
   dbusd=yes
   ```

2. Recarregue serviços:

   ```sh
   sv restart dbus
   sv restart lightdm
   ```

3. Você deve ver a tela de login em alguns segundos.

### 5.2 Modo console puro (sem login gráfico)

1. No arquivo de enable, configure:

   ```ini
   lightdm=no
   ```

2. Pare o serviço:

   ```sh
   sv stop lightdm
   ```

3. Nas próximas inicializações, não haverá display manager.

### 5.3 Debug de um serviço específico

Exemplo: dbus parecer “travado”.

1. Ver estado:

   ```sh
   sv status dbus
   ```

2. Parar e iniciar manualmente:

   ```sh
   sv stop dbus
   sv start dbus
   ```

3. Ver logs do serviço (dependendo da configuração):

   ```sh
   tail -n 50 /var/log/messages
   ```

---

## 6. Boas práticas

- Mantenha `/etc/bk-supervisor.enable` **sob controle de versão** (git local, por exemplo)
- Documente suas alterações usando comentários no próprio arquivo
- Em caso de dúvida, deixe o serviço como `yes` e apenas faça `sv stop` manual
- Use `sv status` antes e depois de mudar o arquivo para garantir que o sistema está saudável

Com isso você tem um **controle simples e poderoso** sobre todos os serviços
do 3bLinux, seja em modo desktop ou console minimal.
