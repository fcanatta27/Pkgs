#!/bin/sh
# 3bLinux init hook: 00-system.sh
# Responsável por garantir diretórios básicos, permissões e arquivos mínimos.

set -eu

log() { printf '%s\n' "$*"; }

# Diretórios mínimos
for d in /var/log /var/run /var/tmp /run/lock; do
  [ -d "$d" ] || mkdir -p "$d" 2>/dev/null || true
done

chmod 1777 /var/tmp 2>/dev/null || true

# Arquivo de log de boot
[ -f /var/log/boot.log ] || touch /var/log/boot.log 2>/dev/null || true

# /etc/profile padrão se não existir (não sobrescreve customizações)
if [ ! -f /etc/profile ]; then
  cat > /etc/profile <<'EOF'
# 3bLinux default profile
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PS1='\u@3bLinux:\w\$ '
EOF
fi

# /etc/hosts mínimo
if [ ! -f /etc/hosts ]; then
  cat > /etc/hosts <<'EOF'
127.0.0.1 localhost
::1       localhost
EOF
fi
