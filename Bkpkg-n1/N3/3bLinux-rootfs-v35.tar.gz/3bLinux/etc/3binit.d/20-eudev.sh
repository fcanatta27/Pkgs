#!/bin/sh
# 3bLinux init hook: 20-eudev.sh
# Inicia udevd (eudev) se disponível.

set -eu

if command -v udevd >/dev/null 2>&1 || command -v /usr/lib/udev/udevd >/dev/null 2>&1; then
  echo "[3binit] iniciando udevd..."
  if command -v udevd >/dev/null 2>&1; then
    udevd --daemon || true
  else
    /usr/lib/udev/udevd --daemon || true
  fi
  udevadm trigger --action=add || true
  udevadm settle || true
fi
