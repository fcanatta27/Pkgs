#!/bin/sh
# 3bLinux init hook: 08-kernel-cmdline.sh
# Analisa /proc/cmdline e sinaliza modo single/rescue.
set -eu

mkdir -p /run 2>/dev/null || true

if [ -r /proc/cmdline ]; then
  cmdline="$(cat /proc/cmdline 2>/dev/null || echo "")"
  case " $cmdline " in
    *" single "*|*" 3blinux.single "*)
      : > /run/3blinux.single
      ;;
    *" 3blinux.rescue "*)
      : > /run/3blinux.rescue
      ;;
  esac
fi
