#!/bin/sh
# 3bLinux init hook: 25-console-keymap.sh
# Placeholder para futuros ajustes de layout de teclado no console.
set -eu

# Se existir /etc/vconsole.conf (compatível com systemd-style), poderíamos aplicar aqui.
# Por ora, apenas garante que o console exista.
[ -c /dev/console ] || mknod -m 600 /dev/console c 5 1 2>/dev/null || true
