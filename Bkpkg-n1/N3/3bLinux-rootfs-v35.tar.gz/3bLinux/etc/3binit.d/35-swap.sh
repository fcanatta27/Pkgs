#!/bin/sh
# 3bLinux init hook: 35-swap.sh
# Ativa swap definido em /etc/fstab, se houver.
set -eu

if command -v swapon >/dev/null 2>&1 && [ -f /etc/fstab ]; then
  # swapon -a ignora entradas que não são swap
  swapon -a 2>/dev/null || true
fi
