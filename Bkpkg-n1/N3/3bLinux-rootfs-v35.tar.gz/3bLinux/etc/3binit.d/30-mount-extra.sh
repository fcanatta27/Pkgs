#!/bin/sh
# 3bLinux init hook: 30-mount-extra.sh
# Monta pontos comuns adicionais se existirem em /etc/fstab.

set -eu

if [ -f /etc/fstab ] && command -v mount >/dev/null 2>&1; then
  mount -a 2>/dev/null || true
fi
