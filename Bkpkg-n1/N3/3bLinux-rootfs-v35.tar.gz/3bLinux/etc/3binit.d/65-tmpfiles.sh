#!/bin/sh
# 3bLinux init hook: 65-tmpfiles.sh
# Cria caminhos e symlinks comuns em runtime.
set -eu

mkdir -p /run /run/lock 2>/dev/null || true
mkdir -p /var/run /var/lock 2>/dev/null || true

# sistemas modernos: /var/run -> /run, /var/lock -> /run/lock
if [ ! -L /var/run ]; then
  rm -rf /var/run 2>/dev/null || true
  ln -sf /run /var/run 2>/dev/null || true
fi

if [ ! -L /var/lock ]; then
  rm -rf /var/lock 2>/dev/null || true
  ln -sf /run/lock /var/lock 2>/dev/null || true
fi
