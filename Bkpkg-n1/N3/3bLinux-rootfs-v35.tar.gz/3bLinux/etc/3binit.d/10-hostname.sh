#!/bin/sh
# 3bLinux init hook: 10-hostname.sh
# Aplica hostname se /etc/hostname existir.

set -eu

[ -f /etc/hostname ] || exit 0

hn="$(sed -n '1p' /etc/hostname 2>/dev/null || echo '')"
[ -n "$hn" ] || exit 0

hostname "$hn" 2>/dev/null || true
