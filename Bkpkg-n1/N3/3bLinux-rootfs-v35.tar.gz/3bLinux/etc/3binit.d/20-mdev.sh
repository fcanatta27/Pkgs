#!/bin/sh
# 3bLinux init hook: 20-mdev.sh
# Configura mdev como gerenciador simples de dispositivos se BusyBox estiver disponível.

set -eu

if command -v mdev >/dev/null 2>&1; then
  echo /sbin/mdev > /proc/sys/kernel/hotplug 2>/dev/null || true
  mdev -s 2>/dev/null || true
fi
