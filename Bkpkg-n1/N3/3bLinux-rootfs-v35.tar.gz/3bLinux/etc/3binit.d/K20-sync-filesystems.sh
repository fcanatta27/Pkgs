\
#!/usr/bin/env bash
set -euo pipefail

# /etc/3binit.d/K20-sync-filesystems.sh
#
# Hook simples que garante sync e desativação de swap, se desejado.
#
# Argumento:
#   $1 = ação (reboot|poweroff)

ACTION="${1:-poweroff}"

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }

bl "[K20] Sync e swapoff para ação: $ACTION"

sync || true

if command -v swapoff >/dev/null 2>&1; then
  swapoff -a || true
fi

exit 0
