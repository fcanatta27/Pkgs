#!/bin/sh
# 3bLinux init hook: 50-sysctl.sh
# Aplica /etc/sysctl.conf se sysctl existir.
set -eu

if command -v sysctl >/dev/null 2>&1 && [ -f /etc/sysctl.conf ]; then
  sysctl -p /etc/sysctl.conf 2>/dev/null || true
fi
