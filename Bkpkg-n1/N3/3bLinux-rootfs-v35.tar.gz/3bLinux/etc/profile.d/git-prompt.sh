\
# /etc/profile.d/git-prompt.sh - 3bLinux minimal git prompt helpers
# Não depende do bash-completion do git.

__bk_git_branch() {
  command -v git >/dev/null 2>&1 || return 0
  git rev-parse --is-inside-work-tree >/dev/null 2>&1 || return 0
  local b
  b="$(git symbolic-ref --quiet --short HEAD 2>/dev/null || git describe --tags --exact-match 2>/dev/null || git rev-parse --short HEAD 2>/dev/null)"
  [ -n "$b" ] && printf "%s" "$b"
}

__bk_git_dirty() {
  command -v git >/dev/null 2>&1 || return 0
  git rev-parse --is-inside-work-tree >/dev/null 2>&1 || return 0
  git diff --no-ext-diff --quiet --ignore-submodules -- 2>/dev/null && git diff --cached --quiet --ignore-submodules -- 2>/dev/null && return 0
  return 1
}
