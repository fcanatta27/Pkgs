#!/usr/bin/env bash
set -euo pipefail

# Package: gdbm
# Version: 1.26
#
# Dependencies (host / build) aproximadas:
#   - bash, coreutils, findutils, grep, sed, gawk
#   - tar, xz, gzip, bzip2
#   - make, gcc, pkg-config
#   - curl ou wget
#
# Dependencies (runtime) aproximadas:
#   - libc (glibc), libstdc++, zlib, libgcc
#   - bibliotecas específicas deste pacote (use ldd no binário instalado)
#
# Flags suportadas (ambiente padrão do 3bLinux):
#   BK_JOBS           : paralelismo do make (default 1)
#   BK_DOWNLOAD_DIR   : diretório de cache de tarballs (default /tmp/bk-src)
#   BK_BUILD_DIR      : diretório base de build da receita
#   BK_STAGE_ROOT     : DESTDIR para instalação (conteúdo que será empacotado)
#   BK_*_URL          : URL do tarball da receita (quando definido)
#   BK_*_CONFIG_EXTRA : flags extras passadas para ./configure/meson/cmake/etc.
#
# Flags completas do programa:
#   Consulte:
#     - ./configure --help        (projetos autotools)
#     - meson configure           (projetos Meson)
#     - cmake -LH                 (projetos CMake)
#     - --help do binário final   (opções em tempo de execução)

# - tar
# - make
# - gcc/toolchain funcional
# - curl ou wget
  #
  # Flags suportadas (via ambiente):
  #   BK_JOBS               : paralelismo do make (default 1)
# BK_DOWNLOAD_DIR       : diretório para tarballs (default /tmp/bk-src)
# BK_BUILD_DIR          : diretório base de build da receita
# BK_STAGE_ROOT         : DESTDIR para instalação (conteúdo que será empacotado)
# BK_GDBM_URL           : URL do tarball
# BK_GDBM_CONFIG_EXTRA  : flags extras para o configure
  #
  # Observação:
  #   Instala GNU dbm (GDBM) em /usr.

  b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
  bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
  info(){ echo "$*"; }
  die(){ echo "ERROR: $*" >&2; exit 1; }

  : "${BK_JOBS:=1}"
  : "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
  : "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-gdbm-1.26}}"
  : "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
  : "${BK_GDBM_URL:=https://ftp.gnu.org/gnu/gdbm/gdbm-1.26.tar.gz}"
  : "${BK_GDBM_CONFIG_EXTRA:=}"

  SRC_TAR="$BK_DOWNLOAD_DIR/gdbm-1.26.tar.gz"
  SRC_DIR="$BK_BUILD_DIR/src"
  BUILD_DIR="$BK_BUILD_DIR/build"

  fetch(){
    local url="$1" out="$2"
    mkdir -p "$(dirname "$out")"
    if [ -s "$out" ]; then
      info "  Usando tarball em cache: $(b "$out")"
      return 0
    fi
    info "  Baixando: $(b "$url")"
    if command -v curl >/dev/null 2>&1; then
      curl -L --fail --retry 3 --output "$out" "$url"
    elif command -v wget >/dev/null 2>&1; then
      wget -O "$out" "$url"
    else
      die "nem curl nem wget encontrados"
    fi
  }

  bl "=== Construção $(b gdbm-1.26) ==="
  info "  Recipe.....: ${BK_RECIPE:-gdbm-1.26}"
  info "  Download...: $(b "$BK_GDBM_URL")"
  info "  Download dir: $(b "$BK_DOWNLOAD_DIR")"
  info "  Build dir..: $(b "$BK_BUILD_DIR")"
  info "  Stage root.: $(b "$BK_STAGE_ROOT")"

  mkdir -p "$BK_DOWNLOAD_DIR" "$BK_BUILD_DIR" "$BK_STAGE_ROOT"
  fetch "$BK_GDBM_URL" "$SRC_TAR"

  rm -rf "$SRC_DIR" "$BUILD_DIR"
  mkdir -p "$SRC_DIR" "$BUILD_DIR"
  tar -xf "$SRC_TAR" -C "$SRC_DIR" --strip-components=1

  cd "$BUILD_DIR"

  "$SRC_DIR/configure" \
--prefix=/usr \
--disable-static \
$BK_GDBM_CONFIG_EXTRA

  make -j"$BK_JOBS"
  make DESTDIR="$BK_STAGE_ROOT" install

  bl "=== Summary $(b gdbm-1.26) ==="
  info "  Staged root: $(b "$BK_STAGE_ROOT")"
  info "  usr dir....: $(b "$BK_STAGE_ROOT/usr")"
