#!/usr/bin/env bash
set -euo pipefail

# Package: markupsafe
# Version: 3.0.3
#
# Dependencies (host / build) aproximadas:
#   - bash, coreutils, findutils, grep, sed, gawk
#   - tar, xz, gzip, bzip2
#   - make, gcc, pkg-config
#   - curl ou wget
#
# Dependencies (runtime) aproximadas:
#   - libc (glibc), libstdc++, zlib, libgcc
#   - bibliotecas específicas deste pacote (use ldd no binário instalado)
#
# Flags suportadas (ambiente padrão do 3bLinux):
#   BK_JOBS           : paralelismo do make (default 1)
#   BK_DOWNLOAD_DIR   : diretório de cache de tarballs (default /tmp/bk-src)
#   BK_BUILD_DIR      : diretório base de build da receita
#   BK_STAGE_ROOT     : DESTDIR para instalação (conteúdo que será empacotado)
#   BK_*_URL          : URL do tarball da receita (quando definido)
#   BK_*_CONFIG_EXTRA : flags extras passadas para ./configure/meson/cmake/etc.
#
# Flags completas do programa:
#   Consulte:
#     - ./configure --help        (projetos autotools)
#     - meson configure           (projetos Meson)
#     - cmake -LH                 (projetos CMake)
#     - --help do binário final   (opções em tempo de execução)

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_STAGE_ROOT:=/tmp/bk-build/${BK_RECIPE:-markupsafe-3.0.3}/root}"

command -v python3 >/dev/null 2>&1 || die "python3 não encontrado no host"
bl "=== Instalando MarkupSafe==3.0.3 em $(b "$BK_STAGE_ROOT") ==="
python3 -m pip install --no-compile --root "$BK_STAGE_ROOT" "MarkupSafe==3.0.3"
