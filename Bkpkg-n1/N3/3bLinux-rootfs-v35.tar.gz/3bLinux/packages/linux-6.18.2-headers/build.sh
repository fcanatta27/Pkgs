#!/usr/bin/env bash
set -euo pipefail

# Package: linux
# Version: 6.18.2
#
# Dependencies (host / build) aproximadas:
#   - bash, coreutils, findutils, grep, sed, gawk
#   - tar, xz, gzip, bzip2
#   - make, gcc, pkg-config
#   - curl ou wget
#
# Dependencies (runtime) aproximadas:
#   - libc (glibc), libstdc++, zlib, libgcc
#   - bibliotecas específicas deste pacote (use ldd no binário instalado)
#
# Flags suportadas (ambiente padrão do 3bLinux):
#   BK_JOBS           : paralelismo do make (default 1)
#   BK_DOWNLOAD_DIR   : diretório de cache de tarballs (default /tmp/bk-src)
#   BK_BUILD_DIR      : diretório base de build da receita
#   BK_STAGE_ROOT     : DESTDIR para instalação (conteúdo que será empacotado)
#   BK_*_URL          : URL do tarball da receita (quando definido)
#   BK_*_CONFIG_EXTRA : flags extras passadas para ./configure/meson/cmake/etc.
#
# Flags completas do programa:
#   Consulte:
#     - ./configure --help        (projetos autotools)
#     - meson configure           (projetos Meson)
#     - cmake -LH                 (projetos CMake)
#     - --help do binário final   (opções em tempo de execução)

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }

: "${BK_JOBS:=1}"
: "${BK_KERNEL_HEADERS_PREFIX:=/usr}"
: "${BK_KERNEL_HEADERS_URL:=https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-6.18.2.tar.xz}"

TAR="$BK_DOWNLOAD_DIR/linux-6.18.2.tar.xz"
SRC="$BK_BUILD_DIR/src"

bl "=== Build $(b linux-headers) $(b 6.18.2) ==="
echo "  Recipe.....: ${BK_RECIPE:-linux-6.18.2-headers}"
echo "  Download...: $(b "$BK_KERNEL_HEADERS_URL")"
echo "  Download dir: $(b "$BK_DOWNLOAD_DIR")"
echo "  Build dir..: $(b "$BK_BUILD_DIR")"
echo "  Stage root.: $(b "$BK_STAGE_ROOT")"
echo "  Prefix.....: $(b "$BK_KERNEL_HEADERS_PREFIX")"

mkdir -p "$BK_DOWNLOAD_DIR" "$BK_BUILD_DIR" "$BK_STAGE_ROOT"

fetch(){
  if [ -s "$TAR" ]; then echo "  Using cached: $TAR"; return; fi
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 --output "$TAR" "$BK_KERNEL_HEADERS_URL"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$TAR" "$BK_KERNEL_HEADERS_URL"
  else
    echo "ERROR: need curl or wget" >&2
    exit 1
  fi
}

fetch
rm -rf "$SRC"
mkdir -p "$SRC"
tar -xf "$TAR" -C "$SRC" --strip-components=1

cd "$SRC"
make mrproper ${BK_KERNEL_HEADERS_MAKEFLAGS:-}
make headers_install INSTALL_HDR_PATH="$BK_STAGE_ROOT$BK_KERNEL_HEADERS_PREFIX" ${BK_KERNEL_HEADERS_MAKEFLAGS:-}

bl "=== Summary ==="
echo "  Installed headers: $(b "$BK_STAGE_ROOT$BK_KERNEL_HEADERS_PREFIX/include")"
