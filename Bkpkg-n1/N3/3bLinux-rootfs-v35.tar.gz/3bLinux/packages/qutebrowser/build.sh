\
#!/usr/bin/env bash
set -euo pipefail

# Package: qutebrowser
# Version: latest (blueprint)
#
# Dependencies (runtime/build):
#   - python3
#   - Qt6 ou Qt5 + QtWebEngine
#   - setuptools/pip (ou instalação via wheel)
#
# Observação:
#   O gargalo real é QtWebEngine (muito pesado). Este recipe assume que Qt+WebEngine
#   já existem no sistema e instala o qutebrowser via pip/pep517.

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-qutebrowser}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
: "${BK_QUTEBROWSER_PIP:=qutebrowser}"

prepare(){ bl "=== qutebrowser: prepare ==="; }

install(){
  bl "=== qutebrowser: install (stage) ==="
  command -v python3 >/dev/null 2>&1 || die "python3 não encontrado"
  python3 -m pip install --no-deps --root "$BK_STAGE_ROOT" --prefix /usr "$BK_QUTEBROWSER_PIP"
}

main(){ prepare; install; bl "=== Summary qutebrowser ==="; }
main "$@"
