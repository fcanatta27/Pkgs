    #!/usr/bin/env bash
    set -euo pipefail

    # Package: libxcvt
    # Version: 0.1.3
    #
    # Dependencies (build/runtime) aproximadas:
    #   - gcc, make
#
    # Flags / opções de compilação:
    #   - ./configure --prefix=/usr
#
    # Este script segue o padrão 3bLinux:
    #   - Usa BK_* para diretórios/URLs
    #   - Usa BK_STAGE_ROOT como destino temporário (DESTDIR)
    #   - Idempotente: pode ser reexecutado; build e stage ficam em /tmp/bk-build

    b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
    bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
    info(){ echo "$*"; }
    die(){ echo "ERROR: $*" >&2; exit 1; }

    : "${BK_JOBS:=1}"
    : "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
    : "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-libxcvt-0.1.3}}"
    : "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

    : "${BK_LIBXCVT_URL:=https://www.x.org/releases/individual/lib/libxcvt-0.1.3.tar.xz}"

    SRC_TAR="$BK_DOWNLOAD_DIR/libxcvt-0.1.3.tar.*"
    SRC_DIR="$BK_BUILD_DIR/src"
    BUILD_DIR="$BK_BUILD_DIR/build"

    fetch(){
      local url="${BK_LIBXCVT_URL}" out="$BK_DOWNLOAD_DIR/libxcvt-0.1.3.tar"
      mkdir -p "$(dirname "$out")"
      if ls $BK_DOWNLOAD_DIR/libxcvt-0.1.3.tar* >/dev/null 2>&1; then
        info "  Usando tarball em cache: $(b "$(ls $BK_DOWNLOAD_DIR/libxcvt-0.1.3.tar* | head -n1)")"
        return 0
      fi
      info "  Baixando: $(b "$url")"
      if command -v curl >/dev/null 2>&1; then
        curl -L "$url" -o "$out"
      elif command -v wget >/dev/null 2>&1; then
        wget -O "$out" "$url"
      else
        die "nem curl nem wget encontrados"
      fi
    }

    prepare(){
      bl "=== libxcvt-0.1.3: prepare ==="
      mkdir -p "$BK_DOWNLOAD_DIR" "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR"
      fetch
      rm -rf "$SRC_DIR" "$BUILD_DIR"
      mkdir -p "$SRC_DIR" "$BUILD_DIR"
      # tenta descompactar robustamente (.tar, .tar.gz, .tar.xz, etc.)
      local tarball
      tarball=$(ls $BK_DOWNLOAD_DIR/libxcvt-0.1.3.tar* | head -n1)
      tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
    }

    build(){
      bl "=== libxcvt-0.1.3: build ==="
      cd "$SRC_DIR"
      ./configure --prefix=/usr
      make -j"$BK_JOBS"
    }

    install(){
      bl "=== libxcvt-0.1.3: install (stage em $BK_STAGE_ROOT) ==="
      cd "$SRC_DIR"
      make DESTDIR="$BK_STAGE_ROOT" install
    }

    main(){
      prepare
      build
      install

      bl "=== Summary $(b libxcvt-0.1.3) ==="
      info "  Staged root: $(b "$BK_STAGE_ROOT")"
      info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin")"
      info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
      info "  Includes.. : $(b "$BK_STAGE_ROOT/usr/include")"
    }

    main "$@"
