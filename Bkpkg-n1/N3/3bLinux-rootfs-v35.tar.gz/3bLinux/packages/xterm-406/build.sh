\
#!/usr/bin/env bash
set -euo pipefail

# Package: xterm
# Version: 406
#
# Dependencies (build/runtime) aproximadas:
#   - Xorg libs: libX11, libXaw, libXt, libXft (para fonte moderna), libXmu
#   - freetype/fontconfig (se usar Xft)
#   - ncurses (terminfo)
#
# Flags / opções (configure):
#   - --enable-wide-chars
#   - --enable-256-color
#   - --enable-luit
#   - --with-icondir=...
#   - --with-xterm-termcap
#
# Download oficial:
#   https://invisible-mirror.net/archives/xterm/xterm-406.tgz

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-xterm-406}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

: "${BK_XTERM_URL:=https://invisible-mirror.net/archives/xterm/xterm-406.tgz}"

SRC_TAR="$BK_DOWNLOAD_DIR/xterm-406.tgz"
SRC_DIR="$BK_BUILD_DIR/src"
BUILD_DIR="$BK_BUILD_DIR/build"

fetch(){
  local url="$BK_XTERM_URL" out="$SRC_TAR"
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then info "  Usando tarball em cache: $(b "$out")"; return 0; fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
  else die "nem curl nem wget encontrados"; fi
}

prepare(){
  bl "=== xterm-406: prepare ==="
  mkdir -p "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR" "$BK_DOWNLOAD_DIR"
  fetch
  rm -rf "$SRC_DIR" "$BUILD_DIR"
  mkdir -p "$SRC_DIR" "$BUILD_DIR"
  tar -xf "$SRC_TAR" -C "$SRC_DIR" --strip-components=1
}

build(){
  bl "=== xterm-406: build ==="
  cd "$SRC_DIR"
  ./configure --prefix=/usr \
    --with-app-defaults=/etc/X11/app-defaults \
    --enable-wide-chars \
    --enable-256-color \
    --enable-luit
  make -j"$BK_JOBS"
}

install(){
  bl "=== xterm-406: install (stage em $BK_STAGE_ROOT) ==="
  cd "$SRC_DIR"
  make DESTDIR="$BK_STAGE_ROOT" install
}

main(){
  prepare
  build
  install
  bl "=== Summary $(b xterm-406) ==="
  info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin/xterm")"
}

main "$@"
