#!/usr/bin/env bash
set -euo pipefail

# Package: py3status
# Version: 3.57
#
# Tipo: status bar (i3bar) em Python
#
# Dependências (conceituais):
#   - python3
#   - pip
#   - i3status / i3bar
#
# Flags / opções suportadas:
#   - instalação via pip no rootfs (site-packages padrão)
#
# Padrão 3bLinux: usa BK_STAGE_ROOT como raiz via --root (quando suportado)

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
die(){ echo "ERROR: $*" >&2; exit 1; }
info(){ echo "  $*" >&2; }

: "${BK_BUILD_DIR:=/tmp/bk-build/py3status-3.57}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/stage}"

prepare(){
  bl "=== $(b py3status-3.57): prepare ==="
  mkdir -p "$BK_BUILD_DIR" "$BK_STAGE_ROOT"
}

build(){
  bl "=== $(b py3status-3.57): build (pip wheel) ==="
  cd "$BK_BUILD_DIR"
  python3 -m pip download py3status==3.57 -d .
  local whl
  whl="$(ls py3status-3.57-*.whl | head -n1)"
  [ -n "$whl" ] || die "wheel do py3status não encontrado"
  info "Usando wheel: $whl"
}

install(){
  bl "=== $(b py3status-3.57): install (DESTDIR=$BK_STAGE_ROOT) ==="
  cd "$BK_BUILD_DIR"
  local whl
  whl="$(ls py3status-3.57-*.whl | head -n1)"
  python3 -m pip install --no-deps --root "$BK_STAGE_ROOT" "$whl"
}

main(){
  prepare
  build
  install
  bl "=== Summary $(b py3status-3.57) ==="
  info "  Stage em: $(b "$BK_STAGE_ROOT")"
}

main "$@"
