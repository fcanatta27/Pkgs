\
#!/usr/bin/env bash
set -euo pipefail

# Package: libinput
# Version: 1.30.1
#
# Dependencies (build/runtime) aproximadas:
#   - libevdev
#   - libudev (udev/eudev)
#   - libwacom (opcional, recomendado)
#   - mtdev (opcional)
#   - meson, ninja, pkg-config
#
# Flags / opções (meson):
#   - -Ddebug-gui=false|true
#   - -Dtests=true|false
#   - -Ddocumentation=true|false

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-libinput-1.30.1}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

: "${BK_LIBINPUT_URL:=https://gitlab.freedesktop.org/libinput/libinput/-/archive/1.30.1/libinput-1.30.1.tar.gz}"

SRC_TAR="$BK_DOWNLOAD_DIR/libinput-1.30.1.tar.gz"
SRC_DIR="$BK_BUILD_DIR/src"
BUILD_DIR="$BK_BUILD_DIR/build"

fetch(){
  local url="$BK_LIBINPUT_URL" out="$SRC_TAR"
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then info "  Usando tarball em cache: $(b "$out")"; return 0; fi
  info "  Baixando: $(b "$url")"
  if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
  elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
  else die "nem curl nem wget encontrados"; fi
}

prepare(){
  bl "=== libinput-1.30.1: prepare ==="
  mkdir -p "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR" "$BK_DOWNLOAD_DIR"
  fetch
  rm -rf "$SRC_DIR" "$BUILD_DIR"
  mkdir -p "$SRC_DIR" "$BUILD_DIR"
  tar -xf "$SRC_TAR" -C "$SRC_DIR" --strip-components=1
}

build(){
  bl "=== libinput-1.30.1: build ==="
  cd "$SRC_DIR"
  meson setup "$BUILD_DIR" \
    --prefix=/usr \
    --buildtype=release \
    -Dtests=false \
    -Ddocumentation=false
  ninja -C "$BUILD_DIR" -j"$BK_JOBS"
}

install(){
  bl "=== libinput-1.30.1: install (stage em $BK_STAGE_ROOT) ==="
  DESTDIR="$BK_STAGE_ROOT" ninja -C "$BUILD_DIR" install
}

main(){
  prepare
  build
  install
  bl "=== Summary $(b libinput-1.30.1) ==="
  info "  Staged root: $(b "$BK_STAGE_ROOT")"
  info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
  info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin")"
}

main "$@"
