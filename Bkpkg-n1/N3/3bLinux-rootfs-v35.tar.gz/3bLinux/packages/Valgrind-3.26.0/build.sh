    #!/usr/bin/env bash
    set -euo pipefail

    # Package: Valgrind
    # Version: 3.26.0
    #
    # Dependencies (build/runtime) aproximadas:
    #   - gcc, make
#   - perl (alguns scripts)
#
    # Flags / opções de compilação:
    #   - ./configure --prefix=/usr
#   - --enable-only64bit (opcional)
#
    # Padrão 3bLinux:
    #   - BK_STAGE_ROOT como DESTDIR
    #   - build em /tmp/bk-build
    #   - idempotente (reexecutável)

    b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
    bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
    info(){ echo "$*"; }
    die(){ echo "ERROR: $*" >&2; exit 1; }

    : "${BK_JOBS:=1}"
    : "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
    : "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-Valgrind-3.26.0}}"
    : "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

    : "${BK_VALGRIND_URL:=https://sourceware.org/pub/valgrind/valgrind-3.26.0.tar.bz2}"

    SRC_DIR="$BK_BUILD_DIR/src"
    BUILD_DIR="$BK_BUILD_DIR/build"

    fetch(){
      mkdir -p "$BK_DOWNLOAD_DIR"
      if ls "$BK_DOWNLOAD_DIR/Valgrind-3.26.0.tar"* >/dev/null 2>&1; then
        info "  Usando tarball em cache: $(b "$(ls $BK_DOWNLOAD_DIR/Valgrind-3.26.0.tar* | head -n1)")"
        return 0
      fi
      info "  Baixando: $(b "${BK_VALGRIND_URL}")"
      if command -v curl >/dev/null 2>&1; then
        curl -L "${BK_VALGRIND_URL}" -o "$BK_DOWNLOAD_DIR/Valgrind-3.26.0.tar"
      elif command -v wget >/dev/null 2>&1; then
        wget -O "$BK_DOWNLOAD_DIR/Valgrind-3.26.0.tar" "${BK_VALGRIND_URL}"
      else
        die "nem curl nem wget encontrados"
      fi
    }

    prepare(){
      bl "=== Valgrind-3.26.0: prepare ==="
      mkdir -p "$BK_BUILD_DIR" "$SRC_DIR" "$BUILD_DIR"
      fetch
      rm -rf "$SRC_DIR" "$BUILD_DIR"
      mkdir -p "$SRC_DIR" "$BUILD_DIR"
      local tarball
      tarball=$(ls "$BK_DOWNLOAD_DIR"/Valgrind-3.26.0.tar* | head -n1)
      tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
    }

    build(){
      bl "=== Valgrind-3.26.0: build ==="
      cd "$SRC_DIR"
      ./configure --prefix=/usr
      make -j"$BK_JOBS"
    }

    install(){
      bl "=== Valgrind-3.26.0: install (stage em $BK_STAGE_ROOT) ==="
      cd "$SRC_DIR"
      make DESTDIR="$BK_STAGE_ROOT" install
    }

    main(){
      prepare
      build
      install
      bl "=== Summary $(b Valgrind-3.26.0) ==="
      info "  Staged root: $(b "$BK_STAGE_ROOT")"
      info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin")"
      info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
      info "  Headers... : $(b "$BK_STAGE_ROOT/usr/include")"
      info "  Data...... : $(b "$BK_STAGE_ROOT/usr/share")"
    }

    main "$@"
