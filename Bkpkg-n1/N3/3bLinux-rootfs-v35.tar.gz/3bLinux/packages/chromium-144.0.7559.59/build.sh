\
#!/usr/bin/env bash
set -euo pipefail

# Package: chromium
# Version: 144.0.7559.59 (blueprint)
#
# Dependencies: ver pacote chromium (depot_tools, clang/llvm, ninja)
#
# Flags:
#   - BK_GN_ARGS (string)
#
# Observação:
#   Fixar exatamente uma versão do Chromium normalmente exige checkout por tag/branch
#   e, frequentemente, DEPS compatíveis. Este script define um alvo e deixa o checkout
#   para você ajustar conforme a infra do seu mirror.

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-chromium-144.0.7559.59}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
: "${BK_DEPOT_TOOLS:=/opt/depot_tools}"
: "${BK_GN_ARGS:=is_official_build=true use_sysroot=false proprietary_codecs=true ffmpeg_branding=Chrome}"
: "${BK_CHROMIUM_REF:=144.0.7559.59}"

SRC_DIR="$BK_BUILD_DIR/src"
OUT_DIR="$BK_BUILD_DIR/out/Release"

prepare(){
  bl "=== chromium-144.0.7559.59: prepare ==="
  [ -d "$BK_DEPOT_TOOLS" ] || die "depot_tools não encontrado em $BK_DEPOT_TOOLS"
  export PATH="$BK_DEPOT_TOOLS:$PATH"
  mkdir -p "$SRC_DIR"
  if [ ! -d "$SRC_DIR/.git" ]; then
    fetch --nohooks chromium
  fi
  cd "$SRC_DIR"
  # ajuste aqui para o seu fluxo (tag/branch/commit)
  info "  Checkout alvo: $(b "$BK_CHROMIUM_REF") (ajuste conforme necessário)"
  gclient sync
}

build(){
  bl "=== chromium-144.0.7559.59: build ==="
  cd "$SRC_DIR"
  gn gen "$OUT_DIR" --args="$BK_GN_ARGS"
  ninja -C "$OUT_DIR" -j"$BK_JOBS" chrome
}

install(){
  bl "=== chromium-144.0.7559.59: install (stage em $BK_STAGE_ROOT) ==="
  mkdir -p "$BK_STAGE_ROOT/opt/chromium-144.0.7559.59"
  cp -a "$OUT_DIR/." "$BK_STAGE_ROOT/opt/chromium-144.0.7559.59/"
  mkdir -p "$BK_STAGE_ROOT/usr/bin"
  ln -sf /opt/chromium-144.0.7559.59/chrome "$BK_STAGE_ROOT/usr/bin/chromium" || true
}

main(){ prepare; build; install; bl "=== Summary chromium-144.0.7559.59 ==="; info "  Staged: $BK_STAGE_ROOT"; }
main "$@"
