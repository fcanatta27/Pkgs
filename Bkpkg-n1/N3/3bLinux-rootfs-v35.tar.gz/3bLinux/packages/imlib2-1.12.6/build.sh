\
        #!/usr/bin/env bash
        set -euo pipefail

        # Package: imlib2
        # Version: 1.12.6
        #
        # Dependencies (build/runtime) aproximadas:
        #   - libpng, libjpeg-turbo
        #   - freetype (opcional)
        #   - X11 libs (opcional)
        #
        # Flags / opções:
        #   - Autotools: ./configure --prefix=/usr --sysconfdir=/etc
        #   - Meson: depende do tarball (nem sempre disponível)

        b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
        bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
        info(){ echo "$*"; }
        die(){ echo "ERROR: $*" >&2; exit 1; }

        : "${BK_JOBS:=1}"
        : "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
        : "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-imlib2-1.12.6}}"
        : "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"

        : "${BK_IMLIB2_URL:=https://downloads.sourceforge.net/enlightenment/imlib2-1.12.6.tar.xz}"

        SRC_DIR="$BK_BUILD_DIR/src"
        BUILD_DIR="$BK_BUILD_DIR/build"

        url_basename(){ local u="$1"; u="${u%%\?*}"; echo "$(basename "$u")"; }

        fetch(){
          mkdir -p "$BK_DOWNLOAD_DIR"
          local url="$BK_IMLIB2_URL" base out
          base="$(url_basename "$url")"
          out="$BK_DOWNLOAD_DIR/$base"
          if [ -s "$out" ]; then info "  Usando tarball em cache: $(b "$out")"; echo "$out"; return 0; fi
          info "  Baixando: $(b "$url")"
          if command -v curl >/dev/null 2>&1; then curl -L "$url" -o "$out"
          elif command -v wget >/dev/null 2>&1; then wget -O "$out" "$url"
          else die "nem curl nem wget encontrados"; fi
          echo "$out"
        }

        prepare(){
          bl "=== imlib2-1.12.6: prepare ==="
          rm -rf "$SRC_DIR" "$BUILD_DIR"
          mkdir -p "$SRC_DIR" "$BUILD_DIR"
          local tarball
          tarball="$(fetch)"
          tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
        }

        build(){
          bl "=== imlib2-1.12.6: build ==="
          if [ -f "$SRC_DIR/meson.build" ] && command -v meson >/dev/null 2>&1; then
            bl "  Usando meson/ninja"
            meson setup "$BUILD_DIR" --prefix=/usr --buildtype=release
            ninja -C "$BUILD_DIR" -j"$BK_JOBS"
            return 0
          fi
          bl "  Usando autotools (padrão upstream)"
          cd "$SRC_DIR"
          ./configure --prefix=/usr --sysconfdir=/etc
          make -j"$BK_JOBS"
        }

        install(){
          bl "=== imlib2-1.12.6: install (stage em $BK_STAGE_ROOT) ==="
          if [ -f "$SRC_DIR/meson.build" ] && [ -f "$BUILD_DIR/build.ninja" ]; then
            DESTDIR="$BK_STAGE_ROOT" ninja -C "$BUILD_DIR" install
          else
            cd "$SRC_DIR"
            make DESTDIR="$BK_STAGE_ROOT" install
          fi
        }

        main(){
          prepare
          build
          install
          bl "=== Summary $(b imlib2-1.12.6) ==="
          info "  Staged root: $(b "$BK_STAGE_ROOT")"
          info "  Libs...... : $(b "$BK_STAGE_ROOT/usr/lib")"
          info "  Binários.. : $(b "$BK_STAGE_ROOT/usr/bin")"
        }

        main "$@"
