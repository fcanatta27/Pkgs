\
#!/usr/bin/env bash
set -euo pipefail

# Package group: Xorg Applications
#
# Orquestrador para aplicativos Xorg (xterm, xclock, xsetroot, etc.).
# Usa BK_XORG_APPS ou /etc/3bLinux/xorg-apps.list para listar os pacotes.

b(){ tput bold 2>/dev/null||true; echo -n "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; echo "$*"; tput sgr0 2>/dev/null||true; }
info(){ echo "$*"; }

: "${BK_XORG_APPS:=}"

ROOT_PACKAGES_DIR="${BK_PACKAGES_DIR:-/packages}"

load_default_list(){
  if [ -n "$BK_XORG_APPS" ]; then
    printf '%s\n' "$BK_XORG_APPS"
    return 0
  fi
  if [ -f /etc/3bLinux/xorg-apps.list ]; then
    grep -v '^[[:space:]]*#' /etc/3bLinux/xorg-apps.list | sed '/^[[:space:]]*$/d'
    return 0
  fi
  return 1
}

main(){
  bl "=== Xorg Applications: orchestrator ==="
  local apps
  apps=$(load_default_list || true)
  if [ -z "$apps" ]; then
    info "Nenhuma lista de apps definida (BK_XORG_APPS ou /etc/3bLinux/xorg-apps.list)."
    info "Ajuste conforme necessário. Nada a fazer."
    exit 0
  fi

  echo "$apps" | while read -r pkg; do
    [ -z "$pkg" ] && continue
    bl ">>> Build Xorg app: $pkg"
    if [ -x "$ROOT_PACKAGES_DIR/$pkg/build.sh" ]; then
      ( cd "$ROOT_PACKAGES_DIR/$pkg" && ./build.sh )
    else
      info "  [SKIP] build.sh não encontrado em $ROOT_PACKAGES_DIR/$pkg"
    fi
  done
}

main "$@"
