#!/usr/bin/env bash
set -euo pipefail

# Package: gcc
# Version: 15.2.0
#
# Dependencies (host / build) aproximadas:
#   - bash, coreutils, findutils, grep, sed, gawk
#   - tar, xz, gzip, bzip2
#   - make, gcc, pkg-config
#   - curl ou wget
#
# Dependencies (runtime) aproximadas:
#   - libc (glibc), libstdc++, zlib, libgcc
#   - bibliotecas específicas deste pacote (use ldd no binário instalado)
#
# Flags suportadas (ambiente padrão do 3bLinux):
#   BK_JOBS           : paralelismo do make (default 1)
#   BK_DOWNLOAD_DIR   : diretório de cache de tarballs (default /tmp/bk-src)
#   BK_BUILD_DIR      : diretório base de build da receita
#   BK_STAGE_ROOT     : DESTDIR para instalação (conteúdo que será empacotado)
#   BK_*_URL          : URL do tarball da receita (quando definido)
#   BK_*_CONFIG_EXTRA : flags extras passadas para ./configure/meson/cmake/etc.
#
# Flags completas do programa:
#   Consulte:
#     - ./configure --help        (projetos autotools)
#     - meson configure           (projetos Meson)
#     - cmake -LH                 (projetos CMake)
#     - --help do binário final   (opções em tempo de execução)

b(){ tput bold 2>/dev/null||true; printf '%s' "$*"; tput sgr0 2>/dev/null||true; }
bl(){ tput bold 2>/dev/null||true; printf '%s
' "$*"; tput sgr0 2>/dev/null||true; }
info(){ printf '%s
' "$*"; }
die(){ printf 'ERROR: %s
' "$*" >&2; exit 1; }

: "${BK_JOBS:=1}"
: "${BK_DOWNLOAD_DIR:=/tmp/bk-src}"
: "${BK_BUILD_DIR:=/tmp/bk-build/${BK_RECIPE:-gcc-15.2.0-pass1}}"
: "${BK_STAGE_ROOT:=$BK_BUILD_DIR/root}"
: "${BK_TARGET:?BK_TARGET não definido (ex: x86_64-3blinux-gnu)}"

: "${BK_GCC_URL:=https://gcc.gnu.org/pub/gcc/releases/gcc-15.2.0/gcc-15.2.0.tar.xz}"
: "${BK_GCC_LANGUAGES:=c}"
: "${BK_GCC_CONFIG_EXTRA:=}"
: "${BK_GCC_DOWNLOAD_PREREQS:=1}"

TAR="$BK_DOWNLOAD_DIR/gcc-15.2.0.tar.xz"
SRC="$BK_BUILD_DIR/src"
BUILD="$BK_BUILD_DIR/build"

fetch(){
  local url="$1" out="$2"
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then
    info "  Using cached source: $out"
    return 0
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 --output "$out" "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    die "need curl or wget"
  fi
}

bl "=== Build $(b gcc) $(b 15.2.0-pass1) ==="
info "  Name.......: $(b "${BK_PKG_NAME:-gcc}")"
info "  Version....: $(b "${BK_PKG_VERSION:-15.2.0-pass1}")"
info "  Recipe.....: ${BK_RECIPE:-gcc-15.2.0-pass1}"
info "  Target.....: $(b "$BK_TARGET")"
info "  Languages..: $(b "$BK_GCC_LANGUAGES")"
info "  Download...: $(b "$BK_GCC_URL")"
info "  Download dir: $(b "$BK_DOWNLOAD_DIR")"
info "  Build dir..: $(b "$BK_BUILD_DIR")"
info "  Stage root.: $(b "$BK_STAGE_ROOT")"

mkdir -p "$BK_DOWNLOAD_DIR" "$BK_BUILD_DIR" "$BK_STAGE_ROOT"
fetch "$BK_GCC_URL" "$TAR"

rm -rf "$SRC" "$BUILD"
mkdir -p "$SRC" "$BUILD"
tar -xf "$TAR" -C "$SRC" --strip-components=1

# Baixar dependências GMP/MPFR/MPC se solicitado
if [ "$BK_GCC_DOWNLOAD_PREREQS" = "1" ] && [ -x "$SRC/contrib/download_prerequisites" ]; then
  ( cd "$SRC" && ./contrib/download_prerequisites )
fi

cd "$BUILD"

"$SRC/configure" \
  --target="$BK_TARGET" \
  --prefix=/usr \
  --disable-nls \
  --disable-multilib \
  --disable-libssp \
  --disable-libstdcxx-pch \
  --enable-languages="$BK_GCC_LANGUAGES" \
  $BK_GCC_CONFIG_EXTRA

make -j"$BK_JOBS" all-gcc
make DESTDIR="$BK_STAGE_ROOT" install-gcc

bl "=== Summary $(b gcc 15.2.0-pass1) ==="
info "  Compiler...: $(b "$BK_STAGE_ROOT/usr/bin")"
