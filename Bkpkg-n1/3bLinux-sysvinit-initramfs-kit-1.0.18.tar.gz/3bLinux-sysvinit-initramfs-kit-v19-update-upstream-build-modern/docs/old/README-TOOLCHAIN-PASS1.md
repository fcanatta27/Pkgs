\
# 3bLinux – Toolchain Pass 1 (Bootstrap com bk)

Este documento descreve a **fase Toolchain Pass 1** do projeto 3bLinux, usando o
**bk-kit** como gerenciador de pacotes e os scripts de construção em `packages/`.

A ideia desta fase é:

- construir uma **toolchain inicial** (binutils e GCC Pass 1) em um prefixo isolado
  (`/usr/cross`), empacotada via `bk`;
- garantir que as **ferramentas de suporte** necessárias (m4, ncurses, diffutils, gawk, etc.)
  também possam ser construídas e instaladas via `bk`;
- permitir que tudo possa ser feito dentro de um ambiente isolado com `bk-chroot`.

> IMPORTANTE: todos os scripts seguem o padrão:
>
> - build em `/tmp/<nome>-<versão>-build`
> - instalação em `PKG_ROOT=/tmp/.../pkg-root`
> - empacotamento final com `bk package NOME PKG_ROOT`
> - instalação posterior com `bk install NOME` no sistema “de verdade”

---

## 1. Visão geral da ordem de build

Uma ordem sugerida para a fase Pass 1 é:

1. Dependências de documentação / base:
   - `m4-1.4.20`
   - `ncurses-6.5`
   - `diffutils-3.12`
   - `gawk-5.3.2`
   - `grep-3.12`
   - `sed-4.9`
   - `gzip-1.14`
   - `tar-1.35`
   - `file-5.46`
   - `patch-2.8` (usa tarball real 2.7.6)
   - `gdbm-1.23`
   - `groff-1.23.0`
   - `less-643`
   - `man-db-2.13.1` (do bundle anterior)

2. Dependências matemáticas e de libs (caso ainda não tenha feito):
   - `gmp-6.3.0`
   - `mpfr-4.2.2`
   - `mpc-1.3.1`
   - `isl-0.27`
   - `zlib-1.3`
   - `xz-5.8.2`

3. Toolchain Pass 1:
   - `binutils-2.45.1-pass1`
   - `gcc-15.2.0-pass1`

Depois desta fase, você terá um compilador cross (Pass 1) localizado em
`/usr/cross`, gerenciado via `bk`, pronto para ser usado nas próximas fases
(Pass 2, construção de glibc final, etc.).

---

## 2. Variável TARGET

Os scripts de Pass 1 utilizam uma variável `TARGET` para definir o triplo
(“target triple”) do toolchain. Por padrão:

```sh
TARGET="$(uname -m)-3blinux-linux-gnu"
```

Exemplos comuns:

- `x86_64-3blinux-linux-gnu`
- `aarch64-3blinux-linux-gnu`

Você pode sobrescrever na linha de comando, por exemplo:

```sh
TARGET=x86_64-3blinux-linux-gnu ./build-binutils-2.45.1-pass1.sh
TARGET=x86_64-3blinux-linux-gnu ./build-gcc-15.2.0-pass1.sh
```

Internamente, os scripts usam:

- `--target="$TARGET"`
- `--prefix="/usr/cross"`

Assim, o binutils / gcc Pass 1 ficam isolados em `/usr/cross/bin`,
`/usr/cross/lib`, etc.

---

## 3. Exemplo de sequência completa de build (fora ou dentro de bk-chroot)

### 3.1. Pré-requisitos

- `bk` já instalado e funcional.
- Diretório de repositório em `/var/3bLinux` configurado.
- Ambiente base com:
  - compilador host (gcc) funcional;
  - ferramentas básicas (coreutils, bash, etc.).

Se quiser garantir tudo em ambiente controlado, você pode usar o `bk-chroot`
para criar um chroot de bootstrap do 3bLinux.

### 3.2. Usando bk-chroot (fluxo recomendado)

1. Crie uma raiz para o chroot, por exemplo:

   ```sh
   sudo mkdir -p /srv/3blinux-root
   ```

2. Use o `bk-chroot` (script do kit) para entrar:

   ```sh
   sudo ./bk-chroot /srv/3blinux-root
   ```

   O `bk-chroot` do projeto cuida de:

   - montar `proc`, `sys`, `dev`, `run` dentro do chroot;
   - bind-mount de partes necessárias;
   - registrar um trap para desmontar tudo com segurança ao sair.

3. Dentro do chroot, você verá o `/` como se fosse um mini-sistema 3bLinux.
   A partir daí, rode os scripts de construção normalmente:

   ```sh
   cd /caminho/para/3bLinux-sysvinit-initramfs-kit-v13-pass1-baseutils
   ```

### 3.3. Exemplo de build passo-a-passo (simplificado)

Dentro do chroot ou no host (se preferir):

```sh
# 1) Ferramentas de base
cd packages/m4-1.4.20
./build-m4-1.4.20.sh
bk install m4-1.4.20

cd ../ncurses-6.5
./build-ncurses-6.5.sh
bk install ncurses-6.5

cd ../diffutils-3.12
./build-diffutils-3.12.sh
bk install diffutils-3.12

cd ../gawk-5.3.2
./build-gawk-5.3.2.sh
bk install gawk-5.3.2

cd ../grep-3.12
./build-grep-3.12.sh
bk install grep-3.12

cd ../sed-4.9
./build-sed-4.9.sh
bk install sed-4.9

cd ../gzip-1.14
./build-gzip-1.14.sh
bk install gzip-1.14

cd ../tar-1.35
./build-tar-1.35.sh
bk install tar-1.35

cd ../file-5.46
./build-file-5.46.sh
bk install file-5.46

cd ../patch-2.8
./build-patch-2.8.sh
bk install patch-2.8

cd ../gdbm-1.23
./build-gdbm-1.23.sh
bk install gdbm-1.23

cd ../groff-1.23.0
./build-groff-1.23.0.sh
bk install groff-1.23.0

cd ../less-643
./build-less-643.sh
bk install less-643
```

Depois, certifique-se de ter `man-db`, `bash`, etc. (de bundles anteriores) caso
queira um ambiente mais confortável.

### 3.4. Libs matemáticas e compressão

Se ainda não estiverem instaladas, a sequência recomendada:

```sh
cd packages/gmp-6.3.0
./build-gmp-6.3.0.sh
bk install gmp-6.3.0

cd ../mpfr-4.2.2
./build-mpfr-4.2.2.sh
bk install mpfr-4.2.2

cd ../mpc-1.3.1
./build-mpc-1.3.1.sh
bk install mpc-1.3.1

cd ../isl-0.27
./build-isl-0.27.sh
bk install isl-0.27

cd ../zlib-1.3
./build-zlib-1.3.sh
bk install zlib-1.3

cd ../xz-5.8.2
./build-xz-5.8.2.sh
bk install xz-5.8.2
```

---

## 4. Construindo o toolchain Pass 1

### 4.1. Binutils Pass 1

Script:

```sh
cd packages/binutils-2.45.1-pass1
TARGET=x86_64-3blinux-linux-gnu ./build-binutils-2.45.1-pass1.sh
bk install binutils-2.45.1-pass1
```

Isto irá instalar o binutils cross em:

- `/usr/cross/bin`
- `/usr/cross/<TARGET>/bin`
- etc.

### 4.2. GCC Pass 1

Script:

```sh
cd ../gcc-15.2.0-pass1
TARGET=x86_64-3blinux-linux-gnu ./build-gcc-15.2.0-pass1.sh
bk install gcc-15.2.0-pass1
```

Após isso, você deve ter:

- `/usr/cross/bin/${TARGET}-gcc`
- `/usr/cross/bin/${TARGET}-gcc-ar`
- `/usr/cross/bin/${TARGET}-gcc-nm`
- `/usr/cross/bin/${TARGET}-gcc-ranlib`
- `/usr/cross/lib/gcc/${TARGET}/...`

---

## 5. Integrando o Pass 1 com bk e bk-chroot

### 5.1. Gestão com bk

O bk cuida de:

- guardar os pacotes em `/var/3bLinux` (repositório);
- instalar/remover os pacotes no root atual (host ou chroot).

Para ver pacotes:

```sh
bk list
bk info gcc-15.2.0-pass1
```

Para remover:

```sh
bk remove gcc-15.2.0-pass1
```

Isso permite testar, refazer builds e reinstalar sem “sujar” o sistema manualmente.

### 5.2. Uso dentro do chroot

Quando você roda o `bk-chroot /srv/3blinux-root`, tudo que é instalado com `bk`
dentro do chroot afeta **apenas** aquele root.

Exemplo:

```sh
sudo ./bk-chroot /srv/3blinux-root

# Dentro do chroot:
cd /src/3bLinux-sysvinit-initramfs-kit
cd packages/binutils-2.45.1-pass1
TARGET=x86_64-3blinux-linux-gnu ./build-binutils-2.45.1-pass1.sh
bk install binutils-2.45.1-pass1

cd ../gcc-15.2.0-pass1
TARGET=x86_64-3blinux-linux-gnu ./build-gcc-15.2.0-pass1.sh
bk install gcc-15.2.0-pass1
```

Ao sair do chroot, o host não vê `/usr/cross` do chroot; ele está isolado em
`/srv/3blinux-root`.

---

## 6. Notas sobre versões e compatibilidade

- **GNU patch 2.8**: não há tarball amplamente disponível com rótulo `2.8` na
  linha oficial; a última versão estável conhecida é `2.7.6`. O script
  `build-patch-2.8.sh`:
  - baixa `patch-2.7.6.tar.xz`;
  - constrói normalmente;
  - empacota com o nome `patch-2.8` para seguir a convenção do projeto 3bLinux.

Se preferir alinhar exatamente com a versão real, você pode:

- renomear o pacote para `patch-2.7.6` no script; ou
- manter `2.8` apenas como identificador interno do projeto.

---

## 7. Próximos passos (Pass 2 e além)

Com a fase `Toolchain Pass 1` concluída, você terá:

- um conjunto rico de ferramentas POSIX (sed, grep, gawk, patch, etc.);
- suporte a manpages (man-db + groff + less);
- libs matemáticas (gmp, mpfr, mpc, isl);
- toolchain cross inicial (binutils/gcc Pass 1).

Os próximos passos típicos são:

1. Construir e instalar definitivamente:
   - headers do kernel;
   - glibc (usando o toolchain apropriado);
2. Fazer **GCC / binutils Pass 2**, agora apontando para a glibc do 3bLinux;
3. Começar a montar o userland mais completo em cima deste ambiente.

Toda essa evolução continua integrando-se com:

- `bk` para empacotamento/instalação;
- `bk-chroot` para isolamento;
- `init-reparo` e `bk-reparo` para manter consistência e sanidade do sistema.

