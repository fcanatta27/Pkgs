# PERFIL-WORKSTATION-1.0

Este documento descreve o conjunto de pacotes necessários para montar um **desktop stack completo** (perfil workstation) do 3bLinux 1.0.x, e fornece uma lista de comandos `bk-build-wrapper` prontos para copiar/colar.

## Pré-requisito

Dentro do diretório raiz do kit 3bLinux, use sempre:

```sh
cd 3bLinux-sysvinit-initramfs-kit-1.0.x
```

E garanta que `tools/bk-build-wrapper` está executável.

## Option 1 – Construir tudo com um único meta-pacote

O modo mais simples é usar o metapacote `3blinux-workstation` que orquestra tudo em uma ordem razoável:

```sh
tools/bk-build-wrapper 3blinux-workstation-1.0
```

## Option 2 – Construir por etapas (comandos para copiar/colar)

### 1. Base Xorg

```sh
tools/bk-build-wrapper xorg-server
tools/bk-build-wrapper xorg-drivers
tools/bk-build-wrapper xorg-fonts
tools/bk-build-wrapper xbitmaps-1.1.3
tools/bk-build-wrapper xorg-input-drivers-1.0
tools/bk-build-wrapper xcb-utilities-1.0
tools/bk-build-wrapper xorg-applications-1.0
tools/bk-build-wrapper xinit
tools/bk-build-wrapper xterm
tools/bk-build-wrapper twm
tools/bk-build-wrapper xclock-1.1.1
```

### 2. OpenGL / Mesa

```sh
tools/bk-build-wrapper libdrm-2.4.125
tools/bk-build-wrapper libxshmfence-1.3.3
tools/bk-build-wrapper glu-9.0.3
tools/bk-build-wrapper wayland-1.23.0
tools/bk-build-wrapper wayland-protocols-1.40
tools/bk-build-wrapper Mesa-25.3.1
```

### 3. Toolkits GTK / libs GUI

```sh
tools/bk-build-wrapper glib-2.86.3
tools/bk-build-wrapper cairo-1.18.2
tools/bk-build-wrapper harfbuzz-10.4.0
tools/bk-build-wrapper fribidi-1.0.16
tools/bk-build-wrapper pango-1.57.0
tools/bk-build-wrapper gdk-pixbuf-2.44.4
tools/bk-build-wrapper atk-2.38.0
tools/bk-build-wrapper at-spi2-core-2.58.3
tools/bk-build-wrapper libepoxy-1.5.10
tools/bk-build-wrapper gtk2-2.24.33
tools/bk-build-wrapper gtk3-3.24.51
tools/bk-build-wrapper GTK-4.20.3
tools/bk-build-wrapper Gtkmm-3.24.10
tools/bk-build-wrapper Gtkmm-4.20.0
tools/bk-build-wrapper libnotify-0.8.8
tools/bk-build-wrapper startup-notification-0.12
tools/bk-build-wrapper libcanberra-0.30
```

### 4. Web / browser

```sh
tools/bk-build-wrapper firefox-bin-128.8.0esr
tools/bk-build-wrapper WebKitGTK-2.50.4
```

### 5. Áudio (ALSA) + GStreamer

```sh
tools/bk-build-wrapper alsa-lib-1.2.15.3
tools/bk-build-wrapper alsa-utils-1.2.15.2
tools/bk-build-wrapper alsa-tools-1.2.15
tools/bk-build-wrapper alsa-firmware-1.2.4

tools/bk-build-wrapper gstreamer-1.26.10
tools/bk-build-wrapper gst-plugins-base-1.26.10
tools/bk-build-wrapper gst-plugins-good-1.26.10
tools/bk-build-wrapper gst-plugins-bad-1.26.10
tools/bk-build-wrapper gst-plugins-ugly-1.26.10
tools/bk-build-wrapper gst-libav-1.26.10
tools/bk-build-wrapper LAME-3.100
tools/bk-build-wrapper mpg123-1.33.4
```

### 6. Vídeo / codecs / player

```sh
tools/bk-build-wrapper x264-20250815
tools/bk-build-wrapper x265-4.1
tools/bk-build-wrapper libass-0.17.4
tools/bk-build-wrapper ffmpeg-7.0
tools/bk-build-wrapper mpv-0.41.0
tools/bk-build-wrapper dvd+rw-tools-7.1
tools/bk-build-wrapper SDL3-3.4.0
```

### 7. Fonts / ícones / tema

```sh
tools/bk-build-wrapper dejavu-fonts-2.37
tools/bk-build-wrapper liberation-fonts-2.1.5
tools/bk-build-wrapper Hack-fonts-3.003
tools/bk-build-wrapper nerd-fonts-3.3.0
tools/bk-build-wrapper awesome-fonts-6.5.2
tools/bk-build-wrapper Adwaita-fonts-0.303
tools/bk-build-wrapper adwaita-icon-theme-49.0
tools/bk-build-wrapper adwaita-theme-1.0
```

### 8. Sessão gráfica / WMs / utilitários

```sh
tools/bk-build-wrapper lightdm-1.32.0
tools/bk-build-wrapper openbox-3.6.1
tools/bk-build-wrapper Fluxbox-1.3.7
tools/bk-build-wrapper i3-4.23
tools/bk-build-wrapper feh-3.11.2
tools/bk-build-wrapper rxvt-unicode-9.31
tools/bk-build-wrapper xdg-utils-1.2.1
```

Com todos os grupos acima construídos e instalados via `bk`, você terá um desktop stack completo para o perfil workstation do 3bLinux 1.0.x.