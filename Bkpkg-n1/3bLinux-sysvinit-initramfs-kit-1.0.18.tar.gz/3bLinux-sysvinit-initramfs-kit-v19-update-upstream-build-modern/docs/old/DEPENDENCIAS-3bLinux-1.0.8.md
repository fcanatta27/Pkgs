# DEPENDENCIAS-3bLinux-1.0.8

Gerado automaticamente em 2026-01-17 01:58:01Z a partir do bundle 1.0.8 (com scripts adicionais).

| Pacote | Versão | Dependências diretas (resumo) | Script em `packages/` |
|--------|--------|--------------------------------|------------------------|
| `7zip` | `25.01` | cmake; c++ toolchain | `packages/7zip-25.01/build-7zip-25.01.sh` |
| `acl-${VER}` | `2.3.2` | não declarado | `packages/acl-2.3.2/build-acl-2.3.2.sh` |
| `acpid-2.0.34` | `2.0.34` | não declarado | `packages/acpid-2.0.34/build-acpid-2.0.34.sh` |
| `adwaita-fonts` | `0.303` | não declarado | `packages/Adwaita-fonts-0.303/build-Adwaita-fonts-0.303.sh` |
| `adwaita-icon-theme` | `49.0` | gtk4 (para algumas ferramentas); meson; ninja | `packages/adwaita-icon-theme-49.0/build-adwaita-icon-theme-49.0.sh` |
| `alsa-1.2.13` | `` | não declarado | `packages/alsa-1.2.13/build-alsa-1.2.13.sh` |
| `alsa-firmware` | `1.2.4` | binutils; kernel com suporte aos dispositivos; scripts de atualização (opcional) | `packages/alsa-firmware-1.2.4/build-alsa-firmware-1.2.4.sh` |
| `alsa-lib` | `1.2.13` | libpthread (glibc); libdl; pkg-config | `packages/alsa-lib-1.2.13/build-alsa-lib-1.2.13.sh` |
| `alsa-lib` | `1.2.15.3` | libpthread (glibc); libdl; pkg-config | `packages/alsa-lib-1.2.15.3/build-alsa-lib-1.2.15.3.sh` |
| `alsa-tools` | `1.2.15` | alsa-lib; gtk2/gtk3 (para algumas GUIs); libraw1394 (opcional) | `packages/alsa-tools-1.2.15/build-alsa-tools-1.2.15.sh` |
| `alsa-utils` | `1.2.13` | alsa-lib; ncurses; libsamplerate (opcional); libffado (opcional) | `packages/alsa-utils-1.2.13/build-alsa-utils-1.2.13.sh` |
| `alsa-utils` | `1.2.15.2` | alsa-lib; ncurses; libsamplerate (opcional); libffado (opcional) | `packages/alsa-utils-1.2.15.2/build-alsa-utils-1.2.15.2.sh` |
| `at-spi2-core` | `2.58.3` | dbus; glib; libxml2 (recomendado); meson; ninja | `packages/at-spi2-core-2.58.3/build-at-spi2-core-2.58.3.sh` |
| `atk` | `2.38.0` | glib; meson; ninja | `packages/atk-2.38.0/build-atk-2.38.0.sh` |
| `attr-${VER}` | `2.5.2` | não declarado | `packages/attr-2.5.2/build-attr-2.5.2.sh` |
| `autoconf-${VER}` | `2.72` | não declarado | `packages/autoconf-2.72/build-autoconf-2.72.sh` |
| `automake-${VER}` | `1.18.1` | não declarado | `packages/automake-1.18.1/build-automake-1.18.1.sh` |
| `bash-${VER}` | `5.3` | não declarado | `packages/bash-5.3/build-bash-5.3.sh` |
| `bash-completion` | `2.14.0` | bash; pkg-config | `packages/bash-completions-2.14.0/build-bash-completions-2.14.0.sh` |
| `bc-${VER}` | `7.0.3` | não declarado | `packages/bc-7.0.3/build-bc-7.0.3.sh` |
| `binutils-${VER}` | `2.45.1` | não declarado | `packages/binutils-2.45.1/build-binutils-2.45.1.sh` |
| `binutils-${VER}` | `2.45.1` | não declarado | `packages/binutils-2.45.1-pass1/build-binutils-2.45.1-pass1.sh` |
| `binutils-${VER}` | `2.45.1` | não declarado | `packages/binutils-2.45.1-pass2/build-binutils-2.45.1-pass2.sh` |
| `bison-{VER}` | `3.8.2` | não declarado | `packages/bison-3.8.2/build-bison-3.8.2.sh` |
| `brotli` | `1.1.0` | cmake | `packages/brotli-1.1.0/build-brotli-1.1.0.sh` |
| `btrfs-progs-6.17.1` | `6.17.1` | não declarado | `packages/btrfs-progs-6.17.1/build-btrfs-progs-6.17.1.sh` |
| `busybox-1.37.1` | `` | não declarado | `packages/busybox-1.37.1/build-busybox-1.37.1.sh` |
| `bzip2-{VER}` | `1.0.8` | não declarado | `packages/bzip2-1.0.8/build-bzip2-1.0.8.sh` |
| `cairo` | `1.18.2` | pixman; freetype; fontconfig (recomendado); meson; ninja | `packages/cairo-1.18.2/build-cairo-1.18.2.sh` |
| `ccache` | `4.12.2` | cmake; (opcional) ninja | `packages/ccache-4.12.2/build-ccache-4.12.2.sh` |
| `clang-19.1.0` | `` | não declarado | `packages/clang-19.1.0/build-clang-19.1.0.sh` |
| `coreutils-9.9` | `9.9` | não declarado | `packages/coreutils-9.9/build-coreutils-9.9.sh` |
| `curl` | `8.17.0` | openssl; zlib; (opcional) brotli, zstd, nghttp2, libidn2, libpsl | `packages/curl-8.17.0/build-curl-8.17.0.sh` |
| `dbus-${VER}` | `1.16.2` | não declarado | `packages/dbus-1.16.2/build-dbus-1.16.2.sh` |
| `dejagnu-${VER}` | `1.6.3` | não declarado | `packages/dejagnu-1.6.3/build-dejagnu-1.6.3.sh` |
| `dejavu-fonts` | `2.37` | não declarado | `packages/dejavu-fonts-2.37/build-dejavu-fonts-2.37.sh` |
| `dhcpcd` | `10.3.0` | openssl (opcional p/ privsep EAP); libcap (opcional); base system headers | `packages/dhcpcd-10.3.0/build-dhcpcd-10.3.0.sh` |
| `diffutils-${VER}` | `3.12` | não declarado | `packages/diffutils-3.12/build-diffutils-3.12.sh` |
| `dosfstools-4.2` | `4.2` | não declarado | `packages/dosfstools-4.2/build-dosfstools-4.2.sh` |
| `e2fsprogs-${VER}` | `1.47.3` | não declarado | `packages/e2fsprogs-1.47.3/build-e2fsprogs-1.47.3.sh` |
| `elfutils-${VER}` | `0.194` | não declarado | `packages/libelf-elfutils-0.194/build-libelf-elfutils-0.194.sh` |
| `eudev-${VER}` | `3.2.14` | não declarado | `packages/eudev-3.2.14/build-eudev-3.2.14.sh` |
| `expat-${VER}` | `2.6.2` | não declarado | `packages/expat-2.6.2/build-expat-2.6.2.sh` |
| `expect${VER}` | `5.45.4` | não declarado | `packages/expect-5.45.4/build-expect-5.45.4.sh` |
| `feh` | `3.11.2` | imlib2; libX11; libXinerama; libXrandr | `packages/feh-3.11.2/build-feh-3.11.2.sh` |
| `file-${VER}` | `5.46` | não declarado | `packages/file-5.46/build-file-5.46.sh` |
| `findutils-${VER}` | `4.10.0` | não declarado | `packages/findutils-4.10.0/build-findutils-4.10.0.sh` |
| `firefox` | `${VER:-128.8.0esr}` | não declarado | `packages/firefox-128.8.0esr/build-firefox-128.8.0esr.sh` |
| `firefox-bin` | `${VER:-128.8.0esr}` | - glibc, libstdc++, gtk3 stack, dbus, alsa (dependendo do uso), mesa/opengl - fontes (ex. noto-fonts) | `packages/firefox-bin-128.8.0esr/build-firefox-bin-128.8.0esr.sh` |
| `flex-${VER}` | `2.6.4` | não declarado | `packages/flex-2.6.4/build-flex-2.6.4.sh` |
| `flit-core-3.12.0` | `3.12.0` | não declarado | `packages/flit-core-3.12.0/build-flit-core-3.12.0.sh` |
| `fluxbox` | `1.3.7` | libX11; libXft; libXrandr; libXinerama | `packages/Fluxbox-1.3.7/build-Fluxbox-1.3.7.sh` |
| `font-awesome` | `6.5.2` | não declarado | `packages/awesome-fonts-6.5.2/build-awesome-fonts-6.5.2.sh` |
| `FreeType-2.14.1` | `2.14.1` | não declarado | `packages/FreeType-2.14.1/build-FreeType-2.14.1.sh` |
| `fribidi` | `1.0.16` | meson; ninja | `packages/fribidi-1.0.16/build-fribidi-1.0.16.sh` |
| `Fuse-3.18.1` | `3.18.1` | não declarado | `packages/Fuse-3.18.1/build-Fuse-3.18.1.sh` |
| `gawk-${VER}` | `5.3.2` | não declarado | `packages/gawk-5.3.2/build-gawk-5.3.2.sh` |
| `gcc-${VER}` | `15.2.0` | não declarado | `packages/gcc-15.2.0/build-gcc-15.2.0.sh` |
| `gcc-${VER}` | `15.2.0` | não declarado | `packages/gcc-15.2.0-pass1/build-gcc-15.2.0-pass1.sh` |
| `gcc-${VER}` | `15.2.0` | não declarado | `packages/gcc-15.2.0-pass2/build-gcc-15.2.0-pass2.sh` |
| `gdbm-${VER}` | `1.23` | não declarado | `packages/gdbm-1.23/build-gdbm-1.23.sh` |
| `gdk-pixbuf` | `2.44.4` | glib; libpng; jpeg (opcional); tiff (opcional); meson; ninja | `packages/gdk-pixbuf-2.44.4/build-gdk-pixbuf-2.44.4.sh` |
| `gettext-{VER}` | `0.26` | não declarado | `packages/gettext-0.26/build-gettext-0.26.sh` |
| `git` | `2.52.0` | - curl, openssl, expat, zlib - perl (opcional p/ algumas ferramentas e docs) | `packages/git-2.52.0/build-git-2.52.0.sh` |
| `GLib-2.86.3` | `2.86.3` | não declarado | `packages/GLib-2.86.3/build-GLib-2.86.3.sh` |
| `glibc-${VER}` | `2.42` | não declarado | `packages/glibc-2.42/build-glibc-2.42.sh` |
| `glu` | `9.0.3` | mesa/OpenGL; libX11; libXext | `packages/glu-9.0.3/build-glu-9.0.3.sh` |
| `gmp-${VER}` | `6.3.0` | não declarado | `packages/gmp-6.3.0/build-gmp-6.3.0.sh` |
| `gnupg-${VER}` | `2.5.16` | não declarado | `packages/gnupg-2.5.16/build-gnupg-2.5.16.sh` |
| `gperf-${VER}` | `3.3` | não declarado | `packages/gperf-3.3/build-gperf-3.3.sh` |
| `gpgme-${VER}` | `2.0.1` | não declarado | `packages/gpgme-2.0.1/build-gpgme-2.0.1.sh` |
| `gptfdisk-1.0.10` | `1.0.10` | não declarado | `packages/gptfdisk-1.0.10/build-gptfdisk-1.0.10.sh` |
| `graphite2` | `1.3.14` | cmake | `packages/graphite2-1.3.14/build-graphite2-1.3.14.sh` |
| `grep-${VER}` | `3.12` | não declarado | `packages/grep-3.12/build-grep-3.12.sh` |
| `groff-${VER}` | `1.23.0` | não declarado | `packages/groff-1.23.0/build-groff-1.23.0.sh` |
| `grub-${VER}` | `2.14` | não declarado | `packages/grub-2.14/build-grub-2.14-uefi.sh` |
| `grub-2.12` | `2.12` | não declarado | `packages/grub-2.12/build-grub-2.12.sh` |
| `gst-plugins-base` | `1.26.10` | gstreamer; glib; orc (opcional); meson; ninja | `packages/gst-plugins-base-1.26.10/build-gst-plugins-base-1.26.10.sh` |
| `gstreamer` | `1.26.10` | glib; meson; ninja | `packages/gstreamer-1.26.10/build-gstreamer-1.26.10.sh` |
| `gtk-1.0` | `` | não declarado | `packages/gtk-1.0/build-gtk-1.0.sh` |
| `gtk2` | `2.24.33` | glib; pango; atk; cairo; gdk-pixbuf; xorg libs | `packages/gtk2-2.24.33/build-gtk2-2.24.33.sh` |
| `gtk3` | `3.24.51` | glib; pango; atk; cairo; gdk-pixbuf; at-spi2-core; libepoxy; xorg libs; meson; ninja | `packages/gtk3-3.24.51/build-gtk3-3.24.51.sh` |
| `gtk4` | `4.20.3` | glib; pango; cairo; gdk-pixbuf; atk; at-spi2-core; libepoxy; wayland; xorg libs; meson; ninja | `packages/GTK-4.20.3/build-GTK-4.20.3.sh` |
| `gtkmm3` | `3.24.10` | gtk3; glibmm; cairomm; pangomm; meson; ninja | `packages/Gtkmm-3.24.10/build-Gtkmm-3.24.10.sh` |
| `gtkmm4` | `4.20.0` | gtk4; glibmm; cairomm; pangomm; meson; ninja | `packages/Gtkmm-4.20.0/build-Gtkmm-4.20.0.sh` |
| `gzip-${VER}` | `1.14` | não declarado | `packages/gzip-1.14/build-gzip-1.14.sh` |
| `hack-fonts` | `3.003` | não declarado | `packages/Hack-fonts-3.003/build-Hack-fonts-3.003.sh` |
| `harfbuzz` | `10.4.0` | freetype; glib; graphite2; fribidi; meson; ninja | `packages/harfbuzz-10.4.0/build-harfbuzz-10.4.0.sh` |
| `hwclock-2.40.2` | `2.40.2` | não declarado | `packages/hwclock-2.40.2/build-hwclock-2.40.2.sh` |
| `i3` | `4.23` | xcb-utils; xcb-util-wm; xcb-util-keysyms; pango; yajl; meson; ninja | `packages/i3-4.23/build-i3-4.23.sh` |
| `iana-etc-{VER}` | `20251215` | não declarado | `packages/iana-etc-20251215/build-iana-etc-20251215.sh` |
| `imlib2` | `1.12.6` | libjpeg; libpng; freetype; pkg-config | `packages/imlib2-1.12.6/build-imlib2-1.12.6.sh` |
| `inetutils-${VER}` | `2.7` | não declarado | `packages/inetutils-2.7/build-inetutils-2.7.sh` |
| `intltool-${VER}` | `0.51.0` | não declarado | `packages/intltool-0.51.0/build-intltool-0.51.0.sh` |
| `iproute2-${VER}` | `6.18.0` | não declarado | `packages/iproute2-6.18.0/build-iproute2-6.18.0.sh` |
| `iptables-${VER}` | `1.8.11` | não declarado | `packages/iptables-1.8.11/build-iptables-1.8.11.sh` |
| `isl-${VER}` | `0.27` | não declarado | `packages/isl-0.27/build-isl-0.27.sh` |
| `Jinja2-${VER}` | `3.1.6` | não declarado | `packages/Jinja2-3.1.6/build-Jinja2-3.1.6.sh` |
| `kbd-${VER}` | `2.9.0` | não declarado | `packages/kbd-2.9.0/build-kbd-2.9.0.sh` |
| `kernel-6.18.2` | `` | não declarado | `packages/kernel-6.18.2/build-kernel-6.18.2.sh` |
| `kernel-headers-6.18.2` | `` | não declarado | `packages/kernel-headers-6.18.2/build-kernel-headers-6.18.2.sh` |
| `kmod-${VER}` | `34.2` | não declarado | `packages/kmod-34.2/build-kmod-34.2.sh` |
| `less-${VER}` | `643` | não declarado | `packages/less-643/build-less-643.sh` |
| `libarchive` | `3.8.5` | zlib; liblzma (xz); libbz2 (bzip2); libzstd; liblz4 (opcional) | `packages/libarchive-3.8.5/build-libarchive-3.8.5.sh` |
| `libcap-${VER}` | `2.77` | não declarado | `packages/libcap-2.77/build-libcap-2.77.sh` |
| `libdrm` | `2.4.125` | libpciaccess (opcional); wayland (opcional); meson; ninja | `packages/libdrm-2.4.125/build-libdrm-2.4.125.sh` |
| `libepoxy` | `1.5.10` | mesa/opengl headers; xorg libs; meson; ninja | `packages/libepoxy-1.5.10/build-libepoxy-1.5.10.sh` |
| `liberation-fonts` | `2.1.5` | não declarado | `packages/liberation-fonts-2.1.5/build-liberation-fonts-2.1.5.sh` |
| `libffi-${VER}` | `3.5.2` | não declarado | `packages/libffi-3.5.2/build-libffi-3.5.2.sh` |
| `libfontenc-1.1.8` | `1.1.8` | xorgproto; util-macros; pkg-config | `packages/libfontenc-1.1.8/build-libfontenc-1.1.8.sh` |
| `libICE-1.1.2` | `1.1.2` | xtrans; xorgproto; util-macros; pkg-config | `packages/libICE-1.1.2/build-libICE-1.1.2.sh` |
| `libidn2` | `2.3.8` | libunistring | `packages/libidn2-2.3.8/build-libidn2-2.3.8.sh` |
| `libnotify` | `0.8.8` | glib; gobject; gtk3; meson; ninja | `packages/libnotify-0.8.8/build-libnotify-0.8.8.sh` |
| `liboauth-${VER}` | `1.0.3` | não declarado | `packages/liboauth-1.0.3/build-liboauth-1.0.3.sh` |
| `libpipeline-${VER}` | `1.5.8` | não declarado | `packages/libpipeline-1.5.8/build-libpipeline-1.5.8.sh` |
| `libpsl` | `0.21.5` | libidn2; meson; ninja | `packages/libpsl-0.21.5/build-libpsl-0.21.5.sh` |
| `libSM-1.2.6` | `1.2.6` | libICE; xtrans; pkg-config | `packages/libSM-1.2.6/build-libSM-1.2.6.sh` |
| `libssh2` | `1.11.1` | openssl; zlib | `packages/libssh2-1.11.1/build-libssh2-1.11.1.sh` |
| `libtool-${VER}` | `2.5.4` | não declarado | `packages/libtool-2.5.4/build-libtool-2.5.4.sh` |
| `libunistring` | `1.3` | autotools | `packages/libunistring-1.3/build-libunistring-1.3.sh` |
| `libX11-1.8.10` | `1.8.10` | xorgproto; xtrans; libXau; libxcb; libXdmcp (opcional); pkg-config | `packages/libX11-1.8.10/build-libX11-1.8.10.sh` |
| `libXau-1.0.12` | `1.0.12` | xorgproto; util-macros; pkg-config | `packages/libXau-1.0.12/build-libXau-1.0.12.sh` |
| `libxcb-1.17.0` | `1.17.0` | xcb-proto; libXau; (opcional) libXdmcp; pkg-config | `packages/libxcb-1.17.0/build-libxcb-1.17.0.sh` |
| `libXcomposite-0.4.6` | `0.4.6` | libX11; xorgproto; pkg-config | `packages/libXcomposite-0.4.6/build-libXcomposite-0.4.6.sh` |
| `libxcrypt-${VER}` | `4.5.2` | não declarado | `packages/libxcrypt-4.5.2/build-libxcrypt-4.5.2.sh` |
| `libXcursor-1.2.3` | `1.2.3` | libX11; xorgproto; pkg-config | `packages/libXcursor-1.2.3/build-libXcursor-1.2.3.sh` |
| `libxcvt-0.1.3` | `0.1.3` | meson; ninja; pkg-config | `packages/libxcvt-0.1.3/build-libxcvt-0.1.3.sh` |
| `libXdamage-1.1.6` | `1.1.6` | libX11; xorgproto; pkg-config | `packages/libXdamage-1.1.6/build-libXdamage-1.1.6.sh` |
| `libXdmcp-1.1.5` | `1.1.5` | libXau; xorgproto; util-macros; pkg-config | `packages/libXdmcp-1.1.5/build-libXdmcp-1.1.5.sh` |
| `libXext-1.3.4` | `1.3.4` | libX11; xorgproto; pkg-config | `packages/libXext-1.3.4/build-libXext-1.3.4.sh` |
| `libXfixes-6.0.1` | `6.0.1` | libX11; xorgproto; pkg-config | `packages/libXfixes-6.0.1/build-libXfixes-6.0.1.sh` |
| `libXfont2-2.0.7` | `2.0.7` | FreeType; Fontconfig; libX11; xorgproto; pkg-config | `packages/libXfont2-2.0.7/build-libXfont2-2.0.7.sh` |
| `libXi-1.8.2` | `1.8.2` | libX11; xorgproto; pkg-config | `packages/libXi-1.8.2/build-libXi-1.8.2.sh` |
| `libXinerama-1.1.5` | `1.1.5` | libX11; xorgproto; pkg-config | `packages/libXinerama-1.1.5/build-libXinerama-1.1.5.sh` |
| `libxkbfile-1.1.3` | `1.1.3` | libX11; xorgproto; pkg-config | `packages/libxkbfile-1.1.3/build-libxkbfile-1.1.3.sh` |
| `libXrandr-1.5.4` | `1.5.4` | libX11; xorgproto; pkg-config | `packages/libXrandr-1.5.4/build-libXrandr-1.5.4.sh` |
| `libXrender-0.9.12` | `0.9.12` | libX11; xorgproto; pkg-config | `packages/libXrender-0.9.12/build-libXrender-0.9.12.sh` |
| `libxshmfence` | `1.3.3` | xorgproto | `packages/libxshmfence-1.3.3/build-libxshmfence-1.3.3.sh` |
| `libXtst-1.2.5` | `1.2.5` | libX11; xorgproto; pkg-config | `packages/libXtst-1.2.5/build-libXtst-1.2.5.sh` |
| `lightdm` | `1.32.0` | glib; gtk3 (para greeters padrão); libX11; libXdmcp; pam; systemd-logind/consolekit | `packages/lightdm-1.32.0/build-lightdm-1.32.0.sh` |
| `Linux-PAM-${VER}` | `1.7.1` | não declarado | `packages/Linux-PAM-1.7.1/build-Linux-PAM-1.7.1.sh` |
| `llvm` | `19.1.0` | - cmake, ninja, python3 - gcc/cc, binutils - zlib (recomendado), libxml2 (recomendado), libedit (opcional) | `packages/llvm-19.1.0/build-llvm-19.1.0.sh` |
| `LSB-Tools-0.12` | `0.12` | não declarado | `packages/LSB-Tools-0.12/build-LSB-Tools-0.12.sh` |
| `lz4-${VER}` | `1.10.0` | não declarado | `packages/lz4-1.10.0/build-lz4-1.10.0.sh` |
| `m4-${VER}` | `1.4.20` | não declarado | `packages/m4-1.4.20/build-m4-1.4.20.sh` |
| `make-${VER}` | `4.4.1` | não declarado | `packages/make-4.4.1/build-make-4.4.1.sh` |
| `make-ca-${VER}` | `1.16.1` | não declarado | `packages/make-ca-1.16.1/build-make-ca-1.16.1.sh` |
| `man-db-${VER}` | `2.13.1` | não declarado | `packages/man-db-2.13.1/build-man-db-2.13.1.sh` |
| `man-pages-{VER}` | `6.16` | não declarado | `packages/man-pages-6.16/build-man-pages-6.16.sh` |
| `MarkupSafe-${VER}` | `3.0.3` | não declarado | `packages/MarkupSafe-3.0.3/build-MarkupSafe-3.0.3.sh` |
| `mesa` | `25.3.1` | llvm; libdrm; wayland; wayland-protocols; libxshmfence; zlib; libX11; libXext; libXfixes; meson; ninja | `packages/Mesa-25.3.1/build-Mesa-25.3.1.sh` |
| `meson-1.10.0` | `1.10.0` | não declarado | `packages/meson-1.10.0/build-meson-1.10.0.sh` |
| `mpc-${VER}` | `1.3.1` | não declarado | `packages/mpc-1.3.1/build-mpc-1.3.1.sh` |
| `mpfr-${VER}` | `4.2.2` | não declarado | `packages/mpfr-4.2.2/build-mpfr-4.2.2.sh` |
| `ncurses-${VER}` | `6.5` | não declarado | `packages/ncurses-6.5/build-ncurses-6.5.sh` |
| `nerd-fonts` | `3.3.0` | não declarado | `packages/nerd-fonts-3.3.0/build-nerd-fonts-3.3.0.sh` |
| `net-tools` | `2.10` | - kernel headers; libc - make; gcc/cc - (opcional) libselinux para recursos específicos | `packages/Net-tools-2.10/build-Net-tools-2.10.sh` |
| `nghttp2` | `1.67.1` | openssl; zlib; pkg-config | `packages/nghttp2-1.67.1/build-nghttp2-1.67.1.sh` |
| `ninja-1.13.2` | `1.13.2` | não declarado | `packages/ninja-1.13.2/build-ninja-1.13.2.sh` |
| `notification-daemon-3.20.0` | `3.20.0` | não declarado | `packages/notification-daemon-3.20.0/build-notification-daemon-3.20.0.sh` |
| `noto-fonts-2025.12.01` | `2025.12.01` | não declarado | `packages/noto-fonts-2025.12.01/build-noto-fonts-2025.12.01.sh` |
| `ntp` | `4.2.8p17` | openssl; libcap; libevent (opcional) | `packages/ntp-4.2.8p17/build-ntp-4.2.8p17.sh` |
| `openbox` | `3.6.1` | glib; pango; libX11; libXinerama; libXrandr; startup-notification (opcional) | `packages/openbox-3.6.1/build-openbox-3.6.1.sh` |
| `openssl-${VER}` | `3.6.0` | não declarado | `packages/openssl-3.6.0/build-openssl-3.6.0.sh` |
| `packaging-25.0` | `25.0` | não declarado | `packages/packaging-25.0/build-packaging-25.0.sh` |
| `pango` | `1.57.0` | glib; harfbuzz; fribidi; cairo; meson; ninja | `packages/pango-1.57.0/build-pango-1.57.0.sh` |
| `parted-3.6` | `3.6` | não declarado | `packages/parted-3.6/build-parted-3.6.sh` |
| `patch-${VER_REAL}` | `` | não declarado | `packages/patch-2.8/build-patch-2.8.sh` |
| `pcre2-${VER}` | `10.47` | não declarado | `packages/pcre2-10.47/build-pcre2-10.47.sh` |
| `perl-{VER}` | `5.42.0` | não declarado | `packages/perl-5.42.0/build-perl-5.42.0.sh` |
| `pixman-0.46.4` | `0.46.4` | meson; ninja; pkg-config; (opcional) libpng | `packages/pixman-0.46.4/build-pixman-0.46.4.sh` |
| `pkgconf-${VER}` | `2.5.1` | não declarado | `packages/pkgconf-2.5.1/build-pkgconf-2.5.1.sh` |
| `pm-utils-1.4.1` | `1.4.1` | não declarado | `packages/pm-utils-1.4.1/build-pm-utils-1.4.1.sh` |
| `procps-ng-${VER}` | `4.0.5` | não declarado | `packages/procps-ng-4.0.5/build-procps-ng-4.0.5.sh` |
| `psmisc-${VER}` | `23.7` | não declarado | `packages/psmisc-23.7/build-psmisc-23.7.sh` |
| `Python-{VER}` | `3.14.2` | não declarado | `packages/python-3.14.2/build-python-3.14.2.sh` |
| `qemu-10.2.0` | `10.2.0` | não declarado | `packages/qemu-10.2.0/build-qemu-10.2.0.sh` |
| `readline-${VER}` | `8.3` | não declarado | `packages/readline-8.3/build-readline-8.3.sh` |
| `reiserfsprogs-3.6.27` | `3.6.27` | não declarado | `packages/reiserfsprogs-3.6.27/build-reiserfsprogs-3.6.27.sh` |
| `rsync-3.4.1` | `3.4.1` | não declarado | `packages/rsync-3.4.1/build-rsync-3.4.1.sh` |
| `rust` | `1.92.0` | não declarado | `packages/Rustc-1.92.0/build-Rustc-1.92.0.sh` |
| `rxvt-unicode` | `9.31` | libX11; libXrender; libXft; perl | `packages/rxvt-unicode-9.31/build-rxvt-unicode-9.31.sh` |
| `sed-${VER}` | `4.9` | não declarado | `packages/sed-4.9/build-sed-4.9.sh` |
| `setuptools-80.9.0` | `80.9.0` | não declarado | `packages/setuptools-80.9.0/build-setuptools-80.9.0.sh` |
| `shadow-${VER}` | `4.16.0` | não declarado | `packages/shadow-4.16.0/build-shadow-4.16.0.sh` |
| `slang` | `2.3.3` | ncurses; libm | `packages/slang-2.3.3/build-slang-2.3.3.sh` |
| `smartmontools-7.5` | `7.5` | não declarado | `packages/smartmontools-7.5/build-smartmontools-7.5.sh` |
| `sqlite-autoconf-${VER}` | `3510200` | não declarado | `packages/sqlite-3510200/build-sqlite-3510200.sh` |
| `sshfs-3.7.5` | `3.7.5` | não declarado | `packages/sshfs-3.7.5/build-sshfs-3.7.5.sh` |
| `startup-notification` | `0.12` | glib; x11; xorg libs; pkg-config | `packages/startup-notification-0.12/build-startup-notification-0.12.sh` |
| `sudo-1.9.17p2` | `1.9.17p2` | não declarado | `packages/sudo-1.9.17p2/build-sudo-1.9.17p2.sh` |
| `sysklogd-${VER}` | `2.7.2` | não declarado | `packages/sysklogd-2.7.2/build-sysklogd-2.7.2.sh` |
| `sysvinit-${VER}` | `3.15` | não declarado | `packages/sysvinit-3.15/build-sysvinit-3.15.sh` |
| `tar-${VER}` | `1.35` | não declarado | `packages/tar-1.35/build-tar-1.35.sh` |
| `tcl${SRC_VER}` | `8.6.17` | não declarado | `packages/tcl-8.6.17/build-tcl-8.6.17.sh` |
| `texinfo-{VER}` | `7.2` | não declarado | `packages/texinfo-7.2/build-texinfo-7.2.sh` |
| `twm-1.0.13.1` | `1.0.13.1` | libX11; libXext; (opcional) libXmu; pkg-config | `packages/twm-1.0.13.1/build-twm-1.0.13.1.sh` |
| `tzdata-${TZ_RELEASE}` | `2025` | não declarado | `packages/tzdata-2025/build-tzdata-2025.sh` |
| `UDisks-2.11.0` | `2.11.0` | não declarado | `packages/UDisks-2.11.0/build-UDisks-2.11.0.sh` |
| `util-linux-{VER}` | `2.41.3` | não declarado | `packages/util-linux-2.41.3/build-util-linux-2.41.3.sh` |
| `util-macros-1.20.2` | `1.20.2` | autoconf/automake/libtool; m4; pkg-config | `packages/util-macros-1.20.2/build-util-macros-1.20.2.sh` |
| `vala` | `0.56.18` | glib; meson; ninja; flex/bison (para alguns cenários) | `packages/Vala-0.56.18/build-Vala-0.56.18.sh` |
| `vim-${VER}` | `9.1.2031` | não declarado | `packages/vim-9.1.2031/build-vim-9.1.2031.sh` |
| `wayland` | `1.23.0` | expat; libffi; meson; ninja | `packages/wayland-1.23.0/build-wayland-1.23.0.sh` |
| `wayland-protocols` | `1.40` | meson; ninja; wayland | `packages/wayland-protocols-1.40/build-wayland-protocols-1.40.sh` |
| `webkitgtk` | `2.50.4` | gtk3/gtk4; libsoup; libwebp; libjpeg; libpng; libicu; gstreamer; gst-plugins-base; wayland/x11; cmake; ninja | `packages/WebKitGTK-2.50.4/build-WebKitGTK-2.50.4.sh` |
| `wget` | `1.25.0` | openssl; zlib; (opcional) libidn2, libunistring | `packages/wget-1.25.0/build-wget-1.25.0.sh` |
| `wheel-0.46.1` | `0.46.1` | não declarado | `packages/wheel-0.46.1/build-wheel-0.46.1.sh` |
| `wireless_tools` | `29` | - kernel headers; libc - make; gcc/cc | `packages/Wireless-Tools-29/build-Wireless-Tools-29.sh` |
| `xbitmaps` | `1.1.3` | xorgproto; util-macros | `packages/xbitmaps-1.1.3/build-xbitmaps-1.1.3.sh` |
| `xcb-proto-1.17.0` | `1.17.0` | python3; xorgproto; util-macros; pkg-config | `packages/xcb-proto-1.17.0/build-xcb-proto-1.17.0.sh` |
| `xcb-util` | `0.4.1` | libxcb; xorgproto | `packages/xcb-util-0.4.1/build-xcb-util-0.4.1.sh` |
| `xcb-util-image` | `0.4.1` | libxcb; xorgproto | `packages/xcb-util-image-0.4.1/build-xcb-util-image-0.4.1.sh` |
| `xcb-util-keysyms` | `0.4.1` | libxcb; xorgproto | `packages/xcb-util-keysyms-0.4.1/build-xcb-util-keysyms-0.4.1.sh` |
| `xcb-util-renderutil` | `0.3.10` | libxcb; xorgproto | `packages/xcb-util-renderutil-0.3.10/build-xcb-util-renderutil-0.3.10.sh` |
| `xcb-util-wm` | `0.4.2` | libxcb; xorgproto | `packages/xcb-util-wm-0.4.2/build-xcb-util-wm-0.4.2.sh` |
| `xcb-utilities-1.0` | `` | não declarado | `packages/xcb-utilities-1.0/build-xcb-utilities-1.0.sh` |
| `xclock` | `1.1.1` | libX11; libXrender; libXft; libXt; libXaw; libXmu; xorgproto | `packages/xclock-1.1.1/build-xclock-1.1.1.sh` |
| `xcursor-themes` | `1.0.7` | libXcursor; xorgproto | `packages/xcursor-themes-1.0.7/build-xcursor-themes-1.0.7.sh` |
| `xdg-utils` | `1.2.1` | bash; coreutils; xorg; desktop-file-utils | `packages/xdg-utils-1.2.1/build-xdg-utils-1.2.1.sh` |
| `xf86-input-evdev` | `2.10.6` | xorg-server; xorgproto; pkg-config | `packages/xf86-input-evdev-2.10.6/build-xf86-input-evdev-2.10.6.sh` |
| `xf86-input-libinput` | `1.6.0` | libinput; libxkbcommon; xorg-server; xorgproto; pkg-config | `packages/xf86-input-libinput-1.6.0/build-xf86-input-libinput-1.6.0.sh` |
| `xfsprogs-6.18.0` | `6.18.0` | não declarado | `packages/xfsprogs-6.18.0/build-xfsprogs-6.18.0.sh` |
| `xinit-1.4.4` | `1.4.4` | xorg-server; libX11; xorgproto; pkg-config | `packages/xinit-1.4.4/build-xinit-1.4.4.sh` |
| `xkeyboard-config` | `2.46` | xkbcomp; xorgproto; meson; ninja | `packages/XKeyboardConfig-2.46/build-XKeyboardConfig-2.46.sh` |
| `XML-Parser-${VER}` | `2.47` | não declarado | `packages/xml-parser-2.47/build-xml-parser-2.47.sh` |
| `xorg-applications-1.0` | `` | não declarado | `packages/xorg-applications-1.0/build-xorg-applications-1.0.sh` |
| `xorg-drivers-1.0` | `` | não declarado | `packages/xorg-drivers-1.0/build-xorg-drivers-1.0.sh` |
| `xorg-fonts-1.0` | `` | - xorgproto, util-macros, pkg-config - mkfontscale/mkfontdir (font-util instala), bdftopcf (opcional) e gzip/bzip2/xz | `packages/xorg-fonts-1.0/build-xorg-fonts-1.0.sh` |
| `xorg-input-drivers-1.0` | `` | não declarado | `packages/xorg-input-drivers-1.0/build-xorg-input-drivers-1.0.sh` |
| `xorg-server-21.1.21` | `21.1.21` | pixman; libX11; libXext; libXrender; libXfont2; libxkbfile; libxcvt; (opcional) mesa/libdrm/libepoxy se habilitar glamor/dri | `packages/xorg-server-21.1.21/build-xorg-server-21.1.21.sh` |
| `xorgproto-2024.1` | `2024.1` | util-macros; pkg-config; (opcional) python3 para alguns checks | `packages/xorgproto-2024.1/build-xorgproto-2024.1.sh` |
| `xorriso-1.5.6` | `1.5.6` | não declarado | `packages/xorriso-1.5.6/build-xorriso-1.5.6.sh` |
| `xterm-406` | `406` | ncurses; libX11; (opcional) libXft/fontconfig/freetype; pkg-config | `packages/xterm-406/build-xterm-406.sh` |
| `xtrans-1.5.1` | `1.5.1` | xorgproto; util-macros; pkg-config | `packages/xtrans-1.5.1/build-xtrans-1.5.1.sh` |
| `xz-${VER}` | `5.8.2` | não declarado | `packages/xz-5.8.2/build-xz-5.8.2.sh` |
| `yasm` | `1.3.0` | libc; gcc | `packages/yasm-1.3.0/build-yasm-1.3.0.sh` |
| `zlib-${VER}` | `1.3` | não declarado | `packages/zlib-1.3/build-zlib-1.3.sh` |
| `zstd-${VER}` | `1.5.7` | não declarado | `packages/zstd-1.5.7/build-zstd-1.5.7.sh` |