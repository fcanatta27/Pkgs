# Tutorial – Conjunto de ferramentas do 3bLinux (bk-*)

Este tutorial explica o conjunto de ferramentas do 3bLinux e como elas trabalham juntas.

## 1. Visão geral das ferramentas

Principais scripts em `tools/`:

- `bk-build-wrapper` – wrapper principal de build.
- `bk-update` – atualização de pacotes a partir de repositório.
- `bk-upstream` – configuração de origem de repositório, canais stable/testing.
- `bk-initramfs` – (re)geração de initramfs.
- `bk-mkiso` – geração de ISO inicializável.
- `bk-install` – instalação do 3bLinux em disco.
- `bk-postinstall-workstation` – pós-instalação de perfil workstation.
- `bk-update-alternatives` – ajustes inteligentes de `update-alternatives`.
- `bk-reparo` – reparos gerais (init, alternativas, caches, etc.).

## 2. bk-build-wrapper

Responsável por:

- localizar scripts `packages/<nome>/build-*.sh`;
- garantir ambiente mínimo (variáveis, diretórios);
- chamar o script de build e depois empacotar o resultado.

Exemplo:

```sh
tools/bk-build-wrapper coreutils-9.9
```

Fluxo:

1. Cria diretórios temporários.
2. Chama `packages/coreutils-9.9/build-coreutils-9.9.sh`.
3. Ao final, pega `PKG_ROOT` e gera um arquivo de pacote.
4. Atualiza o índice do repositório local.

## 3. bk-update

Trabalha em conjunto com:

- índices de repositório;
- URLs configuradas em `bk-upstream`.

Funções:

- baixar índice do repositório (stable/testing);
- comparar com o estado atual do sistema;
- baixar pacotes novos;
- aplicar atualização;
- criar snapshots para rollback.

Comando típico:

```sh
sudo bk-update
```

## 4. bk-upstream

Gerencia configurações de origem:

- URLs de `stable` e `testing`;
- chaves de assinatura;
- canal atual utilizado pelo sistema.

Exemplos de operações (conceituais):

- `bk-upstream set stable http://servidor/repo/stable`
- `bk-upstream set testing http://servidor/repo/testing`
- `bk-upstream channel stable`
- `bk-upstream channel testing`

Assim, `bk-update` sabe de onde buscar.

## 5. bk-initramfs

Responsável por:

- montar um initramfs consistente com o rootfs e kernel atuais;
- incluir binários essenciais, módulos, scripts de init.

Uso típico:

```sh
sudo bk-initramfs --kernel /boot/vmlinuz-3blinux
```

Internamente, ele:

- cria uma árvore temporária;
- copia busybox, libs e scripts;
- gera um cpio comprimido;
- salva em `/boot/initramfs-3blinux.img` (ou nome equivalente).

## 6. bk-mkiso

Gera uma ISO inicializável:

- cria árvore de ISO (root, boot, grub);
- copia kernel + initramfs + arquivos de boot;
- chama `xorriso`/`grub-mkrescue`.

Uso:

```sh
sudo tools/bk-mkiso \
  --rootfs ./rootfs \
  --kernel ./rootfs/boot/vmlinuz-3blinux \
  --initramfs ./rootfs/boot/initramfs-3blinux.img \
  --output ./3bLinux-1.0.iso
```

## 7. bk-install

Script de instalação que:

1. detecta discos e partições;
2. permite criar/formatar partições;
3. copia o rootfs para a partição escolhida;
4. gera `/etc/fstab` adequado;
5. instala e configura GRUB no disco;
6. acerta runlevels padrão (`/etc/inittab`), hostname, rede básica.

Uso geral (depois de bootar pela ISO):

```sh
sudo bk-install
```

## 8. bk-postinstall-workstation

Script que automatiza a preparação de uma **workstation gráfica**:

- constrói (via `bk-build-wrapper`) os pacotes críticos de desktop;
- chama `bk-update-alternatives apply-default`;
- chama `/bk-reparo` para verificar init/bootchain e atualizar caches;
- deixa o sistema pronto para `init 5` + LightDM.

Uso típico após instalar em disco:

```sh
sudo tools/bk-postinstall-workstation
sudo init 5
```

## 9. bk-update-alternatives

Script inteligente que:

- detecta terminais (`rxvt-unicode`, `xterm`, etc.);
- detecta WMs (`openbox`, `fluxbox`, `i3`);
- detecta browsers, editores, temas de cursor e ícones;
- registra alternativas relevantes via `update-alternatives`:

  - `x-terminal-emulator`
  - `x-window-manager`
  - `x-www-browser`
  - `editor`
  - `x-cursor-theme`
  - `x-icon-theme`

Comandos:

```sh
tools/bk-update-alternatives detect
sudo tools/bk-update-alternatives apply-default
tools/bk-update-alternatives list
```

## 10. bk-reparo

Script que:

- checa a **bootchain** (init, scripts de rc, etc.);
- chama `bk-update-alternatives apply-default` (ou o binário instalado no sistema);
- atualiza caches de desktop:

  - `update-desktop-database`
  - `gtk-update-icon-cache`
  - `fc-cache`
  - `update-mime-database`
  - `xdg-desktop-menu forceupdate`

É chamado:

- automaticamente antes do LightDM subir;
- em `~/.xinitrc` padrão;
- pode ser chamado manualmente:

  ```sh
  sudo /bk-reparo --verbose
  ```

## 11. Como tudo coopera automaticamente

- `bk-build-wrapper` garante builds e pacotes consistentes.
- `bk-update` aplica atualizações do repositório.
- `bk-initramfs` e `bk-mkiso` mantêm boot e ISO alinhados com o rootfs.
- `bk-install` instala em disco com boot funcional.
- `bk-postinstall-workstation` monta o ambiente desktop.
- `bk-update-alternatives` e `bk-reparo` mantêm a experiência gráfica ajustada.

Essa orquestração permite que você:

- automatize ao máximo, mas ainda tenha controle total sobre scripts e rootfs;
- use o 3bLinux como base para sua própria distro, com pipeline de build → repo → ISO → instalação → atualização.
