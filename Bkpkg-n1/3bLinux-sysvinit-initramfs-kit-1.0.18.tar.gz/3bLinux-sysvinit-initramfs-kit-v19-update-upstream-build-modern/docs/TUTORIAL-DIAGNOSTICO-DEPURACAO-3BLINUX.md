# Tutorial – Diagnóstico e depuração (init, Xorg, display manager, builds)

Este tutorial foca em como **diagnosticar e depurar problemas** no 3bLinux:

- boot (init, initramfs);
- Xorg, display manager (LightDM), xinit;
- builds de programas e dependências.

## 1. Problemas de boot (init, initramfs, GRUB)

### 1.1. Sintomas

- Kernel entra, mas trava antes de montar root.
- Mensagens do tipo:
  - "cannot mount root fs"
  - "no init found"
- Kernel entra, mas logo cai em um shell de emergência do initramfs.

### 1.2. Passos de diagnóstico

1. **Ver mensagens do kernel / initramfs**  
   Olhe atentamente as últimas linhas de erro.

2. **Checar parâmetros `root=` no GRUB**:

   - Use UUIDs estáveis em vez de `/dev/sda1`.
   - Exemplo:

     ```cfg
     linux /boot/vmlinuz-3blinux root=UUID=<uuid-da-particao> rw
     ```

3. **Conferir se a partição existe e está formatada**  
   Num ambiente de rescue, rode:

   ```sh
   lsblk
   blkid
   ```

4. **Validar initramfs**:

   - Certifique-se que o initramfs foi criado com os módulos necessários (drivers de disco, FS).
   - Regere:

     ```sh
     sudo bk-initramfs --kernel /boot/vmlinuz-3blinux
     ```

5. **`/etc/fstab` inválido**:

   - Se o root é montado, mas o sistema trava ao montar outras partições:
     - confira `/etc/fstab`;
     - comente temporariamente entradas suspeitas;
     - use `0 0` em partições não críticas.

## 2. Problemas de init/sysvinit

### 2.1. Sintomas

- Sistema entra, mas não sobe serviços esperados.
- Runlevel errado (gráfico não sobe, ou não entra no multiuser text).
- Mensagens sobre `inittab` inválido.

### 2.2. Checagens

1. **Verificar `/etc/inittab`**:

   - `id:3:initdefault:` para modo texto;
   - `id:5:initdefault:` para modo gráfico.

2. **Verificar scripts `rcS` e `rc`**:

   - `/etc/init.d/rcS`
   - `/etc/init.d/rc`

3. **Verificar serviços no runlevel 5**:

   - linhas `db:5:once:...`, `dm:5:once:...` etc.

Se algo estiver inconsistente, corrija e rode:

```sh
sudo /bk-reparo --verbose
```

## 3. Problemas com Xorg / LightDM / xinit

### 3.1. Onde olhar logs

- `/var/log/Xorg.0.log`
- `/var/log/lightdm/lightdm.log` (ou similar)
- `~/.xsession-errors` (em algumas configurações)

### 3.2. Testar Xorg manualmente

Para simplificar, tente:

```sh
startx
```

Isso usa `~/.xinitrc`. Se você usar o `xinit` diretamente:

```sh
xinit /usr/bin/xterm -- :0
```

Se funcionar, o problema pode ser:

- no LightDM;
- ou em scripts de sessão (p.ex. `.xsession`).

### 3.3. Testar LightDM separado

```sh
sudo /etc/init.d/lightdm stop
sudo /etc/init.d/lightdm start
```

Verifique logs em `/var/log/`.  
Se `bk-reparo` é chamado antes do LightDM, use:

```sh
sudo /bk-reparo --verbose
```

para garantir caches e alternativas coerentes.

## 4. Problemas de temas, ícones, cursores

Sintomas:

- ícones “faltando”;
- temas GTK parecendo quebrados;
- cursor esquisito.

Diagnóstico:

1. Rode `bk-reparo`:

   ```sh
   sudo /bk-reparo --verbose
   ```

2. Verifique se os temas estão instalados em:

   - `/usr/share/icons/...`
   - `/usr/share/themes/...`

3. Confira `~/.gtkrc-2.0` e `~/.config/gtk-3.0/settings.ini`.

4. Use `bk-update-alternatives`:

   ```sh
   tools/bk-update-alternatives list
   ```

   e ajuste, se necessário:

   ```sh
   sudo tools/bk-update-alternatives apply-default
   ```

## 5. Depuração de builds de programas

### 5.1. Logs e modo verboso

Rode:

```sh
bash -x packages/foo-1.0/build-foo-1.0.sh
```

para ver cada comando.  
Verifique:

- se o tarball foi baixado;
- se o `./configure` passou;
- se o `make` deu erro.

### 5.2. Dependências faltando

- O erro geralmente indica:

  - biblioteca ausente (`fatal error: foo.h: No such file or directory`);
  - `pkg-config` não encontra um `.pc`.

- Use:

  ```sh
  pkg-config --libs --cflags nome-da-lib
  ```

  para testar se a lib está instalada corretamente.

- Veja também:

  ```sh
  ldd /usr/bin/programa
  ```

  para saber quais bibliotecas são necessárias em tempo de execução.

### 5.3. Ajustando scripts de build

Quando descobrir uma dependência faltante:

1. Adicione ao cabeçalho do script:

   ```sh
   # Dependências (resumo):
   #   libfoo
   #   bar-devel
   #   pkg-config
   ```

2. Garanta que o pacote da dependência existe em `packages/` e foi construído antes.

## 6. Ferramentas úteis de diagnóstico

- `dmesg` – mensagens do kernel (utilidade para boot e drivers).
- `journalctl` – se você tiver systemd-journald (no caso do 3bLinux com sysvinit, pode haver logging separado).
- `strace` – rastrear syscalls de programas com comportamento estranho.
- `lsof` – ver arquivos abertos.
- `pstree` – ver hierarquia de processos, útil para init/serviços.

## 7. Check-list rápido por tipo de problema

### 7.1. Sistema não entra no root

- Checar `root=` no GRUB.
- Checar `fstab`.
- Regenerar initramfs.

### 7.2. Sistema entra, mas sem serviços básicos

- Checar `/etc/inittab` e `rcS`/`rc`.
- Logs em `/var/log/`.

### 7.3. Sem X/LightDM

- Testar `startx`.
- Ver logs de Xorg e LightDM.
- Rodar `bk-reparo`.

### 7.4. Builds falham

- Ver log do `configure`/`meson`/`cmake`.
- Checar dependências com `pkg-config` e `ldd`.
- Verificar se scripts de build estão instalando no `PKG_ROOT` correto.

## 8. Resumo

Diagnosticar o 3bLinux envolve:

- entender a cadeia boot → initramfs → init → serviços;
- saber onde estão os logs;
- usar `bk-reparo` e `bk-update-alternatives` para ambiente gráfico;
- ajustar scripts de build conforme necessário.

Com isso, você consegue:

- resolver problemas de boot;
- restaurar ambiente gráfico;
- corrigir builds e dependências;
- manter a distro saudável e sob controle.
