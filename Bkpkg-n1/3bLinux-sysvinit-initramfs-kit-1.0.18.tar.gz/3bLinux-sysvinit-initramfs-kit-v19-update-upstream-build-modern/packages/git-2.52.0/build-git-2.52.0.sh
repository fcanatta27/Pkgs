#!/usr/bin/env bash
set -euo pipefail

NAME="git"
VER="2.52.0"
URL="https://www.kernel.org/pub/software/scm/git/git-2.52.0.tar.gz"
TARBALL_NAME="git-2.52.0.tar.gz"

# Dependências (reais):
#  - curl, openssl, expat, zlib
#  - perl (opcional p/ algumas ferramentas e docs)

BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/usr}"
SYSCONFDIR="${SYSCONFDIR:-/etc}"
LOCALSTATEDIR="${LOCALSTATEDIR:-/var}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[git] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[git] %s\n' "$*"; }

fetch(){
  local out="$1"
  if have curl; then curl -L --fail --retry 3 -o "$out" "$URL"
  else wget -O "$out" "$URL"
  fi
}

main(){
  have tar || die "tar não encontrado"
  (have curl || have wget) || die "curl ou wget necessário"
  have make || die "make não encontrado"
  (have gcc || have cc) || die "gcc/cc não encontrado"

  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"
  fetch "${BUILD_ROOT}/${TARBALL_NAME}"
  tar -xf "${BUILD_ROOT}/${TARBALL_NAME}" -C "$SRC_DIR" --strip-components=1
  cd "$SRC_DIR"

  info "Compilando"
  make -j"$JOBS" prefix="$PREFIX" all

  info "Instalando em DESTDIR: $PKG_ROOT"
  make prefix="$PREFIX" DESTDIR="$PKG_ROOT" install

  # completions / extras úteis
  if [ -f "contrib/completion/git-prompt.sh" ]; then
    mkdir -p "$PKG_ROOT/etc/profile.d"
    install -m 0644 contrib/completion/git-prompt.sh "$PKG_ROOT/etc/profile.d/git-prompt.sh"
  fi

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
