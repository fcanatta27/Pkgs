#!/usr/bin/env bash
#
# build-Jinja2-3.1.6.sh
#
# Build real do Jinja2 3.1.6 para 3bLinux, padrÃ£o bk.
#
set -euo pipefail

VER="3.1.6"
NAME="Jinja2-${VER}"
TARBALL_NAME="${NAME}.tar.gz"
# PyPI source tarball
URL="https://files.pythonhosted.org/packages/source/j/jinja2/${TARBALL_NAME}"

BUILD_ROOT="/tmp/jinja2-${VER}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="Jinja2-${VER}"

die() { echo "Erro: $*" >&2; exit 1; }
info() { echo "[build-Jinja2-${VER}] $*"; }

check_requirements() {
  command -v python3 >/dev/null 2>&1 || die "python3 nÃ£o encontrado."
  command -v pip3    >/dev/null 2>&1 || die "pip3 nÃ£o encontrado."
  command -v tar     >/dev/null 2>&1 || die "tar nÃ£o encontrado."
  command -v gzip    >/dev/null 2>&1 || die "gzip nÃ£o encontrado."
  command -v bk      >/dev/null 2>&1 || die "bk nÃ£o encontrado."
}

prepare_dirs() {
  info "Preparando $BUILD_ROOT"
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT"
}

download_source() {
  info "Baixando $URL"
  if [ -f "$TARBALL" ]; then
    info "Tarball jÃ¡ presente, reutilizando."
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L -o "$TARBALL" "$URL"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$TARBALL" "$URL"
  else
    die "precisa de curl ou wget."
  fi
}

extract_source() {
  info "Extraindo fonte"
  tar -xzf "$TARBALL" -C "$BUILD_ROOT"
  [ -d "$SRC_DIR" ] || die "SRC_DIR nÃ£o encontrado: $SRC_DIR"
}

install_into_pkgroot() {
  info "Instalando via pip (sem deps) em PKG_ROOT=$PKG_ROOT"
  cd "$SRC_DIR"
  PIP_NO_BUILD_ISOLATION=1 \
  python3 -m pip install . \
    --no-deps \
    --no-compile \
    --prefix=/usr \
    --root="$PKG_ROOT"
}

package_with_bk() {
  info "Empacotando com bk: $PKG_NAME"
  bk package "$PKG_NAME" "$PKG_ROOT"
  bk info "$PKG_NAME" || true
  info "Instale com: sudo bk install $PKG_NAME"
}

main() {
  check_requirements
  prepare_dirs
  download_source
  extract_source
  install_into_pkgroot
  package_with_bk
}

main "$@"
