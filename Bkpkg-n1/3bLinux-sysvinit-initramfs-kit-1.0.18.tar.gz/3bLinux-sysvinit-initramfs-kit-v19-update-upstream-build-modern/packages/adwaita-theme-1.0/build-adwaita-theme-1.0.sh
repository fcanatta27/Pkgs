#!/usr/bin/env bash
set -euo pipefail

# adwaita-theme - meta que garante adwaita-icon-theme, Adwaita-fonts e gtk4 instalados via bk.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

"${ROOT_DIR}/tools/bk-build-wrapper" adwaita-icon-theme-49.0 || true
"${ROOT_DIR}/tools/bk-build-wrapper" Adwaita-fonts-0.303 || true
"${ROOT_DIR}/tools/bk-build-wrapper" GTK-4.20.3 || true

echo "[adwaita-theme] Nada para instalar diretamente, este pacote é apenas um meta-helper."
