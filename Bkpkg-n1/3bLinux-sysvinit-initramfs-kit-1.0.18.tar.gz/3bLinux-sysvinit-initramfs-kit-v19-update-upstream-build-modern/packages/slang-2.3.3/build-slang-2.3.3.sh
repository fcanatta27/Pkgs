#!/usr/bin/env bash
set -euo pipefail

NAME="slang"
VER="2.3.3"
TARBALL_NAME="slang-2.3.3.tar.bz2"
URL="https://www.jedsoft.org/releases/slang/slang-2.3.3.tar.bz2"

# Dependências (resumo):
# ncurses; libm

SCRIPT_NAME="${0##*/}"
BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/usr}"
SYSCONFDIR="${SYSCONFDIR:-/etc}"
LOCALSTATEDIR="${LOCALSTATEDIR:-/var}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[bk-build] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[bk-build] %s\n' "$*"; }

fetch(){
  local out="$1"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 --retry-delay 1 -o "$out" "$URL"
  else
    wget -O "$out" "$URL"
  fi
}

prepare(){
  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"
}

extract_src(){
  local tarball="$1"
  info "Extraindo: $tarball"
  tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
}

main(){
  (command -v curl >/dev/null 2>&1 || command -v wget >/dev/null 2>&1) || die "curl ou wget necessário"
  command -v tar >/dev/null 2>&1 || die "tar não encontrado"
  command -v make >/dev/null 2>&1 || die "make não encontrado"
  (command -v gcc >/dev/null 2>&1 || command -v cc >/dev/null 2>&1) || die "gcc/cc não encontrado"

  prepare
  local tarball="${BUILD_ROOT}/${TARBALL_NAME}"
  info "Baixando: $URL"
  fetch "$tarball"
  extract_src "$tarball"
  cd "$SRC_DIR"

  info "Configurando (autotools)"
  ./configure \
    --prefix="$PREFIX" \
    --sysconfdir="$SYSCONFDIR" \
    --localstatedir="$LOCALSTATEDIR" \

  info "Compilando"
  make -j"$JOBS" 
  info "Instalando em DESTDIR: $PKG_ROOT"
  make DESTDIR="$PKG_ROOT" install

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
