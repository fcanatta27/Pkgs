#!/usr/bin/env bash
#
# build-util-linux-2.41.3.sh
#
# Build real do util-linux 2.41.3 para 3bLinux, padrão bk.
#
set -euo pipefail

VER="2.41.3"
NAME="util-linux-{VER}"
TARBALL_NAME="{NAME}.tar.xz"
URL="https://www.kernel.org/pub/linux/utils/util-linux/v2.41/{TARBALL_NAME}"

BUILD_ROOT="/tmp/util-linux-{VER}-build"
TARBALL="{BUILD_ROOT}/{TARBALL_NAME}"
SRC_DIR="{BUILD_ROOT}/{NAME}"
PKG_ROOT="{BUILD_ROOT}/pkg-root"

PKG_NAME="util-linux-{VER}"
JOBS="{JOBS:-$(nproc 2>/dev/null || echo 1)}"

die() { echo "Erro: $*" >&2; exit 1; }
info() { echo "[build-util-linux-{VER}] $*"; }

check_requirements() {
  command -v make >/dev/null 2>&1 || die "make não encontrado."
  command -v tar  >/dev/null 2>&1 || die "tar não encontrado."
  command -v xz   >/dev/null 2>&1 || die "xz não encontrado."
  command -v gcc  >/dev/null 2>&1 || die "gcc não encontrado."
  command -v bk   >/dev/null 2>&1 || die "bk não encontrado."
}

prepare_dirs() {
  info "Preparando $BUILD_ROOT"
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT"
}

download_source() {
  info "Baixando $URL"
  if [ -f "$TARBALL" ]; then
    info "Tarball já presente, reutilizando."
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L -o "$TARBALL" "$URL"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$TARBALL" "$URL"
  else
    die "precisa de curl ou wget."
  fi
}

extract_source() {
  info "Extraindo fonte"
  tar -xJf "$TARBALL" -C "$BUILD_ROOT"
  [ -d "$SRC_DIR" ] || die "SRC_DIR não encontrado: $SRC_DIR"
}

configure_build() {
  info "Configurando util-linux"
  cd "$SRC_DIR"
  ./configure \
    --prefix=/usr \
    --disable-static \
    --without-python \
    --without-systemd || die "configure falhou."
}

build_util() {
  info "Compilando util-linux (JOBS=$JOBS)"
  cd "$SRC_DIR"
  make -j"$JOBS"
}

install_into_pkgroot() {
  info "Instalando em PKG_ROOT=$PKG_ROOT"
  cd "$SRC_DIR"
  make DESTDIR="$PKG_ROOT" install
}

package_with_bk() {
  info "Empacotando com bk: $PKG_NAME"
  bk package "$PKG_NAME" "$PKG_ROOT"
  bk info "$PKG_NAME" || true
  info "Instale com: sudo bk install $PKG_NAME"
}

main() {
  check_requirements
  prepare_dirs
  download_source
  extract_source
  configure_build
  build_util
  install_into_pkgroot
  package_with_bk
}

main "$@"
