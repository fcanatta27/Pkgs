#!/usr/bin/env bash
\
#!/usr/bin/env bash
#
# build-busybox-1.37.1.sh
#
# Script de construção REAL para o busybox 1.37.1, usando /tmp para build
# e o bk para empacotar o resultado em /var/3bLinux como pacote:
#
#   busybox-1.37.1
#
# O pacote resultante conterá, em PKG_ROOT:
#   - /bin/busybox
#   - symlinks para applets em /bin (via make install)
#
# Requisitos no sistema de build:
#   - toolchain C (gcc, ld, etc.)
#   - make
#   - xz (para extrair o tarball .tar.bz2 ou .tar.xz, se aplicável)
#   - curl ou wget
#   - bk instalado e funcional
#   - espaço livre em /tmp
#
# Observação:
#   - Se existir um arquivo /etc/busybox-1.37.1.config, ele será usado como .config.
#   - Caso contrário, será usado "defconfig" do busybox e você pode ajustar depois.
#

set -euo pipefail

BB_VER="1.37.1"
BB_NAME="busybox-${BB_VER}"
BB_TARBALL="${BB_NAME}.tar.bz2"
BB_URL="https://busybox.net/downloads/${BB_TARBALL}"

BUILD_ROOT="/tmp/busybox-${BB_VER}-build"
SRC_DIR="${BUILD_ROOT}/${BB_NAME}"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="busybox-${BB_VER}"

JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"

b_die(){ echo "Erro: $*" >&2; exit 1; }
b_info(){ echo "[build-busybox-${BB_VER}] $*"; }

check_requirements(){
    command -v make >/dev/null 2>&1 || b_die "make não encontrado."
    command -v xz >/dev/null 2>&1 || true   # pode não ser necessário para .tar.bz2
    if command -v curl >/dev/null 2>&1; then
        DL_TOOL="curl"
    elif command -v wget >/dev/null 2>&1; then
        DL_TOOL="wget"
    else
        b_die "nem curl nem wget encontrados para download do busybox."
    fi
    command -v bk >/dev/null 2>&1 || b_die "bk não encontrado no PATH. Instale/copiar o bk para /usr/local/bin."
}

prepare_dirs(){
    b_info "Preparando diretórios em ${BUILD_ROOT}..."
    rm -rf "${BUILD_ROOT}"
    mkdir -p "${BUILD_ROOT}" "${PKG_ROOT}"
}

download_busybox(){
    b_info "Baixando busybox ${BB_VER} de ${BB_URL}..."
    local dest="${BUILD_ROOT}/${BB_TARBALL}"
    if [ -f "${dest}" ]; then
        b_info "Tarball já existe em ${dest}, reutilizando."
    else
        case "${DL_TOOL}" in
            curl) curl -L -o "${dest}" "${BB_URL}" ;;
            wget) wget -O "${dest}" "${BB_URL}" ;;
        esac
    fi
}

extract_busybox(){
    b_info "Extraindo fonte do busybox em ${BUILD_ROOT}..."
    cd "${BUILD_ROOT}"
    tar -xjf "${BB_TARBALL}"
}

configure_busybox(){
    b_info "Configurando busybox..."
    cd "${SRC_DIR}"

    if [ -f "/etc/busybox-${BB_VER}.config" ]; then
        b_info "Usando /etc/busybox-${BB_VER}.config como .config..."
        cp "/etc/busybox-${BB_VER}.config" .config
        yes "" | make oldconfig
    else
        b_info "Usando defconfig padrão do busybox..."
        make defconfig
    fi

    b_info "Configuração concluída (.config gerado)."
}

build_busybox(){
    b_info "Compilando busybox (JOBS=${JOBS})..."
    cd "${SRC_DIR}"
    make -j"${JOBS}"
}

install_into_pkgroot(){
    b_info "Instalando busybox em PKG_ROOT=${PKG_ROOT}..."
    cd "${SRC_DIR}"
    make CONFIG_PREFIX="${PKG_ROOT}" install

    b_info "Conteúdo de ${PKG_ROOT}:"
    find "${PKG_ROOT}" -maxdepth 3 -type f -o -type l | sed 's/^/  /' || true
}

package_with_bk(){
    b_info "Empacotando com bk: ${PKG_NAME} a partir de ${PKG_ROOT}..."
    bk package "${PKG_NAME}" "${PKG_ROOT}"
    b_info "Pacote busybox criado em /var/3bLinux."
    bk info "${PKG_NAME}" || true
}

main(){
    check_requirements
    prepare_dirs
    download_busybox
    extract_busybox
    configure_busybox
    build_busybox
    install_into_pkgroot
    package_with_bk

    b_info "Build do busybox ${BB_VER} concluído."
    b_info "Você pode instalar o pacote em um sistema alvo com, por exemplo:"
    echo
    echo "  sudo bk install ${PKG_NAME}"
    echo
}

main "$@"