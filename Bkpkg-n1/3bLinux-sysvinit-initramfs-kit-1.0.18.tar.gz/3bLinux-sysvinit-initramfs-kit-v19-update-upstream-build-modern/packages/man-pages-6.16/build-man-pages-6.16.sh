#!/usr/bin/env bash
#
# build-man-pages-6.16.sh
#
# Build/instalação do man-pages 6.16 para 3bLinux, padrão bk.
#
set -euo pipefail

VER="6.16"
NAME="man-pages-{VER}"
TARBALL_NAME="{NAME}.tar.xz"
URL="https://www.kernel.org/pub/linux/docs/man-pages/{TARBALL_NAME}"

BUILD_ROOT="/tmp/man-pages-{VER}-build"
TARBALL="{BUILD_ROOT}/{TARBALL_NAME}"
SRC_DIR="{BUILD_ROOT}/{NAME}"
PKG_ROOT="{BUILD_ROOT}/pkg-root"

PKG_NAME="man-pages-{VER}"

die() { echo "Erro: $*" >&2; exit 1; }
info() { echo "[build-man-pages-{VER}] $*"; }

check_requirements() {
  command -v tar  >/dev/null 2>&1 || die "tar não encontrado."
  command -v xz   >/dev/null 2>&1 || die "xz não encontrado."
  command -v make >/dev/null 2>&1 || die "make não encontrado."
  command -v bk   >/dev/null 2>&1 || die "bk não encontrado."
}

prepare_dirs() {
  info "Preparando $BUILD_ROOT"
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT"
}

download_source() {
  info "Baixando $URL"
  if [ -f "$TARBALL" ]; then
    info "Tarball já presente, reutilizando."
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L -o "$TARBALL" "$URL"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$TARBALL" "$URL"
  else
    die "precisa de curl ou wget."
  fi
}

extract_source() {
  info "Extraindo fonte"
  tar -xJf "$TARBALL" -C "$BUILD_ROOT"
  [ -d "$SRC_DIR" ] || die "SRC_DIR não encontrado: $SRC_DIR"
}

install_into_pkgroot() {
  info "Instalando man-pages em PKG_ROOT=$PKG_ROOT"
  cd "$SRC_DIR"
  make prefix=/usr DESTDIR="$PKG_ROOT" install
}

package_with_bk() {
  info "Empacotando com bk: $PKG_NAME"
  bk package "$PKG_NAME" "$PKG_ROOT"
  bk info "$PKG_NAME" || true
  info "Instale com: sudo bk install $PKG_NAME"
}

main() {
  check_requirements
  prepare_dirs
  download_source
  extract_source
  install_into_pkgroot
  package_with_bk
}

main "$@"
