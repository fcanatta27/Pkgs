#!/usr/bin/env bash
set -euo pipefail

NAME="font-fixed"
VER="1.0"
TARBALL_NAME="font-fixed-1.0.tar.gz"

# Este script assume que o tarball já está disponível localmente (ex.: em distfiles/).
# Ajuste o caminho de origem conforme seu fluxo de trabalho.

BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/usr}"
FONTSDIR="${FONTSDIR:-/usr/share/fonts}"

die(){ printf '[%s] ERRO: %s\n' "$NAME" "$*" >&2; exit 1; }
info(){ printf '[%s] %s\n' "$NAME" "$*"; }

main(){
  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"

  local src_tar="./${TARBALL_NAME}"
  [ -f "$src_tar" ] || die "tarball $src_tar não encontrado (coloque-o ao lado deste script ou ajuste o caminho)."

  info "Usando tarball local: $src_tar"
  tar -xf "$src_tar" -C "$SRC_DIR" --strip-components=1

  cd "$SRC_DIR"

  # Convenção: arquivos de fonte (pcf/ttf/otf/bdf) são copiados para FONTSDIR/NAME
  info "Instalando fontes em staging"
  mkdir -p "${PKG_ROOT}${FONTSDIR}/${NAME}"
  find . -type f \( -name '*.pcf' -o -name '*.pcf.gz' -o -name '*.ttf' -o -name '*.otf' -o -name '*.bdf' \) -print0 | \
    xargs -0 -I '{}' cp '{}' "${PKG_ROOT}${FONTSDIR}/${NAME}/"

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
