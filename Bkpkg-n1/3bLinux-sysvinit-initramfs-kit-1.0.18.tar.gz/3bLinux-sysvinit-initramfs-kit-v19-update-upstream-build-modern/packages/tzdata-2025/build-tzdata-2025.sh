#!/usr/bin/env bash
#
# build-tzdata-2025.sh
#
# Build real do tzdata 2025 (release "2025a") para 3bLinux (formato bk).
# Baseado nas instruções do LFS para instalação de time zone data.
#
set -euo pipefail

VER="2025"
TZ_RELEASE="2025a"          # revisão upstream (tzdata2025a)
NAME="tzdata-${TZ_RELEASE}"
TARBALL_NAME="tzdata${TZ_RELEASE}.tar.gz"
URL="https://www.iana.org/time-zones/repository/releases/${TARBALL_NAME}"

BUILD_ROOT="/tmp/tzdata-${VER}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="tzdata-${VER}"

JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"

die() { echo "[build-tzdata-${VER}] Erro: $*" >&2; exit 1; }
info() { echo "[build-tzdata-${VER}] $*"; }

check_requirements() {
  command -v tar >/dev/null 2>&1 || die "tar não encontrado."
  command -v zic >/dev/null 2>&1 || die "zic (glibc) não encontrado."
  command -v bk  >/dev/null 2>&1 || die "bk não encontrado."
}

prepare_dirs() {
  info "Preparando diretórios em ${BUILD_ROOT}"
  rm -rf "${BUILD_ROOT}"
  mkdir -p "${BUILD_ROOT}" "${PKG_ROOT}"
}

download_source() {
  info "Baixando ${URL}"
  if [ -f "${TARBALL}" ]; then
    info "Tarball já presente, reutilizando."
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L -o "${TARBALL}" "${URL}"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "${TARBALL}" "${URL}"
  else
    die "precisa de curl ou wget."
  fi
}

extract_source() {
  info "Extraindo fonte ${TARBALL_NAME}"
  mkdir -p "${SRC_DIR}"
  tar -xzf "${TARBALL}" -C "${SRC_DIR}" --strip-components=0 || die "falha ao extrair tzdata."
}

build_zoneinfo() {
  info "Gerando base de timezones (sem instalar direto no sistema)"
  cd "${SRC_DIR}"

  # Alguns releases usam leap-seconds.list; garanta um alias "leapseconds" se necessário.
  if [ ! -f leapseconds ] && [ -f leap-seconds.list ]; then
    ln -sf leap-seconds.list leapseconds
  fi

  ZONEINFO="${PKG_ROOT}/usr/share/zoneinfo"
  mkdir -pv "${ZONEINFO}/"{posix,right}

  for tz in etcetera southamerica northamerica europe africa antarctica \
            asia australasia backward; do
    zic -L /dev/null   -d "${ZONEINFO}"       "${tz}"
    zic -L /dev/null   -d "${ZONEINFO}/posix" "${tz}"
    zic -L leapseconds -d "${ZONEINFO}/right" "${tz}" || true
  done

  cp -v zone.tab zone1970.tab iso3166.tab "${ZONEINFO}"

  # Default POSIX rules (o administrador ainda deve escolher /etc/localtime depois).
  zic -d "${ZONEINFO}" -p America/New_York || true
}

post_install_notes() {
  # Não criamos /etc/localtime aqui, isso é responsabilidade de cada sistema.
  mkdir -p "${PKG_ROOT}/usr/share/doc/${PKG_NAME}"
  cat > "${PKG_ROOT}/usr/share/doc/${PKG_NAME}/README.tzdata-2025" << 'DOC'
Este pacote instala os arquivos de zona horária em /usr/share/zoneinfo
(árvores normal, posix e right).

Após instalar o pacote com "bk install tzdata-2025", selecione sua timezone
criando o link apropriado, por exemplo:

  ln -sf /usr/share/zoneinfo/America/Sao_Paulo /etc/localtime

Consulte também o utilitário "tzselect" para descobrir o nome da zona.
DOC
}

package_with_bk() {
  info "Empacotando com bk: ${PKG_NAME}"
  bk package "${PKG_NAME}" "${PKG_ROOT}"
  bk info "${PKG_NAME}" || true
  info "Instale com: sudo bk install ${PKG_NAME}"
}

main() {
  check_requirements
  prepare_dirs
  download_source
  extract_source
  build_zoneinfo
  post_install_notes
  package_with_bk
}

main "$@"
