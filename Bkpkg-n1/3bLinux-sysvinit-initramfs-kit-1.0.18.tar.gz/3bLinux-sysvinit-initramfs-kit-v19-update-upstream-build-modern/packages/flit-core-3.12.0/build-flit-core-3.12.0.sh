#!/usr/bin/env bash
#
# build-flit-core-3.12.0.sh
#
# Instala flit-core via fonte do PyPI, empacotando com bk.
#
set -euo pipefail

VER="3.12.0"
PROJ="flit-core"
TARBALL_NAME="flit_core-3.12.0.tar.gz"
URL="https://files.pythonhosted.org/packages/source/f/flit-core/flit_core-3.12.0.tar.gz"

BUILD_ROOT="/tmp/flit-core-3.12.0-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="flit-core-3.12.0"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"

die(){ echo "Erro: $*" >&2; exit 1; }
info(){ echo "[build-flit-core] $*"; }

check_requirements(){
  for p in python3 tar gzip bk; do
    command -v "$p" >/dev/null 2>&1 || die "$p não encontrado."
  done
  command -v pip3 >/dev/null 2>&1 || die "pip3 não encontrado (necessário para instalar flit-core)."
}

prepare_dirs(){
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$SRC_DIR" "$PKG_ROOT"
}

download_source(){
  info "Baixando $URL"
  if [ -f "$TARBALL" ]; then return; fi
  if command -v curl >/dev/null 2>&1; then curl -L -o "$TARBALL" "$URL"
  elif command -v wget >/dev/null 2>&1; then wget -O "$TARBALL" "$URL"
  else die "precisa de curl ou wget."; fi
}

extract_source(){
  info "Extraindo"
  tar -xzf "$TARBALL" -C "$SRC_DIR" --strip-components=1
}

install_into_pkgroot(){
  info "Instalando com pip (isolado em PKG_ROOT)"
  # --no-deps porque dependências serão tratadas pela ordem do README
  # --prefix=/usr para layout do sistema
  PIP_NO_BUILD_ISOLATION=1 \
  python3 -m pip install . \
    --no-deps \
    --no-compile \
    --prefix=/usr \
    --root="$PKG_ROOT"
}

package_with_bk(){
  info "Empacotando com bk: $PKG_NAME"
  bk package "$PKG_NAME" "$PKG_ROOT"
  bk info "$PKG_NAME" || true
}

main(){
  check_requirements
  prepare_dirs
  download_source
  extract_source
  cd "$SRC_DIR"
  install_into_pkgroot
  package_with_bk
}
main "$@"
