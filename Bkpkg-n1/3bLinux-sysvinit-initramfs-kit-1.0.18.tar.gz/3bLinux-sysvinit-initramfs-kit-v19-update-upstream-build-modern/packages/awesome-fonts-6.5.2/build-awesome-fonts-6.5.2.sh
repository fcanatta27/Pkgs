#!/usr/bin/env bash
set -euo pipefail

NAME="font-awesome"
VER="6.5.2"
URL="https://github.com/FortAwesome/Font-Awesome/releases/download/${VER}/fontawesome-free-${VER}-desktop.zip"
TARBALL_NAME="fontawesome-free-${VER}-desktop.zip"

BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

FONTDIR="${FONTDIR:-/usr/share/fonts/fontawesome}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[font-awesome] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[font-awesome] %s\n' "$*"; }

fetch(){
  local out="$1"
  if have curl; then curl -L --fail --retry 3 -o "$out" "$URL"
  else wget -O "$out" "$URL"
  fi
}

main(){
  (have curl || have wget) || die "curl ou wget necessário"
  command -v unzip >/dev/null 2>&1 || die "unzip necessário"

  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"

  info "Baixando: $URL"
  fetch "${BUILD_ROOT}/${TARBALL_NAME}"
  unzip -q "${BUILD_ROOT}/${TARBALL_NAME}" -d "$SRC_DIR"

  info "Instalando em staging"
  mkdir -p "${PKG_ROOT}${FONTDIR}"
  find "$SRC_DIR" -maxdepth 4 -type f -name '*.ttf' -o -name '*.otf' | while read -r f; do
    install -m 0644 "$f" "${PKG_ROOT}${FONTDIR}/"
  done

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
