#!/usr/bin/env bash
set -euo pipefail

# firefox (source build) - script real, porém build completo é pesado.
# Este script prepara o tree e compila com mach.
#
# Requisitos grandes:
#  - python3, rust, cargo, nodejs, nasm, yasm, clang (recomendado), llvm, ccache
#  - libs: gtk3 stack, dbus, pulseaudio/alsa, etc.
#
# Observação: para um kit 1.0.x, a recomendação prática é usar firefox-bin no repositório.

NAME="firefox"
VER="${VER:-128.8.0esr}"
LOCALE="${LOCALE:-pt-BR}"

SRC_URL="https://ftp.mozilla.org/pub/firefox/releases/${VER}/source/firefox-${VER}.source.tar.xz"

BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/usr}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[firefox] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[firefox] %s\n' "$*"; }

fetch(){
  local out="$1"
  if have curl; then curl -L --fail --retry 3 -o "$out" "$SRC_URL"
  else wget -O "$out" "$SRC_URL"
  fi
}

main(){
  (have curl || have wget) || die "curl ou wget necessário"
  have tar || die "tar não encontrado"
  have python3 || die "python3 necessário"
  have rustc || die "rustc necessário"
  have cargo || die "cargo necessário"

  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"
  info "Baixando fonte: $SRC_URL"
  fetch "${BUILD_ROOT}/firefox.src.tar.xz"
  tar -xf "${BUILD_ROOT}/firefox.src.tar.xz" -C "$SRC_DIR" --strip-components=1
  cd "$SRC_DIR"

  info "Preparando mozconfig mínimo"
  cat > .mozconfig <<EOF
mk_add_options MOZ_OBJDIR=@TOPSRCDIR@/obj
ac_add_options --prefix=${PREFIX}
ac_add_options --enable-release
ac_add_options --disable-debug
ac_add_options --enable-system-ffi
ac_add_options --enable-system-pixman
EOF

  info "Compilando (mach) - pode demorar bastante"
  ./mach build -j "$JOBS"

  info "Instalando em staging"
  DESTDIR="$PKG_ROOT" ./mach install

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
