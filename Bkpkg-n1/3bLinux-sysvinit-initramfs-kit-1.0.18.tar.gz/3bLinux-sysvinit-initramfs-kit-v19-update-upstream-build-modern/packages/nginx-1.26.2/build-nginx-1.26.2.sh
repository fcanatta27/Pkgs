#!/usr/bin/env bash
set -euo pipefail

NAME="nginx"
VER="1.26.2"
TARBALL_NAME="${NAME}-${VER}.tar.gz"
URL="http://nginx.org/download/${TARBALL_NAME}"

# Dependências (resumo):
#   pcre2
#   zlib
#   openssl
#   gcc, make
#   pkg-config (opcional, dependendo da distro)

SCRIPT_NAME="${0##*/}"
BUILD_ROOT="/tmp/${NAME}-${VER}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/usr}"
SYSCONFDIR="${SYSCONFDIR:-/etc}"
LOCALSTATEDIR="${LOCALSTATEDIR:-/var}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[bk-build][%s] ERRO: %s\n' "$NAME" "$*" >&2; exit 1; }
info(){ printf '[bk-build][%s] %s\n' "$NAME" "$*"; }

fetch(){
  local out="$1"
  if have curl; then
    curl -L --fail --retry 3 --retry-delay 1 -o "$out" "$URL"
  elif have wget; then
    wget -O "$out" "$URL"
  else
    die "nem curl nem wget encontrados"
  fi
}

prepare(){
  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"
}

extract_src(){
  local tarball="$1"
  info "Extraindo: $tarball"
  tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
}

main(){
  have tar || die "tar não encontrado"
  have make || die "make não encontrado"
  (have gcc || have cc) || die "gcc/cc não encontrado"

  prepare
  local tarball="${BUILD_ROOT}/${TARBALL_NAME}"

  info "Baixando: $URL"
  fetch "$tarball"
  extract_src "$tarball"
  cd "$SRC_DIR"

  info "Configurando nginx"
  # Diretórios padrão:
  #   binário principal:   /usr/sbin/nginx
  #   configs:             /etc/nginx
  #   logs:                /var/log/nginx
  #   pid:                 /run/nginx.pid
  #   html estático:       /usr/share/nginx/html
  ./configure \
    --prefix="${PREFIX}" \
    --sbin-path="${PREFIX}/sbin/nginx" \
    --conf-path="${SYSCONFDIR}/nginx/nginx.conf" \
    --pid-path=/run/nginx.pid \
    --lock-path=/run/nginx.lock \
    --error-log-path="${LOCALSTATEDIR}/log/nginx/error.log" \
    --http-log-path="${LOCALSTATEDIR}/log/nginx/access.log" \
    --http-client-body-temp-path="${LOCALSTATEDIR}/lib/nginx/body" \
    --http-proxy-temp-path="${LOCALSTATEDIR}/lib/nginx/proxy" \
    --http-fastcgi-temp-path="${LOCALSTATEDIR}/lib/nginx/fastcgi" \
    --http-uwsgi-temp-path="${LOCALSTATEDIR}/lib/nginx/uwsgi" \
    --http-scgi-temp-path="${LOCALSTATEDIR}/lib/nginx/scgi" \
    --with-http_ssl_module \
    --with-http_gzip_static_module \
    --with-pcre \
    --with-file-aio \
    --with-threads

  info "Compilando nginx"
  make -j"${JOBS}"

  info "Instalando em PKG_ROOT (${PKG_ROOT})"
  make DESTDIR="${PKG_ROOT}" install

  # Diretórios adicionais para logs/temp (caso não sejam criados pelo make install)
  mkdir -p "${PKG_ROOT}${LOCALSTATEDIR}/log/nginx"
  mkdir -p "${PKG_ROOT}${LOCALSTATEDIR}/lib/nginx"
  mkdir -p "${PKG_ROOT}/run"

  info "Staging nginx pronto em: ${PKG_ROOT}"
  info "Use tools/bk-build-wrapper nginx-1.26.2 para empacotar via bk."
}
main "$@"
