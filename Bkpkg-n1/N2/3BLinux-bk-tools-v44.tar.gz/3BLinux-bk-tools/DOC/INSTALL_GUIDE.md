# 3BLinux – Guia Completo de Construção, ISO, QEMU e Instalação

Este guia descreve um fluxo **completo e reproduzível** para:
1. Construir um userland + toolchain com `bk-cli-stage-system`
2. Gerar initramfs com `bk-initramfs`
3. Gerar ISO bootável com `bk-mkiso`
4. Testar com QEMU (automático com `bk-qemu` ou manual)
5. Rodar o instalador `bk-install` dentro do live e instalar em disco

> Aviso: várias etapas exigem privilégios de root (montagens, chroot, instalação do GRUB).  
> Recomenda-se executar tudo em uma VM primeiro.

---

## 0. Convenções

- **Diretório do projeto**: onde você extraiu o bundle do bk-tools
- **ROOTFS final**: `./3BLinux/` dentro do projeto (é o seu `/` do 3BLinux)
- **Cache de binários**: `/var/3bLinux` (no host ou no sistema live), **não** é local de build
- **Build temporário**: `/tmp` (usado pelos scripts de build)

Variáveis úteis:

```sh
export ROOTFS="$PWD/3BLinux"
export BK_BUILD_ROOT="$ROOTFS"
```

---

## 1) Construindo o sistema com bk-cli-stage-system (base + devel)

### 1.1 Requisitos no host (ambiente de build)

Você precisa de um Linux host com ferramentas básicas (ex.: Debian/Fedora/Arch), com:
- `bash`, `make`, `gcc/g++`, `wget`, `tar`, `xz`, `bzip2`, `gzip`
- `git` (se for compilar pacotes que baixam do git)
- Para ISO: `grub-mkrescue`, `xorriso`
- Para QEMU: `qemu-system-x86_64`, `qemu-img`

### 1.2 Rodando o stage

No diretório do projeto:

```sh
cd 3BLinux-bk-tools
export ROOTFS="$PWD/3BLinux"
export BK_BUILD_ROOT="$ROOTFS"

# opcional: paralelismo de build
export BK_JOBS="$(nproc)"

# constrói base + toolchain-devel
bin/bk-cli-stage-system
```

O que acontece:

- `bk-cli-stage-system` chama `bk build <pacote>` na ordem correta.
- Cada `packages/<pkg>/build.sh`:
  - baixa o tarball para `/tmp`
  - extrai em `/tmp`
  - compila em `/tmp/build-...`
  - instala no rootfs via `DESTDIR="$BK_BUILD_ROOT"`

No final, o rootfs `./3BLinux` terá um userland funcional e um ambiente de desenvolvimento coerente.

### 1.3 Verificações pós-build (recomendado)

Verifique alguns binários básicos no rootfs:

```sh
test -x "$ROOTFS/bin/sh" || echo "Faltou /bin/sh"
test -x "$ROOTFS/usr/bin/bash" || echo "Faltou bash"
test -x "$ROOTFS/usr/bin/ldd" || echo "Faltou glibc tools"
```

---

## 2) Gerando initramfs com bk-initramfs

O `bk-initramfs` cria um initramfs baseado em BusyBox, com init funcional.

### 2.1 Pré-requisito

- BusyBox precisa existir no rootfs (o stage já constrói).
- Tenha um diretório de boot no rootfs:

```sh
mkdir -p "$ROOTFS/boot"
```

### 2.2 Gerar o initramfs

Exemplo:

```sh
bin/bk-initramfs   --rootfs "$ROOTFS"   --output "$ROOTFS/boot/initramfs.img"
```

Recomendações:

- Gere sempre em `$ROOTFS/boot/initramfs.img` para facilitar `bk-mkiso` e GRUB.
- Se você gerar um modo “live completo”, considere também um squashfs do rootfs (se usar):

```sh
# opcional, para live completo em squashfs
mksquashfs "$ROOTFS" 3blinux.squashfs -comp xz -b 1M
```

---

## 3) Gerando ISO com bk-mkiso

O `bk-mkiso` cria uma ISO com GRUB, kernel e initramfs.

### 3.1 Pré-requisitos

No host, instale:
- `grub-mkrescue`
- `xorriso`

Você também precisa de um kernel pronto (por exemplo `vmlinuz-6.18.2`) em:

```text
$ROOTFS/boot/vmlinuz-6.18.2
$ROOTFS/boot/initramfs.img
```

### 3.2 Gerar ISO (modo initramfs live)

```sh
bin/bk-mkiso   -R "$ROOTFS"   -o 3blinux.iso   -L 3BLINUX   -a "console=ttyS0"
```

### 3.3 Gerar ISO (modo live squashfs)

Se você gerou `3blinux.squashfs`:

```sh
bin/bk-mkiso   -R "$ROOTFS"   -s 3blinux.squashfs   -o 3blinux-live.iso   -L 3BLINUXLIVE
```

O ISO resultante terá duas entradas no GRUB:
- live via initramfs
- live via squashfs (se fornecido)

---

## 4) Boot no QEMU (manual e via bk-qemu)

### 4.1 Boot manual com ISO

```sh
qemu-system-x86_64   -m 2048   -cdrom 3blinux.iso   -boot d   -nographic
```

Se quiser console serial:

```sh
qemu-system-x86_64 -m 2048 -cdrom 3blinux.iso -boot d -serial mon:stdio
```

### 4.2 Boot manual com kernel + initramfs

```sh
qemu-system-x86_64   -m 2048   -kernel "$ROOTFS/boot/vmlinuz-6.18.2"   -initrd "$ROOTFS/boot/initramfs.img"   -append "console=ttyS0"   -nographic
```

### 4.3 Usando bk-qemu (recomendado)

O `bk-qemu` cria e gerencia imagens em um diretório próprio e facilita rodar.

Exemplos:

```sh
# inicializa diretório de imagens
bin/bk-qemu init

# cria uma imagem de disco de 20G
bin/bk-qemu create mydisk 20G

# roda com ISO e disco
bin/bk-qemu run mydisk --cdrom 3blinux.iso --mem 2048 --serial stdio
```

---

## 5) Instalando no disco usando bk-install (dentro do live)

O `bk-install` é o instalador. Ele **pode destruir dados** se você mandar autoparticionar.

### 5.1 Cenário recomendado: VM com disco virtual

Crie um disco e rode o live:

```sh
bin/bk-qemu create target 20G
bin/bk-qemu run target --cdrom 3blinux.iso --mem 2048 --serial stdio
```

### 5.2 Dentro do sistema live: identificar discos

No console do live, use:

```sh
lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINT
```

Suponha que o disco seja `/dev/vda` (QEMU/virtio).

### 5.3 Instalação automática (autoparticionamento GPT)

**Isso apaga o disco inteiro.**

```sh
bk-install   -R /   -d /dev/vda   -L pt_BR.UTF-8   -k br-abnt2   -H 3blinux   -U user   -G wheel,audio,video
```

O script vai pedir uma confirmação textual forte antes de particionar.

Ele criará:
- `/dev/vda1` EFI (FAT32)
- `/dev/vda2` root (ext4)

Vai copiar o rootfs, configurar `/etc`, instalar GRUB e criar o usuário.

### 5.4 Instalação em partições existentes (modo manual)

Se você já particionou e formatou:

```sh
bk-install   -R /   -r /dev/vda2   -e /dev/vda1   -U user
```

### 5.5 Finalização

Após finalizar, desmonte:

```sh
umount -R /mnt/3bl-target
reboot
```

Remova o ISO no QEMU e boot pelo disco.

---

## 6) Pós-instalação (primeiro boot)

Após boot do sistema instalado:

- Defina senha do usuário (se desejar):
  - `passwd user`
- Configure rede se necessário
- Rode checagens e reparos:
  - `bk-reparo`
  - `bk-cache-alternative` (para caches de font/icon/menu, se existir no sistema)

---

## 7) Diagnóstico

Se o boot falhar:

- No GRUB, edite a linha do kernel e adicione:
  - `init=/bin/sh`
- Verifique mounts e logs:
  - `mount`
  - `dmesg`
  - `/var/log/messages`


---

## 6. Ajustes específicos para notebooks (stage-laptop)

Depois de ter um sistema base + desktop dentro do rootfs `3BLinux`, é altamente
recomendado aplicar o workflow de notebook para melhorar:

- gerenciamento de energia;
- ACPI (tampa, botão power);
- suporte a suspensão;
- teclas de brilho/volume;
- Bluetooth e estatísticas de sistema.

### 6.1 Aplicando o stage-laptop

No host de build, dentro da árvore do projeto:

```sh
export BK_ROOT="$PWD/3BLinux"

bin/bk-cli-stage-laptop
```

O que esse comando faz:

- instala (via `bk`) pacotes como `acpid`, `pm-utils`, `sysstat`, `udisks2`, `bluez`;
- garante os arquivos ACPI em `3BLinux/etc/acpi/` (lid, power, volume, brightness);
- aplica o preset de serviços apropriado em `/etc/sysconfig/rc`;
- chama `bk-power-profile laptop` no host, para ajustar governor de CPU e energia.

### 6.2 Testando suspensão e ACPI dentro do sistema instalado

Após instalar o sistema em disco (via `bk-install`) e dar boot no notebook real:

1. Verifique se o `acpid` está ativo:

   ```sh
   ps aux | grep acpid
   ```

2. Feche a tampa:
   - o sistema deve entrar em **suspend** (se `pm-utils` e ACPI suportarem).

3. Abra a tampa:
   - o sistema deve retomar;
   - rede pode ser reiniciada automaticamente (hook em `pm-utils`).

4. Teste teclas de volume/brilho:
   - volume: veja logs via `dmesg` ou `journal` e sinta o efeito de `amixer`.
   - brilho: o script mexe em `/sys/class/backlight/*/brightness`.

---

## 7. Pós-instalação e manutenção com bk-tools

Depois do primeiro login (console ou XFCE), você pode usar:

- **bk-reparo**:
  - reparos gerais do sistema (permissões, diretórios, init scripts);
- **bk-init-reparo**:
  - focado em init, initramfs e sequência de boot;
- **bk-resolve**:
  - sanity-check de binários, libs, links simbólicos;
  - rebuild de caches (fonts, ícones, MIME, schemas, desktop);
  - restart de serviços conforme `/etc/sysconfig/rc`;
- **bk-hardware-detect**:
  - diagnóstico de Wi-Fi, GPU, firmware ausente e ACPI;
- **bk-power-profile**:
  - alternar rapidamente entre perfis `laptop`, `desktop` e `performance`.

Exemplos:

```sh
# Reparar um sistema já instalado (a partir do próprio 3BLinux)
bk-reparo

# Revisar um rootfs offline montado em /mnt/3bl
bk-reparo --root /mnt/3bl

# Cura de desktop (stack gráfico) de uma vez
bk-resolve --root /mnt/3bl --heal-desktop

# Ajustar perfil de energia em tempo real
bk-power-profile laptop
```

Para uma visão ainda mais ampla de administração e manutenção, leia
`DOC/ADMIN_AND_MAINTENANCE.md` e `DOC/SOS_CHECKLIST.md`.
