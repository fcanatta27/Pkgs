# Manifesto 3BLinux 1.0

## 1. O que é o 3BLinux

O **3BLinux** é um sistema operacional GNU/Linux construído com foco em:

- controle total do sistema
- previsibilidade e simplicidade
- clareza entre build, sistema e repositório
- recuperação e manutenção fáceis
- desktop clássico, estável e funcional

O projeto **não** tem como objetivo ser uma distro genérica para iniciantes,
mas sim um sistema **sólido, auditável e educacional**, utilizável no dia a dia.

---

## 2. Princípios fundamentais

1. **RootFS é o sistema final**
   - nada é instalado no host
   - nada é construído dentro de /var/3bLinux
2. **/var/3bLinux é somente cache/repositório de binários**
3. **Tudo é reproduzível**
4. **Scripts > magia**
5. **Falhou? Deve ser reparável com um comando**
6. **Desktop clássico antes de efeitos**

---

## 3. Estrutura oficial

```
/
├── bin/            (bk-tools)
├── sbin/
├── usr/
├── etc/
│   ├── sysconfig/
│   ├── init.d/
│   └── bk/
├── var/
│   └── 3bLinux/    (cache binários)
└── home/
```

---

## 4. Canais oficiais

### stable (oficial)

- somente binários:
  - compilados com scripts versionados
  - testados em VM e hardware real
  - passam por `bk-reparo` + `bk-resolve`
- mudanças **conservadoras**
- upgrades previsíveis

### unstable (rolling)

- snapshots frequentes
- novas versões de pacotes
- mudanças de toolchain permitidas
- pode quebrar temporariamente

---

## 5. Critérios de estabilidade (stable)

Um pacote só entra no **stable** se:

- build reproduzível
- dependências explícitas
- passa:
  - boot
  - login texto
  - login gráfico (se aplicável)
- não quebra:
  - base
  - stage-desktop-full
- versão congelada (patches ok, major version não)

---

## 6. O que entra na base oficial 1.0

### Base obrigatória
- kernel
- glibc
- coreutils
- bash
- util-linux
- procps
- sysklogd
- shadow
- init + busybox

### Toolchain
- binutils
- gcc
- llvm/clang
- rust

### Rede
- iproute2
- NetworkManager
- dhcpcd (opcional)

### Desktop oficial
- Xorg
- Mesa
- XFCE
- LightDM + GTK Greeter
- GTK2/3/4
- Fonts base

### Notebook
- linux-firmware-selected
- acpid
- pm-utils
- bluetooth
- pipewire

---

## 7. O que NÃO entra na base oficial

- ambientes pesados (GNOME, KDE)
- sistemas imutáveis
- auto-update agressivo
- snaps/flatpaks
- systemd

Esses podem existir como **stages opcionais**.

---

## 8. Versionamento

- Sistema: **3BLinux 1.0**
- Patches: 1.0.x
- Rolling: unstable (sem número fixo)

---

## 9. Promessa do projeto

> Se o sistema quebrar, ele **pode ser consertado**
> sem reinstalar tudo.

Esse é o compromisso do 3BLinux.
