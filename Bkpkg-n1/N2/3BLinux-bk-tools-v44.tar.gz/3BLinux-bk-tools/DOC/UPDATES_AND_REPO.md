# 3BLinux – Atualização, Upgrade e Repositórios de Binários (bk-update / bk-upstream)

Este guia cobre:

- Como o `bk` enxerga pacotes binários (tar.gz)
- Como o `bk-upstream` ajuda a identificar novas versões
- Como o `bk-update` aplica upgrades a partir de um repositório
- Como desenhar um repositório **stable** e **unstable**
- Como hospedar (HTTP/HTTPS/rsync)
- Como sincronizar e atualizar **vários sistemas** usando o mesmo repo

---

## 1. Modelo de pacotes do bk

O `bk` empacota programas em tarballs (por exemplo, `openssh-10.2p1.tar.gz`) com metadados internos e um “arquivo de lista” (filelist) para permitir:

- `bk install pacote.tar.gz --root <rootfs>`
- `bk uninstall name-version --root <rootfs>`
- `bk list --root <rootfs>`

O cache de binários padrão é **/var/3bLinux** (apenas repositório, não local de construção).

Você pode:

- Construir usando `bk build <pacote>` (via scripts em `packages/*/build.sh`)
- Gerar o binário/artefato com o próprio `bk` (já integrado nos scripts do projeto)
- Subir esses tar.gz para um servidor **stable** ou **unstable**

---

## 2. Checando upstream com bk-upstream

O `bk-upstream` lê um arquivo de definições e detecta versões mais novas no upstream (HTML ou listagem de arquivos).

Formato:

```text
name|current|url|regex(opcional)
```

- `name`: nome do pacote (coerente com o bk)
- `current`: sua versão atual
- `url`: listagem upstream
- `regex`: regex com **grupo 1** capturando a versão

Exemplo de arquivo `DOC/upstream.list`:

```text
openssh|10.2p1|https://cdn.openbsd.org/pub/OpenBSD/OpenSSH/portable/|openssh-([0-9.]+p[0-9]+)\.tar\.gz
iptables|1.8.11|https://www.netfilter.org/projects/iptables/files/|iptables-([0-9.]+)\.tar\.xz
gnupg|2.5.16|https://gnupg.org/ftp/gcrypt/gnupg/|gnupg-([0-9.]+)\.tar\.bz2
```

Uso:

```sh
cd 3BLinux-bk-tools
bin/bk-upstream -f DOC/upstream.list
bin/bk-upstream -f DOC/upstream.list --only-major
bin/bk-upstream -f DOC/upstream.list --json > upstream-report.json
```

Interpretação:

- Para cada linha, o script pega a “ultima” versão (sort -V) e indica:
  - `SAME`: você já está na mais nova
  - `MINOR/PATCH`: update menor
  - `MAJOR`: mudança de major (pede mais cuidado)

---

## 3. Atualizando via bk-update (HTTP/HTTPS ou rsync)

O `bk-update` foi desenhado para trabalhar com um repositório de binários simples, baseado em um manifesto `bk-repo.txt`.

### 3.1 Formato do manifesto

Arquivo: `bk-repo.txt`

```text
name|version|filename
openssh|10.2p1|openssh-10.2p1.tar.gz
iptables|1.8.11|iptables-1.8.11.tar.gz
gnupg|2.5.16|gnupg-2.5.16.tar.gz
```

- `name`: mesmo nome que o `bk list` mostra (ex.: `openssh`)
- `version`: versão exata (ex.: `10.2p1`)
- `filename`: nome do tar.gz no repositório

### 3.2 Organização de diretórios do repositório

Sugestão:

```text
repo-root/
  stable/
    bk-repo.txt
    openssh-10.2p1.tar.gz
    iptables-1.8.11.tar.gz
    ...
  unstable/
    bk-repo.txt
    openssh-10.3p1.tar.gz
    ...
```

Você pode ter dois repositórios diferentes:

- `https://example.com/3blinux/stable`
- `https://example.com/3blinux/unstable`

Cada um com seu próprio `bk-repo.txt` coerente com os binários ali presentes.

### 3.3 Uso do bk-update (HTTP/HTTPS)

Exemplo (stable):

```sh
cd 3BLinux-bk-tools
bin/bk-update --repo https://example.com/3blinux/stable --root ./3BLinux
```

Exemplo (unstable):

```sh
bin/bk-update --repo https://example.com/3blinux/unstable --root ./3BLinux
```

Fluxo interno:

1. Baixa `bk-repo.txt`
2. Interpreta e guarda, para cada `name`, a **maior versão** disponível
3. Lê pacotes instalados com `bk list --root ROOTFS`
4. Para cada `name-versao_instalada`, se existir versão maior no repo:
   - baixa o `filename` correspondente
   - executa `bk uninstall name-versao_instalada`
   - executa `bk install filename --root ROOTFS`

Você também pode rodar em **dry-run**:

```sh
bin/bk-update --repo https://example.com/3blinux/stable --root ./3BLinux --dry-run
```

### 3.4 Uso com rsync

Se o seu repo está em um servidor com acesso rsync:

Estrutura no servidor:

```text
/var/www/3blinux-repo/
  stable/
    bk-repo.txt
    *.tar.gz
  unstable/
    bk-repo.txt
    *.tar.gz
```

Uso:

```sh
bin/bk-update --rsync user@host:/var/www/3blinux-repo/stable --root ./3BLinux
```

---

## 4. Como montar um servidor de repositório (stable/unstable)

### 4.1 No lado do servidor

1. Crie a estrutura:

```sh
sudo mkdir -p /var/www/3blinux-repo/{stable,unstable}
sudo chown -R www-data:www-data /var/www/3blinux-repo
```

2. Copie seus pacotes binários construídos com `bk`:

```sh
cp /var/3bLinux/*.tar.gz /var/www/3blinux-repo/stable/
```

3. Crie o `bk-repo.txt` em cada subdiretório:

Exemplo simples (`stable`):

```sh
cd /var/www/3blinux-repo/stable
ls *.tar.gz | while read -r f; do
  name="$(echo "$f" | sed -E 's/^(.*)-([0-9][^.]*)\.tar\.gz$//')"
  ver="$(echo "$f" | sed -E 's/^(.*)-([0-9][^.]*)\.tar\.gz$//')"
  echo "${name}|${ver}|${f}"
done > bk-repo.txt
```

Você pode refiná-lo manualmente se quiser agrupar diferentes variantes, etc.

4. Configure o servidor HTTP (por exemplo, nginx/apache) para servir `/var/www/3blinux-repo`.

### 4.2 Política stable vs unstable

Uma política simples:

- `unstable`: entra tudo que acabou de ser construído/testado rapidamente.
- `stable`: somente o que passou por testes adicionais (boot real, `bk-reparo`, testes de ferramenta).

Fluxo sugerido:

1. Construa pacote com `bk` no ambiente de build.
2. Publique inicialmente em `unstable/`.
3. Em uma VM de teste, aponte `bk-update` para `unstable` e teste:
   - boot
   - serviços críticos
   - `bk-reparo`, `bk-cache-alternative`
4. Se aprovado, copie o mesmo tar.gz e entrada de manifesto para `stable/`.

---

## 5. Sincronizando múltiplos sistemas com bk

### 5.1 Vários rootfs no mesmo host

Se você tiver:

```text
/opt/3blinux-srv1/3BLinux
/opt/3blinux-srv2/3BLinux
```

Você pode rodar:

```sh
cd /opt/3blinux-srv1/3BLinux-bk-tools
bin/bk-update --repo https://example.com/3blinux/stable --root ./3BLinux

cd /opt/3blinux-srv2/3BLinux-bk-tools
bin/bk-update --repo https://example.com/3blinux/stable --root ./3BLinux
```

Com isso, ambos ficam sincronizados com o mesmo repositório.

### 5.2 Sistemas remotos

Dentro de cada sistema instalado:

1. Monte o rootfs real (se necessário) ou use `bk` direto no sistema.
2. Execute `bk-update` apontando para o repositório:

```sh
bk-update --repo https://example.com/3blinux/stable --root /
```

Você também pode centralizar downloads (via `--download-dir`) e copiar pacotes binários manualmente entre máquinas, se quiser.

---

## 6. Fluxos recomendados

### 6.1 Ciclo completo de upgrade

1. Checar upstream:

```sh
bin/bk-upstream -f DOC/upstream.list > DOC/upstream-report.txt
```

2. Escolher pacotes a atualizar.
3. Atualizar scripts de build e construir com `bk`.
4. Publicar binários no repositório `unstable`.
5. Testar em QEMU/VM usando `bk-update` (unstable).
6. Se tudo ok, promover para `stable`.
7. Nos sistemas de produção, rodar:

```sh
bk-update --repo https://example.com/3blinux/stable --root /
bk-reparo --root /
bk-init-reparo --root / --rebuild-initramfs
```

---

## 7. Boas práticas

- Sempre versionar o conteúdo do repositório (usar git para `bk-repo.txt`).
- Manter backups dos tarballs estáveis.
- Testar upgrades em QEMU antes de aplicar em máquinas reais.
- Documentar, em `DOC/`, quais versões de base compõem determinado “release 3BLinux”.
