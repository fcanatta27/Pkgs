# Repositório online 3BLinux (bk)

Este documento descreve um layout **pronto para subir em um servidor HTTP/HTTPS**
e usar **bk-update** no 3BLinux.

## 1) Estrutura do servidor

Sugestão de raiz:
- `/var/www/3blinux-repo/`

Estrutura de canais:

```
/var/www/3blinux-repo/
  stable/
    bk-repo.txt
    packages/
      *.tar.gz
  unstable/
    bk-repo.txt
    packages/
      *.tar.gz
```

## 2) Gerar/atualizar o manifesto automaticamente

No servidor:

```sh
bk-repo-scan --repo-root /var/www/3blinux-repo --channel stable
bk-repo-scan --repo-root /var/www/3blinux-repo --channel unstable
```

O manifesto gerado tem formato:

```
name|version|filename|sha256|size
```

## 3) Configurar o cliente 3BLinux

No rootfs (cliente), edite:

`/etc/bk/repo.conf`

Exemplo:

```sh
BK_REPO_BASE_URL="https://seu-dominio/3blinux-repo"
BK_REPO_CHANNEL="stable"
BK_REPO_VERIFY_SHA256="yes"
```

## 4) Atualizar o sistema

Atualiza tudo instalado:

```sh
bk-update
```

Atualiza somente um pacote:

```sh
bk-update openssl
```

Trocar para canal unstable:

```sh
bk-update --channel unstable
```

## 5) Observações de segurança

- `bk-repo-scan` gera `sha256` para cada tarball.
- `bk-update` valida o `sha256` por padrão.
- Para segurança mais forte (assinatura GPG do manifesto), isso pode ser adicionado
  numa próxima etapa.
