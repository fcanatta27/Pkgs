# 3BLinux – Preparação e Construção do Zero (Guia Completo)

Este tutorial é um passo a passo **do zero** para você preparar o ambiente, construir o **rootfs final** (`./3BLinux`), gerar initramfs/ISO e validar o sistema em QEMU.

Ele assume que você está usando o bundle do projeto `3BLinux-bk-tools` e que:
- O **rootfs final** é o diretório `./3BLinux` (dentro do projeto)
- O **cache de binários** é `/var/3bLinux` (somente repositório de binários/pré-builds, não é local de build)
- Os **builds** ocorrem em `/tmp`

---

## 1) Requisitos do host (onde você compila)

Você precisa de um Linux host (Debian/Fedora/Arch etc.) com:
- Toolchain: `gcc`, `g++`, `make`, `binutils`
- Ferramentas base: `bash`, `coreutils`, `tar`, `gzip`, `bzip2`, `xz`, `patch`
- Download: `wget` (ou `curl` se você preferir, mas os scripts usam `wget`)
- Para alguns pacotes modernos: `python3`, `pip`, `meson`, `ninja`, `pkg-config`
- Para ISO: `grub-mkrescue`, `xorriso`
- Para QEMU: `qemu-system-x86_64`, `qemu-img`

> Dica prática: use uma VM Linux “builder” dedicada, para evitar poluir seu host.

---

## 2) Estrutura do projeto

Depois de extrair o bundle você terá, no mínimo:

- `bin/` – ferramentas (bk, bk-cli, bk-initramfs, bk-mkiso, bk-install, etc.)
- `packages/` – receitas de build (`build.sh`) por pacote
- `3BLinux/` – rootfs final (isso é o seu “/” do 3BLinux)
- `DOC/` – documentação

O sistema final vai existir **dentro de `3BLinux/`**.

---

## 3) Preparação do rootfs antes de construir

### 3.1 Permissões e diretórios mínimos

No diretório do projeto:

```sh
cd 3BLinux-bk-tools
export ROOTFS="$PWD/3BLinux"
export BK_BUILD_ROOT="$ROOTFS"

mkdir -p "$ROOTFS"
mkdir -p "$ROOTFS"/{bin,sbin,etc,proc,sys,dev,run,tmp,var,usr}
mkdir -p "$ROOTFS"/usr/{bin,sbin,lib,share}
mkdir -p "$ROOTFS"/var/{log,cache,lib}
chmod 1777 "$ROOTFS/tmp"
```

### 3.2 Arquivos /etc mínimos

O bundle já entrega vários arquivos em `3BLinux/etc` (fstab, hostname, hosts, init scripts, etc.).  
Confirme que existem:

```sh
ls -la "$ROOTFS/etc"
```

Se você alterou algo manualmente, rode também:

```sh
bin/bk-reparo -R "$ROOTFS" || true
```

---

## 4) Construção do userland e toolchain (stage-system)

### 4.1 Variáveis recomendadas

```sh
export ROOTFS="$PWD/3BLinux"
export BK_BUILD_ROOT="$ROOTFS"
export BK_JOBS="$(nproc)"
```

### 4.2 Rodar a construção automática

```sh
bin/bk-cli-stage-system
```

O `bk-cli-stage-system` chama `bk build` em sequência para compor um userland “quase completo”.
Cada pacote segue o padrão:
- baixa tarball em `/tmp`
- extrai fontes em `/tmp/src-*`
- compila em `/tmp/build-*`
- instala no rootfs usando `DESTDIR="$BK_BUILD_ROOT"`

### 4.3 Verificações rápidas pós-build

```sh
test -x "$ROOTFS/bin/sh" || echo "ERRO: /bin/sh ausente"
test -x "$ROOTFS/usr/bin/bash" || echo "ERRO: bash ausente"
test -d "$ROOTFS/usr/lib" || echo "ERRO: /usr/lib ausente"
```

---

## 5) Kernel e módulos

Para boot real você precisa de um kernel instalado em:

- `3BLinux/boot/vmlinuz-<versão>`
- (opcional) `3BLinux/lib/modules/<versão>/`

Se você já tem o build do kernel integrado no bk, use o pacote `kernel-*`.
Caso contrário, construa kernel no host e instale no rootfs.

---

## 6) Gerar initramfs (bk-initramfs)

O initramfs do 3BLinux é baseado em BusyBox e inclui init funcional.

```sh
bin/bk-initramfs --rootfs "$ROOTFS" --output "$ROOTFS/boot/initramfs.img"
```

Confirme:

```sh
ls -lh "$ROOTFS/boot/initramfs.img"
```

---

## 7) Gerar ISO (bk-mkiso)

Você precisa ter kernel e initramfs prontos em `3BLinux/boot/`.

Exemplo:

```sh
bin/bk-mkiso -R "$ROOTFS" -o 3blinux.iso -L 3BLINUX -a "console=ttyS0"
```

---

## 8) Testar em QEMU (bk-qemu)

### 8.1 Criar disco virtual

```sh
bin/bk-qemu init
bin/bk-qemu create target 20G
```

### 8.2 Boot pelo ISO

```sh
bin/bk-qemu run target --cdrom 3blinux.iso --mem 2048 --serial stdio
```

Dentro do live você deve chegar em um shell/console de manutenção.

---

## 9) Instalar no disco (bk-install) dentro do live

### 9.1 Ver discos

No live:

```sh
lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINT
```

Em QEMU geralmente o disco é `/dev/vda`.

### 9.2 Instalação automática (apaga o disco)

```sh
bk-install -R / -d /dev/vda -L pt_BR.UTF-8 -k br-abnt2 -H 3blinux -U user -G wheel,audio,video
```

Após finalizar:

```sh
umount -R /mnt/3bl-target
reboot
```

Remova o ISO e deixe bootar pelo disco.

---

## 10) Pós-boot e serviços

O rootfs inclui init scripts básicos e agora também:
- dbus
- sshd
- smartd
- inetd (opcional)
- iptables (opcional)

Os scripts estão em:
- `/etc/init.d/*`
e os links de boot estão em:
- `/etc/rcS.d/S*`

Se você quiser habilitar/desabilitar serviços, ajuste os links em `rcS.d`.

---

## 11) Recomendações finais de sanidade

Dentro do sistema instalado:

```sh
bk-reparo
bk-cache-alternative
```

- `bk-reparo` garante diretórios/permissões básicos e roda reparos comuns.
- `bk-cache-alternative` tenta gerar cache de fontes/ícones/desktop/mime quando as ferramentas existem.


---

## 4. Construindo a cross-toolchain e temporary tools (fluxo padronizado)

Esta seção descreve o fluxo sugerido para montar a toolchain **cross/temporary**
dentro do rootfs 3BLinux usando os scripts `packages/*/build.sh` e o `bk`.

### 4.1 Ordem recomendada (alto nível)

1. **Headers do kernel**
   - Pacote: `kernel-headers-6.18.2`
   - Objetivo: instalar headers limpos em `${BK_BUILD_ROOT}/usr/include`.

2. **Binutils (pass1)**
   - Pacote: `binutils-2.45.1-pass1`
   - Objetivo: montar o assembler/linker iniciais direcionados ao `target` do 3BLinux.

3. **GCC (pass1)**
   - Pacote: `gcc-15.2.0-pass1`
   - Objetivo: criar o compilador cross inicial (sem libc completa).

4. **Glibc startfiles + headers**
   - Pacote: `glibc-2.42` (fase de startfiles conforme script de construção).
   - Objetivo: disponibilizar headers e startfiles necessárias para o GCC final.

5. **GCC “final” (toolchain completa no chroot)**
   - Pacote: `gcc-15.2.0`
   - Usa os headers/kernel e glibc startfiles já instalados no rootfs alvo.

Cada um desses passos já possui um `build.sh` preparado em `packages/`, seguindo
o padrão do `bk-tools` (compilando em `/tmp` e instalando no rootfs via `DESTDIR`).

### 4.2 Exemplo de sequência com bk-cli

Supondo que você esteja **dentro da árvore do projeto** e o rootfs final seja `./3BLinux`:

```sh
export BK_ROOT="$PWD/3BLinux"
export BK_BUILD_ROOT="$BK_ROOT"

# Exemplo genérico de uso:
#   bk-cli build <nome-pacote> [--root "$BK_ROOT"]

# 1) Headers do kernel
bin/bk-cli build kernel-headers-6.18.2 --root "$BK_ROOT"

# 2) Binutils pass1
bin/bk-cli build binutils-2.45.1-pass1 --root "$BK_ROOT"

# 3) GCC pass1
bin/bk-cli build gcc-15.2.0-pass1 --root "$BK_ROOT"

# 4) Glibc (fase headers/startfiles)
bin/bk-cli build glibc-2.42 --root "$BK_ROOT"

# 5) GCC final
bin/bk-cli build gcc-15.2.0 --root "$BK_ROOT"
```

> Observação: os scripts de construção já contêm flags ajustadas para o fluxo
> cross/temporary tools. Não é necessário passar CFLAGS/LDFLAGS customizados
> manualmente, a menos que você queira fazer tuning avançado.

### 4.3 Evoluindo do toolchain para o sistema base

Depois que a cross-toolchain e os temporary tools estiverem prontos:

1. Use `bin/bk-cli-stage-base` para construir o **conjunto base** (coreutils, bash, etc.).
2. Use `bin/bk-cli-stage-system` para montar a **toolchain de desenvolvimento completa** e um userland sólido.
3. A partir daí, siga para:
   - `bin/bk-cli-stage-xorg`
   - `bin/bk-cli-stage-desktop-min` / `-desktop-full` / `-desktop-xfce`
   - `bin/bk-cli-stage-laptop` (notebooks)

Para o restante do fluxo (initramfs, ISO, QEMU, instalação em disco), use o
`DOC/INSTALL_GUIDE.md` e `DOC/BOOT_GUIDE.md`.
