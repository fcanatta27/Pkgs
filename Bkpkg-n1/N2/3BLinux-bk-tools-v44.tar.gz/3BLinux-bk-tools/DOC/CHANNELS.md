# Política de Canais – Stable vs Unstable

## Stable
- referência para usuários
- recomendado para produção
- base para ISO oficial

## Unstable
- desenvolvimento
- testes
- novas versões
- snapshots frequentes

## Fluxo
unstable → teste → stable

Nunca o contrário.
