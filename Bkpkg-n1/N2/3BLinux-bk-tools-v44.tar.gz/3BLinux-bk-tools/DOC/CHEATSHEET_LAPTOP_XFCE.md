# 3BLinux – Cheat Sheet cronológica (Host vazio → Primeiro login XFCE em notebook)

Este documento é um **diagrama-resumo em texto**, em ordem cronológica, com os
comandos necessários para sair de um host Linux “vazio” e chegar no **primeiro
login XFCE em notebook** usando apenas o kit **bk-tools**.

> Convenções:
> - **HOST** = seu Linux atual (onde você compila e monta o rootfs).
> - **ROOTFS** = diretório `./3BLinux` (sistema final).
> - **BK_ROOT** aponta para o ROOTFS.
> - `/var/3bLinux` dentro do ROOTFS é **somente cache/repo de binários** (não build).
> - Todos os builds acontecem em `/tmp` (no host), e instalam em `DESTDIR=$BK_DESTDIR`
>   para então o `bk` empacotar e instalar no ROOTFS.

---

## 0) Pré-requisitos no host (uma vez)

### 0.1 Pacotes essenciais do host

Você precisa ter um host com toolchain e utilitários básicos para compilar:

- bash, coreutils, findutils, grep, sed, gawk
- gcc, g++, make
- binutils (ld/as), pkg-config/pkgconf
- python3, perl
- git, curl/wget
- tar, xz, gzip, bzip2
- patch, diffutils
- cmake, meson, ninja (para partes do stack gráfico e LLVM)
- bison, flex
- rsync (opcional mas recomendado)

### 0.2 Diretórios do projeto

No seu workspace:

```sh
mkdir -p ~/3blinux-work
cd ~/3blinux-work
tar -xf 3BLinux-bk-tools-v41.tar.gz
cd 3BLinux-bk-tools
```

Estrutura importante:

- `bin/` – comandos bk-tools
- `packages/` – scripts de build (um diretório por pacote)
- `3BLinux/` – o ROOTFS final (você cria)
- `DOC/` – documentação

---

## 1) Criar e preparar o ROOTFS (HOST)

### 1.1 Criar diretório do sistema final

```sh
cd ~/3blinux-work/3BLinux-bk-tools
mkdir -p 3BLinux
export BK_ROOT="$PWD/3BLinux"
```

### 1.2 Estrutura mínima inicial

O bundle já traz um `rootfs/` base. Copie para dentro do ROOTFS:

```sh
rsync -a rootfs/ "$BK_ROOT/"
```

Garanta cache de binários (dentro do ROOTFS):

```sh
mkdir -p "$BK_ROOT/var/3bLinux"
```

---

## 2) Cross/temporary tools (HOST → instala no ROOTFS)

A ordem abaixo é o “fluxo correto” para cross/temporary tools (headers staged, libc startfiles, etc.).

> Dica: sempre rode com `--root "$BK_ROOT"` para instalar dentro do ROOTFS.

### 2.1 Kernel headers (staged)

```sh
bin/bk-cli build kernel-headers-6.18.2 --root "$BK_ROOT"
```

### 2.2 Binutils pass1

```sh
bin/bk-cli build binutils-2.45.1-pass1 --root "$BK_ROOT"
```

### 2.3 GCC pass1 (compilador temporário)

```sh
bin/bk-cli build gcc-15.2.0-pass1 --root "$BK_ROOT"
```

### 2.4 Glibc (startfiles/headers)

```sh
bin/bk-cli build glibc-2.42 --root "$BK_ROOT"
```

### 2.5 GCC final (toolchain “real”)

```sh
bin/bk-cli build gcc-15.2.0 --root "$BK_ROOT"
```

### 2.6 Sanity-check da toolchain

Rode o reparo geral (isso também valida links, permissões e libs básicas):

```sh
bin/bk-reparo --root "$BK_ROOT"
```

---

## 3) Userland base (HOST → instala no ROOTFS)

### 3.1 Montar base completa

```sh
bin/bk-cli-stage-base --root "$BK_ROOT"
```

Isso instala um conjunto mínimo funcional (shell, coreutils, tar/xz, etc.) e configurações essenciais.

### 3.2 Montar “system” (serviços e ferramentas)

```sh
bin/bk-cli-stage-system --root "$BK_ROOT"
```

Aqui entram: syslog, cronie, rede básica, SSL, ferramentas dev mínimas etc.

---

## 4) Xorg + Desktop XFCE (HOST → instala no ROOTFS)

### 4.1 Stack Xorg completo

```sh
bin/bk-cli-stage-xorg --root "$BK_ROOT"
```

### 4.2 Desktop FULL (áudio + rede + greetd + sessão)

```sh
bin/bk-cli-stage-desktop-full --root "$BK_ROOT"
```

Isso prepara:
- `alsa` / `pipewire`
- `NetworkManager`
- `greetd` (opcional, dependendo do perfil)
- cache de ícones/fontes/MIME
- presets em `/etc/sysconfig/rc`

### 4.3 Desktop XFCE completo

```sh
bin/bk-cli-stage-desktop-xfce --root "$BK_ROOT"
```

Ao final você deve ter:
- `startx` funcionando
- `.xinitrc` com seleção de sessão
- XFCE instalado e pronto para uso

### 4.4 Cura completa do desktop (quando algo quebrar)

Depois de instalar/remover pacotes do desktop, rode:

```sh
bin/bk-resolve --heal-desktop --root "$BK_ROOT"
```

E, se necessário, o reparo geral:

```sh
bin/bk-reparo --root "$BK_ROOT"
bin/bk-init-reparo --root "$BK_ROOT"
```

---

## 5) Notebook: stage-laptop + perfis (HOST → instala no ROOTFS)

### 5.1 Instalar suporte laptop

```sh
bin/bk-cli-stage-laptop --root "$BK_ROOT"
```

### 5.2 Aplicar perfil de energia notebook

```sh
bin/bk-power-profile laptop --root "$BK_ROOT"
```

### 5.3 Diagnóstico de hardware

```sh
bin/bk-hardware-detect --root "$BK_ROOT"
```

Verifique no output:
- ACPI / bateria
- Wi-Fi (firmware)
- GPU (intel/amd/nouveau)
- input (touchpad)

---

## 6) Preparar boot: initramfs + kernel + grub (HOST)

### 6.1 Gerar initramfs (BusyBox + init)

```sh
bin/bk-initramfs --root "$BK_ROOT"
```

Isso gera um initramfs completo e funcional dentro do ROOTFS (veja o output do script).

### 6.2 Construir kernel (se ainda não tiver)

Se o pacote do kernel estiver no `packages/` e fizer parte do seu fluxo:

```sh
bin/bk-cli build kernel-6.18.2 --root "$BK_ROOT"
```

> Observação: o nome exato do diretório do kernel pode variar conforme o bundle; use `ls packages | grep -i kernel`.

### 6.3 Configurar GRUB (para instalação em disco)

Você normalmente faz isso durante `bk-install`. Para QEMU/ISO, use o fluxo abaixo.

---

## 7) Testar no QEMU antes de instalar (HOST)

### 7.1 Criar VM e bootar

Crie uma imagem e instale (ou use ISO):

```sh
bin/bk-qemu create --name 3blinux-notebook --size 40G
bin/bk-qemu boot   --name 3blinux-notebook --iso out/3BLinux.iso
```

> Dica: o `bk-qemu` mantém as imagens num diretório próprio e gerencia listar/remover.

---

## 8) Gerar ISO e boot live (HOST)

### 8.1 Gerar ISO

```sh
bin/bk-mkiso --root "$BK_ROOT" --outdir "$PWD/out"
```

Resultado esperado:
- `out/3BLinux.iso`

### 8.2 Testar ISO no QEMU

```sh
bin/bk-qemu boot --name 3blinux-live --iso out/3BLinux.iso
```

---

## 9) Primeiro boot real e primeiro login XFCE (NO SISTEMA)

Quando você bootar (live ou instalado):

### 9.1 Login no console

- root (ou usuário criado no install)

### 9.2 Criar usuário (se ainda não existir)

Dentro do 3BLinux:

```sh
bk-adduser <nome>
```

### 9.3 Escolher sessão X e iniciar XFCE

Se o `.xinitrc` estiver configurado com menu, você pode escolher XFCE.

Ou iniciar diretamente:

```sh
startx
```

Se quiser forçar XFCE:

```sh
XSESSION=xfce startx
```

### 9.4 Se o desktop falhar

Rodar cura completa:

```sh
bk-resolve --heal-desktop
bk-reparo
bk-init-reparo
```

---

## 10) “Mapa” mental do fluxo (diagrama em linha)

```
HOST vazio
  -> preparar host + extrair bk-tools
  -> criar ROOTFS (./3BLinux) + rsync rootfs/
  -> cross/temporary tools:
       kernel-headers -> binutils-pass1 -> gcc-pass1 -> glibc(startfiles) -> gcc-final
  -> bk-reparo (sanity toolchain)
  -> stage-base -> stage-system
  -> stage-xorg -> stage-desktop-full -> stage-desktop-xfce
  -> stage-laptop + power profile + hardware detect
  -> bk-initramfs -> kernel -> mkiso -> qemu test
  -> boot live -> bk-install -> boot instalado
  -> bk-adduser -> startx -> XFCE
```

---

## 11) Checklist rápido SOS (desktop em notebook não sobe)

Dentro do sistema (ou com `--root` apontando pro ROOTFS):

```sh
bk-hardware-detect
bk-resolve --heal-desktop
bk-reparo
bk-init-reparo
```

Se rede não sobe:

```sh
# Habilitar no /etc/sysconfig/rc e reiniciar serviço (ou reboot)
# Ver status do NM
nmcli dev
```

Se áudio não sobe:

```sh
# checar pipewire / alsa
pw-cli info 0 || true
aplay -l || true
```

---

Fim do cheat sheet.
