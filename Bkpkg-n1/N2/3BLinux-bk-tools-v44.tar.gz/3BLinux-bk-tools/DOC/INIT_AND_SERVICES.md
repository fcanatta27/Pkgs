# 3BLinux – Guia de Init, Serviços e Perfis de Boot

Este documento explica, em profundidade:

- O modelo de init do 3BLinux (init + rcS + rcS.d)
- Como os scripts em `/etc/init.d` funcionam
- Como o perfil de serviços em `/etc/sysconfig/rc` controla o boot
- Interação com `bk-init-reparo` e `bk-reparo`

Ele assume que você tem o rootfs em `./3BLinux` dentro do projeto `3BLinux-bk-tools`.

---

## 1. Visão geral do init

O init do 3BLinux é baseado em:

- `3BLinux/sbin/init` (gerado pelo `bk-initramfs` usando BusyBox + scripts)
- `/etc/inittab` – define o runlevel inicial e quais scripts são chamados
- `/etc/init.d/*` – scripts de serviço no estilo “SysV-like” simplificado
- `/etc/rcS.d/` – links simbólicos `SNNnome` que apontam para scripts reais

Fluxo básico de boot:

1. `init` é iniciado pelo kernel com `init=/sbin/init` ou padrão.
2. `init` lê `/etc/inittab` do rootfs.
3. Em modo single/boot, chama o script `rcS` (tipicamente `/etc/init.d/rcS`).
4. `rcS` percorre `/etc/rcS.d/S*` em ordem numérica e chama cada link com `start`.

Exemplo: se você tiver:

```text
/etc/rcS.d/S15dbus   -> ../init.d/dbus
/etc/rcS.d/S20network -> ../init.d/network
/etc/rcS.d/S25syslog -> ../init.d/syslog
/etc/rcS.d/S60sshd   -> ../init.d/sshd
```

Na subida do sistema, serão chamados na ordem:

1. `/etc/init.d/dbus start`
2. `/etc/init.d/network start`
3. `/etc/init.d/syslog start`
4. `/etc/init.d/sshd start`

---

## 2. Scripts em /etc/init.d

Cada serviço é um shell script simples, com interface padrão:

```sh
#!/bin/sh

case "$1" in
  start)
    # código para subir serviço
    ;;
  stop)
    # código para parar serviço
    ;;
  restart)
    "$0" stop
    "$0" start
    ;;
  *)
    echo "Uso: $0 {start|stop|restart}" >&2
    exit 1
    ;;
esac

exit 0
```

No 3BLinux você já tem, por exemplo:

- `dbus` – inicia `dbus-daemon` system bus
- `sshd` – garante chaves host e sobe `sshd`
- `smartd` – sobe `smartd` com `/etc/smartd.conf`
- `inetd` – sobe `inetd` com `/etc/inetd.conf`
- `iptables` – carrega regras de `/etc/iptables/rules.v4`
- `network`, `syslog`, etc. – outros serviços básicos

Você pode:

- Iniciar manualmente: `chroot 3BLinux /etc/init.d/sshd start`
- Parar manualmente: `chroot 3BLinux /etc/init.d/sshd stop`

---

## 3. Perfil de serviços em /etc/sysconfig/rc

O controle central dos serviços de boot é o arquivo:

```text
3BLinux/etc/sysconfig/rc
```

Formato base:

```sh
# /etc/sysconfig/rc - perfil de serviços 3BLinux
# Valores: yes/no (case-insensitive)
SERVICE_DBUS=yes
SERVICE_SSHD=yes
SERVICE_SMARTD=no
SERVICE_INETD=no
SERVICE_IPTABLES=no
```

Essas variáveis definem quais links devem existir em `/etc/rcS.d`.

### 3.1 Como aplicar o perfil

Do lado de fora (no host), com o rootfs em `./3BLinux`:

```sh
bin/bk-reparo --root 3BLinux
```

ou, focado no init/initramfs:

```sh
bin/bk-init-reparo --root 3BLinux --rebuild-initramfs
```

Esses scripts vão:

1. Garantir diretórios e arquivos básicos em `3BLinux/etc`
2. Aplicar o perfil de serviços (criando/removendo links `SNN*` baseado em `SERVICE_*`)
3. Opcionalmente reconstruir initramfs (`bk-init-reparo`)

### 3.2 Perfis “prontos” (presets)

No próprio `/etc/sysconfig/rc` existem presets comentados, por exemplo:

```sh
## Presets sugeridos
# --- preset-server (mínimo, seguro) ---
# SERVICE_DBUS=no
# SERVICE_SSHD=yes
# SERVICE_SMARTD=yes
# SERVICE_INETD=no
# SERVICE_IPTABLES=yes

# --- preset-desktop-lite (userland + dbus) ---
# SERVICE_DBUS=yes
# SERVICE_SSHD=no
# SERVICE_SMARTD=no
# SERVICE_INETD=no
# SERVICE_IPTABLES=no

# --- preset-lab (debug/experimentos) ---
# SERVICE_DBUS=yes
# SERVICE_SSHD=yes
# SERVICE_SMARTD=no
# SERVICE_INETD=yes
# SERVICE_IPTABLES=no
```

Para usar um preset, basta:

1. Copiar o bloco desejado
2. Substituir os `SERVICE_*` principais no topo do arquivo
3. Rodar `bk-reparo` ou `bk-init-reparo`

Exemplo, configurando um servidor:

```sh
sed -i 's/^SERVICE_DBUS=.*/SERVICE_DBUS=no/' 3BLinux/etc/sysconfig/rc
sed -i 's/^SERVICE_SSHD=.*/SERVICE_SSHD=yes/' 3BLinux/etc/sysconfig/rc
sed -i 's/^SERVICE_SMARTD=.*/SERVICE_SMARTD=yes/' 3BLinux/etc/sysconfig/rc
sed -i 's/^SERVICE_IPTABLES=.*/SERVICE_IPTABLES=yes/' 3BLinux/etc/sysconfig/rc

bin/bk-reparo --root 3BLinux
```

---

## 4. Interação com bk-initramfs e bk-init-reparo

- `bk-initramfs` monta um initramfs completo, a partir do rootfs.
- `bk-init-reparo` garante que:
  - `/sbin/init` aponte para o init esperado (busybox + script)
  - `/etc/inittab` exista e esteja coerente
  - scripts `rcS` e diretórios sejam criados
  - o perfil de serviços sob `/etc/sysconfig/rc` seja respeitado
  - o initramfs seja reconstruído (se você passar `--rebuild-initramfs`)

Sempre que você fizer mudanças profundas em init, serviços ou `/etc/sysconfig/rc`, é boa prática:

```sh
bin/bk-init-reparo --root 3BLinux --rebuild-initramfs
```

Isso reduz chances de “boot quebra por falta de arquivo”.
