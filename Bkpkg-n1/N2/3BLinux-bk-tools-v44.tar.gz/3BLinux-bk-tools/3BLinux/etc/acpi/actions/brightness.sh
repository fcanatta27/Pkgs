#!/bin/sh
# Ajuste de brilho simples via /sys/class/backlight/*/brightness
LOGGER="logger -t acpid-brightness"

BACKLIGHT_DIR="$(ls -d /sys/class/backlight/* 2>/dev/null | head -n1)"
[ -n "$BACKLIGHT_DIR" ] || exit 0

BRIGHT_FILE="$BACKLIGHT_DIR/brightness"
MAX_FILE="$BACKLIGHT_DIR/max_brightness"

[ -r "$BRIGHT_FILE" ] || exit 0
[ -r "$MAX_FILE" ] || exit 0

CUR=$(cat "$BRIGHT_FILE")
MAX=$(cat "$MAX_FILE")

STEP=$((MAX / 10))
[ "$STEP" -lt 1 ] && STEP=1

case "$1" in
  up)
    NEW=$((CUR + STEP))
    [ "$NEW" -gt "$MAX" ] && NEW="$MAX"
    echo "$NEW" > "$BRIGHT_FILE"
    $LOGGER "brightness up: $CUR -> $NEW"
    ;;
  down)
    NEW=$((CUR - STEP))
    [ "$NEW" -lt 1 ] && NEW=1
    echo "$NEW" > "$BRIGHT_FILE"
    $LOGGER "brightness down: $CUR -> $NEW"
    ;;
  *)
    $LOGGER "brightness event: $*"
    ;;
esac
