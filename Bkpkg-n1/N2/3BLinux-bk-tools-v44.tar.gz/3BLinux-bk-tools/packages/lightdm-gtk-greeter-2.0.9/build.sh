#!/usr/bin/env bash
# build.sh – lightdm-gtk-greeter 2.0.9
#
# Pacote: lightdm-gtk-greeter
# Versão: 2.0.9
# Descrição: Greeter GTK3 para LightDM.
# Fonte: https://github.com/Xubuntu/lightdm-gtk-greeter/releases/download/2.0.9/lightdm-gtk-greeter-2.0.9.tar.gz
#
# Dependências (comentadas):
#   - lightdm
#   - gtk3
#   - glib2
#   - cairo
#   - gdk-pixbuf
#   - libx11
#
set -Eeuo pipefail

# UI
if [[ -t 2 ]]; then
  B="\033[1m"; R="\033[31m"; G="\033[32m"; Y="\033[33m"; N="\033[0m"
else
  B=""; R=""; G=""; Y=""; N=""
fi
msg(){ echo -e "${B}${G}==>${N} $*" >&2; }
warn(){ echo -e "${B}${Y}==> WARN:${N} $*" >&2; }
die(){ echo -e "${B}${R}==> ERRO:${N} $*" >&2; exit 1; }

export BK_PKG_NAME="${BK_PKG_NAME:-lightdm-gtk-greeter}"
export BK_PKG_VERSION="${BK_PKG_VERSION:-2.0.9}"

: "${BK_ROOT:=${BK_ROOT:-/}}"
: "${BK_WORKDIR:=${BK_WORKDIR:-/tmp/bk-build/${BK_PKG_NAME}-${BK_PKG_VERSION}}}"
: "${BK_SRCDIR:=${BK_SRCDIR:-/tmp/bk-src}}"
: "${BK_DESTDIR:=${BK_DESTDIR:-${BK_WORKDIR}/dest}}"
: "${BK_JOBS:=${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}}"

mkdir -p "$BK_WORKDIR" "$BK_SRCDIR" "$BK_DESTDIR"

fetch() {
  local url="$1" out="$2"
  if [[ -f "$out" ]]; then msg "Fonte já existe: $out"; return 0; fi
  msg "Baixando: $url"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 -o "$out" "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    die "Precisa de curl ou wget"
  fi
}

unpack() {
  local tarball="$1"
  msg "Extraindo: $tarball"
  rm -rf "$BK_WORKDIR/src"
  mkdir -p "$BK_WORKDIR/src"
  tar -xf "$tarball" -C "$BK_WORKDIR/src" --strip-components=1
}

msg "Iniciando build: ${BK_PKG_NAME}-${BK_PKG_VERSION}"
msg "WORKDIR=$BK_WORKDIR"
msg "DESTDIR=$BK_DESTDIR"
SRC="$BK_SRCDIR/lightdm-gtk-greeter-2.0.9.tar.gz"
fetch "https://github.com/Xubuntu/lightdm-gtk-greeter/releases/download/2.0.9/lightdm-gtk-greeter-2.0.9.tar.gz" "$SRC"
unpack "$SRC"
cd "$BK_WORKDIR/src"

msg "Configurando…"
./configure --prefix=/usr \
  --sysconfdir=/etc \
  --localstatedir=/var \
  --disable-static

msg "Compilando…"
make -j"$BK_JOBS"

msg "Instalando em DESTDIR…"
make DESTDIR="$BK_DESTDIR" install

msg "OK"
