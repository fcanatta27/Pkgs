#!/usr/bin/env bash
#
# Dependencias (comentado)
#   - Build: bash, coreutils, gcc, meson, ninja, pkg-config, glib2, pipewire, lua
#   - Runtime: pipewire
#
set -Eeuo pipefail

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

TMPDIR=${TMPDIR:-/tmp}
JOBS=${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}

SRC_URL='https://gitlab.freedesktop.org/pipewire/wireplumber/-/archive/0.5.5/wireplumber-0.5.5.tar.gz'
TARBALL='wireplumber-0.5.5.tar.gz'
SRCDIR='wireplumber-0.5.5'

req(){ command -v "wireplumber" >/dev/null 2>&1 || { echo "wireplumber: falta comando: wireplumber" >&2; exit 1; }; }
msg(){ echo "[wireplumber] wireplumber 0.5.5 https://gitlab.freedesktop.org/pipewire/wireplumber/-/archive/0.5.5/wireplumber-0.5.5.tar.gz wireplumber-0.5.5.tar.gz wireplumber-0.5.5 bash, coreutils, gcc, meson, ninja, pkg-config, glib2, pipewire, lua pipewire -Dsystemd=disabled -Dman=false" >&2; }

fetch(){
  local out="${TMPDIR}/${TARBALL}"
  if [[ -f "${out}" ]]; then msg "usando cache ${out}"; return 0; fi
  msg "baixando ${SRC_URL}"
  if command -v curl >/dev/null 2>&1; then curl -L --fail -o "${out}" "${SRC_URL}"; else wget -O "${out}" "${SRC_URL}"; fi
}

unpack(){
  rm -rf "${TMPDIR}/build-src-wireplumber-${BK_PKG_VERSION}"
  mkdir -p "${TMPDIR}/build-src-wireplumber-${BK_PKG_VERSION}"
  tar -C "${TMPDIR}/build-src-wireplumber-${BK_PKG_VERSION}" -xf "${TMPDIR}/${TARBALL}"
}

main(){
  for t in tar gcc; do req ""; done
  req meson; req ninja
  fetch
  unpack
  local top="${TMPDIR}/build-src-wireplumber-${BK_PKG_VERSION}"
  local src="${top}/${SRCDIR}"
  if [[ ! -d "${src}" ]]; then src="$(find "${top}" -maxdepth 2 -type d -name "${SRCDIR}" | head -n1 || true)"; fi
  [[ -d "${src}" ]] || { echo "wireplumber: fontes nao encontradas em ${src}" >&2; exit 1; }

  rm -rf "${BK_BUILD_ROOT:?}"/*
  mkdir -p "${BK_BUILD_ROOT}"

  local bdir="${TMPDIR}/build-wireplumber-${BK_PKG_VERSION}"
  rm -rf "${bdir}"; mkdir -p "${bdir}"

  msg "configurando (meson)..."
  ( cd "${bdir}" && meson setup "${src}" --prefix=/usr --buildtype=release -Ddefault_library=shared -Dsystemd=disabled -Dman=false )

  msg "compilando (ninja)..."
  ninja -C "${bdir}" -j"${JOBS}"

  msg "instalando (DESTDIR)..."
  DESTDIR="${BK_BUILD_ROOT}" ninja -C "${bdir}" install

  msg "ok"
}

main "wireplumber 0.5.5 https://gitlab.freedesktop.org/pipewire/wireplumber/-/archive/0.5.5/wireplumber-0.5.5.tar.gz wireplumber-0.5.5.tar.gz wireplumber-0.5.5 bash, coreutils, gcc, meson, ninja, pkg-config, glib2, pipewire, lua pipewire -Dsystemd=disabled -Dman=false"
