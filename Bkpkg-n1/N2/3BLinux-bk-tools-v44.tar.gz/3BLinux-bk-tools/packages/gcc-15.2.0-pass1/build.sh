#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, make, gcc (host), g++, wget, tar, xz, bzip2, gzip
#   - Build: gmp, mpfr, mpc, isl (via ./contrib/download_prerequisites ou pacotes do host)
#   - Runtime: libgcc (instalado no rootfs), binutils target
#
# build.sh - gcc-15.2.0-pass1 (cross/temporary, instalando em /usr)
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _BK_BOLD="\033[1m"; _BK_RED="\033[31m"; _BK_GRN="\033[32m"; _BK_YEL="\033[33m"; _BK_BLU="\033[34m"; _BK_RST="\033[0m"
else
  _BK_BOLD=""; _BK_RED=""; _BK_GRN=""; _BK_YEL=""; _BK_BLU=""; _BK_RST=""
fi
_bk_info() { echo -e "gcc-pass1: ${_BK_BOLD}${_BK_BLU}$*${_BK_RST}" >&2; }
_bk_ok()   { echo -e "gcc-pass1: ${_BK_BOLD}${_BK_GRN}$*${_BK_RST}" >&2; }
_bk_warn() { echo -e "gcc-pass1: ${_BK_BOLD}${_BK_YEL}$*${_BK_RST}" >&2; }
_bk_err()  { echo -e "gcc-pass1: ${_BK_BOLD}${_BK_RED}$*${_BK_RST}" >&2; }

_die(){ _bk_err "$*"; exit 1; }
_require_cmd(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
MAKE_JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"
TARGET="${BK_TARGET:-$(uname -m)-3blinux-linux-gnu}"
SYSROOT="${BK_SYSROOT:-${BK_BUILD_ROOT}}"

_require_cmd wget
_require_cmd tar
_require_cmd make

SRC_URL="${SRC_URL:-https://gcc.gnu.org/pub/gcc/releases/gcc-${BK_PKG_VERSION}/gcc-${BK_PKG_VERSION}.tar.xz}"
SRC_TARBALL="${TMPDIR}/gcc-${BK_PKG_VERSION}.tar.xz"
SRC_DIR="${TMPDIR}/src-gcc-${BK_PKG_VERSION}"
BUILD_DIR="${TMPDIR}/build-gcc-${BK_PKG_VERSION}-pass1"

_bk_info "Construindo gcc pass1: ${BK_PKG_NAME}-${BK_PKG_VERSION}"
_bk_info "TARGET=${TARGET} SYSROOT=${SYSROOT}"
_bk_info "DESTDIR=${BK_BUILD_ROOT} JOBS=${MAKE_JOBS}"

mkdir -p -- "${BK_BUILD_ROOT}" "${SRC_DIR}" "${BUILD_DIR}"

if [[ ! -f "${SRC_TARBALL}" ]]; then
  _bk_info "Baixando: ${SRC_URL}"
  wget -O "${SRC_TARBALL}" "${SRC_URL}"
else
  _bk_info "Usando tarball cacheado: ${SRC_TARBALL}"
fi

_bk_info "Extraindo fontes..."
rm -rf -- "${SRC_DIR}"
mkdir -p -- "${SRC_DIR}"
tar -C "${SRC_DIR}" -xf "${SRC_TARBALL}"

src_subdir="${SRC_DIR}/gcc-${BK_PKG_VERSION}"
[[ -d "${src_subdir}" ]] || _die "fontes não encontradas: ${src_subdir}"

if [[ -x "${src_subdir}/contrib/download_prerequisites" ]]; then
  _bk_info "Baixando prerequisitos (GMP/MPFR/MPC/ISL)..."
  ( cd "${src_subdir}" && ./contrib/download_prerequisites )
else
  _bk_warn "download_prerequisites não encontrado; dependências devem existir no host."
fi

rm -rf -- "${BUILD_DIR}"
mkdir -p -- "${BUILD_DIR}"
cd "${BUILD_DIR}"

export PATH="${BK_BUILD_ROOT}/usr/bin:${PATH}"

_bk_info "Configurando..."
"${src_subdir}/configure" \
  --target="${TARGET}" \
  --prefix=/usr \
  --with-sysroot="${SYSROOT}" \
  --disable-nls \
  --disable-multilib \
  --enable-languages=c,c++ \
  --without-headers \
  --with-newlib \
  --disable-shared \
  --disable-threads \
  --disable-libatomic \
  --disable-libgomp \
  --disable-libquadmath \
  --disable-libssp \
  --disable-libvtv \
  --disable-libstdcxx \
  --enable-initfini-array

_bk_info "Compilando (all-gcc)..."
make -j"${MAKE_JOBS}" all-gcc

_bk_info "Compilando (libgcc)..."
make -j"${MAKE_JOBS}" all-target-libgcc

_bk_info "Instalando (install-gcc)..."
make DESTDIR="${BK_BUILD_ROOT}" install-gcc

_bk_info "Instalando (install-target-libgcc)..."
make DESTDIR="${BK_BUILD_ROOT}" install-target-libgcc

_bk_ok "Concluído: gcc pass1 em ${BK_BUILD_ROOT}/usr"
