#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, make, pkg-config, zlib, xz, zstd, pcre2 (opcional)
#   - Build: pam (opcional), systemd (opcional), readline, ncurses (para algumas ferramentas)
#   - Runtime: libc, kernel Linux, fs libs (blkid, uuid, etc.)
#
# build.sh - util-linux ${BK_PKG_VERSION}
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi
_i(){ echo -e "util-linux: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "util-linux: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "util-linux: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "util-linux: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

_req wget
_req tar
_req make

MAJOR_MINOR="2.41"   # diretório em kernel.org
SRC_URL="${SRC_URL:-https://www.kernel.org/pub/linux/utils/util-linux/v${MAJOR_MINOR}/util-linux-${BK_PKG_VERSION}.tar.xz}"
TARBALL="${TMPDIR}/util-linux-${BK_PKG_VERSION}.tar.xz"
SRC_DIR="${TMPDIR}/src-util-linux-${BK_PKG_VERSION}"
BUILD_DIR="${TMPDIR}/build-util-linux-${BK_PKG_VERSION}"

_i "Construindo util-linux ${BK_PKG_VERSION}"
_i "BK_PKG_NAME=${BK_PKG_NAME} DESTDIR=${BK_BUILD_ROOT} JOBS=${JOBS}"

mkdir -p -- "${BK_BUILD_ROOT}" "${SRC_DIR}" "${BUILD_DIR}"

if [[ ! -f "${TARBALL}" ]]; then
  _i "Baixando: ${SRC_URL}"
  wget -O "${TARBALL}" "${SRC_URL}"
else
  _i "Usando tarball cacheado: ${TARBALL}"
fi

_i "Extraindo..."
rm -rf -- "${SRC_DIR}"
mkdir -p -- "${SRC_DIR}"
tar -C "${SRC_DIR}" -xf "${TARBALL}"

src="${SRC_DIR}/util-linux-${BK_PKG_VERSION}"
[[ -d "${src}" ]] || _die "fontes não encontradas: ${src}"

rm -rf -- "${BUILD_DIR}"
mkdir -p -- "${BUILD_DIR}"
cd "${BUILD_DIR}"

_i "Configurando util-linux..."
"${src}/configure" \
  --prefix=/usr \
  --sysconfdir=/etc \
  --localstatedir=/var \
  --bindir=/usr/bin \
  --sbindir=/usr/sbin \
  --libdir=/usr/lib \
  --includedir=/usr/include \
  --disable-static \
  --enable-shared \
  --without-python \
  --without-systemd \
  --without-systemdsystemunitdir \
  --disable-chfn-chsh-password \
  --disable-login \
  --disable-sulogin

_i "Compilando util-linux..."
make -j"${JOBS}"

_i "Instalando util-linux em DESTDIR..."
make DESTDIR="${BK_BUILD_ROOT}" install

_o "Concluído: util-linux ${BK_PKG_VERSION} instalado em ${BK_BUILD_ROOT}"
