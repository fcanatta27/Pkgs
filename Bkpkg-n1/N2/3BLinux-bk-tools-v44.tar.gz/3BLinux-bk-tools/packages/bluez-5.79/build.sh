#!/usr/bin/env bash
#
# Dependencias (comentado)
#   - Build: bash, coreutils, gcc, make, tar, xz, pkg-config, glib2, dbus
#   - Runtime: dbus
#
set -Eeuo pipefail

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

TMPDIR=${TMPDIR:-/tmp}
JOBS=${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}

SRC_URL='https://www.kernel.org/pub/linux/bluetooth/bluez-5.79.tar.xz'
TARBALL='bluez-5.79.tar.xz'
SRCDIR='bluez-5.79'

req(){ command -v "bluez" >/dev/null 2>&1 || { echo "bluez: falta comando: bluez" >&2; exit 1; }; }
msg(){ echo "[bluez] bluez 5.79 https://www.kernel.org/pub/linux/bluetooth/bluez-5.79.tar.xz bluez-5.79.tar.xz bluez-5.79 bash, coreutils, gcc, make, tar, xz, pkg-config, glib2, dbus dbus --enable-library" >&2; }

fetch(){
  local out="${TMPDIR}/${TARBALL}"
  if [[ -f "${out}" ]]; then msg "usando cache ${out}"; return 0; fi
  msg "baixando ${SRC_URL}"
  if command -v curl >/dev/null 2>&1; then curl -L --fail -o "${out}" "${SRC_URL}"; else wget -O "${out}" "${SRC_URL}"; fi
}

unpack(){
  rm -rf "${TMPDIR}/build-src-bluez-${BK_PKG_VERSION}"
  mkdir -p "${TMPDIR}/build-src-bluez-${BK_PKG_VERSION}"
  tar -C "${TMPDIR}/build-src-bluez-${BK_PKG_VERSION}" -xf "${TMPDIR}/${TARBALL}"
}

main(){
  for t in tar make gcc; do req ""; done
  req sh
  fetch
  unpack
  local top="${TMPDIR}/build-src-bluez-${BK_PKG_VERSION}"
  local src="${top}/${SRCDIR}"
  if [[ ! -d "${src}" ]]; then src="$(find "${top}" -maxdepth 2 -type d -name "${SRCDIR}" | head -n1 || true)"; fi
  [[ -d "${src}" ]] || { echo "bluez: fontes nao encontradas em ${src}" >&2; exit 1; }

  rm -rf "${BK_BUILD_ROOT:?}"/*
  mkdir -p "${BK_BUILD_ROOT}"

  msg "configurando..."
  ( cd "${src}" && ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --disable-static --enable-library )

  msg "compilando..."
  ( cd "${src}" && make -j"${JOBS}" )

  msg "instalando (DESTDIR)..."
  ( cd "${src}" && make DESTDIR="${BK_BUILD_ROOT}" install )

  msg "ok"
}

main "bluez 5.79 https://www.kernel.org/pub/linux/bluetooth/bluez-5.79.tar.xz bluez-5.79.tar.xz bluez-5.79 bash, coreutils, gcc, make, tar, xz, pkg-config, glib2, dbus dbus --enable-library"
