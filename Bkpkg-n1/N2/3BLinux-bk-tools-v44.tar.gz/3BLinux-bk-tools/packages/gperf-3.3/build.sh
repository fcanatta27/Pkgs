#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, make, wget, tar
#   - Runtime: libc
#
# Padrão bk-tools:
#   Requer: BK_PKG_NAME, BK_PKG_VERSION, BK_BUILD_ROOT
#   Constrói em /tmp e instala via DESTDIR em BK_BUILD_ROOT
#
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi

_i(){ echo -e "${_B}${_U}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_o(){ echo -e "${_B}${_G}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_w(){ echo -e "${_B}${_Y}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_e(){ echo -e "${_B}${_R}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

_req wget
_req tar
_req make

_dl(){
  local url="$1" out="$2"
  if [[ -f "$out" ]]; then
    _i "Usando tarball cacheado: $out"
    return 0
  fi
  _i "Baixando: $url"
  wget -O "$out" "$url"
}

_extract(){
  local tarball="$1" dest="$2"
  rm -rf -- "$dest"
  mkdir -p -- "$dest"
  tar -C "$dest" -xf "$tarball"
}

SRC_URL="${SRC_URL:-https://ftp.gnu.org/gnu/gperf/gperf-${BK_PKG_VERSION}.tar.gz}"
TARBALL="${TMPDIR}/gperf-3.3.tar.gz"
SRC_DIR="${TMPDIR}/src-gperf-3.3"
BUILD_DIR="${TMPDIR}/build-gperf-3.3"

_i "Construindo gperf-3.3"
_i "DESTDIR=${BK_BUILD_ROOT} JOBS=${JOBS}"

_dl "${SRC_URL}" "${TARBALL}"
_extract "${TARBALL}" "${SRC_DIR}"

src="${SRC_DIR}/gperf-${BK_PKG_VERSION}"
[[ -d "${src}" ]] || _die "fontes não encontradas: $src"

rm -rf -- "${BUILD_DIR}"
mkdir -p -- "${BUILD_DIR}"
cd "${BUILD_DIR}"

_i "Configurando..."
"${src}/configure" --prefix=/usr --disable-static

_i "Compilando..."
make -j"${JOBS}"

_i "Instalando em DESTDIR..."
make DESTDIR="${BK_BUILD_ROOT}" install

_o "Concluído"
