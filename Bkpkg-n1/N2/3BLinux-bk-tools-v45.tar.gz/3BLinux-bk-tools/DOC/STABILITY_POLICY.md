# Critérios de Estabilidade – 3BLinux

## 1. Definição

Estabilidade no 3BLinux significa:

- comportamento previsível
- upgrades controlados
- reparabilidade garantida

Não significa ausência de bugs, mas **controle sobre eles**.

---

## 2. Regras para o canal stable

- Nenhuma atualização automática
- Nenhuma atualização forçada
- Atualizações manuais via bk-update
- Mudanças grandes apenas em releases

---

## 3. Testes mínimos obrigatórios

Todo pacote stable deve passar:

- build limpo
- instalação via bk
- remoção via bk
- reboot
- bk-reparo
- bk-init-reparo

Pacotes gráficos:
- startx
- login via LightDM

---

## 4. Política de regressão

- regressão → pacote volta para unstable
- stable nunca quebra o boot
- stable nunca quebra o login

---

## 5. Segurança

- prioridade em:
  - glibc
  - openssl
  - kernel
- patches retroportados se necessário

---

## 6. Compatibilidade

- ABI preservada dentro da série 1.0
- mudanças incompatíveis → 2.0
