# Guia: publicando o repositório binário do 3BLinux em um servidor

Este guia mostra, passo a passo, como:

1. Preparar um servidor Linux simples para servir o repositório binário.
2. Organizar o diretório `/var/www/3blinux-repo/` com **stable** e **unstable**.
3. Usar `bk-repo-scan` para gerar o `bk-repo.txt`.
4. Configurar HTTPS (TLS) com Let's Encrypt (opcional, recomendado).
5. Configurar os clientes 3BLinux para usar `bk-update`.

O foco é em **Nginx**, mas você pode adaptar para Apache ou outro HTTP server.

---

## 1. Pré-requisitos do servidor

Você pode usar qualquer distro (Debian, Ubuntu, Alma, Arch, etc.).  
Supondo um servidor dedicado ou VPS com:

- Acesso root ou sudo.
- Hostname e DNS apontando para o servidor.
- Porta 80/443 liberadas.

### 1.1 Instalar Nginx e ferramentas básicas

Em um servidor baseado em Debian/Ubuntu:

```sh
apt update
apt install -y nginx rsync tar gzip coreutils
```

Em RHEL/Alma/Rocky:

```sh
dnf install -y nginx rsync tar gzip coreutils
systemctl enable --now nginx
```

---

## 2. Estrutura do repositório

No servidor, o layout sugerido é:

```text
/var/www/3blinux-repo/
  stable/
    bk-repo.txt
    packages/
      *.tar.gz
  unstable/
    bk-repo.txt
    packages/
      *.tar.gz
```

Crie a estrutura:

```sh
mkdir -p /var/www/3blinux-repo/{stable,unstable}/packages
chown -R www-data:www-data /var/www/3blinux-repo   # usuário do nginx (ajuste se for outro)
```

---

## 3. Publicar os pacotes

### 3.1 Gerar pacotes no 3BLinux

No seu ambiente 3BLinux, você constrói os pacotes com `bk` normalmente, e o resultado são
arquivos `.tar.gz` no seu cache (ex.: `/var/3bLinux`).

Copie os pacotes desejados para o servidor (por SSH/rsync):

```sh
rsync -avz /var/3bLinux/*.tar.gz usuario@seu-servidor:/var/www/3blinux-repo/stable/packages/
```

Para unstable:

```sh
rsync -avz /var/3bLinux/unstable/*.tar.gz usuario@seu-servidor:/var/www/3blinux-repo/unstable/packages/
```

---

## 4. Gerar bk-repo.txt com bk-repo-scan

No servidor, instale o script `bk-repo-scan` (do seu bundle bk-tools) em `/usr/local/bin`:

```sh
install -m 755 bk-repo-scan /usr/local/bin/bk-repo-scan
```

Então, gere o manifesto para cada canal:

```sh
bk-repo-scan --repo-root /var/www/3blinux-repo --channel stable
bk-repo-scan --repo-root /var/www/3blinux-repo --channel unstable
```

Isso criará:

- `/var/www/3blinux-repo/stable/bk-repo.txt`
- `/var/www/3blinux-repo/unstable/bk-repo.txt`

Formato de cada linha:

```text
name|version|filename|sha256|size
```

---

## 5. Configurando o Nginx

Crie um arquivo de site, por exemplo `/etc/nginx/sites-available/3blinux-repo.conf`:

```nginx
server {
    listen 80;
    server_name repo.seu-dominio;

    root /var/www/3blinux-repo;
    autoindex on;

    location / {
        try_files $uri $uri/ =404;
    }
}
```

Ative o site (Debian-like):

```sh
ln -s /etc/nginx/sites-available/3blinux-repo.conf /etc/nginx/sites-enabled/3blinux-repo.conf
nginx -t
systemctl reload nginx
```

Teste no navegador ou com curl:

```sh
curl http://repo.seu-dominio/stable/bk-repo.txt
```

---

## 6. HTTPS com Let's Encrypt (recomendado)

Instale o certbot (exemplo em Debian):

```sh
apt install -y certbot python3-certbot-nginx
certbot --nginx -d repo.seu-dominio
```

O certbot irá:

- emitir um certificado
- atualizar automaticamente o config do nginx
- configurar renovação automática

---

## 7. Automatizando atualização do manifesto

Sempre que você adicionar/remover `.tar.gz` em `packages/`, rode:

```sh
bk-repo-scan --repo-root /var/www/3blinux-repo --channel stable
```

Você pode agendar, por exemplo, um cron:

```sh
crontab -e
```

Entrar com algo como:

```cron
*/10 * * * * /usr/local/bin/bk-repo-scan --repo-root /var/www/3blinux-repo --channel stable >/var/log/bk-repo-scan.log 2>&1
```

---

## 8. Configurando o cliente 3BLinux

No rootfs do 3BLinux, edite `/etc/bk/repo.conf`:

```sh
BK_REPO_BASE_URL="https://repo.seu-dominio/3blinux-repo"
BK_REPO_CHANNEL="stable"
BK_REPO_PACKAGES_SUBDIR="packages"
BK_REPO_MANIFEST="bk-repo.txt"
BK_REPO_VERIFY_SHA256="yes"
```

Se você não usou o subdiretório extra `3blinux-repo` na URL, ajuste:

```sh
BK_REPO_BASE_URL="https://repo.seu-dominio"
```

---

## 9. Usando o bk-update

No 3BLinux:

### 9.1 Atualizar tudo instalado

```sh
bk-update
```

### 9.2 Atualizar pacotes específicos

```sh
bk-update openssl bash coreutils
```

### 9.3 Trocar canal para unstable (apenas para testes)

```sh
bk-update --channel unstable
```

---

## 10. Boas práticas

- Mantenha `stable` apenas com pacotes **testados**.
- Use `unstable` para experimentar novas versões.
- Sempre rode `bk-repo-scan` após mexer em `packages/`.
- Use HTTPS em produção.
- Faça backup periódico de `/var/www/3blinux-repo`.

Com isso, você tem um repositório de binários simples, estável e totalmente
integrado com o kit **bk-tools** do 3BLinux.
