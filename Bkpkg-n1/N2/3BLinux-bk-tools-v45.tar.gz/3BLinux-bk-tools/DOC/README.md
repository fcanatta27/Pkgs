# 3BLinux - bk-tools

Este repositório contém um conjunto mínimo de ferramentas de empacotamento e
construção para o projeto **3BLinux**. O objetivo é permitir que você:

- construa pacotes (por exemplo, `gcc-bootstrap-15.2.0`) em diretórios
  temporários em `/tmp`;
- empacote o resultado em um arquivo `.tar.gz`;
- instale o pacote em um *3BLinux* isolado (por padrão `./3BLinux/`);
- registre arquivos instalados para permitir `uninstall` depois;
- mantenha o `/` real e, principalmente, `/etc` protegidos por padrão.

## Estrutura de diretórios

```text
3BLinux-bk-tools/
  bin/
    bk          # gerenciador de pacotes simples
    bk-cli      # front-end para build + package + install
  packages/
    gcc-bootstrap-15.2.0/
      build.sh  # script de construção do GCC
  3BLinux/       # 3BLinux "final" (raiz de instalação padrão)
  DOC/
    README.md   # este arquivo
```

### `3BLinux/`

O diretório `3BLinux/` representa o sistema de arquivos final (a raiz do seu
3BLinux). Por padrão, o `bk` instala tudo sob este diretório, sem tocar no
`/` real da máquina onde você está trabalhando.

Se, conscientemente, você quiser instalar em `/`, é possível, mas exige
configuração explícita (ver seção de segurança).

## bk-tools

O conjunto de ferramentas é composto principalmente por:

- `bin/bk` – o gerenciador de pacotes minimalista;
- `bin/bk-cli` – uma interface de linha de comando para acionar scripts de
  build em `packages/` e chamar o `bk`.

### `bk` (empacotador/instalador)

O `bk` trabalha com três conceitos:

1. **Diretório de build**: árvore de arquivos já instalados em algum
   prefixo temporário (por exemplo, `/tmp/3blinux-build-gcc-bootstrap-15.2.0`).
2. **Arquivo de pacote**: um `tar.gz` gerado a partir do diretório de build,
   geralmente armazenado em `packages/`.
3. **Raiz de instalação (BK_ROOT)**: local onde o pacote será efetivamente
   instalado (por padrão `./3BLinux`).

#### Comandos

- `bk package <nome> <versao> <dir_build>`

  Cria o arquivo de pacote `packages/<nome>-<versao>.tar.gz` a partir do
  diretório `<dir_build>`.

- `bk install <arquivo.tar.gz> [--root DIR]`

  Extrai o pacote para `BK_ROOT` (ou `DIR` se especificado) e registra a
  lista de arquivos instalados em:

  ```text
  <BK_ROOT>/var/lib/bk/<nome>-<versao>.files
  <BK_ROOT>/var/lib/bk/installed.list
  ```

- `bk uninstall <nome-versao>`

  Usa a lista de arquivos registrada para remover o pacote do `BK_ROOT`.
  Quando `BK_ROOT="/"`, há proteção extra para arquivos sob `/etc` (não são
  removidos automaticamente).

- `bk list`

  Lista todos os pacotes registrados como instalados no `BK_ROOT` atual.

- `bk info <nome-versao>`

  Mostra informações resumidas e a lista de arquivos associados ao pacote.

#### Variáveis de ambiente

- `BK_ROOT`  
  Raiz de instalação. Padrão: `./3BLinux` (baseado no diretório do
  repositório).

- `BK_ALLOW_REAL_ROOT`  
  Se definido como `1` e `BK_ROOT="/"`, permite operar diretamente sobre o
  sistema real. Sem esta variável, o `bk` aborta quando detecta
  `BK_ROOT="/"`.

- `BK_PACKAGES_DIR`  
  Diretório onde os pacotes `.tar.gz` são criados/buscados. Padrão:
  `./packages`.

### `bk-cli` (front-end)

O `bk-cli` implementa um fluxo padrão:

1. Recebe um identificador de pacote no formato `nome-versao`
   (ex.: `gcc-bootstrap-15.2.0`).
2. Localiza o diretório `packages/nome-versao/`.
3. Cria um diretório de build em `/tmp/3blinux-build-nome-versao`.
4. Exporta variáveis de ambiente para o `build.sh`:
   - `BK_PKG_NAME`
   - `BK_PKG_VERSION`
   - `BK_BUILD_ROOT`
5. Executa `packages/nome-versao/build.sh`.
6. Chama:
   - `bk package <nome> <versao> <BK_BUILD_ROOT>`
   - `bk install packages/<nome>-<versao>.tar.gz` (a não ser que seja passado
     `--no-install`).

Uso básico:

```sh
# empacota e instala no 3BLinux local
./bin/bk-cli gcc-bootstrap-15.2.0

# empacota sem instalar
./bin/bk-cli gcc-bootstrap-15.2.0 --no-install

# instala no 3BLinux/ mas chamando explicitamente
BK_ROOT="$PWD/3BLinux" ./bin/bk-cli gcc-bootstrap-15.2.0
```

## packages/gcc-bootstrap-15.2.0/build.sh

O script `build.sh` contido em `packages/gcc-bootstrap-15.2.0/` é um exemplo
de construção completa que:

- baixa o tarball do GCC usando uma URL padrão baseada em
  `BK_PKG_VERSION`;
- extrai as fontes em `/tmp/src-gcc-<versao>`;
- configura um diretório de build em `/tmp/build-gcc-<versao>`;
- executa `configure`, `make` e `make install` com
  `DESTDIR="${BK_BUILD_ROOT}"`.

Ele depende de ferramentas comuns como `wget`, `tar`, `make` e de um
toolchain mínimo já disponível no sistema hospedeiro.

Você pode adaptá-lo para outras versões do GCC ou para outros pacotes,
copiando o diretório e ajustando:

- `SRC_URL`
- opções de `configure`
- qualquer passo extra necessário (patches, etc.).

## Segurança e proteção de `/` e `/etc`

Por padrão, o `bk` trabalha com `BK_ROOT` apontando para `./3BLinux`. Isso
significa que:

- nenhuma alteração é feita no `/` real;
- você pode montar ou chrootar em `3BLinux/` para testar seu sistema.

Para operar diretamente sobre o `/` real:

```sh
export BK_ROOT=/
export BK_ALLOW_REAL_ROOT=1
bk install packages/meu-pacote-1.0.tar.gz
```

Mesmo nesse modo:

- o `bk uninstall` **não** remove arquivos sob `/etc` automaticamente,
  emitindo apenas avisos (de forma a proteger configurações críticas);
- há checagens simples para evitar operações perigosas sobre `/`.

Recomenda-se fortemente:

- testar sempre primeiro com o `3BLinux/` local;
- manter backups antes de qualquer instalação em `/`;
- revisar os scripts de build e os arquivos de pacote gerados.

## Fluxo típico de uso

1. Clonar ou copiar este repositório.
2. Garantir que `bin/bk` e `bin/bk-cli` sejam executáveis:

   ```sh
   chmod +x bin/bk bin/bk-cli
   chmod +x packages/gcc-bootstrap-15.2.0/build.sh
   ```

3. Construir e instalar o GCC bootstrap no `3BLinux/`:

   ```sh
   ./bin/bk-cli gcc-bootstrap-15.2.0
   ```

4. Verificar pacotes instalados:

   ```sh
   ./bin/bk list
   ```

5. Desinstalar o pacote, se necessário:

   ```sh
   ./bin/bk uninstall gcc-bootstrap-15.2.0
   ```

6. Reutilizar a infraestrutura de `packages/` para outros softwares,
   criando novos diretórios `packages/<nome>-<versao>/` com seus próprios
   `build.sh`.

## Sobre o projeto 3BLinux

O 3BLinux, neste contexto, é um sistema construído de forma incremental,
usando um 3BLinux controlado e um conjunto de ferramentas simples (bk-tools)
para empacotamento e instalação. A ideia é:

- manter o controle explícito de tudo que entra no sistema;
- facilitar a reprodução do ambiente;
- permitir que o 3BLinux final possa ser usado como base para um sistema
  mais completo (por exemplo, em máquinas físicas, VMs ou containers).

Sinta-se à vontade para expandir este conjunto de ferramentas, adicionando:

- novos comandos ao `bk` (ex.: verificação de integridade, re-instalação);
- suporte a outros formatos de compressão;
- scripts de build para bibliotecas e utilitários de base;
- documentação adicional em `DOC/` (tutoriais, guias de portabilidade, etc.).
## Atualizações recentes

- O script `build.sh` do `gcc-bootstrap-15.2.0` agora instala o GCC em
  **/var/3bLinux** dentro do `DESTDIR` (ou seja, após empacotar/instalar,
  os binários ficam em `/var/3bLinux/bin` dentro do 3BLinux alvo).
- O `bk-cli` foi estendido com:
  - subcomandos `build`, `package` e `install`;
  - opção `--jobs N` (passada para o make via `BK_JOBS`);
  - opção `--keep-build` para manter o diretório de build em `/tmp`;
  - melhor validação de argumentos e mensagens de log.
- O `bk` recebeu melhorias de robustez:
  - normalização de caminhos vindos do tar;
  - proteção explícita contra caminhos absolutos e com `..`;
  - proteção reforçada para `/etc` quando `BK_ROOT="/"`;
  - empacotamento mais previsível a partir de diretórios de build.
- Foi adicionado o script `bin/bk-chroot`, que:
  - prepara um chroot baseado no `BK_ROOT` (por padrão `./3BLinux`);
  - monta `/dev`, `/dev/pts`, `/proc`, `/sys`, `/run` e `/tmp` (se existirem);
  - fornece:
    - `bk-chroot enter` para abrir uma shell dentro do chroot;
    - `bk-chroot run <cmd>` para executar um comando e voltar;
  - é idempotente na montagem (não tenta montar duas vezes o mesmo ponto);
  - permite rodar comandos do `bk` dentro do chroot sem permanecer nele.

Essas ferramentas compõem um pequeno *toolchain* de construção/empacotamento
e gerenciamento de chroot para o 3BLinux, permitindo que você evolua seu
sistema de forma controlada, reproduzível e segura.

## Pacotes adicionais e builds (v3)

Foram adicionados scripts de build reais em `packages/`:

- `binutils-2.45.1-pass1/`
- `gcc-15.2.0-pass1/`
- `kernel-headers-6.18.2/`
- `glibc-2.42/`
- `bk-tools-2.0.0/` (empacota o próprio conjunto bk-tools para instalação no 3BLinux)

### bk-tools como pacote

Para instalar as ferramentas dentro do 3BLinux (ex.: para usar no chroot):

```sh
./bin/bk-cli bk-tools-2.0.0
```

Isso instala `bk`, `bk-cli`, `bk-chroot` e `bk-reparo` em:

```text
/var/3bLinux/bin/
```

### bk-reparo

O `bk-reparo` executa uma verificação e reparo idempotente no `BK_ROOT`:

- garante diretórios essenciais;
- valida e corrige a base de dados do `bk` (stale entries);
- cria `/etc/profile.d/3blinux-path.sh` para colocar `/var/3bLinux/bin` no PATH;
- checa presença do toolchain básico e (opcionalmente) tenta reinstalar pacotes.

Exemplos:

```sh
./bin/bk-reparo --check-only
./bin/bk-reparo --reinstall-missing
```

### bk-chroot presets

O `bk-chroot` agora possui presets:

- `minimal`, `dev` (padrão) e `full`
- `full` tenta bind-mount de `/home` e `/var/3bLinux` do host, quando existirem.

Exemplo:

```sh
./bin/bk-chroot --preset full enter
./bin/bk-chroot --preset dev run bk list
```


## Guias adicionais

- `INSTALL_GUIDE.md` – ISO/QEMU/instalação
- `PREPARE_BUILD_FROM_ZERO.md` – preparação e construção do zero


## Índice de documentação

- `PREPARE_BUILD_FROM_ZERO.md` – preparar host e rootfs, rodar stage-system.
- `INSTALL_GUIDE.md` – initramfs, ISO, QEMU, instalação em disco.
- `BOOT_GUIDE.md` – detalhes de boot, kernel, GRUB.
- `INIT_AND_SERVICES.md` – init, serviços, perfis em /etc/sysconfig/rc.
- `UPDATES_AND_REPO.md` – upstream, repositórios, bk-update.
- `ADMIN_AND_MAINTENANCE.md` – visão geral de administração e manutenção.


---

## Fluxo completo com o kit bk-tools (do zero ao desktop + manutenção)

Esta é uma visão de alto nível de como usar o kit do começo ao fim:

1. **Preparar o host e o rootfs**
   - Leia `DOC/PREPARE_BUILD_FROM_ZERO.md`.
   - Prepare as ferramentas do host (gcc, make, meson, ninja, etc.).
   - Crie o diretório `./3BLinux` que será o rootfs final.
   - Ajuste permissões e arquivos mínimos em `3BLinux/etc`.

2. **Criar a cross-toolchain e temporary tools**
   - Use `bk-cli` + os scripts de construção de:
     - `binutils-2.45.1-pass1`
     - `gcc-15.2.0-pass1`
     - `linux-headers-6.18.2`
     - `glibc-2.42` (startfiles + headers)
   - Esta fase gera a toolchain cross/temporary no rootfs isolado, sem poluir o host.

3. **Montar o userland base + toolchain de desenvolvimento**
   - Use `bin/bk-cli-stage-base` para construir o conjunto base.
   - Use `bin/bk-cli-stage-system` para completar o userland + toolchain (compiladores, make, autotools, etc.).
   - No final desta etapa o rootfs `3BLinux` tem um sistema de usuário completo em modo texto.

4. **Montar o stack gráfico (Xorg + desktop)**
   - Use `bin/bk-cli-stage-xorg` para montar todo o Xorg.
   - Use um dos workflows:
     - `bin/bk-cli-stage-desktop-min` → base + Xorg + startx + twm.
     - `bin/bk-cli-stage-desktop-full` → base + Xorg + serviços de desktop (dbus, polkit, elogind, NetworkManager, PipeWire).
     - `bin/bk-cli-stage-desktop-xfce` → XFCE completo pronto para uso.

5. **Aplicar o perfil de notebook (stage-laptop)**
   - Use `bin/bk-cli-stage-laptop` para:
     - instalar acpid, pm-utils, sysstat, udisks2, bluez;
     - ativar serviços relevantes em `/etc/sysconfig/rc`;
     - aplicar ajustes de energia com `bk-power-profile laptop`;
     - garantir ACPI, teclas Fn, suspensão e touchpad ajustados.

6. **Gerar initramfs e ISO de boot**
   - Gere um initramfs com `bin/bk-initramfs` (BusyBox + init customizado).
   - Gere uma ISO bootável com `bin/bk-mkiso`.
   - Use `bin/bk-qemu` para testar rapidamente o boot em QEMU.

7. **Instalar em disco com bk-install**
   - Inicialize pela ISO.
   - No ambiente live, rode `bin/bk-install` para:
     - particionar discos;
     - montar o destino;
     - copiar o rootfs;
     - instalar kernel, initramfs e GRUB;
     - criar usuário(s) com `bk-adduser`.

8. **Manutenção após o primeiro login**
   - Use:
     - `bk-reparo` / `bk-init-reparo` → reparos gerais de sistema/init.
     - `bk-resolve` → sanity-check, correção de permissões, links, caches e serviços.
     - `bk-hardware-detect` → diagnóstico de Wi-Fi, GPU, ACPI, firmware.
     - `bk-power-profile` → ajustar rapidamente perfis de energia (laptop/desktop/performance).
     - `bk-repo-scan` / `bk-repo.txt` → manter o repositório de binários consistente.
     - `bk-upstream` / `bk-update` → acompanhar versões e releases (quando você ativar a parte de updates).

Para detalhes comando a comando, consulte os guias específicos em `DOC/`:
- `PREPARE_BUILD_FROM_ZERO.md`
- `INSTALL_GUIDE.md`
- `BOOT_GUIDE.md`
- `ADMIN_AND_MAINTENANCE.md`
