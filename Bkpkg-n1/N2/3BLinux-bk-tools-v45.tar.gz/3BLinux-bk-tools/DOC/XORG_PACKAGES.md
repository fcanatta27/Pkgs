# Pacotes Xorg adicionados (v28)

Os nomes foram padronizados para o bk e seguem o mesmo padrão `<BK_PKG_NAME>-<BK_PKG_VERSION>`.

Nota: os pacotes `xfonts-*` aqui representam subconjuntos típicos de fontes do Xorg, mapeados para tarballs
do repositório oficial da X.Org Foundation.

- xfonts-base -> font-misc-misc
- xfonts-75dpi -> font-bitstream-75dpi
- xfonts-100dpi -> font-bitstream-100dpi
- xfonts-scalable -> font-bitstream-type1
