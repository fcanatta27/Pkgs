
# 3BLinux – Guia Completo de Boot

Este documento descreve **passo a passo** como:
1. Montar o rootfs do 3BLinux
2. Construir o sistema base com bk-tools
3. Gerar um initramfs funcional
4. Configurar o GRUB
5. Testar tudo com QEMU

---

## 1. Estrutura do Projeto

- `3BLinux/` → **rootfs final do sistema**
- `bin/` → ferramentas bk (bk, bk-cli, bk-initramfs, etc.)
- `packages/` → scripts de construção
- `/var/3bLinux` → **cache de binários** (fora do rootfs)

Nunca construa nada diretamente dentro do rootfs.

---

## 2. Montando o Rootfs

```sh
export ROOTFS=$PWD/3BLinux
mkdir -p $ROOTFS
```

O rootfs já vem com:
- `/etc`
- `/init`
- `/sbin/init`
- scripts SysV (`/etc/init.d`)

---

## 3. Construindo o Sistema Base

Use o orquestrador:

```sh
bin/bk-cli-stage-system
```

Isso executa:
- stage-base
- bibliotecas essenciais
- rede, syslog, cronie, SSL
- ferramentas de desenvolvimento

Tudo é instalado em `$ROOTFS` via `DESTDIR`.

---

## 4. Gerando o Initramfs

```sh
bin/bk-initramfs   --rootfs $ROOTFS   --output initramfs.img
```

O initramfs inclui:
- BusyBox estático
- /init funcional
- suporte a devtmpfs, proc, sysfs

---

## 5. Kernel

Compile o kernel normalmente e gere:

```sh
arch/x86/boot/bzImage
```

---

## 6. Configurando o GRUB

### Estrutura esperada:

```text
/boot
 ├── vmlinuz-6.18.2
 ├── initramfs.img
 └── grub/grub.cfg
```

### Exemplo `grub.cfg`:

```cfg
set timeout=5
set default=0

menuentry "3BLinux" {
  linux /boot/vmlinuz-6.18.2 root=/dev/sda1 rw
  initrd /boot/initramfs.img
}
```

Instalação:

```sh
grub-install /dev/sdX
grub-mkconfig -o /boot/grub/grub.cfg
```

---

## 7. Testando com QEMU

```sh
qemu-system-x86_64   -m 2048   -kernel vmlinuz-6.18.2   -initrd initramfs.img   -append "console=ttyS0 root=/dev/ram0 rw"   -nographic
```

Ou com disco:

```sh
qemu-system-x86_64   -m 2048   -drive file=rootfs.img,format=raw   -kernel vmlinuz-6.18.2   -append "root=/dev/sda rw"   -nographic
```

---

## 8. Debug

- Use `init=/bin/sh` no kernel cmdline
- Verifique logs em `/var/log`
- `dmesg` e `mount` são seus aliados

---

## 9. Filosofia

3BLinux é:
- determinístico
- isolado do host
- totalmente reconstruível
- sem ferramentas mágicas

Tudo é shell.
