# Exemplo de layout de repositório 3BLinux (binários para bk)

Este diretório `repo-example/3blinux-repo` ilustra como organizar um repositório
de binários para o `bk-update`.

Estrutura sugerida no servidor:

/var/www/3blinux-repo/
  stable/
    bk-repo.txt
    <pacotes>.tar.gz
  unstable/
    bk-repo.txt
    <pacotes>.tar.gz

Neste projeto, você encontra um exemplo em:

- `repo-example/3blinux-repo/stable/bk-repo.txt`
- `repo-example/3blinux-repo/unstable/bk-repo.txt`

Os arquivos de manifesto (`bk-repo.txt`) foram gerados automaticamente a partir dos
scripts de construção (`packages/*/build.sh`), assumindo o padrão de nome de
arquivo:

  <BK_PKG_NAME>-<BK_PKG_VERSION>.tar.gz

Para colocar em produção:

1. Copie o conteúdo de `repo-example/3blinux-repo/stable` para o servidor, por exemplo:

   ```sh
   rsync -av repo-example/3blinux-repo/stable/ user@host:/var/www/3blinux-repo/stable/
   rsync -av repo-example/3blinux-repo/unstable/ user@host:/var/www/3blinux-repo/unstable/
   ```

2. Gere os pacotes `.tar.gz` com `bk` (um por programa) usando o mesmo padrão de nome
   e envie-os para os diretórios correspondentes.

3. No cliente, aponte o `bk-update` para o repo desejado, por exemplo:

   ```sh
   bk-update --repo https://seu-host/3blinux-repo/stable --root /
   ```
