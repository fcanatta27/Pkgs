#!/bin/sh
# Ação ACPI para botão de energia no 3BLinux
# - Solicita shutdown limpo via /sbin/shutdown

LOGGER="logger -t acpid-powerbtn"
$LOGGER "power button pressed: shutting down"
if command -v shutdown >/dev/null 2>&1; then
  shutdown -h now
else
  /sbin/poweroff 2>/dev/null || /bin/poweroff 2>/dev/null || halt
fi
