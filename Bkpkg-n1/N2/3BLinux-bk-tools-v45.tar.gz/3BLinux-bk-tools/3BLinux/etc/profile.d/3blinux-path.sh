# /etc/profile.d/3blinux-path.sh
# Mantém um PATH razoável caso /etc/profile não seja executado
case ":$PATH:" in
  *":/usr/local/sbin:"* ) ;;
  *) PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH" ;;
esac
export PATH
