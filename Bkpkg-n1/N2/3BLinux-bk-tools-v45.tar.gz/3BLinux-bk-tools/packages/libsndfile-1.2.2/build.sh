#!/usr/bin/env bash
#
# Dependencias (comentado)
#   - Build: bash, coreutils, gcc, make, tar, xz
#   - Runtime: none
#
set -Eeuo pipefail

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

TMPDIR=${TMPDIR:-/tmp}
JOBS=${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}

SRC_URL='https://github.com/libsndfile/libsndfile/releases/download/1.2.2/libsndfile-1.2.2.tar.xz'
TARBALL='libsndfile-1.2.2.tar.xz'
SRCDIR='libsndfile-1.2.2'

req(){ command -v "libsndfile" >/dev/null 2>&1 || { echo "libsndfile: falta comando: libsndfile" >&2; exit 1; }; }
msg(){ echo "[libsndfile] libsndfile 1.2.2 https://github.com/libsndfile/libsndfile/releases/download/1.2.2/libsndfile-1.2.2.tar.xz libsndfile-1.2.2.tar.xz libsndfile-1.2.2 bash, coreutils, gcc, make, tar, xz none " >&2; }

fetch(){
  local out="${TMPDIR}/${TARBALL}"
  if [[ -f "${out}" ]]; then msg "usando cache ${out}"; return 0; fi
  msg "baixando ${SRC_URL}"
  if command -v curl >/dev/null 2>&1; then curl -L --fail -o "${out}" "${SRC_URL}"; else wget -O "${out}" "${SRC_URL}"; fi
}

unpack(){
  rm -rf "${TMPDIR}/build-src-libsndfile-${BK_PKG_VERSION}"
  mkdir -p "${TMPDIR}/build-src-libsndfile-${BK_PKG_VERSION}"
  tar -C "${TMPDIR}/build-src-libsndfile-${BK_PKG_VERSION}" -xf "${TMPDIR}/${TARBALL}"
}

main(){
  for t in tar make gcc; do req ""; done
  req sh
  fetch
  unpack
  local top="${TMPDIR}/build-src-libsndfile-${BK_PKG_VERSION}"
  local src="${top}/${SRCDIR}"
  if [[ ! -d "${src}" ]]; then src="$(find "${top}" -maxdepth 2 -type d -name "${SRCDIR}" | head -n1 || true)"; fi
  [[ -d "${src}" ]] || { echo "libsndfile: fontes nao encontradas em ${src}" >&2; exit 1; }

  rm -rf "${BK_BUILD_ROOT:?}"/*
  mkdir -p "${BK_BUILD_ROOT}"

  msg "configurando..."
  ( cd "${src}" && ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --disable-static  )

  msg "compilando..."
  ( cd "${src}" && make -j"${JOBS}" )

  msg "instalando (DESTDIR)..."
  ( cd "${src}" && make DESTDIR="${BK_BUILD_ROOT}" install )

  msg "ok"
}

main "libsndfile 1.2.2 https://github.com/libsndfile/libsndfile/releases/download/1.2.2/libsndfile-1.2.2.tar.xz libsndfile-1.2.2.tar.xz libsndfile-1.2.2 bash, coreutils, gcc, make, tar, xz none "
