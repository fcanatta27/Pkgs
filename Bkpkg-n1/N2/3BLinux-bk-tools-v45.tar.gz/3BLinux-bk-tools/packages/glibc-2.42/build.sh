#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, make, gcc (cross/target), g++, binutils, wget, tar, xz
#   - Build: bison, gawk, sed, perl, python3 (alguns alvos/hosts), texinfo (docs, opcional)
#   - Prereq: Linux API headers instalados em SYSROOT/usr/include
#
# build.sh - glibc-2.42 (instala em SYSROOT/usr)
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _BK_BOLD="\033[1m"; _BK_RED="\033[31m"; _BK_GRN="\033[32m"; _BK_YEL="\033[33m"; _BK_BLU="\033[34m"; _BK_RST="\033[0m"
else
  _BK_BOLD=""; _BK_RED=""; _BK_GRN=""; _BK_YEL=""; _BK_BLU=""; _BK_RST=""
fi
_bk_info() { echo -e "glibc: ${_BK_BOLD}${_BK_BLU}$*${_BK_RST}" >&2; }
_bk_ok()   { echo -e "glibc: ${_BK_BOLD}${_BK_GRN}$*${_BK_RST}" >&2; }
_bk_warn() { echo -e "glibc: ${_BK_BOLD}${_BK_YEL}$*${_BK_RST}" >&2; }
_bk_err()  { echo -e "glibc: ${_BK_BOLD}${_BK_RED}$*${_BK_RST}" >&2; }

_die(){ _bk_err "$*"; exit 1; }
_require_cmd(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
MAKE_JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"
TARGET="${BK_TARGET:-$(uname -m)-3blinux-linux-gnu}"
SYSROOT="${BK_SYSROOT:-${BK_BUILD_ROOT}}"

_require_cmd wget
_require_cmd tar
_require_cmd make

SRC_URL="${SRC_URL:-https://ftp.gnu.org/gnu/glibc/glibc-${BK_PKG_VERSION}.tar.xz}"
SRC_TARBALL="${TMPDIR}/glibc-${BK_PKG_VERSION}.tar.xz"
SRC_DIR="${TMPDIR}/src-glibc-${BK_PKG_VERSION}"
BUILD_DIR="${TMPDIR}/build-glibc-${BK_PKG_VERSION}"

_bk_info "Construindo glibc: ${BK_PKG_NAME}-${BK_PKG_VERSION}"
_bk_info "TARGET=${TARGET} SYSROOT=${SYSROOT}"
_bk_info "DESTDIR=${SYSROOT} JOBS=${MAKE_JOBS}"

if [[ ! -d "${SYSROOT}/usr/include/linux" ]]; then
  _bk_warn "Headers do kernel não encontrados em ${SYSROOT}/usr/include/linux"
  _bk_warn "Instale kernel-headers antes para um sistema real."
fi

mkdir -p -- "${SYSROOT}" "${SRC_DIR}" "${BUILD_DIR}"

if [[ ! -f "${SRC_TARBALL}" ]]; then
  _bk_info "Baixando: ${SRC_URL}"
  wget -O "${SRC_TARBALL}" "${SRC_URL}"
else
  _bk_info "Usando tarball cacheado: ${SRC_TARBALL}"
fi

_bk_info "Extraindo fontes..."
rm -rf -- "${SRC_DIR}"
mkdir -p -- "${SRC_DIR}"
tar -C "${SRC_DIR}" -xf "${SRC_TARBALL}"

src_subdir="${SRC_DIR}/glibc-${BK_PKG_VERSION}"
[[ -d "${src_subdir}" ]] || _die "fontes não encontradas: ${src_subdir}"

rm -rf -- "${BUILD_DIR}"
mkdir -p -- "${BUILD_DIR}"
cd "${BUILD_DIR}"

BUILD_TRIPLET="$("${src_subdir}/scripts/config.guess")"

export PATH="${SYSROOT}/usr/bin:${PATH}"
export CC="${TARGET}-gcc"
export CXX="${TARGET}-g++"
export AR="${TARGET}-ar"
export RANLIB="${TARGET}-ranlib"

_bk_info "Configurando..."
"${src_subdir}/configure" \
  --prefix=/usr \
  --host="${TARGET}" \
  --build="${BUILD_TRIPLET}" \
  --with-headers="${SYSROOT}/usr/include" \
  --disable-werror

_bk_info "Compilando..."
make -j"${MAKE_JOBS}"

_bk_info "Instalando (DESTDIR=sysroot)..."
make DESTDIR="${SYSROOT}" install

_bk_ok "Concluído: glibc em ${SYSROOT}/usr"
