#!/usr/bin/env bash
#
# Dependencias (comentado)
#   - Build: bash, coreutils, gcc, make, tar, bzip2
#   - Runtime: none
#
set -Eeuo pipefail

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

TMPDIR=${TMPDIR:-/tmp}
JOBS=${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}

SRC_URL='https://netfilter.org/projects/libmnl/files/libmnl-1.0.5.tar.bz2'
TARBALL='libmnl-1.0.5.tar.bz2'
SRCDIR='libmnl-1.0.5'

req(){ command -v "libmnl" >/dev/null 2>&1 || { echo "libmnl: falta comando: libmnl" >&2; exit 1; }; }
msg(){ echo "[libmnl] libmnl 1.0.5 https://netfilter.org/projects/libmnl/files/libmnl-1.0.5.tar.bz2 libmnl-1.0.5.tar.bz2 libmnl-1.0.5 bash, coreutils, gcc, make, tar, bzip2 none " >&2; }

fetch(){
  local out="${TMPDIR}/${TARBALL}"
  if [[ -f "${out}" ]]; then msg "usando cache ${out}"; return 0; fi
  msg "baixando ${SRC_URL}"
  if command -v curl >/dev/null 2>&1; then curl -L --fail -o "${out}" "${SRC_URL}"; else wget -O "${out}" "${SRC_URL}"; fi
}

unpack(){
  rm -rf "${TMPDIR}/build-src-libmnl-${BK_PKG_VERSION}"
  mkdir -p "${TMPDIR}/build-src-libmnl-${BK_PKG_VERSION}"
  tar -C "${TMPDIR}/build-src-libmnl-${BK_PKG_VERSION}" -xf "${TMPDIR}/${TARBALL}"
}

main(){
  for t in tar make gcc; do req ""; done
  req sh
  fetch
  unpack
  local top="${TMPDIR}/build-src-libmnl-${BK_PKG_VERSION}"
  local src="${top}/${SRCDIR}"
  if [[ ! -d "${src}" ]]; then src="$(find "${top}" -maxdepth 2 -type d -name "${SRCDIR}" | head -n1 || true)"; fi
  [[ -d "${src}" ]] || { echo "libmnl: fontes nao encontradas em ${src}" >&2; exit 1; }

  rm -rf "${BK_BUILD_ROOT:?}"/*
  mkdir -p "${BK_BUILD_ROOT}"

  msg "configurando..."
  ( cd "${src}" && ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --disable-static  )

  msg "compilando..."
  ( cd "${src}" && make -j"${JOBS}" )

  msg "instalando (DESTDIR)..."
  ( cd "${src}" && make DESTDIR="${BK_BUILD_ROOT}" install )

  msg "ok"
}

main "libmnl 1.0.5 https://netfilter.org/projects/libmnl/files/libmnl-1.0.5.tar.bz2 libmnl-1.0.5.tar.bz2 libmnl-1.0.5 bash, coreutils, gcc, make, tar, bzip2 none "
