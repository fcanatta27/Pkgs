#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, make, pkg-config, xorg-server
#   - Runtime: xorg-server
#
# Padrão bk-tools:
#   Requer: BK_PKG_NAME, BK_PKG_VERSION, BK_BUILD_ROOT
#   Constrói em /tmp e instala via DESTDIR em BK_BUILD_ROOT
#
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z="";
fi
_i(){ echo -e "xf86-input-evdev: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "xf86-input-evdev: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "xf86-input-evdev: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "xf86-input-evdev: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

SRC_URL="https://www.x.org/releases/individual/driver/xf86-input-evdev-2.10.6.tar.xz"
TARBALL="xf86-input-evdev-2.10.6.tar.xz"
SRCDIR="xf86-input-evdev-2.10.6"

_need_tools() {
  for t in sh tar wget make gcc; do
    _req "$t"
  done
}

_fetch() {
  local out="${TMPDIR}/${TARBALL}"
  if [[ -f "${out}" ]]; then
    _i "usando cache: ${out}"
    return 0
  fi
  _i "baixando: ${SRC_URL}"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail -o "${out}" "${SRC_URL}"
  else
    wget -O "${out}" "${SRC_URL}"
  fi
}

_unpack() {
  local out="${TMPDIR}/${TARBALL}"
  rm -rf -- "${TMPDIR}/xf86-input-evdev-2.10.6"
  _i "extraindo: ${out}"
  tar -C "${TMPDIR}" -xf "${out}"
}

main() {
  _need_tools
  _fetch
  _unpack
  local src="${TMPDIR}/xf86-input-evdev-2.10.6"
  if [[ ! -d "${src}" ]]; then
    src="$(find "${TMPDIR}" -maxdepth 2 -type d -name "xf86-input-evdev-2.10.6" -o -mindepth 1 -maxdepth 1 -type d | head -n1 || true)"
  fi
  [[ -d "${src}" ]] || _die "fontes não encontradas: ${src}"

  rm -rf -- "${BK_BUILD_ROOT:?}/"*
  mkdir -p -- "${BK_BUILD_ROOT}"

  _i "configurando (autotools)..."
  ( cd "${src}" && ./configure \
      --prefix=/usr \
      --sysconfdir=/etc \
      --localstatedir=/var \
      --disable-static \
  )

  _i "compilando..."
  ( cd "${src}" && make -j"${JOBS}" )

  _i "instalando em DESTDIR..."
  ( cd "${src}" && make DESTDIR="${BK_BUILD_ROOT}" install )

  _o "Concluído: ${BK_PKG_NAME} ${BK_PKG_VERSION} instalado em ${BK_BUILD_ROOT}"
}

main "$@"
