#!/usr/bin/env bash
# build.sh – firefox 147.0
#
# Pacote: firefox
# Versão: 147.0
# Descrição: Firefox (build a partir do source tarball).
# Fonte: https://ftp.mozilla.org/pub/firefox/releases/147.0/source/firefox-147.0.source.tar.xz
#
# Dependências (comentadas):
#   - python3 (>=3.10) + pip
#   - rust + cargo (compatível com a versão do Firefox)
#   - clang/llvm + lld (recomendado) OU gcc (menos comum)
#   - nodejs (para alguns fluxos/geração)
#   - nasm/yasm
#   - gtk3/gtk4 + mesa + dbus + pulseaudio/pipewire (dependendo da config)
#   - libffi, zlib, bzip2, xz, zstd, icu, sqlite, nss/nspr (normalmente vendorizado no tarball)
#
# Observações:
#   - Este script segue o padrão bk-tools: compila em /tmp e instala em DESTDIR.
#   - Espera as variáveis BK_* do bk (ou usa defaults seguros).
#
set -Eeuo pipefail

# --- UI (cores/bold) ---
if [[ -t 2 ]]; then
  B="\033[1m"; R="\033[31m"; G="\033[32m"; Y="\033[33m"; U="\033[34m"; Z="\033[0m"
else
  B=""; R=""; G=""; Y=""; U=""; Z=""
fi
_i(){ echo -e "build: ${B}${U}$*${Z}" >&2; }
_o(){ echo -e "build: ${B}${G}$*${Z}" >&2; }
_w(){ echo -e "build: ${B}${Y}$*${Z}" >&2; }
_e(){ echo -e "build: ${B}${R}$*${Z}" >&2; }
_die(){ _e "$*"; exit 1; }

BK_PKG_NAME="${BK_PKG_NAME:-}"
BK_PKG_VERSION="${BK_PKG_VERSION:-}"
BK_SRC_URL="${BK_SRC_URL:-}"
BK_WORKDIR="${BK_WORKDIR:-/tmp/bk-build}"
BK_DESTDIR="${BK_DESTDIR:-/tmp/bk-dest}"
BK_ROOT="${BK_ROOT:-/}"         # rootfs alvo (para bk)
BK_JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

mkdir -p "$BK_WORKDIR" "$BK_DESTDIR"

_fetch_unpack() {
  local url="$1"
  local out="$2"
  command -v curl >/dev/null 2>&1 || _die "curl não encontrado"
  command -v tar >/dev/null 2>&1 || _die "tar não encontrado"
  mkdir -p "$BK_WORKDIR/src"
  local fn="${out:-$(basename "$url")}"
  local dl="$BK_WORKDIR/src/$fn"
  if [[ ! -f "$dl" ]]; then
    _i "baixando: $url"
    curl -L --fail -o "$dl" "$url"
  else
    _i "usando cache: $dl"
  fi
  _i "extraindo: $dl"
  tar -xf "$dl" -C "$BK_WORKDIR"
}

_enter_srcdir() {
  local pattern="$1"
  local d
  d="$(find "$BK_WORKDIR" -maxdepth 1 -type d -name "$pattern" | head -n1 || true)"
  [[ -n "$d" ]] || _die "srcdir não encontrado (pattern=$pattern) em $BK_WORKDIR"
  cd "$d"
}

_make_destdirs() {
  mkdir -p "$BK_DESTDIR"/{usr/bin,usr/sbin,usr/lib,usr/share,usr/include,etc,var}
}

_autotools_build() {
  local cfg_args=("$@")
  _i "configure: ${cfg_args[*]}"
  ./configure "${cfg_args[@]}"
  _i "build (make -j$BK_JOBS)"
  make -j"$BK_JOBS"
  _i "install (DESTDIR=$BK_DESTDIR)"
  make DESTDIR="$BK_DESTDIR" install
}

_meson_build() {
  local meson_args=("$@")
  command -v meson >/dev/null 2>&1 || _die "meson não encontrado"
  command -v ninja >/dev/null 2>&1 || _die "ninja não encontrado"
  meson setup build "${meson_args[@]}"
  ninja -C build -j"$BK_JOBS"
  DESTDIR="$BK_DESTDIR" ninja -C build install
}

BK_PKG_NAME="${BK_PKG_NAME:-firefox}"
BK_PKG_VERSION="${BK_PKG_VERSION:-147.0}"
BK_SRC_URL="${BK_SRC_URL:-https://ftp.mozilla.org/pub/firefox/releases/147.0/source/firefox-147.0.source.tar.xz}"

main() {
  _make_destdirs
  _fetch_unpack "$BK_SRC_URL"
  _enter_srcdir "firefox-*"

  # Firefox build é pesado e sensível a toolchain.
  # Este script usa ./mach build + ./mach package e empacota o diretório dist/firefox.
  #
  # Dica: use ccache/sccache para acelerar.
  export MOZBUILD_STATE_PATH="${BK_WORKDIR}/mozbuild"
  export MOZ_OBJDIR="${BK_WORKDIR}/obj-${BK_PKG_NAME}"
  mkdir -p "$MOZ_OBJDIR" "$MOZBUILD_STATE_PATH"

  # mozconfig mínima (ajuste conforme desejar)
  cat > .mozconfig <<'EOF'
ac_add_options --prefix=/usr
ac_add_options --enable-release
ac_add_options --enable-application=browser
ac_add_options --disable-debug
ac_add_options --disable-tests

# Renderização / stack gráfico (ajuste):
# ac_add_options --enable-default-toolkit=cairo-gtk3
# ac_add_options --enable-default-toolkit=cairo-gtk3-wayland

# LTO/PGO (muito pesado; deixe comentado por padrão):
# ac_add_options --enable-lto
# ac_add_options --enable-profile-use
# ac_add_options --enable-profile-generate

# Use clang/lld (recomendado se você tem toolchain):
# export CC=clang
# export CXX=clang++
# export LD=lld

# caches:
mk_add_options MOZ_OBJDIR=@TOPSRCDIR@/../obj-firefox
EOF

  command -v python3 >/dev/null 2>&1 || _die "python3 não encontrado"
  command -v rustc >/dev/null 2>&1 || _w "rustc não encontrado (build provavelmente vai falhar)"
  command -v cargo >/dev/null 2>&1 || _w "cargo não encontrado (build provavelmente vai falhar)"

  _i "mach build (isso pode demorar bastante)"
  ./mach build

  _i "mach package"
  ./mach package

  # localizar dist/firefox
  local pkgdir=""
  pkgdir="$(find "$MOZ_OBJDIR" -maxdepth 3 -type d -name firefox -path "*/dist/*" | head -n1 || true)"
  [[ -n "$pkgdir" ]] || _die "dist/firefox não encontrado em MOZ_OBJDIR=$MOZ_OBJDIR"

  # instalar no rootfs (DESTDIR)
  mkdir -p "$BK_DESTDIR/usr/lib/firefox" "$BK_DESTDIR/usr/bin" "$BK_DESTDIR/usr/share/applications"
  cp -a "$pkgdir/." "$BK_DESTDIR/usr/lib/firefox/"

  cat > "$BK_DESTDIR/usr/bin/firefox" <<'EOF'
#!/bin/sh
exec /usr/lib/firefox/firefox "$@"
EOF
  chmod 0755 "$BK_DESTDIR/usr/bin/firefox"

  cat > "$BK_DESTDIR/usr/share/applications/firefox.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=Firefox
Exec=firefox %u
Icon=firefox
Categories=Network;WebBrowser;
Terminal=false
EOF

  _o "ok: ${BK_PKG_NAME}-${BK_PKG_VERSION}"
}
main "$@"
