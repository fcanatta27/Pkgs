#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, make, wget, tar, pkg-config, python3
#   - Deps: glib2, pango, atk, cairo, gdk-pixbuf, libX11 stack
#   - Runtime: libc
#
# Padrão bk-tools:
#   Requer: BK_PKG_NAME, BK_PKG_VERSION, BK_BUILD_ROOT
#   Constrói em /tmp e instala via DESTDIR em BK_BUILD_ROOT
#
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi

_i(){ echo -e "${_B}${_U}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_o(){ echo -e "${_B}${_G}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_w(){ echo -e "${_B}${_Y}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_e(){ echo -e "${_B}${_R}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

_req wget
_req tar
_req make

_dl(){
  local url="$1" out="$2"
  if [[ -f "$out" ]]; then
    _i "Usando tarball cacheado: $out"
    return 0
  fi
  _i "Baixando: $url"
  wget -O "$out" "$url"
}

_extract(){
  local tarball="$1" dest="$2"
  rm -rf -- "$dest"
  mkdir -p -- "$dest"
  tar -C "$dest" -xf "$tarball"
}


SRC_URL="${SRC_URL:-https://download.gnome.org/sources/gtk%2B/2.24/gtk+-2.24.33.tar.xz}"
TARBALL="${TMPDIR}/$(basename "${SRC_URL}")"
SRC_DIR="${TMPDIR}/src-${BK_PKG_NAME}-${BK_PKG_VERSION}"
BUILD_DIR="${TMPDIR}/build-${BK_PKG_NAME}-${BK_PKG_VERSION}"

_i "Construindo ${BK_PKG_NAME}-${BK_PKG_VERSION}"
_i "DESTDIR=${BK_BUILD_ROOT} JOBS=${JOBS}"

_dl "${SRC_URL}" "${TARBALL}"
_extract "${TARBALL}" "${SRC_DIR}"

src=""
if [[ "gtk+-2.24.33" != "" ]]; then
  src="${SRC_DIR}/gtk+-2.24.33"
fi
if [[ -z "${src}" || ! -d "${src}" ]]; then
  src="$(find "${SRC_DIR}" -mindepth 1 -maxdepth 1 -type d | head -n1 || true)"
fi
[[ -n "${src}" && -d "${src}" ]] || _die "fontes não encontradas em: ${SRC_DIR}"

rm -rf -- "${BUILD_DIR}"
mkdir -p -- "${BUILD_DIR}"

if [[ -f "${src}/meson.build" ]]; then
  _req meson
  _req ninja
  _req pkg-config
  _req python3

  _i "Configurando (meson)..."
  meson setup "${BUILD_DIR}" "${src}" \
    --prefix=/usr \
    --buildtype=release \
    -Ddefault_library=shared \
    

  _i "Compilando (ninja)..."
  ninja -C "${BUILD_DIR}" -j"${JOBS}"

  _i "Instalando em DESTDIR..."
  DESTDIR="${BK_BUILD_ROOT}" ninja -C "${BUILD_DIR}" install
else
  [[ -x "${src}/configure" ]] || _die "build system não reconhecido (sem meson.build e sem configure): ${src}"
  cd "${BUILD_DIR}"

  _i "Configurando..."
  "${src}/configure" \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static \
    --with-xinput=yes --enable-xkb

  _i "Compilando..."
  make -j"${JOBS}"

  _i "Instalando em DESTDIR..."
  make DESTDIR="${BK_BUILD_ROOT}" install
fi

_o "Concluído"
