#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, meson, ninja, cmake, pkg-config, gtk3, libsoup, libjpeg, libpng, libwebp, libseccomp
#   - Runtime: gtk3, libsoup, ca-certificates
#
# Padrão bk-tools:
#   Requer: BK_PKG_NAME, BK_PKG_VERSION, BK_BUILD_ROOT
#   Constrói em /tmp e instala via DESTDIR em BK_BUILD_ROOT
#
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z="";
fi
_i(){ echo -e "webkitgtk: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "webkitgtk: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "webkitgtk: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "webkitgtk: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

SRC_URL="https://webkitgtk.org/releases/webkitgtk-2.50.4.tar.xz"
TARBALL="webkitgtk-2.50.4.tar.xz"
SRCDIR="webkitgtk-2.50.4"

_need_tools() {
  for t in sh tar wget make gcc; do
    _req "$t"
  done
}

_fetch() {
  local out="${TMPDIR}/${TARBALL}"
  if [[ -f "${out}" ]]; then
    _i "usando tarball em cache: ${out}"
    return 0
  fi
  _i "baixando: ${SRC_URL}"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail -o "${out}" "${SRC_URL}"
  else
    _req wget
    wget -O "${out}" "${SRC_URL}"
  fi
}

_unpack() {
  local out="${TMPDIR}/${TARBALL}"
  rm -rf -- "${TMPDIR}/${SRCDIR}"
  _i "extraindo: ${out}"
  tar -C "${TMPDIR}" -xf "${out}"
}

main() {
  _need_tools
  _fetch
  _unpack
  local src="${TMPDIR}/${SRCDIR}"
  if [[ ! -d "${src}" ]]; then
    src="$(find "${TMPDIR}" -maxdepth 2 -type d -name "webkitgtk-2.50.4" -o -mindepth 1 -maxdepth 1 -type d | head -n1 || true)"
  fi
  [[ -d "${src}" ]] || _die "fontes não encontradas: ${src}"

  rm -rf -- "${BK_BUILD_ROOT:?}/"*
  mkdir -p -- "${BK_BUILD_ROOT}"

  local builddir="${TMPDIR}/build-${BK_PKG_NAME}-${BK_PKG_VERSION}"
  rm -rf -- "${builddir}"
  mkdir -p -- "${builddir}"

  _req meson
  _req ninja
  _req pkg-config

  _i "configurando (meson)..."
  meson setup "${builddir}" "${src}" \
    --prefix=/usr \
    --buildtype=release \
    --libdir=lib \
    --sysconfdir=/etc \
    --localstatedir=/var \
    -Dport=GTK -Denable-webgl=true -Denable-introspection=true -Denable-wayland-target=false

  _i "compilando (ninja)..."
  ninja -C "${builddir}" -j"${JOBS}"

  _i "instalando em DESTDIR..."
  DESTDIR="${BK_BUILD_ROOT}" ninja -C "${builddir}" install

  _o "Concluído: ${BK_PKG_NAME} ${BK_PKG_VERSION} instalado em ${BK_BUILD_ROOT}"
}

main "$@"
