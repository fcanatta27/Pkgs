#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, make, wget, tar
#   - Runtime: libc
#
# Padrão bk-tools:
#   Requer: BK_PKG_NAME, BK_PKG_VERSION, BK_BUILD_ROOT
#   Constrói em /tmp e instala via DESTDIR em BK_BUILD_ROOT
#
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi

_i(){ echo -e "${_B}${_U}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_o(){ echo -e "${_B}${_G}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_w(){ echo -e "${_B}${_Y}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_e(){ echo -e "${_B}${_R}${BK_PKG_NAME:-pkg}${_Z}: $*" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

_req wget
_req tar
_req make

_dl(){
  local url="$1" out="$2"
  if [[ -f "$out" ]]; then
    _i "Usando tarball cacheado: $out"
    return 0
  fi
  _i "Baixando: $url"
  wget -O "$out" "$url"
}

_extract(){
  local tarball="$1" dest="$2"
  rm -rf -- "$dest"
  mkdir -p -- "$dest"
  tar -C "$dest" -xf "$tarball"
}

# Dependências adicionais (comentado)
#   - Build/Runtime: python3 (com pip)
#
# Instala o módulo Python 'packaging' no prefixo /usr
# usando pip, com root em BK_BUILD_ROOT.

_req python3

if ! python3 -m pip --version >/dev/null 2>&1; then
  _die "pip não encontrado: instale python com ensurepip/pip antes de packaging"
fi

SRC_URL="${SRC_URL:-https://files.pythonhosted.org/packages/source/p/packaging/packaging-${BK_PKG_VERSION}.tar.gz}"
TARBALL="${TMPDIR}/packaging-${BK_PKG_VERSION}.tar.gz"
SRC_DIR="${TMPDIR}/src-packaging-${BK_PKG_VERSION}"

_i "Instalando packaging ${BK_PKG_VERSION} via pip"
_dl "${SRC_URL}" "${TARBALL}"
_extract "${TARBALL}" "${SRC_DIR}"

src="${SRC_DIR}/packaging-${BK_PKG_VERSION}"
[[ -d "${src}" ]] || _die "fontes não encontradas: $src"
cd "${src}"

python3 -m pip install .   --no-deps   --prefix=/usr   --root="${BK_BUILD_ROOT}"

_o "Concluído"
