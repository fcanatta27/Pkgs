#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, make, perl
#   - Runtime: libc, kernel com /dev/urandom
#
# build.sh - openssl ${BK_PKG_VERSION}
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi
_i(){ echo -e "openssl: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "openssl: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "openssl: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "openssl: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

_req wget
_req tar
_req make
_req perl

SRC_URL="${SRC_URL:-https://www.openssl.org/source/openssl-${BK_PKG_VERSION}.tar.gz}"
TARBALL="${TMPDIR}/openssl-${BK_PKG_VERSION}.tar.gz"
SRC_DIR="${TMPDIR}/src-openssl-${BK_PKG_VERSION}"

_i "Construindo openssl ${BK_PKG_VERSION}"
_i "BK_PKG_NAME=${BK_PKG_NAME} DESTDIR=${BK_BUILD_ROOT} JOBS=${JOBS}"

mkdir -p -- "${BK_BUILD_ROOT}" "${SRC_DIR}"

if [[ ! -f "${TARBALL}" ]]; then
  _i "Baixando: ${SRC_URL}"
  wget -O "${TARBALL}" "${SRC_URL}"
else
  _i "Usando tarball cacheado: ${TARBALL}"
fi

_i "Extraindo..."
rm -rf -- "${SRC_DIR}"
mkdir -p -- "${SRC_DIR}"
tar -C "${SRC_DIR}" -xf "${TARBALL}"

src="${SRC_DIR}/openssl-${BK_PKG_VERSION}"
[[ -d "${src}" ]] || _die "fontes não encontradas: ${src}"

cd "${src}"

_i "Configurando openssl..."
./Configure \
  --prefix=/usr \
  --openssldir=/etc/ssl \
  shared \
  linux-x86_64

_i "Compilando openssl..."
make -j"${JOBS}"

_i "Instalando openssl em DESTDIR..."
make DESTDIR="${BK_BUILD_ROOT}" install

_o "Concluído: openssl ${BK_PKG_VERSION} instalado em ${BK_BUILD_ROOT}"
