#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, make (para scripts auxiliares), wget, tar, gzip
#   - Build: zic (compilador de zonas, normalmente de tzcode ou do sistema)
#   - Runtime: libc; zoneinfo em /usr/share/zoneinfo
#
# Observação:
#   - BK_PKG_VERSION aqui é um rótulo lógico "2025" para o conjunto de dados.
#   - A versão upstream exata (a, b, c) é controlada por TZDATA_RELEASE.
#
# build.sh - tzdata ${BK_PKG_VERSION}
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi
_i(){ echo -e "tzdata: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "tzdata: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "tzdata: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "tzdata: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"  # não usado, mas aceito

_req wget
_req tar
_req zic

TZDATA_RELEASE="${TZDATA_RELEASE:-2025c}"   # ex: 2025a, 2025b, 2025c...
SRC_URL="${SRC_URL:-https://data.iana.org/time-zones/releases/tzdata${TZDATA_RELEASE}.tar.gz}"
TARBALL="${TMPDIR}/tzdata${TZDATA_RELEASE}.tar.gz"
SRC_DIR="${TMPDIR}/src-tzdata-${TZDATA_RELEASE}"

_i "Construindo tzdata ${BK_PKG_VERSION} (upstream ${TZDATA_RELEASE})"
_i "BK_PKG_NAME=${BK_PKG_NAME} DESTDIR=${BK_BUILD_ROOT}"

mkdir -p -- "${BK_BUILD_ROOT}" "${SRC_DIR}"

if [[ ! -f "${TARBALL}" ]]; then
  _i "Baixando: ${SRC_URL}"
  wget -O "${TARBALL}" "${SRC_URL}"
else
  _i "Usando tarball cacheado: ${TARBALL}"
fi

_i "Extraindo..."
rm -rf -- "${SRC_DIR}"
mkdir -p -- "${SRC_DIR}"
tar -C "${SRC_DIR}" -xf "${TARBALL}"

cd "${SRC_DIR}"

ZONEINFO="${BK_BUILD_ROOT}/usr/share/zoneinfo"
mkdir -p -- "${ZONEINFO}" "${ZONEINFO}/posix" "${ZONEINFO}/right"

_i "Compilando bancos de dados de zonas..."
# Arquivos principais de zonas
TZ_FILES="africa antarctica asia australasia europe northamerica southamerica etcetera backward systemv"

for tz in ${TZ_FILES}; do
  if [[ -f "${tz}" ]]; then
    zic -L /dev/null   -d "${ZONEINFO}"        "${tz}"
    zic -L /dev/null   -d "${ZONEINFO}/posix"  "${tz}"
    if [[ -f "leapseconds" ]]; then
      zic -L leapseconds -d "${ZONEINFO}/right" "${tz}"
    fi
  else
    _w "arquivo de zona não encontrado: ${tz} (continuando)"
  fi
done

# Copia tabelas auxiliares se existirem
for f in zone.tab zone1970.tab iso3166.tab leap-seconds.list; do
  if [[ -f "${f}" ]]; then
    cp -v "${f}" "${ZONEINFO}/" 2>/dev/null || true
  fi
done

_o "Concluído: tzdata ${BK_PKG_VERSION} instalado em ${ZONEINFO}"
