#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, make, gcc, g++, wget, tar, gzip, xz
#   - Build: pkg-config (recomendado), gettext (opcional), python3/perl (algumas ferramentas)
#   - Runtime: libc; utilitários usam /dev e permissões adequadas
#
# build.sh - e2fsprogs 1.47.3
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi
_i(){ echo -e "e2fsprogs: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "e2fsprogs: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "e2fsprogs: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "e2fsprogs: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

_req wget
_req tar
_req make

SRC_URL="${SRC_URL:-https://cdn.kernel.org/pub/linux/kernel/people/tytso/e2fsprogs/v${BK_PKG_VERSION}/e2fsprogs-${BK_PKG_VERSION}.tar.gz}"
TARBALL="${TMPDIR}/e2fsprogs-${BK_PKG_VERSION}.tar.gz"
SRC_DIR="${TMPDIR}/src-e2fsprogs-${BK_PKG_VERSION}"
BUILD_DIR="${TMPDIR}/build-e2fsprogs-${BK_PKG_VERSION}"

_i "Construindo e2fsprogs ${BK_PKG_VERSION}"
_i "DESTDIR=${BK_BUILD_ROOT} JOBS=${JOBS}"

mkdir -p -- "${BK_BUILD_ROOT}" "${SRC_DIR}" "${BUILD_DIR}"

if [[ ! -f "${TARBALL}" ]]; then
  _i "Baixando: ${SRC_URL}"
  wget -O "${TARBALL}" "${SRC_URL}"
else
  _i "Usando tarball cacheado: ${TARBALL}"
fi

_i "Extraindo..."
rm -rf -- "${SRC_DIR}"
mkdir -p -- "${SRC_DIR}"
tar -C "${SRC_DIR}" -xf "${TARBALL}"

src="${SRC_DIR}/e2fsprogs-${BK_PKG_VERSION}"
[[ -d "${src}" ]] || _die "fontes não encontradas: ${src}"

rm -rf -- "${BUILD_DIR}"
mkdir -p -- "${BUILD_DIR}"
cd "${BUILD_DIR}"

_i "Configurando..."
"${src}/configure" \
  --prefix=/usr \
  --sysconfdir=/etc \
  --localstatedir=/var \
  --disable-static

_i "Compilando..."
make -j"${JOBS}"

_i "Instalando..."
make DESTDIR="${BK_BUILD_ROOT}" install

_o "Concluído: e2fsprogs instalado em ${BK_BUILD_ROOT}/usr"
