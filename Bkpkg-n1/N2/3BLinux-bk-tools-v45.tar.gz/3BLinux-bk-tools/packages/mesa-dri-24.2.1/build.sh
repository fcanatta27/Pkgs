#!/usr/bin/env bash
#
# mesa-dri (meta) – marca presença de drivers DRI do Mesa
#
# Este pacote assume que o pacote 'mesa' já foi construído e instalado
# para o mesmo ROOTFS/BK_BUILD_ROOT. Ele não recompila o Mesa, apenas
# registra a dependência e, opcionalmente, verifica diretórios de drivers.
#
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z="";
fi
_i(){ echo -e "mesa-dri: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "mesa-dri: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "mesa-dri: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "mesa-dri: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

main() {
  _i "verificando instalação do Mesa..."
  if [[ ! -d "${BK_BUILD_ROOT}/usr/lib" ]]; then
    _w "não encontrei /usr/lib em ${BK_BUILD_ROOT}, nada a verificar"
  fi

  # Apenas checa diretórios típicos de drivers
  for d in     "${BK_BUILD_ROOT}/usr/lib/xorg/modules/dri"     "${BK_BUILD_ROOT}/usr/lib/dri"     "${BK_BUILD_ROOT}/usr/lib64/dri"
  do
    if [[ -d "${d}" ]]; then
      _i "diretório de drivers presente: ${d}"
    fi
  done

  # Cria documentação mínima
  mkdir -p "${BK_BUILD_ROOT}/usr/share/doc/mesa-dri"
  cat > "${BK_BUILD_ROOT}/usr/share/doc/mesa-dri/README" <<'EOF'
Este pacote bk 'mesa-dri' funciona como meta-pacote para os drivers DRI
instalados pelo pacote 'mesa'. Ele não compila nem instala arquivos próprios,
apenas registra a presença dos drivers no sistema.
EOF

  _o "Concluído: mesa-dri registrado em ${BK_BUILD_ROOT}"
}

main "$@"
