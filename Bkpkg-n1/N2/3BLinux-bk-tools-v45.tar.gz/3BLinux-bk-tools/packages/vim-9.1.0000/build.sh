#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, make, ncurses, pkg-config
#   - Runtime: ncurses (para interface de terminal)
#
# build.sh - vim ${BK_PKG_VERSION}
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi
_i(){ echo -e "vim: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "vim: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "vim: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "vim: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

_req wget
_req tar
_req make

SRC_URL="${SRC_URL:-https://github.com/vim/vim/archive/refs/tags/v${BK_PKG_VERSION}.tar.gz}"
TARBALL="${TMPDIR}/vim-${BK_PKG_VERSION}.tar.gz"
SRC_DIR="${TMPDIR}/src-vim-${BK_PKG_VERSION}"
BUILD_DIR="${TMPDIR}/build-vim-${BK_PKG_VERSION}"

_i "Construindo vim ${BK_PKG_VERSION}"
_i "BK_PKG_NAME=${BK_PKG_NAME} DESTDIR=${BK_BUILD_ROOT} JOBS=${JOBS}"

mkdir -p -- "${BK_BUILD_ROOT}" "${SRC_DIR}" "${BUILD_DIR}"

if [[ ! -f "${TARBALL}" ]]; then
  _i "Baixando: ${SRC_URL}"
  wget -O "${TARBALL}" "${SRC_URL}"
else
  _i "Usando tarball cacheado: ${TARBALL}"
fi

_i "Extraindo..."
rm -rf -- "${SRC_DIR}"
mkdir -p -- "${SRC_DIR}"
tar -C "${SRC_DIR}" -xf "${TARBALL}"

src="${SRC_DIR}/vim-${BK_PKG_VERSION}"
[[ -d "${src}" ]] || _die "fontes não encontradas: ${src}"

rm -rf -- "${BUILD_DIR}"
mkdir -p -- "${BUILD_DIR}"
cd "${BUILD_DIR}"

_i "Configurando vim..."
"${src}/configure" \
  --prefix=/usr \
  --with-features=normal \
  --enable-multibyte \
  --disable-gui \
  --without-x

_i "Compilando vim..."
make -j"${JOBS}"

_i "Instalando vim em DESTDIR..."
make DESTDIR="${BK_BUILD_ROOT}" install

_o "Concluído: vim ${BK_PKG_VERSION} instalado em ${BK_BUILD_ROOT}"
