#!/usr/bin/env bash
# build.sh – linux-firmware-selected 20260118
#
# Pacote: linux-firmware-selected
# Versão: 20260118
# Descrição: Firmware selecionado para notebook/desktop (subset do linux-firmware).
# Fonte: https://git.kernel.org/pub/scm/linux/kernel/git/firmware/linux-firmware.git/snapshot/linux-firmware.tar.gz
#
# Dependências (comentadas):
#   - rsync (recomendado)
#
set -Eeuo pipefail

# UI
if [[ -t 2 ]]; then
  B="\033[1m"; R="\033[31m"; G="\033[32m"; Y="\033[33m"; N="\033[0m"
else
  B=""; R=""; G=""; Y=""; N=""
fi
msg(){ echo -e "${B}${G}==>${N} $*" >&2; }
warn(){ echo -e "${B}${Y}==> WARN:${N} $*" >&2; }
die(){ echo -e "${B}${R}==> ERRO:${N} $*" >&2; exit 1; }

export BK_PKG_NAME="${BK_PKG_NAME:-linux-firmware-selected}"
export BK_PKG_VERSION="${BK_PKG_VERSION:-20260118}"

: "${BK_ROOT:=${BK_ROOT:-/}}"
: "${BK_WORKDIR:=${BK_WORKDIR:-/tmp/bk-build/${BK_PKG_NAME}-${BK_PKG_VERSION}}}"
: "${BK_SRCDIR:=${BK_SRCDIR:-/tmp/bk-src}}"
: "${BK_DESTDIR:=${BK_DESTDIR:-${BK_WORKDIR}/dest}}"
: "${BK_JOBS:=${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}}"

mkdir -p "$BK_WORKDIR" "$BK_SRCDIR" "$BK_DESTDIR"

fetch() {
  local url="$1" out="$2"
  if [[ -f "$out" ]]; then msg "Fonte já existe: $out"; return 0; fi
  msg "Baixando: $url"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 -o "$out" "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    die "Precisa de curl ou wget"
  fi
}

unpack() {
  local tarball="$1"
  msg "Extraindo: $tarball"
  rm -rf "$BK_WORKDIR/src"
  mkdir -p "$BK_WORKDIR/src"
  tar -xf "$tarball" -C "$BK_WORKDIR/src" --strip-components=1
}

msg "Iniciando build: ${BK_PKG_NAME}-${BK_PKG_VERSION}"
msg "WORKDIR=$BK_WORKDIR"
msg "DESTDIR=$BK_DESTDIR"
SRC="$BK_SRCDIR/linux-firmware-20260118.tar.gz"
fetch "https://git.kernel.org/pub/scm/linux/kernel/git/firmware/linux-firmware.git/snapshot/linux-firmware.tar.gz" "$SRC"
unpack "$SRC"
cd "$BK_WORKDIR/src"

# Seleção (laptop típico). Ajuste conforme seu hardware.
# Você pode exportar BK_FIRMWARE_PROFILE:
#   minimal | laptop | full
PROFILE="${BK_FIRMWARE_PROFILE:-laptop}"
msg "Perfil firmware: $PROFILE"

install -d "$BK_DESTDIR/usr/lib/firmware"

copy_tree() {
  local path="$1"
  if [[ -e "$path" ]]; then
    msg "Incluindo: $path"
    cp -a "$path" "$BK_DESTDIR/usr/lib/firmware/"
  fi
}

case "$PROFILE" in
  minimal)
    copy_tree "intel-ucode"
    copy_tree "amd-ucode"
    ;;
  laptop|notebook)
    # Wi-Fi (intel/atheros/realtek)
    copy_tree "iwlwifi"
    copy_tree "ath10k"
    copy_tree "ath11k"
    copy_tree "rtlwifi"
    copy_tree "rtl_nic"
    # GPU
    copy_tree "i915"
    copy_tree "amdgpu"
    copy_tree "radeon"
    # Bluetooth
    copy_tree "intel"
    copy_tree "rtl_bt"
    copy_tree "qca"
    ;;
  full)
    msg "Incluindo tudo (linux-firmware completo)…"
    rsync -a --exclude='.git*' ./ "$BK_DESTDIR/usr/lib/firmware/"
    ;;
  *)
    die "BK_FIRMWARE_PROFILE inválido: $PROFILE"
    ;;
esac

msg "OK"
