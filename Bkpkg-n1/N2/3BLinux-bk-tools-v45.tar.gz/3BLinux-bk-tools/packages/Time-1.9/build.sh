#!/usr/bin/env bash
# build.sh – time 1.9
#
# Pacote: time
# Versão: 1.9
# Descrição: GNU time (medir tempo de execução).
# Fonte: https://ftp.gnu.org/gnu/time/time-1.9.tar.gz
#
# Dependências (comentadas):
#   - glibc
#   - gcc
#   - make
#
# Observações:
#   - Este script segue o padrão bk-tools: compila em /tmp e instala em DESTDIR.
#   - Espera as variáveis BK_* do bk (ou usa defaults seguros).
#
set -Eeuo pipefail

# --- UI (cores/bold) ---
if [[ -t 2 ]]; then
  B="\033[1m"; R="\033[31m"; G="\033[32m"; Y="\033[33m"; U="\033[34m"; Z="\033[0m"
else
  B=""; R=""; G=""; Y=""; U=""; Z=""
fi
_i(){ echo -e "build: ${B}${U}$*${Z}" >&2; }
_o(){ echo -e "build: ${B}${G}$*${Z}" >&2; }
_w(){ echo -e "build: ${B}${Y}$*${Z}" >&2; }
_e(){ echo -e "build: ${B}${R}$*${Z}" >&2; }
_die(){ _e "$*"; exit 1; }

BK_PKG_NAME="${BK_PKG_NAME:-}"
BK_PKG_VERSION="${BK_PKG_VERSION:-}"
BK_SRC_URL="${BK_SRC_URL:-}"
BK_WORKDIR="${BK_WORKDIR:-/tmp/bk-build}"
BK_DESTDIR="${BK_DESTDIR:-/tmp/bk-dest}"
BK_ROOT="${BK_ROOT:-/}"         # rootfs alvo (para bk)
BK_JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

mkdir -p "$BK_WORKDIR" "$BK_DESTDIR"

_fetch_unpack() {
  local url="$1"
  local out="$2"
  command -v curl >/dev/null 2>&1 || _die "curl não encontrado"
  command -v tar >/dev/null 2>&1 || _die "tar não encontrado"
  mkdir -p "$BK_WORKDIR/src"
  local fn="${out:-$(basename "$url")}"
  local dl="$BK_WORKDIR/src/$fn"
  if [[ ! -f "$dl" ]]; then
    _i "baixando: $url"
    curl -L --fail -o "$dl" "$url"
  else
    _i "usando cache: $dl"
  fi
  _i "extraindo: $dl"
  tar -xf "$dl" -C "$BK_WORKDIR"
}

_enter_srcdir() {
  local pattern="$1"
  local d
  d="$(find "$BK_WORKDIR" -maxdepth 1 -type d -name "$pattern" | head -n1 || true)"
  [[ -n "$d" ]] || _die "srcdir não encontrado (pattern=$pattern) em $BK_WORKDIR"
  cd "$d"
}

_make_destdirs() {
  mkdir -p "$BK_DESTDIR"/{usr/bin,usr/sbin,usr/lib,usr/share,usr/include,etc,var}
}

_autotools_build() {
  local cfg_args=("$@")
  _i "configure: ${cfg_args[*]}"
  ./configure "${cfg_args[@]}"
  _i "build (make -j$BK_JOBS)"
  make -j"$BK_JOBS"
  _i "install (DESTDIR=$BK_DESTDIR)"
  make DESTDIR="$BK_DESTDIR" install
}

_meson_build() {
  local meson_args=("$@")
  command -v meson >/dev/null 2>&1 || _die "meson não encontrado"
  command -v ninja >/dev/null 2>&1 || _die "ninja não encontrado"
  meson setup build "${meson_args[@]}"
  ninja -C build -j"$BK_JOBS"
  DESTDIR="$BK_DESTDIR" ninja -C build install
}

BK_PKG_NAME="${BK_PKG_NAME:-time}"
BK_PKG_VERSION="${BK_PKG_VERSION:-1.9}"
BK_SRC_URL="${BK_SRC_URL:-https://ftp.gnu.org/gnu/time/time-1.9.tar.gz}"

main() {
  _make_destdirs
  _fetch_unpack "$BK_SRC_URL"
  _enter_srcdir "time-*"

  _autotools_build --prefix=/usr

  _o "ok: ${BK_PKG_NAME}-${BK_PKG_VERSION}"
}
main "$@"
