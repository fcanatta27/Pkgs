#!/usr/bin/env bash
#
# "Pacote" lógico: ca-certificates ${BK_PKG_VERSION}
#
# Baixa o bundle de CAs da Mozilla e instala em:
#   /etc/ssl/certs/ca-certificates.crt
#
# Dependências (comentado)
#   - Build/Runtime: wget ou curl, openssl (opcional para c_rehash)
#
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi
_i(){ echo -e "ca-certificates: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "ca-certificates: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "ca-certificates: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "ca-certificates: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"

BUNDLE_URL="${BUNDLE_URL:-https://curl.se/ca/cacert.pem}"
BUNDLE="${TMPDIR}/cacert.pem"

if command -v wget >/dev/null 2>&1; then
  DL="wget -O"
elif command -v curl >/dev/null 2>&1; then
  DL="curl -L -o"
else
  _die "é necessário wget ou curl para baixar o bundle de CAs"
fi

_i "Instalando bundle de CAs da Mozilla"
_i "BK_PKG_NAME=${BK_PKG_NAME} DESTDIR=${BK_BUILD_ROOT}"

mkdir -p -- "${BK_BUILD_ROOT}/etc/ssl/certs"

_i "Baixando: ${BUNDLE_URL}"
${DL} "${BUNDLE}" "${BUNDLE_URL}"

install -m 0644 "${BUNDLE}" "${BK_BUILD_ROOT}/etc/ssl/certs/ca-certificates.crt"

# Se existir c_rehash, gera links hash
if command -v c_rehash >/dev/null 2>&1; then
  ( cd "${BK_BUILD_ROOT}/etc/ssl/certs" && c_rehash . || _w "c_rehash falhou (continuando)" )
fi

_o "Concluído: ca-certificates instalados em ${BK_BUILD_ROOT}/etc/ssl/certs"
