#!/usr/bin/env bash
# build.sh – imlib2 1.12.6
#
# Pacote: imlib2
# Versão: 1.12.6
# Descrição: Biblioteca de imagens usada por WMs e apps.
# Fonte: https://downloads.sourceforge.net/enlightenment/imlib2-1.12.6.tar.xz
#
# Dependências (comentadas):
#   - xorg-libs
#   - libpng
#   - jpeg
#
# Observações:
#   - Este script segue o padrão bk-tools: compila em /tmp e instala em DESTDIR.
#   - Espera variáveis BK_* do bk (ou usa defaults seguros).
#
set -Eeuo pipefail

# --- UI (cores/bold) ---
if [[ -t 2 ]]; then
  B="\033[1m"; R="\033[31m"; G="\033[32m"; Y="\033[33m"; U="\033[4m"; N="\033[0m"
else
  B=""; R=""; G=""; Y=""; U=""; N=""
fi
msg()  { echo -e "${B}${G}==>${N} $*" >&2; }
warn() { echo -e "${B}${Y}==> WARN:${N} $*" >&2; }
die()  { echo -e "${B}${R}==> ERRO:${N} $*" >&2; exit 1; }

# --- Metadata (padrão bk) ---
export BK_PKG_NAME="${BK_PKG_NAME:-imlib2}"
export BK_PKG_VERSION="${BK_PKG_VERSION:-1.12.6}"

# --- Defaults seguros ---
: "${BK_ROOT:=${BK_ROOT:-/}}"
: "${BK_WORKDIR:=${BK_WORKDIR:-/tmp/bk-build/${BK_PKG_NAME}-${BK_PKG_VERSION}}}"
: "${BK_SRCDIR:=${BK_SRCDIR:-/tmp/bk-src}}"
: "${BK_CACHEDIR:=${BK_CACHEDIR:-${BK_ROOT%/}/var/3bLinux}}"
: "${BK_DESTDIR:=${BK_DESTDIR:-${BK_WORKDIR}/dest}}"
: "${BK_JOBS:=${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}}"

mkdir -p "$BK_WORKDIR" "$BK_SRCDIR" "$BK_DESTDIR" "$BK_CACHEDIR"

fetch() {
  local url="$1" out="$2"
  if [[ -f "$out" ]]; then
    msg "Fonte já existe: $out"
    return 0
  fi
  msg "Baixando: $url"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 -o "$out" "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    die "Precisa de curl ou wget no host"
  fi
}

unpack() {
  local tarball="$1"
  msg "Extraindo: $tarball"
  rm -rf "$BK_WORKDIR/src"
  mkdir -p "$BK_WORKDIR/src"
  tar -xf "$tarball" -C "$BK_WORKDIR/src" --strip-components=1
}

msg "Iniciando build: ${BK_PKG_NAME}-${BK_PKG_VERSION}"
msg "WORKDIR=$BK_WORKDIR"
msg "DESTDIR=$BK_DESTDIR"
msg "ROOT=$BK_ROOT"
msg "CACHE(bin)=$BK_CACHEDIR"

SRC="$BK_SRCDIR/imlib2-1.12.6.tar.xz"
fetch "https://downloads.sourceforge.net/enlightenment/imlib2-1.12.6.tar.xz" "$SRC"
unpack "$SRC"

cd "$BK_WORKDIR/src"

msg "Configurando…"
if [[ -x ./configure ]]; then
  ./configure --prefix=/usr --disable-static --sysconfdir=/etc
else
  die "configure não encontrado"
fi

msg "Compilando…"
make -j"$BK_JOBS"

msg "Instalando em DESTDIR…"
make DESTDIR="$BK_DESTDIR" install

msg "OK: ${BK_PKG_NAME}-${BK_PKG_VERSION}"
