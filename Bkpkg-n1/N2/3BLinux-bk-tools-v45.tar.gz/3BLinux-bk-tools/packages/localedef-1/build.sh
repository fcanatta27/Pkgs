#!/usr/bin/env bash
#
# "Pacote" lógico: localedef ${BK_PKG_VERSION}
#
# Este script não compila fontes; ele usa o binário localedef já
# instalado (via glibc) para gerar um conjunto padrão de locales
# dentro do BK_BUILD_ROOT.
#
# Dependências (comentado)
#   - Runtime: glibc com localedef funcional, arquivos locale.src, charmap, etc.
#
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi
_i(){ echo -e "localedef: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "localedef: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "localedef: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "localedef: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

_req localedef

_i "Gerando locales padrão com localedef"
_i "BK_PKG_NAME=${BK_PKG_NAME} DESTDIR=${BK_BUILD_ROOT}"

LOCALE_ROOT="${BK_BUILD_ROOT}/usr/lib/locale"
mkdir -p -- "${LOCALE_ROOT}"

# Lista mínima de locales (pode ser ajustada via LOCALES env)
LOCALES_DEFAULT="
en_US.UTF-8 UTF-8
pt_BR.UTF-8 UTF-8
C.UTF-8 UTF-8
"

LOCALES="${LOCALES:-${LOCALES_DEFAULT}}"

while read -r name charset; do
  [[ -z "${name}" ]] && continue
  _i "Gerando locale ${name} (${charset})"
  localedef -i "${name%%.*}" -f "${charset}" --prefix="${BK_BUILD_ROOT}" "${name}" || _w "falha ao gerar ${name}"
done <<< "${LOCALES}"

_o "Concluído: locais gerados em ${LOCALE_ROOT}"
