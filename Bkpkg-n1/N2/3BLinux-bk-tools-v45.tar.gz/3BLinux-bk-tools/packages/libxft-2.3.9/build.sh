#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: pkg-config, make, gcc, xorgproto, libx11, freetype2, fontconfig
#   - Runtime: libx11, freetype2, fontconfig
#
# build.sh - libXft 2.3.9
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _G=""; _U=""; _Z=""
fi
_i(){ echo -e "libxft: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "libxft: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "libxft: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "libxft: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

SRC_URL="https://www.x.org/releases/individual/lib/libXft-2.3.9.tar.xz"
TARBALL="libXft-2.3.9.tar.xz"
SRCDIR="libXft-2.3.9"

_need_tools() {
  for t in sh tar wget make gcc; do
    _req "$t"
  done
}

_fetch() {
  local out="${TMPDIR}/${TARBALL}"
  if [[ -f "${out}" ]]; then
    _i "usando cache: ${out}"
    return 0
  fi
  _i "baixando: ${SRC_URL}"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail -o "${out}" "${SRC_URL}"
  else
    wget -O "${out}" "${SRC_URL}"
  fi
}

_unpack() {
  local out="${TMPDIR}/${TARBALL}"
  rm -rf -- "${TMPDIR}/${SRCDIR}"
  _i "extraindo: ${out}"
  tar -C "${TMPDIR}" -xf "${out}"
}

main() {
  _need_tools
  _fetch
  _unpack
  local src="${TMPDIR}/${SRCDIR}"
  [[ -d "${src}" ]] || _die "fonte não encontrado: ${src}"

  
  rm -rf -- "${BK_BUILD_ROOT:?}/"*
  mkdir -p -- "${BK_BUILD_ROOT}"

  _i "configurando..."
  ( cd "${src}" && ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --disable-static  )

  _i "compilando..."
  ( cd "${src}" && make -j"${JOBS}" )

  _i "instalando em DESTDIR..."
  ( cd "${src}" && make DESTDIR="${BK_BUILD_ROOT}" install )

  _o "Concluído: ${BK_PKG_NAME} ${BK_PKG_VERSION} instalado em ${BK_BUILD_ROOT}"
}

main "$@"
