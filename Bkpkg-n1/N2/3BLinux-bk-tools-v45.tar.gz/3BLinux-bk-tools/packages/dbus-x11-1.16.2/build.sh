#!/usr/bin/env bash
#
# dbus-x11 (meta) – integra dbus com sessão X11
#
# Este pacote não compila fontes; ele apenas garante que o dbus esteja
# presente e instala pequenos arquivos auxiliares se necessário.
#
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z="";
fi
_i(){ echo -e "dbus-x11: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "dbus-x11: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "dbus-x11: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "dbus-x11: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

main() {
  _i "verificando presença do dbus..."
  if [[ ! -x "${BK_BUILD_ROOT}/usr/bin/dbus-daemon" && ! -x "${BK_BUILD_ROOT}/bin/dbus-daemon" ]]; then
    _w "dbus não encontrado em ${BK_BUILD_ROOT}; este pacote assume que dbus já está instalado."
  fi

  # cria um stub de sessão X se nada existir
  mkdir -p "${BK_BUILD_ROOT}/etc/X11/xinit"
  if [[ ! -f "${BK_BUILD_ROOT}/etc/X11/xinit/xinitrc.d/10-dbus.sh" ]]; then
    mkdir -p "${BK_BUILD_ROOT}/etc/X11/xinit/xinitrc.d"
    cat > "${BK_BUILD_ROOT}/etc/X11/xinit/xinitrc.d/10-dbus.sh" <<'EOF'
#!/bin/sh
if command -v dbus-launch >/dev/null 2>&1 && [ -z "$DBUS_SESSION_BUS_ADDRESS" ]; then
  eval "$(dbus-launch --sh-syntax --exit-with-session)"
fi
EOF
    chmod 0755 "${BK_BUILD_ROOT}/etc/X11/xinit/xinitrc.d/10-dbus.sh"
  fi

  _o "Concluído: dbus-x11 configurado em ${BK_BUILD_ROOT}"
}

main "$@"
