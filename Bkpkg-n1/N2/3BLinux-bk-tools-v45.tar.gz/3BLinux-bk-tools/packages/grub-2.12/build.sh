#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, g++, make, flex, bison, gettext, device-mapper (opcional)
#   - Runtime: BIOS/EFI, disk acessível
#
# build.sh - grub (grub2) ${BK_PKG_VERSION}
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi
_i(){ echo -e "grub: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "grub: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "grub: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "grub: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

_req wget
_req tar
_req make

SRC_URL="${SRC_URL:-https://ftp.gnu.org/gnu/grub/grub-${BK_PKG_VERSION}.tar.xz}"
TARBALL="${TMPDIR}/grub-${BK_PKG_VERSION}.tar.xz"
SRC_DIR="${TMPDIR}/src-grub-${BK_PKG_VERSION}"
BUILD_DIR="${TMPDIR}/build-grub-${BK_PKG_VERSION}"

_i "Construindo grub ${BK_PKG_VERSION}"
_i "BK_PKG_NAME=${BK_PKG_NAME} DESTDIR=${BK_BUILD_ROOT} JOBS=${JOBS}"

mkdir -p -- "${BK_BUILD_ROOT}" "${SRC_DIR}" "${BUILD_DIR}"

if [[ ! -f "${TARBALL}" ]]; then
  _i "Baixando: ${SRC_URL}"
  wget -O "${TARBALL}" "${SRC_URL}"
else
  _i "Usando tarball cacheado: ${TARBALL}"
fi

_i "Extraindo..."
rm -rf -- "${SRC_DIR}"
mkdir -p -- "${SRC_DIR}"
tar -C "${SRC_DIR}" -xf "${TARBALL}"

src="${SRC_DIR}/grub-${BK_PKG_VERSION}"
[[ -d "${src}" ]] || _die "fontes não encontradas: ${src}"

rm -rf -- "${BUILD_DIR}"
mkdir -p -- "${BUILD_DIR}"
cd "${BUILD_DIR}"

_i "Configurando grub..."
"${src}/configure" \
  --prefix=/usr \
  --sysconfdir=/etc \
  --localstatedir=/var \
  --with-platform=pc \
  --disable-efiemu

_i "Compilando grub..."
make -j"${JOBS}"

_i "Instalando grub em DESTDIR..."
make DESTDIR="${BK_BUILD_ROOT}" install

_o "Concluído: grub ${BK_PKG_VERSION} instalado em ${BK_BUILD_ROOT}"
