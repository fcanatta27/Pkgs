#!/bin/sh
# Ação ACPI para tampa de notebook (lid) no 3BLinux
# - Fecha tampa: suspende (se pm-utils disponível)
# - Abre tampa: apenas registra no log

LOGGER="logger -t acpid-lid"

case "$1" in
  close)
    $LOGGER "lid close: suspend"
    if command -v pm-suspend >/dev/null 2>&1; then
      pm-suspend
    fi
    ;;
  open)
    $LOGGER "lid open"
    ;;
  *)
    # Alguns daemons acpid chamam sem args; tenta detectar pelo $2
    if echo "$*" | grep -qi close; then
      $LOGGER "lid (autodetect close): suspend"
      if command -v pm-suspend >/dev/null 2>&1; then
        pm-suspend
      fi
    fi
    ;;
esac
