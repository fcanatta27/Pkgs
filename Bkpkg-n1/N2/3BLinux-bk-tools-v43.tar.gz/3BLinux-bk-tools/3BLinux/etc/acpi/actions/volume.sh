#!/bin/sh
# Ação genérica para teclas de volume (Fn) no 3BLinux
# Usa amixer (alsa-utils) se disponível.

LOGGER="logger -t acpid-volume"

case "$1" in
  up)
    $LOGGER "volume up"
    command -v amixer >/dev/null 2>&1 && amixer -q set Master 5%+ unmute
    ;;
  down)
    $LOGGER "volume down"
    command -v amixer >/dev/null 2>&1 && amixer -q set Master 5%- unmute
    ;;
  mute)
    $LOGGER "volume mute"
    command -v amixer >/dev/null 2>&1 && amixer -q set Master toggle
    ;;
  *)
    # fallback genérico
    $LOGGER "volume event: $*"
    ;;
esac
