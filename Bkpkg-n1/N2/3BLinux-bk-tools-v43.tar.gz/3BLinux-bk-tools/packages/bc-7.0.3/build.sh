#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, make, wget, tar
#   - Runtime: libc
#
#
# Dependências:
#   - Build: gcc, make, bash
#   - Runtime: libc
#
set -Eeuo pipefail

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

TMPDIR="${TMPDIR:-/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

TARBALL="$TMPDIR/bc-${BK_PKG_VERSION}.tar.gz"
SRC_DIR="$TMPDIR/src-bc-${BK_PKG_VERSION}"
BUILD_DIR="$TMPDIR/build-bc-${BK_PKG_VERSION}"

wget -O "$TARBALL" "https://github.com/gavinhoward/bc/releases/download/7.0.3/bc-7.0.3.tar.gz"
rm -rf "$SRC_DIR" "$BUILD_DIR"
mkdir -p "$SRC_DIR" "$BUILD_DIR"
tar -xf "$TARBALL" -C "$SRC_DIR"

cd "$BUILD_DIR"
"$SRC_DIR"/bc-${BK_PKG_VERSION}/configure --prefix=/usr
make -j"$JOBS"
make DESTDIR="$BK_BUILD_ROOT" install
