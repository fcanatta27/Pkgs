#!/usr/bin/env bash
# build.sh – 3blinux-xfce-defaults 1.0
#
# Pacote: 3blinux-xfce-defaults
# Versão: 1.0
# Descrição: Defaults e tema padrão para XFCE + LightDM.
# Fonte: (config interno)
#
# Dependências (comentadas):
#   - xfce4
#   - lightdm
#   - lightdm-gtk-greeter
#   - dejavu-fonts
#   - fontconfig
#   - gtk3
#
set -Eeuo pipefail

# UI
if [[ -t 2 ]]; then
  B="\033[1m"; R="\033[31m"; G="\033[32m"; Y="\033[33m"; N="\033[0m"
else
  B=""; R=""; G=""; Y=""; N=""
fi
msg(){ echo -e "${B}${G}==>${N} $*" >&2; }
warn(){ echo -e "${B}${Y}==> WARN:${N} $*" >&2; }
die(){ echo -e "${B}${R}==> ERRO:${N} $*" >&2; exit 1; }

export BK_PKG_NAME="${BK_PKG_NAME:-3blinux-xfce-defaults}"
export BK_PKG_VERSION="${BK_PKG_VERSION:-1.0}"

: "${BK_ROOT:=${BK_ROOT:-/}}"
: "${BK_WORKDIR:=${BK_WORKDIR:-/tmp/bk-build/${BK_PKG_NAME}-${BK_PKG_VERSION}}}"
: "${BK_SRCDIR:=${BK_SRCDIR:-/tmp/bk-src}}"
: "${BK_DESTDIR:=${BK_DESTDIR:-${BK_WORKDIR}/dest}}"
: "${BK_JOBS:=${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}}"

mkdir -p "$BK_WORKDIR" "$BK_SRCDIR" "$BK_DESTDIR"

fetch() {
  local url="$1" out="$2"
  if [[ -f "$out" ]]; then msg "Fonte já existe: $out"; return 0; fi
  msg "Baixando: $url"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 -o "$out" "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    die "Precisa de curl ou wget"
  fi
}

unpack() {
  local tarball="$1"
  msg "Extraindo: $tarball"
  rm -rf "$BK_WORKDIR/src"
  mkdir -p "$BK_WORKDIR/src"
  tar -xf "$tarball" -C "$BK_WORKDIR/src" --strip-components=1
}

msg "Iniciando build: ${BK_PKG_NAME}-${BK_PKG_VERSION}"
msg "WORKDIR=$BK_WORKDIR"
msg "DESTDIR=$BK_DESTDIR"
# Este pacote não baixa fonte; ele instala defaults do 3BLinux para XFCE/LightDM.

msg "Instalando defaults…"

# Wallpapers
install -d "$BK_DESTDIR/usr/share/backgrounds/3blinux"
cat > "$BK_DESTDIR/usr/share/backgrounds/3blinux/wallpaper.txt" <<'EOF'
3BLinux wallpaper placeholder.
Substitua por uma imagem real (.png/.jpg) em /usr/share/backgrounds/3blinux/
EOF

# GTK defaults
install -d "$BK_DESTDIR/etc/gtk-3.0" "$BK_DESTDIR/etc/gtk-4.0"
cat > "$BK_DESTDIR/etc/gtk-3.0/settings.ini" <<'EOF'
[Settings]
gtk-theme-name=Adwaita-dark
gtk-icon-theme-name=Adwaita
gtk-font-name=DejaVu Sans 10
gtk-cursor-theme-name=Adwaita
gtk-application-prefer-dark-theme=true
EOF
cat > "$BK_DESTDIR/etc/gtk-4.0/settings.ini" <<'EOF'
[Settings]
gtk-theme-name=Adwaita-dark
gtk-icon-theme-name=Adwaita
gtk-font-name=DejaVu Sans 10
gtk-cursor-theme-name=Adwaita
gtk-application-prefer-dark-theme=true
EOF

# LightDM GTK greeter config
install -d "$BK_DESTDIR/etc/lightdm"
cat > "$BK_DESTDIR/etc/lightdm/lightdm.conf" <<'EOF'
[Seat:*]
greeter-session=lightdm-gtk-greeter
user-session=xfce
EOF

cat > "$BK_DESTDIR/etc/lightdm/lightdm-gtk-greeter.conf" <<'EOF'
[greeter]
theme-name = Adwaita-dark
icon-theme-name = Adwaita
font-name = DejaVu Sans 11
background = /usr/share/backgrounds/3blinux/wallpaper.txt
xft-antialias = true
xft-hintstyle = hintfull
xft-rgba = rgb
indicators = ~host;~spacer;~clock;~spacer;~power
EOF

# XFCE skeleton (minimal, elegante)
install -d "$BK_DESTDIR/etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml"
cat > "$BK_DESTDIR/etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xsettings" version="1.0">
  <property name="Net" type="empty">
    <property name="ThemeName" type="string" value="Adwaita-dark"/>
    <property name="IconThemeName" type="string" value="Adwaita"/>
    <property name="CursorThemeName" type="string" value="Adwaita"/>
    <property name="FontName" type="string" value="DejaVu Sans 10"/>
  </property>
</channel>
EOF

# XFCE session (startxfce4 is default). Provide .xsession for DMs.
cat > "$BK_DESTDIR/etc/skel/.xsession" <<'EOF'
exec startxfce4
EOF

msg "OK"
