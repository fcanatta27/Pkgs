#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, make, gcc, wget, tar, gzip
#   - Runtime: libc; fornece zic, zdump e demais utilitários de timezone
#
# Observação:
#   - BK_PKG_VERSION aqui é um rótulo lógico "2025".
#   - A versão upstream exata (a, b, c) é controlada por TZCODE_RELEASE.
#
# build.sh - tzcode ${BK_PKG_VERSION}
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi
_i(){ echo -e "tzcode: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "tzcode: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "tzcode: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "tzcode: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"  # não usado

_req wget
_req tar
_req make

TZCODE_RELEASE="${TZCODE_RELEASE:-2025c}"   # ex: 2025a, 2025b, 2025c...
SRC_URL="${SRC_URL:-https://data.iana.org/time-zones/releases/tzcode${TZCODE_RELEASE}.tar.gz}"
TARBALL="${TMPDIR}/tzcode${TZCODE_RELEASE}.tar.gz"
SRC_DIR="${TMPDIR}/src-tzcode-${TZCODE_RELEASE}"

_i "Construindo tzcode ${BK_PKG_VERSION} (upstream ${TZCODE_RELEASE})"
_i "BK_PKG_NAME=${BK_PKG_NAME} DESTDIR=${BK_BUILD_ROOT}"

mkdir -p -- "${BK_BUILD_ROOT}" "${SRC_DIR}"

if [[ ! -f "${TARBALL}" ]]; then
  _i "Baixando: ${SRC_URL}"
  wget -O "${TARBALL}" "${SRC_URL}"
else
  _i "Usando tarball cacheado: ${TARBALL}"
fi

_i "Extraindo..."
rm -rf -- "${SRC_DIR}"
mkdir -p -- "${SRC_DIR}"
tar -C "${SRC_DIR}" -xf "${TARBALL}"

cd "${SRC_DIR}"

_i "Compilando tzcode..."
make -j"${JOBS}"

_i "Instalando tzcode em DESTDIR..."
# Instala zic, zdump e demais binários em /usr/sbin (pode ajustar conforme preferência)
BINDIR="${BK_BUILD_ROOT}/usr/sbin"
mkdir -p -- "${BINDIR}"

for bin in zic zdump; do
  if [[ -x "${bin}" ]]; then
    install -m 0755 "${bin}" "${BINDIR}/"
  else
    _w "binário ${bin} não encontrado após build (continuando)"
  fi
done

# Instala scripts de suporte se existirem
for f in tzselect; do
  if [[ -f "${f}" ]]; then
    install -m 0755 "${f}" "${BINDIR}/" 2>/dev/null || true
  fi
done

_o "Concluído: tzcode ${BK_PKG_VERSION} instalado em ${BINDIR}"
