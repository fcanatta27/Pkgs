#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils (install), nenhuma dependência externa
#   - Runtime: bash no sistema
#
# build.sh - bk-tools-2.0.0
#
# Empacota o conjunto bk-tools (bk, bk-cli, bk-chroot, bk-reparo) dentro do rootfs.
# Instala em /usr/bin dentro do DESTDIR (BK_BUILD_ROOT).
#
set -Eeuo pipefail

# --- UI (cores/bold) ---
if [[ -t 2 ]]; then
  _BK_BOLD="\033[1m"; _BK_RED="\033[31m"; _BK_GRN="\033[32m"; _BK_YEL="\033[33m"; _BK_BLU="\033[34m"; _BK_RST="\033[0m"
else
  _BK_BOLD=""; _BK_RED=""; _BK_GRN=""; _BK_YEL=""; _BK_BLU=""; _BK_RST=""
fi
_bk_info() { echo -e "bk-tools: ${_BK_BOLD}${_BK_BLU}$*${_BK_RST}" >&2; }
_bk_ok()   { echo -e "bk-tools: ${_BK_BOLD}${_BK_GRN}$*${_BK_RST}" >&2; }
_bk_err()  { echo -e "bk-tools: ${_BK_BOLD}${_BK_RED}$*${_BK_RST}" >&2; }

_die(){ _bk_err "$*"; exit 1; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

_script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
_project_root="$(cd "${_script_dir}/../.." && pwd)"

dest="${BK_BUILD_ROOT}/usr/bin"
_bk_info "instalando bk-tools em ${dest}"
mkdir -p -- "${dest}"

for f in bk bk-cli bk-chroot bk-reparo; do
  src="${_project_root}/bin/${f}"
  [[ -f "${src}" ]] || _die "arquivo ausente: ${src}"
  install -m 0755 "${src}" "${dest}/${f}"
done

_bk_ok "bk-tools instalados em ${dest}"
