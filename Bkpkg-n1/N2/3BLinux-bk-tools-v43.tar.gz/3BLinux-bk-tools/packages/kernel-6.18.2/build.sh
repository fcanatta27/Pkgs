#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, make, gcc, g++, wget, tar, xz, bc
#   - Build: flex, bison, perl, python3 (algumas partes), openssl (assinatura/crypto), elfutils (opcional)
#   - Build: pahole/dwarves (opcional, para BTF), rsync (opcional)
#   - Runtime: kernel image em /boot e módulos em /lib/modules/<ver>
#
# build.sh - Linux Kernel 6.18.2 (compila imagem + módulos)
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _B="\033[1m"; _R="\033[31m"; _G="\033[32m"; _Y="\033[33m"; _U="\033[34m"; _Z="\033[0m"
else
  _B=""; _R=""; _G=""; _Y=""; _U=""; _Z=""
fi
_i(){ echo -e "kernel: ${_B}${_U}$*${_Z}" >&2; }
_o(){ echo -e "kernel: ${_B}${_G}$*${_Z}" >&2; }
_w(){ echo -e "kernel: ${_B}${_Y}$*${_Z}" >&2; }
_e(){ echo -e "kernel: ${_B}${_R}$*${_Z}" >&2; }
_die(){ _e "$*"; exit 1; }
_req(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

ARCH="${BK_ARCH:-$(uname -m)}"
KARCH="${BK_KARCH:-}"
case "${KARCH}" in
  "") ;;
  *) ;;
esac

# Detect kernel arch
if [[ -z "${KARCH}" ]]; then
  case "${ARCH}" in
    x86_64|amd64) KARCH="x86_64" ;;
    aarch64|arm64) KARCH="arm64" ;;
    i?86) KARCH="x86" ;;
    *) KARCH="${ARCH}" ;;
  esac
fi

_req wget
_req tar
_req make

SRC_URL="${SRC_URL:-https://www.kernel.org/pub/linux/kernel/v6.x/linux-${BK_PKG_VERSION}.tar.xz}"
TARBALL="${TMPDIR}/linux-${BK_PKG_VERSION}.tar.xz"
SRC_DIR="${TMPDIR}/src-linux-${BK_PKG_VERSION}"
BUILD_DIR="${TMPDIR}/build-linux-${BK_PKG_VERSION}"

_i "Construindo Linux ${BK_PKG_VERSION}"
_i "ARCH=${KARCH} DESTDIR=${BK_BUILD_ROOT} JOBS=${JOBS}"
_i "Nota: este script usa defconfig. Para config custom, coloque um .config e exporte BK_KERNEL_CONFIG=/caminho/.config"

mkdir -p -- "${BK_BUILD_ROOT}" "${SRC_DIR}" "${BUILD_DIR}"

if [[ ! -f "${TARBALL}" ]]; then
  _i "Baixando: ${SRC_URL}"
  wget -O "${TARBALL}" "${SRC_URL}"
else
  _i "Usando tarball cacheado: ${TARBALL}"
fi

_i "Extraindo..."
rm -rf -- "${SRC_DIR}"
mkdir -p -- "${SRC_DIR}"
tar -C "${SRC_DIR}" -xf "${TARBALL}"

src="${SRC_DIR}/linux-${BK_PKG_VERSION}"
[[ -d "${src}" ]] || _die "fontes não encontradas: ${src}"

# Build in-tree (kernel prefere)
cd "${src}"
make mrproper

if [[ -n "${BK_KERNEL_CONFIG:-}" && -f "${BK_KERNEL_CONFIG}" ]]; then
  _i "Usando config custom: ${BK_KERNEL_CONFIG}"
  cp -f "${BK_KERNEL_CONFIG}" .config
  make olddefconfig
else
  _i "Gerando defconfig..."
  make defconfig
fi

_i "Compilando kernel + módulos..."
make -j"${JOBS}"

_i "Instalando módulos em DESTDIR..."
make INSTALL_MOD_PATH="${BK_BUILD_ROOT}" modules_install

_i "Instalando imagem do kernel em /boot (DESTDIR)..."
mkdir -p -- "${BK_BUILD_ROOT}/boot"

# Heurística para localizar a imagem conforme arch:
VMLINUX=""
if [[ "${KARCH}" == "x86_64" || "${KARCH}" == "x86" ]]; then
  VMLINUX="arch/x86/boot/bzImage"
elif [[ "${KARCH}" == "arm64" ]]; then
  VMLINUX="arch/arm64/boot/Image"
else
  # fallback
  VMLINUX="vmlinux"
fi

if [[ ! -f "${VMLINUX}" ]]; then
  _w "imagem não encontrada em ${VMLINUX}; tentando fallback vmlinux"
  VMLINUX="vmlinux"
fi
[[ -f "${VMLINUX}" ]] || _die "imagem do kernel não encontrada (nem bzImage/Image nem vmlinux)"

install -m 0644 "${VMLINUX}" "${BK_BUILD_ROOT}/boot/vmlinuz-${BK_PKG_VERSION}"

# System.map e config
if [[ -f System.map ]]; then
  install -m 0644 System.map "${BK_BUILD_ROOT}/boot/System.map-${BK_PKG_VERSION}"
fi
if [[ -f .config ]]; then
  install -m 0644 .config "${BK_BUILD_ROOT}/boot/config-${BK_PKG_VERSION}"
fi

_o "Concluído: kernel instalado em ${BK_BUILD_ROOT}/boot e módulos em ${BK_BUILD_ROOT}/lib/modules"
