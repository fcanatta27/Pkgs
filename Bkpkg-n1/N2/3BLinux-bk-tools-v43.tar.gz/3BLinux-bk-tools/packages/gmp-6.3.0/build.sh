#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, make, wget, tar
#   - Runtime: libc
#
#
# Dependências:
#   - Build: gcc, make, bash
#   - Runtime: libc
#
set -Eeuo pipefail

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

TMPDIR="${TMPDIR:-/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

TARBALL="$TMPDIR/gmp-${BK_PKG_VERSION}.tar.gz"
SRC_DIR="$TMPDIR/src-gmp-${BK_PKG_VERSION}"
BUILD_DIR="$TMPDIR/build-gmp-${BK_PKG_VERSION}"

wget -O "$TARBALL" "https://ftp.gnu.org/gnu/gmp/gmp-6.3.0.tar.xz"
rm -rf "$SRC_DIR" "$BUILD_DIR"
mkdir -p "$SRC_DIR" "$BUILD_DIR"
tar -xf "$TARBALL" -C "$SRC_DIR"

cd "$BUILD_DIR"
"$SRC_DIR"/gmp-${BK_PKG_VERSION}/configure --prefix=/usr
make -j"$JOBS"
make DESTDIR="$BK_BUILD_ROOT" install
