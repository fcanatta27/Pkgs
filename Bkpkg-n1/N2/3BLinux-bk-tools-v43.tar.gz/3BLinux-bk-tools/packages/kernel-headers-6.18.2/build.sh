#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, make, gcc (host), wget, tar, xz
#   - Runtime: headers em /usr/include
#
# build.sh - kernel-headers-6.18.2 (instala Linux API headers em SYSROOT/usr/include)
set -Eeuo pipefail

if [[ -t 2 ]]; then
  _BK_BOLD="\033[1m"; _BK_RED="\033[31m"; _BK_GRN="\033[32m"; _BK_YEL="\033[33m"; _BK_BLU="\033[34m"; _BK_RST="\033[0m"
else
  _BK_BOLD=""; _BK_RED=""; _BK_GRN=""; _BK_YEL=""; _BK_BLU=""; _BK_RST=""
fi
_bk_info() { echo -e "kernel-headers: ${_BK_BOLD}${_BK_BLU}$*${_BK_RST}" >&2; }
_bk_ok()   { echo -e "kernel-headers: ${_BK_BOLD}${_BK_GRN}$*${_BK_RST}" >&2; }
_bk_err()  { echo -e "kernel-headers: ${_BK_BOLD}${_BK_RED}$*${_BK_RST}" >&2; }

_die(){ _bk_err "$*"; exit 1; }
_require_cmd(){ command -v "$1" >/dev/null 2>&1 || _die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
SYSROOT="${BK_SYSROOT:-${BK_BUILD_ROOT}}"

_require_cmd wget
_require_cmd tar
_require_cmd make

SRC_URL="${SRC_URL:-https://www.kernel.org/pub/linux/kernel/v6.x/linux-${BK_PKG_VERSION}.tar.xz}"
SRC_TARBALL="${TMPDIR}/linux-${BK_PKG_VERSION}.tar.xz"
SRC_DIR="${TMPDIR}/src-linux-${BK_PKG_VERSION}"

_bk_info "Instalando kernel headers: ${BK_PKG_NAME}-${BK_PKG_VERSION}"
_bk_info "SYSROOT=${SYSROOT} (destino: ${SYSROOT}/usr/include)"

mkdir -p -- "${SYSROOT}/usr" "${SRC_DIR}"

if [[ ! -f "${SRC_TARBALL}" ]]; then
  _bk_info "Baixando: ${SRC_URL}"
  wget -O "${SRC_TARBALL}" "${SRC_URL}"
else
  _bk_info "Usando tarball cacheado: ${SRC_TARBALL}"
fi

_bk_info "Extraindo fontes..."
rm -rf -- "${SRC_DIR}"
mkdir -p -- "${SRC_DIR}"
tar -C "${SRC_DIR}" -xf "${SRC_TARBALL}"

src_subdir="${SRC_DIR}/linux-${BK_PKG_VERSION}"
[[ -d "${src_subdir}" ]] || _die "fontes não encontradas: ${src_subdir}"

cd "${src_subdir}"
_bk_info "Preparando árvore..."
make mrproper

_bk_info "Gerando headers..."
make headers

_bk_info "Limpando arquivos não-.h..."
find usr/include -type f ! -name '*.h' -delete

_bk_info "Copiando para sysroot..."
cp -r usr/include "${SYSROOT}/usr/"

_bk_ok "Concluído: headers em ${SYSROOT}/usr/include"
