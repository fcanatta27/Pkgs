#!/usr/bin/env bash
#
# Dependências (comentado)
#   - Build: bash, coreutils, gcc, make, pkg-config, wget, tar, bzip2
#   - Runtime: dbus, glib2, libxfce4util
#
# build.sh - xfconf ${BK_PKG_VERSION}
set -Eeuo pipefail

if [[ -t 2 ]]; then
  B="\033[1m"; R="\033[31m"; G="\033[32m"; Y="\033[33m"; U="\033[34m"; Z="\033[0m"
else
  B=""; R=""; G=""; Y=""; U=""; Z=""
fi
i(){ echo -e "xfconf: ${B}${U}$*${Z}" >&2; }
o(){ echo -e "xfconf: ${B}${G}$*${Z}" >&2; }
w(){ echo -e "xfconf: ${B}${Y}$*${Z}" >&2; }
e(){ echo -e "xfconf: ${B}${R}$*${Z}" >&2; }
die(){ e "$*"; exit 1; }
req(){ command -v "$1" >/dev/null 2>&1 || die "comando requerido não encontrado: $1"; }

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

: "${TMPDIR:=/tmp}"
JOBS="${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}"

SRC_URL="https://archive.xfce.org/src/xfce/xfconf/4.20/xfconf-4.20.0.tar.bz2"
TARBALL="xfconf-4.20.0.tar.bz2"
SRC_DIRNAME="xfconf-4.20.0"

fetch() {
  local out="${TMPDIR}/${TARBALL}"
  if [[ -f "$out" ]]; then i "usando tarball em cache: $out"; return 0; fi
  i "baixando: ${SRC_URL}"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail -o "$out" "${SRC_URL}"
  else
    req wget
    wget -O "$out" "${SRC_URL}"
  fi
}

unpack() {
  local out="${TMPDIR}/${TARBALL}"
  rm -rf -- "${TMPDIR:?}/${SRC_DIRNAME}"
  i "extraindo: $out"
  tar -C "${TMPDIR}" -xf "$out"
}

main() {
  req sh; req tar; req make; req gcc

  fetch
  unpack

  local src="${TMPDIR}/${SRC_DIRNAME}"
  [[ -d "$src" ]] || die "fontes não encontradas: $src"

  rm -rf -- "${BK_BUILD_ROOT:?}/"*
  mkdir -p -- "${BK_BUILD_ROOT}"

  i "configurando..."
  ( cd "$src" && ./configure \
      --prefix=/usr \
      --sysconfdir=/etc \
      --localstatedir=/var \
      --disable-static \
      
  )

  i "compilando..."
  ( cd "$src" && make -j"$JOBS" )

  i "instalando em DESTDIR..."
  ( cd "$src" && make DESTDIR="${BK_BUILD_ROOT}" install )

  o "OK: ${BK_PKG_NAME} ${BK_PKG_VERSION} -> ${BK_BUILD_ROOT}"
}

main "$@"
