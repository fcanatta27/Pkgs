#!/usr/bin/env bash
#
# Dependencias (comentado)
#   - Build: bash, coreutils, gcc, meson, ninja, pkg-config, glib2, expat
#   - Runtime: glib2
#
set -Eeuo pipefail

: "${BK_PKG_NAME:?}"
: "${BK_PKG_VERSION:?}"
: "${BK_BUILD_ROOT:?}"

TMPDIR=${TMPDIR:-/tmp}
JOBS=${BK_JOBS:-$(nproc 2>/dev/null || echo 1)}

SRC_URL='https://gitlab.freedesktop.org/polkit/polkit/-/archive/125/polkit-125.tar.gz'
TARBALL='polkit-125.tar.gz'
SRCDIR='polkit-125'

req(){ command -v "polkit" >/dev/null 2>&1 || { echo "polkit: falta comando: polkit" >&2; exit 1; }; }
msg(){ echo "[polkit] polkit 125 https://gitlab.freedesktop.org/polkit/polkit/-/archive/125/polkit-125.tar.gz polkit-125.tar.gz polkit-125 bash, coreutils, gcc, meson, ninja, pkg-config, glib2, expat glib2 -Dman=false" >&2; }

fetch(){
  local out="${TMPDIR}/${TARBALL}"
  if [[ -f "${out}" ]]; then msg "usando cache ${out}"; return 0; fi
  msg "baixando ${SRC_URL}"
  if command -v curl >/dev/null 2>&1; then curl -L --fail -o "${out}" "${SRC_URL}"; else wget -O "${out}" "${SRC_URL}"; fi
}

unpack(){
  rm -rf "${TMPDIR}/build-src-polkit-${BK_PKG_VERSION}"
  mkdir -p "${TMPDIR}/build-src-polkit-${BK_PKG_VERSION}"
  tar -C "${TMPDIR}/build-src-polkit-${BK_PKG_VERSION}" -xf "${TMPDIR}/${TARBALL}"
}

main(){
  for t in tar gcc; do req ""; done
  req meson; req ninja
  fetch
  unpack
  local top="${TMPDIR}/build-src-polkit-${BK_PKG_VERSION}"
  local src="${top}/${SRCDIR}"
  if [[ ! -d "${src}" ]]; then src="$(find "${top}" -maxdepth 2 -type d -name "${SRCDIR}" | head -n1 || true)"; fi
  [[ -d "${src}" ]] || { echo "polkit: fontes nao encontradas em ${src}" >&2; exit 1; }

  rm -rf "${BK_BUILD_ROOT:?}"/*
  mkdir -p "${BK_BUILD_ROOT}"

  local bdir="${TMPDIR}/build-polkit-${BK_PKG_VERSION}"
  rm -rf "${bdir}"; mkdir -p "${bdir}"

  msg "configurando (meson)..."
  ( cd "${bdir}" && meson setup "${src}" --prefix=/usr --buildtype=release -Ddefault_library=shared -Dman=false )

  msg "compilando (ninja)..."
  ninja -C "${bdir}" -j"${JOBS}"

  msg "instalando (DESTDIR)..."
  DESTDIR="${BK_BUILD_ROOT}" ninja -C "${bdir}" install

  msg "ok"
}

main "polkit 125 https://gitlab.freedesktop.org/polkit/polkit/-/archive/125/polkit-125.tar.gz polkit-125.tar.gz polkit-125 bash, coreutils, gcc, meson, ninja, pkg-config, glib2, expat glib2 -Dman=false"
