# Auditoria de dependências dos scripts de construção

Esta auditoria foi feita automaticamente varrendo todos os `packages/*/build.sh` e
lendo as linhas de comentários de dependências (`Build`/`Runtime`).

- Todos os scripts passaram em `bash -n` (checagem de sintaxe).
- Foi feita uma tentativa de mapear cada dependência comentada para um pacote bk
  existente ou para ferramentas básicas do toolchain (gcc, make, python, etc).
- Foram identificadas cinco bibliotecas centrais que ainda não existiam como pacotes e foram criadas:
  - lzo (para btrfs-progs)
  - libxml2 (para gettext)
  - elfutils (para kernel / ferramentas ELF)
  - libslirp (para qemu)
  - libfdt (para qemu / device tree)

Vários outros "itens" marcados como faltando eram na verdade frases explicativas,
arquivos de configuração (`/etc/*`), caminhos de sistema ou bibliotecas já cobertas
por outros pacotes (por exemplo, glibc, libuuid, libblkid, libtinfo, etc.), e por isso
não foram transformados em pacotes separados.

Se você quiser no futuro, é possível refinar manualmente os comentários de dependência
em cada `build.sh` para remover textos descritivos e manter apenas nomes de pacotes,
o que deixará a próxima auditoria ainda mais precisa.


---

## Atualização da auditoria na versão v40

Foi feita uma nova varredura automática em **todos** os `packages/*/build.sh`
deste bundle (v40), incluindo os pacotes adicionados recentemente
(`ffmpeg`, `firefox`, `firefox-bin`, `pciutils`, `usbutils`, `UDisks`, `Sysstat`,
`pm-utils`, `acpid`, `autofs`, `UDisks`, `Git`, etc.).

Os resultados principais:

1. **Nenhuma nova biblioteca "obrigatória" faltando**
   - Todas as dependências estruturais de toolchain, userland base, Xorg e XFCE
     já estão cobertas pelos pacotes existentes (incluindo `lzo`, `libxml2`,
     `elfutils`, `libslirp`, `libfdt` criados na primeira auditoria).
   - Os itens que continuam aparecendo na varredura como "faltando" são, em sua
     maioria:
       - palavras de texto dos comentários (ex.: “este”, “instala”, “tmp”);
       - bibliotecas opcionais de multimídia (ex.: `libx264`, `libx265`, `libvpx`,
         `libvorbis`, `libopus`) usadas em **flags comentadas** do `ffmpeg`;
       - toolchains alternativas para builds pesados (`rust`, `llvm`, `nodejs`)
         usados no build *from source* do Firefox.

2. **Multimídia: dependências opcionais**
   - O script do `ffmpeg` foi escrito com diversas flags comentadas e documentadas
     (codecs opcionais). Estes codecs não são necessários para o funcionamento
     básico do sistema ou de um desktop XFCE funcional.
   - Caso você queira empacotar `libx264`, `libx265`, `libvpx`, etc., pode seguir
     o mesmo padrão dos demais `build.sh` e habilitar as flags correspondentes.

3. **Firefox: toolchain avançada**
   - O build *from source* do Firefox exige uma toolchain moderna (Rust, clang/LLVM,
     nodejs, ICU, NSS/NSPR). O bundle também oferece o pacote `firefox-bin`, que
     usa o tarball binário oficial e evita a necessidade dessa toolchain pesada.
   - Portanto, para um desktop 3BLinux funcional, basta usar o `firefox-bin`.

Conclusão: do ponto de vista de dependências **mínimas necessárias** para construir
o sistema completo (base + Xorg + XFCE + ferramentas principais), o conjunto de
scripts `packages/*/build.sh` do bundle v40 já está coerente e cobrindo tudo que
é realmente necessário. As dependências restantes são opcionais ou relacionadas
a cenários avançados (multimídia máxima, build completo do Firefox via source).
