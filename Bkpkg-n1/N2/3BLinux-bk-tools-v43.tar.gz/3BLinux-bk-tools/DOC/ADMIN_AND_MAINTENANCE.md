# 3BLinux – Guia Geral de Administração e Manutenção com bk-tools

Este documento organiza todos os tutoriais e guias do projeto e sugere
fluxos de uso para construir, manter e atualizar o 3BLinux usando o kit `bk-tools`.

---

## 1. Mapa da documentação (DOC/)

Atualmente, os principais arquivos em `DOC/` são:

- `README.md`
  - Visão geral do projeto 3BLinux e do kit `bk-tools`.

- `PREPARE_BUILD_FROM_ZERO.md`
  - Como preparar o host de build.
  - Como preparar o rootfs `3BLinux/`.
  - Como rodar `bk-cli-stage-system` e obter um sistema base.

- `INSTALL_GUIDE.md`
  - Como gerar initramfs com `bk-initramfs`.
  - Como gerar ISO com `bk-mkiso`.
  - Como bootar em QEMU.
  - Como usar `bk-install` dentro do live para instalar em disco.

- `BOOT_GUIDE.md`
  - Guia focado na sequência de boot, kernel, initramfs e GRUB.

- `INIT_AND_SERVICES.md`
  - Detalha o init do 3BLinux, `/etc/init.d`, `/etc/rcS.d`.
  - Explica `/etc/sysconfig/rc` e perfis de serviços.
  - Mostra a interação com `bk-reparo` e `bk-init-reparo`.

- `UPDATES_AND_REPO.md`
  - Explica o modelo de pacotes do `bk`.
  - Orienta uso de `bk-upstream` e `bk-update`.
  - Detalha como montar repositórios stable/unstable.
  - Mostra estratégias de sincronização entre múltiplos sistemas.

---

## 2. Fluxo de trabalho recomendado

### 2.1 Construção do sistema (do zero até rootfs funcional)

1. Leia `PREPARE_BUILD_FROM_ZERO.md`
2. Prepare o host (toolchain, meson, ninja, etc.)
3. Prepare o rootfs `./3BLinux` (diretórios, permissões)
4. Execute `bk-cli-stage-system` para montar o userland base + toolchain de desenvolvimento.
5. Ajuste perfis de serviços em `/etc/sysconfig/rc` conforme desejado.
6. Rode `bk-reparo --root 3BLinux` para validar e corrigir detalhes.

### 2.2 Boot, initramfs, ISO e QEMU

1. Leia `BOOT_GUIDE.md` + `INSTALL_GUIDE.md`
2. Use `bk-initramfs` para gerar o initramfs (com BusyBox + init).
3. Use `bk-mkiso` para gerar uma ISO bootável.
4. Use `bk-qemu` para testar o boot em QEMU.
5. Dentro do live, use `bk-install` para instalar em um disco real/virtual.

### 2.3 Serviços e perfis de boot

1. Leia `INIT_AND_SERVICES.md`
2. Ajuste `/etc/sysconfig/rc` conforme o perfil desejado (server, desktop-lite, lab, etc.).
3. Rode `bk-reparo` e/ou `bk-init-reparo` para sincronizar os links em `rcS.d`.
4. Teste serviços manualmente com `/etc/init.d/<servico> start/stop` quando necessário.

### 2.4 Upgrades e repositórios binários

1. Leia `UPDATES_AND_REPO.md`
2. Mantenha um arquivo `DOC/upstream.list` com os programas críticos.
3. Use `bk-upstream` para detectar novas versões upstream.
4. Atualize scripts de build em `packages/*/build.sh` quando for subir de versão.
5. Construa pacotes via `bk` e publique em repositórios `stable`/`unstable`.
6. Use `bk-update` para aplicar upgrades nos rootfs/sistemas.

---

## 3. Visão dos principais comandos do kit bk-tools

Abaixo, uma visão classificada por “fase”:

### 3.1 Construção e toolchain

- `bk-cli-stage-base`
  - Monta o stage-base inicial (core, shell, ferramentas mínimas).

- `bk-cli-stage-system`
  - Amplia para um userland completo com toolchain de desenvolvimento.

- `bk build <pacote>`
  - Constrói pacotes individualmente, usando `packages/<name-version>/build.sh`.

### 3.2 Rootfs, init e initramfs

- `bk-reparo`
  - Faz sanity-check do rootfs e corrige:
    - diretórios básicos
    - permissões
    - perfis de serviços (`/etc/sysconfig/rc`)
    - caches (fontes/ícones/menus), via `bk-cache-alternative`

- `bk-init-reparo`
  - Focado no init/initramfs.
  - Garante `/sbin/init`, `inittab`, `rcS`, links em `rcS.d`.
  - Reinstala BusyBox via bk, se necessário.
  - Reconstrói initramfs (opcional, via flag).

- `bk-initramfs`
  - Gera o arquivo de initramfs (`/boot/initramfs.img`) baseado no rootfs e BusyBox.

### 3.3 ISO e QEMU

- `bk-mkiso`
  - Cria ISO bootável a partir do rootfs + kernel + initramfs.

- `bk-qemu`
  - Gerencia imagens QEMU e inicializa VMs de teste.
  - Permite criar, listar, apagar e rodar imagens em diretório dedicado.

### 3.4 Instalação em disco

- `bk-install`
  - Instalador automatizado (modo live → disco).
  - Detecta discos, cria partições, formata, instala rootfs, configura GRUB, idioma, teclado, rede, usuários.

### 3.5 Usuários, skeleton e ambiente

- `bk-adduser`
  - Criação de usuários alinhada com o skeleton `/etc/skel` do 3BLinux.
  - Copia `.bashrc`, configura shell, home, grupos.

- `/etc/skel`
  - Arquivos padrão de usuário (prompt, cores, git, bash-completion).

### 3.6 Upstream, repositório e upgrade

- `bk-upstream`
  - Lê arquivo de definições (name|current|url|regex) e aponta novas versões upstream.

- `bk-update`
  - Lê `bk-repo.txt` remoto (HTTP/rsync) e aplica upgrades binários de forma automática.

- `bk-cache-alternative`
  - Regenera caches de fontes (`fc-cache`), ícones (`gtk-update-icon-cache`), desktop (`update-desktop-database`) e MIME (`update-mime-database`).

---

## 4. Estratégias de manutenção contínua

### 4.1 Manutenção semanal em uma máquina 3BLinux

Sugestão de rotina:

```sh
# 1) Upgrade via repositório stable
bk-update --repo https://example.com/3blinux/stable --root /

# 2) Reparo geral
bk-reparo --root /

# 3) Reparo init/initramfs se houve atualizações críticas
bk-init-reparo --root / --rebuild-initramfs
```

### 4.2 Manutenção em ambiente de build

Antes de começar uma nova grande rodada de builds:

```sh
cd 3BLinux-bk-tools
bin/bk-upstream -f DOC/upstream.list > DOC/upstream-report-$(date +%F).txt
```

Analise o relatório, escolha o que atualizar, e proceda com:

- ajuste de `build.sh` dos pacotes envolvidos
- reconstrução via `bk build`
- publicação em `unstable` → testes → promoção para `stable`.

### 4.3 Debug de problemas de boot

Se um upgrade ou alteração em init quebrar o boot:

1. Boot via ISO de recuperação (ou QEMU com ISO).
2. Monte o rootfs alvo em `/mnt`.
3. Rode:

```sh
chroot /mnt /bin/sh
bk-reparo --root /
bk-init-reparo --root / --rebuild-initramfs
```

4. Reinstale GRUB se necessário (`grub-install`, `grub-mkconfig`) de acordo com o `BOOT_GUIDE.md`.

---

## 5. Próximos passos sugeridos

Se você quiser ir além:

- Adicionar logs mais detalhados aos builds (por exemplo `bk build <pkg> 2>&1 | tee LOGS/<pkg>.log`).
- Criar um documento `RELEASE_NOTES.md` que vincule um “release 3BLinux X.Y” a uma foto dos pacotes/versões presentes no repo stable.
- Integrar testes automatizados (scripts que checam serviços e comandos básicos após um upgrade).

O objetivo é que, com esses guias, você tenha uma visão completa:

- de como construir e instalar
- de como o init e serviços funcionam
- de como manter e atualizar o sistema em produção
- tudo orquestrado pelo kit `bk-tools`.


---

## 3. Fluxo completo: do host vazio ao login gráfico

### 3.1 Resumo em fases

1. **Preparação do host e rootfs**
   - Leia `PREPARE_BUILD_FROM_ZERO.md`.
   - Instale ferramentas de desenvolvimento no host.
   - Crie `./3BLinux` e garanta que os diretórios básicos existem.

2. **Cross-toolchain e temporary tools**
   - Use `bk-cli` com os scripts:
     - `kernel-headers-6.18.2`
     - `binutils-2.45.1-pass1`
     - `gcc-15.2.0-pass1`
     - `glibc-2.42` (fase startfiles/headers)
     - `gcc-15.2.0` (toolchain final)
   - No final, você tem uma toolchain isolada no rootfs.

3. **Userland base + toolchain-devel**
   - `bk-cli-stage-base`
   - `bk-cli-stage-system`

4. **Stack gráfico (Xorg + desktop)**
   - `bk-cli-stage-xorg`
   - escolha um dos perfis:
     - `bk-cli-stage-desktop-min`
     - `bk-cli-stage-desktop-full`
     - `bk-cli-stage-desktop-xfce`

5. **Notebooks (perfis laptop)**
   - `bk-cli-stage-laptop`
   - `bk-power-profile laptop`
   - use `bk-hardware-detect` para confirmar suporte Wi-Fi/GPU/ACPI.

6. **Boot, ISO e instalação**
   - `bk-initramfs`
   - `bk-mkiso`
   - `bk-qemu` para testes em VM
   - `bk-install` dentro do ambiente live para instalar em disco.

### 3.2 Manutenção pós-login

Depois que o sistema estiver instalado e você já estiver logando (console ou XFCE):

- **Verificações iniciais**
  - `bk-hardware-detect`:
    - verifica Wi-Fi, GPU, mensagens de firmware, ACPI.
  - `bk-resolve --heal-desktop`:
    - corrige permissões, links, libs faltando (quando possível);
    - reconstrói caches de fontes, ícones, MIME, desktop, GSettings;
    - reinicia serviços conforme `/etc/sysconfig/rc`.

- **Ciclos periódicos de manutenção**
  - semanal/mensal:
    - `bk-reparo` (raiz em produção);
    - backup de `/etc`, `/home` e `/var/lib`.
  - após adicionar/remover pacotes no repositório:
    - `bk-repo-scan` no servidor para regenerar `bk-repo.txt`.

- **Ajustes de energia e perfis**
  - em notebooks:
    - `bk-power-profile laptop` para máximo de economia;
  - em desktops:
    - `bk-power-profile desktop` ou `bk-power-profile performance`.

---

## 4. Relação dos principais comandos bk (resumo rápido)

- `bk` – empacota, instala, remove e lista pacotes.
- `bk-cli` – wrapper de conveniência para rodar scripts de construção em `packages/`.
- `bk-cli-stage-*` – workflows de alto nível:
  - `stage-base`, `stage-system`, `stage-xorg`,
  - `stage-desktop-min`, `stage-desktop-full`, `stage-desktop-xfce`,
  - `stage-laptop`.
- `bk-initramfs` – gera um initramfs completo (BusyBox + init).
- `bk-mkiso` – gera ISO de boot.
- `bk-qemu` – gerencia VMs QEMU para testar o sistema.
- `bk-install` – instala o 3BLinux em disco a partir da ISO/rootfs.
- `bk-reparo` / `bk-init-reparo` – reparos gerais do sistema e de init/boot.
- `bk-resolve` – análise e correção fina de programas, libs, caches e serviços.
- `bk-hardware-detect` – diagnóstico de hardware (Wi-Fi, GPU, firmware, ACPI).
- `bk-power-profile` – perfis rápidos de energia.

Para detalhes linha a linha de cada comando, consulte a seção correspondente
nos demais documentos em `DOC/`.
