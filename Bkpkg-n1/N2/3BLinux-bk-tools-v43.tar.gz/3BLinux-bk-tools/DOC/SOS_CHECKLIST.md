
# 3BLinux – Modo SOS / Recuperação de Sistema com bk-tools

Este guia assume que você já tem o **bundle bk-tools** (3BLinux-bk-tools) em algum lugar
acessível (pendrive, partição de utilitários, etc.) e que o root do sistema a ser
recuperado fica montado em, por exemplo, `/mnt/3blinux`.

A ideia é ter um **fluxo único e repetível** para recuperar:

- toolchain
- init + rc + ttys
- serviços básicos (syslog, rede, cron, ssh, dbus, etc.)
- Xorg + desktop mínimo

Tudo **usando apenas o kit bk-tools + stages**.

---

## 1. Preparar ambiente de recuperação

1. Bootar a partir de:
   - ISO de 3BLinux gerada com `bk-mkiso`, **ou**
   - outro Linux qualquer (live) com acesso ao disco.

2. Descobrir as partições:

   ```sh
   lsblk -f
   ```

3. Montar o root do 3BLinux:

   ```sh
   mkdir -p /mnt/3blinux
   mount /dev/sdXn /mnt/3blinux
   ```

   Se tiver `/boot` separado, monte também:

   ```sh
   mkdir -p /mnt/3blinux/boot
   mount /dev/sdXm /mnt/3blinux/boot
   ```

4. Montar pseudo-fs necessários:

   ```sh
   mount -t proc /proc /mnt/3blinux/proc
   mount --rbind /sys  /mnt/3blinux/sys
   mount --rbind /dev  /mnt/3blinux/dev
   mount --rbind /run  /mnt/3blinux/run
   ```

---

## 2. Montar o kit bk-tools dentro do rootfs

Supondo que o tarball dos bk-tools esteja em, por exemplo, `/root/3BLinux-bk-tools.tar.gz`
no ambiente live:

```sh
cd /mnt/3blinux
tar -xvf /caminho/para/3BLinux-bk-tools.tar.gz
# isso cria o diretório 3BLinux-bk-tools/ com bin/, packages/, etc.
export PATH="/mnt/3blinux/3BLinux-bk-tools/bin:${PATH}"
```

Confirme:

```sh
bk --help
```

---

## 3. Entrar em chroot “seguro” usando o bk-chroot

Você pode usar o `bk-chroot` do kit para entrar de forma padronizada:

```sh
cd /mnt/3blinux/3BLinux-bk-tools/bin
./bk-chroot enter /mnt/3blinux
```

Ou, se quiser apenas rodar um comando rápido **sem permanecer** dentro:

```sh
./bk-chroot run /mnt/3blinux -- bk status
./bk-chroot run /mnt/3blinux -- uname -a
```

---

## 4. Sanidade geral do sistema com bk-reparo

Dentro do chroot (prompt do 3BLinux), rode:

```sh
cd /3BLinux-bk-tools/bin
./bk-reparo --root /        # root interno do chroot é /
```

O que esse comando faz, em resumo:

- verifica e corrige estrutura básica de diretórios (`/bin`, `/sbin`, `/usr`, `/var`, `/tmp`, etc.);
- repara permissões de arquivos e diretórios críticos;
- repara/valida:
  - toolchain (gcc, binutils, glibc, etc.)
  - bk database (`/var/lib/bk`, cache de pacotes)
  - perfis de serviços (`/etc/sysconfig/rc`)
  - caches de ícones, fontes, mime, desktop;
- se detectar Xorg instalado:
  - cria/repara `/etc/X11/xinit/xinitrc`;
  - cria `/etc/X11/xinit/xinitrc.d` e skeleton `~/.xinitrc` em `/etc/skel`;
  - reforça atualização de caches do desktop.

Sempre que possível, ele corrige automaticamente; falhas graves são logadas em vermelho.

---

## 5. Conserto do init, ttys e initramfs com bk-init-reparo

Ainda dentro do chroot:

```sh
cd /3BLinux-bk-tools/bin
./bk-init-reparo --root /
```

Isso vai:

- validar/corrigir:
  - `/sbin/init`, `/etc/inittab`, scripts `rc` e runlevels;
  - scripts de serviço em `/etc/init.d` e links em `/etc/rc?.d`;
  - `getty` em consoles (tty1, tty2...);
  - configurações base em `/etc` (hosts, resolv.conf se configurado pelo sistema);
- se Xorg estiver presente:
  - garantir estrutura X11 coerente com o bk-reparo;
- garantir que o `busybox` essencial esteja instalado (via bk, se necessário);
- reconstruir/initramfs se for necessário, usando:
  - kernel instalado em `/boot`;
  - ferramentas do `bk-initramfs`.

Após esse passo, em muitos casos o sistema já volta a bootar.

---

## 6. Reinstalar base/toolchain se estiver quebrado

Se você sabe que a base (stage-base / stage-system) foi comprometida ou parcialmente
apagada, você pode remontar tudo com os stages:

1. Ainda no chroot, exporte um ROOTFS explícito:

   ```sh
   export ROOTFS=/
   cd /3BLinux-bk-tools/bin
   ```

2. Rodar stage base + system (se necessário):

   ```sh
   ./bk-cli-stage-base          # recompõe toolchain/base
   ./bk-cli-stage-system        # adiciona serviços e userland de sistema
   ```

Esses scripts usam o bk para:

- reconstruir gcc, binutils, glibc, coreutils, bash, etc.;
- reinstalar serviços essenciais (syslog, cron, rede, etc.);
- reinstalar o ambiente de desenvolvimento.

---

## 7. Reinstalar/curar Xorg e desktop

Se o problema é especificamente gráfico (Xorg não sobe, desktop quebrado):

1. Reconstruir stack Xorg:

   ```sh
   export ROOTFS=/
   ./bk-cli-stage-xorg
   ```

2. Reconstruir desktop completo (base + Xorg + twm + xterm + GTK + temas):

   ```sh
   export ROOTFS=/
   ./bk-cli-stage-desktop-full
   ```

3. Reforçar reparo completo:

   ```sh
   ./bk-reparo --root /
   ./bk-init-reparo --root /
   ```

---

## 8. Regenerar bootloader (GRUB) se necessário

Se o GRUB estiver quebrado ou desatualizado, ainda dentro do chroot:

1. Reinstalar GRUB no disco (exemplo em `/dev/sda`):

   ```sh
   grub-install /dev/sda
   ```

2. Regenerar configuração:

   ```sh
   grub-mkconfig -o /boot/grub/grub.cfg
   ```

3. Se usar `bk-mkiso` para gerar ISO live atualizada, você pode:

   - sair do chroot,
   - gerar uma nova ISO,
   - testar pelo `bk-qemu` antes de reinstalar.

---

## 9. Sair do chroot e desmontar tudo

Quando terminar:

```sh
exit   # sai do chroot
umount -R /mnt/3blinux/proc
umount -R /mnt/3blinux/sys
umount -R /mnt/3blinux/dev
umount -R /mnt/3blinux/run
umount  /mnt/3blinux/boot  # se montou separadamente
umount  /mnt/3blinux
```

Depois basta rebootar:

```sh
reboot
```

---

## 10. Resumo rápido do fluxo SOS

Para um uso “de cabeça”, o fluxo típico é:

```sh
# fora do chroot
mount /dev/sdXn /mnt/3blinux
mount proc /mnt/3blinux/proc -t proc
mount --rbind /sys /mnt/3blinux/sys
mount --rbind /dev /mnt/3blinux/dev
mount --rbind /run /mnt/3blinux/run
tar -xvf 3BLinux-bk-tools.tar.gz -C /mnt/3blinux
chroot /mnt/3blinux /bin/bash

# dentro do chroot
cd /3BLinux-bk-tools/bin
./bk-reparo --root /
./bk-init-reparo --root /
./bk-cli-stage-system         # se precisar reconstruir a base
./bk-cli-stage-xorg           # se o problema for Xorg
./bk-cli-stage-desktop-full   # se quiser remontar o desktop completo
grub-install /dev/sda         # se o bootloader estiver quebrado
grub-mkconfig -o /boot/grub/grub.cfg
```

Com isso você tem um **checklist SOS padronizado** para recuperar um sistema 3BLinux
apenas com o kit bk-tools e os stages.
