# Tutorial – Como criar scripts de construção para o 3bLinux (bk-*)

Este tutorial explica em detalhes como escrever scripts `build-*.sh` em `packages/`
para que funcionem corretamente com o `bk-build-wrapper`.

## 1. Estrutura padrão de um script de build

Um script típico gerado no kit segue o formato:

```bash
#!/usr/bin/env bash
set -euo pipefail

NAME="foo"
VER="1.0"
TARBALL_NAME="foo-1.0.tar.xz"
URL="https://exemplo.org/foo/foo-1.0.tar.xz"

# Dependências (resumo):
#   bar >= 2.0
#   pkg-config
#   zlib

SCRIPT_NAME="${0##*/}"
BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/usr}"
SYSCONFDIR="${SYSCONFDIR:-/etc}"
LOCALSTATEDIR="${LOCALSTATEDIR:-/var}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[bk-build] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[bk-build] %s\n' "$*"; }

fetch(){
  local out="$1"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 --retry-delay 1 -o "$out" "$URL"
  else
    wget -O "$out" "$URL"
  fi
}

prepare(){
  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"
}

extract_src(){
  local tarball="$1"
  info "Extraindo: $tarball"
  tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
}

main(){
  (command -v curl >/dev/null 2>&1 || command -v wget >/dev/null 2>&1) || die "curl ou wget necessário"
  command -v tar >/dev/null 2>&1 || die "tar não encontrado"
  command -v make >/dev/null 2>&1 || die "make não encontrado"
  (command -v gcc >/dev/null 2>&1 || command -v cc >/dev/null 2>&1) || die "gcc/cc não encontrado"

  prepare
  local tarball="${BUILD_ROOT}/${TARBALL_NAME}"
  info "Baixando: $URL"
  fetch "$tarball"
  extract_src "$tarball"
  cd "$SRC_DIR"

  info "Configurando (autotools)"
  ./configure \
    --prefix="$PREFIX" \
    --sysconfdir="$SYSCONFDIR" \
    --localstatedir="$LOCALSTATEDIR"

  info "Compilando"
  make -j"$JOBS"

  info "Instalando em DESTDIR: $PKG_ROOT"
  make DESTDIR="$PKG_ROOT" install

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
```

## 2. Pontos importantes

1. **Shebang**: sempre use `#!/usr/bin/env bash`.
2. **`set -euo pipefail`**: garante que erros parem o script.
3. **Variáveis principais**:
   - `NAME`, `VER`, `TARBALL_NAME`, `URL`.
4. **Diretórios**:
   - `BUILD_ROOT` – diretório temporário do build;
   - `SRC_DIR` – onde o código-fonte é extraído;
   - `PKG_ROOT` – árvore de instalação (staging), que será empacotada.
5. **Configuração de prefixos**:
   - `PREFIX=/usr`, `SYSCONFDIR=/etc`, `LOCALSTATEDIR=/var`.

## 3. Autotools vs Meson vs CMake

### 3.1. Autotools

Use:

```sh
./configure \
  --prefix="$PREFIX" \
  --sysconfdir="$SYSCONFDIR" \
  --localstatedir="$LOCALSTATEDIR" \
  [opções extras]

make -j"$JOBS"
make DESTDIR="$PKG_ROOT" install
```

### 3.2. Meson

Exemplo:

```bash
command -v meson >/dev/null 2>&1 || die "meson não encontrado"
command -v ninja >/dev/null 2>&1 || die "ninja não encontrado"

meson setup build \
  --prefix="$PREFIX" \
  --sysconfdir="$SYSCONFDIR" \
  --localstatedir="$LOCALSTATEDIR" \
  -Ddoc=disabled

ninja -C build -j "$JOBS"
DESTDIR="$PKG_ROOT" ninja -C build install
```

### 3.3. CMake

Exemplo:

```bash
cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX="$PREFIX"

cmake --build build -- -j"$JOBS"
DESTDIR="$PKG_ROOT" cmake --install build
```

## 4. Pacotes “meta”

Para pacotes que não compilam nada, mas orquestram outros builds (como `autotools-1.0`):

- o script pode chamar:

  ```bash
  ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
  BK="${ROOT_DIR}/tools/bk-build-wrapper"

  "$BK" m4-1.4.19
  "$BK" autoconf-2.72
  ...
  ```

- sem usar `PKG_ROOT` diretamente.

## 5. Scripts para fontes, temas, ícones, etc.

Pacotes como:

- fontes (`.ttf`, `.otf`, `.pcf`);
- temas de ícones;
- temas de cursor;

geralmente:

1. descompactam o tarball;
2. copiam arquivos para:

   - `/usr/share/fonts/...`
   - `/usr/share/icons/...`

Exemplo genérico:

```bash
mkdir -p "${PKG_ROOT}/usr/share/fonts/foo"
find . -type f -name '*.ttf' -print0 | \
  xargs -0 -I '{}' cp '{}' "${PKG_ROOT}/usr/share/fonts/foo/"
```

Ou para ícones:

```bash
mkdir -p "${PKG_ROOT}/usr/share/icons/FooTheme"
cp -a FooTheme/* "${PKG_ROOT}/usr/share/icons/FooTheme/"
```

## 6. Dicas de depuração de scripts de build

- Rode o script manualmente:

  ```sh
  bash -x build-foo-1.0.sh
  ```

- Verifique o que está em `PKG_ROOT`:

  ```sh
  tree /tmp/foo-build/pkgroot
  ```

- Veja se arquivos foram instalados nos caminhos esperados.

## 7. Boas práticas

- Sempre documente dependências no cabeçalho.
- Evite caminhos absolutos específicos da sua máquina.
- Use variáveis `PREFIX`, `SYSCONFDIR`, etc., para manter flexibilidade.
- Não instale fora de `PKG_ROOT` (isso quebraria o empacotamento).

## 8. Resumo

Para criar um script de construção no 3bLinux:

1. Copie um script existente similar.
2. Ajuste `NAME`, `VER`, `URL`, `TARBALL_NAME`.
3. Adapte `./configure` / `meson` / `cmake`.
4. Instale em `PKG_ROOT`.
5. Teste com `tools/bk-build-wrapper <nome-versao>`.
