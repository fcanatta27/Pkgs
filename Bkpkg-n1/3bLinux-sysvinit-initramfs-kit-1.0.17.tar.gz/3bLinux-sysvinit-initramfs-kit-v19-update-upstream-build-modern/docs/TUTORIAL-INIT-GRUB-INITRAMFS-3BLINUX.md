# Tutorial – Init, initramfs, GRUB e scripts de inicialização no 3bLinux

Este tutorial destrincha:

- o papel do GRUB;
- como o initramfs funciona;
- como o `/sbin/init` (sysvinit) dá sequência ao boot;
- como escrever/ajustar scripts de inicialização;
- como personalizar e manter o GRUB e o initramfs.

## 1. GRUB – bootloader

O GRUB (GRand Unified Bootloader):

- é instalado no disco (MBR/EFI);
- carrega kernel + initramfs;
- exibe menu de boot com entradas configuradas.

### 1.1. Arquivo de configuração

Na ISO e em sistemas BIOS/Legacy, o GRUB usa:

- `/boot/grub/grub.cfg`

Exemplo básico:

```cfg
set default=0
set timeout=5

menuentry "3bLinux 1.0" {
    linux /boot/vmlinuz-3blinux root=/dev/sda1 rw quiet
    initrd /boot/initramfs-3blinux.img
}
```

Em sistemas EFI, você pode ter uma partição EFI montada em `/boot/efi` e entradas de `grub.cfg` similares.

## 2. Initramfs

O **initramfs** é uma imagem (geralmente `.img`) que:

- contém um pequeno sistema de arquivos (cpio+gzip/xz);
- é montado em memória pelo kernel logo no boot;
- executa um script `init` interno.

Esse `init` geralmente:

1. monta pseudo-sistemas (`/proc`, `/sys`, `/dev`);
2. detecta o dispositivo raiz (`root=` ou por UUID/label);
3. monta o root real;
4. executa `switch_root` ou `pivot_root` para o root real e chama `/sbin/init`.

### 2.1. Conteúdo típico

- `/init` – script principal;
- `/bin/busybox` – binário multifunções;
- módulos de kernel necessários (`/lib/modules/...`).

No 3bLinux, o script `bk-initramfs` controla:

- o que entra no initramfs;
- como o `init` é gerado;
- as correções automáticas em caso de mudanças no rootfs/kernel.

## 3. `/sbin/init` (sysvinit) e `/etc/inittab`

Depois do `switch_root`, o kernel chama:

- `/sbin/init`

No 3bLinux, é o `sysvinit`, que lê `/etc/inittab`.

Exemplo simplificado:

```ini
id:3:initdefault:

si::sysinit:/etc/init.d/rcS

l0:0:wait:/etc/init.d/rc 0
l1:1:wait:/etc/init.d/rc 1
l2:2:wait:/etc/init.d/rc 2
l3:3:wait:/etc/init.d/rc 3
l4:4:wait:/etc/init.d/rc 4
l5:5:wait:/etc/init.d/rc 5
l6:6:wait:/etc/init.d/rc 6

db:5:once:/etc/init.d/dbus start
as:5:once:/etc/init.d/alsa start
nt:5:once:/etc/init.d/ntpd start
dm:5:once:/etc/init.d/lightdm start

ca:12345:ctrlaltdel:/sbin/shutdown -t1 -a -r now

c1:12345:respawn:/sbin/agetty --noclear 38400 tty1 linux
...
```

Isso define:

- runlevel padrão (3 = texto);
- scripts `rcS` e `rc` para cada runlevel;
- serviços extras no runlevel 5 (gráfico);
- consoles `agetty`.

## 4. Scripts de inicialização (sysvinit)

Scripts normalmente moram em:

- `/etc/init.d/` – scripts de serviço.

Exemplo: `/etc/init.d/lightdm`

Trecho interessante (já adaptado para 3bLinux):

```sh
start() {
    echo "[lightdm] iniciando..."

    # Reparos de desktop antes de subir o X/LightDM
    if [ -x /bk-reparo ]; then
      echo "[lightdm] executando bk-reparo antes de iniciar o X..."
      /bk-reparo || echo "[lightdm] bk-reparo retornou erro, continuando mesmo assim."
    fi

    echo "[lightdm] iniciando display manager..."
    $DAEMON &
}
```

Você pode criar scripts similares para outros serviços:

- `start()`, `stop()`, `restart()`;
- usar `case "$1" in start|stop|restart|status)` etc.

## 5. Personalizando GRUB

### 5.1. Temas e aparência

Você pode:

- adicionar imagem de fundo em `/boot/grub/`;
- usar fontes específicas;
- ajustar cores de texto.

Exemplo de bloco em `grub.cfg`:

```cfg
set menu_color_normal=white/black
set menu_color_highlight=black/white
```

### 5.2. Manutenção

Se você trocar o kernel:

- atualize entradas no `grub.cfg`;
- garanta que o caminho de `initramfs` está correto.

## 6. Personalizando e mantendo initramfs

Ao alterar:

- drivers de disco;
- layout de rootfs;
- scripts de montagem;

é recomendável regenerar o initramfs com `bk-initramfs`.

Ele deve:

- coletar binários essenciais;
- copiar scripts;
- montar a imagem final (`cpio` + compressão).

## 7. Resumo

No 3bLinux:

- GRUB → carrega kernel + initramfs;
- initramfs → monta root real e chama `/sbin/init`;
- sysvinit → lê `/etc/inittab` e scripts em `/etc/init.d`.

Você personaliza:

- GRUB via `/boot/grub/grub.cfg`;
- initramfs via `bk-initramfs` e arquivos de configuração associados;
- init/sysvinit via `/etc/inittab` e scripts em `/etc/init.d`.

Entender essas camadas permite:

- criar inicializações personalizadas;
- depurar problemas de boot;
- montar perfis de sistema com comportamento específico.
