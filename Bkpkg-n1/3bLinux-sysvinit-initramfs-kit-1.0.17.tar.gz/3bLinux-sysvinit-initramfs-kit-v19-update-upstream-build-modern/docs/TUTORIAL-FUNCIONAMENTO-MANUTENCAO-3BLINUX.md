# Tutorial – Funcionamento geral e manutenção do 3bLinux

Este tutorial descreve, em alto nível e em detalhe, como o 3bLinux funciona e como mantê-lo:

- boot (init + initramfs + serviços);
- organização do rootfs;
- ferramentas `bk-*`;
- fluxo de atualizações;
- boas práticas de manutenção.

## 1. Visão geral de funcionamento

O 3bLinux é organizado em três camadas principais:

1. **Bootloader (GRUB)**  
   Carrega:
   - kernel Linux;
   - initramfs do 3bLinux.

2. **Initramfs**  
   Fornece um ambiente mínimo (busybox, scripts) que:
   - detecta root real;
   - monta sistemas de arquivos;
   - faz checagens básicas;
   - transfere controle para `/sbin/init` no rootfs real.

3. **Rootfs + sysvinit**  
   No rootfs, o `/sbin/init` (sysvinit) lê `/etc/inittab` e:

   - roda scripts `rcS`, `rc 0..6`, `rc.local` (dependendo da configuração);
   - sobe serviços (dbus, udev, rede, etc.);
   - traz o sistema até um **runlevel** (3 texto, 5 gráfico, etc.).

### 1.1. Pilares das ferramentas bk

As ferramentas `bk-*` suportam:

- **build de pacotes** (compilar código → instalar em staging → empacotar);
- **repositório binário** (índices, canais stable/testing, snapshots);
- **deploy** (atualizar rootfs, gerar ISO, instalar em disco).

## 2. Manutenção de sistema

### 2.1. Atualizações de pacotes

No sistema instalado:

```sh
sudo bk-update
```

Isso deve:

1. Consultar o repositório (via HTTP ou local).
2. Ver as diferenças entre versões instaladas e disponíveis.
3. Baixar e aplicar pacotes novos.
4. Gravar snapshot de estado anterior.

### 2.2. Reparo de ambiente gráfico

Sempre que você instalar/atualizar pacotes de desktop (Xorg, GTK, temas, etc.), rode:

```sh
sudo /bk-reparo --verbose
```

Ele:

- revisa init/bootchain;
- ajusta alternativas (`bk-update-alternatives apply-default`);
- atualiza caches de desktop (menus, ícones, fontes, MIME).

Além disso, o `bk-reparo` é chamado:

- antes do LightDM no runlevel gráfico;
- no `~/.xinitrc` padrão.

### 2.3. Manutenção de logs e espaço em disco

Verifique periodicamente:

- `/var/log/` – logs de sistema;
- `/var/tmp` e `/tmp` – arquivos temporários;
- `/var/lib/bk/snapshots` (ou equivalente) – snapshots de atualização.

Limpezas típicas:

```sh
sudo rm -rf /tmp/*
sudo rm -rf /var/tmp/*
# snapshots antigos – cuidado:
sudo rm -rf /var/lib/bk/snapshots/<N>    # apenas se tiver certeza
```

## 3. Manutenção de boot (kernel, initramfs, GRUB)

### 3.1. Novo kernel

Quando você constrói/instala um kernel novo:

- instale em `/boot/vmlinuz-<versão>`;
- atualize `initramfs`:

  ```sh
  sudo bk-initramfs --kernel /boot/vmlinuz-<versão>
  ```

- atualize entradas do GRUB (conforme o fluxo do kit – pode haver scripts para isso).

### 3.2. Verificações se o sistema não bootar

- Verifique entradas do GRUB (root=, UUID, etc.).
- Confirme que o initramfs contém:

  - módulos necessários (drivers de disco, filesystem);
  - scripts de montagem do root.

Se o problema estiver no rootfs:

- use a entrada de **rescue** do GRUB (single user);
- monte o rootfs e corrija `/etc/fstab`, `/etc/inittab`, scripts em `/etc/init.d`.

## 4. Manutenção de ambiente gráfico

### 4.1. Serviços em runlevel 5

Conforme configurado em `/etc/inittab`, no runlevel 5 o sistema sobe:

- `dbus`
- `alsa`
- `ntpd`
- `lightdm` (display manager)

Se algo falhar:

- verifique logs em `/var/log/` (dbus, Xorg, lightdm);
- tente subir manualmente:

  ```sh
  sudo /etc/init.d/dbus start
  sudo /etc/init.d/lightdm start
  ```

### 4.2. Regenerar caches de desktop

Além de chamar `bk-reparo`, você pode rodar comandos específicos:

```sh
sudo update-desktop-database /usr/share/applications
sudo gtk-update-icon-cache -f -q /usr/share/icons/Adwaita
sudo fc-cache -f
sudo update-mime-database /usr/share/mime
```

## 5. Manutenção do repositório

Se você controla o repositório:

- remova pacotes antigos que não serão mais usados;
- mantenha sempre os índices (`INDEX.v1`) coerentes com o conteúdo;
- assine os índices com chave GPG;
- separe claramente:

  - `stable/` – versões testadas;
  - `testing/` – versões em desenvolvimento.

## 6. Boas práticas gerais

- Teste mudanças em uma VM antes de aplicar em máquinas reais.
- Use canais `testing` para novos pacotes; só promova para `stable` após testes.
- Documente scripts locais que você alterar em `docs/` ou `/usr/local/share/doc/3blinux-local/`.

## 7. Resumo

Manter o 3bLinux significa:

- manter boot estável (GRUB + kernel + initramfs);
- manter rootfs limpo e coerente (`/etc`, `/var`, `packages` atualizados);
- usar ferramentas `bk-*` para:
  - updates,
  - reparos,
  - reconstrução de initramfs,
  - geração de ISO.

Os tutoriais complementares abordam:

- criação de ISO,
- servidor de repositório,
- desenvolvimento de pacotes,
- diagnóstico e depuração.
