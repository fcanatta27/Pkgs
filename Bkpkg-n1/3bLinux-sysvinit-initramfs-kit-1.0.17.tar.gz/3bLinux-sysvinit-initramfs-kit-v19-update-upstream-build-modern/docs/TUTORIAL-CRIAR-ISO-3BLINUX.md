# Tutorial – Criar uma ISO funcional do 3bLinux

Este tutorial explica como gerar uma ISO inicializável do 3bLinux usando o kit
(3bLinux + initramfs + GRUB + `xorriso` / `grub-mkrescue`).

## 1. Pré-requisitos

Na máquina de build, instale:

- `xorriso`
- `grub-mkrescue` (fornecido por `grub` em muitas distros)
- `mtools` (dependência comum do `grub-mkrescue`)

Além disso:

- o rootfs do 3bLinux precisa estar relativamente completo,
- initramfs e kernel disponíveis (se ainda não estiverem, use `bk-initramfs` e scripts de kernel).

## 2. Ferramenta: bk-mkiso

O kit traz um script (ou mais de um) na pasta `tools/`, normalmente algo como:

- `tools/bk-mkiso`

Ele é responsável por:

1. preparar uma árvore de ISO (`iso-tree` ou similar);
2. copiar:
   - kernel (ex.: `vmlinuz-...`)
   - initramfs (ex.: `initramfs-3blinux.img`)
   - arquivos de boot do GRUB (ou isolinux);
3. chamar `xorriso`/`grub-mkrescue` para gerar a ISO final.

## 3. Passos práticos para gerar a ISO

### 3.1. Confirmar kernel e initramfs

Verifique se, dentro do kit ou do rootfs, você tem:

- `/boot/vmlinuz-3blinux` (ou nome equivalente)
- `/boot/initramfs-3blinux.img`

Se ainda não:

- Gere o initramfs com o script apropriado (ex.: `bk-initramfs`).
- Certifique-se de que o kernel foi instalado no `/boot` do rootfs.

### 3.2. Rodar o bk-mkiso

Exemplo típico:

```sh
cd 3bLinux-sysvinit-initramfs-kit-1.0.15

# Gerar ISO
sudo tools/bk-mkiso \
  --rootfs ./rootfs \
  --kernel ./rootfs/boot/vmlinuz-3blinux \
  --initramfs ./rootfs/boot/initramfs-3blinux.img \
  --output ./3bLinux-1.0.iso
```

O script deve:

- criar um diretório temporário (por exemplo `./work/iso-root`);
- montar a estrutura do GRUB:

  ```text
  iso-root/
    boot/
      grub/
        grub.cfg
      vmlinuz-3blinux
      initramfs-3blinux.img
  ```

- chamar `grub-mkrescue`:

  ```sh
  grub-mkrescue -o 3bLinux-1.0.iso iso-root
  ```

### 3.3. Exemplo de `grub.cfg` para a ISO

Dentro da ISO (diretório `boot/grub/grub.cfg`):

```cfg
set default=0
set timeout=5

menuentry "3bLinux 1.0 (modo live)" {
    linux /boot/vmlinuz-3blinux root=/dev/ram0 rw quiet
    initrd /boot/initramfs-3blinux.img
}

menuentry "3bLinux 1.0 (modo rescue)" {
    linux /boot/vmlinuz-3blinux root=/dev/ram0 rw single
    initrd /boot/initramfs-3blinux.img
}
```

O `bk-mkiso` geralmente gera esse arquivo automaticamente, mas você pode ajustá-lo.

## 4. Testando a ISO

Você pode testar em:

### 4.1. QEMU

```sh
qemu-system-x86_64 \
  -enable-kvm \
  -m 2048 \
  -cdrom 3bLinux-1.0.iso
```

### 4.2. VirtualBox / VMware

- Crie uma VM nova.
- Use a ISO `3bLinux-1.0.iso` como mídia de boot.

## 5. Integração com instalação

A ISO deve conter:

- o rootfs completo (ou imagem squashfs, dependendo do design do kit);
- scripts de instalação (`bk-install`);
- ferramentas de partição (`parted`, `fdisk`, `mkfs.*` etc.).

Processo típico depois de dar boot pela ISO:

1. Logar como root.
2. Particionar o disco com `fdisk`/`parted`.
3. Rodar `bk-install` para:

   - detectar discos e partições;
   - formatar;
   - copiar rootfs;
   - gerar `fstab`;
   - instalar e configurar GRUB no disco.

## 6. Personalização da ISO

Você pode:

- alterar o `grub.cfg` da ISO para:

  - adicionar opções de kernel (ex.: `nomodeset`, `debug`);
  - adicionar entradas de boot alternativas.

- customizar splash de GRUB (imagens de fundo, fontes etc.);
- incluir scripts extras de pós-boot (por exemplo, um script que roda `bk-postinstall-workstation` automaticamente em ambiente live-chroot).

## 7. Resumo

1. Garante kernel + initramfs em `/boot`.
2. Rodar `tools/bk-mkiso` com `--rootfs`, `--kernel`, `--initramfs`.
3. Testar a ISO em QEMU.
4. Ajustar `grub.cfg` se necessário.

Essa ISO será seu **meio de instalação oficial** do 3bLinux, que junto com `bk-install` forma o pipeline:

- **build → ISO → instalação → pós-instalação workstation**.
