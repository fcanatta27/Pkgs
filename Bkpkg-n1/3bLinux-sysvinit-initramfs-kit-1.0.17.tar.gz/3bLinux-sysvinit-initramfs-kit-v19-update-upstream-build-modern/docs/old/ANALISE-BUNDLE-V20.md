# Análise do bundle v20 (derivado do v19)

Esta análise é estática (leitura de scripts), focada em robustez, reprodutibilidade e segurança operacional.

## Resumo de achados (heurísticos)
- **DL**: 90
- **SUDO**: 69
- **SHEBANG**: 20
- **STRICT**: 1

## Detalhe por arquivo

### bk
- Linhas: 367
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### bk-chroot
- Linhas: 254
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### bk-initramfs
- Linhas: 300
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### bk-reparo
- Linhas: 412
- Achados:
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### bk-update
- Linhas: 377
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### bk-upstream
- Linhas: 313
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.

### init-reparo
- Linhas: 549
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/Jinja2-3.1.6/build-Jinja2-3.1.6.sh
- Linhas: 87
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/MarkupSafe-3.0.3/build-MarkupSafe-3.0.3.sh
- Linhas: 88
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/acl-2.3.2/build-acl-2.3.2.sh
- Linhas: 69
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/attr-2.5.2/build-attr-2.5.2.sh
- Linhas: 69
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/autoconf-2.72/build-autoconf-2.72.sh
- Linhas: 83
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/automake-1.18.1/build-automake-1.18.1.sh
- Linhas: 83
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/bash-5.3/build-bash-5.3.sh
- Linhas: 104
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/bc-7.0.3/build-bc-7.0.3.sh
- Linhas: 99
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/binutils-2.45.1-pass1/build-binutils-2.45.1-pass1.sh
- Linhas: 110
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/binutils-2.45.1-pass2/build-binutils-2.45.1-pass2.sh
- Linhas: 107
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/binutils-2.45.1/build-binutils-2.45.1.sh
- Linhas: 107
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/bison-3.8.2/build-bison-3.8.2.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/busybox-1.37.1/build-busybox-1.37.1.sh
- Linhas: 139
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/bzip2-1.0.8/build-bzip2-1.0.8.sh
- Linhas: 97
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/dbus-1.16.2/build-dbus-1.16.2.sh
- Linhas: 114
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/dejagnu-1.6.3/build-dejagnu-1.6.3.sh
- Linhas: 69
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/diffutils-3.12/build-diffutils-3.12.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/e2fsprogs-1.47.3/build-e2fsprogs-1.47.3.sh
- Linhas: 102
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/eudev-3.2.14/build-eudev-3.2.14.sh
- Linhas: 116
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/expect-5.45.4/build-expect-5.45.4.sh
- Linhas: 69
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/file-5.46/build-file-5.46.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/findutils-4.10.0/build-findutils-4.10.0.sh
- Linhas: 99
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/flex-2.6.4/build-flex-2.6.4.sh
- Linhas: 93
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/flit-core-3.12.0/build-flit-core-3.12.0.sh
- Linhas: 77
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/gawk-5.3.2/build-gawk-5.3.2.sh
- Linhas: 102
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/gcc-15.2.0-pass1/build-gcc-15.2.0-pass1.sh
- Linhas: 128
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/gcc-15.2.0-pass2/build-gcc-15.2.0-pass2.sh
- Linhas: 107
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/gcc-15.2.0/build-gcc-15.2.0.sh
- Linhas: 112
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/gdbm-1.23/build-gdbm-1.23.sh
- Linhas: 99
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/gettext-0.26/build-gettext-0.26.sh
- Linhas: 105
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/glibc-2.42/build-glibc-2.42.sh
- Linhas: 120
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/gmp-6.3.0/build-gmp-6.3.0.sh
- Linhas: 98
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/gperf-3.3/build-gperf-3.3.sh
- Linhas: 83
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/grep-3.12/build-grep-3.12.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/groff-1.23.0/build-groff-1.23.0.sh
- Linhas: 98
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/grub-2.14/build-grub-2.14-uefi.sh
- Linhas: 117
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/gzip-1.14/build-gzip-1.14.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/hwclock-2.40.2/build-hwclock-2.40.2.sh
- Linhas: 111
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/iana-etc-20251215/build-iana-etc-20251215.sh
- Linhas: 86
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/inetutils-2.7/build-inetutils-2.7.sh
- Linhas: 92
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/intltool-0.51.0/build-intltool-0.51.0.sh
- Linhas: 83
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/iproute2-6.18.0/build-iproute2-6.18.0.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/isl-0.27/build-isl-0.27.sh
- Linhas: 99
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/kbd-2.9.0/build-kbd-2.9.0.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/kernel-6.18.2/build-kernel-6.18.2.sh
- Linhas: 130
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/kernel-headers-6.18.2/build-kernel-headers-6.18.2.sh
- Linhas: 89
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/kmod-34.2/build-kmod-34.2.sh
- Linhas: 102
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/less-643/build-less-643.sh
- Linhas: 97
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/libcap-2.77/build-libcap-2.77.sh
- Linhas: 64
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/libelf-elfutils-0.194/build-libelf-elfutils-0.194.sh
- Linhas: 102
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/libffi-3.5.2/build-libffi-3.5.2.sh
- Linhas: 82
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/libpipeline-1.5.8/build-libpipeline-1.5.8.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/libtool-2.5.4/build-libtool-2.5.4.sh
- Linhas: 83
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/libxcrypt-4.5.2/build-libxcrypt-4.5.2.sh
- Linhas: 69
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/lz4-1.10.0/build-lz4-1.10.0.sh
- Linhas: 64
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/m4-1.4.20/build-m4-1.4.20.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/make-4.4.1/build-make-4.4.1.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/man-db-2.13.1/build-man-db-2.13.1.sh
- Linhas: 110
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/man-pages-6.16/build-man-pages-6.16.sh
- Linhas: 80
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/meson-1.10.0/build-meson-1.10.0.sh
- Linhas: 77
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/mpc-1.3.1/build-mpc-1.3.1.sh
- Linhas: 99
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/mpfr-4.2.2/build-mpfr-4.2.2.sh
- Linhas: 99
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/ncurses-6.5/build-ncurses-6.5.sh
- Linhas: 110
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/ninja-1.13.2/build-ninja-1.13.2.sh
- Linhas: 75
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/openssl-3.6.0/build-openssl-3.6.0.sh
- Linhas: 88
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/packaging-25.0/build-packaging-25.0.sh
- Linhas: 77
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/patch-2.8/build-patch-2.8.sh
- Linhas: 99
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/pcre2-10.47/build-pcre2-10.47.sh
- Linhas: 97
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/perl-5.42.0/build-perl-5.42.0.sh
- Linhas: 103
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/pkgconf-2.5.1/build-pkgconf-2.5.1.sh
- Linhas: 72
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/procps-ng-4.0.5/build-procps-ng-4.0.5.sh
- Linhas: 99
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/psmisc-23.7/build-psmisc-23.7.sh
- Linhas: 69
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/python-3.14.2/build-python-3.14.2.sh
- Linhas: 108
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/readline-8.3/build-readline-8.3.sh
- Linhas: 95
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/sed-4.9/build-sed-4.9.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/setuptools-80.9.0/build-setuptools-80.9.0.sh
- Linhas: 77
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/shadow-4.16.0/build-shadow-4.16.0.sh
- Linhas: 132
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/sqlite-3510200/build-sqlite-3510200.sh
- Linhas: 90
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/sysklogd-2.7.2/build-sysklogd-2.7.2.sh
- Linhas: 91
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/sysvinit-3.15/build-sysvinit-3.15.sh
- Linhas: 99
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/tar-1.35/build-tar-1.35.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/tcl-8.6.17/build-tcl-8.6.17.sh
- Linhas: 73
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/texinfo-7.2/build-texinfo-7.2.sh
- Linhas: 96
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/util-linux-2.41.3/build-util-linux-2.41.3.sh
- Linhas: 100
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/vim-9.1.2031/build-vim-9.1.2031.sh
- Linhas: 104
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/wheel-0.46.1/build-wheel-0.46.1.sh
- Linhas: 77
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/xml-parser-2.47/build-xml-parser-2.47.sh
- Linhas: 81
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.

### packages/xz-5.8.2/build-xz-5.8.2.sh
- Linhas: 111
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/zlib-1.3/build-zlib-1.3.sh
- Linhas: 100
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### packages/zstd-1.5.7/build-zstd-1.5.7.sh
- Linhas: 87
- Achados:
  - [DL] Downloads sem flag de falha (curl -f / wget robusto) ou validação de hash.
  - [SUDO] Evitar sudo dentro do script; documentar fora.

### rootfs/etc/init.d/init-reparo
- Linhas: 29
- Achados:
  - [SHEBANG] Sem shebang na primeira linha.
  - [STRICT] Não usa set -e (ideal: set -euo pipefail).
