# Análise do bundle v19 (scripts)

Esta análise é estática (leitura de código). Ela aponta riscos reais e melhorias recomendadas.

## Resumo de alertas (heurístico)
- Scripts analisados: 86
- Sem shebang: 20
- Sem `set -e`: 1
- Uso de caminhos fixos em /tmp: 80

## Detalhamento por arquivo

### `bk`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)

### `bk-chroot`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)

### `bk-initramfs`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `bk-reparo`
- Não usa `set -u` (variáveis não definidas podem virar bug)

### `bk-update`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Parsing com `grep | awk` pode ser frágil (preferir formatos determinísticos / validação)

### `bk-upstream`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)

### `init-reparo`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/acl-2.3.2/build-acl-2.3.2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/attr-2.5.2/build-attr-2.5.2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/autoconf-2.72/build-autoconf-2.72.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/automake-1.18.1/build-automake-1.18.1.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/bash-5.3/build-bash-5.3.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/bc-7.0.3/build-bc-7.0.3.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/binutils-2.45.1-pass1/build-binutils-2.45.1-pass1.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/binutils-2.45.1-pass2/build-binutils-2.45.1-pass2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/binutils-2.45.1/build-binutils-2.45.1.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/bison-3.8.2/build-bison-3.8.2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/busybox-1.37.1/build-busybox-1.37.1.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/bzip2-1.0.8/build-bzip2-1.0.8.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/dejagnu-1.6.3/build-dejagnu-1.6.3.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/diffutils-3.12/build-diffutils-3.12.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/eudev-3.2.14/build-eudev-3.2.14.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/expect-5.45.4/build-expect-5.45.4.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/file-5.46/build-file-5.46.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/flex-2.6.4/build-flex-2.6.4.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/flit-core-3.12.0/build-flit-core-3.12.0.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/gawk-5.3.2/build-gawk-5.3.2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/gcc-15.2.0-pass1/build-gcc-15.2.0-pass1.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/gcc-15.2.0-pass2/build-gcc-15.2.0-pass2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/gcc-15.2.0/build-gcc-15.2.0.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/gdbm-1.23/build-gdbm-1.23.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/gettext-0.26/build-gettext-0.26.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/glibc-2.42/build-glibc-2.42.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/gmp-6.3.0/build-gmp-6.3.0.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/gperf-3.3/build-gperf-3.3.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/grep-3.12/build-grep-3.12.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/groff-1.23.0/build-groff-1.23.0.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/grub-2.14/build-grub-2.14-uefi.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/gzip-1.14/build-gzip-1.14.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/hwclock-2.40.2/build-hwclock-2.40.2.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/iana-etc-20251215/build-iana-etc-20251215.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/inetutils-2.7/build-inetutils-2.7.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/intltool-0.51.0/build-intltool-0.51.0.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/isl-0.27/build-isl-0.27.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/kernel-6.18.2/build-kernel-6.18.2.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/kernel-headers-6.18.2/build-kernel-headers-6.18.2.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/less-643/build-less-643.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/libcap-2.77/build-libcap-2.77.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/libelf-elfutils-0.194/build-libelf-elfutils-0.194.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/libffi-3.5.2/build-libffi-3.5.2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/libtool-2.5.4/build-libtool-2.5.4.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/libxcrypt-4.5.2/build-libxcrypt-4.5.2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/lz4-1.10.0/build-lz4-1.10.0.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/m4-1.4.20/build-m4-1.4.20.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/make-4.4.1/build-make-4.4.1.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/man-db-2.13.1/build-man-db-2.13.1.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/man-pages-6.16/build-man-pages-6.16.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/meson-1.10.0/build-meson-1.10.0.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/mpc-1.3.1/build-mpc-1.3.1.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/mpfr-4.2.2/build-mpfr-4.2.2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/ncurses-6.5/build-ncurses-6.5.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/ninja-1.13.2/build-ninja-1.13.2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/openssl-3.6.0/build-openssl-3.6.0.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/packaging-25.0/build-packaging-25.0.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/patch-2.8/build-patch-2.8.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/pcre2-10.47/build-pcre2-10.47.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/perl-5.42.0/build-perl-5.42.0.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/pkgconf-2.5.1/build-pkgconf-2.5.1.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/psmisc-23.7/build-psmisc-23.7.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/python-3.14.2/build-python-3.14.2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/readline-8.3/build-readline-8.3.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/sed-4.9/build-sed-4.9.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/setuptools-80.9.0/build-setuptools-80.9.0.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/shadow-4.16.0/build-shadow-4.16.0.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/sqlite-3510200/build-sqlite-3510200.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/sysvinit-3.15/build-sysvinit-3.15.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/tar-1.35/build-tar-1.35.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/tcl-8.6.17/build-tcl-8.6.17.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/texinfo-7.2/build-texinfo-7.2.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/util-linux-2.41.3/build-util-linux-2.41.3.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/wheel-0.46.1/build-wheel-0.46.1.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/xml-parser-2.47/build-xml-parser-2.47.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/xz-5.8.2/build-xz-5.8.2.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/zlib-1.3/build-zlib-1.3.sh`
- Sem shebang na primeira linha
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `packages/zstd-1.5.7/build-zstd-1.5.7.sh`
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Usa caminhos fixos em /tmp (melhor `mktemp -d`)

### `rootfs/etc/init.d/init-reparo`
- Sem shebang na primeira linha
- Não usa `set -e` (falhas podem passar silenciosamente)
- Não usa `set -u` (variáveis não definidas podem virar bug)
- Não usa `set -o pipefail` (pipelines podem mascarar falhas)
