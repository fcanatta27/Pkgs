# THEMES-GUI-1.0

Este documento descreve como configurar temas gráficos no 3bLinux 1.0.x para os ambientes:

- TWM
- Openbox
- Fluxbox
- i3wm

Também mostra como ajustar:

- fontes e cores via `~/.Xresources`
- temas GTK2/GTK3 (`~/.gtkrc-2.0` e `~/.config/gtk-3.0/settings.ini`)
- temas de ícones e cursores com `update-alternatives` (quando disponível)

## 1. Arquivos padrão criados em /etc/skel

Ao criar um novo usuário com `useradd -m`, os seguintes arquivos serão copiados:

- `~/.bashrc`
- `~/.Xresources`
- `~/.twmrc`
- `~/.xinitrc`
- `~/.gtkrc-2.0`
- `~/.config/gtk-3.0/settings.ini`

Você pode editar esses arquivos globalmente em `/etc/skel` antes de criar usuários, ou ajustar por usuário depois.

### 1.1. ~/.Xresources

Controla cores e fonte do terminal (por exemplo, `urxvt`) e outros recursos X.  
Para recarregar após edição:

```sh
xrdb -merge ~/.Xresources
```

### 1.2. GTK2 – ~/.gtkrc-2.0

Exemplo (já padrão no 3bLinux):

```ini
gtk-theme-name="Adwaita"
gtk-icon-theme-name="Adwaita"
gtk-font-name="Hack 10"
```

### 1.3. GTK3 – ~/.config/gtk-3.0/settings.ini

Exemplo padrão:

```ini
[Settings]
gtk-theme-name=Adwaita
gtk-icon-theme-name=Adwaita
gtk-font-name=Hack 10
gtk-application-prefer-dark-theme=true
```

Altere os nomes de tema (`gtk-theme-name`, `gtk-icon-theme-name`) para qualquer tema instalado em `/usr/share/themes` (GTK) e `/usr/share/icons` (ícones).

---

## 2. Selecionando temas de cursores e ícones com update-alternatives

Se `update-alternatives` estiver disponível, o `bk-reparo` tenta:

- registrar um tema de cursor padrão (`x-cursor-theme`)
- registrar um tema de ícones padrão (`x-icon-theme`)

Você pode ajustar manualmente, por exemplo:

```sh
sudo update-alternatives --config x-cursor-theme
sudo update-alternatives --config x-icon-theme
```

Para registrar um tema de cursor customizado (ex.: Capitaine Cursors), algo como:

```sh
sudo update-alternatives   --install /usr/share/icons/default/index.theme x-cursor-theme   /usr/share/icons/capitaine-cursors/index.theme 60
```

Para ícones (ex.: Argon):

```sh
sudo update-alternatives   --install /usr/share/icons/default/index.theme-icon x-icon-theme   /usr/share/icons/Argon/index.theme 60
```

> Nota: os caminhos exatos podem variar entre temas. Verifique o conteúdo em `/usr/share/icons/NOME_DO_TEMA`.

---

## 3. TWM – aparência e menu

O arquivo `~/.twmrc` padrão do 3bLinux já vem com:

- bordas finas
- cores escuras
- menu principal acessado com **botão esquerdo** no desktop
- atalhos:
  - `Alt+F1` abre terminal (`rxvt-unicode`)
  - `Alt+F2` abre Firefox

Se quiser alterar o terminal usado no menu:

```twmrc
"Terminal" f.exec "rxvt-unicode &"
# troque por
"Terminal" f.exec "xterm &"
```

Para mudar a imagem de fundo, edite a função `Init` em `~/.twmrc`:

```twmrc
Function "Init" {
  f.exec "xsetroot -solid '#202020'"
  f.exec "feh --bg-fill /caminho/para/sua-imagem.jpg || xsetroot -solid '#202020'"
}
```

---

## 4. Openbox

### 4.1. Arquivos principais

- `~/.config/openbox/rc.xml` – atalhos, bordas, foco.
- `~/.config/openbox/menu.xml` – menu do botão direito.
- `~/.config/openbox/autostart` – programas que sobem com a sessão (ex.: `feh`, `nm-applet`, etc).

Crie a estrutura caso não exista:

```sh
mkdir -p ~/.config/openbox
cp /etc/xdg/openbox/{rc.xml,menu.xml,autostart} ~/.config/openbox 2>/dev/null || true
```

### 4.2. Ajustando tema e bordas

No `rc.xml`, seção `<theme>`:

```xml
<theme>
  <name>Adwaita-dark</name>
  <titleLayout>NLIMC</titleLayout>
  <font place="ActiveWindow">
    <name>Hack</name>
    <size>10</size>
  </font>
  ...
</theme>
```

Altere `<name>` para qualquer tema Openbox instalado (ex.: `Onyx`, `Clearlooks`, etc).

### 4.3. Autostart – iniciar compositor, wallpaper, tray

Exemplo em `~/.config/openbox/autostart`:

```sh
# Definir papel de parede
feh --bg-fill /usr/share/backgrounds/3blinux-default.jpg &

# Carregar Xresources
[ -f "$HOME/.Xresources" ] && xrdb -merge "$HOME/.Xresources"

# Iniciar compositor (se instalado)
# picom &

# Applets de rede / audio (se existirem)
# nm-applet &
# pasystray &

# Cursor "bonito" (opcional, se não usar update-alternatives)
xsetroot -cursor_name left_ptr
```

---

## 5. Fluxbox

### 5.1. Arquivos

- `~/.fluxbox/init`
- `~/.fluxbox/menu`
- `~/.fluxbox/keys`
- `~/.fluxbox/styles/` – temas

Criação inicial:

```sh
fluxbox-generate_menu 2>/dev/null || true
```

### 5.2. Mudando tema (style)

No `~/.fluxbox/init`:

```ini
session.styleFile:    /usr/share/fluxbox/styles/black
```

Altere para qualquer style instalado:

```ini
session.styleFile:    /usr/share/fluxbox/styles/3blinux-dark
```

### 5.3. Wallpaper e apps

No `~/.fluxbox/startup`:

```sh
feh --bg-fill /usr/share/backgrounds/3blinux-default.jpg &
[ -f "$HOME/.Xresources" ] && xrdb -merge "$HOME/.Xresources"
exec fluxbox
```

---

## 6. i3wm

### 6.1. Arquivo principal

- `~/.config/i3/config`

Para criar config inicial:

```sh
mkdir -p ~/.config/i3
cp /etc/i3/config ~/.config/i3/config 2>/dev/null || i3-config-wizard
```

### 6.2. Cores e fontes

No config:

```conf
font pango:Hack Nerd Font 10

set $bg      #202020
set $fg      #d0d0d0
set $accent  #81a2be

client.focused          $bg  $fg  $accent  $accent
client.unfocused        #1d1f21 #c5c8c6 #1d1f21 #1d1f21
```

### 6.3. Autostart

No mesmo arquivo:

```conf
exec_always --no-startup-id feh --bg-fill /usr/share/backgrounds/3blinux-default.jpg
exec_always --no-startup-id xrdb -merge ~/.Xresources
```

---

## 7. Integrando com o bk-reparo

O `bk-reparo` foi estendido para:

- checar e registrar alternativas com `update-alternatives` (quando disponível) para:
  - `x-terminal-emulator`
  - `x-window-manager`
  - temas de cursor
  - temas de ícones
- atualizar caches:
  - `update-desktop-database`
  - `gtk-update-icon-cache`
  - `fc-cache`
  - `update-mime-database`
  - `xdg-desktop-menu forceupdate`

Além disso:

- o script `/etc/init.d/lightdm` chama `bk-reparo` **antes** de subir o LightDM (portanto antes do X no modo gráfico).
- o `~/.xinitrc` padrão em `/etc/skel` também executa `bk-reparo` antes de iniciar o `twm` em sessões `startx`.

Assim, depois de instalar/atualizar temas e pacotes de desktop via `bk`, rodar:

```sh
sudo /bk-reparo --verbose
```

ou apenas trocar para o runlevel gráfico (`init 5`) já será suficiente para deixar:

- caches atualizados
- alternativas coerentes
- X pronto para uso com aparência consistente.
