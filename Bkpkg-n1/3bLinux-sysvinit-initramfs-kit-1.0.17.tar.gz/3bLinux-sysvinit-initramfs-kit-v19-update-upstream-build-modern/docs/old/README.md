# 3bLinux – Ordem de Construção por Dependências (Base do Sistema com bk)

> Documentação adicional (tutoriais e notas): veja a pasta `docs/`.

Este README define uma **ordem recomendada de construção** para criar um sistema 3bLinux
do zero, usando o **bk-kit** para empacotar e instalar tudo de forma reprodutível.

A abordagem aqui é similar ao estilo “from scratch”:

- construir um conjunto mínimo de ferramentas (Toolchain Pass 1)
- montar as bibliotecas base (kernel headers, glibc, zlib, etc.)
- construir o userland essencial (shell, core tools, compressão, build tools)
- preparar boot (kernel, initramfs, sysvinit, udev, grub)

O objetivo é que você tenha um **/ funcional**, com:
- init (sysvinit), scripts de boot, /dev /proc /sys /run
- ferramenta de pacotes (bk)
- toolchain completa (gcc/binutils)
- utilitários essenciais (tar, gzip, sed, grep, etc.)
- base de rede (/etc/services, /etc/protocols, etc.)
- boot via GRUB + initramfs + kernel

---

## 1) Convenções do kit

- Repositório de pacotes: `/var/3bLinux`
- Estado do bk: `/var/lib/bk`
- Todos os scripts de build constroem em `/tmp/<pkg>-build` e instalam em `PKG_ROOT`,
  empacotando ao final com:

```sh
bk package NOME "$PKG_ROOT"
```

Instalação típica:

```sh
sudo bk install NOME
```

---

## 2) Infraestrutura base (requisitos do próprio build)

Antes de iniciar, garanta:
- partições montadas para o root do seu 3bLinux (ou um chroot)
- `bk` funcionando
- um ambiente de build (host) com compilador mínimo se você estiver começando “do zero absoluto”

Recomendação operacional:
- usar `bk-chroot` para construir dentro de um root isolado (ex.: `/srv/3blinux-root`).

Exemplo:

```sh
sudo mkdir -p /srv/3blinux-root
sudo ./bk-chroot /srv/3blinux-root
```

Dentro do chroot, você roda os scripts e instala com `bk` naquele root.

---

## 3) Ordem de construção por camadas

### Camada A: Ferramentas mínimas de build e shell

Essenciais para construir quase todo o resto:

1. `bash-5.3`
2. `make-4.4.1`
3. `m4-1.4.20`
4. `diffutils-3.12`
5. `gawk-5.3.2`
6. `grep-3.12`
7. `sed-4.9`
8. `tar-1.35`
9. `gzip-1.14`
10. `bzip2-1.0.15`
11. `xz-5.8.2`
12. `zstd-1.5.7`

Notas:
- `flex-2.6.4` requer `m4`.
- `bc-7.0.3` pode requerer `flex` e/ou `bison` (dependendo do build).

### Camada B: Bibliotecas matemáticas do GCC (para toolchain)

1. `gmp-6.3.0`
2. `mpfr-4.2.2` (depende de gmp)
3. `mpc-1.3.1` (depende de gmp e mpfr)
4. `isl-0.27`

### Camada C: Toolchain Pass 1 (bootstrap)

1. `binutils-2.45.1-pass1`
2. `gcc-15.2.0-pass1`

Observação:
- O Pass 1 instala em `/usr/cross`.
- A variável `TARGET` define o triplo, por padrão:
  `$(uname -m)-3blinux-linux-gnu`.

Exemplo:

```sh
TARGET=x86_64-3blinux-linux-gnu ./build-binutils-2.45.1-pass1.sh
sudo bk install binutils-2.45.1-pass1

TARGET=x86_64-3blinux-linux-gnu ./build-gcc-15.2.0-pass1.sh
sudo bk install gcc-15.2.0-pass1
```

### Camada D: Kernel headers + libc + libs base

1. `kernel-headers-6.18.2`
2. `zlib-1.3`
3. `glibc-2.42`

Depois disso, você já tem base suficiente para compilar um userland completo.

### Camada E: Ferramentas de runtime essenciais

1. `readline-8.3` (depende de ncurses)
2. `ncurses-6.5`
3. `pcre2-10.47`
4. `gettext-0.26`
5. `bison-3.8.2`
6. `flex-2.6.4`
7. `bc-7.0.3`
8. `perl-5.42.0`
9. `python-3.14.2`
10. `texinfo-7.2`
11. `util-linux-2.41.3`
12. `file-5.46`

### Camada F: Documentação e base de rede (opcional, mas recomendado)

1. `man-pages-6.16`
2. `groff-1.23.0`
3. `less-643`
4. `man-db-2.13.1`
5. `iana-etc-20251215` (instala /etc/services e /etc/protocols)

---

## 4) Boot: kernel, initramfs, init, udev, grub

Ordem prática sugerida:

1. `busybox-1.37.1`
2. `bk-initramfs` (gera initramfs com busybox e scripts)
3. `sysvinit-3.15`
4. `eudev-3.2.14`
5. `grub-2.14-uefi`
6. `kernel-6.18.2`

Depois, configure:
- `/etc/inittab`, scripts em `/etc/init.d`
- GRUB em `/boot/grub` e (se UEFI) `/boot/efi`

---

## 5) Reparo e sanity-check com bk-reparo

O script `bk-reparo` foi expandido para:

- criar diretórios essenciais se faltarem (idempotente)
- checar mounts de `/proc`, `/sys`, `/dev`, `/run`
- checar consistência básica do bk (`bk list`)
- garantir links de compatibilidade seguros (ex.: /bin/sh, awk, python3)
- procurar links quebrados em áreas críticas e reportar
- validar configs mínimas em `/etc` e criar templates mínimos seguros quando possível
- checar itens básicos da cadeia de boot (init, /etc/init.d, /boot, grub, mkinitramfs)

Uso:

```sh
sudo bk-reparo
sudo bk-reparo --check-only
sudo bk-reparo --dry-run --verbose
```

---

## 6) Dicas de execução

- Sempre prefira construir dentro de um chroot com `bk-chroot`.
- Faça builds em ordem; se um pacote reclamar de dependência, volte e instale a camada anterior.
- Depois de cada conjunto grande, rode:

```sh
sudo bk-reparo --check-only --verbose
```

para garantir que você não acumulou inconsistências.

---

## 7) Toolchain Pass 2 (final do compilador)

Depois de ter:

- kernel headers + glibc instalados
- Toolchain Pass 1 já usado para compilar a base

você consolida o toolchain final com:

1. `binutils-2.45.1-pass2`
2. `gcc-15.2.0-pass2`

Exemplo (dentro do chroot 3bLinux):

```sh
TARGET_TRIPLET=x86_64-3blinux-linux-gnu

cd packages/binutils-2.45.1-pass2
sudo ./build-binutils-2.45.1-pass2.sh

cd ../gcc-15.2.0-pass2
sudo ./build-gcc-15.2.0-pass2.sh
```

---

## 8) Ferramentas de desenvolvimento / Autotools

Com o toolchain final pronto, construa os utilitários de desenvolvimento:

1. `m4-1.4.20`            (já definido anteriormente)
2. `pkgconf-2.5.1`
3. `libtool-2.5.4`
4. `gperf-3.3`
5. `autoconf-2.72`
6. `automake-1.18.1`
7. `perl-5.42.0`
8. `perl-xml-parser-2.47` (XML::Parser)
9. `intltool-0.51.0`

Ordem sugerida:

```text
m4 -> pkgconf -> libtool -> gperf -> autoconf -> automake -> perl -> XML::Parser -> intltool
```

Esses pacotes completam o “ecossistema autotools” para compilar muitos projetos de terceiros.

---

## 9) Rede e criptografia

Para ter uma base mínima de rede e TLS:

1. `inetutils-2.7`   – ifconfig, ping, telnet, ftp, etc. (básico de rede userland)
2. `openssl-3.6.0`   – biblioteca de criptografia e ferramentas (openssl, etc.)

Dentro do chroot:

```sh
cd packages/inetutils-2.7
sudo ./build-inetutils-2.7.sh

cd ../openssl-3.6.0
sudo ./build-openssl-3.6.0.sh
```

Depois disso, você já tem:
- toolchain final (GCC/Binutils)
- libs base (glibc, zlib, xz, zstd, etc.)
- sistema de build (pkgconf, autotools, libtool, gperf)
- rede e TLS (inetutils + openssl)
- gerenciamento de pacotes com bk
- infraestrutura de boot (sysvinit + initramfs + kernel + grub) conforme descrito anteriormente.

A partir daqui, você pode seguir expandindo 3bLinux com bibliotecas gráficas, userland adicional, servidor SSH, etc., sempre usando o mesmo padrão de scripts em `packages/*/build-*.sh` + `bk package` + `bk install`.

---

# Atualizações do 3bLinux (bk-update) e monitoramento upstream (bk-upstream)

## bk-update — sincronização do repositório de binários (/var/3bLinux)

Objetivo: manter o diretório **/var/3bLinux/** (somente repositório de binários) atualizado a partir do seu servidor caseiro.

### Estrutura recomendada do repositório remoto

- `BASE_URL/INDEX.txt`
- `BASE_URL/pkgs/<arquivos de pacotes>`

`INDEX.txt` (formato):
- `<sha256>  <relpath>`

Exemplo:
```
d2c7...  pkgs/bash-5.3.tar.gz
a13f...  pkgs/glibc-2.42.tar.gz
```

### Configuração

Crie `/etc/bk-update.conf`:
```sh
BK_REPO_URL="http://SEU_SERVIDOR/3bLinux"
BK_REPO_INDEX="INDEX.txt"
```

Uso:
```sh
sudo ./bk-update --base-url "$BK_REPO_URL"
sudo ./bk-update --base-url "$BK_REPO_URL" --dry-run --verbose
sudo ./bk-update --base-url "$BK_REPO_URL" --apply
```

Observações:
- O download é **atômico** e valida **SHA256** antes de substituir o arquivo local.
- `--apply` tenta aplicar updates via `bk install <pkg>` por heurística (best-effort).

## bk-upstream — detectar versões novas nos upstreams automaticamente

Objetivo: reduzir o trabalho de caçar versões novas manualmente.

Uso:
```sh
./bk-upstream --verbose
sudo ./bk-upstream --write-json /var/lib/bk/upstream-report.json
```

Como ele decide:
- GNU (ftp.gnu.org): tenta descobrir a última versão pelo listing do diretório
- GitHub releases: usa a API `releases/latest`
- Outros (SourceForge/Launchpad/CPAN): marca como MANUAL

Ele **não altera** seus scripts automaticamente; ele te entrega um relatório para você decidir as atualizações.

---

## Checklist completo de build do 3bLinux (Fase 0 -> sistema bootável)

Este checklist assume que você está construindo em um host Linux (build host) e instalando o resultado no alvo (rootfs) do 3bLinux.
A recomendação é usar `bk-chroot` para executar as fases dentro do rootfs com consistência.

### Fase 0 — Preparação do host e do target
- [ ] Definir onde ficará o rootfs do 3bLinux (ex: `/mnt/3broot`) e montar a partição alvo
- [ ] Criar diretórios básicos no rootfs: `/{bin,boot,dev,etc,home,lib,lib64,mnt,opt,proc,root,run,sbin,srv,sys,tmp,usr,var}`
- [ ] Garantir permissões: `/tmp` e `/var/tmp` com `1777`
- [ ] Preparar mounts de pseudo-filesystems no rootfs: `proc`, `sysfs`, `devtmpfs` (e `run` quando aplicável)
- [ ] Copiar o kit bk para dentro do rootfs (ou instalar via seus binários)

### Fase 1 — Base de headers/libs e toolchain inicial (Pass 1)
- [ ] Construir/instalar: `kernel-headers-6.18.2` (headers em `/usr/include`)
- [ ] Construir/instalar: `zlib-1.3`, `xz-5.8.2` (e demais libs base conforme seu roteiro)
- [ ] Construir/instalar: `glibc-2.42`
- [ ] Toolchain Pass 1 (conforme README específico de Pass 1):
  - [ ] `Binutils-2.45.1 - Pass 1`
  - [ ] `GCC-15.2.0 - Pass 1`

### Fase 2 — Userland essencial (base do sistema)
- [ ] Construir e instalar utilitários base (coreutils e afins conforme seus pacotes já adicionados)
- [ ] `bash-5.3`, `ncurses-6.5`, `less`, `file`, `tar`, `gzip`, `grep`, `gawk`, `sed`, `patch`, `diffutils`, etc.
- [ ] Instalar `man-pages` e `iana-etc` (quando já tiver seu toolchain e paths corretos)
- [ ] Construir bibliotecas adicionais conforme necessário: `zstd`, `readline`, `pcre2`, etc.

### Fase 3 — Toolchain final (Pass 2)
- [ ] `binutils-2.45.1-pass2` (instalação final em `/usr`)
- [ ] `gcc-15.2.0-pass2` (compilador final em `/usr`)
- [ ] Validar: `gcc --version`, `ld --version`, compilar e rodar um "hello world"

### Fase 4 — Ecossistema de build (Autotools / pkg-config)
- [ ] `m4`
- [ ] `pkgconf`
- [ ] `libtool`
- [ ] `gperf`
- [ ] `autoconf`
- [ ] `automake`
- [ ] `perl` + `XML::Parser`
- [ ] `intltool`

### Fase 5 — Segurança, rede e administração base
- [ ] `openssl`
- [ ] `inetutils` (ou alternativa)
- [ ] `shadow` (usuários/senhas) e `util-linux` (seu script já cobre versões)
- [ ] Executar `bk-reparo` para sanity-check e correções idempotentes

### Fase 6 — Boot stack (kernel + initramfs + init + grub)
- [ ] Compilar kernel (seus scripts de kernel) e instalar em `/boot`
- [ ] Construir busybox e gerar initramfs com `bk-initramfs`
- [ ] Validar scripts do init (sysvinit) e `init-reparo` configurado para rodar no boot
- [ ] Instalar e configurar GRUB2 (UEFI), gerar `grub.cfg`
- [ ] Validar: `fstab`, console, módulos, e parâmetros de kernel

### Fase 7 — Primeira inicialização e pós-boot
- [ ] Bootar no 3bLinux
- [ ] Rodar `bk-reparo` (deve ser idempotente)
- [ ] Configurar rede, timezone, usuários
- [ ] Configurar `bk-update` para sincronizar /var/3bLinux do seu servidor (seu repo caseiro)
- [ ] Rodar `bk-upstream` periodicamente para detectar versões novas


## Mapa de dependências (ordem sugerida dos scripts em packages/)

Formato: `pacote/script`

- `acl-2.3.2/build-acl-2.3.2.sh`
- `attr-2.5.2/build-attr-2.5.2.sh`
- `autoconf-2.72/build-autoconf-2.72.sh`
- `automake-1.18.1/build-automake-1.18.1.sh`
- `bash-5.3/build-bash-5.3.sh`
- `bc-7.0.3/build-bc-7.0.3.sh`
- `binutils-2.45.1/build-binutils-2.45.1.sh`
- `binutils-2.45.1-pass1/build-binutils-2.45.1-pass1.sh`
- `binutils-2.45.1-pass2/build-binutils-2.45.1-pass2.sh`
- `bison-3.8.2/build-bison-3.8.2.sh`
- `busybox-1.37.1/build-busybox-1.37.1.sh`
- `bzip2-1.0.15/build-bzip2-1.0.15.sh`
- `dejagnu-1.6.3/build-dejagnu-1.6.3.sh`
- `diffutils-3.12/build-diffutils-3.12.sh`
- `eudev-3.2.14/build-eudev-3.2.14.sh`
- `expect-5.45.4/build-expect-5.45.4.sh`
- `file-5.46/build-file-5.46.sh`
- `flex-2.6.4/build-flex-2.6.4.sh`
- `gawk-5.3.2/build-gawk-5.3.2.sh`
- `gcc-15.2.0/build-gcc-15.2.0.sh`
- `gcc-15.2.0-pass1/build-gcc-15.2.0-pass1.sh`
- `gcc-15.2.0-pass2/build-gcc-15.2.0-pass2.sh`
- `gdbm-1.23/build-gdbm-1.23.sh`
- `gettext-0.26/build-gettext-0.26.sh`
- `glibc-2.42/build-glibc-2.42.sh`
- `gmp-6.3.0/build-gmp-6.3.0.sh`
- `gperf-3.3/build-gperf-3.3.sh`
- `grep-3.12/build-grep-3.12.sh`
- `groff-1.23.0/build-groff-1.23.0.sh`
- `grub-2.14/build-grub-2.14-uefi.sh`
- `gzip-1.14/build-gzip-1.14.sh`
- `hwclock-2.40.2/build-hwclock-2.40.2.sh`
- `iana-etc-20251215/build-iana-etc-20251215.sh`
- `inetutils-2.7/build-inetutils-2.7.sh`
- `intltool-0.51.0/build-intltool-0.51.0.sh`
- `isl-0.27/build-isl-0.27.sh`
- `kernel-6.18.2/build-kernel-6.18.2.sh`
- `kernel-headers-6.18.2/build-kernel-headers-6.18.2.sh`
- `less-643/build-less-643.sh`
- `libcap-2.77/build-libcap-2.77.sh`
- `libtool-2.5.4/build-libtool-2.5.4.sh`
- `libxcrypt-4.5.2/build-libxcrypt-4.5.2.sh`
- `lz4-1.10.0/build-lz4-1.10.0.sh`
- `m4-1.4.20/build-m4-1.4.20.sh`
- `make-4.4.1/build-make-4.4.1.sh`
- `man-db-2.13.1/build-man-db-2.13.1.sh`
- `man-pages-6.16/build-man-pages-6.16.sh`
- `mpc-1.3.1/build-mpc-1.3.1.sh`
- `mpfr-4.2.2/build-mpfr-4.2.2.sh`
- `ncurses-6.5/build-ncurses-6.5.sh`
- `openssl-3.6.0/build-openssl-3.6.0.sh`
- `patch-2.8/build-patch-2.8.sh`
- `pcre2-10.47/build-pcre2-10.47.sh`
- `perl-5.42.0/build-perl-5.42.0.sh`
- `pkgconf-2.5.1/build-pkgconf-2.5.1.sh`
- `psmisc-23.7/build-psmisc-23.7.sh`
- `python-3.14.2/build-python-3.14.2.sh`
- `readline-8.3/build-readline-8.3.sh`
- `sed-4.9/build-sed-4.9.sh`
- `shadow-4.16.0/build-shadow-4.16.0.sh`
- `sysvinit-3.15/build-sysvinit-3.15.sh`
- `tar-1.35/build-tar-1.35.sh`
- `tcl-8.6.17/build-tcl-8.6.17.sh`
- `texinfo-7.2/build-texinfo-7.2.sh`
- `util-linux-2.41.3/build-util-linux-2.41.3.sh`
- `xml-parser-2.47/build-xml-parser-2.47.sh`
- `xz-5.8.2/build-xz-5.8.2.sh`
- `zlib-1.3/build-zlib-1.3.sh`
- `zstd-1.5.7/build-zstd-1.5.7.sh`

---

# Camada: build moderno (Meson/Ninja) e base Python packaging

Após ter Python + pip funcionando, você pode fechar uma base moderna de build para diversos projetos:

Ordem recomendada (por dependência):

1. `libffi-3.5.2` (recomendado antes de alguns bindings)
2. `libelf-elfutils-0.194` (base ELF tooling)
3. `sqlite-3510200` (db embutido; útil para diversas ferramentas)
4. `setuptools-80.9.0`
5. `wheel-0.46.1`
6. `packaging-25.0`
7. `flit-core-3.12.0`
8. `ninja-1.13.2`
9. `meson-1.10.0`

Notas:
- Scripts Python usam `pip3` com `--root` e `--prefix=/usr` para empacotar no formato bk.
- Para evitar conflitos, mantenha `--no-deps` (dependências resolvidas pela ordem acima).

