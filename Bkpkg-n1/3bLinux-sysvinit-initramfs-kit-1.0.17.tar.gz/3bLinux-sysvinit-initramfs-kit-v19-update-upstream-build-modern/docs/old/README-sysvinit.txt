Leia README.txt (canônico) para tutorial completo.

3bLinux - Kit sysvinit + initramfs + busybox + bk + GRUB
========================================================

Este kit foi montado em cima do bundle v6 do bk e fornece:

- Scripts bk (bk, bk-chroot, bk-reparo, bk-initramfs)
- Um rootfs de exemplo com estrutura SysV init:
    rootfs/etc/inittab
    rootfs/etc/init.d/rc
    rootfs/etc/init.d/rcS
    rootfs/etc/init.d/local
    rootfs/etc/rcS.d/
    rootfs/etc/rc0.d ... rc6.d
- Um exemplo de configuração do GRUB em:
    boot/grub/grub.cfg.example

Fluxo geral (alto nível)
------------------------
1. Construir o rootfs 3bLinux real (com sysvinit, busybox, bibliotecas, etc.)
   usando o bk para empacotar e instalar componentes no rootfs (ou diretamente em /).

2. Gerar o initramfs com busybox usando o bk-initramfs
   (por exemplo, saindo em /var/3bLinux/initramfs-3blinux.cpio.gz).

3. Copiar o kernel (vmlinuz-3blinux) e o initramfs gerado para /boot.

4. Configurar o GRUB usando o exemplo de grub.cfg, apontando para esse kernel+initramfs.

5. Bootar a máquina: o initramfs monta o root real e passa o controle para /sbin/init
   (sysvinit), que por sua vez usa /etc/inittab e os scripts em /etc/init.d e /etc/rc*.d.

Importante
----------
- Este kit NÃO inclui o binário do sysvinit, nem o do kernel ou do busybox.
  Ele fornece a estrutura de configuração (inittab, rc, rcS, rc.d) e o kit bk.
- O script bk-initramfs já gera um /init funcional para a imagem de initramfs:
  ele monta /proc, /sys, /dev, lê root=/3broot= e faz switch_root para o root real,
  chamando /sbin/init no sistema final.

Ajustes recomendados
--------------------
- Edite rootfs/etc/inittab conforme a sua necessidade (runlevel padrão, consoles, etc.).
- Crie scripts de serviços reais em rootfs/etc/init.d e links em rc*.d,
  seguindo o padrão SysV (K* para stop, S* para start).
- Ajuste o exemplo de fstab em rootfs/etc/fstab para os seus dispositivos reais.
- Ajuste o grub.cfg.example com o nome real do kernel, partição root, etc.



Ferramenta extra: init-reparo
-----------------------------
O script `init-reparo` faz sanity-check e reparos de melhor esforço no pipeline de boot:

  GRUB -> kernel -> initramfs (busybox) -> switch_root -> /sbin/init (sysvinit)

Ele trabalha por padrão em modo somente-relatório (dry-run). Para aplicar reparos:

  sudo init-reparo --apply
  sudo init-reparo --apply --yes
  sudo init-reparo --root /var/lib/bk/chroot-root --apply --report /tmp/init-reparo.log

O que ele faz:
- Cria diretórios essenciais ausentes no root alvo (/, /boot, /etc, /dev, /proc...)
- Cria links comuns (ex.: /bin/sh) quando apropriado
- Verifica presença de sysvinit (/sbin/init) e tenta instalar via `bk` se faltar
- Verifica kernel/initramfs em /boot; gera initramfs via bk-initramfs se estiver faltando
- Cria um /boot/grub/grub.cfg mínimo se estiver faltando (com placeholders a ajustar)
- Opcionalmente roda checks adicionais (--deep) como ldd para libs ausentes

Observação: ele NÃO adivinha seu disco/partição para GRUB; você precisa ajustar root= e set root=.

Integração automática do init-reparo no boot
--------------------------------------------
Este kit agora inclui:

- /sbin/init-reparo            (script principal, idempotente)
- rootfs/etc/init.d/init-reparo
- rootfs/etc/rcS.d/S01init-reparo -> ../init.d/init-reparo

Quando você copiar/usar o rootfs deste kit como base do seu sistema 3bLinux,
o sysvinit chamará /etc/init.d/rcS, que por sua vez executará todos os scripts
S* em /etc/rcS.d. O link S01init-reparo garante que o comando

  /sbin/init-reparo --apply --yes --boot

seja executado automaticamente em todo boot, garantindo:

- criação de diretórios essenciais,
- verificação e (quando possível) instalação de programas base via bk,
- verificação de /boot (kernel, initramfs, grub.cfg mínimo),
- logs gravados em /var/lib/bk/logs/init-reparo-*.log.

Como o init-reparo foi projetado para ser idempotente, ele pode rodar em todo
boot sem quebrar o sistema, apenas mantendo o pipeline de boot consistente.

Script de construção do busybox-1.37.1
--------------------------------------
Um script real de build do busybox foi adicionado em:

  packages/busybox-1.37.1/build-busybox-1.37.1.sh

Uso típico no sistema de build:

  cd packages/busybox-1.37.1
  chmod +x build-busybox-1.37.1.sh
  ./build-busybox-1.37.1.sh

Ele constrói o busybox em /tmp, instala em um PKG_ROOT temporário e, ao final,
gera um pacote bk (busybox-1.37.1) em /var/3bLinux, pronto para ser instalado
com:

  sudo bk install busybox-1.37.1


Build de sysvinit/udev/grub2 (UEFI)
---------------------------------
Scripts adicionados (build em /tmp, empacotamento via bk em /var/3bLinux):

- SysVinit 3.15:
  packages/sysvinit-3.15/build-sysvinit-3.15.sh

- udev (eudev) 3.2.14:
  packages/eudev-3.2.14/build-eudev-3.2.14.sh
  Exemplo de init script SysV:
    rootfs/etc/init.d/udev
    rootfs/etc/rcS.d/S03udev

- GRUB 2.14 com UEFI:
  packages/grub-2.14/build-grub-2.14-uefi.sh

Nota: o script do GRUB empacota as ferramentas; o grub-install no disco é manual.

Build de shadow/hwclock/gcc/binutils
-----------------------------------
Scripts adicionados (build em /tmp, empacotamento via bk em /var/3bLinux):

- Shadow 4.16.0:
  packages/shadow-4.16.0/build-shadow-4.16.0.sh
  Gera o pacote shadow-4.16.0 com binários de gerenciamento de contas
  e arquivos de configuração mínimos em /etc/login.defs e /etc/default/useradd
  dentro do PKG_ROOT.

- hwclock (util-linux 2.40.2):
  packages/hwclock-2.40.2/build-hwclock-2.40.2.sh
  Compila apenas o hwclock a partir do util-linux e gera o pacote
  hwclock-2.40.2 com /sbin/hwclock.

  Também foi adicionado script SysV para o hwclock:
    rootfs/etc/init.d/hwclock
    rootfs/etc/rcS.d/S02hwclock -> ../init.d/hwclock   (hctosys no boot)
    rootfs/etc/rc0.d/K99hwclock -> ../init.d/hwclock  (systohc no halt)
    rootfs/etc/rc6.d/K99hwclock -> ../init.d/hwclock  (systohc no reboot)

- Binutils 2.45.1:
  packages/binutils-2.45.1/build-binutils-2.45.1.sh

- GCC 15.2.0:
  packages/gcc-15.2.0/build-gcc-15.2.0.sh

Observe que GCC e binutils exigem toolchain e bibliotecas de suporte adequadas
(gmp/mpfr/mpc/isl para o GCC, por exemplo). Os scripts apenas automatizam o
fluxo padrão de configure/make/install + empacotamento via bk, mas as
dependências precisam estar resolvidas no sistema de build.
