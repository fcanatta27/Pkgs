# 3bLinux 1.0 – Notas de Release

## Visão Geral

O 3bLinux 1.0 é o primeiro release estável do kit de sistema baseado em:

- **Init SysV** simples e previsível.
- **Gerenciador de pacotes próprio (`bk`)** com suporte a snapshots e rollback.
- **Auto‑reparo de boot (`init-reparo`)**, rodando em todo boot.
- **Builds reprodutíveis** a partir de código‑fonte (scripts em `packages/`).

O objetivo é fornecer uma base sólida para:

- Servidores.
- Ambientes técnicos em modo texto.
- Testes, laboratório e aprendizado de Linux “de verdade”.
- Construção de distros derivadas.

## Principais destaques

### 1. `bk-install` – Instalador oficial

O 1.0 introduce o script `bk-install`, que:

- Detecta discos e partições.
- Permite escolher:
  - usar o disco inteiro (particionamento automático),
  - ou usar partições já existentes.
- Cria e/ou formata partições conforme necessário.
- Copia o rootfs base do kit para o disco de destino.
- Gera `/etc/fstab` automaticamente usando UUIDs.
- Cria `/etc/bk-update.conf` apontando para o repositório 1.0.
- Prepara chroot, roda `init-reparo` e tenta:
  - gerar initramfs com `bk-initramfs`,
  - instalar o GRUB (BIOS/UEFI).

Com isso, o caminho de “ISO → sistema instalado e bootável” fica objetivo e reproduzível.

### 2. `init-reparo` – Boot autorreparável

O `init-reparo` no 1.0:

- É executado em todo boot (via `rcS`).
- Usa lockfile para evitar concorrência.
- Valida e corrige:
  - `/etc/fstab` (pseudo‑FS, /run, /tmp, etc.).
  - `/etc/inittab` (initdefault, sysinit, gettys básicos).
  - Estrutura de `/etc/init.d` e symlinks em `/etc/rc*.d`.
- Integra com `bk-initramfs` para regenerar initramfs se estiver faltando.

Em outras palavras: o sistema tenta sempre **se consertar sozinho** para garantir um boot utilizável.

### 3. Repositório 1.0 com canais `stable` e `testing`

O repositório 1.0 é organizado como:

```text
3bLinux/1.0/
  stable/
    INDEX.v1
    INDEX.v1.asc
    pkgs/*.bk.tar.zst
  testing/
    INDEX.v1
    INDEX.v1.asc
    pkgs/*.bk.tar.zst
```

Características:

- Índice `INDEX.v1` com metadados (formato estável e versionado).
- Assinatura GPG obrigatória (`INDEX.v1.asc`).
- `bk-update` suporta escolha de canal e rollback via snapshots.
- `stable` recebe apenas correções e updates aprovados.
- `testing` é o lugar para novos pacotes e versões antes de promover para `stable`.

### 4. rootfs completo e coerente

O `rootfs/` do 3bLinux 1.0 inclui:

- `init` SysV funcional.
- Scripts de init para:
  - `mountvirtfs`, `checkfs`, `mountfs`, `swap`, `hwclock`,
  - `hostname`, `sysctl`, `urandom`, `udev`, `local`,
  - `sysklogd`, `dbus`, `iptables`, `init-reparo`.
- Estrutura de runlevels `/etc/rcS.d`, `/etc/rc0.d`…`/etc/rc6.d`.
- Arquivos de configuração principais em `/etc`:
  - `fstab`, `inittab`, `hosts`, `resolv.conf`,
  - `profile`, `profile.d/*`,
  - `nsswitch.conf`, `services`, `protocols`,
  - configs de PAM, dbus, syslog, iptables, GnuPG, make-ca, tzdata.

Isso permite que o sistema instalado seja utilizável logo no primeiro boot, sem uma pilha enorme
de passos manuais.

### 5. `bk-mkiso` – Geração de ISO de instalação

O release 1.0 inclui o script `tools/bk-mkiso`, que gera uma ISO bootável via `grub-mkrescue`/`xorriso`.
A ISO embute o kit em `/kit/` para execução do instalador `bk-install` no ambiente live.

## Compatibilidade e limites da 1.0

- Arquitetura alvo: **x86_64**.
- Init: **SysV** (systemd não é parte deste release).
- Foco em modo texto / servidor – não há ambiente gráfico pré‑instalado.
- Espera-se que o kernel e alguns drivers sejam fornecidos pelo ambiente de build ou por pacotes adicionais.

## Próximos passos (ideias para versões futuras)

- Ferramentas de rede mais avançadas (gerência automática de IPv4/IPv6).
- Metapacotes de perfis (servidor web, banco de dados, etc.).
- Imagens prontas para nuvem/VM (qcow2, raw).
- Integrar testes automatizados de boot (CI) para cada build.

---
3bLinux 1.0 é um ponto de partida sólido. A filosofia é simples:
> “Um sistema pequeno, previsível, que você entende e consegue consertar.”
