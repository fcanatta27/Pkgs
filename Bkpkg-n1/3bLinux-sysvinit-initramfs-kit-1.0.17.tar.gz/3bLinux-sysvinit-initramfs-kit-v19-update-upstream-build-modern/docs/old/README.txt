README - 3bLinux SysVinit + initramfs + bk-kit
==============================================

Visão geral
-----------
Este bundle entrega uma base funcional para um Linux "do zero" com foco em:
- gestão de pacotes por binários via **bk** (tar.gz + manifests),
- boot tradicional via **GRUB -> kernel -> initramfs (busybox) -> sysvinit**,
- reparo automático e idempotente do boot e da base do sistema via **init-reparo**,
- scripts "reais" de build (em /tmp) para compilar e empacotar componentes-chave no repositório **/var/3bLinux**.

Diretórios e convenções principais
---------------------------------
- Repositório de binários gerados (apenas pacotes):   /var/3bLinux
- Estado do bk:                                      /var/lib/bk
  - manifests:                                       /var/lib/bk/db
  - marcadores de instalação:                        /var/lib/bk/installed
  - logs (inclui init-reparo):                       /var/lib/bk/logs
- Scripts do kit (recomendado instalar em /sbin ou /usr/local/bin):
  - bk, bk-chroot, bk-reparo, bk-initramfs, init-reparo

Fluxo de boot (modelo recomendado)
---------------------------------
1) GRUB carrega:
   - /boot/vmlinuz-3blinux-*
   - /boot/initramfs-3blinux.cpio.gz (ou initramfs-3blinux.cpio.*)
2) initramfs (busybox) sobe mounts mínimos (/proc, /sys, /dev) e faz switch_root
3) sysvinit (/sbin/init) entra com /etc/inittab
4) rcS roda (scripts S* em /etc/rcS.d):
   - init-reparo (auto, idempotente)
   - udev (eudev) (se instalado)
   - hwclock (se instalado)
   - scripts locais (local)

Instalação do kit no host (build machine)
-----------------------------------------
1) Extraia este bundle.
2) Copie os scripts para o PATH do host:
   sudo cp bk bk-chroot bk-reparo bk-initramfs init-reparo /usr/local/bin/
   sudo chmod +x /usr/local/bin/bk /usr/local/bin/bk-chroot /usr/local/bin/bk-reparo /usr/local/bin/bk-initramfs /usr/local/bin/init-reparo

Operações do bk (pacotes por binário)
-------------------------------------

1) Criar pacote
   bk package NOME /caminho/para/prefix-root

   Exemplo (após um build script gerar PKG_ROOT):
   bk package busybox-1.37.1 /tmp/busybox-1.37.1-build/pkg-root

   Resultado:
   - /var/3bLinux/NOME-VERSAO-<timestamp>.tar.gz
   - /var/lib/bk/db/NOME-VERSAO.manifest

2) Instalar pacote
   sudo bk install NOME [VERSAO] [--root /]

3) Desinstalar pacote
   sudo bk uninstall NOME [VERSAO] [--root /]

4) Verificar pacote/manifest
   bk verify NOME [VERSAO]
   bk info   NOME [VERSAO]

bk-reparo (consistência do bk e do sistema)
-------------------------------------------
- Verifica pacotes órfãos, manifests inconsistentes e inconsistências típicas.
- Modos:
  bk-reparo --scan
  sudo bk-reparo --repair --auto-yes

bk-chroot (chroot seguro e temporário)
--------------------------------------
- Monta bind de /dev, /proc, /sys, /run e também /var/3bLinux e /var/lib/bk (opcional, padrão do kit).
- Possui 'shell' interativo e modo 'run' para executar comando e sair, sempre desmontando via trap.
  Exemplos:
    sudo bk-chroot create /var/lib/bk/chroot-root
    sudo bk-chroot shell /var/lib/bk/chroot-root
    sudo bk-chroot run /var/lib/bk/chroot-root bk info busybox-1.37.1

bk-initramfs (initramfs completo com busybox)
---------------------------------------------
- Gera initramfs com layout mínimo e um /init compatível com switch_root.
- Uso típico:
  sudo bk-initramfs -o /boot/initramfs-3blinux.cpio.gz

init-reparo (auto-reparo idempotente no boot)
---------------------------------------------
- Roda automaticamente no boot (via SysV link em rcS.d) e também pode ser usado manualmente.
- É idempotente: rodar repetidamente não deve "quebrar" nem reescrever configurações existentes desnecessariamente.
- O que ele cobre (alto nível):
  - diretórios essenciais
  - /dev mínimo (nós básicos)
  - /etc/passwd, /etc/group, /etc/shadow mínimos (se ausentes)
  - sysvinit básico (inittab, rcS, rc)
  - /boot: kernel, initramfs, grub.cfg mínimo (cria apenas se não existir)
  - limpeza de symlinks quebrados em paths críticos
  - integração com bk-reparo

- Execução manual:
  init-reparo            # padrão = apply e sem perguntas (ideal para boot)
  init-reparo --scan     # somente relatório
  sudo init-reparo --deep --report /tmp/init-reparo.log

Scripts SysV incluídos no rootfs (modelos)
------------------------------------------
Dentro de rootfs/ há modelos para você copiar para o root real:
- /etc/init.d/init-reparo  (garante execução automática no boot)
- /etc/init.d/udev         (sobe eudev/udev)
- /etc/init.d/hwclock      (RTC <-> sysclock)
- /etc/init.d/local        (gancho local)
- /etc/init.d/rcS e /etc/init.d/rc (orquestração SysV)

Build scripts (reais, build em /tmp, empacotamento via bk)
----------------------------------------------------------
Os diretórios em packages/ contêm scripts de build para compilar e gerar pacotes bk em /var/3bLinux:
- busybox-1.37.1
- kernel-6.18.2
- sysvinit-3.15
- eudev-3.2.14 (udev sem systemd)
- grub-2.14 (UEFI)  -> pacote "grub-2.14-uefi" (grub-install em disco é manual)
- shadow-4.16.0
- hwclock-2.40.2 (via util-linux 2.40.2)
- binutils-2.45.1
- gcc-15.2.0

Notas importantes de dependências
---------------------------------
- gcc-15.2.0 precisa de bibliotecas: gmp, mpfr, mpc, isl e zlib (além de um compilador C funcional prévio).
- eudev e grub podem exigir ferramentas adicionais (bison/flex/gettext/gperf/pkg-config). Os scripts agora apenas avisam;
  o ./configure indicará o que falta com precisão.

Checklist mínimo para "bootar"
------------------------------
1) /boot contém kernel e initramfs
2) /boot/grub/grub.cfg válido (ajustar root= e set root=)
3) /sbin/init (sysvinit) instalado
4) /etc/inittab e /etc/init.d/rcS presentes
5) init-reparo habilitado em /etc/rcS.d para manter tudo consistente

Arquivos e integridade
----------------------
Inventário (sha256 e linhas) dos scripts principais:
- bk
  - sha256: c30e1e8bf28bbd8e2cb1316f4d33ae3ff44c318cf97759adbf01641b48c79422
  - linhas: 367
- bk-chroot
  - sha256: 2c8836eb31bd848f7b0b4353d2be5f529a17f5d1238a034da1b9966ee6221fae
  - linhas: 254
- bk-initramfs
  - sha256: 18b377cd3bc560fc4edcbd9df887905f9f8f4b64c2ef07236420b60bc96bc081
  - linhas: 300
- bk-reparo
  - sha256: 4e5ac5dd4c40fa4585a9bb878adf451e78c7d78c023d5ea4e82c2a2d4659ab8e
  - linhas: 337
- init-reparo
  - sha256: b058265232ddceae10e6710e7fb20f2df5edd69fdb19f2e85f2005040c6ef9a8
  - linhas: 549
- packages/binutils-2.45.1/build-binutils-2.45.1.sh
  - sha256: fd45bab28842b81bfc8050a9a4fe887e223ae93774f864f8278b5bcb0f3eab80
  - linhas: 89
- packages/busybox-1.37.1/build-busybox-1.37.1.sh
  - sha256: db9cf3a22907acfb43ba2da044702c724321271af60354cf925500e60052a10f
  - linhas: 139
- packages/eudev-3.2.14/build-eudev-3.2.14.sh
  - sha256: 92cc8dda0ac40a3ca071dbb9f724c08a84023f686ead978155280df1972a55df
  - linhas: 33
- packages/gcc-15.2.0/build-gcc-15.2.0.sh
  - sha256: 4dbf10e91c29604206dceb114a64a37b34f0d5d973dc8dc50c54f5a105aabdef
  - linhas: 92
- packages/grub-2.14/build-grub-2.14-uefi.sh
  - sha256: ca3d8fe6e4188d4eeb6a0c93a0c46e6f5e7be02423da8add21432148a68f71e0
  - linhas: 41
- packages/hwclock-2.40.2/build-hwclock-2.40.2.sh
  - sha256: 067fbf1d4a49db71e8296f415c6202c5cf186b93c6110eb4bcbb033762c6e158
  - linhas: 88
- packages/kernel-6.18.2/build-kernel-6.18.2.sh
  - sha256: 90b0bfccf43a149f3e31f9c5272d905cd5c1317c61bcc022786272ae7bda8309
  - linhas: 168
- packages/shadow-4.16.0/build-shadow-4.16.0.sh
  - sha256: 258588e6397f79f0f66858ec0c7d508e50973dde1032c20f1b4e983c7eb41889
  - linhas: 115
- packages/sysvinit-3.15/build-sysvinit-3.15.sh
  - sha256: 99df0f83b08f1fe57ce8aa5394d84cab59d595fc4ecc7ecba25b9074cd7b377c
  - linhas: 32
- rootfs/etc/init.d/hwclock
  - sha256: 060742568d9fbb98f1dcffbb56cd515a50ec4e733877c77819a496da194434ad
  - linhas: 35
- rootfs/etc/init.d/init-reparo
  - sha256: 35bf0f108561ba3192933cec328fca1ec15ba9d7ece6492d4e35674403687b32
  - linhas: 29
- rootfs/etc/init.d/local
  - sha256: f8d71ec6e9c38fa63f3683aaf06435a35f0f8d4eb5769369327740895dc0caf6
  - linhas: 21
- rootfs/etc/init.d/rc
  - sha256: 6976b06f162f85391c63c2840847e6eaced5d389ee62410ddcb9c94b8b3733b4
  - linhas: 39
- rootfs/etc/init.d/rcS
  - sha256: 121dfed81d11537e1f8c171da59e35c61c1622066aaa22bcd52f9e155371882e
  - linhas: 18
- rootfs/etc/init.d/udev
  - sha256: ab1f84ac3e38ec19dd405b6a188f309cde2adcab475e048bf74039e2f8e09b8e
  - linhas: 23
- rootfs/etc/rc0.d/K99hwclock
  - sha256: 060742568d9fbb98f1dcffbb56cd515a50ec4e733877c77819a496da194434ad
  - linhas: 35
- rootfs/etc/rc3.d/S10local
  - sha256: f8d71ec6e9c38fa63f3683aaf06435a35f0f8d4eb5769369327740895dc0caf6
  - linhas: 21
- rootfs/etc/rc6.d/K99hwclock
  - sha256: 060742568d9fbb98f1dcffbb56cd515a50ec4e733877c77819a496da194434ad
  - linhas: 35
- rootfs/etc/rcS.d/S02hwclock
  - sha256: 060742568d9fbb98f1dcffbb56cd515a50ec4e733877c77819a496da194434ad
  - linhas: 35
- rootfs/etc/rcS.d/S03udev
  - sha256: ab1f84ac3e38ec19dd405b6a188f309cde2adcab475e048bf74039e2f8e09b8e
  - linhas: 23
- rootfs/etc/rcS.d/S10local
  - sha256: f8d71ec6e9c38fa63f3683aaf06435a35f0f8d4eb5769369327740895dc0caf6
  - linhas: 21

