#!/usr/bin/env bash
#
# build-liboauth-1.0.3.sh
#
# Build real do liboauth-1.0.3 para 3bLinux (formato bk).
# Baseado em BLFS liboauth-1.0.3.
#
set -euo pipefail

VER="1.0.3"
NAME="liboauth-${VER}"
TARBALL_NAME="${NAME}.tar.gz"
URL="https://downloads.sourceforge.net/liboauth/${TARBALL_NAME}"
PATCH_URL="https://www.linuxfromscratch.org/patches/blfs/svn/liboauth-1.0.3-openssl-1.1.0-3.patch"
PATCH_NAME="liboauth-1.0.3-openssl-1.1.0-3.patch"

BUILD_ROOT="/tmp/liboauth-${VER}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
PATCH_FILE="${BUILD_ROOT}/${PATCH_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="liboauth-${VER}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"

die() { echo "[build-liboauth-${VER}] Erro: $*" >&2; exit 1; }
info() { echo "[build-liboauth-${VER}] $*"; }

check_requirements() {
  command -v tar   >/dev/null 2>&1 || die "tar não encontrado."
  command -v gzip  >/dev/null 2>&1 || die "gzip não encontrado."
  command -v make  >/dev/null 2>&1 || die "make não encontrado."
  command -v gcc   >/dev/null 2>&1 || die "gcc não encontrado."
  command -v patch >/dev/null 2>&1 || die "patch não encontrado."
  command -v bk    >/dev/null 2>&1 || die "bk não encontrado."
}

prepare_dirs() {
  info "Preparando diretórios em ${BUILD_ROOT}"
  rm -rf "${BUILD_ROOT}"
  mkdir -p "${BUILD_ROOT}" "${PKG_ROOT}"
}

fetch_file() {
  local url="$1" dest="$2"
  if [ -f "${dest}" ]; then
    info "${dest} já presente, reutilizando."
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L -o "${dest}" "${url}"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "${dest}" "${url}"
  else
    die "precisa de curl ou wget."
  fi
}

download_sources() {
  info "Baixando fontes e patch"
  fetch_file "${URL}" "${TARBALL}"
  fetch_file "${PATCH_URL}" "${PATCH_FILE}"
}

extract_source() {
  info "Extraindo fonte ${TARBALL_NAME}"
  tar -xzf "${TARBALL}" -C "${BUILD_ROOT}"
  [ -d "${SRC_DIR}" ] || die "SRC_DIR não encontrado: ${SRC_DIR}"
}

apply_patch() {
  info "Aplicando patch OpenSSL em liboauth"
  cd "${SRC_DIR}"
  patch -Np1 -i "${PATCH_FILE}"
}

configure_build() {
  info "Configurando liboauth"
  cd "${SRC_DIR}"
  ./configure \
    --prefix=/usr \
    --disable-static || die "configure falhou."
}

build_liboauth() {
  info "Compilando liboauth (JOBS=${JOBS})"
  cd "${SRC_DIR}"
  make -j"${JOBS}"
}

install_into_pkgroot() {
  info "Instalando em PKG_ROOT=${PKG_ROOT}"
  cd "${SRC_DIR}"
  make DESTDIR="${PKG_ROOT}" install
}

package_with_bk() {
  info "Empacotando com bk: ${PKG_NAME}"
  bk package "${PKG_NAME}" "${PKG_ROOT}"
  bk info "${PKG_NAME}" || true
  info "Instale com: sudo bk install ${PKG_NAME}"
}

main() {
  check_requirements
  prepare_dirs
  download_sources
  extract_source
  apply_patch
  configure_build
  build_liboauth
  install_into_pkgroot
  package_with_bk
}

main "$@"
