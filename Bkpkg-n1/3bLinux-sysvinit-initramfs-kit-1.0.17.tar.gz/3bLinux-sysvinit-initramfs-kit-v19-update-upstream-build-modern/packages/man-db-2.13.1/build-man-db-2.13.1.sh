#!/usr/bin/env bash
#
# build-man-db-2.13.1.sh
#
# Build real do man-db 2.13.1 para 3bLinux, padrão bk.
#
# Observações:
# - man-db precisa de um troff (ex.: groff) para formatar páginas man em runtime.
# - Também pode exigir: zlib, xz, gdbm ou berkeley db, flex/bison dependendo do ambiente.
# - Este script empacota o man-db; dependências devem ser resolvidas pelo seu toolchain do 3bLinux.
#
set -euo pipefail

VER="2.13.1"
NAME="man-db-${VER}"
TARBALL_NAME="${NAME}.tar.xz"
URL="https://download-mirror.savannah.gnu.org/releases/man-db/${TARBALL_NAME}"

BUILD_ROOT="/tmp/man-db-${VER}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"
BUILD_DIR="${BUILD_ROOT}/build"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="man-db-${VER}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"

die() { echo "Erro: $*" >&2; exit 1; }
info() { echo "[build-man-db-${VER}] $*"; }

check_requirements() {
  command -v make >/dev/null 2>&1 || die "make não encontrado."
  command -v tar  >/dev/null 2>&1 || die "tar não encontrado."
  command -v xz   >/dev/null 2>&1 || die "xz não encontrado."
  command -v gcc  >/dev/null 2>&1 || die "gcc não encontrado."
  command -v bk   >/dev/null 2>&1 || die "bk não encontrado."

  command -v groff >/dev/null 2>&1 || info "Aviso: groff não encontrado (necessário para renderizar manpages em runtime)."
  command -v less  >/dev/null 2>&1 || info "Aviso: less não encontrado (pager padrão)."
}

prepare_dirs() {
  info "Preparando ${BUILD_ROOT}"
  rm -rf "${BUILD_ROOT}"
  mkdir -p "${BUILD_ROOT}" "${PKG_ROOT}"
}

download_source() {
  info "Baixando ${URL}"
  if [ -f "${TARBALL}" ]; then
    info "Tarball já presente, reutilizando."
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L -o "${TARBALL}" "${URL}"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "${TARBALL}" "${URL}"
  else
    die "precisa de curl ou wget."
  fi
}

extract_source() {
  info "Extraindo fonte"
  tar -xJf "${TARBALL}" -C "${BUILD_ROOT}"
  [ -d "${SRC_DIR}" ] || die "SRC_DIR não encontrado: ${SRC_DIR}"
}

configure_build() {
  info "Configurando man-db"
  mkdir -p "${BUILD_DIR}"
  cd "${BUILD_DIR}"

  "${SRC_DIR}/configure"     --prefix=/usr     --sysconfdir=/etc     --localstatedir=/var     --disable-setuid     --with-systemdtmpfilesdir=no     --with-systemdsystemunitdir=no || die "configure falhou. Verifique dependências."
}

build_man_db() {
  info "Compilando man-db (JOBS=${JOBS})"
  cd "${BUILD_DIR}"
  make -j"${JOBS}"
}

install_into_pkgroot() {
  info "Instalando em PKG_ROOT=${PKG_ROOT}"
  cd "${BUILD_DIR}"
  make DESTDIR="${PKG_ROOT}" install

  # Diretórios padrão de cache/db do mandb (runtime)
  mkdir -p "${PKG_ROOT}/var/cache/man" "${PKG_ROOT}/var/lib/man"
}

package_with_bk() {
  info "Empacotando com bk: ${PKG_NAME}"
  bk package "${PKG_NAME}" "${PKG_ROOT}"
  bk info "${PKG_NAME}" || true
  info "Instale com: sudo bk install ${PKG_NAME}"
}

main() {
  check_requirements
  prepare_dirs
  download_source
  extract_source
  configure_build
  build_man_db
  install_into_pkgroot
  package_with_bk
}

main "$@"
