#!/usr/bin/env bash
set -euo pipefail

NAME="dejavu-fonts"
VER="2.37"
URL="https://downloads.sourceforge.net/dejavu/dejavu-fonts-ttf-${VER}.tar.bz2"
TARBALL_NAME="dejavu-fonts-ttf-${VER}.tar.bz2"

BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

FONTDIR="${FONTDIR:-/usr/share/fonts/dejavu}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[dejavu] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[dejavu] %s\n' "$*"; }

fetch(){
  local out="$1"
  if have curl; then curl -L --fail --retry 3 -o "$out" "$URL"
  else wget -O "$out" "$URL"
  fi
}

main(){
  (have curl || have wget) || die "curl ou wget necessário"
  have tar || die "tar não encontrado"

  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"

  info "Baixando: $URL"
  fetch "${BUILD_ROOT}/${TARBALL_NAME}"
  tar -xf "${BUILD_ROOT}/${TARBALL_NAME}" -C "$SRC_DIR" --strip-components=1

  info "Instalando em staging"
  mkdir -p "${PKG_ROOT}${FONTDIR}"
  find "$SRC_DIR" -maxdepth 2 -type f -name '*.ttf' -print0 | xargs -0 -I{} install -m 0644 "{}" "${PKG_ROOT}${FONTDIR}/"

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
