# Dependências aproximadas dos pacotes – 3bLinux 1.0.2

Esta tabela resume dependências de runtime principais entre os pacotes. Todos presumem a presença do toolchain base (gcc, glibc, linux-headers).

| Pacote (packages/) | Dependências principais |
|--------------------|-------------------------|
| `Jinja2-3.1.6` | glibc |
| `Linux-PAM-1.7.1` | glibc |
| `MarkupSafe-3.0.3` | glibc |
| `acl-2.3.2` | glibc |
| `attr-2.5.2` | glibc |
| `autoconf-2.72` | glibc |
| `automake-1.18.1` | glibc |
| `bash-5.3` | glibc, readline, ncurses |
| `bc-7.0.3` | glibc |
| `binutils-2.45.1` | glibc |
| `binutils-2.45.1-pass1` | glibc |
| `binutils-2.45.1-pass2` | glibc |
| `bison-3.8.2` | glibc |
| `btrfs-progs-6.17.1` | glibc |
| `busybox-1.37.1` | glibc |
| `bzip2-1.0.8` | glibc |
| `dbus-1.16.2` | glibc, expat |
| `dejagnu-1.6.3` | glibc |
| `diffutils-3.12` | glibc |
| `dosfstools-4.2` | glibc |
| `e2fsprogs-1.47.3` | glibc |
| `eudev-3.2.14` | glibc |
| `expect-5.45.4` | glibc |
| `file-5.46` | glibc |
| `findutils-4.10.0` | glibc |
| `flex-2.6.4` | glibc |
| `flit-core-3.12.0` | glibc |
| `gawk-5.3.2` | glibc |
| `gcc-15.2.0` | glibc |
| `gcc-15.2.0-pass1` | glibc |
| `gcc-15.2.0-pass2` | glibc |
| `gdbm-1.23` | glibc |
| `gettext-0.26` | glibc |
| `glibc-2.42` | glibc |
| `gmp-6.3.0` | glibc |
| `gnupg-2.5.16` | glibc |
| `gperf-3.3` | glibc |
| `gpgme-2.0.1` | glibc |
| `grep-3.12` | glibc |
| `groff-1.23.0` | glibc |
| `grub-2.12` | glibc, xorriso |
| `grub-2.14` | glibc, xorriso |
| `gzip-1.14` | glibc |
| `hwclock-2.40.2` | glibc |
| `iana-etc-20251215` | glibc |
| `inetutils-2.7` | glibc |
| `intltool-0.51.0` | glibc |
| `iproute2-6.18.0` | glibc |
| `iptables-1.8.11` | glibc |
| `isl-0.27` | glibc |
| `kbd-2.9.0` | glibc |
| `kernel-6.18.2` | glibc |
| `kernel-headers-6.18.2` | glibc |
| `kmod-34.2` | glibc |
| `less-643` | glibc |
| `libcap-2.77` | glibc |
| `libelf-elfutils-0.194` | glibc |
| `libffi-3.5.2` | glibc |
| `liboauth-1.0.3` | glibc |
| `libpipeline-1.5.8` | glibc |
| `libtool-2.5.4` | glibc |
| `libxcrypt-4.5.2` | glibc |
| `lz4-1.10.0` | glibc |
| `m4-1.4.20` | glibc |
| `make-4.4.1` | glibc |
| `make-ca-1.16.1` | glibc |
| `man-db-2.13.1` | glibc |
| `man-pages-6.16` | glibc |
| `meson-1.10.0` | glibc |
| `mpc-1.3.1` | glibc |
| `mpfr-4.2.2` | glibc |
| `ncurses-6.5` | glibc |
| `ninja-1.13.2` | glibc |
| `openssl-3.6.0` | glibc |
| `packaging-25.0` | glibc |
| `parted-3.6` | glibc, readline, libuuid |
| `patch-2.8` | glibc |
| `pcre2-10.47` | glibc |
| `perl-5.42.0` | glibc |
| `pkgconf-2.5.1` | glibc |
| `procps-ng-4.0.5` | glibc |
| `psmisc-23.7` | glibc |
| `python-3.14.2` | glibc |
| `readline-8.3` | glibc |
| `reiserfsprogs-3.6.27` | glibc |
| `rsync-3.4.1` | glibc, zlib |
| `sed-4.9` | glibc |
| `setuptools-80.9.0` | glibc |
| `shadow-4.16.0` | glibc |
| `sqlite-3510200` | glibc |
| `sudo-1.9.17p2` | glibc, Linux-PAM |
| `sysklogd-2.7.2` | glibc |
| `sysvinit-3.15` | glibc |
| `tar-1.35` | glibc |
| `tcl-8.6.17` | glibc |
| `texinfo-7.2` | glibc |
| `tzdata-2025` | (nenhuma além de glibc base) |
| `util-linux-2.41.3` | glibc |
| `vim-9.1.2031` | glibc |
| `wheel-0.46.1` | glibc |
| `xfsprogs-6.18.0` | glibc |
| `xml-parser-2.47` | glibc |
| `xorriso-1.5.6` | glibc |
| `xz-5.8.2` | glibc |
| `zlib-1.3` | glibc |
| `zstd-1.5.7` | glibc |