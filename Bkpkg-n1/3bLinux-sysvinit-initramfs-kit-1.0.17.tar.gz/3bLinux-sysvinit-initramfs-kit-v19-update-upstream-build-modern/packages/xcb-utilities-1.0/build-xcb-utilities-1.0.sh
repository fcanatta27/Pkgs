#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
for p in xcb-util-0.4.1 xcb-util-image-0.4.1 xcb-util-keysyms-0.4.1 xcb-util-renderutil-0.3.10 xcb-util-wm-0.4.2; do
  "${ROOT_DIR}/tools/bk-build-wrapper" "$p"
done
