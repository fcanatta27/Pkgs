#!/usr/bin/env bash
set -euo pipefail

# autotools-1.0 - meta pacote para construir a toolchain autotools:
# m4, autoconf, automake, libtool (na ordem correta).

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
BK="${ROOT_DIR}/tools/bk-build-wrapper"

run() {
  echo "[autotools] >>> $*"
  "$BK" "$@"
}

echo "[autotools] Iniciando build da toolchain autotools..."

# Ordem recomendada (similar a LFS):
run m4-1.4.19 || true
run autoconf-2.72 || true
run automake-1.16.5 || true
run libtool-2.5.4 || true

echo "[autotools] Toolchain autotools concluída (verifique erros acima, se houver)."
