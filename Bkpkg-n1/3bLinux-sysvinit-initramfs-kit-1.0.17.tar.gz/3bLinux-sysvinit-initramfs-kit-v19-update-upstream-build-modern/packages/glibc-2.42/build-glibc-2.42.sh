#!/usr/bin/env bash
\
#!/usr/bin/env bash
#
# build-glibc-2.42.sh
#
# Build real (nativo) da glibc 2.42 para 3bLinux, padrão bk.
#
# ATENÇÃO:
#   - Este script assume um ambiente já relativamente estável (não é estágio inicial cross).
#   - Requer headers de kernel já instalados (kernel-headers-6.18.2).
#   - Requer toolchain funcional (binutils e gcc já instalados).
#
set -euo pipefail

VER="2.42"
NAME="glibc-${VER}"
TARBALL_NAME="${NAME}.tar.xz"
URL="https://ftp.gnu.org/gnu/libc/${TARBALL_NAME}"

BUILD_ROOT="/tmp/glibc-${VER}-build"
SRC_DIR="${BUILD_ROOT}/${NAME}"
BUILD_DIR="${BUILD_ROOT}/build"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="glibc-${VER}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"

die() { echo "Erro: $*" >&2; exit 1; }
info() { echo "[build-glibc-${VER}] $*"; }

check_requirements() {
  command -v make >/dev/null 2>&1 || die "make não encontrado."
  command -v tar  >/dev/null 2>&1 || die "tar não encontrado."
  command -v xz   >/dev/null 2>&1 || die "xz não encontrado."
  command -v gcc  >/dev/null 2>&1 || die "gcc não encontrado."
  command -v bk   >/dev/null 2>&1 || die "bk não encontrado."

  # glibc tipicamente exige:
  # - headers do kernel em /usr/include
  # - binutils/gcc compatíveis
}

prepare_dirs() {
  info "Preparando ${BUILD_ROOT}"
  rm -rf "${BUILD_ROOT}"
  mkdir -p "${BUILD_ROOT}" "${PKG_ROOT}"
}

download_source() {
  info "Baixando ${URL}"
  local tarball="${BUILD_ROOT}/${TARBALL_NAME}"
  if [ -f "${tarball}" ]; then
    info "Tarball já presente, reutilizando."
    TARBALL="${tarball}"
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L -o "${tarball}" "${URL}"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "${tarball}" "${URL}"
  else
    die "precisa de curl ou wget."
  fi
  TARBALL="${tarball}"
}

extract_source() {
  info "Extraindo fonte"
  tar -xJf "${TARBALL}" -C "${BUILD_ROOT}"
  [ -d "${SRC_DIR}" ] || die "SRC_DIR não encontrado: ${SRC_DIR}"
}

configure_build() {
  info "Configurando glibc (nativo)"
  mkdir -p "${BUILD_DIR}"
  cd "${BUILD_DIR}"

  # Ajuste do caminho do loader para x86_64; em outras arquiteturas, ajustar.
  "${SRC_DIR}/configure" \
    --prefix=/usr \
    --libdir=/usr/lib \
    --sysconfdir=/etc \
    --enable-kernel=4.19 \
    --enable-stack-protector=strong \
    --disable-werror || die "configure falhou. Verifique mensagens acima."
}

build_glibc() {
  info "Compilando glibc (JOBS=${JOBS})"
  cd "${BUILD_DIR}"
  make -j"${JOBS}"
}

install_into_pkgroot() {
  info "Instalando glibc em PKG_ROOT=${PKG_ROOT}"
  cd "${BUILD_DIR}"
  # O próprio glibc lida com estrutura interna de diretórios.
  make DESTDIR="${PKG_ROOT}" install
}

package_with_bk() {
  info "Empacotando com bk: ${PKG_NAME}"
  bk package "${PKG_NAME}" "${PKG_ROOT}"
  bk info "${PKG_NAME}" || true
  info "Instale com EXTREMO cuidado, pois glibc é core do sistema:"
  echo "  sudo bk install ${PKG_NAME}"
}

main() {
  check_requirements
  prepare_dirs
  download_source
  extract_source
  configure_build
  build_glibc
  install_into_pkgroot
  package_with_bk
}

main "$@"