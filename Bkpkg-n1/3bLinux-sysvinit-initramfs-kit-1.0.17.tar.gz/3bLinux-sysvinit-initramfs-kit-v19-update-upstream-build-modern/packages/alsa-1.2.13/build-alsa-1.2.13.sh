#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
"${ROOT_DIR}/tools/bk-build-wrapper" alsa-lib-1.2.13
"${ROOT_DIR}/tools/bk-build-wrapper" alsa-utils-1.2.13
