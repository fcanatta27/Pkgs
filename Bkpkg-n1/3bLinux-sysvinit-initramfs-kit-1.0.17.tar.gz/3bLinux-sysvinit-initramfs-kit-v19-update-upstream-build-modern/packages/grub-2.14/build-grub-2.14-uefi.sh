#!/usr/bin/env bash
\
#!/usr/bin/env bash
#
# build-grub-2.14-uefi.sh
#
# Build real do GRUB 2.14 com suporte UEFI (x86_64-efi), padrão bk.
# NÃO executa grub-install em disco; apenas empacota as ferramentas.
#
set -euo pipefail

VER="2.14"
NAME="grub-${VER}"
TARBALL_NAME="${NAME}.tar.gz"
URL="https://ftp.gnu.org/gnu/grub/${TARBALL_NAME}"

BUILD_ROOT="/tmp/grub-${VER}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="grub-${VER}-uefi"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"
TARGET="${TARGET:-x86_64}"

die() { echo "Erro: $*" >&2; exit 1; }
info() { echo "[build-grub-${VER}-uefi] $*"; }

check_requirements() {
  command -v make >/dev/null 2>&1 || die "make não encontrado."
  command -v tar  >/dev/null 2>&1 || die "tar não encontrado."
  command -v gcc  >/dev/null 2>&1 || die "gcc não encontrado."
  command -v bk   >/dev/null 2>&1 || die "bk não encontrado."

  command -v bison      >/dev/null 2>&1 || info "Aviso: bison não encontrado (pode ser necessário)."
  command -v flex       >/dev/null 2>&1 || info "Aviso: flex não encontrado (pode ser necessário)."
  command -v pkg-config >/dev/null 2>&1 || info "Aviso: pkg-config não encontrado (pode ser necessário)."
  command -v msgfmt     >/dev/null 2>&1 || info "Aviso: msgfmt (gettext) não encontrado (pode ser necessário)."
}

prepare_dirs() {
  info "Preparando ${BUILD_ROOT}"
  rm -rf "${BUILD_ROOT}"
  mkdir -p "${BUILD_ROOT}" "${PKG_ROOT}"
}

download_source() {
  info "Baixando ${URL}"
  if [ -f "${TARBALL}" ]; then
    info "Tarball já presente, reutilizando."
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L -o "${TARBALL}" "${URL}"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "${TARBALL}" "${URL}"
  else
    die "precisa de curl ou wget."
  fi
}

extract_source() {
  info "Extraindo fonte"
  tar -xzf "${TARBALL}" -C "${BUILD_ROOT}"
  [ -d "${SRC_DIR}" ] || die "SRC_DIR não encontrado: ${SRC_DIR}"
}

configure_build() {
  info "Configurando GRUB para UEFI (${TARGET}-efi)"
  cd "${SRC_DIR}"
  ./configure \
    --prefix=/usr \
    --sbindir=/sbin \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-werror \
    --with-platform=efi \
    --target="${TARGET}" || die "configure falhou. Verifique dependências."
}

build_grub() {
  info "Compilando GRUB (JOBS=${JOBS})"
  cd "${SRC_DIR}"
  make -j"${JOBS}"
}

install_into_pkgroot() {
  info "Instalando em PKG_ROOT=${PKG_ROOT}"
  cd "${SRC_DIR}"
  make DESTDIR="${PKG_ROOT}" install

  mkdir -p "${PKG_ROOT}/boot/grub"
}

package_with_bk() {
  info "Empacotando com bk: ${PKG_NAME}"
  bk package "${PKG_NAME}" "${PKG_ROOT}"
  bk info "${PKG_NAME}" || true

  info "Instale com:"
  echo "  sudo bk install ${PKG_NAME}"
  echo "Depois (manual, com cuidado):"
  echo "  sudo grub-install --target=x86_64-efi --efi-directory=/boot/efi --bootloader-id=3bLinux"
  echo "  sudo grub-mkconfig -o /boot/grub/grub.cfg"
}

main() {
  check_requirements
  prepare_dirs
  download_source
  extract_source
  configure_build
  build_grub
  install_into_pkgroot
  package_with_bk
}

main "$@"