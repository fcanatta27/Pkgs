#!/usr/bin/env bash
#
# build-libelf-elfutils-0.194.sh
#
# Constrói e empacota apenas libelf (de elfutils) para 3bLinux.
#
set -euo pipefail

VER="0.194"
NAME="elfutils-${VER}"
TARBALL_NAME="${NAME}.tar.bz2"
URL="https://sourceware.org/elfutils/ftp/${VER}/${TARBALL_NAME}"

BUILD_ROOT="/tmp/libelf-elfutils-${VER}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"
BUILD_DIR="${BUILD_ROOT}/build"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="libelf-elfutils-${VER}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"

die(){ echo "Erro: $*" >&2; exit 1; }
info(){ echo "[build-libelf] $*"; }

check_requirements(){
  for p in gcc make tar bzip2 bk; do
    command -v "$p" >/dev/null 2>&1 || die "$p não encontrado."
  done
}

prepare_dirs(){
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT" "$BUILD_DIR"
}

download_source(){
  info "Baixando $URL"
  if [ -f "$TARBALL" ]; then return; fi
  if command -v curl >/dev/null 2>&1; then
    curl -L -o "$TARBALL" "$URL"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$TARBALL" "$URL"
  else
    die "precisa de curl ou wget."
  fi
}

extract_source(){
  info "Extraindo fonte"
  tar -xjf "$TARBALL" -C "$BUILD_ROOT"
  [ -d "$SRC_DIR" ] || die "SRC_DIR não encontrado: $SRC_DIR"
}

configure_build(){
  info "Configurando (somente libs; desabilitando componentes não essenciais)"
  cd "$BUILD_DIR"
  "$SRC_DIR/configure" \
    --prefix=/usr \
    --disable-debuginfod \
    --disable-libdebuginfod \
    --disable-nls \
    --disable-rpath \
    --enable-shared \
    --disable-static || die "configure falhou."
}

build_all(){
  info "Compilando (JOBS=$JOBS)"
  cd "$BUILD_DIR"
  make -j"$JOBS"
}

install_into_pkgroot(){
  info "Instalando em PKG_ROOT=$PKG_ROOT"
  cd "$BUILD_DIR"
  make DESTDIR="$PKG_ROOT" install

  # Mantém apenas libelf e headers essenciais
  rm -rf "$PKG_ROOT/usr/bin" "$PKG_ROOT/usr/sbin" "$PKG_ROOT/usr/share" "$PKG_ROOT/etc" 2>/dev/null || true
  # Remove libs não-libelf (best-effort)
  find "$PKG_ROOT/usr/lib" -maxdepth 1 -type f -name "libdw*" -o -name "libasm*" -o -name "libdebuginfod*" 2>/dev/null | xargs -r rm -f
  rm -f "$PKG_ROOT/usr/lib/"*.la 2>/dev/null || true
}

package_with_bk(){
  info "Empacotando com bk: $PKG_NAME"
  bk package "$PKG_NAME" "$PKG_ROOT"
  bk info "$PKG_NAME" || true
}

main(){
  check_requirements
  prepare_dirs
  download_source
  extract_source
  configure_build
  build_all
  install_into_pkgroot
  package_with_bk
}
main "$@"
