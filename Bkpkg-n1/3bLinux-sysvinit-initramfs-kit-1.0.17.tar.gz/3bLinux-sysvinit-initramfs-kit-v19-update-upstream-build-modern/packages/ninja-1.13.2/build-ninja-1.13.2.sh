#!/usr/bin/env bash
#
# build-ninja-1.13.2.sh
#
# Ninja build system (bootstrap) para 3bLinux.
#
set -euo pipefail

VER="1.13.2"
NAME="ninja-1.13.2"
TARBALL_NAME="1.13.2.tar.gz"
URL="https://github.com/ninja-build/ninja/archive/refs/tags/v1.13.2.tar.gz"

BUILD_ROOT="/tmp/ninja-1.13.2-build"
TARBALL="${BUILD_ROOT}/ninja-v1.13.2.tar.gz"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="ninja-1.13.2"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"

die(){ echo "Erro: $*" >&2; exit 1; }
info(){ echo "[build-ninja] $*"; }

check_requirements(){
  for p in python3 gcc g++ make tar gzip bk; do
    command -v "$p" >/dev/null 2>&1 || die "$p não encontrado."
  done
}

prepare_dirs(){
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$SRC_DIR" "$PKG_ROOT"
}

download_source(){
  info "Baixando $URL"
  if [ -f "$TARBALL" ]; then return; fi
  if command -v curl >/dev/null 2>&1; then curl -L -o "$TARBALL" "$URL"
  elif command -v wget >/dev/null 2>&1; then wget -O "$TARBALL" "$URL"
  else die "precisa de curl ou wget."; fi
}

extract_source(){
  info "Extraindo"
  tar -xzf "$TARBALL" -C "$SRC_DIR" --strip-components=1
}

build_ninja(){
  info "Bootstrap ninja"
  cd "$SRC_DIR"
  python3 configure.py --bootstrap
}

install_into_pkgroot(){
  info "Instalando em PKG_ROOT"
  install -D -m 0755 "$SRC_DIR/ninja" "$PKG_ROOT/usr/bin/ninja"
}

package_with_bk(){
  info "Empacotando com bk: $PKG_NAME"
  bk package "$PKG_NAME" "$PKG_ROOT"
  bk info "$PKG_NAME" || true
}

main(){
  check_requirements
  prepare_dirs
  download_source
  extract_source
  build_ninja
  install_into_pkgroot
  package_with_bk
}
main "$@"
