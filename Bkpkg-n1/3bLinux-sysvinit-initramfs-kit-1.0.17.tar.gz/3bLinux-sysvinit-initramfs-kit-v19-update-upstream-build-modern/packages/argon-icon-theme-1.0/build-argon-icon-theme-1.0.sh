#!/usr/bin/env bash
set -euo pipefail

# ATENÇÃO: este script usa uma URL de exemplo (example.invalid).
# Substitua a variável URL pelo local real do tarball antes de usar em produção.


NAME="argon-icon-theme"
VER="1.0"
URL="https://example.invalid/argon-icon-theme-${VER}.tar.gz"
TARBALL_NAME="argon-icon-theme-${VER}.tar.gz"

BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

ICONDIR="${ICONDIR:-/usr/share/icons}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[argon-icon-theme] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[argon-icon-theme] %s\n' "$*"; }

fetch(){
  local out="$1"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 -o "$out" "$URL"
  else
    wget -O "$out" "$URL"
  fi
}

main(){
  (have curl || have wget) || die "curl ou wget necessário"
  command -v tar >/dev/null 2>&1 || die "tar não encontrado"

  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"

  info "Baixando: $URL"
  fetch "${BUILD_ROOT}/${TARBALL_NAME}"
  tar -xf "${BUILD_ROOT}/${TARBALL_NAME}" -C "$SRC_DIR" --strip-components=1
  cd "$SRC_DIR"

  info "Instalando tema Argon Icon em staging"
  mkdir -p "${PKG_ROOT}${ICONDIR}"
  cp -a Argon* "${PKG_ROOT}${ICONDIR}/"

  info "ATENÇÃO: ajuste a URL para o tarball real do tema argon-icon-theme."
  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
