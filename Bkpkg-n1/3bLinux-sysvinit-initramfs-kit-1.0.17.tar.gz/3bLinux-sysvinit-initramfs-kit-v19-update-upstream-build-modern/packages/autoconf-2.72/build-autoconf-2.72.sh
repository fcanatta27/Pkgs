#!/usr/bin/env bash
#
# build-autoconf-2.72.sh
#
set -euo pipefail

VER="2.72"
NAME="autoconf-${VER}"
TARBALL_NAME="${NAME}.tar.xz"
URL="https://ftp.gnu.org/gnu/autoconf/${TARBALL_NAME}"

BUILD_ROOT="/tmp/autoconf-${VER}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="autoconf-${VER}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"

die(){ echo "Erro: $*" >&2; exit 1; }
info(){ echo "[build-autoconf] $*"; }

check_requirements(){
  for p in m4 perl make tar xz bk; do
    command -v "$p" >/dev/null 2>&1 || die "$p não encontrado."
  done
}

prepare_dirs(){
  info "Preparando $BUILD_ROOT"
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT"
}

download_source(){
  info "Baixando $URL"
  if [ -f "$TARBALL" ]; then info "Tarball já presente."; return; fi
  if command -v curl >/dev/null 2>&1; then curl -L -o "$TARBALL" "$URL"
  elif command -v wget >/dev/null 2>&1; then wget -O "$TARBALL" "$URL"
  else die "precisa de curl ou wget."; fi
}

extract_source(){
  info "Extraindo fonte"
  tar -xJf "$TARBALL" -C "$BUILD_ROOT"
  [ -d "$SRC_DIR" ] || die "SRC_DIR não encontrado: $SRC_DIR"
}

configure_build(){
  info "Configurando autoconf"
  cd "$SRC_DIR"
  ./configure --prefix=/usr || die "configure falhou."
}

build_autoconf(){
  info "Compilando autoconf (JOBS=$JOBS)"
  cd "$SRC_DIR"
  make -j"$JOBS"
}

install_into_pkgroot(){
  info "Instalando em PKG_ROOT=$PKG_ROOT"
  cd "$SRC_DIR"
  make DESTDIR="$PKG_ROOT" install
}

package_with_bk(){
  info "Empacotando com bk: $PKG_NAME"
  bk package "$PKG_NAME" "$PKG_ROOT"
  bk info "$PKG_NAME" || true
}

main(){
  check_requirements
  prepare_dirs
  download_source
  extract_source
  configure_build
  build_autoconf
  install_into_pkgroot
  package_with_bk
}
main "$@"
