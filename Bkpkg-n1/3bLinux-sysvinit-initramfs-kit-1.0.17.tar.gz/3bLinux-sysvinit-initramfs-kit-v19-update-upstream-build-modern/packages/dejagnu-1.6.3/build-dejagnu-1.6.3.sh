#!/usr/bin/env bash
set -euo pipefail
VER="1.6.3"
NAME="dejagnu-${VER}"
TARBALL_NAME="${NAME}.tar.gz"
URL="https://ftp.gnu.org/gnu/dejagnu/${TARBALL_NAME}"
BUILD_ROOT="/tmp/dejagnu-${VER}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"
PKG_ROOT="${BUILD_ROOT}/pkg-root"
PKG_NAME="dejagnu-${VER}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"
die(){ echo "Erro: $*" >&2; exit 1; }
info(){ echo "[build-dejagnu-${VER}] $*"; }
check_requirements(){
  command -v make >/dev/null 2>&1 || die "make não encontrado."
  command -v tar  >/dev/null 2>&1 || die "tar não encontrado."
  command -v gzip >/dev/null 2>&1 || die "gzip não encontrado."
  command -v gcc  >/dev/null 2>&1 || die "gcc não encontrado."
  command -v bk   >/dev/null 2>&1 || die "bk não encontrado."
}
prepare_dirs(){
  info "Preparando $BUILD_ROOT"
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT"
}
download_source(){
  info "Baixando $URL"
  if [ -f "$TARBALL" ]; then info "Tarball já presente, reutilizando."; return; fi
  if command -v curl >/dev/null 2>&1; then curl -L -o "$TARBALL" "$URL"
  elif command -v wget >/dev/null 2>&1; then wget -O "$TARBALL" "$URL"
  else die "precisa de curl ou wget."; fi
}
extract_source(){
  info "Extraindo fonte"
  tar -xzf "$TARBALL" -C "$BUILD_ROOT"
  [ -d "$SRC_DIR" ] || die "SRC_DIR não encontrado: $SRC_DIR"
}
configure_build(){
  info "Configurando dejagnu"
  cd "$SRC_DIR"
  ./configure --prefix=/usr || die "configure falhou."
}
build_dejagnu(){
  info "Compilando dejagnu (JOBS=$JOBS)"
  cd "$SRC_DIR"
  make -j"$JOBS"
}
install_into_pkgroot(){
  info "Instalando em PKG_ROOT=$PKG_ROOT"
  cd "$SRC_DIR"
  make DESTDIR="$PKG_ROOT" install
}
package_with_bk(){
  info "Empacotando com bk: $PKG_NAME"
  bk package "$PKG_NAME" "$PKG_ROOT"
  bk info "$PKG_NAME" || true
}
main(){
  check_requirements
  prepare_dirs
  download_source
  extract_source
  configure_build
  build_dejagnu
  install_into_pkgroot
  package_with_bk
}
main "$@"
