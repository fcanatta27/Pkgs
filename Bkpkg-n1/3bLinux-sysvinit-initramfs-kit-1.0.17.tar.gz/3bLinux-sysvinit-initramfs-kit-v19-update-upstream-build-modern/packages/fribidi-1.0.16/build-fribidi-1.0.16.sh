#!/usr/bin/env bash
set -euo pipefail

NAME="fribidi"
VER="1.0.16"
TARBALL_NAME="fribidi-1.0.16.tar.xz"
URL="https://github.com/fribidi/fribidi/releases/download/v1.0.16/fribidi-1.0.16.tar.xz"

# Dependências (resumo):
# meson; ninja

SCRIPT_NAME="${0##*/}"
BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/usr}"
SYSCONFDIR="${SYSCONFDIR:-/etc}"
LOCALSTATEDIR="${LOCALSTATEDIR:-/var}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"

color(){ local c="$1"; shift; case "$c" in red) printf '\033[1;31m%s\033[0m\n' "$*";; yellow) printf '\033[1;33m%s\033[0m\n' "$*";; blue) printf '\033[1;34m%s\033[0m\n' "$*";; *) printf '%s\n' "$*";; esac; }
info(){ color blue "[bk-build] $*"; }
warn(){ color yellow "[bk-build] AVISO: $*"; }
die(){ color red "[bk-build] ERRO: $*"; exit 1; }

have(){ command -v "$1" >/dev/null 2>&1; }

need_tools() {
  have tar || die "tar não encontrado"
  (have curl || have wget) || die "curl ou wget é necessário para download"
  have make || warn "make não encontrado (alguns pacotes não usam make diretamente)"
  (have gcc || have cc) || warn "gcc/cc não encontrado (necessário para compilar)"
  have pkg-config || warn "pkg-config não encontrado (pode falhar em vários pacotes)"
}

fetch() {
  local out="$1"
  info "Baixando: $URL"
  if have curl; then
    curl -L --fail --retry 3 --retry-delay 1 -o "$out" "$URL"
  else
    wget -O "$out" "$URL"
  fi
}

extract_src() {
  local tarball="$1"
  info "Extraindo: $tarball"
  rm -rf "$SRC_DIR"
  mkdir -p "$SRC_DIR"
  tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
}

prepare() {
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT"
}

main() {
  need_tools
  prepare
  local tarball="${BUILD_ROOT}/${TARBALL_NAME}"
  fetch "$tarball"
  extract_src "$tarball"
  cd "$SRC_DIR"

  have meson || die "meson não encontrado"
  have ninja || die "ninja não encontrado"
  info "Configurando (meson)"
  meson setup build \
    --prefix="$PREFIX" \
    --sysconfdir="$SYSCONFDIR" \
    --localstatedir="$LOCALSTATEDIR" \
    -Ddocs=false \
    -Dtests=false \
  info "Compilando"
  ninja -C build -j "$JOBS" 
  info "Instalando em DESTDIR: $PKG_ROOT"
  DESTDIR="$PKG_ROOT" ninja -C build install

  info "Staging pronto: $PKG_ROOT"
  info "Use o wrapper tools/bk-build-wrapper para empacotar via bk."
}

main "$@"
