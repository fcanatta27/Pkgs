# Stack Xorg no Seu Sistema – Conceitos, Fluxo e Debug

Este documento descreve:

- O que compõe o stack Xorg que você vai empacotar:
  - `libdrm`
  - `mesa`
  - `libinput`
  - `xorg-server`
- A ordem lógica de build e dependências
- Como integrar com o resto do sistema (udev, serviços, usuário normal)
- Como debugar problemas típicos de Xorg em um sistema minimalista

A ideia é sempre pensar em **camadas**:

1. Kernel + DRM/KMS + /dev/dri
2. libdrm (user-space para DRM)
3. Mesa (implementações OpenGL/Vulkan/GLES, drivers Gallium, etc.)
4. libinput (entrada – mouse, teclado, touchpad, tablet)
5. xorg-server (servidor X11 em si)
6. Window manager / desktop (Openbox, XFCE, etc.)

Se uma camada abaixo não estiver funcionando, tudo acima quebra ou se comporta
de forma estranha.

---

## 1. Dependências e ordem de build

Ordem recomendada de build dos pacotes (categoria `xorg`):

1. `libdrm`
2. `mesa`
3. `libinput`
4. `xorg-server`
5. drivers de vídeo e input (não cobertos aqui, mas seguem depois)
6. `xinit` e WMs/DEs (Openbox, XFCE, etc.)

### 1.1 libdrm

- Biblioteca de espaço de usuário para falar com o DRM/KMS do kernel.
- Precisa de:
  - kernel com DRM/KMS habilitado (CONFIG_DRM, CONFIG_DRM_KMS_HELPER, driver da GPU)
  - `/dev/dri/card0` e/ou outros devices
  - libs de sistema básicas (glibc)

Sem `libdrm` funcional, `mesa` degrada para modos de software ou falha.

### 1.2 Mesa

- Implementa OpenGL/GLES/Vulkan para várias GPUs.
- Depende fortemente de:
  - `libdrm`
  - libs X (`libX11`, `libXext`, etc.) para drivers X11
  - driver de DRM do kernel carregado (amdgpu, i915, nouveau, etc.)
  - opcionalmente Wayland (se você habilitar backends wayland)

A combinação **mesa + libdrm + driver de kernel** é o que vai decidir:

- se você terá aceleração 3D
- se Xorg consegue usar o driver `modesetting` ou drivers específicos

### 1.3 libinput

- Biblioteca de entrada (mouse, teclado, touchpad, tablets, etc.).
- Usada tanto por Xorg quanto por Wayland compositors.
- Depende de:
  - `/dev/input/*` funcionando
  - `udev`/`eudev` rodando (para receber eventos de devices)
  - libs auxiliares como `libevdev`, `mtdev`, `libwacom` (conforme configuração)

Se `libinput` não estiver funcional:

- Xorg sobe, mas você fica sem teclado/mouse
- ou as entradas se comportam de forma errática

### 1.4 xorg-server

- É o servidor X em si (o "X" que o `startx` vai chamar).
- Depende de:
  - libs X (libX11, libXext, libXfont2, etc.)
  - `libdrm`, `mesa` (para drivers modesetting/nouveau/amdgpu/i915)
  - `libinput` (para input)
  - fontes básicas (terminus, misc, etc.)

Sem essas libs/drivers, Xorg vai exibir erros como:

- "No screens found"
- "Failed to load driver modesetting"
- "Failed to open /dev/dri/card0"
- "No input driver specified, ignoring this device"

---

## 2. Integração com o seu sistema de serviços

Para um desktop funcionar bem, a base do sistema precisa estar OK:

- `udev` / `eudev` rodando (serviço `udev` habilitado via `service enable udev 10`)
- syslog (para logs de Xorg, libinput, etc.)
- rede se quiser atualizar/instalar outras coisas (dhcpcd, etc.)
- usuário normal para rodar `startx`

Check rápido, dentro do seu sistema:

```sh
service list-enabled
```

Esperado:

- `udev`
- `syslog-ng`
- `dhcpcd`
- `cronie`
- `sshd` (opcional)

Se algo essencial estiver faltando, habilite com:

```sh
service enable udev 10
service enable syslog-ng 20
service enable dhcpcd 30
```

---

## 3. Fluxo típico para ter um X básico com startx

Supondo que você já criou recipes para:

- `xorg:libdrm`
- `xorg:mesa`
- `xorg:libinput`
- `xorg:xorg-server`
- drivers de vídeo (`xf86-video-*` ou usar `modesetting`)
- `xinit` (client side – startx)

Dentro do seu sistema (CHROOT ou já em boot real):

```sh
# libs e DRM
pkg build --install libdrm      xorg
pkg build --install mesa        xorg

# input
pkg build --install libinput    xorg

# xorg-server em si
pkg build --install xorg-server xorg

# (quando você criar) meta-pacote xorg-base
# pkg build --install xorg-base xorg
```

Depois, crie um usuário normal:

```sh
useradd -m -s /bin/bash user
passwd user
```

Logue como `user` e crie `~/.xinitrc`:

```sh
cat > ~/.xinitrc << 'EOF'
# ~/.xinitrc - sessão X simples
# Substitua pelo WM/DE que você empacotar:
# exec openbox-session
# exec i3
# exec xfce4-session
exec xterm
EOF
```

Em seguida:

```sh
startx
```

Se tudo estiver certo, você verá um X básico com `xterm` (ou o WM/DE definido).

---

## 4. Debug: problemas típicos e como atacar

Aqui estão os problemas mais comuns ao subir Xorg em uma base mínima, e como
investigar e corrigir.

### 4.1 Xorg não sobe: "No screens found"

Sintomas:

- `startx` falha
- No log `/var/log/Xorg.0.log` aparecem mensagens tipo:
  - `No screens found`
  - `failed to load driver: modesetting`
  - `failed to open /dev/dri/card0`

Passos de debug:

1. Verificar se `/dev/dri/card0` existe:

   ```sh
   ls -l /dev/dri
   ```

   Se não existir:

   - Checar se o driver DRM/KMS do kernel está habilitado (amdgpu, i915, nouveau, etc.).
   - Verificar se `udev` está rodando e criando devices:
     ```sh
     ps aux | grep udev
     ```
   - Verificar `dmesg | grep -i drm` para ver se o driver carregou.

2. Verificar se o driver de vídeo está instalado:

   - Se você usar `modesetting` (driver genérico), geralmente basta ter:
     - `xorg-server` com suporte a modesetting
     - `libdrm` + `mesa`

   - Se usar drivers específicos (`xf86-video-amdgpu`, `xf86-video-intel`, etc.),
     confira se as libs/driver estão instaladas no prefixo correto (`/usr/lib/xorg/modules/drivers`).

3. Conferir o log de Xorg:

   ```sh
   less /var/log/Xorg.0.log
   ```

   Procure por linhas com `(EE)` (errors) e `(WW)` (warnings).  
   Atenção especial para:

   - `Module "modesetting" not found`
   - `Failed to load module "fbdev"`
   - `Failed to load driver`

Possíveis correções:

- recompilar xorg-server com os drivers/suporte habilitados
- instalar drivers adicionais (`xf86-video-*`)
- corrigir configuração de kernel para habilitar DRM/KMS da GPU

### 4.2 Xorg sobe mas mouse/teclado não funcionam

Sintomas:

- A tela gráfica aparece, mas teclado/mouse não respondem.

Coisas para verificar:

1. `libinput` está instalado corretamente?

   ```sh
   pkg list | grep libinput
   ```

2. `udev` está rodando?

   ```sh
   ps aux | grep udev
   ```

3. Devices em `/dev/input` existem?

   ```sh
   ls -l /dev/input
   ```

4. No log de Xorg (`/var/log/Xorg.0.log`), veja se há erros do tipo:

   - `failed to load libinput`
   - `Failed to open /dev/input/event*`

Possíveis causas e correções:

- **Permissões**: o usuário não tem permissão em `/dev/input/*`.
  - solução rápida (não ideal, apenas para teste): adicionar o usuário a um grupo
    que tenha acesso (por exemplo, `input`) e configurar udev para isso.
- **Falta de libinput ou de dependências**:
  - garantir que `libinput` foi compilado com suporte a evdev/udev
- **udev não rodando**:
  - habilitar o serviço `udev` no seu init
  - conferir se o Daemon está subindo no boot

### 4.3 Xorg sobe, mas não há aceleração (tudo lento)

Sintomas:

- `glxinfo` (quando você empacotar mesa-demos) mostra renderer "llvmpipe" ou "softpipe"
- animações e movimento de janelas muito lentos

Verificações:

1. Conferir renderer:

   ```sh
   glxinfo | grep -i "renderer string"
   ```

   Se vier `llvmpipe` ou similar, é software.

2. Conferir `dmesg` para mensagens do driver da GPU:

   ```sh
   dmesg | grep -iE "drm|amdgpu|i915|nouveau"
   ```

Possíveis causas:

- driver DRM do kernel não habilitado ou falhando
- `mesa` compilada sem o driver desejado (por ex., sem `-D gallium-drivers=radeonsi` etc.)
- ausência de `libdrm` ou versão incompatível

Correções:

- Ajustar a configuração de `mesa` (opções meson) para incluir o driver correto.
- Atualizar/libdrm para uma versão mais recente e recompilar `mesa`.

### 4.4 Erros de bibliotecas ausentes (`libX11.so`, `libdrm.so`, etc.)

Sintomas:

- `startx` ou `Xorg` reclamam de `error while loading shared libraries: libXYZ.so: cannot open shared object file`

Verificações:

- Conferir se o arquivo existe em `/usr/lib`:
  ```sh
  ls /usr/lib | grep libX11
  ```
- Rodar `ldd` no binário:
  ```sh
  ldd /usr/bin/Xorg
  ```

Possíveis correções:

- instalar o pacote correspondente (libX11, libXext, etc.)
- rodar `ldconfig` se você vier a usar um cache de libs mais tarde
- garantir que o `--libdir=/usr/lib` foi usado nos `./configure`/meson

### 4.5 Xorg fecha imediatamente sem log

Verificações:

- Olhar `/var/log/Xorg.0.log`
- Verificar permissões:
  - se você está rodando `startx` como usuário normal
  - se o usuário tem acesso a `/dev/tty*`, `/dev/dri/*`, `/dev/input/*`

Possíveis correções:

- Rodar um teste **temporário** como root com `startx` para isolar se é problema
  de permissões (não deixe isso como solução definitiva).
- Criar regras de `udev` + grupos (`video`, `input`) para controlar acesso.

---

## 5. Estratégia geral de debug

Quando algo der errado:

1. **Logs primeiro**:
   - `/var/log/Xorg.0.log`
   - `dmesg`
   - logs de syslog (`/var/log/messages`, `/var/log/auth.log` etc.)

2. **Dispositivos depois**:
   - `/dev/dri/card0`
   - `/dev/input/*`
   - `lsmod` para drivers de kernel

3. **Bibliotecas e versões**:
   - `pkg list` (se você tiver essa funcionalidade)
   - `ldd` nos binários (`Xorg`, `libinput-list-devices`, etc.)

4. **Reproduzir o problema com mais verbosidade**:
   - rodar `Xorg` diretamente com opções de debug
   - usar `LIBGL_DEBUG=verbose` para ver detalhes de Mesa

Mantendo essa disciplina (logs → dispositivos → libs → versões), você reduz muito
o tempo de investigação quando expandir o sistema para um desktop completo.

## Window Managers, Terminais e Display Managers

Além do stack base (libdrm, mesa, libinput, xorg-server), este bundle inclui
recipes para:

- Window Managers:
  - `openbox` – leve e altamente configurável.
  - `twm` – WM clássico, ótimo para testes.

- Terminais:
  - `xterm`
  - `rxvt-unicode`

- Fontes:
  - `terminus-font` – fonte bitmap legível para console e X.

- Display Managers:
  - `xdm` – clássico, simples, baseado em XDMCP.
  - `lightdm` 1.32.0 – moderno, configurado para **não** usar systemd
    (usa PAM e serviços de login genéricos).

Fluxo típico:
- usar `xinit`/`startx` com WMs (openbox, twm) para debug inicial;
- depois configurar `xdm` ou `lightdm` para login gráfico automático.
