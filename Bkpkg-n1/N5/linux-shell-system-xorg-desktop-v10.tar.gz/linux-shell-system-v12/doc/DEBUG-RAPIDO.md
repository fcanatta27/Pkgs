DEBUG-RAPIDO.md
===============

Logs importantes:

- Xorg:
  - /var/log/Xorg.0.log
- NetworkManager:
  - /var/log/NetworkManager.log
- PipeWire (modo sistema):
  - /var/log/pipewire-system.log
- syslog-ng:
  - /var/log/messages ou /var/log/syslog, conforme configuração

Checklist de debug:

1. Problema de rede:
   - Verificar 'ip addr', 'ip route'
   - Verificar 'nmcli general status'
   - Verificar /var/log/NetworkManager.log
2. Problema de som:
   - Verificar 'pactl info' (se PipeWire-Pulse)
   - Verificar 'pw-top' (se existir)
   - Verificar se 'pipewire', 'wireplumber' estão rodando
3. Problema gráfico:
   - Verificar /var/log/Xorg.0.log
   - Verificar 'glxinfo' (mesa, aceleração)
4. Problemas de permissão:
   - Verificar se o usuário está nos grupos:
     - audio, video, input, plugdev, netdev, wheel, storage, power
