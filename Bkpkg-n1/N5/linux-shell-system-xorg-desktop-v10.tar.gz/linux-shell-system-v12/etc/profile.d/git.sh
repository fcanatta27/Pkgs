# /etc/profile.d/git.sh - integrações leves com git
if command -v git >/dev/null 2>&1; then
    : "${GIT_PAGER:=less}"
    export GIT_PAGER
fi
