# /etc/profile.d/man.sh - ajuda man pages
export MANWIDTH=80
