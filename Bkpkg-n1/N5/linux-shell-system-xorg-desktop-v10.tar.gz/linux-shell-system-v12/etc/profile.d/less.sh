# /etc/profile.d/less.sh - ajustes para o pager less
export LESS='-R -M -i'
export LESSCHARSET='utf-8'
export PAGER=less
