#!/bin/sh
#
# xf86-video-intel - X.Org video driver for Intel GPUs
#

pkg_name=xf86-video-intel
pkg_version=2.99.917
pkg_category=xorg
pkg_description="xf86-video-intel - Xorg video driver for Intel GPUs"
pkg_depends="toolchain:glibc xorg:xorg-server xorg:mesa xorg:libdrm xorg:libpciaccess"

pkg_url="https://www.x.org/archive/individual/driver/xf86-video-intel-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "xf86-video-intel-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
