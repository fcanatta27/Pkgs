#!/bin/sh
#
# rxvt-unicode - terminal emulador para X com suporte a Unicode
#

pkg_name=rxvt-unicode
pkg_version=9.31
pkg_category=xorg
pkg_description="rxvt-unicode - emulador de terminal leve para X com Unicode"
pkg_depends="toolchain:glibc xorg:libX11 xorg:libXft xorg:libXrender base:fontconfig base:freetype"

pkg_url="https://dist.schmorp.de/rxvt-unicode/Attic/rxvt-unicode-${pkg_version}.tar.bz2"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "rxvt-unicode-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --enable-256-color \
        --enable-unicode3 || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
