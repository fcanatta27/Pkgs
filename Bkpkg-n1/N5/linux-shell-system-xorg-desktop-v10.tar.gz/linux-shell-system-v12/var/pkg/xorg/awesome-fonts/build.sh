#!/bin/sh
pkg_name=awesome-fonts
pkg_version=6.5.2
pkg_category=xorg
pkg_description="awesome-fonts - Font Awesome ícones"
pkg_depends="toolchain:glibc"
pkg_url="https://github.com/FortAwesome/Font-Awesome/archive/refs/tags/${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "Font-Awesome-${pkg_version}" || return 1
    mkdir -p "$PKGROOT/usr/share/fonts/awesome"
    find . -type f -name '*.ttf' -exec cp -v '{}' "$PKGROOT/usr/share/fonts/awesome" \; || true
    return 0
}
