#!/bin/sh
#
# libevdev - wrapper para eventos de input do kernel
#

pkg_name=libevdev
pkg_version=1.13.1
pkg_category=xorg
pkg_description="libevdev - wrapper para a interface evdev do kernel Linux"
pkg_depends="toolchain:glibc"

pkg_url="https://www.freedesktop.org/software/libevdev/libevdev-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libevdev-${pkg_version}" || return 1

    meson setup build \
        --prefix=/usr \
        --libdir=/usr/lib \
        --buildtype=release || return 1

    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 0

    return 0
}
