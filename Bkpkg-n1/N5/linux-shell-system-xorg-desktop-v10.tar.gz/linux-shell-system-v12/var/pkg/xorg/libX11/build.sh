#!/bin/sh
#
# libX11 - Core X11 protocol client library
#

pkg_name=libX11
pkg_version=1.8.10
pkg_category=xorg
pkg_description="libX11 - core X11 protocol client library"
pkg_depends="toolchain:glibc xorg:xorgproto xorg:libxcb xorg:libXau xorg:libXdmcp"

pkg_url="https://www.x.org/archive/individual/lib/libX11-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libX11-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
