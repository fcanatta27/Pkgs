#!/bin/sh
#
# Recipe: /var/pkg/xorg/xorg-server/build.sh
#
# Xorg Server - servidor X11
#

pkg_name=xorg-server
pkg_version=21.1.13
pkg_category=xorg
pkg_description="Xorg Server - servidor X Window System"
pkg_depends="toolchain:glibc xorg:mesa xorg:libdrm xorg:libinput xorg:libX11 xorg:libXext xorg:libXfixes xorg:libXrender xorg:libXft xorg:libXdmcp xorg:libXau base:openssl base:zlib"

pkg_url="https://www.x.org/archive/individual/xserver/xorg-server-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "xorg-server-${pkg_version}" || return 1

    meson setup build \
        --prefix=/usr \
        --libdir=/usr/lib \
        --buildtype=release \
        -D xorg=true \
        -D xwayland=false \
        -D glamor=true \
        -D ipv6=true \
        -D suid_wrapper=true || return 1

    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1

    return 0
}
