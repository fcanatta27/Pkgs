#!/bin/sh
#
# openbox - leve window manager para X
#

pkg_name=openbox
pkg_version=3.6.1
pkg_category=xorg
pkg_description="openbox - leve window manager empilhado para X11"
pkg_depends="toolchain:glibc xorg:libX11 xorg:libXinerama xorg:libXft xorg:libXrandr xorg:libXcursor base:glib base:glib2 base:pango base:fontconfig base:freetype"

pkg_url="https://openbox.org/dist/openbox/openbox-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "openbox-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
