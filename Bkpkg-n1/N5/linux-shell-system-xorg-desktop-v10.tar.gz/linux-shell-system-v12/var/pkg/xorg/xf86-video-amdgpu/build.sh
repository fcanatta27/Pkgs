#!/bin/sh
#
# xf86-video-amdgpu - X.Org video driver for AMD GPUs
#

pkg_name=xf86-video-amdgpu
pkg_version=23.0.0
pkg_category=xorg
pkg_description="xf86-video-amdgpu - Xorg video driver for AMD Radeon GPUs"
pkg_depends="toolchain:glibc xorg:xorg-server xorg:mesa xorg:libdrm xorg:libpciaccess"

pkg_url="https://www.x.org/archive/individual/driver/xf86-video-amdgpu-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "xf86-video-amdgpu-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
