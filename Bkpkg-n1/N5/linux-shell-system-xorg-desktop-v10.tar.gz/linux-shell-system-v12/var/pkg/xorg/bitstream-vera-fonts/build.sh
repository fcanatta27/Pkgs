#!/bin/sh
pkg_name=bitstream-vera-fonts
pkg_version=1.10
pkg_category=xorg
pkg_description="bitstream-vera-fonts - fontes Bitstream Vera TTF"
pkg_depends="toolchain:glibc"
pkg_url="https://ftp.gnome.org/pub/GNOME/sources/ttf-bitstream-vera/${pkg_version}/ttf-bitstream-vera-${pkg_version}.tar.bz2"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "ttf-bitstream-vera-${pkg_version}" || return 1
    mkdir -p "$PKGROOT/usr/share/fonts/bitstream-vera"
    cp -v *.ttf "$PKGROOT/usr/share/fonts/bitstream-vera" || true
    return 0
}
