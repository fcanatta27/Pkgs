#!/bin/sh
#
# libXft - FreeType-based font drawing library for X
#

pkg_name=libXft
pkg_version=2.3.8
pkg_category=xorg
pkg_description="libXft - FreeType-based font drawing library for X"
pkg_depends="toolchain:glibc xorg:libXrender base:fontconfig base:freetype"

pkg_url="https://www.x.org/archive/individual/lib/libXft-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libXft-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
