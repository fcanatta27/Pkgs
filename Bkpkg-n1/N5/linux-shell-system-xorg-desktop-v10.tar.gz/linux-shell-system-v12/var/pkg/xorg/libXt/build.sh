#!/bin/sh
pkg_name=libXt
pkg_version=1.3.0
pkg_category=xorg
pkg_description="libXt - X Toolkit Intrinsics"
pkg_depends="xorg:libX11"
pkg_url="https://www.x.org/releases/individual/lib/libXt-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd libXt-${pkg_version} || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
