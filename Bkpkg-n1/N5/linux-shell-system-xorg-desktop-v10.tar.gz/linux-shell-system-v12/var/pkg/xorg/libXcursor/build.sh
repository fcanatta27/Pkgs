#!/bin/sh
#
# libXcursor - X cursor management library
#

pkg_name=libXcursor
pkg_version=1.2.3
pkg_category=xorg
pkg_description="libXcursor - X cursor management library"
pkg_depends="toolchain:glibc xorg:libXfixes xorg:libXrender xorg:libX11 xorg:libXrandr"

pkg_url="https://www.x.org/archive/individual/lib/libXcursor-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libXcursor-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
