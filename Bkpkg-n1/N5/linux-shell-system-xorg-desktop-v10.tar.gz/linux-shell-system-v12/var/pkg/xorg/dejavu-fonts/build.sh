#!/bin/sh
pkg_name=dejavu-fonts
pkg_version=2.37
pkg_category=xorg
pkg_description="dejavu-fonts - fontes DejaVu TTF"
pkg_depends="toolchain:glibc"
pkg_url="https://sourceforge.net/projects/dejavu/files/dejavu/${pkg_version}/dejavu-fonts-ttf-${pkg_version}.tar.bz2"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "dejavu-fonts-ttf-${pkg_version}" || return 1
    mkdir -p "$PKGROOT/usr/share/fonts/dejavu"
    cp -v *.ttf "$PKGROOT/usr/share/fonts/dejavu" || true
    return 0
}
