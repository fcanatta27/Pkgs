#!/bin/sh
pkg_name=xf86-video-modesetting
pkg_version=1.0.0
pkg_category=xorg
pkg_description="xf86-video-modesetting - driver de vídeo genérico para Xorg"
pkg_depends="xorg:xorg-server xorg:libpciaccess"
pkg_url="https://www.x.org/releases/individual/driver/xf86-video-modesetting-${pkg_version}.tar.bz2"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd xf86-video-modesetting-${pkg_version} || return 1

    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
