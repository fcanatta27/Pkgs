#!/bin/sh
#
# Recipe: /var/pkg/xorg/mesa/build.sh
#
# Mesa - drivers OpenGL/Vulkan/etc.
#

pkg_name=mesa
pkg_version=25.3.1
pkg_category=xorg
pkg_description="Mesa - implementação de OpenGL/GLES/Vulkan"
pkg_depends="toolchain:glibc xorg:libdrm base:zlib base:xz base:expat xorg:libX11 xorg:libXext xorg:libxcb"

pkg_url="https://mesa.freedesktop.org/archive/mesa-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "mesa-${pkg_version}" || return 1

    meson setup build \
        --prefix=/usr \
        --libdir=/usr/lib \
        --buildtype=release \
        -D platforms=x11 \
        -D gallium-drivers=auto \
        -D vulkan-drivers=auto \
        -D dri3=true \
        -D egl=true \
        -D gbm=true \
        -D glx=dri \
        -D shared-glapi=true || return 1

    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1

    return 0
}
