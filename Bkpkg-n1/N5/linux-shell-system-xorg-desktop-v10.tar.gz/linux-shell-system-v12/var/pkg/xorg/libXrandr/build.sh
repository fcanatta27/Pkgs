#!/bin/sh
#
# libXrandr - X RandR extension library
#

pkg_name=libXrandr
pkg_version=1.5.4
pkg_category=xorg
pkg_description="libXrandr - X Resize, Rotate and Reflect extension library"
pkg_depends="toolchain:glibc xorg:libXext xorg:libXrender xorg:xorgproto"

pkg_url="https://www.x.org/archive/individual/lib/libXrandr-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libXrandr-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
