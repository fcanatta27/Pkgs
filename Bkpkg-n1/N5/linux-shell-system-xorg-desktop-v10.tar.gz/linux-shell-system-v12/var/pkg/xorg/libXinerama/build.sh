#!/bin/sh
pkg_name=libXinerama
pkg_version=1.1.5
pkg_category=xorg
pkg_description="libXinerama - extensão de múltiplos monitores"
pkg_depends="xorg:libXext xorg:libX11"
pkg_url="https://www.x.org/releases/individual/lib/libXinerama-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd libXinerama-${pkg_version} || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
