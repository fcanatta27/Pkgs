#!/bin/sh
#
# lightdm - Display Manager leve (sem systemd)
#

pkg_name=lightdm
pkg_version=1.32.0
pkg_category=xorg
pkg_description="lightdm - display manager leve, configurado para não usar systemd"
pkg_depends="toolchain:glibc base:shadow base:glib base:gtk3 base:pam"

pkg_url="https://github.com/canonical/lightdm/releases/download/${pkg_version}/lightdm-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "lightdm-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --localstatedir=/var \
        --disable-tests \
        --with-systemd-logind=no || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
