#!/bin/sh
#
# pkg-config - helper para flags de compilação
#

pkg_name=pkg-config
pkg_version=0.29.2
pkg_category=base
pkg_description="pkg-config - ferramenta para descoberta de flags de compilação de libs"
pkg_depends="toolchain:glibc"

pkg_url="https://pkg-config.freedesktop.org/releases/pkg-config-${pkg_version}.tar.gz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "pkg-config-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --with-internal-glib \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
