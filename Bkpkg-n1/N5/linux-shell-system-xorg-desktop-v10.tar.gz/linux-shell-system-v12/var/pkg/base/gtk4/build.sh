#!/bin/sh
pkg_name=gtk4
pkg_version=4.20.3
pkg_category=base
pkg_description="gtk4 - toolkit gráfico GTK 4"
pkg_depends="toolchain:glibc base:glib base:pango base:fontconfig base:freetype base:gdk-pixbuf xorg:libX11 xorg:libXext xorg:libXrender xorg:libXrandr"
pkg_url="https://download.gnome.org/sources/gtk/${pkg_version%.*}/gtk-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "gtk-${pkg_version}" || return 1
    meson setup build --prefix=/usr --libdir=/usr/lib --buildtype=release || return 1
    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1
    return 0
}
