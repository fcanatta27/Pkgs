#!/bin/sh
pkg_name=sane-backends
pkg_version=1.3.1
pkg_category=base
pkg_description="sane-backends - suporte a scanners"
pkg_depends="toolchain:glibc base:usbutils base:libjpeg base:libpng"
pkg_url="https://gitlab.com/sane-project/backends/-/archive/${pkg_version}/backends-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd backends-${pkg_version} || return 1
    ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 0
}
