#!/bin/sh
pkg_name=ghostscript
pkg_version=10.03.1
pkg_category=base
pkg_description="Ghostscript - interpretador PostScript/PDF"
pkg_depends="toolchain:glibc base:zlib base:libjpeg base:libpng base:tiff"
pkg_url="https://github.com/ArtifexSoftware/ghostpdl-downloads/releases/download/gs${pkg_version//./}/ghostscript-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd ghostscript-${pkg_version} || return 1
    ./configure --prefix=/usr --disable-compile-inits --disable-gtk || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 0
}
