#!/bin/sh
pkg_name=tlp
pkg_version=1.6.0
pkg_category=base
pkg_description="TLP - otimização de energia para notebooks"
pkg_depends="toolchain:glibc base:bash base:grep base:sed base:coreutils"
pkg_url="https://github.com/linrunner/TLP/archive/refs/tags/${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd TLP-${pkg_version} || return 1
    make install DESTDIR="$PKGROOT" PREFIX=/usr || return 1
}
