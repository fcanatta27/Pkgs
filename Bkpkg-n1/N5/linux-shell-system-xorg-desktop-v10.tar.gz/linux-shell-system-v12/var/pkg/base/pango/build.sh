#!/bin/sh
#
# pango - layout de texto
#

pkg_name=pango
pkg_version=1.52.4
pkg_category=base
pkg_description="pango - layout e renderização de texto para GTK+"
pkg_depends="toolchain:glibc base:glib base:fontconfig base:freetype"

pkg_url="https://download.gnome.org/sources/pango/${pkg_version%.*}/pango-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "pango-${pkg_version}" || return 1

    meson setup build \
        --prefix=/usr \
        --libdir=/usr/lib \
        --buildtype=release || return 1

    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1

    return 0
}
