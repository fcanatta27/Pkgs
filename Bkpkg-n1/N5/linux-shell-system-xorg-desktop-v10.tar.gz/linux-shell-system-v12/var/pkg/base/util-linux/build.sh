#!/bin/sh
#
# Recipe: /var/pkg/base/util-linux/build.sh (Stage2, nativo)
#

pkg_name=util-linux
pkg_version=2.39.3
pkg_category=base
pkg_description="Utilitários essenciais do sistema (mount, fs, login, etc.)"
pkg_depends=""

pkg_url="https://mirrors.edge.kernel.org/pub/linux/utils/util-linux/v2.39/util-linux-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "util-linux-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --localstatedir=/var \
        --disable-chfn-chsh \
        --disable-login \
        --disable-nologin \
        --disable-su \
        --disable-setpriv \
        --without-python \
        --without-systemd \
        --without-udev || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
