#!/bin/sh
#
# ninja - executor de builds
#

pkg_name=ninja
pkg_version=1.12.0
pkg_category=base
pkg_description="ninja - pequeno executor de builds rápido"
pkg_depends="toolchain:glibc"

pkg_url="https://github.com/ninja-build/ninja/archive/refs/tags/v${pkg_version}.tar.gz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "ninja-${pkg_version}" || return 1

    mkdir -p "$PKGROOT/usr/bin"
    ./configure.py --bootstrap || return 1
    install -m 0755 ninja "$PKGROOT/usr/bin/ninja" || return 1

    return 0
}
