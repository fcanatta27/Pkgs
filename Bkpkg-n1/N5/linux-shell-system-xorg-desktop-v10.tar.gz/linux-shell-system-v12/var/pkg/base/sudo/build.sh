#!/bin/sh
pkg_name=sudo
pkg_version=1.9.17p2
pkg_category=base
pkg_description="sudo - execute comandos como outro usuário"
pkg_depends="toolchain:glibc base:pam"
pkg_url="https://www.sudo.ws/dist/sudo-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "sudo-${pkg_version}" || return 1
    ./configure --prefix=/usr --libexecdir=/usr/lib/sudo --with-rundir=/run/sudo --with-pam --with-editor=vi || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
