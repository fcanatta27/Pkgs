#!/bin/sh
pkg_name=man-db
pkg_version=2.13.1
pkg_category=base
pkg_description="man-db - visualizador e indexador de páginas de manual"
pkg_depends="toolchain:glibc base:less base:gdbm"
pkg_url="https://download.savannah.gnu.org/releases/man-db/man-db-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "man-db-${pkg_version}" || return 1
    ./configure --prefix=/usr --libexecdir=/usr/lib --sysconfdir=/etc --disable-setuid --with-browser=/usr/bin/less --with-pager=less --with-vgrind=no --with-grap=no || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
