#!/bin/sh
pkg_name=ffmpeg
pkg_version=7.0
pkg_category=base
pkg_description="ffmpeg - suíte de ferramentas de áudio/vídeo"
pkg_depends="toolchain:glibc base:zlib base:bzip2 base:xz base:libvpx base:libopus base:x264 base:x265"
pkg_url="https://ffmpeg.org/releases/ffmpeg-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd ffmpeg-${pkg_version} || return 1
    ./configure --prefix=/usr --enable-gpl --enable-libvpx --enable-libopus --enable-libx264 --enable-libx265 || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
