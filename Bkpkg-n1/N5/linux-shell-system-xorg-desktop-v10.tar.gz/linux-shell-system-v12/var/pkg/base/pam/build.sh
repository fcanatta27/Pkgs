#!/bin/sh
#
# Linux-PAM - Pluggable Authentication Modules
#

pkg_name=pam
pkg_version=1.6.0
pkg_category=base
pkg_description="Linux-PAM - módulos de autenticação"
pkg_depends="toolchain:glibc"

pkg_url="https://github.com/linux-pam/linux-pam/releases/download/v${pkg_version}/Linux-PAM-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "Linux-PAM-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --libdir=/usr/lib \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
