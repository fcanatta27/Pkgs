#!/bin/sh
#
# Recipe: /var/pkg/base/crontabs/build.sh
#

pkg_name=crontabs
pkg_version=1
pkg_category=base
pkg_description="Arquivos de crontab de sistema e diretórios cron.*"
pkg_depends=""

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    mkdir -p "$PKGROOT/usr/share/pkg-meta" || return 1
    echo "${pkg_name}-${pkg_version}" > "$PKGROOT/usr/share/pkg-meta/${pkg_name}.meta" || return 1
    return 0
}
"

    mkdir -p "$PKGROOT/etc"
    mkdir -p "$PKGROOT/etc/cron.d" "$PKGROOT/etc/cron.daily" "$PKGROOT/etc/cron.hourly" \
             "$PKGROOT/etc/cron.weekly" "$PKGROOT/etc/cron.monthly"

    if [ -f /etc/crontab ]; then
        cp -av /etc/crontab "$PKGROOT/etc/crontab"
    fi

    return 0
}
