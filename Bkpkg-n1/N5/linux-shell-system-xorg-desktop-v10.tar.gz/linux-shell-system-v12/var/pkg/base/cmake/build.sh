#!/bin/sh
pkg_name=cmake
pkg_version=3.30.5
pkg_category=base
pkg_description="CMake - sistema de construção multiplataforma"
pkg_depends="toolchain:glibc base:openssl base:zlib"
pkg_url="https://github.com/Kitware/CMake/releases/download/v${pkg_version}/cmake-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd cmake-${pkg_version} || return 1
    ./bootstrap --prefix=/usr || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
