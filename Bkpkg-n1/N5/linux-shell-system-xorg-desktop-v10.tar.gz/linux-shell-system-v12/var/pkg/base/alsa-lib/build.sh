#!/bin/sh
pkg_name=alsa-lib
pkg_version=1.2.15.3
pkg_category=base
pkg_description="ALSA library - API de áudio de baixo nível"
pkg_depends="toolchain:glibc"
pkg_url="https://www.alsa-project.org/files/pub/lib/alsa-lib-${pkg_version}.tar.bz2"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd alsa-lib-${pkg_version} || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
