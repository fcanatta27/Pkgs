#!/bin/sh
#
# Recipe: /var/pkg/base/base-system/build.sh
#
# Meta-pacote Stage2: garante que a base do sistema esteja instalada.
#

pkg_name=base-system
pkg_version=1
pkg_category=base
pkg_description="Meta-pacote do sistema base (util-linux, iproute2, kmod, e2fsprogs, procps-ng)"
pkg_depends="base:util-linux base:iproute2 base:kmod base:e2fsprogs base:procps-ng"

# Meta-pacote: não instala arquivos, só registra dependências.
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    mkdir -p "$PKGROOT/usr/share/pkg-meta" || return 1
    echo "${pkg_name}-${pkg_version}" > "$PKGROOT/usr/share/pkg-meta/${pkg_name}.meta" || return 1
    return 0
}
"
    mkdir -p "$PKGROOT"
    return 0
}
