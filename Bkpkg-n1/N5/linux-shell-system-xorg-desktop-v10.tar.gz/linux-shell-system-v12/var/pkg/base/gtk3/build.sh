#!/bin/sh
#
# gtk3 - toolkit gráfico
#

pkg_name=gtk3
pkg_version=3.24.41
pkg_category=base
pkg_description="gtk3 - toolkit gráfico para aplicações X/Wayland"
pkg_depends="toolchain:glibc base:glib base:pango base:fontconfig base:freetype base:atk base:gdk-pixbuf"

pkg_url="https://download.gnome.org/sources/gtk+/${pkg_version%.*}/gtk+-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "gtk+-${pkg_version}" || return 1

    meson setup build \
        --prefix=/usr \
        --libdir=/usr/lib \
        --buildtype=release || return 1

    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1

    return 0
}
