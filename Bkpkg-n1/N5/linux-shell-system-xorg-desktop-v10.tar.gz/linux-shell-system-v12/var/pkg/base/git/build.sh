#!/bin/sh
pkg_name=git
pkg_version=2.52.0
pkg_category=base
pkg_description="git - sistema de controle de versão distribuído"
pkg_depends="toolchain:glibc base:openssl base:zlib base:expat base:pcre2"
pkg_url="https://www.kernel.org/pub/software/scm/git/git-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "git-${pkg_version}" || return 1
    make prefix=/usr all || return 1
    make prefix=/usr DESTDIR="$PKGROOT" install || return 1
    return 0
}
