#!/bin/sh
pkg_name=libxcrypt
pkg_version=4.5.2
pkg_category=base
pkg_description="libxcrypt - biblioteca moderna de hashing de senhas"
pkg_depends="toolchain:glibc"
pkg_url="https://github.com/besser82/libxcrypt/archive/refs/tags/v${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libxcrypt-${pkg_version}" || return 1
    ./autogen.sh 2>/dev/null || true
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
