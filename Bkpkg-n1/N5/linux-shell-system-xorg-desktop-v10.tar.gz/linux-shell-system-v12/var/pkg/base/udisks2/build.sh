#!/bin/sh
pkg_name=udisks2
pkg_version=2.10.1
pkg_category=base
pkg_description="udisks2 - daemon de gerenciamento de discos"
pkg_depends="toolchain:glibc base:glib base:dbus base:eudev base:polkit"
pkg_url="https://github.com/storaged-project/udisks/archive/refs/tags/udisks-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd udisks-* || return 1
    ./autogen.sh 2>/dev/null || true
    ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --enable-available-modules || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 0
}
