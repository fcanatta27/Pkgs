#!/bin/sh
#
# Recipe: /var/pkg/base/eudev/build.sh
#

pkg_name=eudev
pkg_version=3.2.14
pkg_category=base
pkg_description="eudev - userspace device manager (udev) sem systemd"
pkg_depends="base:util-linux base:kmod toolchain:glibc"

pkg_url="https://github.com/gentoo/eudev/archive/refs/tags/v${pkg_version}.tar.gz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "eudev-${pkg_version}" || return 1

    mkdir -p build
    cd build || return 1

    ../configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --libdir=/usr/lib \
        --libexecdir=/lib/udev \
        --with-rootprefix= \
        --with-rootlibdir=/lib \
        --disable-manpages \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    mkdir -p "$PKGROOT/lib/udev/rules.d"
    return 0
}
