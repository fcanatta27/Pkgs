#!/bin/sh
pkg_name=pcre2
pkg_version=10.44
pkg_category=base
pkg_description="pcre2 - biblioteca de expressões regulares compatível com Perl"
pkg_depends="toolchain:glibc"
pkg_url="https://github.com/PCRE2Project/pcre2/releases/download/pcre2-${pkg_version}/pcre2-${pkg_version}.tar.bz2"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "pcre2-${pkg_version}" || return 1
    ./configure --prefix=/usr --enable-unicode --enable-pcre2-16 --enable-pcre2-32 --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
