#!/bin/sh
pkg_name=chromium
pkg_version=144.0.7559.59
pkg_category=base
pkg_description="Chromium - navegador web construído a partir do código-fonte"
pkg_depends="toolchain:glibc base:python3 devel:clang devel:llvm base:gtk3 base:dbus base:alsa-lib base:libvpx base:libopus base:nss base:nspr base:fontconfig base:freetype base:ffmpeg"
pkg_url="https://commondatastorage.googleapis.com/chromium-browser-official/chromium-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1

    cd chromium-${pkg_version} || return 1

    # O build do Chromium assume que 'gn' e 'ninja' estão instalados no sistema.
    if ! command -v gn >/dev/null 2>&1; then
        echo "Erro: 'gn' não encontrado no PATH (necessário para construir o Chromium)"
        return 1
    fi
    if ! command -v ninja >/dev/null 2>&1; then
        echo "Erro: 'ninja' não encontrado no PATH (necessário para construir o Chromium)"
        return 1
    fi

    mkdir -p out/Release || return 1
    gn gen out/Release --args='is_debug=false is_official_build=true use_system_ffmpeg=true use_system_libjpeg=true use_system_zlib=true symbol_level=0' || return 1
    ninja -C out/Release chrome || return 1

    mkdir -p "$PKGROOT/opt/chromium" "$PKGROOT/usr/bin" || return 1
    cp -a out/Release/* "$PKGROOT/opt/chromium/" || return 1
    ln -sf /opt/chromium/chrome "$PKGROOT/usr/bin/chromium" || return 1
}
