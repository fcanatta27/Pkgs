#!/bin/sh
pkg_name=lxqt-policykit
pkg_version=1.4.0
pkg_category=base
pkg_description="lxqt-policykit - agente gráfico de autenticação polkit"
pkg_depends="toolchain:glibc base:qt6 base:polkit"
pkg_url="https://github.com/lxqt/lxqt-policykit/archive/refs/tags/${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd lxqt-policykit-${pkg_version} || return 1
    cmake -S . -B build -DCMAKE_INSTALL_PREFIX=/usr || return 1
    cmake --build build || return 1
    DESTDIR="$PKGROOT" cmake --install build || return 1
}
