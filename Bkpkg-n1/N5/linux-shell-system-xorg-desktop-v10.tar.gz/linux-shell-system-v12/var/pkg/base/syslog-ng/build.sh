#!/bin/sh
#
# Recipe: /var/pkg/base/syslog-ng/build.sh
#

pkg_name=syslog-ng
pkg_version=4.6.0
pkg_category=base
pkg_description="syslog-ng - daemon de logs avançado"
pkg_depends="toolchain:glibc base:util-linux"

pkg_url="https://github.com/syslog-ng/syslog-ng/releases/download/syslog-ng-${pkg_version}/syslog-ng-${pkg_version}.tar.gz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "syslog-ng-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --localstatedir=/var \
        --disable-java \
        --disable-python || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
