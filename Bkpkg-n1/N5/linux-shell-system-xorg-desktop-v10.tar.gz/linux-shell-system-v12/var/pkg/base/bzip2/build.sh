#!/bin/sh
pkg_name=bzip2
pkg_version=1.0.8
pkg_category=base
pkg_description="bzip2 - compressor de dados de alta taxa"
pkg_depends="toolchain:glibc"
pkg_url="https://sourceware.org/pub/bzip2/bzip2-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "bzip2-${pkg_version}" || return 1
    make -f Makefile-libbz2_so || return 1
    make clean || return 1
    make || return 1
    mkdir -p "$PKGROOT/usr"
    make PREFIX="$PKGROOT/usr" install || return 1
    return 0
}
