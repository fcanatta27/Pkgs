#!/bin/sh
#
# libpciaccess - acesso a configuração PCI
#

pkg_name=libpciaccess
pkg_version=0.18.1
pkg_category=base
pkg_description="libpciaccess - biblioteca para acesso a dispositivos PCI"
pkg_depends="toolchain:glibc"

pkg_url="https://www.x.org/archive/individual/lib/libpciaccess-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libpciaccess-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
