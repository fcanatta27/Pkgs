#!/bin/sh
pkg_name=libvpx
pkg_version=1.14.0
pkg_category=base
pkg_description="libvpx - biblioteca de codecs VP8/VP9"
pkg_depends="toolchain:glibc"
pkg_url="https://github.com/webmproject/libvpx/archive/refs/tags/v${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd libvpx-${pkg_version} || return 1
    ./configure --prefix=/usr --disable-static --enable-vp8 --enable-vp9 || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
