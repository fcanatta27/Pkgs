#!/bin/sh
#
# Recipe: /var/pkg/base/grub/build.sh
#

pkg_name=grub
pkg_version=2.12
pkg_category=base
pkg_description="GRUB - Grand Unified Bootloader (BIOS/PC)"
pkg_depends="toolchain:glibc base:xz base:zlib base:e2fsprogs base:util-linux"

pkg_url="https://ftp.gnu.org/gnu/grub/grub-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "grub-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --with-platform=pc \
        --disable-werror || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
