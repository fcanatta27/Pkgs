#!/bin/sh
pkg_name=libpng
pkg_version=1.6.44
pkg_category=base
pkg_description="libpng - biblioteca para imagens PNG"
pkg_depends="toolchain:glibc base:zlib"
pkg_url="https://download.sourceforge.net/libpng/libpng-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libpng-${pkg_version}" || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
