#!/bin/sh
pkg_name=firefox-bin
pkg_version=147.0.1
pkg_category=base
pkg_description="Firefox - binário oficial Mozilla"
pkg_depends="toolchain:glibc base:gtk3 base:dbus base:alsa-lib base:libvpx base:libopus base:fontconfig base:freetype"
pkg_url="https://download-installer.cdn.mozilla.net/pub/firefox/releases/${pkg_version}/linux-x86_64/en-US/firefox-${pkg_version}.tar.bz2"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    mkdir -p "$PKGROOT/opt" "$PKGROOT/usr/bin"
    mv firefox "$PKGROOT/opt/firefox" || return 1
    ln -sf /opt/firefox/firefox "$PKGROOT/usr/bin/firefox"
}
