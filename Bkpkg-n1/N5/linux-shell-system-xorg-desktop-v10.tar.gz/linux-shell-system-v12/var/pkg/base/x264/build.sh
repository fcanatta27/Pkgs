#!/bin/sh
pkg_name=x264
pkg_version=20241001
pkg_category=base
pkg_description="x264 - codec H.264"
pkg_depends="toolchain:glibc"
pkg_url="https://download.videolan.org/pub/videolan/x264/snapshots/x264-snapshot-${pkg_version}-2245-stable.tar.bz2"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd x264-* || return 1
    ./configure --prefix=/usr --enable-shared --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
