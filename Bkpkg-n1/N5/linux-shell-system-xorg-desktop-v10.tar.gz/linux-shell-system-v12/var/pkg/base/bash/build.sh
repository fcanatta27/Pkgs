#!/bin/sh
pkg_name=bash
pkg_version=5.3
pkg_category=base
pkg_description="bash - shell padrão compatível com sh"
pkg_depends="toolchain:glibc base:ncurses base:readline"
pkg_url="https://ftp.gnu.org/gnu/bash/bash-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "bash-${pkg_version}" || return 1
    ./configure --prefix=/usr --with-curses --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    mkdir -p "$PKGROOT/bin"
    ln -sf ../usr/bin/bash "$PKGROOT/bin/bash"
    return 0
}
