#!/bin/sh
pkg_name=firewalld
pkg_version=2.1.1
pkg_category=base
pkg_description="firewalld - firewall dinâmico com frontend em D-Bus"
pkg_depends="toolchain:glibc base:python3 base:iptables base:dbus"
pkg_url="https://github.com/firewalld/firewalld/archive/refs/tags/v${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd firewalld-${pkg_version} || return 1
    python3 setup.py build || return 1
    python3 setup.py install --root="$PKGROOT" --prefix=/usr || return 1
}
