#!/bin/sh
pkg_name=glib
pkg_version=2.82.0
pkg_category=base
pkg_description="GLib - utilitários de baixo nível do GNOME"
pkg_depends="toolchain:glibc base:gettext base:libffi base:pcre2"
pkg_url="https://download.gnome.org/sources/glib/2.82/glib-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd glib-${pkg_version} || return 1
    meson setup build --prefix=/usr --libdir=/usr/lib --buildtype=release || return 1
    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1
}
