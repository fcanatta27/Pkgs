#!/bin/sh
pkg_name=clang
pkg_version=21.1.8
pkg_category=devel
pkg_description="Clang - compilador C/C++/Obj-C baseado em LLVM"
pkg_depends="devel:llvm"
pkg_url=""
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    mkdir -p "$PKGROOT/usr/share/pkg-meta" || return 1
    echo "${pkg_name}-${pkg_version}" > "$PKGROOT/usr/share/pkg-meta/${pkg_name}.meta" || return 1
    return 0
}

