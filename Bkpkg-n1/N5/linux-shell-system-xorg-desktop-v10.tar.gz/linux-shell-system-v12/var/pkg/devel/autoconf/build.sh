#!/bin/sh
#
# Recipe: /var/pkg/devel/autoconf/build.sh
#

pkg_name=autoconf
pkg_version=2.72
pkg_category=devel
pkg_description="autoconf - gerador de scripts configure"
pkg_depends="toolchain:glibc"

pkg_url="https://ftp.gnu.org/gnu/autoconf/autoconf-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "autoconf-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
