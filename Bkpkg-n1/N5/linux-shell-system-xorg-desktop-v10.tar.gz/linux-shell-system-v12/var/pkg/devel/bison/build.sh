#!/bin/sh
#
# Recipe: /var/pkg/devel/bison/build.sh
#

pkg_name=bison
pkg_version=3.8.2
pkg_category=devel
pkg_description="bison - gerador de analisadores sintáticos"
pkg_depends="toolchain:glibc"

pkg_url="https://ftp.gnu.org/gnu/bison/bison-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "bison-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --docdir=/usr/share/doc/bison-${pkg_version} || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
