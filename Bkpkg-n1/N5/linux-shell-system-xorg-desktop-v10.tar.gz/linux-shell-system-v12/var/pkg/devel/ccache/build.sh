#!/bin/sh
pkg_name=ccache
pkg_version=4.10
pkg_category=devel
pkg_description="ccache - cache para compilação C/C++"
pkg_depends="toolchain:glibc base:zstd base:zlib"
pkg_url="https://github.com/ccache/ccache/releases/download/v${pkg_version}/ccache-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "ccache-${pkg_version}" || return 1
    cmake -S . -B build -DCMAKE_INSTALL_PREFIX=/usr || return 1
    cmake --build build || return 1
    DESTDIR="$PKGROOT" cmake --install build || return 1
    return 0
}
