#!/bin/sh
#
# Recipe: /var/pkg/devel/libtool/build.sh
#

pkg_name=libtool
pkg_version=2.5.4
pkg_category=devel
pkg_description="libtool - suporte a bibliotecas compartilhadas portáveis"
pkg_depends="devel:autoconf devel:automake toolchain:glibc"

pkg_url="https://ftp.gnu.org/gnu/libtool/libtool-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libtool-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
