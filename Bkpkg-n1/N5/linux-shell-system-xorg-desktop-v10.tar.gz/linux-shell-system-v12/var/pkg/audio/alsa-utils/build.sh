#!/bin/sh
pkg_name=alsa-utils
pkg_version=1.2.15.2
pkg_category=audio
pkg_description="ALSA utilities - ferramentas de linha de comando para ALSA"
pkg_depends="audio:alsa-lib base:ncurses base:readline"
pkg_url="https://www.alsa-project.org/files/pub/utils/alsa-utils-${pkg_version}.tar.bz2"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "alsa-utils-${pkg_version}" || return 1
    ./configure --prefix=/usr --disable-static --with-udev-rules-dir=/usr/lib/udev/rules.d || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
