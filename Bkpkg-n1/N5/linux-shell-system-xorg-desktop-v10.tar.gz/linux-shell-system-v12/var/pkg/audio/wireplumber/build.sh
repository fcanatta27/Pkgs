#!/bin/sh
pkg_name=wireplumber
pkg_version=0.5.6
pkg_category=audio
pkg_description="wireplumber - gerenciador de sessão do PipeWire"
pkg_depends="toolchain:glibc base:glib base:lua base:dbus audio:pipewire"
pkg_url="https://gitlab.freedesktop.org/pipewire/wireplumber/-/archive/${pkg_version}/wireplumber-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd wireplumber-${pkg_version}* || return 1
    meson setup build --prefix=/usr --libdir=/usr/lib --buildtype=release || return 1
    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1
}
