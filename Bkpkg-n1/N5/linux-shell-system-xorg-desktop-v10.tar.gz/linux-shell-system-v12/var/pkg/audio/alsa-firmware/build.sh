#!/bin/sh
pkg_name=alsa-firmware
pkg_version=1.2.4
pkg_category=audio
pkg_description="ALSA firmware - firmwares para algumas placas de som"
pkg_depends="toolchain:glibc"
pkg_url="https://www.alsa-project.org/files/pub/firmware/alsa-firmware-${pkg_version}.tar.bz2"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "alsa-firmware-${pkg_version}" || return 1
    ./configure --prefix=/usr --with-hotplug-dir=/lib/firmware || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
