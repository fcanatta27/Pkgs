#!/bin/sh
pkg_name=pulseaudio-module-bluetooth
pkg_version=17.0
pkg_category=audio
pkg_description="Pulseaudio Bluetooth modules - suporte Bluetooth para áudio"
pkg_depends="toolchain:glibc base:glib base:dbus audio:alsa-lib net:bluez"
pkg_url="https://www.freedesktop.org/software/pulseaudio/releases/pulseaudio-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "pulseaudio-${pkg_version}" || return 1
    ./configure --prefix=/usr --disable-systemd-daemon --disable-bluez4 --enable-bluez5 || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
