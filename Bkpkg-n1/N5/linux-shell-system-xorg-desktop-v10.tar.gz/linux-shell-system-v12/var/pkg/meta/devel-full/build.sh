#!/bin/sh
pkg_name=devel-full
pkg_version=1
pkg_category=meta
pkg_description="Meta-pacote: toolchain de desenvolvimento completo"
pkg_depends="base:gcc base:binutils base:make base:cmake base:meson base:pkgconf devel:llvm devel:clang devel:ccache base:gdb base:git base:python3 lang:perl"
pkg_url=""
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    mkdir -p "$PKGROOT/usr/share/pkg-meta" || return 1
    echo "${pkg_name}-${pkg_version}" > "$PKGROOT/usr/share/pkg-meta/${pkg_name}.meta" || return 1
    return 0
}

