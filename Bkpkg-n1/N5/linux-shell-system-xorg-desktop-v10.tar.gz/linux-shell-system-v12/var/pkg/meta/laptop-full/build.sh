#!/bin/sh
pkg_name=laptop-full
pkg_version=1
pkg_category=meta
pkg_description="Meta-pacote: recursos extras para notebook (energia, bluetooth, sensores)"
pkg_depends="meta:desktop-full base:tlp base:upower base:lm-sensors base:brightnessctl daemon:acpid net:blueman net:bluez"
pkg_url=""
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    mkdir -p "$PKGROOT/usr/share/pkg-meta" || return 1
    echo "${pkg_name}-${pkg_version}" > "$PKGROOT/usr/share/pkg-meta/${pkg_name}.meta" || return 1
    return 0
}

