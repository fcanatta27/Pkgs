#!/bin/sh
pkg_name=bluez
pkg_version=5.78
pkg_category=net
pkg_description="bluez - stack Bluetooth para Linux"
pkg_depends="toolchain:glibc base:glib base:dbus base:eudev"
pkg_url="https://www.kernel.org/pub/linux/bluetooth/bluez-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "bluez-${pkg_version}" || return 1
    ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --disable-systemd || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
