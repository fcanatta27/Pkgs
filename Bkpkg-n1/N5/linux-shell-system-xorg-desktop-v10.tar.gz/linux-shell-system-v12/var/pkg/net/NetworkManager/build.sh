#!/bin/sh
pkg_name=NetworkManager
pkg_version=1.54.3
pkg_category=net
pkg_description="NetworkManager - gerenciador de conexões de rede"
pkg_depends="toolchain:glibc base:glib base:dbus base:libnl base:libndp net:iw base:iproute2"
pkg_url="https://download.gnome.org/sources/NetworkManager/1.54/NetworkManager-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "NetworkManager-${pkg_version}" || return 1
    ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --disable-systemd --with-resolvconf=no --with-config-dns-rc-manager=none || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
