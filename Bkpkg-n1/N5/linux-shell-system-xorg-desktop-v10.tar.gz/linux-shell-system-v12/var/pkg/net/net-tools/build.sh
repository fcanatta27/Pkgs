#!/bin/sh
pkg_name=net-tools
pkg_version=2.10
pkg_category=net
pkg_description="net-tools - ifconfig, route, netstat, etc"
pkg_depends="toolchain:glibc"
pkg_url="https://sourceforge.net/projects/net-tools/files/net-tools-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "net-tools-${pkg_version}" || return 1
    yes "" | make config || return 1
    make || return 1
    make BASEDIR="$PKGROOT" install || return 1
    return 0
}
