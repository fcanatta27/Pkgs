#!/bin/sh
#
# /cross-toolchain/04-glibc.sh - Glibc para o sistema alvo (instala em $ROOTFS)
#
# Requer:
#   - Linux headers já instalados em $ROOTFS/usr/include
#   - GCC pass1 e Binutils cross em $TOOLS
#

set -eu
. "$(dirname "$0")/config.sh"

SRC_URL="https://ftp.gnu.org/gnu/glibc/glibc-${GLIBC_VER}.tar.xz"

tarball=$(download "$SRC_URL" "$SRC_DIR")

builddir="$BUILD_DIR/glibc-${GLIBC_VER}-build"
rm -rf "$builddir"
mkdir -p "$builddir"
cd "$builddir"

tar xf "$tarball"
cd "glibc-${GLIBC_VER}"

mkdir -p build
cd build

BUILD_TRIPLET=$(../scripts/config.guess 2>/dev/null || echo "x86_64-unknown-linux-gnu")
HOST_TRIPLET="$CROSS_TARGET"

../configure \
    --prefix=/usr \
    --build="$BUILD_TRIPLET" \
    --host="$HOST_TRIPLET" \
    --with-headers="$ROOTFS/usr/include" \
    --enable-kernel=3.2 \
    --disable-werror \
    libc_cv_slibdir=/usr/lib

make -j"$JOBS"
make DESTDIR="$ROOTFS" install

echo "04-glibc: instalada em $ROOTFS (prefix=/usr)."
