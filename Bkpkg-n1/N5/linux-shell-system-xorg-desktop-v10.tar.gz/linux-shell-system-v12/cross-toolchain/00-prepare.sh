#!/bin/sh
#
# /cross-toolchain/00-prepare.sh - Prepara diretórios e layout básico
#

set -eu
. "$(dirname "$0")/config.sh"

echo "Preparando diretórios:"
echo "  ROOTFS = $ROOTFS"
echo "  TOOLS  = $TOOLS"
echo "  SRC    = $SRC_DIR"
echo "  BUILD  = $BUILD_DIR"

mkdir -p "$ROOTFS" "$TOOLS" "$SRC_DIR" "$BUILD_DIR"

# Opcional: link /tools -> $TOOLS (útil em alguns fluxos LFS)
if [ ! -e /tools ]; then
    ln -s "$TOOLS" /tools 2>/dev/null || true
fi

echo "00-prepare: pronto."
