#!/bin/sh
#
# /cross-toolchain/config.sh - Configuração comum para a toolchain temporária
#
# Convenções:
#   - Rootfs final: /mnt/rootfs (ajustável via ROOTFS)
#   - Toolchain temporária: $ROOTFS/tools
#   - Build e fontes: /tmp (ajustável via BUILD_DIR e SRC_DIR)
#
#   ROOTFS       : raiz do sistema alvo
#   TOOLS        : prefixo da toolchain temporária
#   CROSS_TARGET : tripla alvo (ex.: x86_64-lfs-linux-gnu)
#   JOBS         : paralelismo (make -j)
#

set -eu

ROOTFS=${ROOTFS:-/mnt/rootfs}
TOOLS=${TOOLS:-"$ROOTFS/tools"}
SRC_DIR=${SRC_DIR:-/tmp/src}
BUILD_DIR=${BUILD_DIR:-/tmp/build}
JOBS=${JOBS:-$(nproc 2>/dev/null || echo 4)}
CROSS_TARGET=${CROSS_TARGET:-x86_64-lfs-linux-gnu}

# Versões alinhadas com as recipes do sistema final
LINUX_VER=${LINUX_VER:-6.18.2}
BINUTILS_VER=${BINUTILS_VER:-2.45.1}
GLIBC_VER=${GLIBC_VER:-2.42}
GCC_VER=${GCC_VER:-15.2.0}

export ROOTFS TOOLS SRC_DIR BUILD_DIR JOBS CROSS_TARGET
export LINUX_VER BINUTILS_VER GLIBC_VER GCC_VER

mkdir -p "$ROOTFS" "$TOOLS" "$SRC_DIR" "$BUILD_DIR"

download() {
    url=$1
    dest_dir=$2

    mkdir -p "$dest_dir"
    file=$dest_dir/$(basename "$url")

    if [ -f "$file" ]; then
        echo "$file"
        return 0
    fi

    if command -v curl >/dev/null 2>&1; then
        curl -L --fail --retry 3 --retry-delay 2 -o "$file".part "$url" || {
            rm -f "$file".part
            echo "download: falha ao baixar $url" >&2
            return 1
        }
        mv "$file".part "$file"
        echo "$file"
        return 0
    elif command -v wget >/dev/null 2>&1; then
        wget -O "$file".part "$url" || {
            rm -f "$file".part
            echo "download: falha ao baixar $url" >&2
            return 1
        }
        mv "$file".part "$file"
        echo "$file"
        return 0
    else:
        echo "download: é necessário curl ou wget." >&2
        return 1
    fi
}
