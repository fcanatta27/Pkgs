#!/bin/sh
#
# Recipe: /var/pkg/base/coreutils/build.sh
#
# Esperado pelo /usr/bin/pkg:
#   - Variáveis:
#       pkg_name, pkg_version, pkg_category
#       pkg_description (opcional, recomendado)
#       pkg_depends (opcional)
#       pkg_url (opcional)  -> se definido, o pkg fará download via curl e expõe SRCFILE
#   - Função build():
#       deve instalar em DESTDIR="$PKGROOT"
#
# Convenções disponíveis (exportadas por pkg):
#   - PKGROOT : diretório DESTDIR final do pacote
#   - WORKDIR : diretório de trabalho para build (você deve compilar aqui)
#   - SRCFILE : caminho do tarball baixado (se pkg_url definido)
#

pkg_name=coreutils
pkg_version=9.5
pkg_category=base
pkg_description="GNU Core Utilities (ls, cp, mv, etc.)"
pkg_depends="glibc"

pkg_url="https://ftp.gnu.org/gnu/coreutils/coreutils-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"

    if [ -z "${SRCFILE:-}" ] || [ ! -f "$SRCFILE" ]; then
        echo "Recipe coreutils: SRCFILE ausente. Verifique pkg_url e curl." >&2
        return 1
    fi

    cd "$WORKDIR" || return 1
    rm -rf "coreutils-${pkg_version}"
    tar xf "$SRCFILE" || return 1
    cd "coreutils-${pkg_version}" || return 1

    # Ajuste BUILD/TARGET conforme seu ambiente (cross, chroot, etc.)
    if [ -z "${BUILD:-}" ]; then
        BUILD=$(./build-aux/config.guess 2>/dev/null || echo "x86_64-unknown-linux-gnu")
    fi
    if [ -z "${TARGET:-}" ]; then
        TARGET="$BUILD"
    fi

    ./configure \
        --prefix=/usr \
        --host="$TARGET" \
        --build="$BUILD" \
        --enable-no-install-program=kill,uptime || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
