#!/bin/sh
#
# Recipe: /var/pkg/toolchain/gcc/build.sh (modo nativo)
#
# Observações:
#   - GCC pode baixar prerequisitos (gmp/mpfr/mpc/isl) via download_prerequisites.
#   - Para builds mais "distro-grade", é comum empacotar prerequisitos separadamente.
#

pkg_name=gcc
pkg_version=15.2.0
pkg_category=toolchain
pkg_description="GNU Compiler Collection - native"
pkg_depends="toolchain:binutils toolchain:glibc"

pkg_url="https://gcc.gnu.org/pub/gcc/releases/gcc-${pkg_version}/gcc-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "gcc-${pkg_version}" || return 1

    # Baixar prerequisitos (gmp/mpfr/mpc/isl) dentro do tree do gcc.
    if [ -x ./contrib/download_prerequisites ]; then
        ./contrib/download_prerequisites || return 1
    fi

    mkdir -p build
    cd build || return 1

    # Build nativo: sem --target. Prefix final /usr.
    ../configure \
        --prefix=/usr \
        --disable-multilib \
        --enable-languages=c,c++ \
        --enable-shared \
        --enable-threads=posix \
        --enable-__cxa_atexit \
        --with-system-zlib || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
