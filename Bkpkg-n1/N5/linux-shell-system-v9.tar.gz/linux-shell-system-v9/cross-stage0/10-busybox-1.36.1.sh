#!/bin/sh
#
# /cross-stage0/10-busybox-1.36.1.sh - Stage0 BusyBox (fornece /bin/sh e utilitários básicos)
#

set -eu
. "$(dirname "$0")/config.sh"

VERSION=1.36.1
SRC_URL="https://busybox.net/downloads/busybox-${VERSION}.tar.bz2"

tarball=$(download "$SRC_URL" "$SRC_DIR")

builddir="$BUILD_DIR/busybox-${VERSION}-stage0-build"
rm -rf "$builddir"
mkdir -p "$builddir"
cd "$builddir"

tar xf "$tarball"
cd "busybox-${VERSION}"

# Limpa qualquer build anterior
make distclean >/dev/null 2>&1 || true

# Configuração padrão como base
make defconfig

# Garante que 'sh' esteja habilitado (busybox shell)
# E que será instalado em /bin
# (em geral defconfig já habilita 'sh', este trecho é best-effort)
if command -v sed >/dev/null 2>&1; then
    sed -i 's/^# CONFIG_SH is not set/CONFIG_SH=y/' .config 2>/dev/null || true
fi

# Compila BusyBox para o alvo, usando a toolchain cross
make -j"$JOBS" CROSS_COMPILE="${CROSS_TARGET}-"

# Instala no rootfs
make CONFIG_PREFIX="$ROOTFS" install

# Garante /bin/sh → busybox
if [ -x "$ROOTFS/bin/busybox" ]; then
    mkdir -p "$ROOTFS/bin"
    ln -sf busybox "$ROOTFS/bin/sh"
fi

echo "stage0: BusyBox ${VERSION} instalado em $ROOTFS."
