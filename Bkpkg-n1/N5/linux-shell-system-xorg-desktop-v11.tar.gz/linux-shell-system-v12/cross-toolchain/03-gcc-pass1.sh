#!/bin/sh
#
# /cross-toolchain/03-gcc-pass1.sh - GCC pass1 (sem headers, só para C) em $TOOLS
#
# Requer:
#   - Binutils cross instalados em $TOOLS
#

set -eu
. "$(dirname "$0")/config.sh"

SRC_URL="https://gcc.gnu.org/pub/gcc/releases/gcc-${GCC_VER}/gcc-${GCC_VER}.tar.xz"

tarball=$(download "$SRC_URL" "$SRC_DIR")

builddir="$BUILD_DIR/gcc-${GCC_VER}-pass1-build"
rm -rf "$builddir"
mkdir -p "$builddir"
cd "$builddir"

tar xf "$tarball"
cd "gcc-${GCC_VER}"

# Baixar prerequisitos (gmp/mpfr/mpc/isl)
if [ -x ./contrib/download_prerequisites ]; then
    ./contrib/download_prerequisites
fi

mkdir -p build
cd build

../configure \
    --target="$CROSS_TARGET" \
    --prefix="$TOOLS" \
    --with-glibc-version="$GLIBC_VER" \
    --with-sysroot="$ROOTFS" \
    --with-newlib \
    --without-headers \
    --enable-languages=c \
    --disable-nls \
    --disable-shared \
    --disable-multilib \
    --disable-decimal-float \
    --disable-threads \
    --disable-libatomic \
    --disable-libgomp \
    --disable-libquadmath \
    --disable-libssp \
    --disable-libvtv \
    --disable-libstdcxx

make -j"$JOBS" all-gcc all-target-libgcc
make install-gcc install-target-libgcc

echo "03-gcc-pass1: GCC cross C-only instalado em $TOOLS."
