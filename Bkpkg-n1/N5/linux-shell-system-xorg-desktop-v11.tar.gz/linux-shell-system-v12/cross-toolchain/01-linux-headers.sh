#!/bin/sh
#
# /cross-toolchain/01-linux-headers.sh - Instala Linux API Headers no rootfs
#

set -eu
. "$(dirname "$0")/config.sh"

SRC_URL="https://www.kernel.org/pub/linux/kernel/v6.x/linux-${LINUX_VER}.tar.xz"

tarball=$(download "$SRC_URL" "$SRC_DIR")

builddir="$BUILD_DIR/linux-${LINUX_VER}-build"
rm -rf "$builddir"
mkdir -p "$builddir"
cd "$builddir"

tar xf "$tarball"
cd "linux-${LINUX_VER}"

make mrproper
make headers_install INSTALL_HDR_PATH="$ROOTFS/usr"

find "$ROOTFS/usr/include" \( -name '.install' -o -name '..install.cmd' \) -delete 2>/dev/null || true

echo "01-linux-headers: instalado em $ROOTFS/usr/include."
