#!/bin/sh
#
# /cross-toolchain/05-gcc-pass2.sh - GCC pass2 usando glibc no rootfs
#
# Requer:
#   - Glibc já instalada em $ROOTFS
#

set -eu
. "$(dirname "$0")/config.sh"

SRC_URL="https://gcc.gnu.org/pub/gcc/releases/gcc-${GCC_VER}/gcc-${GCC_VER}.tar.xz"

tarball=$(download "$SRC_URL" "$SRC_DIR")

builddir="$BUILD_DIR/gcc-${GCC_VER}-pass2-build"
rm -rf "$builddir"
mkdir -p "$builddir"
cd "$builddir"

tar xf "$tarball"
cd "gcc-${GCC_VER}"

if [ -x ./contrib/download_prerequisites ]; then
    ./contrib/download_prerequisites
fi

mkdir -p build
cd build

BUILD_TRIPLET=$(../config.guess 2>/dev/null || echo "x86_64-unknown-linux-gnu")

../configure \
    --target="$CROSS_TARGET" \
    --build="$BUILD_TRIPLET" \
    --prefix="$TOOLS" \
    --with-sysroot="$ROOTFS" \
    --with-glibc-version="$GLIBC_VER" \
    --enable-languages=c,c++ \
    --disable-multilib \
    --disable-nls \
    --enable-shared \
    --enable-threads=posix \
    --enable-__cxa_atexit \
    --with-system-zlib

make -j"$JOBS"
make install

echo "05-gcc-pass2: GCC cross (C/C++) final instalado em $TOOLS."
