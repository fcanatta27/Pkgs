#!/bin/sh
# Script simples para tratar botão de energia via acpid
# Ajuste conforme seu init (chamar /sbin/poweroff, /sbin/halt, etc.)

if command -v poweroff >/dev/null 2>&1; then
    poweroff
elif command -v halt >/dev/null 2>&1; then
    halt
fi
