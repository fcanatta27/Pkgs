#!/bin/sh
#
# Recipe: /var/pkg/toolchain/binutils/build.sh (modo nativo)
#

pkg_name=binutils
pkg_version=2.45.1
pkg_category=toolchain
pkg_description="GNU Binutils (ld, as, objdump, etc.) - native"
pkg_depends=""

pkg_url="https://ftp.gnu.org/gnu/binutils/binutils-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "binutils-${pkg_version}" || return 1

    mkdir -p build
    cd build || return 1

    # Build nativo: sem --target/--sysroot.
    # Ajuste opções conforme seu objetivo (gold/ld, plugins, etc.).
    ../configure \
        --prefix=/usr \
        --disable-nls \
        --enable-shared \
        --with-system-zlib || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
