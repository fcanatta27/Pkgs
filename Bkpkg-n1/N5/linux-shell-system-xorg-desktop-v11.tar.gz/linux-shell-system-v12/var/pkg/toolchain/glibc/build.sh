#!/bin/sh
#
# Recipe: /var/pkg/toolchain/glibc/build.sh (modo nativo)
#
# Requisitos:
#   - Linux API headers instalados em /usr/include no ambiente de build
#   - Toolchain funcional (gcc/ld/as nativos ou temporários no chroot)
#

pkg_name=glibc
pkg_version=2.42
pkg_category=toolchain
pkg_description="GNU C Library - native"
pkg_depends="toolchain:linux-headers"

pkg_url="https://ftp.gnu.org/gnu/glibc/glibc-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "glibc-${pkg_version}" || return 1

    mkdir -p build
    cd build || return 1

    # Build nativo: host=build (autodetect). Mantemos builddir separado.
    ../configure \
        --prefix=/usr \
        --disable-werror \
        --enable-kernel=3.2 \
        libc_cv_slibdir=/usr/lib || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
