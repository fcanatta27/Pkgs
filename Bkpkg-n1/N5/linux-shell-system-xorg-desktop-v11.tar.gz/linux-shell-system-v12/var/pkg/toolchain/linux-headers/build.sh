#!/bin/sh
#
# Recipe: /var/pkg/toolchain/linux-headers/build.sh
# Instala Linux API Headers a partir do tarball do kernel.
#
# Referência: kernel.org tarballs (v6.x)
#

pkg_name=linux-headers
pkg_version=6.18.2
pkg_category=toolchain
pkg_description="Linux kernel API headers for userspace (used by glibc)"
pkg_depends=""

pkg_url="https://www.kernel.org/pub/linux/kernel/v6.x/linux-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "linux-${pkg_version}" || return 1

    make mrproper || return 1
    make headers_install INSTALL_HDR_PATH="$PKGROOT/usr" || return 1

    # Remove arquivos desnecessários (best-effort)
    find "$PKGROOT/usr/include" \( -name '.install' -o -name '..install.cmd' \) -delete 2>/dev/null || true

    return 0
}
