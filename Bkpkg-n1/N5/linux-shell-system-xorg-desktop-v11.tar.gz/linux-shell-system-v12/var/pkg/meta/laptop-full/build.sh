#!/bin/sh
pkg_name=laptop-full
pkg_version=1
pkg_category=meta
pkg_description="Meta-pacote: recursos extras para notebook (energia, bluetooth, sensores)"
pkg_depends="meta:desktop-full base:tlp base:upower base:lm-sensors base:brightnessctl daemon:acpid net:blueman net:bluez"
pkg_url=""
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    mkdir -p "$PKGROOT/usr/share/pkg-meta" || return 1
    cat >"$PKGROOT/usr/share/pkg-meta/${pkg_name}.meta" <<EOF
Pacote meta: ${pkg_name}-${pkg_version}
Dependências declaradas: meta:desktop-full base:tlp base:upower base:lm-sensors base:brightnessctl daemon:acpid net:blueman net:bluez
EOF
    return 0
}


