#!/bin/sh
pkg_name=desktop-core
pkg_version=1
pkg_category=meta
pkg_description="Meta-pacote: desktop core (Xorg, Openbox, terminais, fontes básicas)"
pkg_depends="xorg:xorg-server xorg:mesa xorg:libdrm xorg:libinput xorg:libX11 xorg:libXft xorg:xf86-video-modesetting xorg:xinit xorg:xterm xorg:openbox xorg:rxvt-unicode xorg:xdm"
pkg_url=""
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    mkdir -p "$PKGROOT/usr/share/pkg-meta" || return 1
    cat >"$PKGROOT/usr/share/pkg-meta/${pkg_name}.meta" <<EOF
Pacote meta: ${pkg_name}-${pkg_version}
Dependências declaradas: xorg:xorg-server xorg:mesa xorg:libdrm xorg:libinput xorg:libX11 xorg:libXft xorg:xf86-video-modesetting xorg:xinit xorg:xterm xorg:openbox xorg:rxvt-unicode xorg:xdm
EOF
    return 0
}


