#!/bin/sh
pkg_name=desktop-full
pkg_version=1
pkg_category=meta
pkg_description="Meta-pacote: desktop completo (desktop-core + browsers + multimídia)"
pkg_depends="meta:desktop-core base:firefox-bin base:chromium-bin base:ffmpeg audio:pipewire audio:wireplumber base:udisks2 base:polkit base:lxqt-policykit base:vim"
pkg_url=""
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    mkdir -p "$PKGROOT/usr/share/pkg-meta" || return 1
    cat >"$PKGROOT/usr/share/pkg-meta/${pkg_name}.meta" <<EOF
Pacote meta: ${pkg_name}-${pkg_version}
Dependências declaradas: meta:desktop-core base:firefox-bin base:chromium-bin base:ffmpeg audio:pipewire audio:wireplumber base:udisks2 base:polkit base:lxqt-policykit base:vim
EOF
    return 0
}


