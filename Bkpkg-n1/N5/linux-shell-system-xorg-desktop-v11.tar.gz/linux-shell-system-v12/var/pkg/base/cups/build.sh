#!/bin/sh
pkg_name=cups
pkg_version=2.4.10
pkg_category=base
pkg_description="CUPS - sistema de impressão"
pkg_depends="toolchain:glibc base:openssl base:zlib base:libjpeg base:libpng base:dbus"
pkg_url="https://github.com/OpenPrinting/cups/releases/download/v${pkg_version}/cups-${pkg_version}-source.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd cups-${pkg_version} || return 1
    ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --disable-systemd || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 0
}
