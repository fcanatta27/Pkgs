#!/bin/sh
pkg_name=lua
pkg_version=5.4.7
pkg_category=base
pkg_description="Lua - linguagem de script leve"
pkg_depends="toolchain:glibc"
pkg_url="https://www.lua.org/ftp/lua-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd lua-${pkg_version} || return 1
    make linux || return 1
    make INSTALL_TOP=/usr DESTDIR="$PKGROOT" install || return 1
}
