#!/bin/sh
#
# Recipe: /var/pkg/base/gzip/build.sh
#

pkg_name=gzip
pkg_version=1.14
pkg_category=base
pkg_description="gzip - utilitário de compressão"
pkg_depends="toolchain:glibc"

pkg_url="https://ftp.gnu.org/gnu/gzip/gzip-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "gzip-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
