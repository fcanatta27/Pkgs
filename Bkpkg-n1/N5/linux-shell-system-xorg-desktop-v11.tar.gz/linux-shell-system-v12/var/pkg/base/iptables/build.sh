#!/bin/sh
pkg_name=iptables
pkg_version=1.8.11
pkg_category=base
pkg_description="iptables - ferramentas de firewall para o kernel Linux"
pkg_depends="toolchain:glibc base:libmnl base:libnftnl"
pkg_url="https://www.netfilter.org/projects/iptables/files/iptables-${pkg_version}.tar.bz2"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd iptables-${pkg_version} || return 1
    ./configure --prefix=/usr --sbindir=/usr/sbin --disable-nftables || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
