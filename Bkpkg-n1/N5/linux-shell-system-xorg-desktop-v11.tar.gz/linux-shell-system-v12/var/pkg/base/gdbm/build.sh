#!/bin/sh
pkg_name=gdbm
pkg_version=1.26
pkg_category=base
pkg_description="gdbm - GNU database manager"
pkg_depends="toolchain:glibc"
pkg_url="https://ftp.gnu.org/gnu/gdbm/gdbm-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "gdbm-${pkg_version}" || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
