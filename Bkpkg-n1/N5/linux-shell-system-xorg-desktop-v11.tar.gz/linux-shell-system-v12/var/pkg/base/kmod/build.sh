#!/bin/sh
#
# Recipe: /var/pkg/base/kmod/build.sh (Stage2, nativo)
#

pkg_name=kmod
pkg_version=32
pkg_category=base
pkg_description="Ferramentas de módulos de kernel (kmod, modprobe, lsmod, etc.)"
pkg_depends=""

pkg_url="https://www.kernel.org/pub/linux/utils/kernel/kmod/kmod-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "kmod-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --with-xz \
        --with-zstd \
        --with-zlib || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    # Links de compatibilidade em /sbin (se quiser seguir padrões antigos)
    mkdir -p "$PKGROOT/sbin"
    for b in depmod insmod lsmod modinfo modprobe rmmod; do
        if [ -x "$PKGROOT/usr/bin/kmod" ] && [ ! -e "$PKGROOT/sbin/$b" ]; then
            ln -sf ../usr/bin/kmod "$PKGROOT/sbin/$b"
        fi
    done

    return 0
}
