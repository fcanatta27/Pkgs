#!/bin/sh
pkg_name=x265
pkg_version=3.6
pkg_category=base
pkg_description="x265 - codec H.265/HEVC"
pkg_depends="toolchain:glibc"
pkg_url="https://bitbucket.org/multicoreware/x265_git/get/${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd multicoreware-* || return 1
    cd source || return 1
    cmake -S . -B build -DCMAKE_INSTALL_PREFIX=/usr || return 1
    cmake --build build || return 1
    DESTDIR="$PKGROOT" cmake --install build || return 1
}
