#!/bin/sh
pkg_name=nss
pkg_version=3.108
pkg_category=base
pkg_description="NSS - Network Security Services"
pkg_depends="toolchain:glibc base:nspr base:sqlite base:zlib"
pkg_url="https://ftp.mozilla.org/pub/security/nss/releases/NSS_${pkg_version//./_}_RTM/src/nss-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd nss-${pkg_version} || return 1
    make BUILD_OPT=1 NSPR_INCLUDE_DIR=/usr/include/nspr NSPR_LIB_DIR=/usr/lib || return 1
    mkdir -p "$PKGROOT/usr/lib" "$PKGROOT/usr/include/nss"
    cp -av dist/*.so "$PKGROOT/usr/lib/" 2>/dev/null || true
}
