#!/bin/sh
pkg_name=rust
pkg_version=1.83.0
pkg_category=base
pkg_description="Rust - linguagem de programação e toolchain"
pkg_depends="toolchain:glibc base:python3"
pkg_url="https://static.rust-lang.org/dist/rust-${pkg_version}-x86_64-unknown-linux-gnu.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd rust-${pkg_version}-x86_64-unknown-linux-gnu || return 1
    ./install.sh --prefix=/usr --destdir="$PKGROOT" || return 1
}
