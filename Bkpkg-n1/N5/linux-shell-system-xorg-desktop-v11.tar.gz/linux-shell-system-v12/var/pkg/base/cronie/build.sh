#!/bin/sh
#
# Recipe: /var/pkg/base/cronie/build.sh
#

pkg_name=cronie
pkg_version=1.6.1
pkg_category=base
pkg_description="cronie - daemon cron compatível com Vixie cron"
pkg_depends="base:crontabs toolchain:glibc"

pkg_url="https://github.com/cronie-crond/cronie/releases/download/cronie-${pkg_version}/cronie-${pkg_version}.tar.gz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "cronie-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --localstatedir=/var \
        --with-pam=no || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
