#!/bin/sh
#
# Recipe: /var/pkg/base/openssl/build.sh
#

pkg_name=openssl
pkg_version=3.6.0
pkg_category=base
pkg_description="OpenSSL - biblioteca e ferramentas de criptografia"
pkg_depends="toolchain:glibc base:zlib"

pkg_url="https://www.openssl.org/source/openssl-${pkg_version}.tar.gz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "openssl-${pkg_version}" || return 1

    ./Configure \
        linux-x86_64 \
        --prefix=/usr \
        --openssldir=/etc/ssl \
        shared \
        zlib || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install_sw || return 1

    return 0
}
