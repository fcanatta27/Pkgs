#!/bin/sh
pkg_name=perl
pkg_version=5.42.0
pkg_category=base
pkg_description="Perl - linguagem de script"
pkg_depends="toolchain:glibc"
pkg_url="https://www.cpan.org/src/5.0/perl-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd perl-${pkg_version} || return 1
    sh Configure -des -Dprefix=/usr || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
