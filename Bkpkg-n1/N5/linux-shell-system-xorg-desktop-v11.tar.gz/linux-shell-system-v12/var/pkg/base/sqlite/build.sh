#!/bin/sh
pkg_name=sqlite
pkg_version=3510200
pkg_category=base
pkg_description="sqlite - banco de dados SQL embutido"
pkg_depends="toolchain:glibc base:readline base:ncurses"
pkg_url="https://www.sqlite.org/2025/sqlite-autoconf-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    # diretório normalmente sqlite-autoconf-${pkg_version}
    cd "sqlite-autoconf-${pkg_version}" || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
