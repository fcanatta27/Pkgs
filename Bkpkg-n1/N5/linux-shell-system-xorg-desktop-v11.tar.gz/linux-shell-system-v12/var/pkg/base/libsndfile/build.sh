#!/bin/sh
pkg_name=libsndfile
pkg_version=1.2.2
pkg_category=base
pkg_description="libsndfile - biblioteca para arquivos de áudio"
pkg_depends="toolchain:glibc"
pkg_url="https://github.com/libsndfile/libsndfile/releases/download/${pkg_version}/libsndfile-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libsndfile-${pkg_version}" || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
