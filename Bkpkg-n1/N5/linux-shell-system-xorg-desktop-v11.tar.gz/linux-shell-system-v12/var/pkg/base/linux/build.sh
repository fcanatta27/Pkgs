#!/bin/sh
#
# Recipe: /var/pkg/base/linux/build.sh
# Kernel Linux 6.18.2 (nativo)
#

pkg_name=linux
pkg_version=6.18.2
pkg_category=base
pkg_description="Linux kernel 6.18.2 e módulos"
pkg_depends="toolchain:gcc toolchain:binutils toolchain:linux-headers base:kmod base:e2fsprogs"

pkg_url="https://www.kernel.org/pub/linux/kernel/v6.x/linux-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "linux-${pkg_version}" || return 1

    make mrproper || return 1
    make defconfig || return 1

    make -j"$(nproc 2>/dev/null || echo 4)" || return 1

    make modules_install INSTALL_MOD_PATH="$PKGROOT" || return 1

    mkdir -p "$PKGROOT/boot"
    cp -v arch/x86/boot/bzImage "$PKGROOT/boot/vmlinuz-${pkg_version}" || return 1
    cp -v System.map "$PKGROOT/boot/System.map-${pkg_version}" || true
    cp -v .config "$PKGROOT/boot/config-${pkg_version}" || true

    return 0
}
