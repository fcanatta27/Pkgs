#!/bin/sh
pkg_name=bash-completion
pkg_version=2.14.0
pkg_category=base
pkg_description="bash-completion - complementos de auto-completar para bash"
pkg_depends="toolchain:glibc base:bash"
pkg_url="https://github.com/scop/bash-completion/releases/download/${pkg_version}/bash-completion-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "bash-completion-${pkg_version}" || return 1
    ./configure --prefix=/usr --sysconfdir=/etc --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
