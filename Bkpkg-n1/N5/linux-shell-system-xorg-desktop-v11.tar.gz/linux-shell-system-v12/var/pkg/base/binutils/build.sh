#!/bin/sh
pkg_name=binutils
pkg_version=2.45.1
pkg_category=base
pkg_description="binutils - montador e linker do GNU"
pkg_depends="toolchain:glibc"
pkg_url="https://ftp.gnu.org/gnu/binutils/binutils-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    mkdir -p build-binutils
    cd build-binutils || return 1
    ../binutils-${pkg_version}/configure --prefix=/usr --enable-gold --enable-ld=default --enable-plugins --enable-shared --disable-werror || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
