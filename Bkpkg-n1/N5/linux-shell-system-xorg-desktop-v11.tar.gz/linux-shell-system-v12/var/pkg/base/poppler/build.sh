#!/bin/sh
pkg_name=poppler
pkg_version=24.10.0
pkg_category=base
pkg_description="poppler - biblioteca de renderização de PDF"
pkg_depends="toolchain:glibc base:glib base:cairo base:fontconfig base:freetype base:libjpeg base:libpng"
pkg_url="https://poppler.freedesktop.org/poppler-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd poppler-${pkg_version} || return 1
    cmake -S . -B build -DCMAKE_INSTALL_PREFIX=/usr -DENABLE_XPDF_HEADERS=ON || return 1
    cmake --build build || return 1
    DESTDIR="$PKGROOT" cmake --install build || return 1
}
