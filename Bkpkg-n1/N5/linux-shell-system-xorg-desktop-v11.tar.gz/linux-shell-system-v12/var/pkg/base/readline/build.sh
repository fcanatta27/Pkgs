#!/bin/sh
pkg_name=readline
pkg_version=8.3
pkg_category=base
pkg_description="readline - biblioteca de edição de linha para shells"
pkg_depends="toolchain:glibc base:ncurses"
pkg_url="https://ftp.gnu.org/gnu/readline/readline-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "readline-${pkg_version}" || return 1
    ./configure --prefix=/usr --disable-static --with-curses || return 1
    make SHLIB_LIBS="-lncursesw" || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
