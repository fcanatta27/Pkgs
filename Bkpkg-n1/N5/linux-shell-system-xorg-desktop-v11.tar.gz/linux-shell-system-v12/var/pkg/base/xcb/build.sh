#!/bin/sh
pkg_name=xcb
pkg_version=1.16
pkg_category=base
pkg_description="xcb - metapacote simples para bibliotecas base do XCB"
pkg_depends="xorg:libxcb"
pkg_url=""
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    mkdir -p "$PKGROOT/usr/share/pkg-meta" || return 1
    cat >"$PKGROOT/usr/share/pkg-meta/${pkg_name}.meta" <<EOF
Pacote meta: ${pkg_name}-${pkg_version}
Dependências declaradas: xorg:libxcb
EOF
    return 0
}

