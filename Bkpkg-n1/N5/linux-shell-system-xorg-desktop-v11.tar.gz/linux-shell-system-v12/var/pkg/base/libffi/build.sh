#!/bin/sh
pkg_name=libffi
pkg_version=3.4.6
pkg_category=base
pkg_description="libffi - foreign function interface"
pkg_depends="toolchain:glibc"
pkg_url="https://github.com/libffi/libffi/releases/download/v${pkg_version}/libffi-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libffi-${pkg_version}" || return 1
    ./configure --prefix=/usr --disable-static --with-gcc-arch=native || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
