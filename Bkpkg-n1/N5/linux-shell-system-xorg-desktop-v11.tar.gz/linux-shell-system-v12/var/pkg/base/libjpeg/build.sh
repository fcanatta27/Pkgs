#!/bin/sh
pkg_name=libjpeg
pkg_version=3.0.3
pkg_category=base
pkg_description="libjpeg-turbo - biblioteca de compressão JPEG"
pkg_depends="toolchain:glibc"
pkg_url="https://downloads.sourceforge.net/libjpeg-turbo/libjpeg-turbo-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libjpeg-turbo-${pkg_version}" || return 1
    cmake -S . -B build -DCMAKE_INSTALL_PREFIX=/usr -DENABLE_STATIC=FALSE || return 1
    cmake --build build || return 1
    DESTDIR="$PKGROOT" cmake --install build || return 1
    return 0
}
