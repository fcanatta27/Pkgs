#!/bin/sh
#
# Recipe: /var/pkg/base/e2fsprogs/build.sh (Stage2, nativo)
#

pkg_name=e2fsprogs
pkg_version=1.47.0
pkg_category=base
pkg_description="Ferramentas para sistemas de arquivos ext2/3/4"
pkg_depends=""

pkg_url="https://www.kernel.org/pub/linux/kernel/people/tytso/e2fsprogs/v${pkg_version}/e2fsprogs-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "e2fsprogs-${pkg_version}" || return 1

    mkdir -p build
    cd build || return 1

    ../configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --enable-elf-shlibs || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    # Instalar o e2fsck estático em /sbin, se presente
    if [ -x "$PKGROOT/usr/sbin/e2fsck" ] && [ ! -e "$PKGROOT/sbin/e2fsck" ]; then
        mkdir -p "$PKGROOT/sbin"
        ln -sf ../usr/sbin/e2fsck "$PKGROOT/sbin/e2fsck"
    fi

    return 0
}
