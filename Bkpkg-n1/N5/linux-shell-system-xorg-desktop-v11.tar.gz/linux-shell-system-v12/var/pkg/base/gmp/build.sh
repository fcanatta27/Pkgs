#!/bin/sh
pkg_name=gmp
pkg_version=6.3.0
pkg_category=base
pkg_description="GMP - biblioteca de precisão arbitrária"
pkg_depends="toolchain:glibc"
pkg_url="https://ftp.gnu.org/gnu/gmp/gmp-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd gmp-${pkg_version} || return 1
    ./configure --prefix=/usr --enable-cxx --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
