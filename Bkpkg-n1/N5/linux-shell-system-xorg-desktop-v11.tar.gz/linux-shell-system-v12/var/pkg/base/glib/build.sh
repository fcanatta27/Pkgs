#!/bin/sh
#
# glib - utilitários de baixo nível para GNOME e geral
#

pkg_name=glib
pkg_version=2.80.2
pkg_category=base
pkg_description="glib - utilitários de baixo nível (tipos, loops, etc.)"
pkg_depends="toolchain:glibc base:libffi base:pcre2"

pkg_url="https://download.gnome.org/sources/glib/${pkg_version%.*}/glib-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "glib-${pkg_version}" || return 1

    meson setup build \
        --prefix=/usr \
        --libdir=/usr/lib \
        --buildtype=release || return 1

    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1

    return 0
}
