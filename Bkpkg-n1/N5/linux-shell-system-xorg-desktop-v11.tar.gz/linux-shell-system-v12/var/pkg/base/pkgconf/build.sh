#!/bin/sh
pkg_name=pkgconf
pkg_version=2.3.0
pkg_category=base
pkg_description="pkgconf - implementação de pkg-config"
pkg_depends="toolchain:glibc"
pkg_url="https://distfiles.dereferenced.org/pkgconf/pkgconf-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd pkgconf-${pkg_version} || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
