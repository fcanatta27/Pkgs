#!/bin/sh
#
# Recipe: /var/pkg/base/xz/build.sh
#

pkg_name=xz
pkg_version=5.8.2
pkg_category=base
pkg_description="XZ Utils - compressão LZMA/XZ"
pkg_depends="toolchain:glibc"

pkg_url="https://tukaani.org/xz/xz-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "xz-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
