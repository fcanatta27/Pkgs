#!/bin/sh
pkg_name=gdb
pkg_version=15.2
pkg_category=base
pkg_description="GDB - depurador GNU"
pkg_depends="toolchain:glibc base:readline base:ncurses base:python3"
pkg_url="https://ftp.gnu.org/gnu/gdb/gdb-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd gdb-${pkg_version} || return 1
    ./configure --prefix=/usr --with-python=/usr/bin/python3 || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
