#!/bin/sh
#
# Recipe: /var/pkg/base/iproute2/build.sh (Stage2, nativo)
#

pkg_name=iproute2
pkg_version=6.7.0
pkg_category=base
pkg_description="Ferramentas de rede iproute2 (ip, ss, tc, etc.)"
pkg_depends=""

pkg_url="https://www.kernel.org/pub/linux/utils/net/iproute2/iproute2-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "iproute2-${pkg_version}" || return 1

    # Ajusta paths de instalação
    sed -i 's#^PREFIX = /usr/local#PREFIX = /usr#' Makefile || true
    sed -i 's#^SBINDIR = /sbin#SBINDIR = /usr/sbin#' Makefile || true

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
