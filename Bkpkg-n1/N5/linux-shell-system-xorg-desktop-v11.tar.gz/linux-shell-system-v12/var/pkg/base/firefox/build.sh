#!/bin/sh
pkg_name=firefox
pkg_version=147.0.1
pkg_category=base
pkg_description="Firefox - navegador web construído a partir do código-fonte"
pkg_depends="toolchain:glibc base:python3 devel:clang devel:llvm base:rust base:gtk3 base:dbus base:alsa-lib base:libvpx base:libopus base:nss base:nspr base:fontconfig base:freetype base:zlib base:libpng base:libjpeg"
pkg_url="https://archive.mozilla.org/pub/firefox/releases/${pkg_version}/source/firefox-${pkg_version}.source.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd firefox-* || return 1

    if ! command -v python3 >/dev/null 2>&1; then
        echo "Erro: python3 não encontrado no PATH"
        return 1
    fi
    if ! command -v rustc >/dev/null 2>&1; then
        echo "Erro: rustc não encontrado no PATH"
        return 1
    fi
    if ! command -v clang >/dev/null 2>&1; then
        echo "Erro: clang não encontrado no PATH"
        return 1
    fi

    # Arquivo de configuração MOZCONFIG básico para build otimizado
    cat > .mozconfig << 'EOF'
ac_add_options --prefix=/usr
ac_add_options --enable-application=browser
ac_add_options --enable-release
ac_add_options --enable-optimize
ac_add_options --disable-debug
ac_add_options --disable-tests
ac_add_options --enable-jack
mk_add_options MOZ_OBJDIR=@TOPSRCDIR@/obj-browser
EOF

    ./mach configure || return 1
    ./mach build || return 1

    mkdir -p "$PKGROOT/opt/firefox" "$PKGROOT/usr/bin" || return 1
    objdir=$(find . -maxdepth 1 -type d -name 'obj-*' | head -n1)
    if [ -n "$objdir" ]; then
        cp -a "$objdir"/dist/* "$PKGROOT/opt/firefox/" || return 1
    elif [ -d "dist" ]; then
        cp -a dist/* "$PKGROOT/opt/firefox/" || return 1
    fi
    ln -sf /opt/firefox/firefox "$PKGROOT/usr/bin/firefox" || return 1
}
