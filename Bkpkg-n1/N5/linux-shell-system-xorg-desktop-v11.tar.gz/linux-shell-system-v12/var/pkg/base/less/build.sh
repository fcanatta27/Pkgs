#!/bin/sh
pkg_name=less
pkg_version=685
pkg_category=base
pkg_description="less - pager para leitura de texto"
pkg_depends="toolchain:glibc base:ncurses"
pkg_url="https://www.greenwoodsoftware.com/less/less-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "less-${pkg_version}" || return 1
    ./configure --prefix=/usr || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
