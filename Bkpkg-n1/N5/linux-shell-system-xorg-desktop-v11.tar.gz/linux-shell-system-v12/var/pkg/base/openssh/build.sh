#!/bin/sh
#
# Recipe: /var/pkg/base/openssh/build.sh
#

pkg_name=openssh
pkg_version=10.2p1
pkg_category=base
pkg_description="OpenSSH - cliente e servidor SSH"
pkg_depends="toolchain:glibc base:openssl base:zlib"

pkg_url="https://ftp.openbsd.org/pub/OpenBSD/OpenSSH/portable/openssh-${pkg_version}.tar.gz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "openssh-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc/ssh \
        --with-privsep-path=/var/empty \
        --with-md5-passwords || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
