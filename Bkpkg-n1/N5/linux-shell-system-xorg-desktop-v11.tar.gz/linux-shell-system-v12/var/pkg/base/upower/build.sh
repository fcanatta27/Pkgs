#!/bin/sh
pkg_name=upower
pkg_version=1.90.4
pkg_category=base
pkg_description="upower - daemon de gerenciamento de energia e bateria"
pkg_depends="toolchain:glibc base:glib base:dbus base:eudev"
pkg_url="https://gitlab.freedesktop.org/upower/upower/-/archive/${pkg_version}/upower-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd upower-${pkg_version}* || return 1
    meson setup build --prefix=/usr --libdir=/usr/lib --buildtype=release || return 1
    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1
}
