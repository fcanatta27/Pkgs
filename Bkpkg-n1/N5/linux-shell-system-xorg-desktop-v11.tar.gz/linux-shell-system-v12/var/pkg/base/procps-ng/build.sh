#!/bin/sh
#
# Recipe: /var/pkg/base/procps-ng/build.sh (Stage2, nativo)
#

pkg_name=procps-ng
pkg_version=4.0.4
pkg_category=base
pkg_description="Ferramentas de monitoramento de processos (ps, top, free, etc.)"
pkg_depends=""

pkg_url="https://sourceforge.net/projects/procps-ng/files/Production/procps-ng-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "procps-ng-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --exec-prefix=/usr \
        --libdir=/usr/lib \
        --docdir=/usr/share/doc/procps-ng-${pkg_version} \
        --disable-nls || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
