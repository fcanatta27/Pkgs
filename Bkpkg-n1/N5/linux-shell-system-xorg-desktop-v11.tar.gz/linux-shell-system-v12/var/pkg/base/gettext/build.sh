#!/bin/sh
pkg_name=gettext
pkg_version=0.22.5
pkg_category=base
pkg_description="gettext - internacionalização de programas (i18n)"
pkg_depends="toolchain:glibc"
pkg_url="https://ftp.gnu.org/pub/gnu/gettext/gettext-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "gettext-${pkg_version}" || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
