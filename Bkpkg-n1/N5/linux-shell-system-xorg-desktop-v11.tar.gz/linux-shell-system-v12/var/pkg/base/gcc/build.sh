#!/bin/sh
pkg_name=gcc
pkg_version=15.2.0
pkg_category=base
pkg_description="GCC - compilador GNU"
pkg_depends="toolchain:glibc base:binutils base:gmp base:mpfr base:mpc"
pkg_url="https://ftp.gnu.org/gnu/gcc/gcc-${pkg_version}/gcc-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    mkdir -p build-gcc
    cd build-gcc || return 1
    ../gcc-${pkg_version}/configure --prefix=/usr --enable-languages=c,c++ --disable-multilib || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
