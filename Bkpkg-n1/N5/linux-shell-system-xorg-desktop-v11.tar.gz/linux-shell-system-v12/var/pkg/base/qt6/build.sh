#!/bin/sh
pkg_name=qt6
pkg_version=6.7.3
pkg_category=base
pkg_description="Qt 6 - toolkit gráfico"
pkg_depends="toolchain:glibc base:openssl base:zlib base:dbus base:glib base:fontconfig base:freetype base:libjpeg base:libpng base:xcb"
pkg_url="https://download.qt.io/official_releases/qt/6.7/6.7.3/single/qt-everywhere-src-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd qt-everywhere-src-${pkg_version} || return 1

    mkdir -p build
    cd build || return 1

    ../configure \
        -prefix /usr \
        -release \
        -opensource \
        -confirm-license \
        -nomake examples \
        -nomake tests || return 1

    cmake --build . || return 1
    DESTDIR="$PKGROOT" cmake --install . || return 1
}
