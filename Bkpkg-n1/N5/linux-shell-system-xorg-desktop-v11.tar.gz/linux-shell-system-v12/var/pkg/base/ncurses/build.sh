#!/bin/sh
pkg_name=ncurses
pkg_version=6.5
pkg_category=base
pkg_description="ncurses - biblioteca de controle de terminal e TUIs"
pkg_depends="toolchain:glibc"
pkg_url="https://ftp.gnu.org/pub/gnu/ncurses/ncurses-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "ncurses-${pkg_version}" || return 1
    ./configure --prefix=/usr --mandir=/usr/share/man --with-shared --without-debug --without-normal --enable-widec || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    ( cd "$PKGROOT/usr/lib" 2>/dev/null &&       for lib in ncurses form panel menu; do         if [ -f "lib${lib}w.so" ]; then ln -sf "lib${lib}w.so" "lib${lib}.so"; fi;       done )
    return 0
}
