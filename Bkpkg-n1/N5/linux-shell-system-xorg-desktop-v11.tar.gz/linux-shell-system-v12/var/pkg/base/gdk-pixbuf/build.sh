#!/bin/sh
pkg_name=gdk-pixbuf
pkg_version=2.42.12
pkg_category=base
pkg_description="gdk-pixbuf - carregamento e manipulação de imagens para GTK"
pkg_depends="toolchain:glibc base:glib base:libjpeg base:libpng base:tiff"
pkg_url="https://download.gnome.org/sources/gdk-pixbuf/${pkg_version%.*}/gdk-pixbuf-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "gdk-pixbuf-${pkg_version}" || return 1
    meson setup build --prefix=/usr --libdir=/usr/lib --buildtype=release -D installed_tests=false -D gtk_doc=false || return 1
    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1
    return 0
}
