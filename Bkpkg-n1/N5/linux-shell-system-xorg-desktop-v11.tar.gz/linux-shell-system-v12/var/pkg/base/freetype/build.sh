#!/bin/sh
#
# freetype - engine de fontes
#

pkg_name=freetype
pkg_version=2.13.3
pkg_category=base
pkg_description="freetype - engine de renderização de fontes"
pkg_depends="toolchain:glibc base:expat"

pkg_url="https://download.savannah.gnu.org/releases/freetype/freetype-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "freetype-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --disable-static \
        --enable-freetype-config || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
