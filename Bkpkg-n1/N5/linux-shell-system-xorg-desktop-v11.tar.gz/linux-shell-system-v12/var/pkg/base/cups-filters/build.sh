#!/bin/sh
pkg_name=cups-filters
pkg_version=2.0.0
pkg_category=base
pkg_description="cups-filters - filtros extras para CUPS"
pkg_depends="toolchain:glibc base:cups base:poppler base:ghostscript"
pkg_url="https://github.com/OpenPrinting/cups-filters/releases/download/${pkg_version}/cups-filters-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd cups-filters-${pkg_version} || return 1
    ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 0
}
