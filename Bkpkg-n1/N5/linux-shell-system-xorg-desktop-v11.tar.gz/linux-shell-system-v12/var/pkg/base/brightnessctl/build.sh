#!/bin/sh
pkg_name=brightnessctl
pkg_version=0.5.1
pkg_category=base
pkg_description="brightnessctl - controle de brilho de backlight"
pkg_depends="toolchain:glibc base:eudev"
pkg_url="https://github.com/Hummer12007/brightnessctl/archive/refs/tags/v${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "brightnessctl-${pkg_version}" || return 1
    make || return 1
    make DESTDIR="$PKGROOT" PREFIX=/usr install || return 1
    return 0
}
