#!/bin/sh
pkg_name=libopus
pkg_version=1.5.2
pkg_category=base
pkg_description="Opus - codec de áudio"
pkg_depends="toolchain:glibc"
pkg_url="https://archive.mozilla.org/pub/opus/opus-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd opus-${pkg_version} || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
