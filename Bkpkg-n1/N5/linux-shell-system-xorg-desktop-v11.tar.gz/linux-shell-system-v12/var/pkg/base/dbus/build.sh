#!/bin/sh
pkg_name=dbus
pkg_version=1.14.10
pkg_category=base
pkg_description="D-Bus - barramento de mensagens para desktop"
pkg_depends="toolchain:glibc"
pkg_url="https://dbus.freedesktop.org/releases/dbus/dbus-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd dbus-${pkg_version} || return 1
    ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --disable-static --disable-systemd --enable-user-session || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
