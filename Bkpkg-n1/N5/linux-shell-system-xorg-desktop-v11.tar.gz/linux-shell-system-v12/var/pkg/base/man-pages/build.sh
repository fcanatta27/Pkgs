#!/bin/sh
pkg_name=man-pages
pkg_version=6.16
pkg_category=base
pkg_description="man-pages - páginas de manual para funções e ferramentas"
pkg_depends="toolchain:glibc"
pkg_url="https://www.kernel.org/pub/linux/docs/man-pages/man-pages-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "man-pages-${pkg_version}" || return 1
    make DESTDIR="$PKGROOT" prefix=/usr install || return 1
    return 0
}
