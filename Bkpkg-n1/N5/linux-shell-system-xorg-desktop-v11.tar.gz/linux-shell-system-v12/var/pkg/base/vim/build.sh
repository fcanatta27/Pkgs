#!/bin/sh
pkg_name=vim
pkg_version=9.1.2031
pkg_category=base
pkg_description="Vim - editor de texto avançado"
pkg_depends="toolchain:glibc base:ncurses base:python3 base:perl base:lua"
pkg_url="https://github.com/vim/vim/archive/refs/tags/v${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd vim-${pkg_version} || return 1
    ./configure --prefix=/usr --with-features=huge --enable-multibyte --enable-python3interp=yes --enable-perlinterp=yes --enable-luainterp=yes || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    # vimrc global
    mkdir -p "$PKGROOT/etc/vim"
    cat >"$PKGROOT/etc/vim/vimrc" <<'EOF'
" Vim global config - simples, funcional, com fzf se disponível

set nocompatible
set number
set relativenumber
set tabstop=4
set shiftwidth=4
set expandtab
set smartindent
set ruler
set cursorline
set termguicolors
syntax on

" Tema básico
set background=dark
colorscheme default

" Navegação em splits
nnoremap <Leader>h <C-w>h
nnoremap <Leader>j <C-w>j
nnoremap <Leader>k <C-w>k
nnoremap <Leader>l <C-w>l

" Abrir splits rapidamente
nnoremap <Leader>sv :vsplit<CR>
nnoremap <Leader>sh :split<CR>

" NERDTree-like com netrw
let g:netrw_liststyle = 3
nnoremap <Leader>e :Ex<CR>

" Integração opcional com fzf, se instalado
if executable('fzf') && executable('rg')
  nnoremap <Leader>f :grep<Space>
  nnoremap <Leader>p :!fzf<CR>
endif
EOF
}
