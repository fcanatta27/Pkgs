#!/bin/sh
pkg_name=inetutils
pkg_version=2.7
pkg_category=base
pkg_description="Inetutils - conjunto de utilitários de rede (telnet, ftp, etc.)"
pkg_depends="toolchain:glibc base:ncurses base:readline"
pkg_url="https://ftp.gnu.org/gnu/inetutils/inetutils-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "inetutils-${pkg_version}" || return 1
    ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --disable-logger --disable-whois --disable-rcp || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
