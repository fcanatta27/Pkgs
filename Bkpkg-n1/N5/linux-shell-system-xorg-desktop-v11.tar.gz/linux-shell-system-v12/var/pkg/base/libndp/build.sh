#!/bin/sh
pkg_name=libndp
pkg_version=1.9.8
pkg_category=base
pkg_description="libndp - biblioteca para Neighbor Discovery Protocol IPv6"
pkg_depends="toolchain:glibc"
pkg_url="https://github.com/jpirko/libndp/archive/v${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libndp-${pkg_version}" || return 1
    ./autogen.sh 2>/dev/null || true
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
