#!/bin/sh
pkg_name=pciutils
pkg_version=3.14.0
pkg_category=base
pkg_description="pciutils - utilitários para barramento PCI"
pkg_depends="toolchain:glibc base:zlib"
pkg_url="https://mj.ucw.cz/download/linux/pci/pciutils-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "pciutils-${pkg_version}" || return 1
    make PREFIX=/usr ZLIB=yes SHARED=yes || return 1
    make PREFIX=/usr DESTDIR="$PKGROOT" install install-lib || return 1
    return 0
}
