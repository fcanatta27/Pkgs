#!/bin/sh
pkg_name=pip
pkg_version=0
pkg_category=base
pkg_description="pip - gerenciador de pacotes Python (via python3 -m ensurepip)"
pkg_depends="base:python3"
pkg_url=""
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    mkdir -p "$PKGROOT/usr/share/pkg-meta" || return 1
    cat >"$PKGROOT/usr/share/pkg-meta/${pkg_name}.meta" <<EOF
Pacote meta: ${pkg_name}-${pkg_version}
Dependências declaradas: base:python3
EOF
    return 0
}


