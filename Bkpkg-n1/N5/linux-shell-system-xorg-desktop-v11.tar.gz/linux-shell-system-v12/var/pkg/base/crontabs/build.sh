#!/bin/sh
#
# Recipe: /var/pkg/base/crontabs/build.sh
#

pkg_name=crontabs
pkg_version=1
pkg_category=base
pkg_description="Arquivos de crontab de sistema e diretórios cron.*"
pkg_depends=""

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    mkdir -p "$PKGROOT/usr/share/pkg-meta" || return 1
    cat >"$PKGROOT/usr/share/pkg-meta/${pkg_name}.meta" <<EOF
Pacote meta: ${pkg_name}-${pkg_version}
Dependências declaradas: 
EOF
    return 0
}

