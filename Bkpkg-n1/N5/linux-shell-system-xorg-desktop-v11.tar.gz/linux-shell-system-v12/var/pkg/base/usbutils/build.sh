#!/bin/sh
pkg_name=usbutils
pkg_version=017
pkg_category=base
pkg_description="usbutils - ferramentas para dispositivos USB"
pkg_depends="toolchain:glibc base:libusb"
pkg_url="https://mirrors.edge.kernel.org/pub/linux/utils/usb/usbutils/usbutils-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd usbutils-${pkg_version} || return 1
    ./configure --prefix=/usr || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
