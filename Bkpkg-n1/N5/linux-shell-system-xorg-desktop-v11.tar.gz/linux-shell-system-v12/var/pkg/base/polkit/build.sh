#!/bin/sh
pkg_name=polkit
pkg_version=124
pkg_category=base
pkg_description="polkit - framework de autorização para desktop"
pkg_depends="toolchain:glibc base:glib base:expat base:dbus"
pkg_url="https://github.com/polkit-org/polkit/archive/refs/tags/${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd polkit-${pkg_version} || return 1
    meson setup build --prefix=/usr --buildtype=release --localstatedir=/var --sysconfdir=/etc || return 1
    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1
}
