#!/bin/sh
pkg_name=tiff
pkg_version=4.7.0
pkg_category=base
pkg_description="libtiff - biblioteca para imagens TIFF"
pkg_depends="toolchain:glibc base:zlib base:libjpeg"
pkg_url="https://download.osgeo.org/libtiff/tiff-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "tiff-${pkg_version}" || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
