#!/bin/sh
pkg_name=lm-sensors
pkg_version=3.6.0
pkg_category=base
pkg_description="lm-sensors - monitoração de sensores de hardware"
pkg_depends="toolchain:glibc base:pciutils"
pkg_url="https://github.com/lm-sensors/lm-sensors/archive/V${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "lm-sensors-${pkg_version}" || return 1
    make PREFIX=/usr || return 1
    make PREFIX=/usr DESTDIR="$PKGROOT" install || return 1
    return 0
}
