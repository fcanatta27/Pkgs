#!/bin/sh
pkg_name=make
pkg_version=4.4.1
pkg_category=base
pkg_description="make - utilitário de construção"
pkg_depends="toolchain:glibc"
pkg_url="https://ftp.gnu.org/gnu/make/make-${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd make-${pkg_version} || return 1
    ./configure --prefix=/usr || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
