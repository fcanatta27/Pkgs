#!/bin/sh
pkg_name=mpfr
pkg_version=4.2.1
pkg_category=base
pkg_description="MPFR - biblioteca de precisão arbitrária para floats"
pkg_depends="toolchain:glibc base:gmp"
pkg_url="https://ftp.gnu.org/gnu/mpfr/mpfr-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd mpfr-${pkg_version} || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
