#!/bin/sh
pkg_name=chromium-bin
pkg_version=144.0.7559.59
pkg_category=base
pkg_description="Chromium - navegador web (binário pré-compilado)"
pkg_depends="toolchain:glibc base:gtk3 base:dbus base:alsa-lib base:libvpx base:libopus base:fontconfig base:freetype"
# URL de exemplo para tarball binário. Ajuste conforme seu mirror.
pkg_url="https://commondatastorage.googleapis.com/chromium-browser-official/chromium-${pkg_version}-linux-x86_64.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1

    # O tarball normalmente contém um diretório chromium-*
    dir=$(find . -maxdepth 1 -type d -name 'chromium-*' | head -n1)
    if [ -z "$dir" ]; then
        echo "Diretório chromium-* não encontrado após extração"
        return 1
    fi

    mkdir -p "$PKGROOT/opt" "$PKGROOT/usr/bin" || return 1
    mv "$dir" "$PKGROOT/opt/chromium" || return 1
    ln -sf /opt/chromium/chrome "$PKGROOT/usr/bin/chromium" || return 1
}
