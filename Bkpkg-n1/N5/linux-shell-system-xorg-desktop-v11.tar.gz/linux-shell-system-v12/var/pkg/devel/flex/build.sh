#!/bin/sh
#
# Recipe: /var/pkg/devel/flex/build.sh
#

pkg_name=flex
pkg_version=2.6.4
pkg_category=devel
pkg_description="flex - gerador de analisadores léxicos"
pkg_depends="toolchain:glibc"

pkg_url="https://github.com/westes/flex/releases/download/v${pkg_version}/flex-${pkg_version}.tar.gz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "flex-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --docdir=/usr/share/doc/flex-${pkg_version} || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    mkdir -p "$PKGROOT/usr/bin"
    ln -sf flex "$PKGROOT/usr/bin/lex"

    return 0
}
