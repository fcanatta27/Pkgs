#!/bin/sh
pkg_name=llvm
pkg_version=21.1.8
pkg_category=devel
pkg_description="LLVM - infraestrutura de compilador (inclui clang)"
pkg_depends="toolchain:glibc base:zlib base:ncurses base:libffi"
pkg_url="https://github.com/llvm/llvm-project/releases/download/llvmorg-${pkg_version}/llvm-project-${pkg_version}.src.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "llvm-project-${pkg_version}.src" || return 1
    mkdir -p build
    cd build || return 1
    cmake -G "Unix Makefiles" \
        -DCMAKE_INSTALL_PREFIX=/usr \
        -DCMAKE_BUILD_TYPE=Release \
        -DLLVM_ENABLE_PROJECTS="clang" \
        ../llvm || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
