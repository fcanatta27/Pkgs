#!/bin/sh
pkg_name=blueman
pkg_version=2.4.2
pkg_category=net
pkg_description="blueman - gerenciador Bluetooth em GTK para BlueZ"
pkg_depends="toolchain:glibc base:python3 base:gtk3 net:bluez base:dbus"
pkg_url="https://github.com/blueman-project/blueman/archive/refs/tags/${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "blueman-${pkg_version}" || return 1
    ./configure --prefix=/usr || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
