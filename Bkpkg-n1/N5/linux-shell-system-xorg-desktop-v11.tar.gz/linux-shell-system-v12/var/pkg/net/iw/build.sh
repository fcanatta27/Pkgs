#!/bin/sh
pkg_name=iw
pkg_version=6.17
pkg_category=net
pkg_description="iw - ferramenta de configuração de wireless (nl80211)"
pkg_depends="toolchain:glibc base:libnl"
pkg_url="https://www.kernel.org/pub/software/network/iw/iw-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "iw-${pkg_version}" || return 1
    make || return 1
    mkdir -p "$PKGROOT/usr/bin"
    install -m 0755 iw "$PKGROOT/usr/bin/iw" || return 1
    return 0
}
