#!/bin/sh
pkg_name=alsa-tools
pkg_version=1.2.15
pkg_category=audio
pkg_description="ALSA tools - ferramentas específicas de hardware"
pkg_depends="audio:alsa-lib"
pkg_url="https://www.alsa-project.org/files/pub/tools/alsa-tools-${pkg_version}.tar.bz2"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "alsa-tools-${pkg_version}" || return 1
    make prefix=/usr || return 1
    make prefix=/usr DESTDIR="$PKGROOT" install || return 1
    return 0
}
