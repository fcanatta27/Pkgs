#!/bin/sh
pkg_name=pipewire
pkg_version=1.4.10
pkg_category=audio
pkg_description="PipeWire - servidor de mídia para áudio e vídeo"
pkg_depends="toolchain:glibc base:glib base:libsndfile base:dbus base:eudev audio:alsa-lib"
pkg_url="https://gitlab.freedesktop.org/pipewire/pipewire/-/releases/${pkg_version}/downloads/pipewire-${pkg_version}.tar.bz2"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "pipewire-${pkg_version}" || return 1
    meson setup build --prefix=/usr --libdir=/usr/lib --buildtype=release -D systemd=disabled -D session-managers=[] || return 1
    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1
    return 0
}
