#!/bin/sh
pkg_name=perl
pkg_version=5.42.0
pkg_category=lang
pkg_description="Perl 5 - linguagem de script"
pkg_depends="toolchain:glibc"
pkg_url="https://www.cpan.org/src/5.0/perl-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "perl-${pkg_version}" || return 1
    sh Configure -des -Dprefix=/usr || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
