#!/bin/sh
pkg_name=acpid
pkg_version=2.0.34
pkg_category=daemon
pkg_description="acpid - daemon de eventos ACPI (botão power, tampas, etc.)"
pkg_depends="toolchain:glibc"
pkg_url="https://downloads.sourceforge.net/acpid2/acpid-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "acpid-${pkg_version}" || return 1
    ./configure --prefix=/usr --sysconfdir=/etc --sbindir=/usr/sbin || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
    return 0
}
