#!/bin/sh
#
# xterm - Terminal emulator for X
#

pkg_name=xterm
pkg_version=390
pkg_category=xorg
pkg_description="xterm - X terminal emulator"
pkg_depends="toolchain:glibc xorg:libX11 xorg:libXaw xorg:libXt xorg:libXmu xorg:libXext xorg:libXft base:fontconfig base:freetype"

pkg_url="https://invisible-mirror.net/archives/xterm/xterm-${pkg_version}.tgz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "xterm-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --disable-static \
        --enable-wide-chars || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
