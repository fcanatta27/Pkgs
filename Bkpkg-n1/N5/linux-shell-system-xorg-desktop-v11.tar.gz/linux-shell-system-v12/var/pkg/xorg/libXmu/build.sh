#!/bin/sh
pkg_name=libXmu
pkg_version=1.1.4
pkg_category=xorg
pkg_description="libXmu - X miscellaneous utilities"
pkg_depends="xorg:libXext xorg:libX11"
pkg_url="https://www.x.org/releases/individual/lib/libXmu-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd libXmu-${pkg_version} || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
