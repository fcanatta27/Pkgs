#!/bin/sh
#
# xorgproto - X.Org protocol headers
#

pkg_name=xorgproto
pkg_version=2024.1
pkg_category=xorg
pkg_description="X.Org X11 protocol headers"
pkg_depends="toolchain:glibc"

pkg_url="https://www.x.org/archive/individual/proto/xorgproto-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "xorgproto-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
