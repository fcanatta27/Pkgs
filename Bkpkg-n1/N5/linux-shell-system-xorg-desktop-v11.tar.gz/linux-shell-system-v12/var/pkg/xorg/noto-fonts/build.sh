#!/bin/sh
pkg_name=noto-fonts
pkg_version=20231130
pkg_category=xorg
pkg_description="noto-fonts - coleção de fontes Noto"
pkg_depends="toolchain:glibc"
pkg_url="https://github.com/notofonts/noto-fonts/archive/refs/tags/v${pkg_version}.tar.gz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "noto-fonts-${pkg_version}" || return 1
    mkdir -p "$PKGROOT/usr/share/fonts/noto"
    find . -type f \( -name '*.ttf' -o -name '*.otf' \) -exec cp -v '{}' "$PKGROOT/usr/share/fonts/noto" \; || true
    return 0
}
