#!/bin/sh
pkg_name=xcb-proto
pkg_version=1.16.0
pkg_category=xorg
pkg_description="xcb-proto - descrições de protocolo XCB"
pkg_depends="toolchain:glibc"
pkg_url="https://www.x.org/releases/individual/xcb/xcb-proto-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd xcb-proto-${pkg_version} || return 1
    ./configure --prefix=/usr || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
