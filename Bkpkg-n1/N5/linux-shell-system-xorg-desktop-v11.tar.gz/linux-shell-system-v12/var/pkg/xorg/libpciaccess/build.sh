#!/bin/sh
pkg_name=libpciaccess
pkg_version=0.18
pkg_category=xorg
pkg_description="libpciaccess - acesso a configuração de dispositivos PCI"
pkg_depends="toolchain:glibc"
pkg_url="https://www.x.org/releases/individual/lib/libpciaccess-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd libpciaccess-${pkg_version} || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
