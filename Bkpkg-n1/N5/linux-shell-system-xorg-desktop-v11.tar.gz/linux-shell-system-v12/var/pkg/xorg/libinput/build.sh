#!/bin/sh
#
# Recipe: /var/pkg/xorg/libinput/build.sh
#
# libinput - biblioteca de input para Xorg/Wayland
#

pkg_name=libinput
pkg_version=1.10.4
pkg_category=xorg
pkg_description="libinput - biblioteca de entrada para servidores gráficos (mouse, teclado, touchpad)"
pkg_depends="toolchain:glibc base:eudev xorg:libevdev xorg:mtdev xorg:libwacom"

pkg_url="https://www.freedesktop.org/software/libinput/libinput-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libinput-${pkg_version}" || return 1

    meson setup build \
        --prefix=/usr \
        --libdir=/usr/lib \
        --buildtype=release \
        -D udev-dir=/lib/udev || return 1

    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1

    return 0
}
