#!/bin/sh
pkg_name=libXaw
pkg_version=1.0.16
pkg_category=xorg
pkg_description="libXaw - X Athena Widgets"
pkg_depends="xorg:libXmu xorg:libXt xorg:libX11"
pkg_url="https://www.x.org/releases/individual/lib/libXaw-${pkg_version}.tar.xz"
build() {
    : "${PKGROOT:?}"; : "${WORKDIR:?}"; : "${SRCFILE:?}"
    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd libXaw-${pkg_version} || return 1
    ./configure --prefix=/usr --disable-static || return 1
    make || return 1
    make DESTDIR="$PKGROOT" install || return 1
}
