#!/bin/sh
#
# terminus-font - fonte bitmap para console/X
#

pkg_name=terminus-font
pkg_version=4.49.1
pkg_category=xorg
pkg_description="terminus-font - fonte bitmap legível para console e X"
pkg_depends="toolchain:glibc"

pkg_url="https://sourceforge.net/projects/terminus-font/files/terminus-font-${pkg_version}.tar.gz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "terminus-font-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --psfdir=/usr/share/kbd/consolefonts \
        --x11dir=/usr/share/fonts/misc || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
