#!/bin/sh
#
# Recipe: /var/pkg/xorg/libdrm/build.sh
#
# libdrm - user-space interface to DRM/KMS
#

pkg_name=libdrm
pkg_version=2.4.124
pkg_category=xorg
pkg_description="libdrm - biblioteca user-space para DRM/KMS (Direct Rendering Manager)"
pkg_depends="toolchain:glibc base:zlib base:libpciaccess"

pkg_url="https://dri.freedesktop.org/libdrm/libdrm-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libdrm-${pkg_version}" || return 1

    # libdrm atual usa meson/ninja
    meson setup build \
        --prefix=/usr \
        --libdir=/usr/lib \
        --buildtype=release || return 1

    ninja -C build || return 1
    DESTDIR="$PKGROOT" ninja -C build install || return 1

    return 0
}
