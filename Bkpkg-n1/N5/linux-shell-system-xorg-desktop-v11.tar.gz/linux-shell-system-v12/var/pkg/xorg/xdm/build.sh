#!/bin/sh
#
# xdm - X Display Manager
#

pkg_name=xdm
pkg_version=1.1.15
pkg_category=xorg
pkg_description="xdm - gerenciador de display X clássico"
pkg_depends="toolchain:glibc xorg:xorg-server xorg:libX11 xorg:libXau xorg:libXdmcp xorg:libXaw xorg:libXmu base:shadow"

pkg_url="https://www.x.org/archive/individual/app/xdm-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "xdm-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
