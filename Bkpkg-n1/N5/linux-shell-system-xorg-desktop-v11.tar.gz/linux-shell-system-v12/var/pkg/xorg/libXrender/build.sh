#!/bin/sh
#
# libXrender - X Render extension client library
#

pkg_name=libXrender
pkg_version=0.9.11
pkg_category=xorg
pkg_description="libXrender - X Render extension client library"
pkg_depends="toolchain:glibc xorg:libX11 xorg:xorgproto"

pkg_url="https://www.x.org/archive/individual/lib/libXrender-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "libXrender-${pkg_version}" || return 1

    ./configure \
        --prefix=/usr \
        --disable-static || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
