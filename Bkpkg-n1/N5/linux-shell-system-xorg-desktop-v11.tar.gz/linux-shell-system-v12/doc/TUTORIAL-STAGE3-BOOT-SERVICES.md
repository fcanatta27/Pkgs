# Tutorial Stage3 – Kernel, /etc, Serviços e Primeiro Boot

Este documento complementa o `TUTORIAL-STAGES.md` e assume que você já concluiu:

- Stage0: toolchain temporária + userland mínimo
- Stage1: toolchain nativa instalada em `/usr`
- Stage2: pacotes base instalados com:
  - `pkg build --install base-system base`

O objetivo do Stage3 é transformar o rootfs em um sistema que:

- Dá boot direto no hardware
- Sobe `init` e `rcS`
- Inicia serviços essenciais (udev, rede, syslog, cron, ssh)
- É administrável (usuários/grupos, fstab, hostname)

Convenções:
- Rootfs: `/mnt/rootfs` (fora do chroot)
- Dentro do chroot, a raiz vista como `/`
- Toolchain nativa já instalada em `/usr`

## 1. Entrar no chroot com ambiente correto

No host:

```sh
pkg-chroot /mnt/rootfs -- /bin/bash
```

Dentro do chroot, ajuste PATH (se necessário):

```sh
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
```

Valide:

```sh
which bash
which gcc
which ld
```

Todos devem estar sob `/usr` (não mais em `/tools`).

## 2. Subir o Stage2 com um comando (meta-pacote base-system)

Ainda dentro do chroot:

```sh
pkg build --install base-system base
```

Isso garante:

- `util-linux`   → mount, umount, etc.
- `iproute2`     → ip, ss, tc
- `kmod`         → modprobe, lsmod, depmod
- `e2fsprogs`    → e2fsck, mkfs.ext4, tune2fs
- `procps-ng`    → ps, top, free

Checklist:

```sh
which mount
which ip
which lsmod
which e2fsck
which ps
```

Se algo falhar, não avance.

## 3. Configuração mínima de /etc

### 3.1 Usuários e grupos básicos

Arquivos esperados:

- `/etc/passwd`
- `/etc/group`
- `/etc/shadow`

O mínimo:

```text
root:x:0:0:root:/root:/bin/bash
```

em `/etc/passwd`, e:

```text
root:x:0:
```

em `/etc/group`. Em `/etc/shadow`, uma linha para root, que você pode ajustar depois via `passwd`.

Para definir uma senha de root dentro do chroot:

```sh
passwd
```

### 3.2 Hostname

Arquivo: `/etc/hostname`

Conteúdo padrão:

```text
mylinux
```

Ajuste para o nome da sua máquina se desejar.

### 3.3 /etc/fstab

Arquivo: `/etc/fstab`  

Exemplo funcional (ajuste o device de `/`):

```text
# <fs>         <dir>   <type>  <opts>          <dump> <pass>
/dev/sda1      /       ext4    defaults        1      1
proc           /proc   proc    nosuid,noexec   0      0
sysfs          /sys    sysfs   nosuid,noexec   0      0
devpts         /dev/pts devpts gid=5,mode=620  0      0
tmpfs          /run    tmpfs   nosuid,nodev    0      0
```

Substitua `/dev/sda1` pelo dispositivo ou UUID real do seu rootfs.

### 3.4 Resolução de nomes e NSS

Arquivos:

- `/etc/resolv.conf` – apontando para um DNS (ajuste conforme sua rede)
- `/etc/nsswitch.conf` – configurando ordem de resolução (files dns)

Verifique DNS dentro do chroot:

```sh
ping -c1 8.8.8.8        # testa conectividade IP
ping -c1 example.com    # testa DNS (se rede estiver OK)
```

### 3.5 Ambiente de shell (/etc/profile, /etc/issue, /etc/shells)

- `/etc/profile`: define PATH padrão e um prompt simples
- `/etc/issue`: mensagem de login no console
- `/etc/shells`: lista de shells válidos (inclui `/bin/sh` e `/bin/bash`)

Você pode personalizar, mas o bundle já deixa algo funcional.

## 4. Serviços e /etc/rc.d

O sistema usa um esquema simples de serviços:

- Scripts em `/etc/rc.d/<nome>` com `start|stop|restart|status`
- Serviços habilitados em `/etc/rc.d/enabled/SNN<nome>`
- `rcS` executa os habilitados em ordem numérica SNN

Novos serviços típicos de Stage3:

- `udev`      (eudev)
- `syslog-ng` (syslog-ng)
- `cronie`    (crond do cronie)
- `dhcpcd`    (cliente DHCP dedicado)
- `sshd`      (servidor OpenSSH)

### 4.1 Habilitar ou trocar serviços

Exemplos dentro do chroot:

- Habilitar eudev em vez de mdev:
  ```sh
  service disable mdev
  service enable udev 10
  ```

- Habilitar syslog-ng em vez do syslog BusyBox:
  ```sh
  service disable syslog
  service enable syslog-ng 20
  ```

- Habilitar rede via dhcpcd:
  ```sh
  service enable dhcpcd 30
  ```

- Habilitar cron via cronie:
  ```sh
  service disable cron
  service enable cronie 50
  ```

- Habilitar sshd:
  ```sh
  service enable sshd 60
  ```

Para verificar:

```sh
service list
service list-enabled
```

## 5. Kernel 6.18.2

Você pode compilar o kernel dentro do chroot usando a recipe `linux`:

```sh
pkg build --install linux base
```

Isso irá:

- baixar `linux-6.18.2.tar.xz`
- compilar com `defconfig`
- instalar:
  - imagem em `/boot/vmlinuz-6.18.2`
  - módulos em `/lib/modules/6.18.2-*`

Depois você pode customizar à vontade reconstruindo a partir da árvore em `/usr/src` (se você guardar as fontes).

## 6. Bootloader (GRUB em BIOS)

Assumindo que `/dev/sda` é seu disco e `/dev/sda1` é a partição root:

1. No host, monte o rootfs em `/mnt/rootfs`.
2. Entre no chroot:

   ```sh
   pkg-chroot /mnt/rootfs -- /bin/bash
   ```

3. Instale o GRUB:

   ```sh
   grub-install /dev/sda
   ```

4. Crie `/boot/grub/grub.cfg`:

   ```sh
   cat > /boot/grub/grub.cfg << 'EOF'
   set default=0
   set timeout=5

   menuentry "Meu Linux From Shell" {
       linux /boot/vmlinuz-6.18.2 root=/dev/sda1 ro
   }
   EOF
   ```

Ajuste `/dev/sda1` conforme seu layout (ou use UUID).

## 7. Primeiro boot real – checklist final

Antes de rebootar o host, confirme:

- [ ] `/mnt/rootfs/sbin/init` é executável
- [ ] `/mnt/rootfs/etc/rc.d/rcS` é executável
- [ ] `/mnt/rootfs/etc/fstab` aponta para o device correto de `/`
- [ ] `/mnt/rootfs/boot/vmlinuz-6.18.2` existe
- [ ] `/mnt/rootfs/lib/modules/6.18.2-*` existe
- [ ] `/mnt/rootfs/etc/passwd`, `/etc/group`, `/etc/shadow` existem
- [ ] `pkg-chroot /mnt/rootfs -- /bin/bash` funciona sem erro
- [ ] Dentro do chroot, `pkg build --install base-system base` foi executado com sucesso
- [ ] Os serviços desejados estão habilitados:
  ```sh
  service list-enabled
  ```

Se tudo estiver OK:

1. Saia do chroot (`exit`)
2. Reboot o host
3. Escolha a entrada "Meu Linux From Shell" no GRUB

Se o boot cair em `init` e você vir o fluxo do `rcS` e depois um `getty` em `tty1`, você chegou no ponto em que o sistema é realmente seu.
