# Tutorial de Construção do Sistema (Stage0 → Stage2)

Este tutorial é um checklist técnico fechado para construir seu Linux x86_64 “do zero” usando:

- Toolchain temporária fora do `pkg` (diretórios `/cross-toolchain` e `/cross-stage0`)
- `pkg` assumindo quando existir uma base mínima dentro do rootfs
- `pkg-chroot` como wrapper para entrar/sair do chroot com mounts seguros

Convenções padrão (podem ser sobrescritas por variáveis de ambiente):
- Rootfs alvo: `/mnt/rootfs`
- Toolchain temporária: `/mnt/rootfs/tools`
- Fontes: `/tmp/src`
- Builds: `/tmp/build`

## Pré-requisitos (Host)

No host (sistema que está construindo), você precisa de um conjunto típico de build:
- `bash`, `make`, `gcc`, `g++`, `binutils`, `tar`, `xz`, `gzip`, `bzip2`, `patch`
- `curl` ou `wget` (download)
- `python` não é obrigatório
- permissões de root para mounts e `chroot`

Também assuma que:
- o kernel do host suporta `proc`, `sysfs`, `devpts` (padrão em Linux moderno)
- você tem espaço em disco suficiente (toolchain + glibc + gcc ocupam bastante)

## Stage0 — Toolchain temporária + userland mínimo (fora do chroot)

Objetivo:
- preparar um rootfs “chrootável” com:
  - headers do kernel em `$ROOTFS/usr/include`
  - glibc em `$ROOTFS/usr`
  - toolchain temporária em `$ROOTFS/tools`
  - shell e ferramentas mínimas em `$ROOTFS/bin` e `$ROOTFS/usr/bin`

### Checklist Stage0 (A)

1. Prepare os diretórios:
   ```sh
   cd /cross-toolchain
   ./00-prepare.sh
   ```

2. Instale Linux API headers no rootfs:
   ```sh
   ./01-linux-headers.sh
   ```

3. Construa Binutils cross (temporário) em `$ROOTFS/tools`:
   ```sh
   ./02-binutils.sh
   ```

4. Construa GCC pass1 (C-only) em `$ROOTFS/tools`:
   ```sh
   ./03-gcc-pass1.sh
   ```

5. Construa e instale Glibc no rootfs (`DESTDIR=$ROOTFS`, prefix `/usr`):
   ```sh
   ./04-glibc.sh
   ```

6. Construa GCC pass2 (C/C++) em `$ROOTFS/tools` (agora usando a glibc do rootfs):
   ```sh
   ./05-gcc-pass2.sh
   ```

### Checklist Stage0 (B) — userland mínimo (ainda fora do chroot)

7. Instale BusyBox (fornece `/bin/sh`) no rootfs:
   ```sh
   cd /cross-stage0
   ./10-busybox-1.36.1.sh
   ```

8. Instale Coreutils no rootfs (prefix `/usr`, com symlinks essenciais em `/bin`):
   ```sh
   ./20-coreutils-9.9.sh
   ```

9. Instale Bash no rootfs (`/bin/bash`):
   ```sh
   ./30-bash-5.3.sh
   ```

### Validação Stage0 (fechada)

Rode no host (fora do chroot):

- Shell existe:
  ```sh
  test -x /mnt/rootfs/bin/sh
  test -x /mnt/rootfs/bin/bash
  ```

- Loader e libc existem (x86_64):
  ```sh
  test -e /mnt/rootfs/lib64/ld-linux-x86-64.so.2 || test -e /mnt/rootfs/lib/ld-linux-x86-64.so.2
  test -e /mnt/rootfs/lib64/libc.so.6 || test -e /mnt/rootfs/lib/libc.so.6 || test -e /mnt/rootfs/usr/lib/libc.so.6
  ```

Se estes itens falharem, NÃO avance: o chroot não vai funcionar.

## Stage1 — Primeiro chroot + toolchain nativa (dentro do chroot, com `pkg`)

Objetivo:
- entrar no chroot com um ambiente mínimo
- usar `pkg` para construir a toolchain “nativa” (instalada em `/usr`)
- deixar o sistema auto-hospedado (sem depender de `/tools`)

### Checklist Stage1 (A) — entrar no chroot

1. Entre no chroot usando o wrapper:
   ```sh
   pkg-chroot /mnt/rootfs -- /bin/bash
   ```

2. Dentro do chroot, valide:
   ```sh
   echo "PATH=$PATH"
   /bin/sh -c 'echo ok'
   /bin/bash -c 'echo ok'
   ```

Observação:
- o `pkg-chroot` já faz mounts e limpa ao sair.
- você ainda está usando a toolchain de `/tools` no PATH.

### Checklist Stage1 (B) — preparar ambiente mínimo no chroot

3. Crie dirs essenciais se ainda não existirem:
   ```sh
   mkdir -p /{dev,proc,sys,run,tmp,var,root,home}
   mkdir -p /var/{log,run,lib,pkg}
   mkdir -p /var/pkg/{db,cache,sources}
   ```

4. Ajuste PATH para priorizar `/usr/bin` e manter `/tools` no final (temporário):
   ```sh
   export PATH=/usr/bin:/bin:/usr/sbin:/sbin:/tools/bin
   ```

### Checklist Stage1 (C) — construir toolchain nativa com `pkg`

Use as recipes da categoria `toolchain` (modo nativo revisado no bundle v9).

5. Instale linux-headers “final” (no sistema; útil para consistência):
   ```sh
   pkg build --install linux-headers toolchain
   ```

6. Instale binutils nativo:
   ```sh
   pkg build --install binutils toolchain
   ```

7. Reinstale/normalize glibc nativa (agora via `pkg` no ambiente do chroot):
   ```sh
   pkg build --install glibc toolchain
   ```

8. Instale gcc nativo:
   ```sh
   pkg build --install gcc toolchain
   ```

### Validação Stage1 (fechada)

Dentro do chroot:

- gcc/ld devem vir de `/usr/bin`:
  ```sh
  command -v gcc
  command -v ld
  ls -l "$(command -v gcc)"
  ls -l "$(command -v ld)"
  ```

- o interpreter de um binário deve apontar para `/lib` ou `/lib64` (não para `/tools`):
  ```sh
  readelf -l /bin/bash | grep 'interpreter' || true
  ```

Quando este checklist passar, você pode remover `/tools` com segurança (opcional, mas recomendado):

```sh
rm -rf /tools
hash -r
```

Se você remover `/tools`, revalide que `gcc` continua funcionando.

## Stage2 — Base do sistema (serviços, rede, usuários, utilitários)

Objetivo:
- completar um sistema mínimo utilizável e “bootável” com:
  - init + rcS funcionando
  - logs, rede, cron (opcionais)
  - ferramentas administrativas e utilitários essenciais

**Nesta fase você deve usar `pkg` para tudo.**

### Checklist Stage2 — pacotes sugeridos (ordem prática)

1. Ferramentas de sistema:
   - `util-linux` (mount/umount/login/agetty dependendo de build)
   - `procps-ng` (ps/top)
   - `e2fsprogs` (fs tools)
   - `kmod` (modprobe/lsmod)
   - `iproute2` (ip)
   - `inetutils` ou alternativas (ping etc.)

2. Ferramentas de build (para continuar evoluindo):
   - `make`, `m4`, `bison`, `flex`
   - `perl` (muitos builds tradicionais dependem)
   - `pkgconf` (pkg-config)
   - `gettext`, `texinfo` (dependendo do ecossistema)

3. Layout e config mínima:
   - `/etc/passwd`, `/etc/group`, `/etc/shadow` (ao menos root)
   - `/etc/fstab` (se for bootar sem initramfs)
   - `/etc/hostname`
   - timezone/locale (opcional inicialmente)

4. Serviços e boot:
   - confirme `/sbin/init`, `/etc/rc.d/rcS`
   - use `/sbin/service enable <svc> <NN>` para ordem
   - valide logs em `/var/log`

### Validação Stage2 (fechada)

- init e rcS existem:
  ```sh
  test -x /sbin/init
  test -x /etc/rc.d/rcS
  ```

- scripts de serviço existem:
  ```sh
  ls -l /etc/rc.d
  ls -l /etc/rc.d/enabled
  ```

- `pkg` e DB:
  ```sh
  test -x /usr/bin/pkg
  test -d /var/pkg/db
  pkg list || true
  ```

Se este checklist estiver OK, você está pronto para:
- compilar e instalar um kernel dentro do rootfs (ou fora)
- instalar um bootloader (GRUB ou similar)
- fazer o primeiro boot real do sistema

## Observações finais

- Evite “misturar” estágios: se o Stage1 não está fechado (gcc/ld nativos, sem dependência em /tools), não avance.
- A partir do Stage2, sua evolução vira “distro engineering”: políticas de pacotes, split -dev, ABI, assinatura, etc.
