Fontconfig padrão
=================

- Diretórios de fontes ativados:
  - /usr/share/fonts
  - /usr/local/share/fonts
  - ~/.local/share/fonts
  - ~/.fonts

- Anti-aliasing, hinting leve e subpixel (RGB) habilitados.
- Famílias genéricas:
  - sans-serif -> Noto Sans, DejaVu Sans, Liberation Sans
  - serif      -> Noto Serif, DejaVu Serif, Liberation Serif
  - monospace  -> DejaVu Sans Mono, Noto Sans Mono, Terminus

Após instalar novas fontes, execute:
  fc-cache -f -v
