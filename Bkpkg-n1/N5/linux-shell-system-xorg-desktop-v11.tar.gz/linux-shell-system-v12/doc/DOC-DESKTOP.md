DOC-DESKTOP.md
==============

Visão geral
-----------

Este documento descreve, em alto nível, como:

- criar um usuário normal e adicioná‑lo aos grupos corretos;
- habilitar serviços essenciais (NetworkManager, acpid, firewalld, cups, etc.);
- subir diretamente em login gráfico (Xorg + Openbox + applets + Bluetooth + Polkit);
- fazer debug rápido de rede, som e vídeo.

Ele assume que você já está **dentro do chroot** do seu rootfs
(`chroot /mnt/rootfs /bin/bash`) e que o sistema já foi construído
com os meta‑pacotes principais (`desktop-full`, `laptop-full`, etc.).


1. Criação de usuário e grupos
------------------------------

1.1 Criar usuário normal
~~~~~~~~~~~~~~~~~~~~~~~~

Exemplo: criar usuário `fernando` com home em `/home/fernando`:

```sh
useradd -m -s /bin/bash fernando
passwd fernando
```

1.2 Grupos recomendados
~~~~~~~~~~~~~~~~~~~~~~~

Os grupos padrão recomendados estão listados em:

- `/etc/default-groups.txt`

Exemplo de conteúdo:

- audio
- video
- input
- plugdev
- wheel
- netdev
- storage
- power

Adicione o usuário nesses grupos (ajuste conforme seu uso):

```sh
usermod -aG audio,video,input,plugdev,wheel,netdev,storage,power fernando
```

Depois disso, faça logout/login (ou reboot) para as permissões de
grupo passarem a valer.


2. Habilitando serviços essenciais
----------------------------------

Os serviços seguem o modelo de scripts em:

- `/etc/rc.d/services/`
- `service <nome> {start|stop|restart|status}`

2.1 NetworkManager
~~~~~~~~~~~~~~~~~~

Subir na mão:

```sh
service networkmanager start
```

Para iniciar no boot:

- Crie symlink em `/etc/rc.d/enabled/`, respeitando a ordem SXX:

```sh
cd /etc/rc.d/enabled
ln -s ../services/networkmanager S20networkmanager
```

2.2 acpid (eventos ACPI: botão de energia, tampa, etc.)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Subir na mão:

```sh
service acpid start
```

Habilitar no boot:

```sh
cd /etc/rc.d/enabled
ln -s ../services/acpid S10acpid
```

2.3 PipeWire (modo sistema, opcional)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Você provavelmente vai rodar PipeWire em **sessão de usuário** via
`autostart` do Openbox, mas, se quiser um daemon de sistema para testes:

```sh
service pipewire start
```

2.4 TLP (economia de energia em notebooks)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Depois de instalar o pacote `tlp`:

```sh
service tlp start
cd /etc/rc.d/enabled
ln -s ../services/tlp S15tlp
```

2.5 UPower (estado de bateria, energia)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

UPower normalmente é um daemon D-Bus. Se houver service dedicado:

```sh
service upowerd start
cd /etc/rc.d/enabled
ln -s ../services/upowerd S15upowerd
```

Caso não exista service, basta garantir que `upowerd` está presente;
ambientes gráficos e ferramentas usam o serviço D-Bus sob demanda.

2.6 firewalld + iptables
~~~~~~~~~~~~~~~~~~~~~~~~

Subir firewall:

```sh
service firewalld start
cd /etc/rc.d/enabled
ln -s ../services/firewalld S40firewalld
```

Use:

```sh
firewall-cmd --state
firewall-cmd --get-active-zones
```

Para adicionar regras conforme necessidade.

2.7 CUPS (impressão)
~~~~~~~~~~~~~~~~~~~~

Subir daemon de impressão:

```sh
service cups start
cd /etc/rc.d/enabled
ln -s ../services/cups S30cups
```

Interface web padrão:

- http://localhost:631

2.8 Outros serviços típicos
~~~~~~~~~~~~~~~~~~~~~~~~~~~

- Bluetooth (`bluetoothd` via BlueZ) – se houver service:
  - `service bluetoothd start`
- `syslog-ng` – para logs centrais do sistema
- `NetworkManager` já cobre a maior parte da rede.


3. Login gráfico com Xorg + Openbox + applets
---------------------------------------------

3.1 Garantir que o Xorg e Openbox estão instalados
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Com o sistema ligado:

```sh
pkg build --install desktop-full meta
```

Isso puxa:

- Xorg, drivers, libs X
- Openbox, xterm / rxvt
- PipeWire, WirePlumber
- Firefox, ffmpeg, etc.

3.2 Xsession do Openbox
~~~~~~~~~~~~~~~~~~~~~~~

Arquivo criado:

- `/usr/share/xsessions/openbox.desktop`

Gerenciador de login gráfico (xdm/lightdm) vai listar:

- “Openbox Session”

3.3 Wrapper de sessão
~~~~~~~~~~~~~~~~~~~~~

Script:

- `/usr/bin/startopenbox`

Ele:

- exporta `XDG_SESSION_TYPE` e `XDG_CURRENT_DESKTOP`;
- chama `openbox-session` ou `openbox` + `autostart` global.

3.4 Autostart global
~~~~~~~~~~~~~~~~~~~~

Arquivo:

- `/etc/xdg/openbox/autostart`

Sobe automaticamente (se instalados):

- `pipewire`
- `pipewire-pulse`
- `wireplumber`
- `nm-applet`
- `blueman-applet`
- `lxqt-policykit-agent` (ou `mate-polkit` se disponível)
- roda `fc-cache` em background na primeira sessão.

3.5 Passos finais para login gráfico
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. Configure o `xdm` ou `lightdm` para iniciar no boot
   (service correspondente).
2. Garanta que seu usuário:
   - está nos grupos descritos em `/etc/default-groups.txt`;
   - tem senha definida (`passwd`).

Depois disso, o fluxo é:

- boot → getty/DM → login gráfico → Openbox + applets + áudio + rede.


4. Fluxos rápidos de debug
--------------------------

4.1 Rede
~~~~~~~~

1. Verificar IP e rotas:

   ```sh
   ip addr
   ip route
   ```

2. Verificar estado geral do NetworkManager:

   ```sh
   nmcli general status
   nmcli device
   nmcli connection show
   ```

3. Logs:

   - `/var/log/NetworkManager.log`
   - logs de sistema (`/var/log/messages` ou `/var/log/syslog`, conforme syslog-ng)

4. Verificar DNS:

   ```sh
   resolvectl status  # se houver
   cat /etc/resolv.conf
   ```

4.2 Som (PipeWire + WirePlumber)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. Verificar se daemons estão rodando (sessão usuário):

   ```sh
   ps aux | grep -E 'pipewire|wireplumber'
   ```

2. Verificar sinks / sources (se `pactl` estiver disponível):

   ```sh
   pactl info
   pactl list short sinks
   pactl list short sources
   ```

3. Logs:

   - `/var/log/pipewire-system.log` (se rodando em modo sistema)
   - para sessão usuário, logs em `journal` ou `~/.local/state/pipewire/` (dependendo da configuração).

4. Checar grupos:

   - usuário precisa estar em `audio` e `video` em alguns setups.

4.3 Vídeo / Xorg
~~~~~~~~~~~~~~~~

1. Verificar log do Xorg:

   - `/var/log/Xorg.0.log`

2. Procurar por erros:

   ```sh
   grep -E "(EE)" /var/log/Xorg.0.log
   grep -E "(WW)" /var/log/Xorg.0.log
   ```

3. Verificar aceleração 3D (se `glxinfo` estiver instalado):

   ```sh
   glxinfo | grep "direct rendering"
   glxinfo | grep "OpenGL renderer"
   ```

4. Verificar driver em uso:

   - No log do Xorg, procurar por:
     - `modesetting`
     - `amdgpu`
     - `intel`
     - etc.

4.4 Permissões e Polkit
~~~~~~~~~~~~~~~~~~~~~~~

Se:

- NM não deixa conectar Wi-Fi;
- udisks não monta pendrive;
- brightnessctl não funciona para usuário;

Verificar:

- usuário em grupos: `wheel`, `plugdev`, `power`, `audio`, `video`, `netdev`;
- se o agente do Polkit está rodando:
  - `ps aux | grep -i policykit`.

Se não estiver:

- verificar `autostart` do Openbox;
- instalar / ajustar o pacote `lxqt-policykit` (ou outro agente).

