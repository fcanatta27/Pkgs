#!/bin/sh
#
# /cross-stage0/20-coreutils-9.9.sh - Stage0 Coreutils para o rootfs
#

set -eu
. "$(dirname "$0")/config.sh"

VERSION=9.9
SRC_URL="https://ftp.gnu.org/gnu/coreutils/coreutils-${VERSION}.tar.xz"

tarball=$(download "$SRC_URL" "$SRC_DIR")

builddir="$BUILD_DIR/coreutils-${VERSION}-stage0-build"
rm -rf "$builddir"
mkdir -p "$builddir"
cd "$builddir"

tar xf "$tarball"
cd "coreutils-${VERSION}"

BUILD_TRIPLET=$(./build-aux/config.guess 2>/dev/null || echo "x86_64-unknown-linux-gnu")
HOST_TRIPLET="$CROSS_TARGET"

# Configure voltado para o alvo; não instala programas considerados "conflitantes" se desejar.
CC="${CROSS_TARGET}-gcc" \
./configure \
    --prefix=/usr \
    --build="$BUILD_TRIPLET" \
    --host="$HOST_TRIPLET" \
    --enable-install-program=hostname \
    --enable-no-install-program=kill,uptime

make -j"$JOBS"
make DESTDIR="$ROOTFS" install

# Garante que /bin contenha alguns utilitários essenciais (ln, cp, mv, rm, etc.)
mkdir -p "$ROOTFS/bin"
for f in cat chgrp chmod chown cp date dd echo false ln ls mkdir mknod mv pwd rm rmdir stty sync true uname ; do
    if [ -x "$ROOTFS/usr/bin/$f" ]; then
        ln -sf "../usr/bin/$f" "$ROOTFS/bin/$f"
    fi
done

echo "stage0: Coreutils ${VERSION} instalados em $ROOTFS."
