# Sistema Linux x86_64 do Zero (Esqueleto) – Toolchain Temporário, Init e Gerenciador de Pacotes em Shell

Este diretório contém um esqueleto de arquivos e scripts para:

- Organização do sistema alvo (`/`), usando um toolchain temporário.
- Init simples em shell (`/sbin/init`) e script principal de boot (`/etc/rc.d/rcS`).
- Gerenciador de pacotes minimalista em shell (`/usr/bin/pkg`).
- Wrapper de serviço (`/sbin/service`) e wrapper de daemon com log (`/usr/bin/pkg-logrun`).
- Exemplo de recipe categorizada em `/var/pkg/base/coreutils/build.sh`.

O objetivo é servir de base para o seu sistema, conforme os passos descritos anteriormente (host, toolchain, chroot, boot, etc.). Ajuste tudo conforme o seu ambiente real.
## Atualizações do bundle v3

Este bundle evolui o v2 com:

- `pkg`:
  - Download automático de fontes via `curl` com cache em `/var/pkg/cache/sources/`.
  - Suporte a múltiplos formatos de tarball (o `curl` baixa "como vier"; a recipe decide como extrair).
  - Registro automático de `category`, `description` e `depends` no banco de dados a partir da recipe.
    - Implementado via arquivo de metadados dentro do pacote (`.pkgmeta`) gerado no `build` e lido no `install`.
  - Resolução de dependências (DFS) com detecção de ciclos.
    - `pkg build <nome> [categoria]` constrói primeiro as dependências declaradas na recipe.
    - Sintaxe de dependência:
      - `foo` (usa categoria default)
      - `base:foo` ou `base/foo` (categoria explícita)

- `init`:
  - Reaper de processos (trata SIGCHLD) para evitar zombies.
  - Suporte a modo single-user via parâmetro `single` ou `S` no cmdline do kernel.
  - Inicialização um pouco mais completa: remount `/` como RW (se possível), hostname, execução de `rcS`, e múltiplos gettys.

- `rcS`:
  - Executa scripts de inicialização em `/etc/rc.d/S??*` (estilo SysV simplificado), se existirem.

## Atualizações do bundle v4

- `pkg`:
  - Novo modo `pkg build --install <nome> [categoria]` (build + install).
- `service`:
  - Subcomandos: `list`, `enable`, `disable`, `enabled`.
  - `service <svc>` assume `status`.
  - `enable/disable` via symlinks em `/etc/rc.d/enabled/`.
- `rcS`:
  - Inicia automaticamente serviços habilitados em `/etc/rc.d/enabled/`.
- `pkg-chroot`:
  - Script `/usr/bin/pkg-chroot` para montar pseudo-filesystems, executar comando no chroot e desmontar com segurança.

## Atualizações do bundle v5

- `rcS`:
  - Inicia serviços habilitados em `/etc/rc.d/enabled/` respeitando ordem por prefixo `SNN*`
    (ex.: `S10mdev`, `S20syslog`, `S30network`), o que ajuda a manter dependências de runtime previsíveis.

- Serviços adicionais em `/etc/rc.d/`:
  - `mdev`  (BusyBox mdev; popula /dev e configura hotplug)
  - `syslog` (BusyBox syslogd/klogd; logs em /var/log/messages)
  - `network` (ip + DHCP opcional via udhcpc/dhclient)
  - `cron` (BusyBox crond; logs em /var/log/cron.log)

- Exemplos habilitados (symlinks):
  - `/etc/rc.d/enabled/S10mdev -> ../mdev`
  - `/etc/rc.d/enabled/S20syslog -> ../syslog`
  - `/etc/rc.d/enabled/S30network -> ../network`
  - `/etc/rc.d/enabled/S40sshd -> ../sshd`
  - `/etc/rc.d/enabled/S50cron -> ../cron`

## Atualizações do bundle v6

- Correções em scripts:
  - `pkg`: parser de `.pkgmeta` sem `eval`, não instala `/.pkgmeta`, remoção em duas fases (arquivos/dirs),
    e evita rebuild repetido em árvores de dependências na mesma execução.
  - `pkg-chroot`: monta/desmonta com tracking somente em caso de sucesso (menos risco de umount indevido).
  - `init`: reaper portátil (sem `wait -n`) e respawn simples de getty.
  - `service`: `enable <svc> [NN]` cria `/etc/rc.d/enabled/SNN<svc>` e `list-enabled` lista habilitados.

- Recipes toolchain adicionadas (categoria `toolchain`):
  - `/var/pkg/toolchain/linux-headers/build.sh` (linux-headers 6.18.2)
  - `/var/pkg/toolchain/binutils/build.sh` (binutils 2.45.1)
  - `/var/pkg/toolchain/glibc/build.sh` (glibc 2.42; depende de linux-headers)
  - `/var/pkg/toolchain/gcc/build.sh` (gcc 15.2.0; baixa prerequisitos via download_prerequisites)

## Atualizações do bundle v7

Diretório `/cross-toolchain` (toolchain temporária, sem usar `pkg`):

- `config.sh`
  - Define variáveis comuns:
    - `ROOTFS` (padrão `/mnt/rootfs`)
    - `TOOLS`  (padrão `$ROOTFS/tools`)
    - `SRC_DIR` (padrão `/tmp/src`)
    - `BUILD_DIR` (padrão `/tmp/build`)
    - `CROSS_TARGET` (padrão `x86_64-lfs-linux-gnu`)
    - versões: `LINUX_VER`, `BINUTILS_VER`, `GLIBC_VER`, `GCC_VER`
  - Função `download()` usando `curl` ou `wget`.

- `00-prepare.sh`
  - Cria diretórios base e opcionalmente linka `/tools -> $ROOTFS/tools`.

- `01-linux-headers.sh`
  - Baixa `linux-${LINUX_VER}` do kernel.org.
  - Executa `make mrproper && make headers_install INSTALL_HDR_PATH=$ROOTFS/usr`.

- `02-binutils.sh`
  - Constrói Binutils cross:
    - prefix=`$ROOTFS/tools`
    - target=`$CROSS_TARGET`
    - `--with-sysroot=$ROOTFS`.

- `03-gcc-pass1.sh`
  - GCC pass1 (C-only, sem headers) para o alvo:
    - prefix=`$ROOTFS/tools`
    - usa `--with-sysroot=$ROOTFS`.

- `04-glibc.sh`
  - Glibc (`glibc-${GLIBC_VER}`) para o sistema alvo:
    - `DESTDIR=$ROOTFS`, `prefix=/usr`
    - usa headers em `$ROOTFS/usr/include`.

- `05-gcc-pass2.sh`
  - GCC pass2 (C e C++) usando Glibc do rootfs:
    - target=`$CROSS_TARGET`, prefix=`$ROOTFS/tools`, sysroot=`$ROOTFS`.

Fluxo típico (como root no host):

```sh
cd /cross-toolchain
./00-prepare.sh
./01-linux-headers.sh
./02-binutils.sh
./03-gcc-pass1.sh
./04-glibc.sh
./05-gcc-pass2.sh
```

## Atualizações do bundle v8

Diretório `/cross-stage0` (stage0 de userland mínimo, ainda sem `pkg`):

- `config.sh`
  - Reaproveita `/cross-toolchain/config.sh` se existir (ROOTFS, TOOLS, SRC_DIR, BUILD_DIR, CROSS_TARGET, JOBS).
  - Garante `PATH` com prioridade para `$TOOLS/bin`.

- `10-busybox-1.36.1.sh`
  - Baixa `busybox-1.36.1.tar.bz2`.
  - Compila com `CROSS_TARGET` (CROSS_COMPILE=`$CROSS_TARGET-`).
  - Instala em `$ROOTFS` (`CONFIG_PREFIX=$ROOTFS`).
  - Garante symlink `bin/sh -> busybox`.

- `20-coreutils-9.9.sh`
  - Baixa `coreutils-9.9.tar.xz`.
  - Configura com `--build=$(config.guess)` e `--host=$CROSS_TARGET`.
  - Instala com `DESTDIR=$ROOTFS` e prefix `/usr`.
  - Cria symlinks essenciais em `$ROOTFS/bin` apontando para `/usr/bin`.

- `30-bash-5.3.sh`
  - Baixa `bash-5.3.tar.gz`.
  - Configura com `--build=$(config.guess)` e `--host=$CROSS_TARGET`.
  - Instala com `DESTDIR=$ROOTFS` e prefix `/usr`.
  - Cria `bin/bash -> ../usr/bin/bash`.

Fluxo sugerido (após terminar a toolchain em `/cross-toolchain`):

```sh
cd /cross-stage0
./10-busybox-1.36.1.sh
./20-coreutils-9.9.sh
./30-bash-5.3.sh
```

Depois disso, o rootfs em `$ROOTFS` terá:
  - /bin/sh (BusyBox)
  - /bin/bash
  - Coreutils e demais applets da BusyBox

Ou seja, um ambiente mínimo consistente para o primeiro chroot funcional.
