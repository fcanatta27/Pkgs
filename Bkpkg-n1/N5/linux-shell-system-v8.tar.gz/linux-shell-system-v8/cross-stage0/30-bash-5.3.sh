#!/bin/sh
#
# /cross-stage0/30-bash-5.3.sh - Stage0 Bash para o rootfs
#

set -eu
. "$(dirname "$0")/config.sh"

VERSION=5.3
SRC_URL="https://ftp.gnu.org/gnu/bash/bash-${VERSION}.tar.gz"

tarball=$(download "$SRC_URL" "$SRC_DIR")

builddir="$BUILD_DIR/bash-${VERSION}-stage0-build"
rm -rf "$builddir"
mkdir -p "$builddir"
cd "$builddir"

tar xf "$tarball"
cd "bash-${VERSION}"

BUILD_TRIPLET=$(./support/config.guess 2>/dev/null || echo "x86_64-unknown-linux-gnu")
HOST_TRIPLET="$CROSS_TARGET"

CC="${CROSS_TARGET}-gcc" \
./configure \
    --prefix=/usr \
    --build="$BUILD_TRIPLET" \
    --host="$HOST_TRIPLET" \
    --without-bash-malloc

make -j"$JOBS"
make DESTDIR="$ROOTFS" install

# Garante /bin/bash -> /usr/bin/bash
mkdir -p "$ROOTFS/bin"
if [ -x "$ROOTFS/usr/bin/bash" ]; then
    ln -sf "../usr/bin/bash" "$ROOTFS/bin/bash"
fi

echo "stage0: Bash ${VERSION} instalado em $ROOTFS."
