#!/bin/sh
#
# /cross-toolchain/02-binutils.sh - Binutils cross (temporário) em $TOOLS
#

set -eu
. "$(dirname "$0")/config.sh"

SRC_URL="https://ftp.gnu.org/gnu/binutils/binutils-${BINUTILS_VER}.tar.xz"

tarball=$(download "$SRC_URL" "$SRC_DIR")

builddir="$BUILD_DIR/binutils-${BINUTILS_VER}-build"
rm -rf "$builddir"
mkdir -p "$builddir"
cd "$builddir"

tar xf "$tarball"
cd "binutils-${BINUTILS_VER}"

mkdir -p build
cd build

../configure \
    --prefix="$TOOLS" \
    --target="$CROSS_TARGET" \
    --with-sysroot="$ROOTFS" \
    --disable-nls \
    --disable-werror

make -j"$JOBS"
make install

echo "02-binutils: instalado em $TOOLS (target=$CROSS_TARGET)."
