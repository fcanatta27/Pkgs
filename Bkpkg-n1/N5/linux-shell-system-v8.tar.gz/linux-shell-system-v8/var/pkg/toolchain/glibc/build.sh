#!/bin/sh
#
# Recipe: /var/pkg/toolchain/glibc/build.sh
#
# Observações:
#   - Requer Linux API headers instalados em /usr/include no ambiente de build/runtime.
#   - Em sistemas do tipo LFS, glibc é normalmente construído em build dir separado.
#

pkg_name=glibc
pkg_version=2.42
pkg_category=toolchain
pkg_description="GNU C Library"
pkg_depends="toolchain:linux-headers"

pkg_url="https://ftp.gnu.org/gnu/glibc/glibc-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "glibc-${pkg_version}" || return 1

    mkdir -p build
    cd build || return 1

    if [ -z "${BUILD:-}" ]; then
        BUILD=$(../scripts/config.guess 2>/dev/null || echo "x86_64-unknown-linux-gnu")
    fi
    if [ -z "${HOST:-}" ]; then
        HOST="$BUILD"
    fi

    # Prefixo final /usr
    ../configure \
        --prefix=/usr \
        --build="$BUILD" \
        --host="$HOST" \
        --disable-werror \
        --enable-kernel=3.2 \
        libc_cv_slibdir=/usr/lib || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
