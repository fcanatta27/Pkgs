#!/bin/sh
#
# Recipe: /var/pkg/toolchain/gcc/build.sh
#
# Observações importantes:
#   - GCC requer dependências (gmp, mpfr, mpc, isl). Esta recipe usa
#     ./contrib/download_prerequisites para baixar e incluir essas libs no tree.
#   - Requer um compilador C/C++ funcional no ambiente (host toolchain).
#

pkg_name=gcc
pkg_version=15.2.0
pkg_category=toolchain
pkg_description="GNU Compiler Collection"
pkg_depends="toolchain:binutils toolchain:glibc"

pkg_url="https://gcc.gnu.org/pub/gcc/releases/gcc-${pkg_version}/gcc-${pkg_version}.tar.xz"

build() {
    : "${PKGROOT:?PKGROOT não definido}"
    : "${WORKDIR:?WORKDIR não definido}"
    : "${SRCFILE:?SRCFILE não definido}"

    cd "$WORKDIR" || return 1
    tar xf "$SRCFILE" || return 1
    cd "gcc-${pkg_version}" || return 1

    # Baixar prerequisitos (gmp/mpfr/mpc/isl)
    if [ -x ./contrib/download_prerequisites ]; then
        ./contrib/download_prerequisites || return 1
    fi

    mkdir -p build
    cd build || return 1

    if [ -z "${BUILD:-}" ]; then
        BUILD=$(../config.guess 2>/dev/null || echo "x86_64-unknown-linux-gnu")
    fi
    if [ -z "${HOST:-}" ]; then
        HOST="$BUILD"
    fi
    if [ -z "${TARGET:-}" ]; then
        TARGET="$BUILD"
    fi

    # Linguagens padrão: C e C++ (ajuste conforme necessário)
    ../configure \
        --prefix=/usr \
        --build="$BUILD" \
        --host="$HOST" \
        --target="$TARGET" \
        --disable-multilib \
        --enable-languages=c,c++ \
        --enable-shared \
        --enable-threads=posix \
        --enable-__cxa_atexit \
        --with-system-zlib || return 1

    make || return 1
    make DESTDIR="$PKGROOT" install || return 1

    return 0
}
