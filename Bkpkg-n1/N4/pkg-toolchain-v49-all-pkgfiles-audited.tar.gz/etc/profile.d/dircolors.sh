# /etc/profile.d/dircolors.sh
if command -v dircolors >/dev/null 2>&1; then
  if [ -f /etc/dircolors ]; then
    eval "$(dircolors -b /etc/dircolors)"
  fi
else
  export LS_COLORS='di=01;34:ln=01;36:ex=01;32:*.tar=01;31:*.gz=01;31:*.bz2=01;31:*.xz=01;31:*.zst=01;31:*.zip=01;31:*.png=01;35:*.jpg=01;35:*.jpeg=01;35:*.mp3=01;35:*.flac=01;35:'
fi

alias ls='ls --color=auto'
alias ll='ls -lh'
alias la='ls -lha'
alias grep='grep --color=auto'
