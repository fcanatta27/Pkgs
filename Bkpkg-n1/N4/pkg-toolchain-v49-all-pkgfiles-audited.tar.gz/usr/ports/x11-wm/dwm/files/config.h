/* config.h exemplo para dwm */
static const char *termcmd[]  = { "xfce4-terminal", NULL };
