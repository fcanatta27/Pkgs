# Notas sobre o rootfs (desktop/notebook)

Este rootfs foi preparado para uso como sistema desktop/notebook com:

- init via /etc/init.d + /etc/init/services.conf
- LightDM opcional para login gráfico
- XFCE como sessão padrão
- NetworkManager + nm-applet
- PipeWire/WirePlumber + pavucontrol (GUI)
- Bluetooth (bluetoothd + blueman-applet) opcional
- gvfs + udisks2 para montagem de mídias

Para ativar o login gráfico por padrão, edite:

    /etc/init/services.conf

e altere:

    lightdm = NO

para:

    lightdm = YES

Usuários novos herdam /etc/skel, que inclui autostart para nm-applet,
blueman-applet e pavucontrol.

Para reparo de ambiente desktop, use:

    pkg-doctor --desktop
    pkg-doctor --desktop --fix
