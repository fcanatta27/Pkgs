# Cola de Debug – Sistema Desktop/Notebook (v45+)

Este documento reúne **problemas comuns** após a instalação e os **comandos exatos**
para diagnóstico e correção rápida.

Use sempre que algo “não funciona” após boot ou login gráfico.

------------------------------------------------------------
## 1) Sem som (PipeWire / WirePlumber)
------------------------------------------------------------

### Verificar se processos estão rodando (sessão do usuário)
```sh
ps aux | egrep 'pipewire|wireplumber' | grep -v egrep
```

Se **não estiverem rodando**:
```sh
pipewire &
wireplumber &
```

### Verificar dispositivos de áudio
```sh
pactl info
pactl list short sinks
```

### Abrir mixer gráfico
```sh
pavucontrol
```

### Verificar grupos
```sh
groups
```
Usuário deve estar em:
```
audio video
```

Adicionar usuário aos grupos:
```sh
usermod -aG audio,video,seu_usuario
```
Depois **logout/login**.

------------------------------------------------------------
## 2) Sem Wi‑Fi (NetworkManager)
------------------------------------------------------------

### Verificar serviço
```sh
service NetworkManager status
```

Se parado:
```sh
service NetworkManager start
```

### Ver interfaces
```sh
ip link
nmcli device
```

### Conectar via CLI
```sh
nmcli device wifi list
nmcli device wifi connect "SSID" password "SENHA"
```

### nm-applet não aparece
```sh
nm-applet &
```

Se funcionar manualmente, confira autostart:
```sh
ls ~/.config/autostart/nm-applet.desktop
```

------------------------------------------------------------
## 3) LightDM tela preta / não abre
------------------------------------------------------------

### Verificar serviço
```sh
service lightdm status
```

### Tentar iniciar manualmente
```sh
service lightdm start
```

### Testar XFCE manualmente (TTY)
```sh
startxfce4
```

Se XFCE abrir, o problema é LightDM.

### Conferir config
```sh
cat /etc/lightdm/lightdm.conf
```

Deve conter:
```
user-session=xfce
```

### Conferir Xsession
```sh
ls -l /etc/lightdm/Xsession
```

Executável:
```sh
chmod +x /etc/lightdm/Xsession
```

------------------------------------------------------------
## 4) Sem X / tela preta geral
------------------------------------------------------------

### Testar X mínimo
```sh
Xorg -configure
Xorg :1
```

### Conferir drivers
```sh
lsmod | grep -E 'amdgpu|nouveau|i915'
```

### Conferir Mesa
```sh
glxinfo | grep "OpenGL renderer"
```

------------------------------------------------------------
## 5) USB / pendrive não monta
------------------------------------------------------------

### Verificar serviços
```sh
service udisksd status
service upowerd status
```

### Testar manualmente
```sh
udisksctl status
```

### Conferir grupos
```sh
groups
```
Usuário deve estar em:
```
plugdev
```

------------------------------------------------------------
## 6) Bluetooth não funciona
------------------------------------------------------------

### Verificar serviço
```sh
service bluetoothd status
```

### Iniciar
```sh
service bluetoothd start
```

### Applet
```sh
blueman-applet &
```

------------------------------------------------------------
## 7) Energia / brilho (notebook)
------------------------------------------------------------

### ACPI
```sh
service acpid status
```

### Power profiles
```sh
service power-profiles status
```

### Brilho
```sh
brightnessctl
brightnessctl set 50%
```

------------------------------------------------------------
## 8) Permissões estranhas / apps não abrem
------------------------------------------------------------

### Rodar verificação geral
```sh
pkg-doctor --desktop
```

### Corrigir automaticamente
```sh
pkg-doctor --desktop --fix
```

------------------------------------------------------------
## 9) Logs importantes
------------------------------------------------------------

```sh
dmesg | less
tail -n 200 /var/log/messages
```

LightDM:
```sh
tail -n 200 /var/log/lightdm/lightdm.log
```

------------------------------------------------------------
## 10) Último recurso
------------------------------------------------------------

```sh
pkg-doctor --desktop --fix
reboot
```

Na maioria dos casos, isso resolve problemas de:
- grupos
- serviços desligados
- configs ausentes
