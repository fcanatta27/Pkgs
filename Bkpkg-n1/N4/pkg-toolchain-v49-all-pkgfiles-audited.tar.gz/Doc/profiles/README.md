# Perfis de instalação (desktop/notebook)

Estes arquivos são listas explícitas de "top-level packages" para instalar via `pkg i`.
As dependências devem ser resolvidas automaticamente pelo `pkg` via `depends=()`.

Perfis:
- `base-login.list`  -> base com login em tty + serviços essenciais (dbus/elogind/polkit) + rede/áudio.
- `xorg.list`        -> adiciona Xorg + Mesa + Vulkan/VAAPI + drivers básicos.
- `xfce-lightdm.list`-> adiciona XFCE4 + LightDM.

Observação:
- `pipewire`/`wireplumber` geralmente rodam como sessão do usuário (XFCE), por isso o serviço global pode ficar NO.
- Bluetooth e firewalld são opcionais: ative se necessário.
