\
# README – Toolchain LFS, `pkg` e init em shell (minit)

Este documento descreve como usar o `pkg` e os Pkgfiles do toolchain, a ordem recomendada de build para **toolchain temporário** e **toolchain final**, e como usar o **minit** (init em shell) com monitor de serviços e enable/disable via arquivo de configuração.

Conceitos-chave:

- `LFS_TGT` (triplet): `x86_64-lfs-linux-gnu`
- `TOOLCHAIN_ROOT`: `/tmp/rootfs-toolchain`
- `ROOT`: root de instalação (para pass1/pass2 é forçado para `TOOLCHAIN_ROOT`)

---

## 1) Ordem do toolchain temporário (pass1 → headers → glibc → pass2)

Export (opcional, mas recomendado):

```sh
export LFS_TGT=x86_64-lfs-linux-gnu
export TOOLCHAIN_ROOT=/tmp/rootfs-toolchain
```

Ordem recomendada:

1. **binutils pass1**
   ```sh
   pkg b devel/binutils-pass1
   ```
2. **gcc pass1**
   ```sh
   pkg b devel/gcc-pass1
   ```
3. **linux-headers**
   ```sh
   pkg b system/linux-headers
   ```
4. **glibc pass1**
   ```sh
   pkg b system/glibc-pass1
   ```
5. **binutils pass2**
   ```sh
   pkg b devel/binutils-pass2
   ```
6. **gcc pass2**
   ```sh
   pkg b devel/gcc-pass2
   ```
7. **libstdc++ (a partir do GCC 15.2.0)**
   ```sh
   pkg b devel/libstdc++-15.2
   ```

Observação: nos pass2, o Pkgfile força:

- `PATH="$TOOLCHAIN_ROOT/usr/bin:$PATH"`
- `CC="$LFS_TGT-gcc"` etc.
- `--with-sysroot="$TOOLCHAIN_ROOT"`

Isso elimina o risco do pass2 “pegar” o toolchain do host por acidente.

---

## 2) Toolchain final (dentro do chroot do TOOLCHAIN_ROOT)

A fase final deve acontecer **dentro do chroot** do rootfs temporário (isso garante que o compilador ativo e as libs sejam as do toolchain que você acabou de construir).

Exemplos:

```sh
pkg-chroot /tmp/rootfs-toolchain -- pkg b devel/m4
pkg-chroot /tmp/rootfs-toolchain -- pkg b devel/binutils
pkg-chroot /tmp/rootfs-toolchain -- pkg b devel/gcc
```

---

## 3) Verificação, remoção e reparo

### Verificar pacotes
```sh
pkg v all
```

### Reparar e checar consistência
```sh
pkg-reparo --root / --mode all
```

Modos úteis:

- `hashes` (archive vs `.meta`)
- `filesums` (hash por arquivo vs DB `*.sha256`)
- `conflicts` (paths em múltiplos pacotes)
- `orphans` (arquivos sob ROOT não pertencem a pacote)
- `rebuild-db --fix` (recria `.list/.meta/.sha256` quando faltando)

### Remover pacotes (seguro)
```sh
pkg-remove <nome-versao>
# ou
pkg-remove <nome>
```

Proteções:
- Não remove em `/` sem `--force`
- Não remove nada em `/etc` sem `--force`

---

## 4) minit (init em shell) – como usar

Arquivos:

- `/sbin/minit` (init)
- `/etc/init/services.conf` (enable/disable)
- `/etc/init.d/<serviço>` (scripts de serviço)
- `/usr/bin/service` (helper para start/stop/status manual)

### services.conf (enable/disable)
Formato:

```ini
syslogd = YES
sshd    = NO
crond   = YES
getty-tty1 = YES
```

O `minit` recarrega este arquivo periodicamente. Trocar `NO→YES` inicia o serviço; `YES→NO` para o serviço.

### Scripts prontos incluídos
Este bundle inclui scripts funcionais para:

- `syslogd` (BusyBox syslogd ou rsyslogd, fallback)
- `sshd` (OpenSSH; gera chaves de host se faltarem)
- `crond` (BusyBox crond ou crond/cronie, fallback)
- `getty-tty1` (agetty ou BusyBox getty)
- `network` (loopback + DHCP via `udhcpc`/`dhcpcd` se existir)

---

## 5) Troubleshooting (erros comuns de LFS e sintomas)

### 5.1 “O pass2 está usando o compilador do host”
**Sintomas**
- `gcc -v` mostra paths do host
- `configure` pega `/usr/include` do host

**Causa típica**
- `PATH` não está priorizando `TOOLCHAIN_ROOT/usr/bin`
- `CC/CXX/LD` não estão fixados

**Correção**
- Use os Pkgfiles pass2 do bundle (já fazem isso).
- Se estiver executando manualmente:
  ```sh
  export PATH="$TOOLCHAIN_ROOT/usr/bin:$PATH"
  export CC="$LFS_TGT-gcc"
  ```

---

### 5.2 “glibc configure falha dizendo que headers do kernel não existem”
**Sintomas**
- Erro em `--with-headers` ou arquivos ausentes em `usr/include`

**Causa típica**
- `linux-headers` não instalado no `TOOLCHAIN_ROOT/usr/include`
- Ordem errada de build

**Correção**
- Garanta que `linux-headers` foi instalado antes do `glibc-pass1`:
  ```sh
  pkg b system/linux-headers
  pkg b system/glibc-pass1
  ```

---

### 5.3 “Falha ao extrair tar.zst”
**Sintomas**
- `tar: unrecognized option '--zstd'` ou não consegue descompactar

**Causa típica**
- `tar` sem suporte a `--zstd` e ausência de `unzstd`

**Correção**
- Instale `zstd` (para `unzstd`) OU use tar compatível.
- O `pkg` faz fallback via `unzstd` quando disponível.

---

### 5.4 “Falta gmp/mpfr/mpc/isl ao buildar gcc”
**Sintomas**
- `configure: error: GMP is missing` etc.

**Causa típica**
- `./contrib/download_prerequisites` não rodou e não há libs no host

**Correção**
- Garanta que o script exista e rodeu no `prepare()` do gcc.
- Se não existir, instale as dependências no host ou adicione Pkgfiles para elas.

---

### 5.5 “Dentro do chroot, comandos básicos falham”
**Sintomas**
- `chroot: failed to run command` / `No such file or directory`

**Causa típica**
- rootfs incompleto (faltam `/bin/sh`, libs, etc.)
- montagens `/proc /sys /dev` não feitas

**Correção**
- Use `pkg-chroot` (ele monta `/dev,/proc,/sys,/run` automaticamente).
- Confirme que seu rootfs tem shell e libs mínimas.

---

### 5.6 “sshd não sobe”
**Sintomas**
- `sshd: no hostkeys available` ou falha silenciosa

**Correção**
- O script `/etc/init.d/sshd` tenta gerar chaves automaticamente via `ssh-keygen`.
- Confirme:
  - `/etc/ssh/sshd_config` existe
  - `ssh-keygen` e `sshd` estão instalados
  - permissões corretas em `/etc/ssh` e `/var/run` (ou `/run`)

---

## 6) Exemplo de configuração inicial do init

Edite:

`/etc/init/services.conf`

Sugestão mínima para um sistema funcional em console:

```ini
syslogd = YES
crond = YES
getty-tty1 = YES
network = YES
# sshd = YES  # habilite quando OpenSSH estiver instalado/configurado
```

Inicie o init (teste manual):

```sh
/sbin/minit
```

Como PID1 (kernel):
- Inicie o kernel com `init=/sbin/minit`.

---

## 7) Init – targets (boot/default) e rc-local

### 7.1 Targets
O `minit` suporta um mecanismo simples de “targets” sem systemd.

- Arquivo de seleção do target:
  - `/etc/init/target`
- Configs de target:
  - `/etc/init/targets/boot.conf`
  - `/etc/init/targets/default.conf`

Formato dos `.conf`: o mesmo de `services.conf` (`nome = YES|NO`).

Fluxo:

1. Se `/etc/init/target` estiver como `boot`, o `minit`:
   - aplica os serviços de boot uma vez
   - então grava `default` em `/etc/init/target`
2. Em seguida entra no loop contínuo com `default`.

Você pode mudar o target em runtime editando `/etc/init/target` e/ou os arquivos em `/etc/init/targets/`.

### 7.2 rc-local
- `/etc/rc.local` é executado pelo serviço `rc-local`.
- O serviço é **oneshot**: ele marca `/run/rc-local.done` para não ser repetido pelo monitor.

### 7.3 time-sync
- Serviço: `/etc/init.d/time-sync`
- Prefere `chronyd`, fallback `ntpd`.
- Para uso com `ntp` (pacote abaixo), basta instalar e deixar `time-sync = YES`.

## Sequência de boot (kernel + initramfs + init)

Resumo do ciclo completo usando os ports deste kit:

1. Construir e instalar a toolchain (ver `usr/ports/toolchain/README.md`).
2. Construir o sistema base (glibc final, coreutils, bash, etc.).
3. Construir o kernel e firmware:

   ```sh
   pkg i kernel/linux
   pkg i kernel/linux-firmware
   ```

4. Gerar o initramfs correspondente:

   ```sh
   # KVER pode ser informado explicitamente ou autodetectado
   pkg-initramfs --root / --kver 6.18.2
   # ou simplesmente:
   pkg-initramfs --root /
   ```

   Isso criará um arquivo do tipo:

   - `/boot/initramfs-6.18.2.img`

5. Configurar o bootloader (exemplo genérico GRUB):

   ```
   menuentry 'Meu LFS' {
       linux  /boot/vmlinuz-6.18.2 root=/dev/sdXN ro
       initrd /boot/initramfs-6.18.2.img
   }
   ```

6. O `init` dentro do initramfs fará:
   - mount de `/proc`, `/sys`, `/dev`
   - montagem ou bind do root real em `/newroot`
   - `switch_root /newroot /sbin/init`

Com isso o sistema deve dar boot diretamente no init system instalado em `/sbin/init` (minit + scripts deste kit).

