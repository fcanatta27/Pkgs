# Ultra Cola – Desktop final (bundle v47/v48)

## 1. Instalar tudo (desktop-final)

```sh
# dentro do sistema de build/chroot com ports montados
cd /caminho/do/bundle

# instala a base + Xorg + XFCE + serviços + browsers
pkg i $(grep -v '^#' Doc/profiles/desktop-final.list | sed 's/^pkg i  //')
```

---

## 2. Empacotar rootfs e ISO

Assumindo que o rootfs final está em `/mnt/target` e o kernel é `6.18.2`:

```sh
pkg-pack \
  --root /mnt/target \
  --kernel /mnt/target/boot/vmlinuz-6.18.2 \
  --initramfs /mnt/target/boot/initramfs-6.18.2.img \
  --outdir /tmp/pkgos-out \
  --label PKGOS \
  --compress zstd
```

Resultado esperado em `/tmp/pkgos-out`:

- `rootfs.tar.zst`
- `pkgos.iso` (nome pode variar conforme config interna)

---

## 3. Gerar initramfs (se estiver montando manualmente)

Se você já tem o sistema instalado em `/` e só quer (re)gerar o initramfs:

```sh
pkg-initramfs --root / --kver 6.18.2 --out /boot/initramfs-6.18.2.img
```

---

## 4. Instalar no disco com usuário padrão

No live (bootado pela ISO):

```sh
lsblk    # descubra disco/partições

pkg-installer \
  --disk /dev/sda \
  --root-part /dev/sda2 \
  --boot-part /dev/sda1 \
  --hostname pkgdesk \
  --locale pt_BR.UTF-8 \
  --keymap br-abnt2 \
  --user fernando \
  --user-password 1234 \
  --profile desktop
```

---

## 5. Ativar LightDM para cair direto no XFCE

Depois da instalação (no sistema instalado):

```sh
# 1) editar serviços
vim /etc/init/services.conf

# encontrar a linha:
#   lightdm = NO
# e trocar para:
#   lightdm = YES

# 2) iniciar agora (ou só rebootar)
service lightdm start
# ou
reboot
```

Pronto: no próximo boot, você já deve cair na tela de login do LightDM
e, após login, diretamente no XFCE com tema/ícones/fonte padrão configurados.
