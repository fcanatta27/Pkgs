\
# Fluxo completo (v43/v44): do zero até desktop XFCE

Este documento descreve um fluxo **alto nível** usando o kit `pkg` para sair de um
ambiente live até chegar em um desktop XFCE funcional, usando:

- `pkg` / `Pkgfile`
- `pkg-pack`
- `pkg-initramfs`
- `pkg-installer`
- `pkg-doctor --desktop`

## 0. Pré-requisitos

Você precisa de:

- Um sistema live (ou chroot) com o bundle extraído (por exemplo, v44).
- A árvore de ports em `/usr/ports`.
- Conectividade de rede para baixar os sources.
- Disco alvo vazio ou com dados que podem ser sobrescritos (ex.: `/dev/sda`).

Assuma neste guia:

- Disco alvo: `/dev/sda`
- Partição root: `/dev/sda2`
- Partição /boot (opcional): `/dev/sda1`
- Locale padrão: `en_US.UTF-8`
- Keymap (console): `us`

Ajuste conforme sua realidade.

---

## 1. Construir o sistema base (chroot builder)

### 1.1. Preparar diretório de build

Crie um diretório de trabalho, por exemplo:

```sh
mkdir -p /mnt/lfs
export LFS=/mnt/lfs
```

Monte as pseudo-fs se necessário:

```sh
mount -t proc /proc "$LFS/proc"
mount -t sysfs /sys "$LFS/sys"
mount --rbind /dev "$LFS/dev"
mount --rbind /run "$LFS/run"
```

### 1.2. Construir toolchain/sistema base com `pkg`

Use os perfis em `Doc/profiles` como referência:

- `Doc/profiles/base-login.list`
- `Doc/profiles/xorg.list`
- `Doc/profiles/xfce-lightdm.list`

Uma estratégia típica:

1. Dentro do chroot/builder (ou no host, instalando direto no `$LFS` via `DESTDIR`):

   ```sh
   # construir a toolchain básica e base do sistema
   pkg b glibc-final
   pkg i glibc-final

   # construir os pacotes de base (veja Doc/perfis, Pkgfiles de base, etc.)
   # ex.: pkg i $(grep -v '^#' Doc/profiles/base-login.list | tr '\\\\' ' ')
   ```

2. Completar o stack gráfico:

   ```sh
   # Xorg + Mesa + drivers
   # ex.: pkg i $(grep -v '^#' Doc/profiles/xorg.list | tr '\\\\' ' ')

   # XFCE + LightDM
   # ex.: pkg i $(grep -v '^#' Doc/profiles/xfce-lightdm.list | tr '\\\\' ' ')
   ```

Dependendo de como você organiza, pode:

- Instalar tudo direto no root futuro (por exemplo, `/mnt/target`), ou
- Construir em um host e depois gerar um rootfs com `pkg-pack`.

O fluxo a seguir assume que você já tem um **rootfs montado em `/mnt/target`**
com todos os pacotes desktop instalados.

---

## 2. Gerar rootfs com `pkg-pack`

Supondo que:

- O sistema final (com base + Xorg + XFCE + serviços) está montado em `/mnt/target`.
- O kernel e initramfs estão em `/mnt/target/boot/vmlinuz-6.18.2` e `/mnt/target/boot/initramfs-6.18.2.img`.

### 2.1. Gerar tarball de rootfs + ISO

Exemplo:

```sh
pkg-pack \
  --root /mnt/target \
  --kernel /mnt/target/boot/vmlinuz-6.18.2 \
  --initramfs /mnt/target/boot/initramfs-6.18.2.img \
  --outdir /tmp/pkgos-out \
  --label PKGOS \
  --compress zstd
```

Isso deve gerar:

- `rootfs.tar.zst` (ou `.xz` dependendo de `--compress`) em `/tmp/pkgos-out`.
- Uma ISO bootável em `/tmp/pkgos-out/pkgos.iso` (nome pode variar conforme configuração interna do `pkg-pack`).

Verifique os arquivos:

```sh
ls -lh /tmp/pkgos-out
```

---

## 3. Gerar initramfs “live/install” com `pkg-initramfs`

Se você estiver usando o `pkg-initramfs` diretamente (por exemplo, a partir de um sistema
instalado), o fluxo típico é:

```sh
pkg-initramfs \
  --root / \
  --kver 6.18.2 \
  --out /boot/initramfs-6.18.2.img
```

O `pkg-initramfs`:

- Monta uma árvore temporária (`/tmp/pkg-initramfs-...`).
- Inclui binários essenciais (coreutils, busybox ou equivalentes, fsck, etc.).
- Inclui suporte para localizar `rootfs.tar.*` na ISO e suportar:
  - Modo live (`pkg-live`).
  - Modo install (`pkg-install`).

No fluxo com `pkg-pack`, o kernel + initramfs + payload (rootfs) já são combinados na ISO.

---

## 4. Instalação com `pkg-installer` (do live)

Boot da ISO (ou de um ambiente live que tenha tools/ports do bundle):

1. Inicie o sistema live (por exemplo, a partir da ISO gerada).
2. Confirme que `pkg-installer` está disponível:

   ```sh
   which pkg-installer
   ```

3. Descubra o disco alvo (ex.: `/dev/sda`) e partições:

   ```sh
   lsblk
   ```

4. Rode o instalador, por exemplo:

   ```sh
   pkg-installer \
     --disk /dev/sda \
     --root-part /dev/sda2 \
     --boot-part /dev/sda1 \
     --hostname pkgdesk \
     --locale en_US.UTF-8 \
     --keymap us \
     --profile desktop
   ```

O `pkg-installer` irá:

- Criar/montar as partições definidas (se for o modo auto-partition).
- Extrair o `rootfs.tar.*` para o target (`/mnt/target`).
- Chamar `configure_system()` para:
  - hostname
  - `locale.conf`, `locale.gen`
  - `vconsole.conf`, `default/keyboard`
  - `timezone`, `adjtime`
  - `nsswitch.conf`
  - `PAM` básico (`system-auth`, `login`, `sudo`, `su`, `passwd`, `lightdm`, `other`)
  - `login.defs`, `limits.d`
  - grupos padrão (`audio`, `video`, `plugdev`, `netdev`, etc.)
  - `fstab` básica
- Entrar em chroot e chamar `finalize_inside_chroot()`:
  - `locale-gen` (se disponível)
  - `pkg-initramfs` (para gerar initramfs do kernel)
  - `pkg-doctor --desktop --fix` (sanity-check e correções automáticas)
- Instalar GRUB (modo BIOS/UEFI conforme configurado no script).

Após sucesso, você poderá reiniciar com:

```sh
reboot
```

---

## 5. Primeiro boot: o que checar

No primeiro boot do sistema instalado:

### 5.1. Login

- Deve aparecer:
  - LightDM (se `lightdm = YES` em `/etc/init/services.conf`), ou
  - Login em tty (`getty-tty1..6`).
- Se estiver usando XFCE + LightDM:
  - Faça login com usuário configurado (ou root, se for o caso inicial).

### 5.2. Serviços de base

Dentro do sistema:

```sh
ps aux | egrep 'dbus-daemon|elogind|polkitd|NetworkManager|lightdm' | grep -v egrep
```

Ou use:

```sh
service dbus status
service elogind status
service polkit status
service NetworkManager status
service lightdm status
```

Verifique:

- `dbus-daemon` rodando
- `elogind` rodando
- `polkitd` rodando
- `NetworkManager` rodando
- `lightdm` (se GUI)

### 5.3. Rede (Wi-Fi/LAN)

No XFCE:

- Deve aparecer o `nm-applet` na bandeja.
- Conecte-se a uma rede Wi-Fi.

No terminal:

```sh
ip addr
ping 1.1.1.1
ping google.com
```

Se não funcionar, veja `journal`/logs do `NetworkManager`.

### 5.4. Áudio (PipeWire / WirePlumber)

No desktop XFCE:

- Rode `pavucontrol`.
- Veja se aparece um device de saída (speaker/HDMI/headphone).

No terminal:

```sh
ps aux | egrep 'pipewire|wireplumber' | grep -v egrep
```

Em setups modernos, `pipewire`/`wireplumber` são iniciados por sessão (não via init de sistema).
Se não estiverem iniciando, verifique:

- Configs em `/etc/xdg/` (autostart).
- Permissões de grupos (`audio`).

### 5.5. Energia e power (notebook)

Verifique:

```sh
service acpid status
service power-profiles status
```

Teste:

- Fechar a tampa (se a ACPI estiver configurada).
- Brilho com `brightnessctl` (se instalado).

### 5.6. Montagem de dispositivos (gvfs + udisks2)

- Plugue um pendrive.
- Abra o Thunar (XFCE).
- Verifique se ele aparece na barra lateral e monta com clique.

Se falhar:

- Verifique `udisksd`, `upowerd`:

  ```sh
  service udisksd status
  service upowerd status
  ```

---

## 6. Serviços de init e ajustes finos

Os serviços controlados por `/etc/init/services.conf` e scripts em `/etc/init.d` incluem:

- `syslogd`
- `network`
- `dbus`
- `elogind`
- `acpid`
- `power-profiles`
- `udisksd`
- `upowerd`
- `NetworkManager`
- `firewalld` (opcional)
- `bluetoothd` (opcional)
- `wpa_supplicant` (se não usar NM)
- `ntpd` (ou outro time-sync)
- `lightdm` (login gráfico)
- `rc-local`

Para habilitar/desabilitar:

```sh
# edite:
vim /etc/init/services.conf

# exemplo:
lightdm = YES
bluetoothd = YES
firewalld = YES
```

Em seguida, reinicie ou pare/inicie serviços manualmente:

```sh
service lightdm restart
service bluetoothd start
```

---

## 7. Ferramentas de reparo

Se algo estiver estranho no ambiente desktop:

- Rode:

  ```sh
  pkg-doctor --desktop
  ```

- Para tentar corrigir automaticamente:

  ```sh
  pkg-doctor --desktop --fix
  ```

Isso refaz checagens de:

- arquivos críticos em `/etc`
- grupos padrão
- serviços essenciais em `services.conf`
- scripts `init.d`
- `ldd` de binários críticos de desktop.

---

Este fluxo é a “espinha dorsal” do projeto para chegar em um desktop XFCE
funcional partindo de uma build LFS-like com o kit `pkg`.
