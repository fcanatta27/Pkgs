# Toolchain ports

Este diretório contém Pkgfiles completos da toolchain (LFS-style) para:

- binutils-pass1, gcc-pass1
- linux-headers
- glibc-pass1
- libstdcxx-pass1
- binutils-pass2, gcc-pass2
- binutils, gcc (final)

Variáveis importantes:
- LFS_TGT (default: x86_64-lfs-linux-gnu)
- TOOLCHAIN_ROOT (default: /tmp/rootfs-toolchain)

Os ports *pass1/pass2/glibc-pass1/libstdcxx-pass1* instalam dentro de TOOLCHAIN_ROOT.
Os ports finais instalam normalmente no DESTDIR (/usr, /lib, etc).

## Ordem oficial de build da toolchain (usando pkg)

Dentro do ambiente de build (host ou chroot adequado), a sequência recomendada é:

```sh
# Toolchain temporária em ${TOOLCHAIN_ROOT:-/tmp/rootfs-toolchain}
pkg i toolchain/binutils-pass1
pkg i toolchain/gcc-pass1
pkg i toolchain/linux-headers
pkg i toolchain/glibc-pass1
pkg i toolchain/libstdcxx-pass1

# Refinar toolchain dentro do TOOLCHAIN_ROOT
pkg i toolchain/binutils-pass2
pkg i toolchain/gcc-pass2

# Toolchain final no sistema
pkg i toolchain/binutils
pkg i toolchain/gcc
```

Assumindo:
- `LFS_TGT=x86_64-lfs-linux-gnu`
- `TOOLCHAIN_ROOT=/tmp/rootfs-toolchain`

A partir daí você pode seguir com os demais ports base (glibc final, coreutils, bash, etc.) normalmente.

