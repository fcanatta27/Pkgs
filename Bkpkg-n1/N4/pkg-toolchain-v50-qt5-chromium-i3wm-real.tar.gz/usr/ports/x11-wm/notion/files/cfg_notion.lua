-- Notion config exemplo (lua-like)
defbindings("WMPlex.toplevel", {
  bdoc("Exit Notion."), kpress(META.."Shift+Q", "ioncore.shutdown()"),
})
