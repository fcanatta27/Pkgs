#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando dhcpcd (cliente DHCP)..."

SRC_DIR=/sources
PKG="dhcpcd-10.0.6"
TARBALL="dhcpcd-10.0.6.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://github.com/NetworkConfiguration/dhcpcd/releases/download/v10.0.6/dhcpcd-10.0.6.tar.xz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls dhcpcd-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls dhcpcd-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado dhcpcd em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

./configure --prefix=/usr \
            --sbindir=/usr/sbin \
            --sysconfdir=/etc

make -j"$(nproc)"
make install

echo "dhcpcd instalado; o serviço 'network' usará dhcpcd quando SERVICE=dhcpcd."