#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando OpenSSH..."

SRC_DIR=/sources
PKG="openssh-9.7p1"
TARBALL="openssh-9.7p1.tar.gz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://ftp.openbsd.org/pub/OpenBSD/OpenSSH/portable/openssh-9.7p1.tar.gz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls openssh-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls openssh-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado OpenSSH em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

install -dv /var/lib/sshd
chown root:root /var/lib/sshd
chmod 700 /var/lib/sshd

./configure --prefix=/usr \
            --sysconfdir=/etc/ssh \
            --with-privsep-path=/var/lib/sshd \
            --with-md5-passwords \
            --with-pam=yes

make -j"$(nproc)"
make install

install -v -m700 -d /etc/ssh
if [[ ! -f /etc/ssh/sshd_config ]]; then
  cat > /etc/ssh/sshd_config << 'EOF'
Port 22
Protocol 2
HostKey /etc/ssh/ssh_host_rsa_key
HostKey /etc/ssh/ssh_host_ed25519_key
UsePrivilegeSeparation yes
KeyRegenerationInterval 1h
ServerKeyBits 2048
SyslogFacility AUTH
LogLevel INFO
LoginGraceTime 2m
PermitRootLogin prohibit-password
StrictModes yes
MaxAuthTries 3
MaxSessions 10
PubkeyAuthentication yes
PasswordAuthentication yes
ChallengeResponseAuthentication no
UsePAM yes
X11Forwarding no
PrintMotd yes
Subsystem sftp /usr/lib/ssh/sftp-server
EOF
fi

echo "==> Gerando chaves de host SSH (se ainda não existirem)..."
if [[ ! -f /etc/ssh/ssh_host_rsa_key ]]; then
  ssh-keygen -t rsa -b 4096 -f /etc/ssh/ssh_host_rsa_key -N ''
fi
if [[ ! -f /etc/ssh/ssh_host_ed25519_key ]]; then
  ssh-keygen -t ed25519 -f /etc/ssh/ssh_host_ed25519_key -N ''
fi

echo "OpenSSH instalado. Crie um serviço SysV opcional para sshd em /etc/rc.d/init.d se desejar."