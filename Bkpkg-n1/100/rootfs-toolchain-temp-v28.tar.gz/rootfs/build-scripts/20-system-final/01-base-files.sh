#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Criando diretórios básicos do sistema..."

install -dv /{boot,home,mnt,opt,srv}
install -dv /{media,usr/local}
install -dv /var/{log,mail,spool,lib/misc,local}
install -dv /var/{opt,cache,lib,run}
install -dv /usr/{bin,include,lib,sbin,src,local}
install -dv /usr/local/{bin,include,lib,sbin,src}
install -dv /usr/share/{color,dict,doc,info,locale,man}
install -dv /usr/share/{misc,terminfo,zoneinfo}
install -dv /usr/share/man/man{1..8}

# /run como symlink para /var/run, se ainda não for
if [[ ! -L /run ]]; then
  rm -rf /run
  install -dv /var/run
  ln -sv /var/run /run
fi

echo "==> Criando arquivos /etc/passwd e /etc/group mínimos..."

cat > /etc/passwd << 'EOF'
root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/dev/null:/usr/bin/false
daemon:x:6:6:Daemon User:/dev/null:/usr/bin/false
messagebus:x:18:18:D-Bus Message Daemon User:/run/dbus:/usr/bin/false
nobody:x:99:99:Unprivileged User:/dev/null:/usr/bin/false
EOF

cat > /etc/group << 'EOF'
root:x:0:
bin:x:1:daemon
sys:x:2:
kmem:x:3:
tape:x:4:
tty:x:5:
daemon:x:6:
lp:x:7:
disk:x:8:
audio:x:10:
video:x:11:
utmp:x:13:
usb:x:14:
cdrom:x:15:
adm:x:16:
messagebus:x:18:
systemd-journal:x:23:
input:x:24:
mail:x:34:
kvm:x:61:
wheel:x:97:
nogroup:x:99:
users:x:999:
EOF

echo "==> Criando diretório /root e configurando permissões..."
install -dv -m 0700 /root

echo "==> Arquivos de log básicos (wtmp, btmp)..."
touch /var/log/{wtmp,btmp}
chmod 664 /var/log/wtmp
chmod 600 /var/log/btmp

echo "==> Criando /etc/issue, /etc/motd, /etc/shells, /etc/os-release..."

cat > /etc/issue << 'EOF'
LFS 12.1 (construído com scripts automatizados)
Kernel \r on an \m (\l)
EOF

cat > /etc/motd << 'EOF'
Bem-vindo ao seu sistema LFS.
EOF

cat > /etc/shells << 'EOF'
/bin/sh
/bin/bash
EOF

cat > /etc/os-release << 'EOF'
NAME="LFS"
PRETTY_NAME="Linux From Scratch"
ID=lfs
VERSION_ID="12.1"
HOME_URL="https://www.linuxfromscratch.org/"
SUPPORT_URL="https://www.linuxfromscratch.org/support.html"
BUG_REPORT_URL="https://www.linuxfromscratch.org/contact.html"
EOF

echo "==> Criando /etc/profile simples..."

cat > /etc/profile << 'EOF'
# /etc/profile - ambiente de login global

export LANG=${LANG:-pt_BR.UTF-8}
export LC_COLLATE=${LC_COLLATE:-C}
umask 022

# Caminho padrão
PATH=/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/local/sbin
export PATH

# Prompt simples
if [ "$PS1" ]; then
  PS1='\u@\h:\w\$ '
fi

# Histórico mais amigável
HISTSIZE=1000
HISTFILESIZE=2000
export HISTSIZE HISTFILESIZE
EOF

echo "Base de arquivos de sistema criada e configurada."
