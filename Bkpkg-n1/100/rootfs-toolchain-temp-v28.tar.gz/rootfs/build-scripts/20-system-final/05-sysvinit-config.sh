#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Configurando SysVinit (/etc/inittab, rc.d)..."

cat > /etc/inittab << 'EOF'
# /etc/inittab para LFS com SysVinit

id:3:initdefault:

si::sysinit:/etc/rc.d/init.d/rc S

l0:0:wait:/etc/rc.d/init.d/rc 0
l1:S:wait:/etc/rc.d/init.d/rc 1
l2:2:wait:/etc/rc.d/init.d/rc 2
l3:3:wait:/etc/rc.d/init.d/rc 3
l4:4:wait:/etc/rc.d/init.d/rc 4
l5:5:wait:/etc/rc.d/init.d/rc 5
l6:6:wait:/etc/rc.d/init.d/rc 6

# Consoles virtuais (ajuste se quiser menos/more TTYs)
1:2345:respawn:/sbin/agetty --noclear tty1 9600
2:2345:respawn:/sbin/agetty tty2 9600
3:2345:respawn:/sbin/agetty tty3 9600
4:2345:respawn:/sbin/agetty tty4 9600

# Console serial opcional (comente se não usar)
#S0:12345:respawn:/sbin/agetty -L 115200 ttyS0 vt100

# Reboot via Ctrl-Alt-Del
ca:12345:ctrlaltdel:/sbin/shutdown -t1 -a -r now

# Tratamento de falha de energia (apenas se tiver suporte)
pf::powerfail:/sbin/shutdown -f -h +2 "Power Failure; System Shutting Down"
pr:12345:powerokwait:/sbin/logger -t init "Power Restored; System Restarting"
EOF

echo "==> Criando estrutura básica /etc/rc.d..."

for dir in rc{0,1,2,3,4,5,6}.d; do
  install -dv /etc/rc.d/"$dir"
done

install -dv /etc/rc.d/init.d

echo "==> Criando script rc principal..."

cat > /etc/rc.d/init.d/rc << 'EOF'
#!/bin/sh
# /etc/rc.d/init.d/rc - controlador de runlevel simples

RUNLEVEL="$1"

if [ -z "$RUNLEVEL" ]; then
  echo "Uso: $0 <runlevel>"
  exit 1
fi

for S in /etc/rc.d/rc"$RUNLEVEL".d/S*; do
  [ -x "$S" ] || continue
  "$S" start
done

for K in /etc/rc.d/rc"$RUNLEVEL".d/K*; do
  [ -x "$K" ] || continue
  "$K" stop
done
EOF

chmod +x /etc/rc.d/init.d/rc

echo "SysVinit configurado com /etc/inittab e estrutura rc.d básica."
