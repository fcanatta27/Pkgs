#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Configuração básica de rede (hostname, hosts, ifconfig)..."

read -rp "Informe o hostname desejado (ex: lfs): " HOSTNAME
HOSTNAME=${HOSTNAME:-lfs}

echo "$HOSTNAME" > /etc/hostname
echo "Arquivo /etc/hostname criado: $HOSTNAME"

cat > /etc/hosts << EOF
127.0.0.1   localhost
127.0.1.1   ${HOSTNAME}.localdomain ${HOSTNAME}

# IPv6
::1         localhost ip6-localhost ip6-loopback
ff02::1     ip6-allnodes
ff02::2     ip6-allrouters
EOF

echo "Arquivo /etc/hosts criado."

echo
echo "Configuração de interface de rede (SysVinit estilo LFS)"
echo "1) DHCP em eth0"
echo "2) IP estático em eth0"
read -rp "Escolha uma opção [1-2]: " NET_OPT
NET_OPT=${NET_OPT:-1}

install -dv /etc/sysconfig

IFCFG=/etc/sysconfig/ifconfig.eth0

case "$NET_OPT" in
  1)
    cat > "$IFCFG" << 'EOF'
ONBOOT=yes
IFACE=eth0
SERVICE=dhcpcd
DHCP_START=
DHCP_STOP=
EOF
    echo "Configuração de rede DHCP criada em $IFCFG."
    ;;
  2)
    read -rp "Endereço IP (ex: 192.168.1.10): " IPADDR
    read -rp "Máscara de rede (ex: 255.255.255.0): " NETMASK
    read -rp "Gateway (ex: 192.168.1.1): " GATEWAY
    IPADDR=${IPADDR:-192.168.1.10}
    NETMASK=${NETMASK:-255.255.255.0}
    GATEWAY=${GATEWAY:-192.168.1.1}

    cat > "$IFCFG" << EOF
ONBOOT=yes
IFACE=eth0
SERVICE=ipv4-static
IP=${IPADDR}
GATEWAY=${GATEWAY}
PREFIX=$(python3 - << 'PY'
import ipaddress, sys
mask = sys.argv[1]
print(ipaddress.IPv4Network("0.0.0.0/"+mask).prefixlen)
PY
${NETMASK})
BROADCAST=
EOF
    echo "Configuração de rede estática criada em $IFCFG."
    ;;
  *)
    echo "Opção inválida, deixando rede não configurada."
    ;;
esac

echo "Configuração básica de rede concluída."
