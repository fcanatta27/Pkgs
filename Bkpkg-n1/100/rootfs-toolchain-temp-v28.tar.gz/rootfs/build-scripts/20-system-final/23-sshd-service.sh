#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Criando serviço SysV para sshd..."

RC_DIR=/etc/rc.d
INITD=${RC_DIR}/init.d

if [[ ! -d "$INITD" ]]; then
  echo "ERRO: ${INITD} não existe. Execute 05-sysvinit-config.sh antes."
  exit 1
fi

# Script de serviço sshd
cat > "${INITD}/sshd" << 'EOF'
#!/bin/sh
# /etc/rc.d/init.d/sshd - inicia/parar servidor OpenSSH
### BEGIN INIT INFO
# Provides:          sshd
# Required-Start:    $local_fs $network $syslog
# Required-Stop:     $local_fs $network $syslog
# Default-Start:     3 4 5
# Default-Stop:      0 1 2 6
# Short-Description: OpenSSH server daemon
### END INIT INFO

DAEMON=/usr/sbin/sshd
PIDFILE=/var/run/sshd.pid
CONFIG=/etc/ssh/sshd_config

case "$1" in
  start)
    echo "Iniciando sshd..."
    if [ ! -x "$DAEMON" ]; then
      echo "  !! $DAEMON não encontrado ou não executável."
      exit 1
    fi
    if [ ! -f "$CONFIG" ]; then
      echo "  !! Arquivo de configuração $CONFIG não encontrado."
      exit 1
    fi
    "$DAEMON" -f "$CONFIG"
    ;;
  stop)
    echo "Parando sshd..."
    if [ -f "$PIDFILE" ]; then
      kill "$(cat "$PIDFILE")" 2>/dev/null || true
      rm -f "$PIDFILE"
    fi
    # fallback
    killall sshd 2>/dev/null || true
    ;;
  restart|reload)
    "$0" stop
    "$0" start
    ;;
  status)
    if pgrep -x sshd >/dev/null 2>&1; then
      echo "sshd está em execução."
    else
      echo "sshd NÃO está em execução."
    fi
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|status}"
    exit 1
    ;;
esac

exit 0
EOF

chmod +x "${INITD}/sshd"

# Helper para links
create_links() {
  local base="$1"  # nome do serviço
  local rc="$2"    # runlevel
  local order="$3" # número
  local action="$4"
  local dir="${RC_DIR}/rc${rc}.d"
  mkdir -pv "$dir"
  ln -sfv "../init.d/${base}" "${dir}/${action}${order}${base}"
}

# Ativar sshd em multiusuário
create_links sshd 3 70 S
create_links sshd 4 70 S
create_links sshd 5 70 S
create_links sshd 0 30 K
create_links sshd 1 30 K
create_links sshd 2 30 K
create_links sshd 6 30 K

echo "Serviço SysV sshd criado e vinculado aos runlevels 3,4,5."
