#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"

echo "==> Construindo e instalando iptables..."

SRC_DIR=/sources
PKG="iptables-1.8.10"
TARBALL="iptables-1.8.10.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://www.netfilter.org/projects/iptables/files/iptables-1.8.10.tar.xz"

cd "$PKG"

./configure --prefix=/usr \
            --sbindir=/usr/sbin \
            --disable-nftables \
            --enable-libipq

make -j"$(nproc)"
make install

echo "iptables instalado."
