#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando procps-ng (ps, top, free, etc.)..."

SRC_DIR=/sources
PKG="procps-ng-4.0.4"
TARBALL="procps-ng-4.0.4.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://sourceforge.net/projects/procps-ng/files/Production/procps-ng-4.0.4.tar.xz/download"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls procps-ng-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls procps-ng-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado procps-ng em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

./configure --prefix=/usr \
            --docdir=/usr/share/doc/"$PKG" \
            --enable-watch8bit \
            --disable-modern-top \
            --disable-static

make -j"$(nproc)"
make install

echo "procps-ng instalado (ps, top, free, etc.)."