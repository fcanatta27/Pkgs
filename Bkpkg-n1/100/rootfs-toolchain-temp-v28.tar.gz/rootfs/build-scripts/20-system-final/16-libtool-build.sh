#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando libtool (atualizado)..."

SRC_DIR=/sources
PKG="libtool-2.4.7"
TARBALL="libtool-2.4.7.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://ftp.gnu.org/gnu/libtool/libtool-2.4.7.tar.xz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls libtool-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls libtool-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado libtool em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

./configure --prefix=/usr --disable-static
make -j"$(nproc)"
make install

# Remover biblioteca estática, se ainda existir
rm -fv /usr/lib/libltdl.a 2>/dev/null || true

echo "libtool instalado/atualizado."