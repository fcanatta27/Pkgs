#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Limpeza final do sistema LFS..."

echo "Removendo /tools (toolchain temporária)..."
if [[ -d /tools ]]; then
  rm -rf /tools
  echo "  /tools removido."
else
  echo "  /tools já não existe, nada a fazer."
fi

echo "Removendo diretórios temporários de build se existirem..."
rm -rf /tmp/* 2>/dev/null || true

echo "Opcional: limpar /sources (tarballs e fontes usadas na construção)."
if [[ -d /sources ]]; then
  ls -1 /sources || true
  echo
  read -rp "Deseja remover TODO o conteúdo de /sources? (digite 'SIM' para confirmar): " CONF
  if [[ "$CONF" == "SIM" ]]; then
    rm -rf /sources/*
    echo "/sources esvaziado."
  else
    echo "Mantendo /sources conforme solicitado."
  fi
fi

echo "Removendo diretórios de estado/log de build (se existirem)..."
rm -rf /var/lib/lfs-build-state-chroot 2>/dev/null || true
rm -rf /var/log/lfs-build-logs-chroot  2>/dev/null || true

echo
echo "Você ainda pode, manualmente, remover:"
echo "  - bibliotecas *.a desnecessárias em /usr/lib"
echo "  - documentação extra em /usr/share/doc"
echo "  - caches temporários específicos de aplicações"
echo
echo "Limpeza final concluída."
