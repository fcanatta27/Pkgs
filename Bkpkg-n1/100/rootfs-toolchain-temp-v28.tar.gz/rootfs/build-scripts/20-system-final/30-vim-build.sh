#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando Vim..."

SRC_DIR=/sources
PKG="vim-9.1.0000"
TARBALL="vim-9.1.0000.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://github.com/vim/vim/archive/refs/tags/v9.1.0000.tar.gz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls vim-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls vim-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado Vim em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

# Vim gosta de compilar a partir do diretório 'src'
cd src

./configure --prefix=/usr \
            --with-features=huge \
            --enable-multibyte \
            --enable-gui=no \
            --without-x \
            --enable-cscope

make -j"$(nproc)"
make install

# Instalar runtime e links usuais
cd ..
# Alguns tarballs já instalam runtime, mas garantimos docs básicos.
install -v -m755 -d /usr/share/doc/vim
cp -vR runtime/doc /usr/share/doc/vim || true

# Links convenientes
ln -sfv vim /usr/bin/vi
ln -sfv vim /usr/bin/vim.basic || true

# vimrc global
if [[ ! -f /etc/vimrc ]]; then
  cat > /etc/vimrc << 'EOF'
\" /etc/vimrc - configuração global simples

set nocompatible
set backspace=indent,eol,start
set ruler
set showcmd
set hlsearch
syntax on
filetype plugin indent on

\" Usar UTF-8 por padrão
set encoding=utf-8

\" Número de linhas de histórico
set history=1000

\" Indentação
set expandtab
set shiftwidth=2
set tabstop=2

EOF
fi

echo "Vim instalado. Use 'vim' ou 'vi'."