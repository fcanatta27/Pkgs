#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Instalando bundle de certificados CA (ca-certificates)..."

CERT_DIR=/etc/ssl/certs
BUNDLE="${CERT_DIR}/ca-certificates.crt"

mkdir -pv "$CERT_DIR"

# Se já existir, não sobrescrever automaticamente
if [[ -f "$BUNDLE" ]]; then
  echo "Bundle CA já existe em $BUNDLE. Uma cópia de backup será criada."
  cp -v "$BUNDLE" "${BUNDLE}.bak.$(date +%Y%m%d%H%M%S)"
fi

# Tentar usar um bundle pré-baixado em /sources, se existir
SRC_BUNDLE=/sources/cacert.pem

if [[ -f "$SRC_BUNDLE" ]]; then
  cp -v "$SRC_BUNDLE" "$BUNDLE"
  echo "Bundle CA instalado a partir de $SRC_BUNDLE."
else
  echo "Nenhum bundle cacert.pem encontrado em /sources."
  echo "Tentando baixar de https://curl.se/ca/cacert.pem usando curl ou wget..."
  if command -v curl >/dev/null 2>&1; then
    curl -L https://curl.se/ca/cacert.pem -o "$BUNDLE"
  elif command -v wget >/dev/null 2>&1; then
    wget https://curl.se/ca/cacert.pem -O "$BUNDLE"
  else
    echo "ERRO: nem curl nem wget disponíveis para baixar o bundle CA."
    exit 1
  fi
fi

chmod 644 "$BUNDLE"

echo "Bundle CA instalado em $BUNDLE."
echo "Programas como curl/wget/OpenSSL usarão este arquivo como raiz de confiança."
