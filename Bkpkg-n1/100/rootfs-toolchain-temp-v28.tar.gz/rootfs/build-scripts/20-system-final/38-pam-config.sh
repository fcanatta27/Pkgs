#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Configurando PAM (/etc/pam.d)..."

install -vdm755 /etc/pam.d

# pam.d/system-auth - usado como base por outros serviços
cat > /etc/pam.d/system-auth << 'EOF'
# /etc/pam.d/system-auth - pilha base simples de autenticação
auth      required   pam_env.so
auth      sufficient pam_unix.so nullok try_first_pass
auth      required   pam_deny.so

account   required   pam_unix.so

password  sufficient pam_unix.so nullok sha512 shadow try_first_pass
password  required   pam_deny.so

session   required   pam_limits.so
session   required   pam_unix.so
EOF

# pam.d/login
cat > /etc/pam.d/login << 'EOF'
# /etc/pam.d/login
auth      required   pam_securetty.so
auth      requisite  pam_nologin.so
auth      include    system-auth

account   include    system-auth

password  include    system-auth

session   optional   pam_motd.so
session   required   pam_limits.so
session   include    system-auth
EOF

# pam.d/passwd
cat > /etc/pam.d/passwd << 'EOF'
# /etc/pam.d/passwd
password  include    system-auth
EOF

# pam.d/su
cat > /etc/pam.d/su << 'EOF'
# /etc/pam.d/su
auth      sufficient pam_rootok.so
auth      required   pam_wheel.so use_uid
auth      include    system-auth

account   include    system-auth

password  include    system-auth

session   include    system-auth
EOF

# pam.d/sshd
cat > /etc/pam.d/sshd << 'EOF'
# /etc/pam.d/sshd
auth      required   pam_nologin.so
auth      include    system-auth

account   include    system-auth

password  include    system-auth

session   optional   pam_motd.so
session   include    system-auth
EOF

echo "Configurações básicas de PAM criadas em /etc/pam.d."
