#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando sysklogd (syslogd/klogd)..."

SRC_DIR=/sources
PKG="sysklogd-1.5.1"
TARBALL="sysklogd-1.5.1.tar.gz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://www.infodrom.org/projects/sysklogd/download/sysklogd-1.5.1.tar.gz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls sysklogd-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls sysklogd-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado sysklogd em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

sed -i '/Error loading kernel symbols/{n;n;d}' klogd/klogd.c || true
sed -i 's/union wait/int/' src/syslogd.c || true

make -j"$(nproc)"
make BINDIR=/sbin install

echo "Criando /etc/syslog.conf padrão..."

cat > /etc/syslog.conf << 'EOF'
# /etc/syslog.conf - configuração simples de syslogd

*.err;kern.debug;auth.notice   /var/log/messages
daemon,auth.notice             /var/log/daemons
*.=debug                       /var/log/debug
mail.*                         -/var/log/mail
EOF

echo "sysklogd instalado e /etc/syslog.conf criado."