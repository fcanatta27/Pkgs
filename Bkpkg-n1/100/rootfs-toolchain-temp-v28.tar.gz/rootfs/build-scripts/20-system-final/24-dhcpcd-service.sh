#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Criando serviço SysV para dhcpcd (cliente DHCP global)..."

RC_DIR=/etc/rc.d
INITD=${RC_DIR}/init.d

if [[ ! -d "$INITD" ]]; then
  echo "ERRO: ${INITD} não existe. Execute 05-sysvinit-config.sh antes."
  exit 1
fi

# Script de serviço dhcpcd
cat > "${INITD}/dhcpcd" << 'EOF'
#!/bin/sh
# /etc/rc.d/init.d/dhcpcd - cliente DHCP global
### BEGIN INIT INFO
# Provides:          dhcpcd
# Required-Start:    $network
# Required-Stop:     $network
# Default-Start:     3 4 5
# Default-Stop:      0 1 2 6
# Short-Description: dhcpcd daemon
### END INIT INFO

DAEMON=/usr/sbin/dhcpcd

case "$1" in
  start)
    echo "Iniciando dhcpcd (global)..."
    if [ ! -x "$DAEMON" ]; then
      echo "  !! $DAEMON não encontrado."
      exit 1
    fi
    "$DAEMON"
    ;;
  stop)
    echo "Parando dhcpcd..."
    if command -v dhcpcd >/dev/null 2>&1; then
      dhcpcd -x >/dev/null 2>&1 || true
    fi
    ;;
  restart|reload)
    "$0" stop
    "$0" start
    ;;
  status)
    pgrep -x dhcpcd >/dev/null 2>&1 && echo "dhcpcd está em execução." || echo "dhcpcd NÃO está em execução."
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|status}"
    exit 1
    ;;
esac

exit 0
EOF

chmod +x "${INITD}/dhcpcd"

# Não ativar por padrão para evitar conflito com o serviço 'network' usando SERVICE=dhcpcd
# O administrador pode ativar manualmente se desejar:
echo "Serviço dhcpcd criado. NÃO foi vinculado automaticamente aos runlevels para evitar conflitos."
echo "Se quiser habilitar, crie links em rc3.d/rc5.d, por exemplo:"
echo "  ln -s ../init.d/dhcpcd /etc/rc.d/rc3.d/S50dhcpcd"
