#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando e2fsprogs (ext2/3/4 fs tools)..."

SRC_DIR=/sources
PKG="e2fsprogs-1.47.0"
TARBALL="e2fsprogs-1.47.0.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://www.kernel.org/pub/linux/kernel/people/tytso/e2fsprogs/v1.47.0/e2fsprogs-1.47.0.tar.xz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls e2fsprogs-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls e2fsprogs-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado e2fsprogs em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

mkdir -pv build
cd build

../configure --prefix=/usr \
             --sysconfdir=/etc \
             --enable-elf-shlibs \
             --disable-libblkid \
             --disable-libuuid \
             --disable-fsck

make -j"$(nproc)"
make install

make -C ../contrib/lnstat install || true

echo "e2fsprogs instalado (e2fsck, tune2fs, etc.)."