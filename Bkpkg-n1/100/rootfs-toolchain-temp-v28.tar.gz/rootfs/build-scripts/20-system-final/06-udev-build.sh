#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Instalando eudev (udev standalone)..."

SRC_DIR=/sources
PKG="eudev-3.2.14"
TARBALL="eudev-3.2.14.tar.gz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://github.com/eudev-project/eudev/releases/download/v3.2.14/eudev-3.2.14.tar.gz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls eudev-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls eudev-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado eudev em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

mkdir -pv build
cd build

../configure \
  --prefix=/usr \
  --sysconfdir=/etc \
  --libexecdir=/lib \
  --with-rootprefix= \
  --with-rootlibdir=/lib \
  --enable-manpages \
  --disable-static

make -j"$(nproc)"
make install

mkdir -pv /lib/udev/rules.d /etc/udev/rules.d

echo "eudev instalado. Regras podem ser colocadas em /etc/udev/rules.d."