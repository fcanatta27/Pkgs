#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root."
  exit 1
fi

echo "==========================================="
echo "  LFS Post-Install Checklist & Fix Tool"
echo "==========================================="

ask_yes_no() {
  local prompt="$1"
  local default="${2:-N}"
  local reply

  case "$default" in
    [sS]) prompt="${prompt} [S/n]: " ;;
    [nN]) prompt="${prompt} [s/N]: " ;;
    *)    prompt="${prompt} [s/n]: " ;;
  esac

  read -rp "$prompt" reply || reply="$default"

  if [[ -z "$reply" ]]; then
    reply="$default"
  fi

  case "$reply" in
    [sS] | [sS][iI][mM]) return 0 ;;
    *) return 1 ;;
  esac
}

echo
echo "==> Verificando usuário(s) não-root no grupo wheel..."

wheel_entry="$(getent group wheel || true)"
if [[ -z "$wheel_entry" ]]; then
  echo "  !! Grupo 'wheel' não existe."
  if ask_yes_no "  -> Criar grupo 'wheel' agora?" "S"; then
    groupadd wheel
    echo "  -> Grupo 'wheel' criado."
    wheel_entry="$(getent group wheel || true)"
  fi
fi

non_root_wheel=""
if [[ -n "$wheel_entry" ]]; then
  IFS=':' read -r name x gid members <<< "$wheel_entry"
  IFS=',' read -ra arr <<< "${members:-}"
  for u in "${arr[@]}"; do
    [[ -z "$u" ]] && continue
    [[ "$u" == "root" ]] && continue
    non_root_wheel="$u ${non_root_wheel}"
  done
fi

if [[ -n "$non_root_wheel" ]]; then
  echo "  OK: usuários não-root no grupo wheel: $non_root_wheel"
else
  echo "  !! Nenhum usuário não-root no grupo wheel."
  if ask_yes_no "  -> Deseja criar um novo usuário no grupo wheel?" "S"; then
    read -rp "     Nome do novo usuário (ex: user): " NEWUSER
    NEWUSER=${NEWUSER:-user}
    read -rp "     Nome completo (GECOS): " FULLNAME
    FULLNAME=${FULLNAME:-Usuario LFS}
    if id "$NEWUSER" >/dev/null 2>&1; then
      echo "     Usuário $NEWUSER já existe; adicionando ao grupo wheel..."
      usermod -aG wheel "$NEWUSER"
    else
      echo "     Criando usuário $NEWUSER e adicionando ao grupo wheel..."
      useradd -m -c "$FULLNAME" -s /bin/bash -G wheel "$NEWUSER"
      echo "     Defina uma senha para $NEWUSER:"
      passwd "$NEWUSER"
    fi
    echo "  -> Usuário $NEWUSER está no grupo wheel."
  else
    echo "  (Você pode depois usar: usermod -aG wheel <usuario>)"
  fi
fi

echo
echo "==> Verificando timezone do sistema..."

ZONEINFO_DIR=/usr/share/zoneinfo
CURRENT_TZ=""
if [[ -f /etc/timezone ]]; then
  CURRENT_TZ="$(cat /etc/timezone 2>/dev/null || true)"
fi

if [[ -e /etc/localtime ]]; then
  echo "  OK: /etc/localtime existe."
else
  echo "  !! /etc/localtime não existe."
fi

if [[ -n "$CURRENT_TZ" ]]; then
  echo "  Timezone atual em /etc/timezone: $CURRENT_TZ"
else
  echo "  !! /etc/timezone não definido."
fi

if [[ ! -e /etc/localtime || -z "$CURRENT_TZ" ]]; then
  if ask_yes_no "  -> Deseja configurar/ajustar a timezone agora?" "S"; then
    read -rp "     Informe a timezone (ex: America/Sao_Paulo): " TZ
    TZ=${TZ:-America/Sao_Paulo}
    if [[ -f "${ZONEINFO_DIR}/${TZ}" ]]; then
      ln -sfv "${ZONEINFO_DIR}/${TZ}" /etc/localtime
      echo "$TZ" > /etc/timezone
      echo "  -> Timezone configurada para $TZ."
    else
      echo "  !! ${ZONEINFO_DIR}/${TZ} não encontrado. Verifique tzdata."
    fi
  fi
fi

echo
echo "==> Verificando chronyd (NTP)..."

if pgrep -x chronyd >/dev/null 2>&1; then
  echo "  OK: chronyd está em execução."
else
  echo "  !! chronyd NÃO está em execução."
  if [[ -x /etc/rc.d/init.d/chrony ]]; then
    if ask_yes_no "  -> Tentar iniciar chronyd agora?" "S"; then
      /etc/rc.d/init.d/chrony start || echo "  !! Falha ao iniciar chronyd."
      if pgrep -x chronyd >/dev/null 2>&1; then
        echo "  -> chronyd iniciado com sucesso."
      fi
    fi
  else
    echo "  !! Serviço /etc/rc.d/init.d/chrony não encontrado."
  fi
fi

echo
echo "==> Verificando firewall (iptables) e regras..."

FWDIR=/etc/firewall
RULES_V4="${FWDIR}/rules.v4"
RULES_V6="${FWDIR}/rules.v6"

if [[ ! -d "$FWDIR" ]]; then
  echo "  !! Diretório $FWDIR não existe."
  echo "     Execute o script 43-firewall-service.sh para criar a estrutura."
else
  echo "  Diretório de firewall: $FWDIR"

  has_v4_rules=0
  if [[ -f "$RULES_V4" ]]; then
    if grep -Eq '^[[:space:]]*[^#[:space:]]' "$RULES_V4"; then
      echo "  OK: rules.v4 contém regras."
      has_v4_rules=1
    else
      echo "  !! rules.v4 existe mas está vazio ou só com comentários."
    fi
  else
    echo "  !! rules.v4 não existe."
  fi

  has_v6_rules=0
  if [[ -f "$RULES_V6" ]]; then
    if grep -Eq '^[[:space:]]*[^#[:space:]]' "$RULES_V6"; then
      echo "  OK: rules.v6 contém regras."
      has_v6_rules=1
    else
      echo "  !! rules.v6 existe mas está vazio ou só com comentários."
    fi
  else
    echo "  !! rules.v6 não existe."
  fi

  if [[ "$has_v4_rules" -eq 0 ]]; then
    if ask_yes_no "  -> Criar um conjunto padrão de regras IPv4 seguras (drop por padrão + SSH)?" "S"; then
      cat > "$RULES_V4" << 'EOF'
*filter
:INPUT DROP [0:0]
:FORWARD DROP [0:0]
:OUTPUT ACCEPT [0:0]

# Permitir loopback
-A INPUT -i lo -j ACCEPT

# Permitir conexões já estabelecidas
-A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# SSH (porta 22)
-A INPUT -p tcp --dport 22 -m state --state NEW -j ACCEPT

COMMIT
EOF
      echo "  -> rules.v4 padrão criado."
    fi
  fi

  if [[ "$has_v6_rules" -eq 0 ]]; then
    if ask_yes_no "  -> Criar um conjunto padrão de regras IPv6 seguras?" "S"; then
      cat > "$RULES_V6" << 'EOF'
*filter
:INPUT DROP [0:0]
:FORWARD DROP [0:0]
:OUTPUT ACCEPT [0:0]

# Permitir loopback
-A INPUT -i lo -j ACCEPT

# Permitir conexões já estabelecidas
-A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# SSH (porta 22)
-A INPUT -p tcp --dport 22 -m state --state NEW -j ACCEPT

COMMIT
EOF
      echo "  -> rules.v6 padrão criado."
    fi
  fi

  if [[ -x /etc/rc.d/init.d/firewall ]]; then
    if ask_yes_no "  -> Aplicar regras chamando 'service firewall restart' agora?" "S"; then
      /etc/rc.d/init.d/firewall restart || echo "  !! Falha ao aplicar regras via firewall."
    fi
  else
    echo "  !! Serviço /etc/rc.d/init.d/firewall não encontrado."
  fi
fi

echo
echo "==> Checklist concluído."
echo "Revise as mensagens acima para garantir que tudo está conforme o esperado."
