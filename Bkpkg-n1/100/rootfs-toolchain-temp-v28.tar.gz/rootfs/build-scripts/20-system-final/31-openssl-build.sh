#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando OpenSSL..."

SRC_DIR=/sources
PKG="openssl-3.2.1"
TARBALL="openssl-3.2.1.tar.gz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://www.openssl.org/source/openssl-3.2.1.tar.gz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls openssl-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls openssl-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado OpenSSL em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

./Configure --prefix=/usr \
            --openssldir=/etc/ssl \
            --libdir=lib \
            shared \
            zlib-dynamic \
            linux-$(uname -m)

make -j"$(nproc)"
make install_sw

# Documentação pode ser pesada, mas deixamos o padrão.

echo "OpenSSL instalado. Bibliotecas em /usr/lib e configs em /etc/ssl."