#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"

echo "==> Construindo e instalando Linux-PAM..."

SRC_DIR=/sources
PKG="Linux-PAM-1.5.3"
TARBALL="Linux-PAM-1.5.3.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://github.com/linux-pam/linux-pam/releases/download/v1.5.3/Linux-PAM-1.5.3.tar.xz"

cd "$PKG"

./configure --prefix=/usr \
            --sysconfdir=/etc \
            --libdir=/usr/lib \
            --disable-regenerate-docu

make -j"$(nproc)"
make install

install -vdm755 /etc/pam.d

echo "Linux-PAM instalado."
