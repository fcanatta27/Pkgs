#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando shadow (ferramentas de contas de usuário)..."

SRC_DIR=/sources
PKG="shadow-4.14.2"
TARBALL="shadow-4.14.2.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://github.com/shadow-maint/shadow/releases/download/4.14.2/shadow-4.14.2.tar.xz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls shadow-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls shadow-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado shadow em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

# Desabilitar suid para programas sensíveis, se apropriado
sed -i 's/groups$(EXEEXT) //' src/Makefile.in || true
find man -name Makefile.in -exec sed -i 's/groups\.1 / /'   {} \; || true

./configure --prefix=/usr \
            --sysconfdir=/etc \
            --with-group-name-max-length=32

make -j"$(nproc)"
make install

echo "==> Ajustando /etc/login.defs padrão..."

cat > /etc/login.defs << 'EOF'
MAIL_DIR        /var/spool/mail
PASS_MAX_DAYS   99999
PASS_MIN_DAYS   0
PASS_WARN_AGE   7
UID_MIN         1000
UID_MAX         60000
GID_MIN         1000
GID_MAX         60000
CREATE_HOME     yes
ENCRYPT_METHOD  SHA512
UMASK           022
USERGROUPS_ENAB yes
EOF

echo "==> Convertendo senhas para /etc/shadow..."
pwconv
grpconv

echo "shadow instalado e /etc/login.defs configurado."