#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Criando serviços SysV padrão (network, syslog, cron, halt/local)..."

RC_DIR=/etc/rc.d
INITD=${RC_DIR}/init.d

if [[ ! -d "$INITD" ]]; then
  echo "ERRO: ${INITD} não existe. Execute 05-sysvinit-config.sh antes."
  exit 1
fi

# --- Função helper para criar links em runlevels ---
create_links() {
  local base="$1"  # nome do serviço, ex: network
  local rc="$2"    # runlevel, ex: 3
  local order="$3" # número, ex: 10
  local action="$4" # S ou K

  local dir="${RC_DIR}/rc${rc}.d"
  mkdir -pv "$dir"
  ln -sfv "../init.d/${base}" "${dir}/${action}${order}${base}"
}

# ====================== network ======================
cat > "${INITD}/network" << 'EOF'
#!/bin/sh
# /etc/rc.d/init.d/network - Bring up/down network interfaces simples
### BEGIN INIT INFO
# Provides:          network
# Required-Start:    $local_fs
# Required-Stop:     $local_fs
# Default-Start:     3 4 5
# Default-Stop:      0 1 2 6
# Short-Description: Network initialization
### END INIT INFO

. /etc/profile 2>/dev/null || true

CONFIG_DIR=/etc/sysconfig

bring_up_interface() {
  cfg="$1"
  . "$cfg"

  case "$SERVICE" in
    dhcpcd|DHCP|dhcp)
      echo "  -> Ativando $IFACE via dhcpcd..."
      if command -v dhcpcd >/dev/null 2>&1; then
        dhcpcd "$IFACE"
      else
        echo "  !! dhcpcd não encontrado; instale dhcpcd ou ajuste SERVICE."
      fi
      ;;
    ipv4-static)
      echo "  -> Configurando $IFACE com IP estático ${IP}/${PREFIX} gw ${GATEWAY}..."
      if command -v ip >/dev/null 2>&1; then
        ip link set "$IFACE" up
        ip addr flush dev "$IFACE" || true
        ip addr add "${IP}/${PREFIX}" dev "$IFACE"
        [ -n "$GATEWAY" ] && ip route add default via "$GATEWAY" dev "$IFACE" || true
      else
        echo "  !! comando 'ip' não encontrado; instale iproute2."
      fi
      ;;
    *)
      echo "  !! SERVICE não reconhecido em $cfg: $SERVICE"
      ;;
  esac
}

bring_down_interface() {
  cfg="$1"
  . "$cfg"

  echo "  -> Desativando $IFACE..."
  if command -v ip >/dev/null 2>&1; then
    ip addr flush dev "$IFACE" || true
    ip link set "$IFACE" down || true
  fi

  if command -v dhcpcd >/dev/null 2>&1; then
    dhcpcd -k "$IFACE" >/dev/null 2>&1 || true
  fi
}

case "$1" in
  start)
    echo "Iniciando rede..."
    for cfg in ${CONFIG_DIR}/ifconfig.*; do
      [ -f "$cfg" ] || continue
      bring_up_interface "$cfg"
    done
    ;;
  stop)
    echo "Parando rede..."
    for cfg in ${CONFIG_DIR}/ifconfig.*; do
      [ -f "$cfg" ] || continue
      bring_down_interface "$cfg"
    done
    ;;
  restart|reload)
    "$0" stop
    "$0" start
    ;;
  status)
    echo "Status de interfaces:"
    if command -v ip >/dev/null 2>&1; then
      ip addr show
    else
      if command -v ifconfig >/dev/null 2>&1; then
        ifconfig -a
      fi
    fi
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|status}"
    exit 1
    ;;
esac

exit 0
EOF
chmod +x "${INITD}/network"

# Links de network (multiusuário)
create_links network 3 10 S
create_links network 4 10 S
create_links network 5 10 S
create_links network 0 90 K
create_links network 1 90 K
create_links network 2 90 K
create_links network 6 90 K

# ====================== syslog ======================
cat > "${INITD}/syslog" << 'EOF'
#!/bin/sh
# /etc/rc.d/init.d/syslog - inicia/parar syslogd e klogd (sysklogd)
### BEGIN INIT INFO
# Provides:          syslog
# Required-Start:    $local_fs
# Required-Stop:     $local_fs
# Default-Start:     3 4 5
# Default-Stop:      0 1 2 6
# Short-Description: System logging daemons
### END INIT INFO

case "$1" in
  start)
    echo "Iniciando syslogd e klogd..."
    if command -v syslogd >/dev/null 2>&1; then
      syslogd
    else
      echo "  !! syslogd não encontrado."
    fi
    if command -v klogd >/dev/null 2>&1; then
      klogd
    else
      echo "  !! klogd não encontrado."
    fi
    ;;
  stop)
    echo "Parando klogd e syslogd..."
    killall klogd 2>/dev/null || true
    killall syslogd 2>/dev/null || true
    ;;
  restart|reload)
    "$0" stop
    "$0" start
    ;;
  status)
    ps ax | grep -E 'syslogd|klogd' | grep -v grep || echo "syslogd/klogd não parecem estar rodando."
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|status}"
    exit 1
    ;;
esac

exit 0
EOF
chmod +x "${INITD}/syslog"

# Links de syslog
create_links syslog 3 05 S
create_links syslog 4 05 S
create_links syslog 5 05 S
create_links syslog 0 90 K
create_links syslog 1 90 K
create_links syslog 2 90 K
create_links syslog 6 90 K

# ====================== cron ======================
cat > "${INITD}/cron" << 'EOF'
#!/bin/sh
# /etc/rc.d/init.d/cron - inicia/parar cron (cronie)
### BEGIN INIT INFO
# Provides:          cron
# Required-Start:    $local_fs $syslog
# Required-Stop:     $local_fs $syslog
# Default-Start:     3 4 5
# Default-Stop:      0 1 2 6
# Short-Description: Cron daemon
### END INIT INFO

DAEMON=crond

case "$1" in
  start)
    echo "Iniciando $DAEMON..."
    if command -v "$DAEMON" >/dev/null 2>&1; then
      "$DAEMON"
    else
      echo "  !! $DAEMON não encontrado."
    fi
    ;;
  stop)
    echo "Parando $DAEMON..."
    killall "$DAEMON" 2>/dev/null || true
    ;;
  restart|reload)
    "$0" stop
    "$0" start
    ;;
  status)
    ps ax | grep "$DAEMON" | grep -v grep || echo "$DAEMON não parece estar rodando."
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|status}"
    exit 1
    ;;
esac

exit 0
EOF
chmod +x "${INITD}/cron"

create_links cron 3 60 S
create_links cron 4 60 S
create_links cron 5 60 S
create_links cron 0 20 K
create_links cron 1 20 K
create_links cron 2 20 K
create_links cron 6 20 K

# ====================== local ======================
cat > "${INITD}/local" << 'EOF'
#!/bin/sh
# /etc/rc.d/init.d/local - hook para comandos locais do administrador
### BEGIN INIT INFO
# Provides:          local
# Required-Start:    $remote_fs $syslog $network
# Required-Stop:     $remote_fs $syslog $network
# Default-Start:     3 4 5
# Default-Stop:      0 1 2 6
# Short-Description: Local customization
### END INIT INFO

LOCALRC=/etc/rc.d/rc.local

case "$1" in
  start)
    if [ -x "$LOCALRC" ]; then
      echo "Executando rc.local..."
      "$LOCALRC"
    fi
    ;;
  stop)
    # nada a fazer
    ;;
  restart|reload)
    "$0" start
    ;;
  status)
    [ -x "$LOCALRC" ] && echo "rc.local existe e é executável." || echo "rc.local não existe ou não é executável."
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|status}"
    exit 1
    ;;
esac

exit 0
EOF
chmod +x "${INITD}/local"

create_links local 3 99 S
create_links local 4 99 S
create_links local 5 99 S

# ====================== halt (shutdown) ======================
cat > "${INITD}/halt" << 'EOF'
#!/bin/sh
# /etc/rc.d/init.d/halt - sequência final de parada
### BEGIN INIT INFO
# Provides:          halt
# Required-Start:
# Required-Stop:     $local_fs $remote_fs $network
# Default-Start:
# Default-Stop:      0 6
# Short-Description: Final poweroff/reboot sequence
### END INIT INFO

case "$1" in
  start)
    # start não faz sentido aqui
    ;;
  stop)
    echo "Sincronizando discos..."
    sync
    echo "Desmontando sistemas de arquivos..."
    umount -a -r >/dev/null 2>&1 || true
    ;;
  *)
    echo "Uso: $0 {stop}"
    exit 1
    ;;
esac

exit 0
EOF
chmod +x "${INITD}/halt"

create_links halt 0 00 K
create_links halt 6 00 K

# Criar rc.local se não existir
if [[ ! -f /etc/rc.d/rc.local ]]; then
  cat > /etc/rc.d/rc.local << 'EOF'
#!/bin/sh
# /etc/rc.d/rc.local - comandos locais executados no fim do boot
EOF
  chmod +x /etc/rc.d/rc.local
fi

echo "Serviços SysV (network, syslog, cron, local, halt) criados e vinculados aos runlevels."
