#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Ajustando identidade do sistema (os-release, motd, hostname, issue)..."

# /etc/os-release
cat > /etc/os-release << 'EOF'
NAME="LFS"
PRETTY_NAME="Linux From Scratch (Automated)"
ID=lfs
VERSION_ID="12.1"
HOME_URL="https://www.linuxfromscratch.org/"
SUPPORT_URL="https://www.linuxfromscratch.org/support.html"
BUG_REPORT_URL="https://www.linuxfromscratch.org/contact.html"
EOF

# motd
cat > /etc/motd << 'EOF'
Bem-vindo ao seu sistema LFS automatizado.
Use sudo para tarefas administrativas (usuários no grupo wheel).
EOF

# issue
cat > /etc/issue << 'EOF'
LFS 12.1 automatizado \n \l
EOF

# hostname (se ainda não definido por 08-network-config)
if [[ ! -f /etc/hostname ]]; then
  read -rp "Informe o hostname desejado (ex: lfs): " HOSTNAME
  HOSTNAME=${HOSTNAME:-lfs}
  echo "$HOSTNAME" > /etc/hostname
fi

echo "Identidade do sistema ajustada."
