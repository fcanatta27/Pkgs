#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

FSTAB=/etc/fstab

if [[ -f "$FSTAB" ]]; then
  echo "AVISO: $FSTAB já existe. Uma cópia de backup será criada em /etc/fstab.bak."
  cp -v "$FSTAB" /etc/fstab.bak
fi

cat > "$FSTAB" << 'EOF'
# /etc/fstab: arquivos de sistemas montados automaticamente
#
# Ajuste os dispositivos (/dev/sdXN) conforme o seu layout de disco.
#
# <file system>  <mount point>  <type>  <options>                  <dump> <pass>
/dev/sda1        /              ext4    defaults                   1      1
proc             /proc          proc    nosuid,noexec,nodev        0      0
sysfs            /sys           sysfs   nosuid,noexec,nodev        0      0
devpts           /dev/pts       devpts  gid=5,mode=620             0      0
tmpfs            /run           tmpfs   defaults                   0      0
devtmpfs         /dev           devtmpfs mode=0755,nosuid          0      0
EOF

echo "Arquivo /etc/fstab criado. Lembre-se de ajustar o dispositivo raiz (/dev/sda1)."
