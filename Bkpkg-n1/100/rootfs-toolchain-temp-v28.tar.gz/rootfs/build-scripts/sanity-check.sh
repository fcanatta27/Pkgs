#!/usr/bin/env bash
# sanity-check.sh
# Faz uma bateria de verificações na toolchain temporária e nas temporary tools
# para ajudar a garantir que tudo foi construído corretamente.
#
# Este script:
#   - Verifica se LFS está definido e se diretórios básicos existem
#   - Lista o status de todas as etapas em 10-toolchain-temp (com base nos .done)
#   - Verifica a existência dos binários/chaves principais e alguns arquivos críticos
#   - Faz um sanity-check de compilação com o $LFS_TGT-gcc
#
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: sanity-check.sh deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOOLS_DIR="${SCRIPT_DIR}/10-toolchain-temp"
STATE_DIR="${LFS}/.lfs-build-state"
LOG_DIR="${LFS}/.lfs-build-logs"

if [[ ! -d "$TOOLS_DIR" ]]; then
  echo "ERRO: diretório de scripts não encontrado: $TOOLS_DIR"
  exit 1
fi

mkdir -pv "$STATE_DIR" "$LOG_DIR"

C_OK=$'\e[32m'
C_BAD=$'\e[31m'
C_INFO=$'\e[34m'
C_RESET=$'\e[0m'

info() { echo "${C_INFO}[CHECK]${C_RESET} $*"; }
ok()   { echo "${C_OK}[OK]   ${C_RESET} $*"; }
bad()  { echo "${C_BAD}[FAIL]${C_RESET} $*"; }

step_done() {
  local name="$1"
  [[ -f "${STATE_DIR}/${name}.done" ]]
}

get_step_name() {
  local path="$1"
  basename "$path" .sh
}

# 1) Verificações básicas de diretórios
info "Verificando diretórios básicos do LFS..."

for d in "$LFS" "$LFS/tools" "$LFS/sources" "$LFS/usr"; do
  if [[ -d "$d" ]]; then
    ok "Diretório existe: $d"
  else
    bad "Diretório NÃO existe: $d"
  fi
done

# 2) Listar status das etapas
info "Coletando lista de etapas em 10-toolchain-temp..."
mapfile -t ALL_SCRIPTS < <(find "$TOOLS_DIR" -maxdepth 1 -type f -name '*.sh' | sort)

if [[ "${#ALL_SCRIPTS[@]}" -eq 0 ]]; then
  bad "Nenhum script encontrado em $TOOLS_DIR"
else
  echo
  echo "Status de etapas (baseado em arquivos .done):"
  for s in "${ALL_SCRIPTS[@]}"; do
    name="$(get_step_name "$s")"
    if step_done "$name"; then
      ts="$(cat "${STATE_DIR}/${name}.done" 2>/dev/null || echo '?')"
      printf "  [%-4s] %s (concluída em %s)\n" "OK" "$name" "$ts"
    else
      printf "  [%-4s] %s\n" "PEND" "$name"
    fi
  done
fi

# 3) Verificação de arquivos/binários importantes
info "Verificando artefatos principais da toolchain..."

check_file() {
  local path="$1"
  local label="$2"
  if [[ -e "$path" ]]; then
    ok "$label presente: $path"
  else
    bad "$label AUSENTE: $path"
  fi
}

# Toolchain em /tools
check_file "$LFS/tools/bin/${LFS_TGT}-gcc" "Cross-compiler (pass1)"
check_file "$LFS/tools/bin/${LFS_TGT}-as"  "Assembler (binutils pass1)"
check_file "$LFS/tools/bin/${LFS_TGT}-ld"  "Linker (binutils pass1)"

# Headers
check_file "$LFS/usr/include/linux/version.h" "Linux API headers (version.h)"

# Glibc
check_file "$LFS/usr/lib/libc.so"      "Glibc (libc.so)"
check_file "$LFS/usr/lib/libc-2.39.so" "Glibc (libc-2.39.so) (nome pode variar por distro/hardening)"

# Binutils/GCC pass2 já instalados no DESTDIR=$LFS
check_file "$LFS/usr/bin/ld"   "Binutils pass2 (ld)"
check_file "$LFS/usr/bin/gcc"  "GCC pass2 (gcc)"
check_file "$LFS/usr/bin/cc"   "Symlink cc -> gcc"

# Temporary tools típicas
check_file "$LFS/usr/bin/m4"       "M4"
check_file "$LFS/usr/lib/libncursesw.so" "Ncurses wide"
check_file "$LFS/bin/sh"           "Link /bin/sh -> bash (dentro do LFS)"
check_file "$LFS/usr/bin/bash"     "Bash"
check_file "$LFS/usr/bin/ls"       "Coreutils (ls)"
check_file "$LFS/usr/bin/diff"     "Diffutils"
check_file "$LFS/usr/bin/make"     "Make"
check_file "$LFS/usr/bin/file"     "file(1)"
check_file "$LFS/usr/bin/find"     "findutils"
check_file "$LFS/usr/bin/gawk"     "gawk"
check_file "$LFS/usr/bin/grep"     "grep"
check_file "$LFS/usr/bin/gzip"     "gzip"
check_file "$LFS/usr/bin/patch"    "patch"
check_file "$LFS/usr/bin/sed"      "sed"
check_file "$LFS/usr/bin/tar"      "tar"
check_file "$LFS/usr/bin/xz"       "xz"
check_file "$LFS/usr/bin/bison"    "bison"
check_file "$LFS/usr/bin/perl"     "perl"
check_file "$LFS/usr/bin/python3"  "python3 (link principal)"

# 4) Sanity-check do cross-compiler com glibc
echo
info "Executando sanity-check do cross-compiler ($LFS_TGT-gcc) com glibc..."

TMPDIR="$(mktemp -d "${TMPDIR:-/tmp}/lfs-sanity-XXXXXX")"
trap 'rm -rf "$TMPDIR"' EXIT

cat > "$TMPDIR/test.c" << 'EOF'
#include <stdio.h>
int main(void) {
  printf("sanity-ok\n");
  return 0;
}
EOF

# Usar o cross-compiler com sysroot implícito em $LFS
if "$LFS_TGT-gcc" -v >/dev/null 2>&1; then
  ok "$LFS_TGT-gcc está funcional o suficiente para responder -v"
else
  bad "Falha ao executar $LFS_TGT-gcc -v"
fi

if "$LFS_TGT-gcc" "$TMPDIR/test.c" -o "$TMPDIR/a.out" >/dev/null 2>&1; then
  ok "Compilação de programa de teste com $LFS_TGT-gcc bem-sucedida."
else
  bad "Falha ao compilar programa de teste com $LFS_TGT-gcc."
fi

if command -v readelf >/dev/null 2>&1 && [[ -f "$TMPDIR/a.out" ]]; then
  interp_line="$(readelf -l "$TMPDIR/a.out" | grep 'Requesting program interpreter' || true)"
  if [[ -n "$interp_line" ]]; then
    ok "readelf encontrou o interpretador de programa: $interp_line"
  else
    bad "readelf não encontrou 'Requesting program interpreter' em a.out."
  fi
else
  info "readelf não disponível ou a.out ausente; pulando verificação de interpretador."
fi

echo
info "Sanity-check concluído. Verifique as linhas marcadas como [FAIL]."
