#!/usr/bin/env bash
# build-all-chroot.sh - Orquestrador principal DENTRO do chroot LFS
#
# Responsabilidades:
#   - construir toolchain completo via build-scripts/10-toolchain-temp/build-all-toolchain.sh
#   - construir sistema final via build-scripts/20-system-final/build-all-system.sh
#   - rodar checklist de pós-instalação
#
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS." >&2
  exit 1
fi

BASE_DIR="/build-scripts"
LOGDIR=/var/log/lfs-build
mkdir -pv "$LOGDIR"

log() { echo "[build-all-chroot] $*"; }

log "Iniciando construção dentro do chroot..."

# 1) Toolchain
if [[ -x "$BASE_DIR/10-toolchain-temp/build-all-toolchain.sh" ]]; then
  log "Construindo toolchain (10-toolchain-temp)..."
  "$BASE_DIR/10-toolchain-temp/build-all-toolchain.sh" 2>&1 | tee -a "$LOGDIR/toolchain-full.log"
else
  echo "ERRO: $BASE_DIR/10-toolchain-temp/build-all-toolchain.sh não encontrado ou não executável." >&2
  exit 1
fi

# 2) Sistema final
if [[ -x "$BASE_DIR/20-system-final/build-all-system.sh" ]]; then
  log "Construindo sistema final (20-system-final)..."
  "$BASE_DIR/20-system-final/build-all-system.sh" 2>&1 | tee -a "$LOGDIR/system-final-full.log"
else
  echo "ERRO: $BASE_DIR/20-system-final/build-all-system.sh não encontrado ou não executável." >&2
  exit 1
fi

# 3) Pós-instalação (se existir)
if [[ -x "$BASE_DIR/30-post-install/post-install-checklist.sh" ]]; then
  log "Executando checklist de pós-instalação..."
  "$BASE_DIR/30-post-install/post-install-checklist.sh" 2>&1 | tee -a "$LOGDIR/post-install.log"
else
  log "Checklist de pós-instalação não encontrado, pulando essa etapa."
fi

log "build-all-chroot.sh concluído."
