#!/usr/bin/env bash
# build-all.sh - Orquestrador principal (HOST) para construir o sistema LFS
#
# Responsabilidades:
#   - preparar o ambiente LFS (diretórios, partição montada)
#   - montar /dev, /proc, /sys, /run dentro do LFS
#   - copiar /etc/resolv.conf para dentro do LFS (para ter rede no chroot)
#   - entrar em chroot e chamar build-all-chroot.sh
#
# Uso típico (no host):
#   export LFS=/mnt/lfs
#   export LFS_DEV=/dev/sdX2   # partição raiz LFS já particionada
#   ./build-all.sh
#
set -euo pipefail

log() { echo "[build-all-host] $*"; }

export LFS=${LFS:-/mnt/lfs}
export LFS_DEV=${LFS_DEV:-/dev/sdX2}

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log "Usando LFS=$LFS e LFS_DEV=$LFS_DEV"

if [[ ! -b "$LFS_DEV" ]]; then
  echo "ERRO: dispositivo de bloco $LFS_DEV não existe. Ajuste LFS_DEV." >&2
  exit 1
fi

# 1) Preparar diretórios básicos
log "Criando diretórios base em $LFS..."
mkdir -pv "$LFS"

# 2) Garantir que a partição está montada
if ! mountpoint -q "$LFS"; then
  log "Montando $LFS_DEV em $LFS..."
  mount "$LFS_DEV" "$LFS"
else
  log "$LFS já está montado, mantendo montagem atual."
fi

# 3) Garantir estrutura mínima de diretórios
log "Criando estrutura mínima em $LFS..."
mkdir -pv "$LFS"/{boot,home,lib,usr,var,etc,bin,sbin,tools,sources}
mkdir -pv "$LFS"/usr/{bin,lib,sbin,src}
mkdir -pv "$LFS/var/log/lfs-build"

# 4) Montar pseudo-sistemas de arquivos
log "Montando /dev, /proc, /sys, /run dentro de $LFS..."
mountpoint -q "$LFS/dev"      || mount --bind /dev "$LFS/dev"
mountpoint -q "$LFS/dev/pts"  || mount --bind /dev/pts "$LFS/dev/pts"
mountpoint -q "$LFS/proc"     || mount -t proc proc "$LFS/proc"
mountpoint -q "$LFS/sys"      || mount -t sysfs sysfs "$LFS/sys"
mountpoint -q "$LFS/run"      || mount -t tmpfs tmpfs "$LFS/run"

if [ -h "$LFS/dev/shm" ]; then
  mkdir -pv "$LFS/$(readlink "$LFS/dev/shm")"
fi

# 5) Copiar resolv.conf para ter rede dentro do chroot
if [[ -f /etc/resolv.conf ]]; then
  log "Copiando /etc/resolv.conf para $LFS/etc/resolv.conf..."
  mkdir -pv "$LFS/etc"
  cp -L /etc/resolv.conf "$LFS/etc/resolv.conf"
else:
  log "AVISO: /etc/resolv.conf não encontrado no host; DNS dentro do chroot pode falhar."
fi

# 6) Entrar em chroot e chamar build-all-chroot.sh
log "Entrando em chroot e executando build-all-chroot.sh..."

chroot "$LFS" /usr/bin/env -i \
    HOME=/root TERM="$TERM" PS1='(lfs-chroot) \u:\w\$ ' \
    PATH=/usr/bin:/usr/sbin:/bin:/sbin \
    /bin/bash -lc "/build-scripts/build-all-chroot.sh"

log "build-all.sh concluído."
