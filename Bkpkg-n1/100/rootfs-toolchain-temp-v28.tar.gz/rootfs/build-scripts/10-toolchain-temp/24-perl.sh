#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=perl-5.38.2
TARBALL="${PKG}.tar.xz"
URL="https://www.cpan.org/src/5.0/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

# Usar apenas o mínimo necessário para as temporary tools.
sh Configure -des                                       \
  -Dprefix=/usr                                         \
  -Dvendorprefix=/usr                                   \
  -Dprivlib=/usr/lib/perl5/5.38/core_perl              \
  -Darchlib=/usr/lib/perl5/5.38/core_perl              \
  -Dsitelib=/usr/lib/perl5/5.38/site_perl              \
  -Dsitearch=/usr/lib/perl5/5.38/site_perl             \
  -Dvendorlib=/usr/lib/perl5/5.38/vendor_perl          \
  -Dvendorarch=/usr/lib/perl5/5.38/vendor_perl         \
  -Dman1dir=/usr/share/man/man1                        \
  -Dman3dir=/usr/share/man/man3                        \
  -Dpager="/usr/bin/less -isR"                          \
  -Dusethreads                                         \
  -Duseshrplib=false

make -j"$(nproc)"
make DESTDIR="$LFS" install

echo "Perl instalado no rootfs temporário ($LFS/usr)."
