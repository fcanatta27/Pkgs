#!/usr/bin/env bash
# build-all-toolchain.sh - constrói toolchain completo via pkg (DENTRO do chroot)
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS." >&2
  exit 1
fi

LOGDIR=${LOGDIR:-/var/log/lfs-build}
mkdir -pv "$LOGDIR"

log() { echo "[toolchain] $*"; }

if ! command -v pkg >/dev/null 2>&1; then
  echo "ERRO: comando 'pkg' não encontrado. Certifique-se de que o gerenciador de pacotes está instalado no chroot." >&2
  exit 1
fi

log "Instalando bibliotecas matemáticas base (gmp, mpfr, mpc, isl, zlib)..."
pkg install gmp mpfr mpc isl zlib 2>&1 | tee -a "$LOGDIR/toolchain-libs.log"

log "Instalando binutils..."
pkg install binutils 2>&1 | tee -a "$LOGDIR/toolchain-binutils.log"

log "Instalando GCC..."
pkg install gcc 2>&1 | tee -a "$LOGDIR/toolchain-gcc.log"

log "Toolchain base instalado via pkg."
