
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=linux-6.7.4
TARBALL="${PKG}.tar.xz"
URL="https://www.kernel.org/pub/linux/kernel/v6.x/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

make mrproper
make headers

find usr/include -type f ! -name '*.h' -delete

mkdir -pv "$LFS/usr"
cp -rv usr/include "$LFS/usr"

echo "Linux API headers instalados em $LFS/usr/include."
