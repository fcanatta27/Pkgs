
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=glibc-2.39
TARBALL="${PKG}.tar.xz"
URL="https://ftp.gnu.org/gnu/glibc/${TARBALL}"

PATCH_FILE="glibc-2.39-fhs-1.patch"
PATCH_URL="https://www.linuxfromscratch.org/patches/lfs/12.1/${PATCH_FILE}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi
if [[ ! -f "$PATCH_FILE" ]]; then
  wget -c "$PATCH_URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

mkdir -pv "$LFS"/{lib,lib64}
case $(uname -m) in
  i?86)
    ln -sfv ld-linux.so.2 "$LFS/lib/ld-lsb.so.3"
  ;;
  x86_64)
    ln -sfv ../lib/ld-linux-x86-64.so.2 "$LFS/lib64"
    ln -sfv ../lib/ld-linux-x86-64.so.2 "$LFS/lib64/ld-lsb-x86-64.so.3"
  ;;
esac

patch -Np1 -i "../${PATCH_FILE}"

mkdir -v build
cd build

echo "rootsbindir=/usr/sbin" > configparms

../configure \
  --prefix=/usr \
  --host="$LFS_TGT" \
  --build="$(../scripts/config.guess)" \
  --enable-kernel=4.19 \
  --with-headers="$LFS/usr/include" \
  --disable-nscd \
  libc_cv_slibdir=/usr/lib

make -j"$(nproc)"
make DESTDIR="$LFS" install

sed '/RTLDLIST=/s@/usr@@g' -i "$LFS/usr/bin/ldd"

cat << 'EOF'

Glibc instalada no rootfs temporário.

Sanity check sugerido:

  echo 'int main(){}' | $LFS_TGT-gcc -xc -
  readelf -l a.out | grep ld-linux
  rm -v a.out

EOF
