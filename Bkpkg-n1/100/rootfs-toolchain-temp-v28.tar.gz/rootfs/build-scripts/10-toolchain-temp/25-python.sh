#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=Python-3.12.2
TARBALL="${PKG}.tar.xz"
URL="https://www.python.org/ftp/python/3.12.2/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

# Desabilitar ensurepip nas temporary tools para reduzir dependências
./configure --prefix=/usr                          \
            --host="$LFS_TGT"                      \
            --build="$(./config.guess)"           \
            --enable-shared                        \
            --with-system-expat                    \
            --with-system-ffi                      \
            --without-ensurepip

make -j"$(nproc)"
make DESTDIR="$LFS" install

# Limpar testes e arquivos pesados para economizar espaço em $LFS
rm -rf "$LFS"/usr/lib/python3.12/test 2>/dev/null || true
rm -rf "$LFS"/usr/lib/python3.12/ensurepip 2>/dev/null || true

echo "Python 3 instalado no rootfs temporário ($LFS/usr)."
