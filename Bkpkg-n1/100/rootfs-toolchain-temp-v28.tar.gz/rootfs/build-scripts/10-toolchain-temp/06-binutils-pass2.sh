
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=binutils-2.42
TARBALL="${PKG}.tar.xz"
URL="https://sourceware.org/pub/binutils/releases/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

sed '6009s/$add_dir//' -i ltmain.sh || true

mkdir -v build
cd build

../configure \
  --prefix=/usr \
  --build="$(../config.guess)" \
  --host="$LFS_TGT" \
  --disable-nls \
  --enable-shared \
  --enable-gprofng=no \
  --disable-werror \
  --enable-64-bit-bfd \
  --enable-default-hash-style=gnu

make -j"$(nproc)"
make DESTDIR="$LFS" install

rm -v "$LFS"/usr/lib/lib{bfd,ctf,ctf-nobfd,opcodes,sframe}.{a,la} 2>/dev/null || true

echo "Binutils pass2 instalado em $LFS/usr."
