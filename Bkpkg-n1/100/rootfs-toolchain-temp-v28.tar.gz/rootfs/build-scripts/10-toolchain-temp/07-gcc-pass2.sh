
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

unset CFLAGS CXXFLAGS CPPFLAGS LDFLAGS || true

PKG=gcc-13.2.0
TARBALL="${PKG}.tar.xz"
URL="https://ftp.gnu.org/gnu/gcc/${PKG}/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

MPFR_TARBALL="mpfr-4.2.1.tar.xz"
GMP_TARBALL="gmp-6.3.0.tar.xz"
MPC_TARBALL="mpc-1.3.1.tar.gz"

MPFR_URL="https://ftp.gnu.org/gnu/mpfr/${MPFR_TARBALL}"
GMP_URL="https://ftp.gnu.org/gnu/gmp/${GMP_TARBALL}"
MPC_URL="https://ftp.gnu.org/gnu/mpc/${MPC_TARBALL}"

for t in "$MPFR_TARBALL" "$GMP_TARBALL" "$MPC_TARBALL"; do
  url_var="${t%%-*}_URL"
  url="${!url_var}"
  if [[ ! -f "$t" ]]; then
    wget -c "$url"
  fi
done

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

tar -xf "../${MPFR_TARBALL}"
mv -v mpfr-4.2.1 mpfr
tar -xf "../${GMP_TARBALL}"
mv -v gmp-6.3.0 gmp
tar -xf "../${MPC_TARBALL}"
mv -v mpc-1.3.1 mpc

case $(uname -m) in
  x86_64)
    sed -e '/m64=/s/lib64/lib/' -i.orig gcc/config/i386/t-linux64
  ;;
esac

sed '/thread_header =/s/@.*@/gthr-posix.h/' \
  -i libgcc/Makefile.in libstdc++-v3/include/Makefile.in

mkdir -v build
cd build

../configure \
  --build="$(../config.guess)" \
  --host="$LFS_TGT" \
  --target="$LFS_TGT" \
  LDFLAGS_FOR_TARGET="-L$PWD/$LFS_TGT/libgcc" \
  --prefix=/usr \
  --with-build-sysroot="$LFS" \
  --enable-default-pie \
  --enable-default-ssp \
  --disable-nls \
  --disable-multilib \
  --disable-libatomic \
  --disable-libgomp \
  --disable-libquadmath \
  --disable-libsanitizer \
  --disable-libssp \
  --disable-libvtv \
  --enable-languages=c,c++

make -j"$(nproc)"
make DESTDIR="$LFS" install

ln -sv gcc "$LFS/usr/bin/cc" || true

echo "GCC pass2 instalado em $LFS/usr."
