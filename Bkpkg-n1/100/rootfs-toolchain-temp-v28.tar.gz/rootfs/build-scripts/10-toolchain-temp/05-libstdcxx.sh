
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=gcc-13.2.0
TARBALL="${PKG}.tar.xz"
URL="https://ftp.gnu.org/gnu/gcc/${PKG}/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

mkdir -v build
cd build

../libstdc++-v3/configure \
  --host="$LFS_TGT" \
  --build="$(../config.guess)" \
  --prefix=/usr \
  --disable-multilib \
  --disable-nls \
  --disable-libstdcxx-pch \
  --with-gxx-include-dir=/tools/$LFS_TGT/include/c++/13.2.0

make -j"$(nproc)"
make DESTDIR="$LFS" install

rm -v "$LFS"/usr/lib/lib{{stdc++,stdc++exp,stdc++fs},supc++}.la 2>/dev/null || true

echo "Libstdc++ instalada no rootfs temporário."
