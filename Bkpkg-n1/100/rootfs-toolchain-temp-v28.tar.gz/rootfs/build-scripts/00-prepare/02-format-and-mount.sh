#!/usr/bin/env bash
# 02-format-and-mount.sh - formata e monta a partição LFS
set -euo pipefail

export LFS=${LFS:-/mnt/lfs}
export LFS_DEV=${LFS_DEV:-/dev/sdX2}

echo "Formatando $LFS_DEV como ext4 (se necessário)..."
# mkfs.ext4 -L LFS_ROOT "$LFS_DEV"   # descomente após revisar

echo "Montando $LFS_DEV em $LFS..."
mkdir -pv "$LFS"
mount "$LFS_DEV" "$LFS"

echo "Cria diretórios base em $LFS"
mkdir -pv "$LFS"/{boot,home,lib,usr,var,etc,bin,sbin}
mkdir -pv "$LFS"/usr/{bin,lib,sbin,src}

echo "Partição montada e diretórios iniciais criados."
