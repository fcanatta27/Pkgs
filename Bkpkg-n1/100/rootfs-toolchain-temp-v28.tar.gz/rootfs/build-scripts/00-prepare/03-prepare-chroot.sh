#!/usr/bin/env bash
# 03-prepare-chroot.sh - monta pseudo-sistemas de arquivos e prepara chroot
set -euo pipefail

export LFS=${LFS:-/mnt/lfs}

if ! mountpoint -q "$LFS"; then
  echo "ERRO: $LFS não está montado. Monte a partição primeiro." >&2
  exit 1
fi

echo "[chroot] Montando /dev, /proc, /sys, /run dentro de $LFS"

mount --bind /dev "$LFS/dev"
mount --bind /dev/pts "$LFS/dev/pts"
mount -t proc proc "$LFS/proc"
mount -t sysfs sysfs "$LFS/sys"
mount -t tmpfs tmpfs "$LFS/run"

if [ -h "$LFS/dev/shm" ]; then
  mkdir -pv "$LFS/$(readlink $LFS/dev/shm)"
fi

echo "[chroot] Ambiente de chroot preparado."
