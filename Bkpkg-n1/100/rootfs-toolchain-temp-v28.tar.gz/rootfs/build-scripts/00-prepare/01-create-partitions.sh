
#!/usr/bin/env bash
set -euo pipefail

# Script de exemplo para particionar o disco alvo.
# ATENÇÃO: ESTE SCRIPT APAGA DADOS NO DISCO INFORMADO.
# Leia e adapte antes de usar em produção.

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: execute 01-create-partitions.sh como root."
  exit 1
fi

DISK="${1:-}"
if [[ -z "$DISK" ]]; then
  echo "Uso: $0 /dev/sdX"
  exit 1
fi

read -r -p "CONFIRMA APAGAR TODAS AS PARTIÇÕES EM $DISK? (digite 'SIM' para confirmar): " answer
if [[ "$answer" != "SIM" ]]; then
  echo "Cancelado."
  exit 1
fi

echo '==> Criando tabela de partições GPT e partição única para LFS em '"$DISK"'...'
parted -s "$DISK" mklabel gpt
parted -s "$DISK" mkpart primary 1MiB 100%

partprobe "$DISK" || true

cat <<EOF

==> Agora, manualmente, execute algo como:

  mkfs.ext4 ${DISK}1
  export LFS=/mnt/lfs
  mkdir -pv \$LFS
  mount ${DISK}1 \$LFS

Depois, execute 00-setup-env.sh para preparar o ambiente.

EOF
