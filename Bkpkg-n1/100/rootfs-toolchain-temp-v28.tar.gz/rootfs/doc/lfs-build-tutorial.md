# Tutorial de Construção do Sistema com `pkg` e build-scripts

Este documento resume o fluxo completo para construir o sistema usando os
scripts em `build-scripts/` e o gerenciador de pacotes `pkg`.

## 1. Preparação do host

1. Certifique-se de que o host tem:
   - ferramentas básicas (bash, coreutils, gcc, make, etc.);
   - conectividade de rede para baixar fontes.

2. Escolha o dispositivo de disco que será usado para o LFS (ex.: `/dev/sda`).

## 2. Preparar ambiente LFS

No host (fora do chroot):

```bash
cd /build-scripts/00-prepare

# Define LFS e dispositivo de raiz
export LFS=/mnt/lfs
export LFS_DEV=/dev/sdX2    # ajuste conforme seu ambiente

./00-setup-env.sh
./01-create-partitions.sh   # revise antes de descomentar comandos destrutivos
./02-format-and-mount.sh
```

## 3. Preparar chroot

Ainda no host:

```bash
cd /build-scripts/00-prepare

export LFS=/mnt/lfs
./03-prepare-chroot.sh
./04-enter-chroot.sh
```

O último comando irá abrir um shell dentro do chroot com `PATH` limpo.

## 4. Construir toolchain dentro do chroot

Dentro do chroot (prompt `(lfs-chroot)`):

```bash
cd /build-scripts/10-toolchain-temp
./build-all-toolchain.sh
```

Isso irá:

- instalar `gmp`, `mpfr`, `mpc`, `isl`, `zlib`;
- instalar `binutils`;
- instalar `gcc`;

usando o gerenciador de pacotes `pkg` com base nos Buildfiles em `/usr/packages`.

## 5. Construir sistema final dentro do chroot

Ainda no chroot:

```bash
cd /build-scripts/20-system-final
./build-all-system.sh
```

Este script instalará:

- `linux-headers`, `glibc`, `linux`, `linux-firmware`;
- `bash`, `coreutils`, `util-linux`;
- `openssl`, `zlib`, `xz`, `zstd`, `curl`, `git`;
- `autotools`, `cmake`, `ninja`;
- `python3`, `pip`, `rust`;

tudo via `pkg`, respeitando dependências declaradas em cada Buildfile.

## 6. Pós-instalação e verificação

Dentro do chroot (ou já no sistema bootado):

```bash
cd /build-scripts/30-post-install
./post-install-checklist.sh
```

Este script verifica:

- se há usuário(s) no grupo `wheel`;
- se o timezone está configurado (`/etc/localtime`);
- se `chronyd` está instalado e em execução;
- se há firewall configurado (`iptables` e/ou `firewalld`).

## 7. Manutenção e upgrades

Para atualizar componentes críticos:

- Editar o `version`/`release` do Buildfile correspondente:
  - kernel: `/usr/packages/system/linux/Buildfile`
  - glibc: `/usr/packages/system/glibc/Buildfile`
  - toolchain: `/usr/packages/toolchain/gcc/Buildfile` etc.

- Rodar:

```bash
pkg upgrade linux
pkg upgrade glibc
pkg upgrade gcc
```

O `pkg` cuidará de:

- comparar versões instaladas com as do Buildfile;
- remover versão antiga;
- construir e instalar a nova versão mantendo o registro em `/var/lib/pkgdb`.

---

Este tutorial, somado a `/doc/pkg.md`, fornece uma visão completa de como
construir, manter e evoluir o sistema apenas com `pkg` e os scripts em
`build-scripts/`.
