#!/usr/bin/env bash
#
# Linux-6.18.5 API Headers
# LFS: capítulo 5.4

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${SCRIPT_DIR}/common.sh"

STEP_ID="linux-headers-6.18.5"

PKG_NAME="linux-6.18.5"
PKG_TARBALL="${PKG_NAME}.tar.xz"
LINUX_HEADERS_URL_DEFAULT="https://www.kernel.org/pub/linux/kernel/v6.x/${PKG_TARBALL}"
: "${LINUX_HEADERS_SRC_URL:=${LINUX_HEADERS_URL_DEFAULT}}"

if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
    echo "Baixando ${PKG_TARBALL}..."
    curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${LINUX_HEADERS_SRC_URL}"
fi

cd "${LFS_WORKDIR}"
rm -rf "${PKG_NAME}"
tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
cd "${PKG_NAME}"

make mrproper
make headers
find usr/include -type f ! -name '*.h' -delete

reset_destdir
mkdir -p "${LFS_DESTDIR}/usr"
cp -rv usr/include "${LFS_DESTDIR}/usr"

register_installed_files "${STEP_ID}"
sync_destdir_to_rootfs

echo "Linux API headers 6.18.5 instalados em ${LFS_ROOTFS}/usr/include."
