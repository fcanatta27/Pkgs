#!/usr/bin/env bash
#
# Configuração comum para os scripts de construção LFS-like.
#
# Este arquivo centraliza:
#   - Diretórios de trabalho (em /tmp por padrão, se $LFS não estiver definido).
#   - Detecção de CPU/memória para definir MAKEFLAGS.
#   - Funções utilitárias: reset_destdir, sync_destdir_to_rootfs, register_installed_files.
#
# Integração com o livro LFS:
#   - Se $LFS estiver definido no ambiente, ele será usado como raiz ($LFS_ROOTFS).
#   - Caso contrário, o projeto usará LFS_ROOTFS=/tmp/rootfs e exportará LFS=$LFS_ROOTFS.

set -euo pipefail

: "${LFS_ROOTFS:=/tmp/rootfs}"
: "${LFS_DESTDIR:=/tmp/destdir}"
: "${LFS_WORKDIR:=/tmp/lfs-work}"
: "${LFS_SRCDIR:=/tmp/lfs-src}"
: "${LFS_LOGDIR:=/tmp/lfs-logs}"
: "${LFS_STATE_DIR:=/tmp/lfs-state}"

# Integração com $LFS do livro
if [ -n "${LFS:-}" ]; then
    LFS_ROOTFS="${LFS}"
else
    export LFS="${LFS_ROOTFS}"
fi

mkdir -p "${LFS_ROOTFS}" "${LFS_DESTDIR}" "${LFS_WORKDIR}" "${LFS_SRCDIR}" "${LFS_LOGDIR}" "${LFS_STATE_DIR}"
mkdir -p "${LFS_ROOTFS}/tools"

: "${LFS_TGT:="$(uname -m)-lfs-linux-gnu"}"
export LFS_ROOTFS LFS_DESTDIR LFS_WORKDIR LFS_SRCDIR LFS_LOGDIR LFS_STATE_DIR LFS_TGT LFS

# Garante que $LFS/tools/bin esteja no PATH
if [[ ":${PATH}:" != *":${LFS_ROOTFS}/tools/bin:"* ]]; then
    export PATH="${LFS_ROOTFS}/tools/bin:${PATH}"
fi

# Detecção de recursos para ajustar MAKEFLAGS
detect_nproc() {
    if command -v nproc >/dev/null 2>&1; then
        nproc
    elif command -v getconf >/dev/null 2>&1; then
        getconf _NPROCESSORS_ONLN || echo 1
    else
        echo 1
    fi
}

detect_total_mem_mb() {
    if [ -r /proc/meminfo ]; then
        local mem_kb
        mem_kb=$(grep -i '^MemTotal:' /proc/meminfo | awk '{print $2}')
        if [[ -n "${mem_kb}" ]]; then
            echo $((mem_kb / 1024))
            return 0
        fi
    fi
    # fallback conservador (~1 GiB)
    echo 1024
}

compute_jobs() {
    local ncpus mem_mb jobs max_jobs_mem
    ncpus=$(detect_nproc)
    mem_mb=$(detect_total_mem_mb)

    jobs="${ncpus:-1}"
    if [ "${jobs}" -lt 1 ]; then
        jobs=1
    fi

    # Limite manual via LFS_MAX_JOBS, se definido
    if [ -n "${LFS_MAX_JOBS:-}" ]; then
        if [ "${LFS_MAX_JOBS}" -lt "${jobs}" ]; then
            jobs="${LFS_MAX_JOBS}"
        fi
    fi

    # Heurística simples: ~1 GiB por job
    if [ "${mem_mb}" -gt 0 ]; then
        max_jobs_mem=$((mem_mb / 1024))
        if [ "${max_jobs_mem}" -lt 1 ]; then
            max_jobs_mem=1
        fi
        if [ "${max_jobs_mem}" -lt "${jobs}" ]; then
            jobs="${max_jobs_mem}"
        fi
    fi

    echo "${jobs}"
}

if [ -z "${MAKEFLAGS:-}" ]; then
    MAKEFLAGS="-j$(compute_jobs)"
    export MAKEFLAGS
fi

PROGRESS_FILE="${LFS_STATE_DIR}/installed.steps"
touch "${PROGRESS_FILE}"

register_installed_files() {
    local step_id="$1"
    local list_file="${LFS_STATE_DIR}/${step_id}.files"

    if [ ! -d "${LFS_DESTDIR}" ]; then
        echo "ERRO: LFS_DESTDIR='${LFS_DESTDIR}' não existe ao registrar arquivos." >&2
        return 1
    fi

    (
        cd "${LFS_DESTDIR}"
        find . -mindepth 1 -print | sed 's|^\./||' > "${list_file}"
    )

    if ! grep -qxF "${step_id}" "${PROGRESS_FILE}" 2>/dev/null; then
        echo "${step_id}" >> "${PROGRESS_FILE}"
    fi
}

reset_destdir() {
    if [ -d "${LFS_DESTDIR}" ]; then
        rm -rf "${LFS_DESTDIR:?}/"*
    fi
    mkdir -p "${LFS_DESTDIR}"
}

sync_destdir_to_rootfs() {
    if [ ! -d "${LFS_DESTDIR}" ]; then
        echo "ERRO: LFS_DESTDIR='${LFS_DESTDIR}' não existe ao copiar para ROOTFS." >&2
        return 1
    fi
    ( cd "${LFS_DESTDIR}" && cp -a . "${LFS_ROOTFS}/" )
}
