#!/usr/bin/env bash
#
# Grep-3.12 (ferramenta temporária) - LFS 6.10

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${SCRIPT_DIR}/common.sh"

STEP_ID="grep-3.12-temp"

PKG_NAME="grep-3.12"
PKG_TARBALL="${PKG_NAME}.tar.xz"
GREP_URL_DEFAULT="https://ftp.gnu.org/gnu/grep/${PKG_TARBALL}"
: "${GREP_SRC_URL:=${GREP_URL_DEFAULT}}"

if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
    echo "Baixando ${PKG_TARBALL}..."
    curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${GREP_SRC_URL}"
fi

cd "${LFS_WORKDIR}"
rm -rf "${PKG_NAME}"
tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
cd "${PKG_NAME}"

./configure --prefix=/usr \
            --host="${LFS_TGT}" \
            --build="$(./build-aux/config.guess)"

make

reset_destdir
make DESTDIR="${LFS_DESTDIR}" install

register_installed_files "${STEP_ID}"
sync_destdir_to_rootfs

echo "Grep-3.12 (temporário) instalado em ${LFS_ROOTFS}."
