#!/usr/bin/env bash
#
# Gzip-1.14 (ferramenta temporária) - LFS 6.11

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${SCRIPT_DIR}/common.sh"

STEP_ID="gzip-1.14-temp"

PKG_NAME="gzip-1.14"
PKG_TARBALL="${PKG_NAME}.tar.xz"
GZIP_URL_DEFAULT="https://ftp.gnu.org/gnu/gzip/${PKG_TARBALL}"
: "${GZIP_SRC_URL:=${GZIP_URL_DEFAULT}}"

if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
echo "Baixando ${PKG_TARBALL}..."
curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${GZIP_SRC_URL}"
fi

cd "${LFS_WORKDIR}"
rm -rf "${PKG_NAME}"
tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
cd "${PKG_NAME}"

./configure --prefix=/usr \
        --host="${LFS_TGT}" \
        --build="$(./config.guess)"

make

reset_destdir
make DESTDIR="${LFS_DESTDIR}" install

register_installed_files "${STEP_ID}"
sync_destdir_to_rootfs

echo "Gzip-1.14 (temporário) instalado em ${LFS_ROOTFS}."
