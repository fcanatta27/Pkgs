# /etc/profile.d/console-colors.sh - tema básico de console
#
# Mantém apenas dircolors/LS_COLORS e aliases genéricos.
# O prompt (PS1) é definido em /etc/bash/bashrc para shells Bash.

# Apenas para shells interativos
case $- in
  *i*) ;;
  *) return ;;
esac

# LS colorido (se dircolors presente)
if command -v dircolors >/dev/null 2>&1; then
  if [ -r /etc/dircolors ]; then
    eval "$(dircolors -b /etc/dircolors)"
  fi
fi

alias ls='ls --color=auto'
alias ll='ls -alF'
alias la='ls -A'

