# /etc/profile.d/power.sh
# Exibe perfil de energia ativo no shell

if [ -r /etc/sysconfig/power ]; then
    . /etc/sysconfig/power
    if [ "$LAPTOP" = "yes" ]; then
        export POWER_PROFILE="laptop"
    else
        export POWER_PROFILE="default"
    fi
fi
