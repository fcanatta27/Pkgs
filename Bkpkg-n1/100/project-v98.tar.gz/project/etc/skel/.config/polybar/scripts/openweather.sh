#!/bin/sh
# Script simples para integrar OpenWeather com a barra.
# Necessário:
#   - export OW_API_KEY="sua_chave_aqui"
#   - export OW_CITY_ID="sua_cidade_id"
#
# Use https://openweathermap.org para obter os dados.

[ -z "$OW_API_KEY" ] && echo "󰖐 ?" && exit 0
[ -z "$OW_CITY_ID" ] && echo "󰖐 ?" && exit 0

data=$(curl -fs "https://api.openweathermap.org/data/2.5/weather?id=$OW_CITY_ID&units=metric&lang=pt_br&appid=$OW_API_KEY") || {
  echo "󰖐 ?"
  exit 0
}

temp=$(printf '%s' "$data" | sed -n 's/.*"temp":[ ]*\([-0-9.]*\).*/\1/p')
icon="󰖐"

[ -n "$temp" ] && printf "%s %s°C" "$icon" "$temp" || printf "%s ?" "$icon"
