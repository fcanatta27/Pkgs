#!/bin/sh
# Lança a barra principal do 3bLinux

# Finaliza instâncias antigas
killall -q polybar

while pgrep -x polybar >/dev/null; do
  sleep 1
done

# Exemplo: lançar uma barra chamada "3bbar"
polybar 3bbar &
