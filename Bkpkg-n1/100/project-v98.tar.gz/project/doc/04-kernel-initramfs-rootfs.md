# Etapa 4 – Kernel, Initramfs e RootFS

## Kernel
Script:
```bash
lfs-build-kernel
```

Ele:
- Detecta arquitetura
- Gera `.config` base
- Compila e instala

## Initramfs
- Suporte a live-mode
- Instalador embutido
- Fallback shell

## RootFS
```bash
3blinux-make-rootfs
```

Gera um tarball limpo do sistema.
