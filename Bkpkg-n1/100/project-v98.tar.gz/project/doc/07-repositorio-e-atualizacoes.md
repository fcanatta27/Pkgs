# Repositório e Atualizações do 3bLinux

O 3bLinux usa o `pkg` como gerenciador.

## Estrutura
```text
/var/packages/categoria/programa/Buildfile
```

## Opções de repositório
- HTTP simples
- Git (recomendado)
- Mirror local

## Atualizações
```bash
pkg -Syu
```

## Boas práticas
- Versionar Buildfiles
- Assinar repositórios
- Testar em VM antes
