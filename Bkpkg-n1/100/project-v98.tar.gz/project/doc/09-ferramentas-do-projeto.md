# Ferramentas do Projeto 3bLinux

## Wrappers
- lfs-build
- lfs-full-build
- lfs-chroot
- lfs-chroot-build

## pkg / pk
- resolução de dependências
- detecção de ciclos
- uninstall seguro

## Live / Installer
- 3blinux-live-menu
- 3blinux-installer

## Como depurar
- logs por etapa
- modo shell
- sanity-checks

## Erros comuns e soluções
Cada ferramenta documenta:
- sintomas
- causa provável
- correção
