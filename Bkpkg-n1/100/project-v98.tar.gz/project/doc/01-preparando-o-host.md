# Etapa 1 – Preparando o Host

Esta etapa prepara o sistema Linux **onde você irá construir o 3bLinux**.

## Requisitos mínimos
- Linux x86_64 moderno
- Bash, coreutils, tar, xz, gcc, make
- Espaço em disco: **mínimo 20 GB**
- Usuário não-root para build

## Usuário LFS
```bash
groupadd lfs
useradd -s /bin/bash -g lfs -m -k /dev/null lfs
passwd lfs
```

## Variáveis essenciais
```bash
export LFS=/mnt/lfs
export LFS_ROOTFS=$LFS/rootfs
```

> Diferença:
> - `$LFS` é o conceito do livro
> - `$LFS_ROOTFS` é a raiz real do projeto 3bLinux

## Verificação do host
Use o script:
```bash
lfs-host-check
```

Se algo falhar, **não continue**.
