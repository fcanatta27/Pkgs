# Modo Automático – Build Completo com um Comando

Script:
```bash
3blinux-orchestrator
```

## O que ele faz
```text
host-check →
toolchain →
chroot →
sanity →
kernel →
initramfs →
iso →
test
```

## Opções
- `--skip-build`
- `--only-rootfs`
- `--only-iso`

## Logs
```text
out/logs/host/
out/logs/chroot/
out/logs/kernel/
```

Se algo falhar, o processo **para imediatamente**.
