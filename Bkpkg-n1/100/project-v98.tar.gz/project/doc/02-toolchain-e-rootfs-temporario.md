# Etapa 2 – Toolchain e RootFS Temporário

Aqui construímos:
- binutils-pass1
- gcc-pass1
- linux-headers
- glibc-pass1
- ferramentas temporárias

## Scripts envolvidos
- `lfs-build`
- `lfs-full-build`
- `lfs-scripts/*.sh`
- `common.sh`

## Fluxo
```text
host → /tmp → destdir → $LFS_ROOTFS/tools
```

## Retomada automática
Cada pacote gera um registro em:
```text
out/state/
```

Se o build parar, basta rodar novamente o comando.
