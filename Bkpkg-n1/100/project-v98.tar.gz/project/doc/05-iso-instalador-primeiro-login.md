# Etapa 5 – ISO, Instalador e Primeiro Login

## ISO
```bash
3blinux-make-iso
```

## Modo Live
- Menu TUI automático
- Pré-checks
- Shell de emergência

## Instalador
Script:
```bash
3blinux-installer
```

Ele cuida de:
- Particionamento
- Montagem
- fstab
- GRUB (UUID)
- Usuário, sudo, locale

## Primeiro login
Sistema já inicia com:
- rede ativa
- shell configurado
- logs funcionando
