#!/usr/bin/env bash
#
# Perl-5.42.0 (Capítulo 8 - dentro do chroot)
#

set -euo pipefail

PKG_NAME="perl-5.42.0"
TARBALL="${PKG_NAME}.tar.xz"
SRC_DIR="/sources"

cd "${SRC_DIR}"
rm -rf "${PKG_NAME}"
tar -xf "${TARBALL}"
cd "${PKG_NAME}"

export BUILD_ZLIB=False
export BUILD_BZIP2=0

sh Configure -des     -Dprefix=/usr     -Dvendorprefix=/usr     -Duseshrplib     -Dprivlib=/usr/lib/perl5/5.42/core_perl     -Darchlib=/usr/lib/perl5/5.42/core_perl     -Dsitelib=/usr/lib/perl5/5.42/site_perl     -Dsitearch=/usr/lib/perl5/5.42/site_perl     -Dvendorlib=/usr/lib/perl5/5.42/vendor_perl     -Dvendorarch=/usr/lib/perl5/5.42/vendor_perl

make

if [ "${LFS_SKIP_TESTS:-0}" != "1" ]; then
    make test
fi

make install

unset BUILD_ZLIB BUILD_BZIP2

echo "Perl-5.42.0 instalado com sucesso."
