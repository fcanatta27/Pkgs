#!/usr/bin/env bash
#
# Gettext-0.26 (Capítulo 8 - dentro do chroot)
#

set -euo pipefail

PKG_NAME="gettext-0.26"
TARBALL="${PKG_NAME}.tar.xz"
SRC_DIR="/sources"

cd "${SRC_DIR}"
rm -rf "${PKG_NAME}"
tar -xf "${TARBALL}"
cd "${PKG_NAME}"

./configure --prefix=/usr             --disable-static             --docdir=/usr/share/doc/gettext-0.26

make

if [ "${LFS_SKIP_TESTS:-0}" != "1" ]; then
    make check
fi

make install

echo "Gettext-0.26 instalado com sucesso."
