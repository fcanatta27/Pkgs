#!/bin/bash
# 00-config/run-all.sh - Orquestra scripts desta etapa
#
# Executa todos os scripts 0*.sh neste diretório (exceto este run-all.sh),
# em ordem lexicográfica, registrando logs individuais em /logs-00-config/.
#
set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
LOGDIR=/logs-00-config
mkdir -pv "$LOGDIR"

echo ">>> [00-config] Iniciando run-all.sh em $HERE"
echo ">>> [00-config] Logs individuais: $LOGDIR/"

shopt -s nullglob
scripts=( "$HERE"/0*.sh )
shopt -u nullglob

if [ ${#scripts[@]} -eq 0 ]; then
  echo "[00-config] Nenhum script 0*.sh encontrado em $HERE."
  exit 0
fi

idx=0
total=${#scripts[@]}

for script in "${scripts[@]}"; do
  base=$(basename "$script")
  if [ "$base" = "run-all.sh" ]; then
    continue
  fi
  if [ ! -x "$script" ]; then
    echo "[00-config] Pulando $base (não executável)."
    continue
  fi
  ((idx++))
  logfile="$LOGDIR/$base.log"
  echo ">>> [00-config] [$idx/$total] Executando $base (log: $logfile)"
  if bash "$script" 2>&1 | tee "$logfile"; then
    echo "[00-config] $base concluído com sucesso."
  else
    echo "[00-config] ERRO ao executar $base (veja $logfile)."
    exit 1
  fi
done

echo ">>> [00-config] run-all.sh concluído."
