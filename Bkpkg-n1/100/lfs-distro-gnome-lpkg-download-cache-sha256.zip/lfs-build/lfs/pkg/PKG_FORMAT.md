
# Formato de pacote (.pkg) para lpkg

Exemplo de pacote:

```sh
NAME=bash
VERSION=5.2
TARBALL=bash-5.2.tar.xz
CATEGORY=core
DEPS="ncurses readline"

BUILD() {
  ./configure --prefix=/usr
  make
  make install
}
```

Campos:
- NAME: nome lógico do pacote
- VERSION: versão
- TARBALL: nome do tarball em /sources
- CATEGORY: diretório lógico no repositório
- DEPS: lista de dependências (por nome de pacote), opcional
- BUILD(): função shell que compila e instala o pacote

lpkg mantém:
- /var/lib/lpkg/installed : pacotes instalados
- /var/lib/lpkg/world     : pacotes explicitamente solicitados (world set)
