
#!/bin/bash
set -euo pipefail
ISO_NAME=${ISO_NAME:-lfs-distro.iso}
WORKDIR=${WORKDIR:-/tmp/lfs-iso-work}
ROOTFS=${ROOTFS:-rootfs}
[ -d "$ROOTFS" ] || { echo "Rootfs $ROOTFS inexistente"; exit 1; }
rm -rf "$WORKDIR"; mkdir -p "$WORKDIR"
rsync -aHAX "$ROOTFS"/ "$WORKDIR"/
cat > "$WORKDIR/boot/grub/grub.cfg" << 'EOF'
set default=0
set timeout=5
menuentry "LFS Distro (ISO)" {
    linux /boot/vmlinuz root=/dev/ram0 rw
    initrd /boot/initrd.img
}
EOF
grub-mkrescue -o "$ISO_NAME" "$WORKDIR"
echo "ISO gerada: $ISO_NAME"
