
# /etc/profile.d/dev-tools.sh - ajustes para ambiente de desenvolvimento

# Preferir /usr/local/bin para ferramentas instaladas pelo usuário
export PATH=/usr/local/bin:$PATH

# Se existir compile_commands.json, clangd usa por padrão; nada a fazer aqui.

# Aviso rápido na primeira sessão de login
if [ -z "${LFS_DEV_BANNER_SHOWN:-}" ]; then
  export LFS_DEV_BANNER_SHOWN=1
  echo "=> Ambiente de desenvolvimento LFS pronto. Use 'dev-session' para começar a codar."
fi
