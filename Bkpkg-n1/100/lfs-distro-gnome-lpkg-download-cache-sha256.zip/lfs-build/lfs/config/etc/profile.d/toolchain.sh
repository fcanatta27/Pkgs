# /etc/profile.d/toolchain.sh - Ajustes de ambiente para desenvolvimento C/C++

# Este arquivo é aplicado via template a partir de lfs/config/etc/profile.d/toolchain.sh.
# Ajuste conforme preciso para o seu ambiente final.

# Adiciona /usr/local/bin e /usr/local/sbin à frente do PATH
if ! echo "$PATH" | grep -q "/usr/local/bin"; then
  export PATH="/usr/local/bin:/usr/local/sbin:$PATH"
fi

# Convenções de compilador padrão
export CC=${CC:-gcc}
export CXX=${CXX:-g++}
export MAKEFLAGS=${MAKEFLAGS:--j$(nproc)}
