
# Git Workflow Oficial da LFS Distro

## Estrutura de branches

- `main` ou `master`:
  - estado "estável" da distro
  - SEM commits experimentais
- `develop`:
  - integração de features antes de ir para main
- `feature/*`:
  - branches para novas funcionalidades
  - exemplo: `feature/lpkg-manifest`, `feature/gnome-44`

## Tags de release

- Formato sugerido: `vMAJOR.MINOR.PATCH`
  - exemplo: `v1.0.0`, `v1.1.0`
- Cada tag aponta para um commit em `main` que:
  - builda completamente
  - gera ISO bootável
  - tem changelog/documentação atualizada

## Processo de release sugerido

1. Desenvolver em `feature/*`
2. Abrir PR/MR para `develop`
3. Testar build completo (toolchain + chroot + 30-system + kernel + configs)
4. Gerar ISO via `lfs/iso/make-iso.sh`
5. Testar instalação com `lfs/installer/text-installer.sh`
6. Merge `develop` → `main`
7. Tag `vX.Y.Z`
8. Publicar ISO e changelog

## Diretórios principais no repositório

- `10-toolchain/` – scripts de toolchain
- `20-chroot-base/` – scripts base dentro do chroot
- `30-system/` – Cap. 8 (userspace + GNOME)
- `40-kernel-bootloader/` – kernel + GRUB
- `50-config/` – configs finais
- `lfs/config/etc/` – templates de /etc
- `lfs/scripts/` – ferramentas auxiliares (lpkg, instalador, sanity-check)
- `lfs/iso/` – geração de ISO
- `lfs/profiles/` – perfis (server, desktop, notebook, etc.)
- `lfs/doc/` – documentação oficial (HOWTO, best practices, etc.)

## Commits

- Mensagens curtas e expressivas:
  - `toolchain: fix GCC pass2 flags`
  - `gnome: add mutter/gnome-shell build scripts`
  - `lpkg: add manifest-based removal`
