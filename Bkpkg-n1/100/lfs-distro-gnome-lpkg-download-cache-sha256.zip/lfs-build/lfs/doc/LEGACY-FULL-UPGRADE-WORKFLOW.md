
# LEGACY-FULL-UPGRADE-WORKFLOW.md

Este documento descreve o **fluxo definitivo recomendado** para atualizar pacotes *legacy*
(pré-lpkg) de forma **segura, auditável e reprodutível**, tanto em uso manual quanto em CI.

Ele usa os helpers:
- `lfs-legacy-upstream-check.sh`
- `lfs-legacy-full-upgrade.sh`
- `lfs-legacy-mkmanifest.sh`
- `lfs-legacy-remove.sh`

---

## 1. Visão geral do fluxo

O ciclo completo é sempre:

1. **Dry-run completo**
2. **Upgrade real (download + build)**
3. **Geração/atualização de manifest**
4. **Checklist de validação pós-upgrade**
5. *(Opcional)* Commit/registro do estado

Nunca pule o dry-run em pacotes críticos.

---

## 2. Etapa 1 – Dry-run completo

Objetivo: validar **configuração, URLs, versões e comandos** sem tocar no sistema.

Comando padrão:

```bash
lfs-legacy-full-upgrade.sh NOME --dry-run-full
```

Exemplos:

```bash
lfs-legacy-full-upgrade.sh bash --dry-run-full
lfs-legacy-full-upgrade.sh coreutils --dry-run-full
lfs-legacy-full-upgrade.sh firefox --dry-run-full
```

O dry-run valida:

- existência de `/lfs/config/legacy-pkgs.d/NOME.conf`
- coerência `NAME == NOME`
- presença de `CURRENT_VERSION`
- expansão correta de `TARBALL_TEMPLATE`
- comandos que **seriam** executados

Logs:

```text
/var/log/lfs-legacy-full-upgrade.log
```

**Critério de aprovação**:
- nenhuma mensagem de ERRO
- URL do tarball correta
- script de build existente

---

## 3. Etapa 2 – Upgrade real

Após dry-run aprovado.

### 3.1. Modo interativo (recomendado manualmente)

```bash
lfs-legacy-full-upgrade.sh bash
```

O script:

1. Checa upstream
2. Pergunta versão alvo
3. Baixa tarball
4. Builda
5. Gera manifest automaticamente

### 3.2. Modo não interativo (CI)

```bash
lfs-legacy-full-upgrade.sh coreutils   --version 9.5   --non-interactive
```

Requisitos:
- `CURRENT_VERSION` correto no `.conf`
- sem prompts pendentes

---

## 4. Etapa 3 – Manifest

O manifest é gerado automaticamente em:

```text
/var/lib/lfs-legacy-manifests/NOME.files
```

Características:
- snapshot before/after em `/usr /etc /var` (default)
- backup automático do manifest antigo (`.bak`)
- log dedicado:

```text
/var/log/lfs-legacy-mkmanifest.log
```

Nunca edite manifests automaticamente sem revisão para pacotes críticos.

---

## 5. Etapa 4 – Checklist pós-upgrade

### 5.1. Bash

```bash
bash --version
echo $SHELL
exec bash -l
```

Verifique:
- shell inicia corretamente
- não há warnings estranhos
- scripts básicos funcionam

### 5.2. Coreutils

```bash
ls --version
cp --version
stat /bin/bash
```

Verifique:
- comandos básicos funcionam
- sem segfaults
- permissões preservadas

### 5.3. Firefox

```bash
firefox --version
firefox --no-remote
```

Verifique:
- abre interface gráfica
- carrega páginas HTTPS
- integra com GNOME (se aplicável)

Logs úteis:

```text
~/.mozilla/firefox/*/console.log
journalctl --user
```

---

## 6. Etapa 5 – Rollback (se necessário)

Se algo falhar:

1. Use o manifest para remoção segura:

```bash
lfs-legacy-remove.sh --dry-run NOME
lfs-legacy-remove.sh --yes NOME
```

2. Restaure tarball antigo:

```bash
ls /sources/legacy-backups/
```

3. Rebuild com versão anterior.

---

## 7. Uso em CI (pipeline sugerido)

Pseudo-fluxo:

```bash
for pkg in bash coreutils firefox; do
  lfs-legacy-full-upgrade.sh "$pkg" --dry-run-full || exit 1
  lfs-legacy-full-upgrade.sh "$pkg" --version "$VERSION" --non-interactive || exit 1
done
```

Critérios de CI:
- dry-run sempre passa
- build retorna 0
- manifest gerado
- logs arquivados

---

## 8. Regras de ouro

- Nunca atualizar `bash` e `coreutils` juntos no mesmo ciclo.
- Sempre reiniciar shell após upgrade do bash.
- Sempre testar Firefox fora de sessões críticas.
- Manter manifests versionados (git).

---

**Este fluxo é o padrão oficial para pacotes legacy nesta distro.**
