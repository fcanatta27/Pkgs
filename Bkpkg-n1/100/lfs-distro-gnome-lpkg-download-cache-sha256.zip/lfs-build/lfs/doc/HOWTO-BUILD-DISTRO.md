
# HOWTO-BUILD-DISTRO – Guia Completo

Este documento descreve, de ponta a ponta, como:

- preparar o host
- rodar cada fase (toolchain, chroot, sistema, kernel, configs)
- gerar uma ISO bootável
- rodar o instalador e aplicar perfis
- usar o `lpkg` depois da instalação
- criar scripts de construção para o `lpkg`

---

## 1. Preparar o host

Requisitos gerais do host:

- Sistema Linux já instalado (qualquer distro estável)
- Ferramentas básicas de desenvolvimento:
  - gcc, g++, make, bash, coreutils, tar, gzip, bzip2, xz, perl, python3, etc.

Passos sugeridos:

```bash
# 1) Criar usuário dedicado para build (opcional, mas recomendado)
sudo useradd -m -s /bin/bash lfs
sudo passwd lfs

# 2) Adicionar lfs ao grupo sudo/wheel se quiser sudo
sudo usermod -aG wheel lfs

# 3) Clonar ou extrair o repositório da LFS Distro
# (abaixo, assumindo que /home/lfs/lfs-build é o diretório do projeto)
```

Defina o ambiente LFS (exemplo genérico; ajuste conforme seu layout):

```bash
export LFS=/mnt/lfs
sudo mkdir -pv $LFS
sudo chown -v lfs:lfs $LFS
```

Dentro do diretório `lfs-build/`, rode os scripts de preparação:

```bash
cd /home/lfs/lfs-build

# Ajustar variáveis, checar host, etc.
bash 00-config/run-all.sh
```

---

## 2. Rodar cada fase

### 2.1. Fase 10 – Toolchain (host)

Dentro do host (não chroot), como usuário de build:

```bash
cd /home/lfs/lfs-build
bash 10-toolchain/run-all.sh
```

Isso vai:

- Compilar binutils/gcc temporários
- Compilar libc e toolchain final
- Registrar logs em `logs-10-toolchain/`

### 2.2. Entrar no chroot

Há um script específico (em 20-chroot-base) chamado `000-enter-chroot.sh`
que deve ser chamado a partir do host. Exemplo de comando dentro do host:

```bash
sudo bash 20-chroot-base/000-enter-chroot.sh
```

Dentro do chroot, você estará no ambiente LFS final com `/` apontando
para o sistema em construção.

### 2.3. Fase 20 – Base do sistema (Cap. 7)

Dentro do **chroot**:

```bash
cd /20-chroot-base
bash run-all.sh
```

### 2.4. Fase 30 – Sistema (Cap. 8 + GNOME)

Ainda no chroot:

```bash
cd /30-system
bash run-all.sh
```

Isto inclui:

- Coreutils, grep, sed, shadow, util-linux, etc.
- systemd
- Stack de fontes
- Deps de GUI (Wayland, libdrm, GTK, etc.)
- Stack GNOME (mutter, gnome-shell, gdm, gnome-terminal, etc.)

### 2.5. Fase 40 – Kernel e Bootloader

Ainda no chroot:

```bash
cd /40-kernel-bootloader
bash 010-kernel-build.sh
```

Isso irá:

- Localizar `linux-*.tar.*` em `/sources`
- Extrair para `linux-src`
- Reaproveitar `/boot/config-linux` ou `/boot/config-$(uname -r)` se existirem
- Rodar `make olddefconfig` ou `make defconfig`
- Compilar com `-j$(nproc)`
- Rodar `make modules_install`
- Rodar `make install` (instala kernel em `/boot`)
- Copiar `.config` para `/boot/config-linux`
- Ajustar `/usr/src/linux` → kernel atual

Helper para GRUB (opcional):

```bash
cd /40-kernel-bootloader
TARGET_DISK=/dev/sda bash 020-grub-install-config.sh
```

Este script:

- Gera `/boot/grub/grub.cfg` (se `grub-mkconfig` existir)
- Instala o GRUB em `$TARGET_DISK` (se definido e válido)

### 2.6. Fase 50 – Configurações finais

Ainda no chroot:

```bash
cd /50-config
bash run-all.sh
```

Aqui, são aplicadas configs em `/etc`, perfis de usuário, shell, systemd, etc.

---

## 3. Gerar a ISO bootável

Assumindo que você já tem o sistema final em um diretório `rootfs/` (por exemplo,
montado em outro lugar, ou copiado do chroot):

```bash
cd lfs/iso

# Por padrão, ROOTFS=rootfs e ISO_NAME=lfs-distro.iso
bash make-iso.sh
```

Saída:

- `lfs-distro.iso` no diretório atual.

Você pode customizar:

```bash
ISO_NAME=my-lfs.iso ROOTFS=/mnt/lfs-root bash make-iso.sh
```

---

## 4. Rodar o instalador e aplicar perfis

Ao bootar com a ISO (ou outra mídia) que contenha essa árvore de arquivos):

### 4.1. Instalador em modo texto

Dentro do ambiente live (já root no sistema futuro):

```bash
cd /lfs/installer
bash text-installer.sh
```

O instalador irá:

- Perguntar hostname
- Criar usuário padrão e senha
- Habilitar serviços essenciais (networkd, resolved, timesyncd)
- Perguntar perfil:
  - base
  - server
  - desktop
  - notebook
  - wm
- Gerar e/ou instalar GRUB (se você fornecer o disco)
- Registrar log em `/install.log`

### 4.2. Perfis

Os perfis são descritos em:

```bash
lfs/profiles/BASE.md
lfs/profiles/SERVER.md
lfs/profiles/DESKTOP.md
lfs/profiles/NOTEBOOK.md
lfs/profiles/WM.md
```

Eles descrevem qual `target` default do systemd usar (multi-user vs graphical),
quais serviços habilitar, etc.

---

## 5. Usando lpkg depois da instalação

Após ter o sistema instalado e rodando, você pode usar o `lpkg` como gerenciador
simples de pacotes (portage-like).

### 5.1. Conceitos

- `REPO_ROOT` (default `/lfs/pkg/repos`):
  - Onde ficam os arquivos `.pkg` (receitas)
- `SRC_DIR` (default `/sources`):
  - Onde ficam os tarballs de código-fonte
- `DB_ROOT` (`/var/lib/lpkg`):
  - `installed` – banco de pacotes instalados
  - `world` – pacotes explicitamente solicitados
  - `manifests/` – lista de arquivos instalados por pacote

### 5.2. Comandos básicos

Listar pacotes disponíveis:

```bash
lpkg list
```

Informação de um pacote:

```bash
lpkg info bash
```

Instalar pacote (com resolução de dependências e detecção de ciclos):

```bash
lpkg install bash
```

Ver banco de instalados:

```bash
lpkg installed
```

Ver world set:

```bash
lpkg world
```

Remover pacote (com remoção de arquivos via manifest):

```bash
lpkg remove bash
```

Upgrade de pacote:

```bash
lpkg upgrade bash
```

### 5.3. Como funciona a remoção com manifest

Ao instalar qualquer pacote via `lpkg install`:

1. O `lpkg` tira um snapshot do filesystem em diretórios padrão:
   - `/bin`, `/sbin`, `/usr`, `/lib`, `/lib64`, `/etc`, `/var`, `/opt`
2. Executa o `BUILD()` do pacote.
3. Tira outro snapshot.
4. Calcula a diferença (`comm`) e grava a lista de caminhos novos em:
   - `/var/lib/lpkg/manifests/<NOME>.files`

Na remoção:

- Lê essa lista de caminhos, tenta remover arquivos/links, depois diretórios.
- Atualiza banco `installed` e `world`.

> Observação: é importante usar o sistema de forma relativamente “imutável” durante instal/uninstall,
> para evitar ruídos no manifest.

---

## 6. Criando scripts de construção para o lpkg

Cada pacote é descrito por um arquivo `.pkg` em `lfs/pkg/repos/<categoria>/`.

Exemplo: `lfs/pkg/repos/core/bash.pkg`

```sh
NAME=bash
VERSION=5.2
TARBALL=bash-5.2.tar.xz
CATEGORY=core
DEPS="ncurses readline"

BUILD() {
  ./configure --prefix=/usr               --without-bash-malloc

  make
  make install
}
```

### 6.1. Passos para criar um novo pacote

1. Copie o tarball para `/sources`:
   ```bash
   cp nome-do-pacote-1.2.3.tar.xz /sources/
   ```

2. Crie o arquivo `.pkg`:
   ```bash
   mkdir -p /lfs/pkg/repos/misc
   cat > /lfs/pkg/repos/misc/meu-pacote.pkg << 'EOF'
   NAME=meu-pacote
   VERSION=1.2.3
   TARBALL=meu-pacote-1.2.3.tar.xz
   CATEGORY=misc
   DEPS="glib2"

   BUILD() {
     ./configure --prefix=/usr
     make
     make install
   }
   EOF
   ```

3. Instale via `lpkg`:
   ```bash
   lpkg install meu-pacote
   ```

O `lpkg` irá:

- Extrair `/sources/meu-pacote-1.2.3.tar.xz` para um diretório temporário.
- Rodar `BUILD()`.
- Atualizar banco de instalados.
- Gerar manifest de arquivos (`/var/lib/lpkg/manifests/meu-pacote.files`).

### 6.2. Boas práticas para scripts BUILD()

- Preserve a semântica de `make check` se possível:
  ```sh
  make
  make check || true
  make install
  ```
- Evite mexer fora de `/usr`, `/etc`, `/var` sem necessidade.
- Não faça `rm -rf /usr` (óbvio, mas fica o registro).

---

## 7. Resumo

1. Host preparado + `00-config` + `10-toolchain` no host.
2. Entrar no chroot via `000-enter-chroot.sh`.
3. Rodar `20-chroot-base/run-all.sh`.
4. Rodar `30-system/run-all.sh` (userspace + GNOME).
5. Rodar `40-kernel-bootloader/010-kernel-build.sh` (e opcionalmente `020-grub-install-config.sh`).
6. Rodar `50-config/run-all.sh`.
7. Opcionalmente gerar ISO (`lfs/iso/make-iso.sh`).
8. Instalar em máquina real (via ISO + instalador).
9. Usar `lpkg` para gerenciar pacotes adicionais.

Este guia, junto com os demais documentos em `lfs/doc/`, forma o manual oficial
de operação da sua LFS Distro.

---

## Sanity pós-perfil (Notebook/Desktop + GNOME)

Depois de aplicar um perfil via instalador (`lfs-install-profile.sh` chamado por `installer/apply-profile.sh`),
o script de sanity roda automaticamente:

```bash
/50-config/090-post-profile-sanity-check.sh
```

Ele grava um log em:

```text
/var/log/post-profile-sanity.log
```

Este log é parseado pelo instalador para mostrar um resumo na tela. As linhas mais importantes têm o formato:

```text
ÁUDIO: OK - ...
ÁUDIO: AVISOS - ...

BATERIA: OK - ...
Nenhuma bateria detectada (provavelmente desktop).
BATERIA: AVISOS - ...

SESSÃO GNOME: OK - ...
SESSÃO GNOME: AVISOS - ...

FIREFOX: OK - ...
FIREFOX: AVISOS - ...
FIREFOX: ERRO - ...
```

### Exemplos de saída e interpretação

#### 1. Caso típico: notebook saudável

```text
=== CHECK: ÁUDIO ===
ÁUDIO: OK - Serviços e dispositivos básicos parecem presentes.

=== CHECK: BATERIA ===
BATERIA: OK - Bateria detectada.
BATERIA DETALHES: state: discharging  percentage: 92%

=== CHECK: SESSÃO GNOME ===
SESSÃO GNOME: OK - GDM, sessão e gnome-shell parecem presentes.

=== CHECK: FIREFOX ===
FIREFOX: OK - Navegador instalado e acessível. Firefox 147.0.1

=== CHECK: GPU/VIDEO ===
GPU DETECTADA: 00:02.0 VGA compatible controller: Intel Corporation ...
GPU DRIVER: driver gráfico kernel parece carregado (nouveau/i915/amdgpu detectado).
```

Interpretação:

- Áudio e dispositivos OK
- Bateria detectada e com carga
- GNOME + GDM prontos para login gráfico
- Firefox funcional
- GPU com driver carregado

#### 2. Desktops sem bateria (esperado)

```text
=== CHECK: ÁUDIO ===
ÁUDIO: OK - Serviços e dispositivos básicos parecem presentes.

=== CHECK: BATERIA ===
Nenhuma bateria detectada (provavelmente desktop).
BATERIA: AVISOS - Ambiente tratado como desktop; verifique se isso é esperado.

=== CHECK: SESSÃO GNOME ===
SESSÃO GNOME: OK - GDM, sessão e gnome-shell parecem presentes.

=== CHECK: FIREFOX ===
FIREFOX: OK - Navegador instalado e acessível. Firefox 147.0.1
```

Interpretação:

- A linha "Nenhuma bateria detectada (provavelmente desktop)." indica que a máquina foi tratada como desktop.
- O status "BATERIA: AVISOS" é esperado em desktops, não é um erro.

#### 3. Problema no GNOME/GDM

```text
=== CHECK: SESSÃO GNOME ===
SESSÃO GNOME: AVISOS - gdm.service não está instalado/registrado. Arquivos de sessão GNOME (.desktop) não encontrados ...
```

Interpretação:

- GNOME ou GDM não foram instalados corretamente.
- Volte para o chroot, rode os scripts GNOME correspondentes em `30-system/8xx-*` e repita o sanity-check.

#### 4. Problema no Firefox

```text
=== CHECK: FIREFOX ===
FIREFOX: ERRO - Binário firefox não encontrado no PATH.
```

Interpretação:

- O Firefox não foi instalado ou não está no PATH.
- Verifique o script de build do Firefox (em `30-system/99x-firefox-*`) e o `.conf` legacy (se estiver usando modo legacy).
- Reinstale e rode novamente o sanity-check.

### Como re-rodar o sanity-check manualmente

Após corrigir algum problema (por exemplo, reinstalar GNOME ou Firefox), você pode reexecutar:

```bash
/50-config/090-post-profile-sanity-check.sh
```

E depois olhar novamente:

```bash
less /var/log/post-profile-sanity.log
```

O instalador usa esse log para construir a tela de resumo pós-perfil. Se o log estiver limpo (ÁUDIO/SESSÃO GNOME/FIREFOX com "OK" e a mensagem de bateria coerente com o hardware), o sistema está pronto para o primeiro reboot.
## Pós-30-system: sanity consolidado do núcleo

Depois de rodar todos os pacotes do Cap. 8 via:

```bash
cd /30-system
./run-all.sh
```

recomenda-se executar o sanity consolidado do núcleo:

```bash
cd /30-system
./999-post-check.sh
```

ou, de forma integrada:

```bash
cd /30-system
./run-all.sh --post-check
```

Esse script verifica rapidamente:

- **e2fsprogs**: `e2fsck -V`, `tune2fs -V`
- **systemd**: `systemctl --version` e diretórios de units
- **shadow**: presença de `passwd`, `useradd`, `userdel`, `groupadd`, `groupdel`, `login`
- **util-linux**: `fdisk --version` e presença de `lsblk`, `mount`, `umount`, `swapon`

Ao final, ele imprime um resumo:

```text
===== RESUMO PÓS-30-SYSTEM =====
OK:
  - e2fsprogs
  - systemd
AVISOS:
  - shadow (comandos faltando: ...)
  - util-linux (ver comandos essenciais no PATH)
```

Antes de gerar a ISO ou rodar o instalador, certifique-se de que não há AVISOS
críticos neste resumo. Em pipelines de CI, este sanity pode ser usado como gate
obrigatório para considerar a build "aprovada" para geração de imagem.
