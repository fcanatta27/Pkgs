
# LEGACY-PACKAGES-HOWTO.md
#
# Gerenciamento de pacotes "pré-lpkg" (scripts antigos) com:
#   - lfs-legacy-upstream-check.sh
#   - lfs-legacy-upgrade.sh
#   - lfs-legacy-remove.sh
#
# Focado em manter **consistência** com o estilo antigo (scripts em 30-system/),
# mas adicionando um pouco de automação e segurança.

## 1. Conceito geral

Antes do `lpkg`, seus pacotes eram gerenciados por:
- tarballs em `/sources`
- scripts de build em `/30-system/NNN-nome.sh`
- instalação direta em `/usr`, `/etc`, `/var`, etc.

Os scripts "legacy" aqui não tentam virar um gerenciador de pacotes complexo.
Eles só ajudam a:

1. Descobrir se existe versão nova de um pacote no upstream.
2. Baixar a versão nova e, opcionalmente, rodar o script de build correspondente.
3. Remover arquivos de um pacote antigo usando um `manifest` gerado por você.

Tudo é baseado em **configs simples** e **files lists explícitas**.

---

## 2. Configuração básica de um pacote legacy

As configs ficam em:

```text
/lfs/config/legacy-pkgs.d/
```

Cada pacote tem um arquivo `NOME.conf`. Exemplo para `gnome-calculator`:

```sh
# /lfs/config/legacy-pkgs.d/gnome-calculator.conf

NAME=gnome-calculator
CURRENT_VERSION=45.0

UPSTREAM_URL="https://download.gnome.org/sources/gnome-calculator/"
VERSION_REGEX='gnome-calculator-([0-9][0-9.]*).tar'

TARBALL_TEMPLATE="https://download.gnome.org/sources/gnome-calculator/%{version}/gnome-calculator-%{version}.tar.xz"
SOURCES_PATTERN="gnome-calculator-*.tar.*"

BUILD_SCRIPT="/30-system/994-gnome-calculator.sh"

# Manifest (para remoção):
# Se você não definir, o script assume:
#   /var/lib/lfs-legacy-manifests/gnome-calculator.files
MANIFEST="/var/lib/lfs-legacy-manifests/gnome-calculator.files"
```

### 2.1. Campos obrigatórios

- `NAME` – nome lógico do pacote (usado nos scripts).
- `CURRENT_VERSION` – versão atual que você considera "instalada".
- `UPSTREAM_URL` – URL de índice/dir onde dá pra enxergar as versões (HTML, listagem).
- `VERSION_REGEX` – regex para extrair versões dos nomes dos tarballs.

### 2.2. Campos recomendados

- `TARBALL_TEMPLATE` – template de URL para baixar o tarball da versão desejada;
  use `%{version}` como placeholder da versão.
- `SOURCES_PATTERN` – padrão do tarball em `/sources` para backups (ex.: `gnome-calculator-*.tar.*`).
- `BUILD_SCRIPT` – caminho do script de build pré-lpkg em `/30-system`.

### 2.3. Campo opcional

- `MANIFEST` – arquivo com a lista de arquivos que o pacote instalou.
  - Se não definir, o script assume `/var/lib/lfs-legacy-manifests/NAME.files`.

---

## 3. Gerando um manifest de arquivos (para remoção limpa)

Para poder remover um pacote limpamente, você precisa de um `manifest`:

```text
/var/lib/lfs-legacy-manifests/gnome-calculator.files
```

Cada linha: um caminho absoluto, por exemplo:

```text
/usr/bin/gnome-calculator
/usr/share/applications/gnome-calculator.desktop
/usr/share/icons/hicolor/48x48/apps/gnome-calculator.png
...
```

### 3.1. Jeito prático via snapshot de `find`

Exemplo: você vai instalar `gnome-calculator` via script `30-system/994-gnome-calculator.sh`.

1. Tire uma foto do estado antes:

   ```bash
   find /usr /etc /var -xdev -type f -o -type l | sort > /tmp/before-gnome-calculator.txt
   ```

2. Rode o script de build/instalação:

   ```bash
   cd /30-system
   bash 994-gnome-calculator.sh
   ```

3. Tire a foto do depois:

   ```bash
   find /usr /etc /var -xdev -type f -o -type l | sort > /tmp/after-gnome-calculator.txt
   ```

4. Gere o diff:

   ```bash
   comm -13 /tmp/before-gnome-calculator.txt /tmp/after-gnome-calculator.txt \
       > /var/lib/lfs-legacy-manifests/gnome-calculator.files
   ```

5. Opcional: revise o manifest para garantir que não entrou nada estranho.

Pronto: agora o `lfs-legacy-remove.sh` consegue remover o pacote de forma limpa.

---

## 4. Verificando versões novas (lfs-legacy-upstream-check.sh)

Script:

```text
lfs/bin/lfs-legacy-upstream-check.sh
```

Uso:

```bash
# Checar todos os pacotes configurados
lfs-legacy-upstream-check.sh

# Checar apenas um pacote
lfs-legacy-upstream-check.sh gnome-calculator
```

Exemplo de saída:

```text
--------------------------------------------------------
[LEGACY-UPSTREAM] Pacote: gnome-calculator
  Versão atual conhecida: 45.0
  Upstream URL: https://download.gnome.org/sources/gnome-calculator/
  Última versão encontrada: 46.0
  [UPDATE DISPONÍVEL] 45.0 -> 46.0
```

Se a regex não bater, você verá:

```text
  [WARN] Nenhuma versão encontrada usando regex: ...
```

Ajuste `VERSION_REGEX` conforme o HTML/listagem real.

---

## 5. Atualizando um pacote (lfs-legacy-upgrade.sh)

Script:

```text
lfs/bin/lfs-legacy-upgrade.sh
```

### 5.1. Caso 1 – descobrir última versão e escolher

```bash
lfs-legacy-upgrade.sh gnome-calculator
```

Fluxo:

1. Carrega `/lfs/config/legacy-pkgs.d/gnome-calculator.conf`.
2. Chama `lfs-legacy-upstream-check.sh gnome-calculator` para mostrar versões.
3. Pergunta:

   ```text
   [LEGACY-UPGRADE] Digite a versão alvo desejada (ENTER para manter 45.0):
   ```

4. Monta a URL do tarball usando:

   ```text
   TARBALL_TEMPLATE=".../%{version}/gnome-calculator-%{version}.tar.xz"
   ```

5. Move tarballs antigos que batem com `SOURCES_PATTERN` para `/sources/legacy-backups/`.
6. Baixa o tarball novo para `/sources/gnome-calculator-<versão>.tar.xz`.
7. Se `BUILD_SCRIPT` estiver definido e for executável, roda `bash $BUILD_SCRIPT`.

Depois disso, você pode (se quiser) atualizar `CURRENT_VERSION` no `.conf` para refletir a nova versão.

### 5.2. Caso 2 – forçar uma versão específica

```bash
lfs-legacy-upgrade.sh gnome-calculator --version 46.0
```

- Não chama o upstream-check; vai direto para baixar usando `TARBALL_TEMPLATE` preenchido com `46.0`.

### 5.3. Caso 3 – só baixar o tarball, sem rebuild

```bash
lfs-legacy-upgrade.sh gnome-calculator --version 46.0 --no-build
```

- Útil se você planeja rodar o script de build manualmente ou quer só preparar os fontes.

### 5.4. Erros comuns e como lidar

- `Config não encontrada`: certifique-se de ter um `NOME.conf` em `/lfs/config/legacy-pkgs.d/`.
- `TARBALL_TEMPLATE não definido`: ajuste seu `.conf` com uma URL de template correta.
- `Tarball não encontrado (404)`: verifique se a versão que você escolheu existe no upstream.

---

## 6. Removendo um pacote (lfs-legacy-remove.sh)

Script evoluído:

```text
lfs/bin/lfs-legacy-remove.sh
```

### 6.1. Comportamento

- Lê a config `/lfs/config/legacy-pkgs.d/NOME.conf`.
- Determina o `MANIFEST`:
  - se `MANIFEST` estiver definido: usa esse valor;
  - senão: assume `/var/lib/lfs-legacy-manifests/NOME.files`.
- Lê a lista de arquivos do manifest.
- **Protege** contra caminhos perigosos, por exemplo:
  - `/`, `/usr`, `/etc`, `/bin`, `/sbin`, `/lib`, `/lib64` (diretamente) nunca serão removidos.
- Mostra cada arquivo que seria removido (ou remove de fato).
- Tenta limpar diretórios vazios relacionados (heurística simples).
- Loga tudo em:
  - `/var/log/lfs-legacy-remove.log`.

### 6.2. Uso básico

```bash
# Remoção "dry-run": só mostra o que faria
lfs-legacy-remove.sh --dry-run gnome-calculator

# Remoção real, perguntando confirmação
lfs-legacy-remove.sh gnome-calculator

# Remover múltiplos pacotes de uma vez
lfs-legacy-remove.sh bash coreutils gnome-calculator
```

Por padrão, para cada pacote ele pergunta:

```text
[LEGACY-REMOVE] Deseja realmente remover o pacote 'gnome-calculator'? [y/N]
```

### 6.3. Modo não interativo (--yes)

Se você quiser rodar scripts automatizados (CI, scripts de manutenção), use:

```bash
lfs-legacy-remove.sh --yes gnome-calculator
```

ou

```bash
lfs-legacy-remove.sh --dry-run --yes gnome-calculator
```

- `--yes` pula a confirmação para **todos** os pacotes.
- `--dry-run` nunca deleta nada; apenas loga/mostra o que faria.

### 6.4. Logs

Todos os eventos são registrados em:

```text
/var/log/lfs-legacy-remove.log
```

Exemplo de linhas:

```text
2026-01-22 15:00:01 [LEGACY-REMOVE] Pacote legacy: gnome-calculator
2026-01-22 15:00:01 rm -f -- /usr/bin/gnome-calculator
2026-01-22 15:00:01 [INFO] rmdir /usr/share/gnome-calculator
...
```

Se algo falhar (por exemplo, manifest ausente), você verá:

```text
[LEGACY-REMOVE] Manifest não existe: /var/lib/lfs-legacy-manifests/gnome-calculator.files (pacote gnome-calculator)
```

---

## 7. Fluxo completo recomendado (exemplo real com gnome-calculator)

1. **Configurar** o pacote legacy:

   ```bash
   cat > /lfs/config/legacy-pkgs.d/gnome-calculator.conf << 'EOF'
   NAME=gnome-calculator
   CURRENT_VERSION=45.0
   UPSTREAM_URL="https://download.gnome.org/sources/gnome-calculator/"
   VERSION_REGEX='gnome-calculator-([0-9][0-9.]*).tar'
   TARBALL_TEMPLATE="https://download.gnome.org/sources/gnome-calculator/%{version}/gnome-calculator-%{version}.tar.xz"
   SOURCES_PATTERN="gnome-calculator-*.tar.*"
   BUILD_SCRIPT="/30-system/994-gnome-calculator.sh"
   MANIFEST="/var/lib/lfs-legacy-manifests/gnome-calculator.files"
   EOF
   ```

2. **Gerar manifest** na próxima instalação/upgrade do pacote (via diferenciar before/after).

3. **Checar se há versão nova:**

   ```bash
   lfs-legacy-upstream-check.sh gnome-calculator
   ```

4. **Atualizar para a última versão (e rebuildar):**

   ```bash
   lfs-legacy-upgrade.sh gnome-calculator
   ```

5. **Validar se o programa funciona** (abrir o app, rodar testes).

6. **Se precisar remover o pacote:**

   ```bash
   lfs-legacy-remove.sh --dry-run gnome-calculator  # revisar o que será removido
   lfs-legacy-remove.sh --yes gnome-calculator      # remover de fato
   ```

7. **Rever logs**:

   ```bash
   less /var/log/lfs-legacy-remove.log
   ```

---

## 8. Dicas gerais e problemas comuns

- Sempre mantenha os `.conf` sob controle de versão (Git) junto com o resto da distro.
- Gere manifests logo após instalar/atualizar um pacote, enquanto o delta de arquivos está bem definido.
- Se um manifest estiver errado, **não** rode o remove em modo real; corrija o manifest primeiro.
- Se `lfs-legacy-upstream-check.sh` não encontrar versões, inspeccione o HTML da URL e ajuste `VERSION_REGEX`.
- Para pacotes muito críticos (glibc, systemd), prefira o fluxo via `lpkg` ou processo manual extremamente controlado;
  use os scripts legacy apenas para pacotes relativamente isolados (apps, libs de alto nível).



---

## 9. Exemplos prontos de .conf

Este repositório já inclui alguns exemplos de configuração em:

```text
/lfs/config/legacy-pkgs.d/bash.conf
/lfs/config/legacy-pkgs.d/coreutils.conf
/lfs/config/legacy-pkgs.d/firefox.conf
```

Eles foram preenchidos com:

- URLs de upstream reais (GNU, Mozilla);
- regexes de versão para nomes típicos de tarball;
- TARBALL_TEMPLATE prontos para uso;
- caminhos de BUILD_SCRIPT apontando para scripts em `/30-system`;
- caminhos de MANIFEST em `/var/lib/lfs-legacy-manifests/*.files`.

Para adaptá-los ao seu ambiente, você normalmente só precisará ajustar:
- `CURRENT_VERSION` (quando subir de versão);
- locale/arquitetura no caso do Firefox (por exemplo, `pt-BR` em vez de `en-US`);
- o nome exato do script de build em `/30-system` se ele for diferente do exemplo.


---

## 10. Gerando manifests automaticamente (lfs-legacy-mkmanifest.sh)

Para não precisar rodar `find` e `comm` na mão, você pode usar o helper:

```text
lfs/bin/lfs-legacy-mkmanifest.sh
```

Uso básico (usando BUILD_SCRIPT definido no .conf):

```bash
lfs-legacy-mkmanifest.sh gnome-calculator
```

Isso irá:

1. Tirar snapshot BEFORE em `/usr /etc /var`.
2. Executar o comando de build correspondente (por exemplo `bash /30-system/994-gnome-calculator.sh`).
3. Tirar snapshot AFTER.
4. Gerar o manifest em `/var/lib/lfs-legacy-manifests/gnome-calculator.files`
   (ou no caminho `MANIFEST` definido no `.conf`), com backup se já existir.

Exemplos avançados:

```bash
# Usar diretórios extras e comando de build customizado
lfs-legacy-mkmanifest.sh firefox --dirs "/usr /etc /var /opt"             --build-cmd "bash /30-system/995-firefox-147.0.1.sh"

# Reutilizar snapshots BEFORE/AFTER já capturados manualmente (não roda build)
lfs-legacy-mkmanifest.sh bash             --before /tmp/before-bash.txt             --after  /tmp/after-bash.txt             --no-build
```

O log das operações fica em:

```text
/var/log/lfs-legacy-mkmanifest.log
```
