
# lpkg - Uso Básico

## Listar pacotes
```bash
lpkg list
```

## Informações de um pacote
```bash
lpkg info bash
```

## Instalar pacote com dependências
```bash
lpkg install bash
```

## Ver banco de instalados
```bash
lpkg installed
```

## Ver world set
```bash
lpkg world
```

## Remover pacote
```bash
lpkg remove bash
```

(arquivos não são apagados ainda; apenas metadata)

## Upgrade
```bash
lpkg upgrade bash
```
