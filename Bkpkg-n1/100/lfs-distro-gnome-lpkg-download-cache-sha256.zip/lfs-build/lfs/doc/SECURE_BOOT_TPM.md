# Secure Boot + TPM (esqueleto conceitual)
