# DEV-ENVIRONMENT.md

Este documento descreve como aplicar os templates de configuração fornecidos em
`lfs/config/etc` para transformar a instalação em uma *dev workstation* padronizada.

## 1. Base: copiar templates para /etc

Assumindo que você já está rodando no sistema instalado (como root) e que o
conteúdo de `lfs/config/etc` foi copiado para algum lugar acessível (por exemplo
`/usr/share/lfs-config-templates`), siga passos como:

```bash
TEMPLATES=/usr/share/lfs-config-templates
```

### 1.1. Readline (`inputrc`)

```bash
install -v -m 644 "$TEMPLATES/inputrc" /etc/inputrc
```

### 1.2. Bash global (`bash.bashrc`)

```bash
install -v -m 644 "$TEMPLATES/bash.bashrc" /etc/bash.bashrc
```

### 1.3. Toolchain profile (`profile.d/toolchain.sh`)

```bash
install -d -m 755 /etc/profile.d
install -v -m 644 "$TEMPLATES/profile.d/toolchain.sh" /etc/profile.d/toolchain.sh
```

Isso garante:

- PATH com `/usr/local/bin:/usr/local/sbin` na frente;
- `CC`, `CXX` e `MAKEFLAGS` padrão ajustados para uso em builds.

### 1.4. Sysctl de tuning de build

```bash
install -d -m 755 /etc/sysctl.d
install -v -m 644 "$TEMPLATES/sysctl.d/90-build-tuning.conf" /etc/sysctl.d/90-build-tuning.conf
sysctl --system
```

Opcionalmente, habilite o serviço dedicado (veja seção 3).

### 1.5. Vim

```bash
install -d -m 755 /etc/vim
install -v -m 644 "$TEMPLATES/vim/vimrc" /etc/vim/vimrc
```

Isso ativa:

- syntax highlight, `filetype plugin indent on`;
- numeração relativa, `colorcolumn=80`;
- indentação com espaços (`tabstop=4`, `shiftwidth=4`, `expandtab`).

## 2. Configurações por usuário (git, tmux)

### 2.1. Git (`~/.gitconfig`)

Como usuário normal:

```bash
cp -v "$TEMPLATES/gitconfig" ~/.gitconfig
vim ~/.gitconfig  # Ajuste name/email
```

### 2.2. tmux extra

Se você já tiver um `~/.tmux.conf`, pode incluir o extra assim:

```bash
mkdir -p ~/.config/lfs
cp -v "$TEMPLATES/tmux-extra.conf" ~/.config/lfs/tmux-extra.conf
echo "source-file ~/.config/lfs/tmux-extra.conf" >> ~/.tmux.conf
```

## 3. Systemd: serviços de dev

### 3.1. Serviço de sysctl de build

```bash
install -d -m 755 /etc/systemd/system
install -v -m 644 "$TEMPLATES/systemd/system/dev-build-sysctl.service" /etc/systemd/system/dev-build-sysctl.service

systemctl daemon-reload
systemctl enable dev-build-sysctl.service
```

Isso garante que, a cada boot, o `sysctl --system` será chamado com o arquivo
`/etc/sysctl.d/90-build-tuning.conf` em vigor.

### 3.2. Serviço de tmux por usuário

```bash
install -d -m 755 /etc/systemd/user
install -v -m 644 "$TEMPLATES/systemd/user/dev-tmux@.service" /etc/systemd/user/dev-tmux@.service
```

Como usuário normal, para habilitar uma sessão chamada `dev`:

```bash
systemctl --user daemon-reload
systemctl --user enable dev-tmux@dev.service
systemctl --user start dev-tmux@dev.service
```

Isso garante que uma sessão `tmux` chamada `dev` esteja sempre disponível.

## 4. clangd global

Para tornar o `clangd` mais amigável para todos os projetos que usam
`compile_commands.json`:

```bash
install -v -m 644 "$TEMPLATES/clangd.conf" /etc/clangd.conf
```

## 5. Checagem final

Depois de aplicar estas configurações:

1. Abra um terminal novo e confirme:
   - `echo $CC`, `echo $CXX`, `echo $MAKEFLAGS`;
   - comportamento de histórico/teclas no bash.
2. Abra o Vim e valide:
   - numeração relativa, highlight, coluna 80.
3. Rode `systemctl status dev-build-sysctl.service` (se habilitado).
4. Rode `systemctl --user status dev-tmux@dev.service` (se habilitado).

Com isso, sua workstation de desenvolvimento fica padronizada e pronta para uso.
