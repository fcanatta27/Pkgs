
# Perfil Desktop GNOME (Wayland)

Stack: Mesa, Wayland, GTK4, Mutter, GNOME Shell, GDM, PipeWire, NetworkManager.
GNOME funciona em Wayland por padrão.
