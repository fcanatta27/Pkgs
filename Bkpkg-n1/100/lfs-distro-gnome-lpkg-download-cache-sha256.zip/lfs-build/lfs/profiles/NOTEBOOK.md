# NOTEBOOK
- Desktop + hardening
