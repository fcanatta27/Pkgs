# DESKTOP
- GNOME + GDM + Wayland
