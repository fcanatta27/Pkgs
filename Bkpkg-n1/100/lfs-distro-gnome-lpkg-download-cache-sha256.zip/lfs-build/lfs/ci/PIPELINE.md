# Skeleton de CI para builds reprodutíveis
