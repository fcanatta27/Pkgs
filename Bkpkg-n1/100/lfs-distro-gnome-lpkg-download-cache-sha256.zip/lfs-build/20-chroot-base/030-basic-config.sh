
#!/bin/bash
# 030-basic-config.sh - Configurações básicas: /etc/hosts, /etc/issue, etc.

set -euo pipefail

echo "[INFO] Configurando /etc/hosts mínimo..."

if [ ! -f /etc/hosts ]; then
  cat > /etc/hosts << 'EOF'
127.0.0.1  localhost
::1        localhost
EOF
  echo "[OK] /etc/hosts criado."
else
  echo "[SKIP] /etc/hosts já existe; mantendo arquivo atual."
fi

if [ ! -f /etc/issue ]; then
  echo "LFS (sistema em construção)" > /etc/issue
  echo "[OK] /etc/issue criado."
fi

echo "[OK] Configuração básica concluída."
