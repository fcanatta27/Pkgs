
#!/bin/bash
# 000-enter-chroot.sh - Monta sistemas de arquivos virtuais e entra no chroot LFS.

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
# shellcheck source=/dev/null
source "$ROOT_DIR/00-config/env.sh"

if [ ! -d "$LFS" ]; then
  echo "[FATAL] Diretório LFS ($LFS) não existe."
  exit 1
fi

echo "[INFO] Montando sistemas de arquivos virtuais em $LFS..."

sudo mountpoint -q "$LFS/dev" || sudo mount --bind /dev "$LFS/dev"
sudo mountpoint -q "$LFS/dev/pts" || sudo mount -t devpts devpts "$LFS/dev/pts" -o gid=5,mode=620
sudo mountpoint -q "$LFS/proc" || sudo mount -t proc proc "$LFS/proc"
sudo mountpoint -q "$LFS/sys"  || sudo mount -t sysfs sysfs "$LFS/sys"
sudo mountpoint -q "$LFS/run"  || sudo mount -t tmpfs tmpfs "$LFS/run"

if [ -h "$LFS/dev/shm" ]; then
  sudo mkdir -pv "$LFS/$(readlink "$LFS/dev/shm")"
fi

echo "[INFO] Entrando em chroot em $LFS..."

sudo chroot "$LFS" /usr/bin/env -i       HOME=/root       TERM="$TERM"       PS1='(lfs chroot) \u:\w\$ '       PATH=/usr/bin:/usr/sbin       /bin/bash --login
