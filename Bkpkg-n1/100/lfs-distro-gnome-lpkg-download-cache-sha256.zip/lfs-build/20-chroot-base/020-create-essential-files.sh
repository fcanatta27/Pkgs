
#!/bin/bash
# 020-create-essential-files.sh - Cria arquivos essenciais (passwd, group, logs) no chroot.

set -euo pipefail

echo "[INFO] Criando /etc/passwd e /etc/group mínimos..."

if [ ! -f /etc/passwd ]; then
  cat > /etc/passwd << 'EOF'
root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/dev/null:/usr/bin/false
daemon:x:6:6:Daemon User:/dev/null:/usr/bin/false
messagebus:x:18:18:D-Bus Message Daemon User:/run/dbus:/usr/bin/false
nobody:x:99:99:Unprivileged User:/dev/null:/usr/bin/false
EOF
  echo "[OK] /etc/passwd criado."
else
  echo "[SKIP] /etc/passwd já existe; mantendo arquivo atual."
fi

if [ ! -f /etc/group ]; then
  cat > /etc/group << 'EOF'
root:x:0:
bin:x:1:
daemon:x:6:
sys:x:3:
adm:x:4:
tty:x:5:
disk:x:8:
lp:x:7:
mail:x:12:
kmem:x:9:
wheel:x:10:
cdrom:x:11:
audio:x:17:
video:x:16:
input:x:24:
kvm:x:61:
render:x:110:
tty:x:5:
users:x:100:
nogroup:x:99:
EOF
  echo "[OK] /etc/group criado."
else
  echo "[SKIP] /etc/group já existe; mantendo arquivo atual."
fi

echo "[INFO] Criando arquivos de log em /var/log..."
touch /var/log/{btmp,lastlog,faillog,wtmp}
chmod 600 /var/log/btmp
chmod 664 /var/log/lastlog /var/log/faillog /var/log/wtmp
chgrp utmp /var/log/lastlog /var/log/wtmp 2>/dev/null || true

echo "[OK] Arquivos essenciais criados/atualizados."
