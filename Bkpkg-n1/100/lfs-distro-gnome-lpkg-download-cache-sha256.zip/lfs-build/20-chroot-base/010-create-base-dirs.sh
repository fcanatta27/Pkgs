
#!/bin/bash
# 010-create-base-dirs.sh - Cria hierarquia básica de diretórios (Cap. 7 - Creating Directories)

set -euo pipefail

echo "[INFO] Criando diretórios básicos do sistema..."

mkdir -pv /{boot,home,mnt,opt,media}
mkdir -pv /etc/{opt,sysconfig}
mkdir -pv /lib/firmware
mkdir -pv /usr/{bin,lib,sbin}
mkdir -pv /usr/local/{bin,lib,sbin}
mkdir -pv /var/{log,mail,spool}
mkdir -pv /var/{opt,cache,lib,local}
mkdir -pv /var/log/old

# Links simbólicos recomendados para sistemas modernos (sem /usr split)
case $(uname -m) in
  x86_64)
    ln -sfv lib /lib64
    ;;
esac

ln -sfv usr/bin /bin
ln -sfv usr/sbin /sbin
ln -sfv usr/lib /lib

echo "[OK] Diretórios e links básicos criados."
