#!/bin/bash
# 090-post-profile-sanity-check.sh - Sanity-check pós-perfil GNOME (notebook/desktop)
#
# Este script roda após a aplicação de perfil (notebook ou desktop) e valida:
#   - ÁUDIO   -> presença de serviços e teste simples de saída (speaker-test se disponível)
#   - BATERIA -> detecção de bateria ou confirmação de desktop
#   - SESSÃO GNOME -> presença de GDM e arquivos de desktop/sessão GNOME
#   - FIREFOX -> binário acessível e teste básico
#   - GPU/VIDEO -> detecção de placa e driver básico (informativo)
#
# As mensagens são geradas em um formato que o installer/apply-profile.sh sabe parsear:
#
#   ÁUDIO: OK / AVISOS / ERRO
#   BATERIA: OK / AVISOS / ERRO
#   SESSÃO GNOME: OK / AVISOS / ERRO
#   FIREFOX: OK / AVISOS / ERRO
#   (e a frase "Nenhuma bateria detectada (provavelmente desktop)" quando aplicável)
#
# Log principal:
#   /var/log/post-profile-sanity.log
#
set -euo pipefail

LOG=/var/log/post-profile-sanity.log
mkdir -pv "$(dirname "$LOG")" >/dev/null 2>&1 || true
: > "$LOG" 2>/dev/null || true

log() {
  echo "$1"
  printf '%s\n' "$1" >> "$LOG" 2>/dev/null || true
}

have_cmd() {
  command -v "$1" >/dev/null 2>&1
}

check_audio() {
  log "=== CHECK: ÁUDIO ==="

  local status="OK"
  local details=()

  # Verificar serviços PipeWire/Pulse/ALSA
  if have_cmd systemctl; then
    for unit in pipewire.service pipewire-pulse.service wireplumber.service pulseaudio.service alsa-restore.service; do
      if systemctl list-unit-files 2>/dev/null | grep -q "^${unit}"; then
        if ! systemctl is-enabled "$unit" >/dev/null 2>&1; then
          details+=( "Unidade $unit existe mas NÃO está habilitada." )
          status="AVISOS"
        fi
      fi
    done
  fi

  # Teste rápido: checar presença de dispositivos OSS/ALSA básicos
  if [ ! -e /dev/snd ] && [ ! -e /dev/audio ]; then
    details+=( "Nenhum dispositivo de áudio detectado em /dev/snd ou /dev/audio." )
    status="AVISOS"
  fi

  # Teste opcional: speaker-test se disponível (não disparamos por padrão para não gerar ruído)
  if have_cmd speaker-test; then
    details+=( "speaker-test encontrado (teste manual recomendado)." )
  fi

  if [ "$status" = "OK" ]; then
    log "ÁUDIO: OK - Serviços e dispositivos básicos parecem presentes."
  else
    log "ÁUDIO: AVISOS - ${details[*]:-Verifique configuração de áudio.}"
  fi
}

check_battery() {
  log "=== CHECK: BATERIA ==="

  local status="OK"
  local details=()
  local has_battery=0

  if have_cmd upower; then
    if upower -e 2>/dev/null | grep -qi "battery"; then
      has_battery=1
    fi
  fi

  if [ $has_battery -eq 0 ] && [ -d /sys/class/power_supply ]; then
    if ls /sys/class/power_supply 2>/dev/null | grep -qi "BAT"; then
      has_battery=1
    fi
  fi

  if [ $has_battery -eq 1 ]; then
    # Notebook
    if have_cmd upower; then
      details+=( "$(upower -i "$(upower -e | grep -i battery | head -n1)" 2>/dev/null | grep -E 'state|percentage' || true)" )
    fi
    log "BATERIA: OK - Bateria detectada."
    if [ "${#details[@]}" -gt 0 ]; then
      log "BATERIA DETALHES: ${details[*]}"
    fi
  else
    # Provavelmente desktop
    log "Nenhuma bateria detectada (provavelmente desktop)."
    log "BATERIA: AVISOS - Ambiente tratado como desktop; verifique se isso é esperado."
  fi
}

check_gnome_session() {
  log "=== CHECK: SESSÃO GNOME ==="

  local status="OK"
  local details=()

  # GDM habilitado?
  if have_cmd systemctl; then
    if systemctl list-unit-files 2>/dev/null | grep -q "^gdm.service"; then
      if ! systemctl is-enabled gdm.service >/dev/null 2>&1; then
        details+=( "gdm.service existe mas NÃO está habilitado." )
        status="AVISOS"
      fi
    else
      details+=( "gdm.service não está instalado/registrado." )
      status="AVISOS"
    fi
  fi

  # Arquivos básicos de sessão GNOME
  if [ ! -f /usr/share/xsessions/gnome.desktop ] && [ ! -f /usr/share/wayland-sessions/gnome.desktop ]; then
    details+=( "Arquivos de sessão GNOME (.desktop) não encontrados em /usr/share/xsessions/ ou /usr/share/wayland-sessions/." )
    status="AVISOS"
  fi

  # gnome-shell presente?
  if ! command -v gnome-shell >/dev/null 2>&1; then
    details+=( "gnome-shell não encontrado no PATH." )
    status="AVISOS"
  fi

  if [ "$status" = "OK" ]; then
    log "SESSÃO GNOME: OK - GDM, sessão e gnome-shell parecem presentes."
  else
    log "SESSÃO GNOME: AVISOS - ${details[*]:-Verifique instalação do GNOME/GDM.}"
  fi
}

check_firefox() {
  log "=== CHECK: FIREFOX ==="

  local status="OK"
  local details=()

  if ! command -v firefox >/dev/null 2>&1; then
    details+=( "Binário firefox não encontrado no PATH." )
    status="ERRO"
  else
    # Teste simples de versão
    if ! firefox --version >/dev/null 2>&1; then
      details+=( "firefox --version retornou erro." )
      status="AVISOS"
    else
      details+=( "$(firefox --version 2>/dev/null | head -n1)" )
    fi
  fi

  # Checar .desktop
  if [ ! -f /usr/share/applications/firefox.desktop ]; then
    details+=( "firefox.desktop não encontrado em /usr/share/applications/." )
    [ "$status" = "OK" ] && status="AVISOS"
  fi

  if [ "$status" = "OK" ]; then
    log "FIREFOX: OK - Navegador instalado e acessível. ${details[*]:-}"
  elif [ "$status" = "AVISOS" ]; then
    log "FIREFOX: AVISOS - ${details[*]:-Verifique instalação do Firefox.}"
  else
    log "FIREFOX: ERRO - ${details[*]:-Firefox ausente ou quebrado.}"
  fi
}

check_gpu() {
  log "=== CHECK: GPU/VIDEO ==="

  # Este bloco é apenas informativo; o installer não parseia essas linhas.
  if command -v lspci >/dev/null 2>&1; then
    local vga
    vga=$(lspci 2>/dev/null | grep -i 'vga' || true)
    if [ -n "$vga" ]; then
      log "GPU DETECTADA: $vga"
    else
      log "GPU DETECTADA: Nenhuma entrada 'VGA' encontrada no lspci."
    fi
  else
    log "GPU DETECTADA: lspci não disponível; passe pciutils para ver placa de vídeo."
  fi

  # Verificar presença de drivers básicos no filesystem (heurístico)
  if lsmod 2>/dev/null | grep -qiE 'nouveau|i915|amdgpu'; then
    log "GPU DRIVER: driver gráfico kernel parece carregado (nouveau/i915/amdgpu detectado)."
  else
    log "GPU DRIVER: nenhum módulo gráfico típico detectado (nouveau/i915/amdgpu)."
  fi
}

main() {
  log "========================================================"
  log "SANITY-CHECK PÓS-PERFIL - INÍCIO"

  check_audio
  check_battery
  check_gnome_session
  check_firefox
  check_gpu

  log "SANITY-CHECK PÓS-PERFIL - FIM"
}

main "$@"
