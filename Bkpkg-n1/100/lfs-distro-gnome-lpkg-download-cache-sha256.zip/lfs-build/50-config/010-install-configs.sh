
#!/bin/bash
# 010-install-configs.sh - instala configs em /etc, /etc/skel e helpers em /usr/local/bin a partir de /lfs/config

set -euo pipefail

SRC_BASE=/lfs/config

if [ ! -d "$SRC_BASE" ]; then
  echo "[WARN] Diretório $SRC_BASE não encontrado; nada para instalar."
  exit 0
fi

echo "[INFO] Instalando configs de $SRC_BASE em /etc, /etc/skel e /usr/local/bin..."

# ---- /etc ----
if [ -d "$SRC_BASE/etc" ]; then
  cd "$SRC_BASE/etc"
  find . -type d -print0 | while IFS= read -r -d '' d; do
    target="/etc/${d#./}"
    [ -d "$target" ] || mkdir -pv "$target"
  done

  find . -type f -print0 | while IFS= read -r -d '' f; do
    rel="${f#./}"
    src="$SRC_BASE/etc/$rel"
    dest="/etc/$rel"
    if [ -e "$dest" ]; then
      echo "[SKIP] $dest já existe; não sobrescrevendo."
    else
      echo "[INSTALL] $dest"
      install -m 0644 "$src" "$dest"
    fi
  done
fi

# ---- /etc/skel ----
if [ -d "$SRC_BASE/skel" ]; then
  mkdir -pv /etc/skel
  echo "[INFO] Copiando skeleton de usuário para /etc/skel (sem sobrescrever existentes)."
  cd "$SRC_BASE/skel"
  find . -type d -print0 | while IFS= read -r -d '' d; do
    target="/etc/skel/${d#./}"
    [ -d "$target" ] || mkdir -pv "$target"
  done

  find . -type f -print0 | while IFS= read -r -d '' f; do
    rel="${f#./}"
    src="$SRC_BASE/skel/$rel"
    dest="/etc/skel/$rel"
    if [ -e "$dest" ]; then
      echo "[SKIP] $dest já existe; não sobrescrevendo."
    else
      echo "[INSTALL] $dest"
      install -m 0644 "$src" "$dest"
    fi
  done
fi

# ---- /usr/local/bin (dev helpers) ----
if [ -d "$SRC_BASE/dev-bin" ]; then
  echo "[INFO] Instalando helpers de desenvolvimento em /usr/local/bin..."
  mkdir -pv /usr/local/bin
  cd "$SRC_BASE/dev-bin"
  find . -type f -maxdepth 1 -print0 | while IFS= read -r -d '' f; do
    rel="${f#./}"
    src="$SRC_BASE/dev-bin/$rel"
    dest="/usr/local/bin/$rel"
    if [ -e "$dest" ]; then
      echo "[SKIP] $dest já existe; não sobrescrevendo."
    else
      echo "[INSTALL] $dest"
      install -m 0755 "$src" "$dest"
    fi
  done
fi

# ---- systemd default target ----
if command -v systemctl >/dev/null 2>&1; then
  echo "[INFO] Configurando alvo padrão do systemd para multi-user.target (se possível)."
  systemctl set-default multi-user.target || true
fi

echo "[OK] Configurações instaladas."
