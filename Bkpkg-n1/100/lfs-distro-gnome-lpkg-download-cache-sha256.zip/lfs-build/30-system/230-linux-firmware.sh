#!/bin/bash
# 230-linux-firmware.sh - Instala firmware do kernel (linux-firmware)
#
# Este script procura um tarball linux-firmware-*.tar.* em /sources,
# extrai para /build/linux-firmware-src e copia o conteúdo para /lib/firmware.
#
set -euo pipefail

SRC_DIR=/sources
BUILD_DIR=/build

echo "[INFO] Instalando linux-firmware a partir de $SRC_DIR..."

tarball=$(ls "$SRC_DIR"/linux-firmware-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[ERRO] Tarball linux-firmware-*.tar.* não encontrado em $SRC_DIR." >&2
  exit 1
fi

rm -rf "$BUILD_DIR/linux-firmware-src"
mkdir -pv "$BUILD_DIR/linux-firmware-src"
cd "$BUILD_DIR/linux-firmware-src"

tar xf "$tarball"
cd linux-firmware-*

# Cria destino se necessário
install -vd /lib/firmware

echo "[INFO] Copiando firmware para /lib/firmware (isso pode demorar)..."
cp -av * /lib/firmware

# Sanity mínimo: diretório não vazio
if [ ! -d /lib/firmware ] || [ -z "$(ls -A /lib/firmware 2>/dev/null)" ]; then
  echo "[WARN] /lib/firmware parece vazio após instalação do linux-firmware."
else
  echo "[OK] linux-firmware instalado em /lib/firmware."
fi

echo "[INFO] 230-linux-firmware.sh concluído."
