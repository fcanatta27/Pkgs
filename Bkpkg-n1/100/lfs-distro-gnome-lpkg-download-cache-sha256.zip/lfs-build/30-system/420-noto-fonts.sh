
#!/bin/bash
# 420-noto-fonts.sh - Noto fonts (subset conforme tarball)

set -euo pipefail

cd /sources

tarball=$(ls noto-fonts-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do noto-fonts não encontrado em /sources."
  exit 0
fi

rm -rf noto-src
mkdir -v noto-src
tar -xf "$tarball" -C noto-src --strip-components=1
cd noto-src

mkdir -pv /usr/share/fonts/noto
find . -type f \( -name '*.ttf' -o -name '*.otf' \) -exec install -m0644 -t /usr/share/fonts/noto {} +

if command -v fc-cache >/dev/null 2>&1; then
  fc-cache -f
fi

cd /sources
rm -rf noto-src

echo "[OK] Noto fonts instaladas."
