#!/bin/bash
# 560-alsa-lib.sh - ALSA library

set -euo pipefail

cd /sources

tarball=$(ls alsa-lib-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do alsa-lib não encontrado em /sources."
  exit 0
fi

rm -rf alsa-lib-src
mkdir -v alsa-lib-src
tar -xf "$tarball" -C alsa-lib-src --strip-components=1
cd alsa-lib-src

./configure --prefix=/usr --disable-static || true

make || true
make check || true
make install || true

cd /sources
rm -rf alsa-lib-src

echo "[OK] alsa-lib instalado (se build OK)."
