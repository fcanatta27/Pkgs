#!/bin/bash
# 590-libsoup.sh - libsoup (HTTP client/server GNOME)

set -euo pipefail

cd /sources

tarball=$(ls libsoup-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do libsoup não encontrado em /sources."
  exit 0
fi

rm -rf libsoup-src
mkdir -v libsoup-src
tar -xf "$tarball" -C libsoup-src --strip-components=1
cd libsoup-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --buildtype=release || true

  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf libsoup-src

echo "[OK] libsoup instalado (se build OK)."
