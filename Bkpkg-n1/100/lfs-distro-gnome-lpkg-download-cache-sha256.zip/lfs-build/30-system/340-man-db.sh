
#!/bin/bash
# 340-man-db.sh - Man-db (visualizador de manpages)

set -euo pipefail

cd /sources

tarball=$(ls man-db-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do man-db não encontrado em /sources."
  exit 0
fi

rm -rf man-db-src
mkdir -v man-db-src
tar -xf "$tarball" -C man-db-src --strip-components=1
cd man-db-src

./configure \
    --prefix=/usr \
    --docdir=/usr/share/doc/man-db \
    --sysconfdir=/etc \
    --disable-setuid \
    --enable-mandirs=/usr/share/man \
    --with-browser=lynx \
    --with-vgrind=vim \
    --with-grap=no

make
make check || true
make install

cd /sources
rm -rf man-db-src

echo "[OK] Man-db instalado em /usr."
