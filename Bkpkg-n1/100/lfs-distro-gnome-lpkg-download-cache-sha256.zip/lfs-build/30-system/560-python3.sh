
#!/bin/bash
# 560-python3.sh - Python 3

set -euo pipefail

cd /sources

tarball=$(ls Python-3*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do Python3 não encontrado em /sources."
  exit 0
fi

rm -rf python3-src
mkdir -v python3-src
tar -xf "$tarball" -C python3-src --strip-components=1
cd python3-src

./configure \
    --prefix=/usr \
    --enable-shared \
    --with-system-expat \
    --with-system-ffi \
    --enable-optimizations

make
make test || true
make install

# pip básico pode vir junto; se existir ensurepip, rodar
if command -v python3 >/dev/null 2>&1; then
  python3 -m ensurepip --upgrade || true
fi

cd /sources
rm -rf python3-src

echo "[OK] Python 3 instalado em /usr."
