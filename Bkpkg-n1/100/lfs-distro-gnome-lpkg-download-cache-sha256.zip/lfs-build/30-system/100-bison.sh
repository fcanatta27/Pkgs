
#!/bin/bash
# 100-bison.sh - Bison (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls bison-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do bison não encontrado em /sources."
  exit 0
fi

rm -rf bison-src
mkdir -v bison-src
tar -xf "$tarball" -C bison-src --strip-components=1
cd bison-src

pkgver=$(echo "${tarball##*/}" | sed 's/bison-\(.*\)\.tar.*/\1/')

./configure     --prefix=/usr     --docdir=/usr/share/doc/bison-"$pkgver"

make
make check || true
make install

cd /sources
rm -rf bison-src

echo "[OK] Bison instalado em /usr."
