
#!/bin/bash
# 010-man-pages.sh - Instalação das man-pages (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls man-pages-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball das man-pages não encontrado em /sources."
  exit 0
fi

rm -rf man-pages-src
mkdir -v man-pages-src
tar -xf "$tarball" -C man-pages-src --strip-components=1
cd man-pages-src

make prefix=/usr install

cd /sources
rm -rf man-pages-src

echo "[OK] Man-pages instaladas em /usr/share/man."
