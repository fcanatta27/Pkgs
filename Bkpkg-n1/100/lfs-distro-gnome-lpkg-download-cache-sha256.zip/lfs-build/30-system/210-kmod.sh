
#!/bin/bash
# 210-kmod.sh - Kmod (manipulação de módulos do kernel)

set -euo pipefail

cd /sources

tarball=$(ls kmod-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do kmod não encontrado em /sources."
  exit 0
fi

rm -rf kmod-src
mkdir -v kmod-src
tar -xf "$tarball" -C kmod-src --strip-components=1
cd kmod-src

./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --with-xz \
    --with-zstd \
    --with-zlib

make
make check || true
make install

# Garantir symlinks para compatibilidade com modprobe/module-init-tools antigos
for prog in depmod insmod lsmod modinfo modprobe rmmod; do
  if [ -x "/usr/bin/kmod" ] && [ ! -e "/usr/bin/$prog" ] && [ ! -e "/usr/sbin/$prog" ]; then
    ln -sv kmod "/usr/bin/$prog" || true
  fi
done

cd /sources
rm -rf kmod-src

echo "[OK] Kmod instalado e symlinks de compatibilidade criados (se necessário)."
