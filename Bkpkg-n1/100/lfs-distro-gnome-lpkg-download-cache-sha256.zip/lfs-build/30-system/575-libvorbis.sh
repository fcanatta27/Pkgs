#!/bin/bash
# 575-libvorbis.sh - libvorbis (codec de áudio Ogg Vorbis)

set -euo pipefail

cd /sources

tarball=$(ls libvorbis-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do libvorbis não encontrado em /sources."
  exit 0
fi

rm -rf libvorbis-src
mkdir -v libvorbis-src
tar -xf "$tarball" -C libvorbis-src --strip-components=1
cd libvorbis-src

./configure --prefix=/usr --disable-static || true

make || true
make check || true
make install || true

cd /sources
rm -rf libvorbis-src

echo "[OK] libvorbis instalado (se build OK)."
