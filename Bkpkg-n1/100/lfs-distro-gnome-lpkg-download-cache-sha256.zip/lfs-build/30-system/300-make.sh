
#!/bin/bash
# 300-make.sh - Make final

set -euo pipefail

cd /sources

tarball=$(ls make-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do make não encontrado em /sources."
  exit 0
fi

rm -rf make-src
mkdir -v make-src
tar -xf "$tarball" -C make-src --strip-components=1
cd make-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf make-src

echo "[OK] Make instalado em /usr."
