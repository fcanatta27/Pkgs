#!/bin/bash
# 572-libcanberra.sh - libcanberra (sons de eventos para GNOME)

set -euo pipefail

cd /sources

tarball=$(ls libcanberra-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do libcanberra não encontrado em /sources."
  exit 0
fi

rm -rf libcanberra-src
mkdir -v libcanberra-src
tar -xf "$tarball" -C libcanberra-src --strip-components=1
cd libcanberra-src

./configure \
    --prefix=/usr \
    --disable-oss \
    --enable-pulse || true

make || true
make check || true
make install || true

cd /sources
rm -rf libcanberra-src

echo "[OK] libcanberra instalado (se build OK)."
