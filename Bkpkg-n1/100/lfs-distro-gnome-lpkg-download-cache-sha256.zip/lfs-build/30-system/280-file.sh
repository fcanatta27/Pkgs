
#!/bin/bash
# 280-file.sh - File

set -euo pipefail

cd /sources

tarball=$(ls file-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do file não encontrado em /sources."
  exit 0
fi

rm -rf file-src
mkdir -v file-src
tar -xf "$tarball" -C file-src --strip-components=1
cd file-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf file-src

echo "[OK] File instalado em /usr."
