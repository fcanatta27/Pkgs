
#!/bin/bash
# 130-coreutils.sh - Coreutils final (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls coreutils-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do coreutils não encontrado em /sources."
  exit 0
fi

rm -rf coreutils-src
mkdir -v coreutils-src
tar -xf "$tarball" -C coreutils-src --strip-components=1
cd coreutils-src

# Algumas versões usam patch de i18n; se existir, aplicamos.
patch_i18n=$(ls ../coreutils-*i18n*.patch 2>/dev/null | head -n1 || true)
if [ -n "$patch_i18n" ]; then
  echo "[INFO] Aplicando patch de i18n: $patch_i18n"
  patch -Np1 -i "$patch_i18n"
fi

./configure \
    --prefix=/usr \
    --enable-no-install-program=kill,uptime

make
make NON_ROOT_USERNAME=nobody check || true
make install

# Mover programas essenciais para /bin (rootfs disponível mesmo sem /usr montado)
for prog in \
  cat chgrp chmod chown cp date dd df echo false ln ls mkdir mknod \
  mv pwd rm rmdir stty sync true uname;
do
  if [ -x "/usr/bin/$prog" ]; then
    mv -v "/usr/bin/$prog" /bin/
  fi
done

# mv chroot
if [ -x /usr/bin/chroot ]; then
  mv -v /usr/bin/chroot /usr/sbin/
fi

# Corrigir manpage do chroot, se estiver em seção 1
if [ -f /usr/share/man/man1/chroot.1 ]; then
  mv -v /usr/share/man/man1/chroot.1 /usr/share/man/man8/chroot.8
  sed -i 's/"1"/"8"/' /usr/share/man/man8/chroot.8
fi

cd /sources
rm -rf coreutils-src

echo "[OK] Coreutils final instalado (binários essenciais em /bin)."
