
#!/bin/bash
# 060-bzip2.sh - Bzip2 (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls bzip2-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do bzip2 não encontrado em /sources."
  exit 0
fi

rm -rf bzip2-src
mkdir -v bzip2-src
tar -xf "$tarball" -C bzip2-src --strip-components=1
cd bzip2-src

if ls ../bzip2-*-install_docs-*.patch >/dev/null 2>&1; then
  patch_file=$(ls ../bzip2-*-install_docs-*.patch | head -n1)
  patch -Np1 -i "$patch_file"
fi

sed -i 's@\(ln -s -f \)$(PREFIX)/bin/@\1@' Makefile || true
sed -i 's@$(PREFIX)/man@$(PREFIX)/share/man@g' Makefile || true

make -f Makefile-libbz2_so
make clean
make

make PREFIX=/usr install

cp -v bzip2-shared /bin/bzip2 2>/dev/null || true
ln -sv bzip2 /bin/bunzip2 2>/dev/null || true
ln -sv bzip2 /bin/bzcat  2>/dev/null || true

cd /sources
rm -rf bzip2-src

echo "[OK] bzip2 instalado em /usr (binários principais em /bin)."
