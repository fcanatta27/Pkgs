
#!/bin/bash
# 740-glib2.sh - GLib 2.x

set -euo pipefail

cd /sources

tarball=$(ls glib-2*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do glib2 não encontrado em /sources."
  exit 0
fi

rm -rf glib2-src
mkdir -v glib2-src
tar -xf "$tarball" -C glib2-src --strip-components=1
cd glib2-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf glib2-src

echo "[OK] GLib2 instalado (se build OK)."
