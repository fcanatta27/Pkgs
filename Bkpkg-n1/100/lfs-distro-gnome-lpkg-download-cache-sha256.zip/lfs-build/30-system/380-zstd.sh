
#!/bin/bash
# 380-zstd.sh - Zstandard

set -euo pipefail

cd /sources

tarball=$(ls zstd-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do zstd não encontrado em /sources."
  exit 0
fi

rm -rf zstd-src
mkdir -v zstd-src
tar -xf "$tarball" -C zstd-src --strip-components=1
cd zstd-src

make
make install

cd /sources
rm -rf zstd-src

echo "[OK] Zstd instalado em /usr."
