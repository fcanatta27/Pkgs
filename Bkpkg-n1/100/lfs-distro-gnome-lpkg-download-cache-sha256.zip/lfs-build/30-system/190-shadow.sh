#!/bin/bash
    # 190-shadow.sh - Shadow (autenticação, contas de usuário)

    set -euo pipefail

    cd /sources

    tarball=$(ls shadow-*.tar.* 2>/dev/null | head -n1 || true)
    if [ -z "$tarball" ]; then
      echo "[SKIP] Tarball de shadow não encontrado em /sources."
      exit 0
    fi

    rm -rf shadow-src
    mkdir -v shadow-src
    tar -xf "$tarball" -C shadow-src --strip-components=1
    cd shadow-src

    ./configure       --prefix=/usr       --sysconfdir=/etc       --with-group-name-max-length=32

    make
    make check || true
    make install

    # SANITY-CHECK: comandos principais
    echo "[SANITY] Verificando comandos shadow..."

    for bin in passwd useradd userdel groupadd groupdel login; do
      if ! command -v "$bin" >/dev/null 2>&1; then
        echo "[WARN] $bin não encontrado no PATH após instalação do shadow."
      fi
    done

    cd /sources
    rm -rf shadow-src

    echo "[OK] Shadow instalado em /usr. Lembre-se de revisar /etc/login.defs, /etc/passwd e /etc/shadow conforme suas políticas."
