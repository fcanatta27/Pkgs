#!/bin/bash
# 930-gnome-themes-extra.sh - Temas extras do GNOME (adwaita-gtk2, etc.)

set -euo pipefail

cd /sources

tarball=$(ls gnome-themes-extra-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gnome-themes-extra não encontrado em /sources."
  exit 0
fi

rm -rf gnome-themes-extra-src
mkdir -v gnome-themes-extra-src
tar -xf "$tarball" -C gnome-themes-extra-src --strip-components=1
cd gnome-themes-extra-src

./configure \
    --prefix=/usr || true

make || true
make install || true

cd /sources
rm -rf gnome-themes-extra-src

echo "[OK] GNOME Themes Extra instalado (se build OK)."
