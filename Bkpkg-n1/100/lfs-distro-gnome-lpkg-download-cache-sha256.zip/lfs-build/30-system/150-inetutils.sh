
#!/bin/bash
# 150-inetutils.sh - Inetutils (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls inetutils-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do inetutils não encontrado em /sources."
  exit 0
fi

rm -rf inetutils-src
mkdir -v inetutils-src
tar -xf "$tarball" -C inetutils-src --strip-components=1
cd inetutils-src

./configure \
    --prefix=/usr \
    --localstatedir=/var \
    --disable-logger \
    --disable-whois \
    --disable-servers

make
make check || true
make install

# Alguns programas podem ser movidos dependendo da sua preferência;
# aqui mantemos o layout padrão do LFS.
echo "[OK] Inetutils instalado em /usr."

cd /sources
rm -rf inetutils-src
