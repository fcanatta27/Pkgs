
#!/bin/bash
# 520-expect.sh - Expect

set -euo pipefail

cd /sources

tarball=$(ls expect-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do expect não encontrado em /sources."
  exit 0
fi

rm -rf expect-src
mkdir -v expect-src
tar -xf "$tarball" -C expect-src --strip-components=1
cd expect-src

./configure \
    --prefix=/usr \
    --with-tcl=/usr/lib \
    --enable-shared

make
make test || true
make install

cd /sources
rm -rf expect-src

echo "[OK] Expect instalado em /usr."
