
#!/bin/bash
# 020-zlib.sh - Zlib (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls zlib-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do zlib não encontrado em /sources."
  exit 0
fi

rm -rf zlib-src
mkdir -v zlib-src
tar -xf "$tarball" -C zlib-src --strip-components=1
cd zlib-src

./configure --prefix=/usr
make
make install

rm -f /usr/lib/libz.a

cd /sources
rm -rf zlib-src

echo "[OK] Zlib instalada em /usr."
