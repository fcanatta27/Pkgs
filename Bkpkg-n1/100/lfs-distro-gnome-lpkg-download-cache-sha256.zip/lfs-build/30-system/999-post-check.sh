#!/bin/bash
# 999-post-check.sh - Sanity consolidado pós-30-system
#
# Este script deve ser executado depois de rodar 30-system/run-all.sh.
# Ele consolida checks rápidos dos componentes de núcleo:
#
#   - e2fsprogs  : e2fsck -V, tune2fs -V
#   - systemd    : systemctl --version
#   - shadow     : passwd --version (se suportado) ou presença de binários
#   - util-linux : fdisk --version
#
# Gera um resumo claro em stdout e pode ser usado também em CI.
#
set -euo pipefail

SUMMARY_OK=()
SUMMARY_WARN=()

have_cmd() {
  command -v "$1" >/dev/null 2>&1
}

check_e2fsprogs() {
  echo "=== CHECK: e2fsprogs ==="
  local ok=1

  if have_cmd e2fsck; then
    echo "[INFO] e2fsck -V:"
    e2fsck -V 2>&1 | head -n5 || true
  else
    echo "[WARN] e2fsck não encontrado no PATH."
    ok=0
  fi

  if have_cmd tune2fs; then
    echo "[INFO] tune2fs -V:"
    tune2fs -V 2>&1 | head -n3 || true
  else
    echo "[WARN] tune2fs não encontrado no PATH."
    ok=0
  fi

  if [ $ok -eq 1 ]; then
    SUMMARY_OK+=( "e2fsprogs" )
  else
    SUMMARY_WARN+=( "e2fsprogs (ver PATH/instalação)" )
  fi
}

check_systemd() {
  echo "=== CHECK: systemd ==="
  local ok=1

  if have_cmd systemctl; then
    echo "[INFO] systemctl --version:"
    systemctl --version 2>&1 | head -n5 || true
  else
    echo "[WARN] systemctl não encontrado no PATH."
    ok=0
  fi

  if [ ! -d /lib/systemd/system ] && [ ! -d /usr/lib/systemd/system ]; then
    echo "[WARN] Diretório de units systemd não encontrado."
    ok=0
  fi

  if [ $ok -eq 1 ]; then
    SUMMARY_OK+=( "systemd" )
  else
    SUMMARY_WARN+=( "systemd (ver diretórios de units/PATH)" )
  fi
}

check_shadow() {
  echo "=== CHECK: shadow ==="
  local ok=0

  # Não são todos os builds de shadow que têm --version, então focamos na presença dos binários
  local missing=()
  for bin in passwd useradd userdel groupadd groupdel login; do
    if ! have_cmd "$bin"; then
      missing+=( "$bin" )
    fi
  done

  if [ ${#missing[@]} -eq 0 ]; then
    ok=1
    echo "[INFO] Comandos shadow encontrados: passwd, useradd, userdel, login, groupadd, groupdel"
  else
    echo "[WARN] Alguns comandos shadow estão faltando: ${missing[*]}"
  fi

  if [ $ok -eq 1 ]; then
    SUMMARY_OK+=( "shadow" )
  else
    SUMMARY_WARN+=( "shadow (comandos faltando: ${missing[*]-})" )
  fi
}

check_util_linux() {
  echo "=== CHECK: util-linux ==="
  local ok=1

  if have_cmd fdisk; then
    echo "[INFO] fdisk --version:"
    fdisk --version 2>&1 | head -n3 || true
  else
    echo "[WARN] fdisk não encontrado no PATH."
    ok=0
  fi

  for bin in lsblk mount umount swapon; do
    if ! have_cmd "$bin"; then
      echo "[WARN] $bin não encontrado no PATH."
      ok=0
    fi
  done

  if [ $ok -eq 1 ]; then
    SUMMARY_OK+=( "util-linux" )
  else
    SUMMARY_WARN+=( "util-linux (ver comandos essenciais no PATH)" )
  fi
}

print_summary() {
  echo
  echo "===== RESUMO PÓS-30-SYSTEM ====="
  if [ ${#SUMMARY_OK[@]} -gt 0 ]; then
    echo "OK:"
    for s in "${SUMMARY_OK[@]}"; do
      echo "  - $s"
    done
  fi

  if [ ${#SUMMARY_WARN[@]} -gt 0 ]; then
    echo "AVISOS:"
    for s in "${SUMMARY_WARN[@]}"; do
      echo "  - $s"
    done
  else
    echo "Nenhum aviso. Núcleo do sistema parece saudável."
  fi
}

main() {
  check_e2fsprogs
  check_systemd
  check_shadow
  check_util_linux
  print_summary
}

main "$@"
