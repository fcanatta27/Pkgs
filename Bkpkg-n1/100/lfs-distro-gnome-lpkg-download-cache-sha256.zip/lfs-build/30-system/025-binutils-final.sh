#!/bin/bash
# 025-binutils-final.sh - Binutils final (Cap. 8)
#
# Este script constrói e instala a versão final do Binutils em /usr,
# substituindo a toolchain temporária. Baseado na sequência típica do LFS,
# adaptado para este projeto.
#
set -euo pipefail

cd /sources

tarball=$(ls binutils-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do binutils não encontrado em /sources."
  exit 0
fi

rm -rf binutils-src
mkdir -v binutils-src
tar -xf "$tarball" -C binutils-src --strip-components=1
cd binutils-src

mkdir -v build
cd build

../configure \
  --prefix=/usr \
  --enable-gold \
  --enable-ld=default \
  --enable-plugins \
  --enable-shared \
  --disable-werror \
  --enable-64-bit-bfd \
  --with-system-zlib

make tooldir=/usr

# Testes: podem demorar bastante; use -k para continuar mesmo com alguns fails
make -k check || true

make tooldir=/usr install

# Remover bibliotecas estáticas desnecessárias
rm -fv /usr/lib/lib{bfd,ctf,ctf-nobfd,opcodes}.a || true

cd /sources
rm -rf binutils-src

echo "[OK] Binutils final instalado em /usr."
