
#!/bin/bash
# 490-automake.sh - Automake

set -euo pipefail

cd /sources

tarball=$(ls automake-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do automake não encontrado em /sources."
  exit 0
fi

rm -rf automake-src
mkdir -v automake-src
tar -xf "$tarball" -C automake-src --strip-components=1
cd automake-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf automake-src

echo "[OK] Automake instalado em /usr."
