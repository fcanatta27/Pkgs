#!/bin/bash
# 981-upower.sh - UPower (gerenciamento de energia, integração com GNOME)

set -euo pipefail

cd /sources

tarball=$(ls upower-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do upower não encontrado em /sources."
  exit 0
fi

rm -rf upower-src
mkdir -v upower-src
tar -xf "$tarball" -C upower-src --strip-components=1
cd upower-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --sysconfdir=/etc \
      --localstatedir=/var \
      --buildtype=release || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure \
      --prefix=/usr \
      --sysconfdir=/etc \
      --localstatedir=/var || true
  make || true
  make check || true
  make install || true
fi

# Ativa serviço, se systemd estiver presente
if command -v systemctl >/dev/null 2>&1; then
  systemctl enable upower.service || true
fi

cd /sources
rm -rf upower-src

echo "[OK] UPower instalado (se build OK)."
