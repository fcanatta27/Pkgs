
#!/bin/bash
# 530-dejagnu.sh - DejaGNU

set -euo pipefail

cd /sources

tarball=$(ls dejagnu-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do dejagnu não encontrado em /sources."
  exit 0
fi

rm -rf dejagnu-src
mkdir -v dejagnu-src
tar -xf "$tarball" -C dejagnu-src --strip-components=1
cd dejagnu-src

./configure --prefix=/usr

make check || true
make install

cd /sources
rm -rf dejagnu-src

echo "[OK] DejaGNU instalado em /usr."
