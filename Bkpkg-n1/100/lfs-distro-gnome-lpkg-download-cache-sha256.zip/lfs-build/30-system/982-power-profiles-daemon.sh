#!/bin/bash
# 982-power-profiles-daemon.sh - Power Profiles Daemon (perfis de energia, usado pelo GNOME)

set -euo pipefail

cd /sources

tarball=$(ls power-profiles-daemon-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do power-profiles-daemon não encontrado em /sources."
  exit 0
fi

rm -rf power-profiles-daemon-src
mkdir -v power-profiles-daemon-src
tar -xf "$tarball" -C power-profiles-daemon-src --strip-components=1
cd power-profiles-daemon-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --sysconfdir=/etc \
      --localstatedir=/var \
      --buildtype=release || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure \
      --prefix=/usr \
      --sysconfdir=/etc \
      --localstatedir=/var || true
  make || true
  make check || true
  make install || true
fi

if command -v systemctl >/dev/null 2>&1; then
  systemctl enable power-profiles-daemon.service || true
fi

cd /sources
rm -rf power-profiles-daemon-src

echo "[OK] Power Profiles Daemon instalado (se build OK)."
