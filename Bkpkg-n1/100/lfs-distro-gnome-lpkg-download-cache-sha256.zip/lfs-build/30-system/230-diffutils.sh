
#!/bin/bash
# 230-diffutils.sh - Diffutils

set -euo pipefail

cd /sources

tarball=$(ls diffutils-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do diffutils não encontrado em /sources."
  exit 0
fi

rm -rf diffutils-src
mkdir -v diffutils-src
tar -xf "$tarball" -C diffutils-src --strip-components=1
cd diffutils-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf diffutils-src

echo "[OK] Diffutils instalado em /usr."
