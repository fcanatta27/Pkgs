
#!/bin/bash
# 400-terminus-font.sh - Terminus console/bitmap font

set -euo pipefail

cd /sources

tarball=$(ls terminus-font-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do terminus-font não encontrado em /sources."
  exit 0
fi

rm -rf terminus-src
mkdir -v terminus-src
tar -xf "$tarball" -C terminus-src --strip-components=1
cd terminus-src

# Alguns tarballs usam make setup, outros usam apenas make install
if grep -q "install-psf" Makefile 2>/dev/null; then
  make
  make install
else
  make
  make install
fi

# Garantir que fontes fiquem sob /usr/share/fonts/terminus, se aplicável
mkdir -pv /usr/share/fonts/terminus
find . -type f \( -name '*.psf*' -o -name '*.pcf*' \) -exec install -m0644 -t /usr/share/fonts/terminus {} + 2>/dev/null || true

if command -v fc-cache >/dev/null 2>&1; then
  fc-cache -f
fi

cd /sources
rm -rf terminus-src

echo "[OK] Terminus font instalado."
