#!/bin/bash
# 993-gnome-clocks.sh - GNOME Clocks (relógio mundial, alarmes, timer, cronômetro)

set -euo pipefail

cd /sources

tarball=$(ls gnome-clocks-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gnome-clocks não encontrado em /sources."
  exit 0
fi

rm -rf gnome-clocks-src
mkdir -v gnome-clocks-src
tar -xf "$tarball" -C gnome-clocks-src --strip-components=1
cd gnome-clocks-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --buildtype=release || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf gnome-clocks-src

echo "[OK] GNOME Clocks instalado (se build OK)."
