
#!/bin/bash
# 710-wayland-protocols.sh - Wayland Protocols

set -euo pipefail

cd /sources

tarball=$(ls wayland-protocols-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do wayland-protocols não encontrado em /sources."
  exit 0
fi

rm -rf wprot-src
mkdir -v wprot-src
tar -xf "$tarball" -C wprot-src --strip-components=1
cd wprot-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr || true
  ninja -C build
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make install || true
fi

cd /sources
rm -rf wprot-src

echo "[OK] Wayland-protocols instalado (se build OK)."
