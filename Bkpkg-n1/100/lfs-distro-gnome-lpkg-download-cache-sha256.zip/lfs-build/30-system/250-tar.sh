
#!/bin/bash
# 250-tar.sh - Tar

set -euo pipefail

cd /sources

tarball=$(ls tar-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do tar não encontrado em /sources."
  exit 0
fi

rm -rf tar-src
mkdir -v tar-src
tar -xf "$tarball" -C tar-src --strip-components=1
cd tar-src

./configure \
    --prefix=/usr \
    --enable-gcc-warnings=no

make
make check || true
make install

cd /sources
rm -rf tar-src

echo "[OK] Tar instalado em /usr."
