
#!/bin/bash
# 440-nerd-fonts.sh - Nerd Fonts collection (ou subset)

set -euo pipefail

cd /sources

tarball=$(ls nerd-fonts-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do nerd-fonts não encontrado em /sources."
  exit 0
fi

rm -rf nerd-src
mkdir -v nerd-src
tar -xf "$tarball" -C nerd-src --strip-components=1
cd nerd-src

mkdir -pv /usr/share/fonts/nerd-fonts
find . -type f \( -name '*.ttf' -o -name '*.otf' \) -exec install -m0644 -t /usr/share/fonts/nerd-fonts {} +

if command -v fc-cache >/dev/null 2>&1; then
  fc-cache -f
fi

cd /sources
rm -rf nerd-src

echo "[OK] Nerd Fonts instaladas."
