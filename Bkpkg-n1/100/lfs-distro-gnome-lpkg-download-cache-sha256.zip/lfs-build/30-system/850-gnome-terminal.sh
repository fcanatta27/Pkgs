#!/bin/bash
set -euo pipefail
cd /sources
tarball=$(ls gnome-terminal-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] gnome-terminal não encontrado."
  exit 0
fi
rm -rf gnome-terminal-src
mkdir -v gnome-terminal-src
tar -xf "$tarball" -C gnome-terminal-src --strip-components=1
cd gnome-terminal-src
if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr --buildtype=release || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi
cd /sources
rm -rf gnome-terminal-src
echo "[OK] gnome-terminal instalado."
