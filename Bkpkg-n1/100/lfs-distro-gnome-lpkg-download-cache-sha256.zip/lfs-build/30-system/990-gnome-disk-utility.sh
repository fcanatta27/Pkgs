#!/bin/bash
# 990-gnome-disk-utility.sh - GNOME Disks (utilitário de discos)

set -euo pipefail

cd /sources

tarball=$(ls gnome-disk-utility-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gnome-disk-utility não encontrado em /sources."
  exit 0
fi

rm -rf gnome-disk-utility-src
mkdir -v gnome-disk-utility-src
tar -xf "$tarball" -C gnome-disk-utility-src --strip-components=1
cd gnome-disk-utility-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --buildtype=release || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf gnome-disk-utility-src

echo "[OK] GNOME Disk Utility instalado (se build OK)."
