
#!/bin/bash
# 080-bc.sh - bc (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls bc-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do bc não encontrado em /sources."
  exit 0
fi

rm -rf bc-src
mkdir -v bc-src
tar -xf "$tarball" -C bc-src --strip-components=1
cd bc-src

CC=${CC:-gcc}

if [ -x ./configure ]; then
  CC=$CC ./configure --prefix=/usr -G -O3 -r
  make
  make install
else
  echo "[WARN] ./configure não encontrado para bc; ajuste manualmente conforme a versão do pacote."
fi

cd /sources
rm -rf bc-src

echo "[OK] bc (se suportado) instalado em /usr."
