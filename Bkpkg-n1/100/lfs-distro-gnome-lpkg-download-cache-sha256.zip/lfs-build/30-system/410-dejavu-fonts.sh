
#!/bin/bash
# 410-dejavu-fonts.sh - DejaVu TrueType fonts

set -euo pipefail

cd /sources

tarball=$(ls dejavu-fonts-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do dejavu-fonts não encontrado em /sources."
  exit 0
fi

rm -rf dejavu-src
mkdir -v dejavu-src
tar -xf "$tarball" -C dejavu-src --strip-components=1
cd dejavu-src

mkdir -pv /usr/share/fonts/dejavu
find . -type f -name '*.ttf' -exec install -m0644 -t /usr/share/fonts/dejavu {} +

if command -v fc-cache >/dev/null 2>&1; then
  fc-cache -f
fi

cd /sources
rm -rf dejavu-src

echo "[OK] DejaVu fonts instaladas."
