#!/bin/bash
# 940-gedit.sh - Editor de texto GNOME clássico (gedit)

set -euo pipefail

cd /sources

tarball=$(ls gedit-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gedit não encontrado em /sources."
  exit 0
fi

rm -rf gedit-src
mkdir -v gedit-src
tar -xf "$tarball" -C gedit-src --strip-components=1
cd gedit-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --buildtype=release || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf gedit-src

echo "[OK] gedit instalado (se build OK)."
