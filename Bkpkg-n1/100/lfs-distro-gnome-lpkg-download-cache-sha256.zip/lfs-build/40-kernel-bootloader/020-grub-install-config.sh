
#!/bin/bash
# 020-grub-install-config.sh - Helper para instalar e configurar GRUB na LFS Distro.
#
# Uso:
#   TARGET_DISK=/dev/sdX 020-grub-install-config.sh
#
# Se TARGET_DISK não for definido, o script irá apenas gerar grub.cfg.

set -euo pipefail

TARGET_DISK=${TARGET_DISK:-}

# Gerar config
echo "[GRUB] Gerando /boot/grub/grub.cfg"
mkdir -p /boot/grub
if command -v grub-mkconfig >/dev/null 2>&1; then
  grub-mkconfig -o /boot/grub/grub.cfg
else
  echo "[WARN] grub-mkconfig não encontrado; verifique instalação do GRUB."
fi

if [ -n "$TARGET_DISK" ]; then
  if [ ! -b "$TARGET_DISK" ]; then
    echo "[ERRO] TARGET_DISK=$TARGET_DISK não é um bloco de disco válido."
    exit 1
  fi
  echo "[GRUB] Instalando GRUB em $TARGET_DISK"
  grub-install "$TARGET_DISK"
else
  echo "[GRUB] TARGET_DISK não definido, pulando instalação em disco."
  echo "       Exemplo: TARGET_DISK=/dev/sda bash 020-grub-install-config.sh"
fi

echo "[GRUB] Passo GRUB concluído."
