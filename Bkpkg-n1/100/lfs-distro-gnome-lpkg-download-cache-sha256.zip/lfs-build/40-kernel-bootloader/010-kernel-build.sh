
#!/bin/bash
# 010-kernel-build.sh - Build completo do kernel Linux para a LFS Distro.
#
# Assumptions:
#  - Tarball linux-*.tar.* em /sources
#  - Executado dentro do chroot final
#  - /boot existe e é o ponto de boot real do sistema

set -euo pipefail

cd /sources

tarball=$(ls linux-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[ERRO] Nenhum linux-*.tar.* encontrado em /sources."
  exit 1
fi

echo "[KERNEL] Usando tarball: $tarball"

rm -rf linux-src
mkdir -v linux-src
tar -xf "$tarball" -C linux-src --strip-components=1
cd linux-src

# Tentar reaproveitar uma configuração existente se houver
if [ -f /boot/config-linux ]; then
  echo "[KERNEL] Usando /boot/config-linux como base de configuração."
  cp -v /boot/config-linux .config
elif [ -f /boot/config-$(uname -r) ]; then
  echo "[KERNEL] Usando /boot/config-$(uname -r) como base de configuração."
  cp -v /boot/config-$(uname -r) .config
fi

# Gera configuração padrão se não houver .config
if [ ! -f .config ]; then
  echo "[KERNEL] Nenhuma .config encontrada, gerando defconfig padrão."
  make defconfig
else
  echo "[KERNEL] Atualizando configuração existente com olddefconfig."
  make olddefconfig
fi

# Compilação (usa todos os cores disponíveis)
jobs=$(nproc || echo 1)
echo "[KERNEL] Compilando com ${jobs} jobs."
make -j"${jobs}"

# Instalar módulos
echo "[KERNEL] Instalando módulos."
make modules_install

# Instalar kernel (bzImage, System.map, config) em /boot
echo "[KERNEL] Instalando kernel em /boot."
make install

# Guardar config usada para facilitar rebuilds futuros
cp -v .config /boot/config-linux || true

# Ajustar symlink /usr/src/linux
if [ -d /usr/src ]; then
  rm -f /usr/src/linux
  mkdir -p /usr/src
  ln -svf "$(pwd)" /usr/src/linux
fi

echo "[KERNEL] Build e instalação do kernel concluídos."
echo "         Verifique /boot/vmlinuz-* e ajuste o bootloader se necessário."
