
#!/bin/bash
# 220-gcc-pass2.sh - GCC-15.2.0 (Pass 2) - temporary tools

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

gcc_tar=$(ls gcc-15.2.0*.tar.* gcc-15.2*.tar.* gcc-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$gcc_tar" ]; then
  echo "Tarball do GCC não encontrado em $LFS/sources"
  exit 1
fi

rm -rf gcc-pass2-src
mkdir -v gcc-pass2-src
tar -xf "$gcc_tar" -C gcc-pass2-src --strip-components=1
cd gcc-pass2-src

mkdir -v build
cd build

../configure         --build=$(../config.guess)         --host=$LFS_TGT         --prefix=/usr         --with-build-sysroot=$LFS         --enable-default-pie         --enable-default-ssp         --disable-multilib         --disable-nls         --enable-languages=c,c++

make
make DESTDIR=$LFS install

ln -sv gcc $LFS/usr/bin/cc || true

cd "$LFS/sources"
rm -rf gcc-pass2-src

echo "GCC-15.2.0 (Pass 2) instalado temporariamente em $LFS/usr."
