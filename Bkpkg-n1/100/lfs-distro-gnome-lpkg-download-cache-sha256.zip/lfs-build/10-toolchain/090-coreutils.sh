
#!/bin/bash
# 090-coreutils.sh - Coreutils (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls coreutils-9.9*.tar.* coreutils-9.6*.tar.* coreutils-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Coreutils não encontrado em $LFS/sources"
  exit 1
fi

rm -rf coreutils-src
mkdir -v coreutils-src
tar -xf "$tarball" -C coreutils-src --strip-components=1
cd coreutils-src

./configure         --prefix=/usr         --host=$LFS_TGT         --build=$(build-aux/config.guess)         --enable-install-program=hostname         --enable-no-install-program=kill,uptime

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf coreutils-src

echo "Coreutils instalado temporariamente em $LFS/usr."
