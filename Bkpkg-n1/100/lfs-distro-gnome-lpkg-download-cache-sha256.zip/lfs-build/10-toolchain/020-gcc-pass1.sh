
#!/bin/bash
# 020-gcc-pass1.sh - GCC-15.2.0 (Pass 1) - cross toolchain

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

gcc_tar=$(ls gcc-15.2.0*.tar.* gcc-15.2*.tar.* gcc-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$gcc_tar" ]; then
  echo "Tarball do GCC não encontrado em $LFS/sources"
  exit 1
fi

rm -rf gcc-pass1-src
mkdir -v gcc-pass1-src
tar -xf "$gcc_tar" -C gcc-pass1-src --strip-components=1
cd gcc-pass1-src

mpfr_tar=$(ls ../mpfr-4.2.2*.tar.* ../mpfr-*.tar.* 2>/dev/null | head -n1 || true)
gmp_tar=$(ls ../gmp-6.3.0*.tar.* ../gmp-*.tar.* 2>/dev/null | head -n1 || true)
mpc_tar=$(ls ../mpc-1.3.1*.tar.* ../mpc-*.tar.* 2>/dev/null | head -n1 || true)

if [ -z "$mpfr_tar" ] || [ -z "$gmp_tar" ] || [ -z "$mpc_tar" ]; then
  echo "Tarballs de mpfr/gmp/mpc não encontrados em $LFS/sources"
  exit 1
fi

tar -xf "$mpfr_tar"
mv -v mpfr-* mpfr

tar -xf "$gmp_tar"
mv -v gmp-* gmp

tar -xf "$mpc_tar"
mv -v mpc-* mpc

case $(uname -m) in
  x86_64)
    sed -e '/m64=/s/lib64/lib/' -i.orig gcc/config/i386/t-linux64
  ;;
esac

mkdir -v build
cd build

../configure                          --target=$LFS_TGT                 --prefix=$LFS/tools               --with-glibc-version=2.42         --with-sysroot=$LFS               --with-newlib                     --without-headers                 --enable-default-pie              --enable-default-ssp              --disable-nls                     --disable-shared                  --disable-multilib                --disable-threads                 --disable-libatomic               --disable-libgomp                 --disable-libquadmath             --disable-libssp                  --disable-libvtv                  --disable-libstdcxx               --enable-languages=c,c++

make
make install

cd ..
libgcc_dir=$(dirname "$($LFS_TGT-gcc -print-libgcc-file-name)")
mkdir -p "${libgcc_dir}/include"
cat gcc/limitx.h gcc/glimits.h gcc/limity.h > "${libgcc_dir}/include/limits.h"

cd "$LFS/sources"
rm -rf gcc-pass1-src

echo "GCC-15.2.0 (Pass 1) instalado em $LFS/tools."
