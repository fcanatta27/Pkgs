#!/bin/bash
# 10-toolchain/run-all.sh - Driver da toolchain (cross + temporária)
#
# Executa todos os scripts NN-*.sh desta pasta em ordem, registrando logs.
# Opcionalmente, roda 00-config/check-toolchain.sh ao final (--sanity).
#
set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
TOP=$(cd "$HERE/.." && pwd)

LOGDIR="$TOP/logs-10-toolchain"
mkdir -pv "$LOGDIR"

DO_SANITY=0

usage() {
  cat << EOF
Uso: ${0##*/} [opções]

Opções:
  --sanity      Após executar todos os scripts, roda 00-config/check-toolchain.sh
  -h, --help    Mostra esta ajuda
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --sanity)
      DO_SANITY=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[10-toolchain] Opção desconhecida: $1" >&2
      usage
      exit 1
      ;;
  esac
done

echo ">>> [10-toolchain] Iniciando run-all.sh em $HERE"
echo ">>> [10-toolchain] Logs individuais: $LOGDIR/"
echo ">>> [10-toolchain] sanity final: $DO_SANITY"

shopt -s nullglob
scripts=( "$HERE"/[0-9][0-9][0-9]-*.sh )
shopt -u nullglob

if [ ${#scripts[@]} -eq 0 ]; then
  echo "[10-toolchain] Nenhum script NN-*.sh encontrado em $HERE."
  exit 0
fi

idx=0
total=${#scripts[@]}

for script in "${scripts[@]}"; do
  base=$(basename "$script")
  if [ "$base" = "run-all.sh" ]; then
    continue
  fi
  if [ ! -x "$script" ]; then
    echo "[10-toolchain] Pulando $base (não executável)."
    continue
  fi
  ((idx++))
  logfile="$LOGDIR/$base.log"
  echo ">>> [10-toolchain] [$idx/$total] Executando $base (log: $logfile)"
  if bash "$script" 2>&1 | tee "$logfile"; then
    echo "[10-toolchain] $base concluído com sucesso."
  else
    echo "[10-toolchain] ERRO ao executar $base (veja $logfile)."
    exit 1
  fi
done

echo ">>> [10-toolchain] run-all.sh concluído."

if [ $DO_SANITY -eq 1 ]; then
  CT="$TOP/00-config/check-toolchain.sh"
  if [ -x "$CT" ]; then
    echo ">>> [10-toolchain] Executando sanity da toolchain (00-config/check-toolchain.sh)..."
    if ! "$CT"; then
      echo "[10-toolchain] Aviso: check-toolchain.sh retornou código diferente de zero."
    fi
  else
    echo "[10-toolchain] sanity habilitado, mas $CT não encontrado ou não executável."
  fi
fi

echo ">>> [10-toolchain] Fim."
