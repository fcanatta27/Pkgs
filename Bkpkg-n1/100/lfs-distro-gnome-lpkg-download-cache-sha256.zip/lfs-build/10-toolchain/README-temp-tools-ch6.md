# Capítulo 6 - Temporary Tools (Cross Compiling Temporary Tools)

Esta pasta agora contém scripts para automatizar os pacotes do Capítulo 6 do LFS:

- 060-m4.sh
- 070-ncurses.sh
- 080-bash.sh
- 090-coreutils.sh
- 100-diffutils.sh
- 110-file.sh
- 120-findutils.sh
- 130-gawk.sh
- 140-grep.sh
- 150-gzip.sh
- 160-make.sh
- 170-patch.sh
- 180-sed.sh
- 190-tar.sh
- 200-xz.sh
- 210-binutils-pass2.sh
- 220-gcc-pass2.sh

A ordem numérica segue a sequência recomendada do livro.
Revise sempre com a versão exata do LFS que você está usando.
