
#!/bin/bash
# 160-make.sh - Make-4.4.1 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls make-4.4.1*.tar.* make-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Make não encontrado em $LFS/sources"
  exit 1
fi

rm -rf make-src
mkdir -v make-src
tar -xf "$tarball" -C make-src --strip-components=1
cd make-src

./configure         --prefix=/usr         --host=$LFS_TGT         --build=$(build-aux/config.guess)

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf make-src

echo "Make instalado temporariamente em $LFS/usr."
