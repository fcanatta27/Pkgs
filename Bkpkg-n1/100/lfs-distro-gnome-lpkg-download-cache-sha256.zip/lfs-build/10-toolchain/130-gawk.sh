
#!/bin/bash
# 130-gawk.sh - Gawk-5.3.2 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls gawk-5.3.2*.tar.* gawk-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Gawk não encontrado em $LFS/sources"
  exit 1
fi

rm -rf gawk-src
mkdir -v gawk-src
tar -xf "$tarball" -C gawk-src --strip-components=1
cd gawk-src

sed -i 's/extras//' Makefile.in || true

./configure         --prefix=/usr         --host=$LFS_TGT         --build=$(build-aux/config.guess)

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf gawk-src

echo "Gawk instalado temporariamente em $LFS/usr."
