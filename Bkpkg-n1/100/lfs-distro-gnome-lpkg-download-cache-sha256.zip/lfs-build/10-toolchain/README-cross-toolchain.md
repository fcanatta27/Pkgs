# Fase 10 - Cross-Toolchain Temporário (Binutils-2.45.1, GCC-15.2.0, Linux Headers 6.16.1, Glibc-2.42, Libstdc++)

Scripts adicionados/atualizados:

- 010-binutils-pass1.sh
    - Constrói Binutils-2.45.1 (Passo 1) em $LFS/tools.
- 020-gcc-pass1.sh
    - Constrói GCC-15.2.0 (Passo 1) em $LFS/tools com mpfr/gmp/mpc
      e gera o limits.h interno.
- 030-linux-headers.sh
    - Extrai headers do kernel (ex.: linux-6.16.1) e instala em $LFS/usr/include.
- 040-glibc-2.42.sh
    - Constrói e instala Glibc-2.42 em $LFS (DESTDIR), usando o cross-compiler.
- 050-libstdc++-from-gcc-15.2.0.sh
    - Constrói e instala Libstdc++ (parte do GCC-15.2.0) em $LFS.

Ordem de execução recomendada a partir da raiz do projeto (como usuário não-root):

1. Ajustar 00-config/env.sh (LFS, LFS_TGT, etc.) e montar a partição em $LFS.
2. Popular 00-config/packages.list com URLs dos pacotes:
   - binutils-2.45.1
   - gcc-15.2.0
   - mpfr-4.2.2
   - gmp-6.3.0
   - mpc-1.3.1
   - linux-6.16.1 (ou outra 6.x)
   - glibc-2.42 e patch glibc-2.42-fhs-1.patch
3. Baixar fontes:
   - source 00-config/env.sh
   - bash 00-config/fetch_sources.sh
4. Construir a cross-toolchain temporária:
   - bash 10-toolchain/run-all.sh

Estes scripts seguem de perto as instruções do livro Linux From Scratch
(ramo de desenvolvimento com GCC-15.2.0 / Glibc-2.42), mas você deve sempre
comparar com a versão exata do livro que estiver usando, pois detalhes podem
mudar.
