
#!/bin/bash
# 150-gzip.sh - Gzip-1.14 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls gzip-1.14*.tar.* gzip-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Gzip não encontrado em $LFS/sources"
  exit 1
fi

rm -rf gzip-src
mkdir -v gzip-src
tar -xf "$tarball" -C gzip-src --strip-components=1
cd gzip-src

./configure         --prefix=/usr         --host=$LFS_TGT

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf gzip-src

echo "Gzip instalado temporariamente em $LFS/usr."
