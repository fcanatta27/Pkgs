
#!/bin/bash
# 120-findutils.sh - Findutils-4.10.0 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls findutils-4.10.0*.tar.* findutils-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Findutils não encontrado em $LFS/sources"
  exit 1
fi

rm -rf findutils-src
mkdir -v findutils-src
tar -xf "$tarball" -C findutils-src --strip-components=1
cd findutils-src

./configure         --prefix=/usr         --host=$LFS_TGT         --build=$(build-aux/config.guess)

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf findutils-src

echo "Findutils instalado temporariamente em $LFS/usr."
