
#!/bin/bash
# 030-linux-headers.sh - Linux API Headers (ex.: Linux-6.16.1)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

linux_tar=$(ls linux-6.16.1*.tar.* linux-6.*.tar.* linux-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$linux_tar" ]; then
  echo "Tarball do kernel Linux não encontrado em $LFS/sources"
  exit 1
fi

rm -rf linux-headers-src
mkdir -v linux-headers-src
tar -xf "$linux_tar" -C linux-headers-src --strip-components=1
cd linux-headers-src

make mrproper
make headers
find usr/include -type f ! -name '*.h' -delete
mkdir -pv "$LFS/usr"
cp -rv usr/include "$LFS/usr"

cd "$LFS/sources"
rm -rf linux-headers-src

echo "Linux API Headers instalados em $LFS/usr/include."
