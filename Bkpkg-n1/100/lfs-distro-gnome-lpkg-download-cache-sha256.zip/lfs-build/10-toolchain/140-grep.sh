
#!/bin/bash
# 140-grep.sh - Grep-3.12 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls grep-3.12*.tar.* grep-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Grep não encontrado em $LFS/sources"
  exit 1
fi

rm -rf grep-src
mkdir -v grep-src
tar -xf "$tarball" -C grep-src --strip-components=1
cd grep-src

./configure         --prefix=/usr         --host=$LFS_TGT         --build=$(./build-aux/config.guess)

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf grep-src

echo "Grep instalado temporariamente em $LFS/usr."
