#!/usr/bin/env bash
#
# Patch-2.8 (ferramenta temporária) - LFS (toolchain)
#
# Construído como ferramenta temporária em /usr dentro do sysroot (${LFS_ROOTFS}),
# usando DESTDIR + cópia via common.sh.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${SCRIPT_DIR}/common.sh"

STEP_ID="patch-2.8-temp"

PKG_NAME="patch-2.8"
PKG_TARBALL="${PKG_NAME}.tar.xz"
PATCH_URL_DEFAULT="https://ftp.gnu.org/gnu/patch/${PKG_TARBALL}"
: "${PATCH_SRC_URL:=${PATCH_URL_DEFAULT}}"

if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
    echo "Baixando ${PKG_TARBALL}..."
    curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${PATCH_SRC_URL}"
fi

cd "${LFS_WORKDIR}"
rm -rf "${PKG_NAME}"
tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
cd "${PKG_NAME}"

./configure --prefix=/usr                 --host="${LFS_TGT}"                 --build="$(build-aux/config.guess)"

make

reset_destdir
make DESTDIR="${LFS_DESTDIR}" install

register_installed_files "${STEP_ID}"
sync_destdir_to_rootfs

echo "Patch-2.8 (temporário) instalado em ${LFS_ROOTFS}."
