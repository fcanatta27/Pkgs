# Documentação do Projeto 3bLinux

Esta pasta contém **toda a documentação oficial** do projeto 3bLinux,
organizada por **etapas cronológicas** e por **assuntos técnicos**.

O objetivo é que você consiga:
- Construir o sistema **do zero**, a partir de um host Linux;
- Entender **cada ferramenta** do projeto;
- Usar o modo **100% automático** ou o modo **manual guiado**;
- Chegar a um sistema final **funcional**, com primeiro login pronto.

## Fluxo recomendado de leitura

1. `01-preparando-o-host.md`
2. `02-toolchain-e-rootfs-temporario.md`
3. `03-chroot-capitulo-8.md`
4. `04-kernel-initramfs-rootfs.md`
5. `05-iso-instalador-primeiro-login.md`
6. `06-configuracao-completa-do-sistema.md`
7. `07-repositorio-e-atualizacoes.md`
8. `08-modo-automatico-orquestrador.md`
9. `09-ferramentas-do-projeto.md`

Cada documento é **autossuficiente**, mas juntos formam o guia completo.
