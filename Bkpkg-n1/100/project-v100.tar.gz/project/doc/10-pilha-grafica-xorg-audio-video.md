# Pilha Gráfica do 3bLinux (Xorg, Áudio e Vídeo)

Este documento descreve como montar uma pilha gráfica **completa e funcional**
no 3bLinux, adequada para uso diário em desktop ou notebook.

## Visão geral da pilha
- Kernel DRM/KMS
- Mesa (OpenGL / Vulkan)
- Xorg Server
- Drivers de vídeo
- ALSA + PipeWire (ou PulseAudio)
- Fontes e input

## Grupos de usuários necessários
```text
video   – acesso a DRM, GPU
audio   – acesso a dispositivos de som
input   – teclado, mouse, touchpad
```
```bash
usermod -aG video,audio,input usuario
```

## Xorg
Pacotes mínimos:
- xorg-server
- xinit
- xauth
- xrandr
- xsetroot

Configuração:
```text
/etc/X11/xorg.conf.d/
  10-monitor.conf
  20-gpu.conf
  30-input.conf
```

## Vídeo
### Drivers comuns
- Intel / AMD: mesa + modesetting
- NVIDIA: nouveau (ou proprietário)

Kernel:
```text
CONFIG_DRM=y
CONFIG_DRM_KMS_HELPER=y
```

## Áudio
Stack recomendada:
- ALSA (kernel + utils)
- PipeWire (substitui PulseAudio e JACK)

Serviços:
- pipewire
- wireplumber

## Udev
Regras importantes:
- permissões corretas para /dev/dri/*
- hotplug de áudio e vídeo
