# Desktop Real no 3bLinux

Esta etapa transforma o 3bLinux em um sistema gráfico completo, com
barra lateral, compositor, menu dinâmico e temas modernos.

## Componentes escolhidos
- Mesa (OpenGL / Vulkan)
- Xorg Server
- PipeWire (áudio)
- Openbox (WM leve)
- Tint2 (barra vertical esquerda)
- Polybar (barra alternativa com métricas)
- Rofi (menu / lançador)
- Picom (pijulius fork) – compositor

## Instalação dos componentes

```bash
pkg -i mesa
pkg -i xorg-server
pkg -i pipewire
pkg -i openbox
pkg -i tint2
pkg -i polybar
pkg -i rofi
pkg -i picom-pijulius
```

## Arquivos de configuração padrão

Ao criar um novo usuário (via /etc/skel), ele já virá com:
- `~/.config/polybar/launch.sh` e `config.ini`
- `~/.config/polybar/scripts/openweather.sh`
- `~/.config/tint2/tint2rc`
- `~/.config/rofi/config.rasi` e tema `3blinux.rasi`
- `~/.config/picom/picom.conf`

## Fluxo sugerido de sessão gráfica

1. Garantir que o usuário está nos grupos corretos:
   ```bash
   usermod -aG video,audio,input usuario
   ```

2. Criar `~/.xinitrc` com:
   ```sh
   picom --config ~/.config/picom/picom.conf &
   ~/.config/polybar/launch.sh &
   exec openbox-session
   ```

3. Iniciar o X:
   ```bash
   startx
   ```

## Barra com métricas e menu

- CPU e memória: mostrados na Polybar ( / ).
- Download / upload: módulos `net-down` e `net-up`.
- Tempo (OpenWeather): script `openweather.sh` (necessita API key).
- Menu dinâmico: clique no ícone de menu () chama `rofi -show drun`.

## Próximos passos

- Ajustar interface de rede na Polybar (padrão: `eth0`).
- Configurar API key do OpenWeather:
  ```bash
  export OW_API_KEY="sua_chave"
  export OW_CITY_ID="sua_cidade"
  ```
- Instalar fontes Nerd / Papirus para melhor visual de ícones.

## Temas GTK, ícones e cursores

Novos usuários (via /etc/skel) já vêm com:

- GTK3/GTK4 configurados em:
  - ~/.config/gtk-3.0/settings.ini
  - ~/.config/gtk-4.0/settings.ini
- GTK2 configurado em:
  - ~/.gtkrc-2.0

Valores padrão:

- Tema GTK: Adwaita-dark
- Tema de ícones: Papirus-Dark
- Fonte: Noto Sans 10
- Cursor: Breeze, tamanho 24

Basta instalar os temas correspondentes (Papirus, Breeze, etc.)
para que o visual fique completo.

## Openbox – atalhos de teclado

Openbox já vem configurado com:

- Super+Enter → xterm
- Super+D → rofi (menu de aplicativos)
- Super+Q → fechar janela
- Super+F → fullscreen
- Super+H/J/K/L → mover foco entre janelas
- Super+1..4 → alternar desktops
- Super+R → recarregar Openbox

O menu do botão direito também contém entradas para:

- Terminal (xterm)
- Navegador (firefox)
- Gerenciador de arquivos (thunar)

## Wallpaper

Um wallpaper padrão do 3bLinux é instalado em:

- /usr/share/backgrounds/3blinux/3blinux-default.png

O Openbox tenta utilizá-lo via `feh` (se instalado). Caso contrário,
usa um fundo sólido com `xsetroot`.

Você pode substituir esse arquivo por qualquer outra imagem mantendo o
mesmo caminho, ou ajustar o autostart do Openbox para usar outra imagem
ou ferramenta (nitrogen, etc.).
