#!/usr/bin/env bash
# 01-create-partitions.sh - exemplo de script para particionamento do disco
set -euo pipefail

DEVICE=${DEVICE:-/dev/sdX}

cat <<EOF
ATENÇÃO: este script é apenas um modelo.
Edite DEVICE=$DEVICE e os comandos de parted/fdisk antes de usar em produção.
EOF

# Exemplo (comentado) com parted:
: <<'EXAMPLE'
parted -s "$DEVICE" mklabel gpt
parted -s "$DEVICE" mkpart primary 1MiB 513MiB          # /boot (EFI/BIOS)
parted -s "$DEVICE" mkpart primary 513MiB 100%          # raiz LFS
mkfs.ext4 -L LFS_ROOT ${DEVICE}2
EXAMPLE

echo "Esboço de particionamento exibido. Ajuste para seu ambiente real."
