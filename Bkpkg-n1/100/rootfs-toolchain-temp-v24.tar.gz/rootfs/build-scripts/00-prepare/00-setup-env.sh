#!/usr/bin/env bash
# 00-setup-env.sh - prepara ambiente base para construção LFS usando pkg e scripts
set -euo pipefail

# Diretórios raízes do projeto
export LFS=${LFS:-/mnt/lfs}
export LFS_ROOTFS="$LFS"
export LFS_LOGDIR="$LFS_ROOTFS/var/log/lfs-build"
export LFS_TOOLS="$LFS_ROOTFS/tools"

mkdir -pv "$LFS_ROOTFS" "$LFS_LOGDIR" "$LFS_TOOLS"

echo "LFS_ROOTFS=$LFS_ROOTFS"
echo "LFS_LOGDIR=$LFS_LOGDIR"
echo "LFS_TOOLS=$LFS_TOOLS"
echo "Ambiente inicial preparado."
