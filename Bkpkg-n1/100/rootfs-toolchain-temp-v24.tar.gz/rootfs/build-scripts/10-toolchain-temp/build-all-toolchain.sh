#!/usr/bin/env bash
# build-all-toolchain.sh - constrói toolchain completo via pkg
set -euo pipefail

LOGDIR=${LOGDIR:-/var/log/lfs-build}
mkdir -pv "$LOGDIR"

log() { echo "[toolchain] $*"; }

log "Instalando toolchain base (binutils, gcc, libs matemáticas) via pkg..."

pkg install gmp mpfr mpc isl zlib binutils gcc 2>&1 | tee -a "$LOGDIR/toolchain-pkg.log"

log "Toolchain construído com sucesso via pkg."
