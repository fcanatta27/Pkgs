LFS build-scripts integration
=============================

Este diretório contém um projeto de scripts de construção inspirados no LFS,
integrados com o gerenciador de pacotes 'pkg'.

- 00-prepare/00-setup-env.sh
- 00-prepare/01-create-partitions.sh
- 10-toolchain-temp/build-all-toolchain.sh
- 20-system-final/build-all-system.sh

Os scripts chamam 'pkg' para construir e instalar o toolchain e o sistema final.
Você pode expandi-los com mais etapas conforme necessário.
