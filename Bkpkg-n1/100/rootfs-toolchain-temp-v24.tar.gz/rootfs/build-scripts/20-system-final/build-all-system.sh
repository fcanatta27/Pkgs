#!/usr/bin/env bash
# build-all-system.sh - constrói conjunto base do sistema final via pkg
set -euo pipefail

LOGDIR=${LOGDIR:-/var/log/lfs-build}
mkdir -pv "$LOGDIR"

log() { echo "[system-final] $*"; }

log "Instalando componentes principais do sistema via pkg..."

# libc, headers, kernel e firmware
pkg install linux-headers glibc linux linux-firmware 2>&1 | tee -a "$LOGDIR/system-kernel-libc.log"

# ferramentas de sistema essenciais
pkg install bash coreutils util-linux 2>&1 | tee -a "$LOGDIR/system-base.log"

# stack de rede/ssl/git (quando os Buildfiles estiverem instalados)
pkg install openssl zlib xz zstd 2>&1 | tee -a "$LOGDIR/system-compress-ssl.log"
pkg install python3 pip 2>&1 | tee -a "$LOGDIR/system-python.log"

log "Conjunto base do sistema construído via pkg."
