
# Gerenciador de Pacotes `pkg`

Este documento descreve em detalhes o funcionamento do gerenciador de pacotes **`pkg`**, o formato dos **Buildfiles**, a base de dados de pacotes, resolução de dependências e exemplos reais de uso para manter **kernel / toolchain / glibc** atualizados de forma controlada.

---

## 1. Conceitos básicos

### 1.1. Objetivo

O `pkg` é um gerenciador de pacotes minimalista, pensado para um sistema estilo LFS:

- Pacotes são construídos **a partir de Buildfiles em shell**.
- Cada pacote é construído em um diretório temporário (`$SRC` e `$PKG`), empacotado em um `.pkg.tar.xz` e depois instalado em `/`.
- Há um **banco de dados local** com metadados e lista de arquivos de cada pacote.
- Há suporte para:
  - **resolução de dependências** com detecção de ciclos;
  - **download automático** (HTTP/HTTPS, rename via `dest::URL`, repositórios `git`);
  - **build, install, remove, fetch e upgrade**.

### 1.2. Comandos principais

```bash
pkg list                # lista pacotes instalados
pkg info <nome>         # mostra metadados do pacote
pkg files <nome>        # lista arquivos que o pacote instalou
pkg install <nome>      # resolve dependências, builda e instala
pkg remove <nome>       # remove pacote (arquivos + entrada no DB)
pkg build <nome>        # apenas constrói o pacote (não instala)
pkg fetch <nome>        # baixa apenas as fontes do pacote
pkg upgrade             # tenta atualizar todos os pacotes instalados
pkg upgrade <nome>      # atualiza apenas pacote(s) específicos
pkg help                # ajuda geral
```

---

## 2. Layout do sistema de pacotes

### 2.1. Buildfiles

Os Buildfiles ficam em:

```text
/usr/packages/<categoria>/<nome>/Buildfile
```

Exemplos reais:

```text
/usr/packages/toolchain/gcc/Buildfile
/usr/packages/toolchain/binutils/Buildfile
/usr/packages/system/glibc/Buildfile
/usr/packages/system/linux/Buildfile
/usr/packages/system/linux-headers/Buildfile
/usr/packages/system/linux-firmware/Buildfile
/usr/packages/libs/zlib/Buildfile
/usr/packages/libs/gmp/Buildfile
/usr/packages/libs/mpfr/Buildfile
/usr/packages/libs/mpc/Buildfile
/usr/packages/libs/isl/Buildfile
/usr/packages/libs/zstd/Buildfile
```

Arquivos auxiliares locais, como um `config` de kernel, ficam na **mesma pasta** do Buildfile e podem ser referenciados no `source=()`.

### 2.2. Banco de dados de pacotes

```text
/var/lib/pkgdb/
  installed/
    <nome>-<versao>-r<release>/
      meta        # metadados do pacote
      manifest    # lista de arquivos instalados
  build/
    ... (scratch de build)
```

Exemplo:

```text
/var/lib/pkgdb/installed/gcc-13.2.0-r1/meta
/var/lib/pkgdb/installed/gcc-13.2.0-r1/manifest
```

### 2.3. Cache de pacotes e build

```text
/var/cache/pkg/
  packages/
    <nome>-<versao>-r<release>.pkg.tar.xz
  build/
    <nome>-<versao>-r<release>/
      src/      # fontes baixadas e extraídas
      pkg/      # árvore DESTDIR antes de empacotar
      meta
      manifest
```

---

## 3. Estrutura de um Buildfile

Um Buildfile é um script em bash, com:

- comentários de metadados (`Description`, `URL`, `Depends`);
- variáveis:
  - `name`
  - `version`
  - `release`
  - `source` (array)
- função `build()`.

Exemplo (resumido) do `zlib`:

```bash
# Description: Zlib compression library
# URL: https://zlib.net/
# Depends:

name=zlib
version=1.3
release=1

source=(https://zlib.net/zlib-$version.tar.xz)

build() {
  cd "$SRC"
  cd "$name-$version"

  ./configure --prefix=/usr
  make
  make DESTDIR="$PKG" install
}
```

### 3.1. Campo `Depends:`

Linha tipo:

```bash
# Depends: gmp mpfr mpc isl zlib binutils
```

é lida pelo `pkg` e usada para:

- resolução de ordem de instalação;
- detecção de dependências faltantes.

Se um pacote já estiver instalado, `pkg` não tenta reconstruí‑lo, a menos que você peça explicitamente.

### 3.2. Array `source=()`

Suporta:

- URLs diretas:

  ```bash
  source=(https://example.com/foo-1.0.tar.xz)
  ```

- rename:

  ```bash
  source=(foo-1.0.tar.xz::https://example.com/releases/foo-1.0.tar.xz)
  ```

- arquivos locais:

  ```bash
  source=(config patch01.patch)
  ```

  (copiados do diretório do Buildfile para `$SRC`)

- repositórios git:

  ```bash
  source=(git+https://github.com/alguem/projeto.git)
  source=(meuprojeto::git+https://github.com/alguem/projeto.git)
  source=(git@github.com:alguem/projeto.git)
  ```

O `pkg`:

- baixa/clone/copia tudo para `$SRC`;
- extrai automaticamente qualquer `*.tar.*` / `*.tgz` em `$SRC`.

---

## 4. Como o `pkg` funciona internamente (resumo)

1. Monta um índice dos Buildfiles em `/usr/packages`:
   - mapeia `name -> Buildfile`;
   - lê `Depends:` para cada pacote.
2. Para `pkg install`:
   - resolve dependências via DFS (topological sort), com detecção de ciclos;
   - para cada pacote não instalado:
     1. `pkg_build` – constrói pacote em DESTDIR com base no Buildfile;
     2. `pkg_install_binary` – extrai `.pkg.tar.xz` no `/` e registra em `/var/lib/pkgdb/installed`.
3. Para `pkg upgrade`:
   - lê `VERSION` e `RELEASE` atuais do `meta`;
   - compara com `version`/`release` do Buildfile;
   - se diferentes:
     - `pkg_remove` + `pkg_build` + `pkg_install_binary` (instala nova versão).

---

## 5. Exemplo real: mantendo o **toolchain** atualizado

### 5.1. Cadeia de dependências do toolchain

Buildfiles criados:

- `libs/zlib` (sem deps)
- `libs/gmp`
- `libs/mpfr` (`Depends: gmp`)
- `libs/mpc` (`Depends: gmp mpfr`)
- `libs/isl` (`Depends: gmp`)
- `toolchain/binutils` (`Depends: zlib`)
- `toolchain/gcc` (`Depends: gmp mpfr mpc isl zlib binutils`)

Graficamente:

```
zlib      gmp
           ├── mpfr
           │    └── mpc
           └── isl

binutils <- zlib
gcc      <- gmp, mpfr, mpc, isl, zlib, binutils
```

### 5.2. Instalando o toolchain com `pkg`

Uma vez dentro do chroot (ou no sistema final):

```bash
# construir e instalar tudo necessário pro gcc
pkg install gcc
```

O `pkg` vai:

1. ler deps de `gcc`;
2. resolver ordem (`gmp`, `mpfr`, `mpc`, `isl`, `zlib`, `binutils`, `gcc`);
3. para cada um:
   - se não instalado → build + install;
   - se já instalado → pula.

Para atualizar o gcc no futuro:

1. você edita o `version`/`release` em:

   ```text
   /usr/packages/toolchain/gcc/Buildfile
   ```

2. roda:

   ```bash
   pkg upgrade gcc
   ```

O `pkg` detecta que `VERSION/RELEASE` mudaram e:

- remove a versão antiga;
- constrói/instala a nova versão.

---

## 6. Exemplo real: mantendo **glibc** atualizado

Buildfiles envolvidos:

- `system/linux-headers`  
- `system/glibc` (`Depends: linux-headers`)

Instalação inicial:

```bash
pkg install glibc
```

- Se `linux-headers` não estiver instalado, será construído antes.
- O `Buildfile` do glibc usa:

  ```bash
  --with-headers=/usr/include
  ```

  assumindo que `linux-headers` populou `/usr/include` corretamente.

Atualizar glibc:

1. editar `version`/`release` em:

   ```text
   /usr/packages/system/glibc/Buildfile
   ```

2. rodar:

   ```bash
   pkg upgrade glibc
   ```

---

## 7. Exemplo real: mantendo o **kernel** e firmware atualizados

Buildfiles:

- `libs/zstd`
- `system/linux` (`Depends: zstd`)
- `system/linux-firmware`

### 7.1. Pré-requisito: `config` de kernel

No diretório:

```text
/usr/packages/system/linux/
```

coloque um arquivo:

```text
config
```

contendo o `.config` que você usa para compilar o kernel (pode ser baseado em um `defconfig` ou no `.config` atual do seu sistema).

O Buildfile do kernel usa:

```bash
source=(
  linux-$version.tar.xz::https://www.kernel.org/pub/linux/kernel/v6.x/linux-$version.tar.xz
  config
)
```

### 7.2. Instalar kernel moderno com `pkg`

```bash
pkg install linux-firmware   # primeiro firmwares (opcional mas recomendado)
pkg install linux            # compila e instala kernel + módulos no DESTDIR e depois no /
```

Isso irá:

- baixar o tarball do kernel na versão definida no Buildfile;
- copiar o `config` local para a árvore de build;
- rodar:

  ```bash
  make olddefconfig
  make -j$(nproc)
  make modules_install INSTALL_MOD_PATH="$PKG"
  ```

- instalar em `$PKG`:
  - `/boot/vmlinuz-<version>`
  - `/boot/System.map-<version>`
  - `/boot/config-<version>`
  - `/lib/modules/<versão>`
  - `/lib/firmware` (diretório, normalmente populado pelo pacote `linux-firmware`).

Depois, você ajusta seu **bootloader (syslinux/grub)** para apontar para o novo kernel.

### 7.3. Atualizar o kernel com `pkg`

1. Atualize `version` no Buildfile:

   ```text
   /usr/packages/system/linux/Buildfile
   ```

   Ajustando também a URL em `source` se o branch mudar (ex.: de v6.x para v7.x).

2. Rode:

   ```bash
   pkg upgrade linux
   ```

3. Atualize o bootloader se necessário.

Para firmware:

1. atualize `version` em:

   ```text
   /usr/packages/system/linux-firmware/Buildfile
   ```

2. rode:

   ```bash
   pkg upgrade linux-firmware
   ```

---

## 8. Fluxo sugerido para manter o sistema saudável

1. **Toolchain base**: `gcc`, `binutils`, `zlib`, `gmp`, `mpfr`, `mpc`, `isl`.
2. **Bibliotecas de runtime**: `glibc`, `zstd`, etc.
3. **Kernel + firmware**: `linux`, `linux-firmware`.
4. **Ferramentas auxiliares**: `libtool`, `xz`, `ninja`, `llvm`, `clang`, `python3`, `pip`, `ccache`, `rust`, etc.  
   (Buildfiles criados nos diretórios apropriados em `/usr/packages`.)

Quando quiser atualizar qualquer stack:

- ajuste `version`/`release` no Buildfile correspondente;
- use `pkg upgrade <nome>` para uma atualização controlada.

---
