
#!/usr/bin/env bash
set -euo pipefail

# Este script deve ser executado como *root* no sistema host.
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: execute 00-setup-env.sh como root no host (ex: sudo -i)."
  exit 1
fi

: "${LFS:?Defina a variável LFS, por exemplo: export LFS=/mnt/lfs}"

echo "==> Criando diretório base em $LFS..."
mkdir -pv "$LFS"

echo "==> Criando diretórios padrão..."
mkdir -pv "$LFS"/{etc,var,tools,sources}
mkdir -pv "$LFS"/usr
mkdir -pv "$LFS"/lib
if [[ $(uname -m) == x86_64 ]]; then
  mkdir -pv "$LFS"/lib64
fi

echo "==> Criando link simbólico /tools -> $LFS/tools (se ainda não existir)..."
if [[ ! -e /tools ]]; then
  ln -sv "$LFS/tools" /tools
fi

echo "==> Criando usuário/grupo lfs (se ainda não existirem)..."
if ! getent group lfs >/dev/null; then
  groupadd lfs
fi
if ! id -u lfs >/dev/null 2>&1; then
  useradd -s /bin/bash -g lfs -m -k /dev/null lfs
fi

echo "==> Ajustando permissões de $LFS/sources e $LFS/tools para o usuário lfs..."
chown -v lfs:lfs "$LFS"/{sources,tools}
chown -v lfs:lfs "$LFS"

cat << 'EOF'

Ambiente preparado.

Agora, como usuário normal, torne-se o usuário 'lfs' e configure o ambiente:

  su - lfs

Dentro do shell do usuário lfs, adicione isto a ~/.bash_profile (se ainda não existir):

  exec env -i HOME=$HOME TERM=$TERM PS1='\u:\w\$ ' \
    PATH=/usr/bin:/bin /bin/bash

E em ~/.bashrc:

  set +h
  umask 022
  LFS=/mnt/lfs        # ajuste se necessário
  export LFS
  export LFS_TGT=$(uname -m)-lfs-linux-gnu
  PATH=/tools/bin:/usr/bin
  export PATH

Depois, reabra o shell do usuário lfs e execute os scripts em
build-scripts/10-toolchain-temp na ordem numérica.

EOF
