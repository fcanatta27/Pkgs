#!/usr/bin/env bash
# 04-enter-chroot.sh - entra no chroot LFS
set -euo pipefail

export LFS=${LFS:-/mnt/lfs}

if ! mountpoint -q "$LFS/proc"; then
  echo "ERRO: parece que 03-prepare-chroot.sh ainda não foi executado." >&2
  exit 1
fi

echo "[chroot] Entrando em chroot em $LFS"

chroot "$LFS" /usr/bin/env -i \
    HOME=/root TERM="$TERM" PS1='(lfs-chroot) \u:\w\$ ' \
    PATH=/usr/bin:/usr/sbin:/bin:/sbin \
    /bin/bash --login
