#!/usr/bin/env bash
# 20-chroot-prep/02-enter-chroot.sh
# Entra no chroot LFS com ambiente limpo, pronto para construir o sistema final.
#
# Deve ser executado como root no host, após 01-mount-virtualfs.sh.
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: 02-enter-chroot.sh deve ser executado como root (host)."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"

if ! mountpoint -q "$LFS"; then
  echo "ERRO: $LFS não está montado."
  exit 1
fi

for d in dev proc sys run; do
  if ! mountpoint -q "$LFS/$d"; then
    echo "ERRO: $LFS/$d não está montado. Execute 01-mount-virtualfs.sh antes."
    exit 1
  fi
done

echo "==> Entrando em chroot em $LFS"
echo "    Para sair, use 'exit' ou Ctrl-D."

chroot "$LFS" /usr/bin/env -i \
  HOME=/root \
  TERM="${TERM:-linux}" \
  PS1='(lfs-chroot)\u:\w\$ ' \
  PATH=/usr/bin:/usr/sbin:/bin:/sbin \
  /bin/bash --login
