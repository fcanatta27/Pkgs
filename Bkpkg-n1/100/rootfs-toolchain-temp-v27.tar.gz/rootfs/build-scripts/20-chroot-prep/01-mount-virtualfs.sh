#!/usr/bin/env bash
# 20-chroot-prep/01-mount-virtualfs.sh
# Monta /dev, /proc, /sys, /run dentro do $LFS para preparar o chroot.
#
# Deve ser executado como root no host.
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: 01-mount-virtualfs.sh deve ser executado como root (host)."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"

echo "==> Montando pseudo-sistemas de arquivos em $LFS"

mountpoint -q "$LFS" || { echo "ERRO: $LFS não está montado."; exit 1; }

# /dev
if ! mountpoint -q "$LFS/dev"; then
  mount --bind /dev "$LFS/dev"
fi

# /dev/pts
if ! mountpoint -q "$LFS/dev/pts"; then
  mount -t devpts devpts "$LFS/dev/pts" -o gid=5,mode=620
fi

# /proc
if ! mountpoint -q "$LFS/proc"; then
  mount -t proc proc "$LFS/proc"
fi

# /sys
if ! mountpoint -q "$LFS/sys"; then
  mount -t sysfs sysfs "$LFS/sys"
fi

# /run
if ! mountpoint -q "$LFS/run"; then
  mount -t tmpfs tmpfs "$LFS/run"
fi

# /dev/shm dentro do chroot se for symlink
if [[ -h "$LFS/dev/shm" ]]; then
  mkdir -pv "$LFS/$(readlink "$LFS/dev/shm")"
fi

echo "==> Montagens para chroot concluídas."
