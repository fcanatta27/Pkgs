#!/usr/bin/env bash
# post-install-checklist.sh - verificações de pós-instalação dentro do sistema final
set -euo pipefail

echo "[post-install] Verificando usuário wheel não-root..."
if getent group wheel >/dev/null 2>&1; then
  WHEEL_USERS=$(getent group wheel | cut -d: -f4)
  if [[ -z "$WHEEL_USERS" ]]; then
    echo "AVISO: não há usuários no grupo wheel."
  else
    echo "Usuários no grupo wheel: $WHEEL_USERS"
  fi
else
  echo "AVISO: grupo wheel não existe."
fi

echo "[post-install] Verificando timezone..."
if [[ -f /etc/localtime ]]; then
  echo "Timezone configurado (link /etc/localtime existe)."
else
  echo "AVISO: timezone não configurado (/etc/localtime ausente)."
fi

echo "[post-install] Verificando chrony..."
if command -v chronyd >/dev/null 2>&1; then
  if pgrep -x chronyd >/dev/null 2>&1; then
    echo "chronyd está em execução."
  else
    echo "AVISO: chronyd instalado mas não em execução."
  fi
else
  echo "AVISO: chrony não está instalado."
fi

echo "[post-install] Verificando firewall (iptables/firewalld)..."
if command -v iptables >/dev/null 2>&1; then
  RULES=$(iptables -S 2>/dev/null | wc -l)
  echo "iptables presente, número de linhas de regras: $RULES"
else
  echo "AVISO: iptables não está instalado."
fi

if command -v firewall-cmd >/dev/null 2>&1; then
  echo "firewalld está instalado."
else
  echo "firewalld não encontrado."
fi

echo "[post-install] Checklist finalizado."
