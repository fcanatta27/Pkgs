#!/usr/bin/env bash
# build-all.sh - Orquestrador da construção da toolchain temporária + temporary tools
# Executa todos os scripts de 10-toolchain-temp na ordem correta, com:
#  - logs separados por etapa
#  - marcação de etapas concluídas (idempotência)
#  - retomada automática (resume)
#  - opções para filtrar/forçar etapas
#
# Uso básico (como usuário lfs, com LFS definido):
#   ./build-all.sh
#
# Opções:
#   --list                 Lista todas as etapas conhecidas e sai
#   --status               Mostra o status (pendente/concluída) de cada etapa
#   --from NOME            Começa a partir da etapa NOME (ex: 08-m4)
#   --to NOME              Para após a etapa NOME (inclusive)
#   --only NOME            Executa apenas a etapa NOME
#   --force                Reexecuta etapas já concluídas (ignora .done)
#   --no-color             Desativa cores no output
#   -h, --help             Mostra esta ajuda
#
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: build-all.sh deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOOLS_DIR="${SCRIPT_DIR}/10-toolchain-temp"

if [[ ! -d "$TOOLS_DIR" ]]; then
  echo "ERRO: diretório de scripts não encontrado: $TOOLS_DIR"
  exit 1
fi

STATE_DIR="${LFS}/.lfs-build-state"
LOG_DIR="${LFS}/.lfs-build-logs"

mkdir -pv "$STATE_DIR" "$LOG_DIR"

# Cores (desativáveis)
USE_COLOR=1
for arg in "$@"; do
  [[ "$arg" == "--no-color" ]] && USE_COLOR=0
done

if [[ "$USE_COLOR" -eq 1 ]]; then
  C_RESET=$'\e[0m'
  C_INFO=$'\e[34m'
  C_WARN=$'\e[33m'
  C_OK=$'\e[32m'
  C_ERR=$'\e[31m'
else
  C_RESET=""
  C_INFO=""
  C_WARN=""
  C_OK=""
  C_ERR=""
fi

log_info()  { echo "${C_INFO}[INFO]${C_RESET}  $*"; }
log_warn()  { echo "${C_WARN}[WARN]${C_RESET}  $*"; }
log_ok()    { echo "${C_OK}[OK]${C_RESET}    $*"; }
log_error() { echo "${C_ERR}[ERRO]${C_RESET}  $*"; }

usage() {
  sed -n '1,70p' "$0"
}

# Parse de argumentos
ARG_FROM=""
ARG_TO=""
ARG_ONLY=""
ARG_FORCE=0
ARG_LIST=0
ARG_STATUS=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --from)
      ARG_FROM="${2:-}"; shift 2;;
    --to)
      ARG_TO="${2:-}"; shift 2;;
    --only)
      ARG_ONLY="${2:-}"; shift 2;;
    --force)
      ARG_FORCE=1; shift;;
    --list)
      ARG_LIST=1; shift;;
    --status)
      ARG_STATUS=1; shift;;
    --no-color)
      shift;; # já tratado antes
    -h|--help)
      usage; exit 0;;
    *)
      log_warn "Argumento desconhecido: $1"
      usage
      exit 1
      ;;
  esac
done

# Descobrir todas as etapas (scripts *.sh) em ordem numérica
mapfile -t ALL_SCRIPTS < <(find "$TOOLS_DIR" -maxdepth 1 -type f -name '*.sh' | sort)

if [[ "${#ALL_SCRIPTS[@]}" -eq 0 ]]; then
  log_error "Nenhum script encontrado em $TOOLS_DIR"
  exit 1
fi

get_step_name() {
  local path="$1"
  basename "$path" .sh
}

# Filtragem de etapas
SELECTED_SCRIPTS=()

# Primeiro, aplicar filtro --only se usado
if [[ -n "$ARG_ONLY" ]]; then
  for s in "${ALL_SCRIPTS[@]}"; do
    local_name="$(get_step_name "$s")"
    if [[ "$local_name" == "$ARG_ONLY" ]]; then
      SELECTED_SCRIPTS+=("$s")
      break
    fi
  done
  if [[ "${#SELECTED_SCRIPTS[@]}" -eq 0 ]]; then
    log_error "Etapa passada em --only não encontrada: $ARG_ONLY"
    exit 1
  fi
else
  # Sem --only: filtro por --from/--to (se existirem)
  from_seen=0
  for s in "${ALL_SCRIPTS[@]}"; do
    local_name="$(get_step_name "$s")"

    # Aplicar --from
    if [[ -n "$ARG_FROM" && "$from_seen" -eq 0 ]]; then
      if [[ "$local_name" == "$ARG_FROM" ]]; then
        from_seen=1
      else
        continue
      fi
    fi

    # Se não há --from, from_seen é implicitamente 1
    [[ -z "$ARG_FROM" ]] && from_seen=1

    # Aplicar --to
    if [[ -n "$ARG_TO" ]]; then
      SELECTED_SCRIPTS+=("$s")
      if [[ "$local_name" == "$ARG_TO" ]]; then
        break
      fi
    else
      SELECTED_SCRIPTS+=("$s")
    fi
  done

  if [[ -n "$ARG_FROM" && "$from_seen" -eq 0 ]]; then
    log_error "Etapa passada em --from não encontrada: $ARG_FROM"
    exit 1
  fi
  if [[ -n "$ARG_TO" ]]; then
    found_to=0
    for s in "${ALL_SCRIPTS[@]}"; do
      [[ "$(get_step_name "$s")" == "$ARG_TO" ]] && found_to=1 && break
    done
    if [[ "$found_to" -eq 0 ]]; then
      log_error "Etapa passada em --to não encontrada: $ARG_TO"
      exit 1
    fi
  fi
fi

# Funções de status
step_done() {
  local name="$1"
  [[ -f "${STATE_DIR}/${name}.done" ]]
}

mark_step_done() {
  local name="$1"
  date -u +"%Y-%m-%dT%H:%M:%SZ" > "${STATE_DIR}/${name}.done"
}

# Modos especiais: --list e --status
if [[ "$ARG_LIST" -eq 1 ]]; then
  echo "Etapas disponíveis (na ordem):"
  for s in "${ALL_SCRIPTS[@]}"; do
    echo "  $(get_step_name "$s")"
  done
  exit 0
fi

if [[ "$ARG_STATUS" -eq 1 ]]; then
  echo "Status das etapas:"
  for s in "${ALL_SCRIPTS[@]}"; do
    name="$(get_step_name "$s")"
    if step_done "$name"; then
      ts="$(cat "${STATE_DIR}/${name}.done" 2>/dev/null || echo '?')"
      echo "  [OK]    $name  (concluída em $ts)"
    else
      echo "  [PEND]  $name"
    fi
  done
  exit 0
fi

log_info "Iniciando build LFS (toolchain + temporary tools)"
log_info "Diretório de scripts: $TOOLS_DIR"
log_info "LFS: $LFS"
log_info "Arquivos de estado: $STATE_DIR"
log_info "Logs das etapas: $LOG_DIR"

# Loop principal sobre as etapas selecionadas
for script in "${SELECTED_SCRIPTS[@]}"; do
  name="$(get_step_name "$script")"
  logfile="${LOG_DIR}/${name}.log"

  if step_done "$name" && [[ "$ARG_FORCE" -eq 0 ]]; then
    log_ok "Etapa $name já concluída anteriormente, pulando (use --force para refazer)."
    continue
  fi

  echo
  echo "============================================================"
  echo ">>> ETAPA: $name"
  echo ">>> Script: $script"
  echo ">>> Log: $logfile"
  echo "============================================================"

  # Registrar etapa em progresso
  echo "$name" > "${STATE_DIR}/_current_step"

  # Executar com tee para log
  {
    echo "=== Início da etapa $name em $(date -u +"%Y-%m-%dT%H:%M:%SZ") ==="
    echo "Comando: bash \"$script\""
  } > "$logfile"

  # Anexa stdout/stderr ao log e à tela
  if bash "$script" >>"$logfile" 2>&1; then
    mark_step_done "$name"
    rm -f "${STATE_DIR}/_current_step"
    log_ok "Etapa $name concluída com sucesso."
  else
    echo "=== FALHA na etapa $name em $(date -u +"%Y-%m-%dT%H:%M:%SZ") ===" >>"$logfile"
    log_error "Etapa $name falhou. Veja o log em: $logfile"
    log_error "Você pode corrigir o problema e rodar novamente:"
    log_error "  ./build-all.sh --from $name"
    exit 1
  fi
done

echo
log_ok "Todas as etapas selecionadas foram concluídas."
echo "Use './build-all.sh --status' para ver o status geral."
