#!/usr/bin/env bash
# Função utilitária para baixar e extrair fontes de pacotes de forma padronizada.
# Uso:
#   fetch_source "<SRC_DIR>" "<PKG_DIR>" "<TARBALL>" "<PRIMARY_URL>" [URL_ALT1] [URL_ALT2] ...
#
# Exemplo:
#   fetch_source "/sources" "bash-5.2.21" "bash-5.2.21.tar.gz" \
#       "https://ftp.gnu.org/gnu/bash/bash-5.2.21.tar.gz"
#
set -euo pipefail

fetch_source() {
  local src_dir="$1"; shift
  local pkg="$1"; shift
  local tarball="$1"; shift
  local primary_url="$1"; shift || true
  local alt_urls=("$@")

  mkdir -pv "$src_dir"
  cd "$src_dir"

  if [[ ! -f "$tarball" ]]; then
    if [[ -n "${primary_url:-}" ]]; then
      alt_urls=("$primary_url" "${alt_urls[@]}")
    fi
    if ((${#alt_urls[@]} == 0)); then
      echo "ERRO: nenhuma URL fornecida para baixar $tarball."
      exit 1
    fi
    echo "==> Baixando $tarball ..."
    local ok=0
    for url in "${alt_urls[@]}"; do
      [[ -z "$url" ]] && continue
      echo "  -> Tentando: $url"
      if command -v curl >/dev/null 2>&1; then
        if curl -fL "$url" -o "$tarball"; then
          ok=1
          break
        fi
      elif command -v wget >/dev/null 2>&1; then
        if wget -O "$tarball" "$url"; then
          ok=1
          break
        fi
      else
        echo "ERRO: nem curl nem wget disponíveis para baixar fontes."
        exit 1
      fi
    done
    if [[ "$ok" -ne 1 ]]; then
      echo "ERRO: falha ao baixar $tarball de todas as URLs fornecidas."
      exit 1
    fi
  fi

  if [[ ! -d "$pkg" ]]; then
    echo "==> Extraindo $tarball ..."
    tar -xf "$tarball"
  fi

  cd "$pkg"
}