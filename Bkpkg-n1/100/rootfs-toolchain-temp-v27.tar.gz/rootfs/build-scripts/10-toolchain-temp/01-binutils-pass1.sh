
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=binutils-2.42
TARBALL="${PKG}.tar.xz"
URL="https://sourceware.org/pub/binutils/releases/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

mkdir -v build
cd build

../configure \
  --prefix="$LFS/tools" \
  --with-sysroot="$LFS" \
  --target="$LFS_TGT" \
  --disable-nls \
  --enable-gprofng=no \
  --disable-werror \
  --enable-default-hash-style=gnu

make -j"$(nproc)"
make install

echo "Binutils pass1 instalado em $LFS/tools."
