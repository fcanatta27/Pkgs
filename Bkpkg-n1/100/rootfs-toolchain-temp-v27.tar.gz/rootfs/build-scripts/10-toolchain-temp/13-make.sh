
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=make-4.4.1
TARBALL="${PKG}.tar.gz"
URL="https://ftp.gnu.org/gnu/make/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

./configure --prefix=/usr        \
            --without-guile      \
            --host="$LFS_TGT"    \
            --build="$(build-aux/config.guess)"

make -j"$(nproc)"
make DESTDIR="$LFS" install

echo "Make instalado no rootfs temporário ($LFS/usr)."
