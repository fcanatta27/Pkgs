
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=grep-3.11
TARBALL="${PKG}.tar.xz"
URL="https://ftp.gnu.org/gnu/grep/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

./configure --prefix=/usr                           \
            --host="$LFS_TGT"                       \
            --build="$(./build-aux/config.guess)"

make -j"$(nproc)"
make DESTDIR="$LFS" install

echo "Grep instalado no rootfs temporário ($LFS/usr)."
