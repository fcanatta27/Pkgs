
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=gcc-13.2.0
GCC_TARBALL="${PKG}.tar.xz"
GCC_URL="https://ftp.gnu.org/gnu/gcc/${PKG}/${GCC_TARBALL}"

if [[ ! -f "$GCC_TARBALL" ]]; then
  wget -c "$GCC_URL"
fi

# Dependências internas do GCC
MPFR_TARBALL="mpfr-4.2.1.tar.xz"
GMP_TARBALL="gmp-6.3.0.tar.xz"
MPC_TARBALL="mpc-1.3.1.tar.gz"

MPFR_URL="https://ftp.gnu.org/gnu/mpfr/${MPFR_TARBALL}"
GMP_URL="https://ftp.gnu.org/gnu/gmp/${GMP_TARBALL}"
MPC_URL="https://ftp.gnu.org/gnu/mpc/${MPC_TARBALL}"

for t in "$MPFR_TARBALL" "$GMP_TARBALL" "$MPC_TARBALL"; do
  url_var="${t%%-*}_URL"
  url="${!url_var}"
  if [[ ! -f "$t" ]]; then
    wget -c "$url"
  fi
done

rm -rf "$PKG"
tar -xf "$GCC_TARBALL"
cd "$PKG"

tar -xf "../${MPFR_TARBALL}"
mv -v mpfr-4.2.1 mpfr
tar -xf "../${GMP_TARBALL}"
mv -v gmp-6.3.0 gmp
tar -xf "../${MPC_TARBALL}"
mv -v mpc-1.3.1 mpc

case $(uname -m) in
  x86_64)
    sed -e '/m64=/s/lib64/lib/' -i.orig gcc/config/i386/t-linux64
  ;;
esac

mkdir -v build
cd build

../configure \
  --target="$LFS_TGT" \
  --prefix="$LFS/tools" \
  --with-glibc-version=2.39 \
  --with-sysroot="$LFS" \
  --with-newlib \
  --without-headers \
  --enable-default-pie \
  --enable-default-ssp \
  --disable-nls \
  --disable-shared \
  --disable-multilib \
  --disable-threads \
  --disable-libatomic \
  --disable-libgomp \
  --disable-libquadmath \
  --disable-libssp \
  --disable-libvtv \
  --disable-libstdcxx \
  --enable-languages=c,c++

make -j"$(nproc)"
make install

cd ..
cat gcc/limitx.h gcc/glimits.h gcc/limity.h > \
  "$(dirname "$("$LFS_TGT-gcc" -print-libgcc-file-name)")/include/limits.h"

echo "GCC pass1 instalado em $LFS/tools e limits.h gerado."
