
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=xz-5.4.5
TARBALL="${PKG}.tar.xz"
URL="https://tukaani.org/xz/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

./configure --prefix=/usr                       \
            --host="$LFS_TGT"                   \
            --build="$(build-aux/config.guess)" \
            --disable-static                    \
            --docdir=/usr/share/doc/"$PKG"

make -j"$(nproc)"
make DESTDIR="$LFS" install

echo "XZ Utils instalado no rootfs temporário ($LFS/usr)."
