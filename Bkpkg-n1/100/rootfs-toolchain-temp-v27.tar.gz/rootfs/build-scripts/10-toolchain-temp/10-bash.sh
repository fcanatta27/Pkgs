
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=bash-5.2.21
TARBALL="${PKG}.tar.gz"
URL="https://ftp.gnu.org/gnu/bash/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

./configure --prefix=/usr                        \
            --build="$(sh support/config.guess)" \
            --host="$LFS_TGT"                    \
            --without-bash-malloc

make -j"$(nproc)"
make DESTDIR="$LFS" install

ln -sv bash "$LFS/bin/sh" || true

echo "Bash instalado no rootfs temporário ($LFS/usr) e linkado como /bin/sh."
