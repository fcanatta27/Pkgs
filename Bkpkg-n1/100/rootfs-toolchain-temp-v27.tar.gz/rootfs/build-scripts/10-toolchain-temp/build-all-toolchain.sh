#!/usr/bin/env bash
# build-all-toolchain.sh - constrói toolchain completo via pkg
set -euo pipefail

LOGDIR=${LOGDIR:-/var/log/lfs-build}
mkdir -pv "$LOGDIR"

log() { echo "[toolchain] $*"; }

log "Instalando toolchain matemático (gmp, mpfr, mpc, isl, zlib)..."
pkg install gmp mpfr mpc isl zlib 2>&1 | tee -a "$LOGDIR/toolchain-libs.log"

log "Instalando binutils..."
pkg install binutils 2>&1 | tee -a "$LOGDIR/toolchain-binutils.log"

log "Instalando GCC..."
pkg install gcc 2>&1 | tee -a "$LOGDIR/toolchain-gcc.log"

log "Toolchain base instalado via pkg."
