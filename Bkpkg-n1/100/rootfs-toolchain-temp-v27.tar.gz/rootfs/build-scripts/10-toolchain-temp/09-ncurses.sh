
#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  echo "ERRO: este script deve ser executado como usuário 'lfs', não como root."
  exit 1
fi

: "${LFS:?Defina LFS (ex: export LFS=/mnt/lfs)}"
export LFS_TGT="${LFS_TGT:-$(uname -m)-lfs-linux-gnu}"
export SRC_DIR="$LFS/sources"

mkdir -pv "$SRC_DIR"
cd "$SRC_DIR"

PKG=ncurses-6.4
TARBALL="${PKG}.tar.gz"
URL="https://ftp.gnu.org/gnu/ncurses/${TARBALL}"

if [[ ! -f "$TARBALL" ]]; then
  wget -c "$URL"
fi

rm -rf "$PKG"
tar -xf "$TARBALL"
cd "$PKG"

sed -i 's/mawk//g' configure

mkdir -v build
pushd build
  ../configure
  make -C include
  make -C progs tic
popd

./configure --prefix=/usr                \
            --host="$LFS_TGT"            \
            --build="$(./config.guess)"  \
            --mandir=/usr/share/man      \
            --with-manpage-format=normal \
            --with-shared                \
            --without-normal             \
            --with-cxx-shared            \
            --without-debug              \
            --without-ada                \
            --disable-stripping          \
            --enable-widec

make -j"$(nproc)"

make DESTDIR="$LFS" TIC_PATH="$(pwd)/build/progs/tic" install

ln -sv libncursesw.so "$LFS/usr/lib/libncurses.so"
sed -e 's/^#if.*XOPEN.*$/#if 1/' -i "$LFS/usr/include/curses.h"

echo "Ncurses instalado no rootfs temporário ($LFS/usr)."
