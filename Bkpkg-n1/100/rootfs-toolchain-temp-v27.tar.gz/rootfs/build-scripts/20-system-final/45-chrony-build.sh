#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"

echo "==> Construindo e instalando chrony (NTP cliente/servidor)..."

SRC_DIR=/sources
PKG="chrony-4.5"
TARBALL="chrony-4.5.tar.gz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://download.tuxfamily.org/chrony/chrony-4.5.tar.gz"

cd "$PKG"

./configure --prefix=/usr \
            --sysconfdir=/etc \
            --chronyrundir=/run/chrony

make -j"$(nproc)"
make install

install -vdm755 /var/lib/chrony

# Configuração padrão
if [[ ! -f /etc/chrony.conf ]]; then
  cat > /etc/chrony.conf << 'EOF'
# /etc/chrony.conf - configuração básica
pool pool.ntp.org iburst
driftfile /var/lib/chrony/drift
makestep 1.0 3
rtcsync
logdir /var/log/chrony
EOF
fi

echo "chrony instalado."
