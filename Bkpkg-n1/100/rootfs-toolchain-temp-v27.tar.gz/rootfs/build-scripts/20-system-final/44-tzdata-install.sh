#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"

echo "==> Instalando tzdata (fuso horário e zona horária)..."

SRC_DIR=/sources
PKG="tzdata2024a"
TARBALL="tzdata2024a.tar.gz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://data.iana.org/time-zones/releases/tzdata2024a.tar.gz"

cd "$PKG"

ZONEDIR=/usr/share/zoneinfo
install -vdm755 "$ZONEDIR"

# Compiling/Installing zoneinfo is normally done via zic; assume pre-built tzdata tree here.
# Se o pacote já contiver os arquivos prontos, apenas copie.
cp -av * "$ZONEDIR" || true

echo "Zonas horárias instaladas em $ZONEDIR."

# Configurar timezone do sistema
read -rp "Informe a timezone (ex: America/Sao_Paulo): " TZ
TZ=${TZ:-America/Sao_Paulo}

if [[ -f "$ZONEDIR/$TZ" ]]; then
  ln -sfv "$ZONEDIR/$TZ" /etc/localtime
  echo "$TZ" > /etc/timezone
  echo "Timezone configurada para $TZ."
else
  echo "AVISO: timezone $TZ não encontrada em $ZONEDIR. Ajuste manualmente depois."
fi
