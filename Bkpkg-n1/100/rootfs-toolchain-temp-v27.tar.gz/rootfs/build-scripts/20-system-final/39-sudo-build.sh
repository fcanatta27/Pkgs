#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"

echo "==> Construindo e instalando sudo..."

SRC_DIR=/sources
PKG="sudo-1.9.15p2"
TARBALL="sudo-1.9.15p2.tar.gz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://www.sudo.ws/dist/sudo-1.9.15p2.tar.gz"

cd "$PKG"

./configure --prefix=/usr \
            --libexecdir=/usr/lib/sudo \
            --with-secure-path="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin" \
            --with-pam \
            --with-env-editor \
            --docdir=/usr/share/doc/"$PKG"

make -j"$(nproc)"
make install

echo "sudo instalado."
