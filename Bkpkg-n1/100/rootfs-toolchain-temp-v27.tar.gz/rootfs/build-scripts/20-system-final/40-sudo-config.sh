#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Configurando sudo (sudoers)..."

if ! command -v visudo >/dev/null 2>&1; then
  echo "ERRO: visudo não encontrado, certifique-se que sudo foi instalado (39-sudo-build.sh)."
  exit 1
fi

# Garante grupo wheel
if ! getent group wheel >/dev/null; then
  groupadd wheel
fi

# Se sudoers já existe, faz backup
if [[ -f /etc/sudoers ]]; then
  cp -v /etc/sudoers /etc/sudoers.bak.$(date +%Y%m%d%H%M%S)
fi

cat > /etc/sudoers << 'EOF'
#
# /etc/sudoers - arquivo de configuração sudo
#

Defaults env_reset
Defaults mail_badpass
Defaults secure_path="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

# Membros do grupo wheel podem usar sudo
%wheel  ALL=(ALL:ALL) ALL

# Permitir sudo sem senha (descomente se desejar)
# %wheel ALL=(ALL:ALL) NOPASSWD: ALL
EOF

chmod 440 /etc/sudoers

echo "sudo configurado para grupo wheel. Use 'usermod -aG wheel <usuario>' para habilitar."
