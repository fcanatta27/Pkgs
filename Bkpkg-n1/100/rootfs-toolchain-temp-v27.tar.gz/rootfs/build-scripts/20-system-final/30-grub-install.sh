#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Instalação do GRUB (modo BIOS/MBR)"

if ! command -v grub-install >/dev/null 2>&1; then
  echo "ERRO: grub-install não encontrado. Certifique-se de ter instalado o GRUB no chroot."
  exit 1
fi

read -rp "Informe o disco onde instalar o GRUB (ex: /dev/sda): " GRUB_DISK

if [[ -z "$GRUB_DISK" ]]; then
  echo "ERRO: disco não informado."
  exit 1
fi

echo "ATENÇÃO: Isto instalará o GRUB no MBR de $GRUB_DISK."
read -rp "Tem certeza? Digite 'SIM' para confirmar: " CONFIRM

if [[ "$CONFIRM" != "SIM" ]]; then
  echo "Instalação do GRUB cancelada."
  exit 1
fi

echo "==> Executando grub-install em $GRUB_DISK..."
grub-install "$GRUB_DISK"

echo "==> Gerando /boot/grub/grub.cfg básico..."

mkdir -pv /boot/grub

ROOT_HINT="(hd0,1)"

cat > /boot/grub/grub.cfg << 'EOF'
set default=0
set timeout=5

menuentry "LFS GNU/Linux" {
    insmod ext2
    set root=(hd0,1)
    linux   /boot/vmlinuz root=/dev/sda1 ro
}
EOF

echo "Arquivo /boot/grub/grub.cfg criado."
echo "Ajuste 'set root' e 'root=/dev/sda1' conforme seu layout de disco real."
