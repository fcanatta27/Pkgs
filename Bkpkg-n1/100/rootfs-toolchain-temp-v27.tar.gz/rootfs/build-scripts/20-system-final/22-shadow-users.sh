#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Criação de usuário(s) real(is) para uso diário..."

# Certificar que shadow está instalado
if ! command -v useradd >/dev/null 2>&1; then
  echo "ERRO: useradd não encontrado. Execute 21-shadow-build.sh antes."
  exit 1
fi

read -rp "Nome do usuário padrão (ex: user): " NEWUSER
NEWUSER=${NEWUSER:-user}

read -rp "Nome completo (GECOS) desse usuário: " FULLNAME
FULLNAME=${FULLNAME:-Usuário LFS}

read -rp "Adicionar usuário ao grupo wheel (sudo-like)? [s/N]: " ADDWHEEL
ADDWHEEL=${ADDWHEEL:-N}

if id "$NEWUSER" >/dev/null 2>&1; then
  echo "Usuário $NEWUSER já existe, pulando criação."
else
  useradd -m -k /etc/skel -c "$FULLNAME" -s /bin/bash "$NEWUSER"
  echo "Defina uma senha para $NEWUSER:"
  passwd "$NEWUSER"
fi

# Garantir /etc/skel básico
if [[ ! -d /etc/skel ]]; then
  mkdir -pv /etc/skel
fi

if [[ ! -f /etc/skel/.bash_profile ]]; then
  cat > /etc/skel/.bash_profile << 'EOF'
# ~/.bash_profile padrão
[[ -f ~/.bashrc ]] && . ~/.bashrc
EOF
fi

if [[ ! -f /etc/skel/.bashrc ]]; then
  cat > /etc/skel/.bashrc << 'EOF'
# ~/.bashrc padrão
PS1='\u@\h:\w\$ '
alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'
EOF
fi

# Grupo wheel opcional (para uso futuro de sudo, se instalado)
if [[ "$ADDWHEEL" =~ ^[sS]$ ]]; then
  if ! getent group wheel >/dev/null; then
    groupadd wheel
  fi
  usermod -aG wheel "$NEWUSER"
  echo "Usuário $NEWUSER adicionado ao grupo wheel."
fi

echo "Criação de usuário(s) finalizada."
