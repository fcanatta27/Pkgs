#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Preparando build do kernel Linux..."

SRC_DIR=/sources
KERNEL_PKG="linux-6.7.4"

# Permitir override via variável KERNEL_PKG se já definido
if [[ -n "${KERNEL_VERSION:-}" ]]; then
  KERNEL_PKG="linux-${KERNEL_VERSION}"
fi

if [[ ! -d "$SRC_DIR" ]]; then
  echo "ERRO: diretório de fontes não encontrado: $SRC_DIR"
  echo "Copie o tarball do kernel para /sources e extraia."
  exit 1
fi

cd "$SRC_DIR"

if [[ ! -d "$KERNEL_PKG" ]]; then
  # tentar descompactar se houver tarball
  if ls linux-*.tar.* >/dev/null 2>&1; then
    tarball="$(ls linux-*.tar.* | head -n1)"
    echo "Extraindo $tarball..."
    rm -rf linux-*
    tar -xf "$tarball"
  else
    echo "ERRO: não foi encontrado diretório $KERNEL_PKG nem tarball linux-*.tar.* em $SRC_DIR."
    exit 1
  fi
fi

cd "$KERNEL_PKG"

# Se não existir .config, gera uma configuração base usando defconfig
if [[ ! -f .config ]]; then
  echo "==> Nenhuma configuração .config encontrada, usando 'defconfig' padrão da arquitetura..."
  make mrproper
  make defconfig
else
  echo "==> Usando configuração de kernel existente (.config)."
  make olddefconfig
fi

echo "==> Compilando kernel e módulos... (isso pode demorar)"
make -j"$(nproc)"
make modules_install

echo "==> Instalando artefatos em /boot..."

KVER="$(make kernelrelease)"
install -v -m 0755 arch/$(uname -m)/boot/bzImage /boot/vmlinuz-"${KVER}"
cp -v System.map /boot/System.map-"${KVER}"
cp -v .config /boot/config-"${KVER}"

# Atualizar symlinks genéricos
ln -sfv vmlinuz-"${KVER}" /boot/vmlinuz
ln -sfv System.map-"${KVER}" /boot/System.map
ln -sfv config-"${KVER}" /boot/config

echo "Kernel ${KVER} instalado em /boot."