#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Instalando SysVinit..."

SRC_DIR=/sources
PKG="sysvinit-3.08"
TARBALL="sysvinit-3.08.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://download.savannah.nongnu.org/releases/sysvinit/sysvinit-3.08.tar.xz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls sysvinit-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls sysvinit-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado sysvinit em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

# Em algumas versões, há conflitos com /usr/bin/kill e /usr/bin/pidof.
# O LFS normalmente resolve isso renomeando ou ajustando.
sed -i 's@/bin/kill@/usr/bin/kill@g' src/killall5.c || true

make -j"$(nproc)"
make install

echo "SysVinit instalado. Binários chave: /sbin/init, /sbin/halt, /sbin/reboot, etc."