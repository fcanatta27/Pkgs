#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando automake..."

SRC_DIR=/sources
PKG="automake-1.16.5"
TARBALL="automake-1.16.5.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://ftp.gnu.org/gnu/automake/automake-1.16.5.tar.xz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls automake-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls automake-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado automake em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

./configure --prefix=/usr --docdir=/usr/share/doc/"$PKG"
make -j"$(nproc)"
make install

echo "automake instalado."