#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando inetutils..."

SRC_DIR=/sources
PKG="inetutils-2.4"
TARBALL="inetutils-2.4.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://ftp.gnu.org/gnu/inetutils/inetutils-2.4.tar.xz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls inetutils-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls inetutils-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado inetutils em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

./configure --prefix=/usr \
            --bindir=/usr/bin \
            --sysconfdir=/etc \
            --localstatedir=/var \
            --disable-logger \
            --disable-whois \
            --disable-rcp \
            --disable-rexec \
            --disable-rlogin \
            --disable-rsh

make -j"$(nproc)"
make install

echo "inetutils instalado (ping, hostname, etc.)."