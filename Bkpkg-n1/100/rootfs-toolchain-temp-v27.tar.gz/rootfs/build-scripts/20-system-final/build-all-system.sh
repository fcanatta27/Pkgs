#!/usr/bin/env bash
# build-all-system.sh - constrói o sistema final via pkg (para rodar dentro do chroot)
set -euo pipefail

LOGDIR=${LOGDIR:-/var/log/lfs-build}
mkdir -pv "$LOGDIR"

log() { echo "[system-final] $*"; }

log "Instalando kernel e glibc..."
pkg install linux-headers glibc linux linux-firmware 2>&1 | tee -a "$LOGDIR/system-kernel-glibc.log"

log "Instalando base de usuário (bash, coreutils, util-linux)..."
pkg install bash coreutils util-linux 2>&1 | tee -a "$LOGDIR/system-base.log"

log "Instalando stack de rede/SSL e ferramentas..."
pkg install openssl zlib xz zstd curl git 2>&1 | tee -a "$LOGDIR/system-net-ssl.log"

log "Instalando ferramentas de desenvolvimento (autotools, cmake, ninja)..."
pkg install autotools cmake ninja 2>&1 | tee -a "$LOGDIR/system-dev.log"

log "Instalando linguagens (python3, pip, rust)..."
pkg install python3 pip rust 2>&1 | tee -a "$LOGDIR/system-lang.log"

log "Construção do sistema final concluída via pkg."
