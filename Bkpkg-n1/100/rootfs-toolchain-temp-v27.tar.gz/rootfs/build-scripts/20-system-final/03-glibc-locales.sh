#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Gerando locales da Glibc..."

# Verificar se localedef existe
if ! command -v localedef >/dev/null 2>&1; then
  echo "ERRO: localedef não encontrado. Certifique-se que glibc final está instalada."
  exit 1
fi

# Exemplos de locales (adicione ou remova conforme necessidade)
locales=(
  "C.UTF-8 UTF-8"
  "en_US ISO-8859-1"
  "en_US.UTF-8 UTF-8"
  "pt_BR ISO-8859-1"
  "pt_BR.UTF-8 UTF-8"
)

for entry in "${locales[@]}"; do
  lang="${entry%% *}"
  charset="${entry##* }"
  echo "  -> localedef -i ${lang%%.*} -f $charset $lang"
  case "$lang" in
    C.UTF-8)
      localedef -i C -f UTF-8 C.UTF-8 || true
      ;;
    *)
      base="${lang%%.*}"
      localedef -i "$base" -f "$charset" "$lang" || true
      ;;
  esac
done

echo "==> Criando /etc/locale.conf padrão..."
cat > /etc/locale.conf << 'EOF'
LANG=pt_BR.UTF-8
LC_COLLATE=C
EOF

echo "==> Criando /etc/nsswitch.conf padrão..."
cat > /etc/nsswitch.conf << 'EOF'
passwd: files
group:  files
shadow: files

hosts:  files dns
networks: files

protocols: files
services:  files
ethers:   files
rpc:      files
EOF

echo "==> Atualizando cache de bibliotecas compartilhadas (ldconfig)..."
if command -v ldconfig >/dev/null 2>&1; then
  ldconfig
fi

echo "Locales da glibc e arquivos de configuração principais criados."
