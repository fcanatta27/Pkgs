#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando wget..."

SRC_DIR=/sources
PKG="wget-1.24.5"
TARBALL="wget-1.24.5.tar.gz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://ftp.gnu.org/gnu/wget/wget-1.24.5.tar.gz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls wget-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls wget-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado wget em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

./configure --prefix=/usr \
            --sysconfdir=/etc \
            --with-ssl=openssl

make -j"$(nproc)"
make install

# wgetrc global
if [[ ! -f /etc/wgetrc ]]; then
  cat > /etc/wgetrc << 'EOF'
# /etc/wgetrc - configurações globais
check_certificate = on
hsts = on
hsts-file = /var/lib/wget-hsts
EOF
fi

echo "wget instalado."