#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Aplicando endurecimento básico de permissões (permissions hardening)..."

# /tmp e /var/tmp devem ser world-writable com sticky bit
install -vdm 1777 /tmp
install -vdm 1777 /var/tmp

# Logs
install -vdm 0750 /var/log
chown root:adm /var/log 2>/dev/null || true

# Arquivos de log padrões
touch /var/log/{wtmp,btmp,lastlog,faillog}
chmod 664 /var/log/wtmp /var/log/lastlog
chmod 600 /var/log/btmp /var/log/faillog

# Mail spool
install -vdm 0770 /var/spool/mail
chgrp mail /var/spool/mail 2>/dev/null || true

# Diretório home do root
chmod 700 /root

# /etc/shadow e /etc/gshadow
chmod 600 /etc/shadow /etc/gshadow 2>/dev/null || true
chown root:root /etc/shadow /etc/gshadow 2>/dev/null || true

echo "Permissões básicas de segurança aplicadas."
