#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando kmod (módulos do kernel)..."

SRC_DIR=/sources
PKG="kmod-32"
TARBALL="kmod-32.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://www.kernel.org/pub/linux/utils/kernel/kmod/kmod-32.tar.xz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls kmod-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls kmod-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado kmod em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

./configure --prefix=/usr \
            --bindir=/usr/bin \
            --sysconfdir=/etc \
            --with-xz \
            --with-zstd \
            --with-zlib \
            --disable-static

make -j"$(nproc)"
make install

# Criar links tradicionais para compatibilidade
for tool in depmod insmod lsmod modinfo modprobe rmmod; do
  ln -sfv kmod "/usr/bin/${tool}"
done

echo "kmod instalado e links de compatibilidade criados."