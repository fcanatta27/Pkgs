#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Criando serviço SysV 'firewall' baseado em iptables..."

RC_DIR=/etc/rc.d
INITD=${RC_DIR}/init.d
FWDIR=/etc/firewall

install -vdm755 "$INITD"
install -vdm700 "$FWDIR"

# Arquivos de regras padrão (vazios, o admin deve preencher)
: > "${FWDIR}/rules.v4"
: > "${FWDIR}/rules.v6"

# Script de serviço
cat > "${INITD}/firewall" << 'EOF'
#!/bin/sh
# /etc/rc.d/init.d/firewall - aplica regras de firewall (iptables/ip6tables)
### BEGIN INIT INFO
# Provides:          firewall
# Required-Start:    $network
# Required-Stop:     $network
# Default-Start:     3 4 5
# Default-Stop:      0 1 2 6
# Short-Description: Firewall de iptables/ip6tables
### END INIT INFO

RULESDIR=/etc/firewall
IPTABLES=/usr/sbin/iptables
IP6TABLES=/usr/sbin/ip6tables

load_rules() {
  if [ -x "$IPTABLES" ] && [ -f "$RULESDIR/rules.v4" ]; then
    echo "  -> Aplicando regras IPv4..."
    $IPTABLES-restore < "$RULESDIR/rules.v4"
  fi
  if [ -x "$IP6TABLES" ] && [ -f "$RULESDIR/rules.v6" ]; then
    echo "  -> Aplicando regras IPv6..."
    $IP6TABLES-restore < "$RULESDIR/rules.v6"
  fi
}

flush_rules() {
  if [ -x "$IPTABLES" ]; then
    $IPTABLES -F
    $IPTABLES -X
    $IPTABLES -t nat -F
    $IPTABLES -t nat -X
    $IPTABLES -t mangle -F
    $IPTABLES -t mangle -X
  fi
  if [ -x "$IP6TABLES" ]; then
    $IP6TABLES -F
    $IP6TABLES -X
    $IP6TABLES -t mangle -F
    $IP6TABLES -t mangle -X
  fi
}

case "$1" in
  start)
    echo "Iniciando firewall..."
    flush_rules
    load_rules
    ;;
  stop)
    echo "Parando firewall (limpando regras)..."
    flush_rules
    ;;
  restart|reload)
    "$0" stop
    "$0" start
    ;;
  status)
    echo "Regras IPv4:"
    [ -x "$IPTABLES" ] && $IPTABLES -L -n -v || echo "iptables não disponível."
    echo
    echo "Regras IPv6:"
    [ -x "$IP6TABLES" ] && $IP6TABLES -L -n -v || echo "ip6tables não disponível."
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|status}"
    exit 1
    ;;
esac

exit 0
EOF

chmod +x "${INITD}/firewall"

# Links nos runlevels
create_links() {
  local base="$1" rc="$2" order="$3" action="$4"
  local dir="${RC_DIR}/rc${rc}.d"
  install -vdm755 "$dir"
  ln -sfv "../init.d/${base}" "${dir}/${action}${order}${base}"
}

create_links firewall 3 20 S
create_links firewall 4 20 S
create_links firewall 5 20 S
create_links firewall 0 80 K
create_links firewall 1 80 K
create_links firewall 2 80 K
create_links firewall 6 80 K

echo "Serviço de firewall criado. Edite /etc/firewall/rules.v4 e rules.v6 conforme necessário."
