#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Criando configurações extras em /etc..."

# /etc/resolv.conf (apenas cria se ainda não existir)
if [[ ! -f /etc/resolv.conf ]]; then
  cat > /etc/resolv.conf << 'EOF'
# /etc/resolv.conf - servidores DNS padrão
# Ajuste estes valores para o seu ambiente de rede real.

# DNS públicos comuns:
nameserver 1.1.1.1
nameserver 8.8.8.8

# Opcionalmente, defina domínio de busca:
# search exemplo.local
EOF
  echo "Arquivo /etc/resolv.conf criado."
else
  echo "/etc/resolv.conf já existe, mantendo arquivo atual."
fi

# /etc/hosts (apenas cria se ainda não existir)
if [[ ! -f /etc/hosts ]]; then
  cat > /etc/hosts << 'EOF'
# /etc/hosts - mapeamento de hosts locais
127.0.0.1   localhost
127.0.1.1   lfs

# IPv6
::1         localhost ip6-localhost ip6-loopback
ff02::1     ip6-allnodes
ff02::2     ip6-allrouters
EOF
  echo "Arquivo /etc/hosts criado."
else
  echo "/etc/hosts já existe, mantendo arquivo atual."
fi

# /etc/dhcpcd.conf (apenas cria se ainda não existir)
if [[ ! -f /etc/dhcpcd.conf ]]; then
  cat > /etc/dhcpcd.conf << 'EOF'
# /etc/dhcpcd.conf - configuração padrão de dhcpcd
# Esta configuração é genérica. Ajuste conforme as necessidades da sua rede.

hostname
clientid
persistent
option rapid_commit
option domain_name_servers, domain_name, domain_search, host_name
option classless_static_routes
option interface_mtu
require dhcp_server_identifier
slaac private

# Exemplo de configuração específica por interface:
# interface eth0
#   static ip_address=192.168.1.10/24
#   static routers=192.168.1.1
#   static domain_name_servers=192.168.1.1
EOF
  echo "Arquivo /etc/dhcpcd.conf criado."
else
  echo "/etc/dhcpcd.conf já existe, mantendo arquivo atual."
fi

echo "Configurações extras em /etc criadas/atualizadas."
