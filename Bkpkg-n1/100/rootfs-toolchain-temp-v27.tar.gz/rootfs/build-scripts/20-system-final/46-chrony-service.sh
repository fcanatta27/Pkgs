#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Criando serviço SysV para chronyd..."

RC_DIR=/etc/rc.d
INITD=${RC_DIR}/init.d

install -vdm755 "$INITD"

cat > "${INITD}/chrony" << 'EOF'
#!/bin/sh
# /etc/rc.d/init.d/chrony - serviço NTP (chronyd)
### BEGIN INIT INFO
# Provides:          chrony
# Required-Start:    $local_fs $network
# Required-Stop:     $local_fs $network
# Default-Start:     3 4 5
# Default-Stop:      0 1 2 6
# Short-Description: NTP daemon chronyd
### END INIT INFO

DAEMON=/usr/sbin/chronyd
PIDFILE=/run/chrony/chronyd.pid

case "$1" in
  start)
    echo "Iniciando chronyd..."
    if [ ! -x "$DAEMON" ]; then
      echo "  !! $DAEMON não encontrado."
      exit 1
    fi
    "$DAEMON"
    ;;
  stop)
    echo "Parando chronyd..."
    if [ -f "$PIDFILE" ]; then
      kill "$(cat "$PIDFILE")" 2>/dev/null || true
    fi
    killall chronyd 2>/dev/null || true
    ;;
  restart|reload)
    "$0" stop
    "$0" start
    ;;
  status)
    if pgrep -x chronyd >/dev/null 2>&1; then
      echo "chronyd está em execução."
    else
      echo "chronyd NÃO está em execução."
    fi
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|status}"
    exit 1
    ;;
esac

exit 0
EOF

chmod +x "${INITD}/chrony"

create_links() {
  local base="$1" rc="$2" order="$3" action="$4"
  local dir="${RC_DIR}/rc${rc}.d"
  install -vdm755 "$dir"
  ln -sfv "../init.d/${base}" "${dir}/${action}${order}${base}"
}

create_links chrony 3 30 S
create_links chrony 4 30 S
create_links chrony 5 30 S
create_links chrony 0 70 K
create_links chrony 1 70 K
create_links chrony 2 70 K
create_links chrony 6 70 K

echo "Serviço chronyd criado e habilitado para runlevels 3,4,5."
