#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Configurando udev (regras básicas)..."

# Exemplo de regra para dispositivos de bloco sem nome persistente
cat > /etc/udev/rules.d/10-local-permissions.rules << 'EOF'
# Torna dispositivos de disco acessíveis somente ao root por padrão
SUBSYSTEM=="block", MODE="0600"

# Permitir acesso ao grupo cdrom para unidades de CD/DVD
SUBSYSTEM=="block", KERNEL=="sr[0-9]*", GROUP="cdrom", MODE="0660"
EOF

# Regra de nome de rede opcional (pode ser ajustada para desativar nomes previsíveis)
cat > /etc/udev/rules.d/80-net-name-slot.rules << 'EOF'
# Exemplo para manter eth0 em sistemas simples
SUBSYSTEM=="net", ACTION=="add", DRIVERS=="?*", NAME="eth0"
EOF

echo "Regras básicas de udev criadas."
