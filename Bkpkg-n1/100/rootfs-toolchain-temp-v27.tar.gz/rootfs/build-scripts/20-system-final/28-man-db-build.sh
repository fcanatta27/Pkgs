#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando man-db (visualizador de manpages)..."

SRC_DIR=/sources
PKG="man-db-2.11.2"
TARBALL="man-db-2.11.2.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://download.savannah.gnu.org/releases/man-db/man-db-2.11.2.tar.xz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls man-db-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls man-db-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado man-db em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

./configure --prefix=/usr \
            --docdir=/usr/share/doc/"$PKG" \
            --sysconfdir=/etc \
            --disable-setuid \
            --enable-mandirs=/usr/share/man \
            --with-systemdtmpfilesdir= \
            --with-systemdsystemunitdir=

make -j"$(nproc)"
make install

echo "man-db instalado. Use 'mandb' para atualizar o banco de manpages."