#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR%/*}/lib/fetch.sh"


if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: este script deve ser executado como root DENTRO do chroot LFS."
  exit 1
fi

# Dentro do chroot, / é o antigo $LFS

echo "==> Construindo e instalando curl..."

SRC_DIR=/sources
PKG="curl-8.7.1"
TARBALL="curl-8.7.1.tar.xz"

fetch_source "$SRC_DIR" "$PKG" "$TARBALL" "https://curl.se/download/curl-8.7.1.tar.xz"

cd "$SRC_DIR"

if [[ ! -d "$PKG" ]]; then
  if [[ -f "$TARBALL" ]]; then
    tar -xf "$TARBALL"
  elif ls curl-*.tar.* >/dev/null 2>&1; then
    TARBALL="$(ls curl-*.tar.* | head -n1)"
    tar -xf "$TARBALL"
    PKG="${TARBALL%.tar.*}"
  else
    echo "ERRO: não foi encontrado curl em $SRC_DIR."
    exit 1
  fi
fi

cd "$PKG"

./configure --prefix=/usr \
            --disable-static \
            --with-openssl \
            --enable-threaded-resolver \
            --with-ca-path=/etc/ssl/certs

make -j"$(nproc)"
make install

# curlrc global opcional
if [[ ! -f /etc/curlrc ]]; then
  cat > /etc/curlrc << 'EOF'
# /etc/curlrc - configurações globais simples
# Exemplo: sempre mostrar progresso, seguir redirects.
--progress-bar
--location
EOF
fi

echo "curl instalado."