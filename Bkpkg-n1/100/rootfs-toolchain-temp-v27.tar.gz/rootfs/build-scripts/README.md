LFS build-scripts integration
=============================

Este diretório contém um projeto de scripts de construção inspirado no LFS,
organizado em estágios e integrado com o gerenciador de pacotes 'pkg'.

Layout:
  00-prepare/     -> preparação de ambiente, disco, montagem e chroot
  10-toolchain-temp/ -> construção do toolchain temporário / base de compilação
  20-system-final/   -> construção do sistema final dentro do chroot
  30-post-install/   -> verificações e ajustes pós-instalação

Os scripts são projetados para serem idempotentes sempre que possível, com logs
em /var/log/lfs-build e mensagens claras em cada passo.
