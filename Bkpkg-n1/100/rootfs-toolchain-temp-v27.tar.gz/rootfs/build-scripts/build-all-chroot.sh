#!/usr/bin/env bash
# build-all-chroot.sh
# Orquestrador para construção do "sistema final" dentro do chroot LFS.
#
# Este script deve ser executado *dentro* do chroot, como root.
# Ele procura scripts em build-scripts/20-system-final/*.sh e os executa
# em ordem, com:
#   - logs por etapa
#   - arquivos de estado (.done)
#   - suporte a resume (--from/--to/--only)
#
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERRO: build-all-chroot.sh deve ser executado como root dentro do chroot."
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FINAL_DIR="${SCRIPT_DIR}/20-system-final"

STATE_DIR="/var/lib/lfs-build-state-chroot"
LOG_DIR="/var/log/lfs-build-logs-chroot"

mkdir -pv "$STATE_DIR" "$LOG_DIR"

USE_COLOR=1
for arg in "$@"; do
  [[ "$arg" == "--no-color" ]] && USE_COLOR=0
done

if [[ "$USE_COLOR" -eq 1 ]]; then
  C_RESET=$'\e[0m'
  C_INFO=$'\e[34m'
  C_WARN=$'\e[33m'
  C_OK=$'\e[32m'
  C_ERR=$'\e[31m'
else
  C_RESET=""
  C_INFO=""
  C_WARN=""
  C_OK=""
  C_ERR=""
fi

log_info()  { echo "${C_INFO}[INFO]${C_RESET}  $*"; }
log_warn()  { echo "${C_WARN}[WARN]${C_RESET}  $*"; }
log_ok()    { echo "${C_OK}[OK]${C_RESET}    $*"; }
log_error() { echo "${C_ERR}[ERRO]${C_RESET}  $*"; }

usage() {
  cat << 'EOF'
build-all-chroot.sh - Orquestrador das etapas do sistema final (dentro do chroot)

Uso:
  ./build-all-chroot.sh [opções]

Opções:
  --list                 Lista todas as etapas conhecidas e sai
  --status               Mostra o status (pendente/concluída) de cada etapa
  --from NOME            Começa a partir da etapa NOME (ex: 01-kernel-headers-final)
  --to NOME              Para após a etapa NOME (inclusive)
  --only NOME            Executa apenas a etapa NOME
  --force                Reexecuta etapas já concluídas (ignora .done)
  --no-color             Desativa cores no output
  -h, --help             Mostra esta ajuda
EOF
}

ARG_FROM=""
ARG_TO=""
ARG_ONLY=""
ARG_FORCE=0
ARG_LIST=0
ARG_STATUS=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --from)   ARG_FROM="${2:-}"; shift 2;;
    --to)     ARG_TO="${2:-}";   shift 2;;
    --only)   ARG_ONLY="${2:-}"; shift 2;;
    --force)  ARG_FORCE=1;       shift;;
    --list)   ARG_LIST=1;        shift;;
    --status) ARG_STATUS=1;      shift;;
    --no-color) shift;;
    -h|--help) usage; exit 0;;
    *)
      log_warn "Argumento desconhecido: $1"
      usage
      exit 1
      ;;
  esac
done

if [[ ! -d "$FINAL_DIR" ]]; then
  log_error "Diretório de scripts do sistema final não existe: $FINAL_DIR"
  exit 1
fi

mapfile -t ALL_SCRIPTS < <(find "$FINAL_DIR" -maxdepth 1 -type f -name '*.sh' | sort)

get_step_name() {
  local path="$1"
  basename "$path" .sh
}

step_done() {
  local name="$1"
  [[ -f "${STATE_DIR}/${name}.done" ]]
}

mark_step_done() {
  local name="$1"
  date -u +"%Y-%m-%dT%H:%M:%SZ" > "${STATE_DIR}/${name}.done"
}

if [[ "$ARG_LIST" -eq 1 ]]; then
  if [[ "${#ALL_SCRIPTS[@]}" -eq 0 ]]; then
    echo "Nenhuma etapa (script) ainda definida em $FINAL_DIR."
  else
    echo "Etapas disponíveis (na ordem):"
    for s in "${ALL_SCRIPTS[@]}"; do
      echo "  $(get_step_name "$s")"
    done
  fi
  exit 0
fi

if [[ "$ARG_STATUS" -eq 1 ]]; then
  if [[ "${#ALL_SCRIPTS[@]}" -eq 0 ]]; then
    echo "Nenhuma etapa (script) ainda definida em $FINAL_DIR."
  else
    echo "Status das etapas:"
    for s in "${ALL_SCRIPTS[@]}"; do
      name="$(get_step_name "$s")"
      if step_done "$name"; then
        ts="$(cat "${STATE_DIR}/${name}.done" 2>/dev/null || echo '?')"
        echo "  [OK]   $name  (concluída em $ts)"
      else
        echo "  [PEND] $name"
      fi
    done
  fi
  exit 0
fi

if [[ "${#ALL_SCRIPTS[@]}" -eq 0 ]]; then
  log_warn "Nenhum script encontrado em $FINAL_DIR."
  log_warn "Crie scripts como 20-system-final/01-alguma-coisa.sh e rode de novo."
  exit 0
fi

SELECTED_SCRIPTS=()

if [[ -n "$ARG_ONLY" ]]; then
  for s in "${ALL_SCRIPTS[@]}"; do
    local_name="$(get_step_name "$s")"
    if [[ "$local_name" == "$ARG_ONLY" ]]; then
      SELECTED_SCRIPTS+=("$s")
      break
    fi
  done
  if [[ "${#SELECTED_SCRIPTS[@]}" -eq 0 ]]; then
    log_error "Etapa passada em --only não encontrada: $ARG_ONLY"
    exit 1
  fi
else
  from_seen=0
  for s in "${ALL_SCRIPTS[@]}"; do
    local_name="$(get_step_name "$s")"
    if [[ -n "$ARG_FROM" && "$from_seen" -eq 0 ]]; then
      if [[ "$local_name" == "$ARG_FROM" ]]; then
        from_seen=1
      else
        continue
      fi
    fi
    [[ -z "$ARG_FROM" ]] && from_seen=1

    if [[ -n "$ARG_TO" ]]; then
      SELECTED_SCRIPTS+=("$s")
      if [[ "$local_name" == "$ARG_TO" ]]; then
        break
      fi
    else
      SELECTED_SCRIPTS+=("$s")
    fi
  done
fi

log_info "Iniciando build do sistema final dentro do chroot"
log_info "Diretório de scripts: $FINAL_DIR"
log_info "Arquivos de estado: $STATE_DIR"
log_info "Logs das etapas: $LOG_DIR"

for script in "${SELECTED_SCRIPTS[@]}"; do
  name="$(get_step_name "$script")"
  logfile="${LOG_DIR}/${name}.log"

  if step_done "$name" && [[ "$ARG_FORCE" -eq 0 ]]; then
    log_ok "Etapa $name já concluída anteriormente, pulando (use --force para refazer)."
    continue
  fi

  echo
  echo "============================================================"
  echo ">>> ETAPA (chroot): $name"
  echo ">>> Script: $script"
  echo ">>> Log: $logfile"
  echo "============================================================"

  echo "$name" > "${STATE_DIR}/_current_step"

  {
    echo "=== Início da etapa $name em $(date -u +"%Y-%m-%dT%H:%M:%SZ") ==="
    echo "Comando: bash \"$script\""
  } > "$logfile"

  if bash "$script" >>"$logfile" 2>&1; then
    mark_step_done "$name"
    rm -f "${STATE_DIR}/_current_step"
    log_ok "Etapa $name concluída com sucesso."
  else
    echo "=== FALHA na etapa $name em $(date -u +"%Y-%m-%dT%H:%M:%SZ") ===" >>"$logfile"
    log_error "Etapa $name falhou. Veja o log em: $logfile"
    log_error "Você pode corrigir o problema e rodar novamente:"
    log_error "  ./build-all-chroot.sh --from $name"
    exit 1
  fi
done

echo
log_ok "Todas as etapas selecionadas (chroot) foram concluídas."
echo "Use './build-all-chroot.sh --status' para ver o status geral."
