# Tutorial LFS Automatizado (Scripts rootfs/build-scripts)

Este documento descreve como usar o conjunto de scripts desta árvore
para construir um sistema Linux From Scratch (LFS 12.1-like) de forma
quase totalmente automatizada.

Os diretórios principais são:

- `build-scripts/00-prepare/`       → scripts de preparação do host
- `build-scripts/10-toolchain-temp/`→ toolchain temporária + temporary tools (cap. 5 e 6)
- `build-scripts/20-chroot-prep/`   → preparação de chroot (montagens e entrada)
- `build-scripts/20-system-final/`  → scripts que você criará para o sistema “final”
- `build-scripts/build-all.sh`      → orquestrador da toolchain + temporary tools (usuário lfs)
- `build-scripts/sanity-check.sh`   → script de sanity-check da toolchain
- `build-scripts/build-all-chroot.sh`→ orquestrador do sistema final (rodar dentro do chroot)
- `doc/`                            → documentação


## 1. Pré-requisitos

- Uma máquina host Linux (ou VM) com:
  - `bash`, `gcc`, `make`, `wget`, `tar`, `xz`, `bzip2`, `gzip`
  - `sudo` (opcional, você pode usar root direto)
  - `parted`, `mount`, `chroot`, etc.
- Bastante espaço em disco (pelo menos ~30–40 GiB recomendados para brincar com folga).
- A VM/host deve ser o mesmo tipo de arquitetura do que você quer construir
  (ex.: x86_64 → x86_64).

**Atenção:** Siga isto em VM ou disco dedicado. Os scripts de particionamento
podem apagar tudo em um disco se usados sem cuidado.


## 2. Preparando o disco LFS

### 2.1 Defina LFS

No host, como root ou usuário normal:

```bash
export LFS=/mnt/lfs
```

Ajuste se quiser outro ponto de montagem.

### 2.2 Particionamento (opcional, mas típico)

Como root:

```bash
cd rootfs/build-scripts
./00-prepare/01-create-partitions.sh /dev/sdX
```

Isto criará uma tabela GPT e UMA partição para o LFS.

Depois, manualmente:

```bash
mkfs.ext4 /dev/sdX1
mkdir -pv $LFS
mount /dev/sdX1 $LFS
```


## 3. Preparando o ambiente LFS (host)

Ainda no host, como root:

```bash
cd rootfs/build-scripts
export LFS=/mnt/lfs   # garantir
./00-prepare/00-setup-env.sh
```

Este script:

- cria `$LFS/{etc,var,tools,sources,usr,lib,lib64}` (se x86_64);
- cria `/tools -> $LFS/tools`;
- cria usuário/grupo `lfs` e ajusta permissões de `$LFS`, `$LFS/tools`, `$LFS/sources`;
- mostra instruções para configurar `.bash_profile` e `.bashrc` do usuário `lfs`.


## 4. Ambiente do usuário lfs

Troque para o usuário `lfs`:

```bash
su - lfs
```

Configure (se ainda não estiver) o `~/.bash_profile` e `~/.bashrc` conforme
mensagem do `00-setup-env.sh`. Exemplo típico:

**~/.bash_profile**:

```bash
exec env -i HOME=$HOME TERM=$TERM PS1='\u:\w\$ ' \
  PATH=/usr/bin:/bin /bin/bash
```

**~/.bashrc**:

```bash
set +h
umask 022
LFS=/mnt/lfs
export LFS
export LFS_TGT=$(uname -m)-lfs-linux-gnu
PATH=/tools/bin:/usr/bin
export PATH
```

Abra um novo shell `lfs` (ou `source ~/.bashrc`).


## 5. Construindo a toolchain + temporary tools

Ainda como usuário `lfs`, dentro de `rootfs/build-scripts`:

```bash
cd /caminho/para/rootfs/build-scripts
./build-all.sh
```

O `build-all.sh` irá:

- detectar todos os scripts de `10-toolchain-temp/*.sh` em ordem numérica;
- criar:
  - `$LFS/.lfs-build-state` (arquivos `.done` por etapa)
  - `$LFS/.lfs-build-logs` (um `.log` por etapa)
- executar cada script e registrar logs;
- em caso de falha, parar e mostrar o log da etapa problemática;
- permitir retomada com `--from`, `--to`, `--only`, `--force`.

Exemplos:

- Listar etapas:
  ```bash
  ./build-all.sh --list
  ```

- Ver status (PEND/OK):
  ```bash
  ./build-all.sh --status
  ```

- Reexecutar só a etapa `11-coreutils`:
  ```bash
  ./build-all.sh --only 11-coreutils --force
  ```

- Retomar a partir de `14-file`:
  ```bash
  ./build-all.sh --from 14-file
  ```


## 6. Sanity-check da toolchain

Após o `build-all.sh` terminar sem erros, ainda como `lfs`:

```bash
cd /caminho/para/rootfs/build-scripts
./sanity-check.sh
```

Este script:

- verifica diretórios básicos (`$LFS`, `$LFS/tools`, `$LFS/usr`);
- lista o status de todas as etapas com base nos `.done`;
- confere a presença de:
  - `$LFS/tools/bin/$LFS_TGT-gcc`, `$LFS/tools/bin/$LFS_TGT-as`, `$LFS/tools/bin/$LFS_TGT-ld`
  - headers Linux em `$LFS/usr/include`
  - libc em `$LFS/usr/lib`
  - binutils/gcc pass2: `$LFS/usr/bin/ld`, `$LFS/usr/bin/gcc`, `$LFS/usr/bin/cc`
  - temporary tools principais (m4, ncurses, bash, coreutils, diffutils, make,
    file, findutils, gawk, grep, gzip, patch, sed, tar, xz, bison, perl, python3);
- compila um pequeno programa C usando `$LFS_TGT-gcc` e executa `readelf -l` para
  conferir o interpretador de programa.

Qualquer linha marcada como `[FAIL]` deve ser investigada.


## 7. Preparando o chroot

Quando a toolchain e as temporary tools estiverem ok, você já tem um rootfs
mínimo em `$LFS`. Agora, é hora de preparar o chroot.

Saia do usuário `lfs` e volte a ser root no host:

```bash
exit     # ou Ctrl-D
sudo -i  # se usar sudo
export LFS=/mnt/lfs
cd /caminho/para/rootfs/build-scripts
```

### 7.1 Montar /dev, /proc, /sys, /run dentro do LFS

```bash
./20-chroot-prep/01-mount-virtualfs.sh
```

Este script:

- garante que `$LFS` esteja montado;
- monta `/dev`, `/dev/pts`, `/proc`, `/sys`, `/run` dentro de `$LFS`;
- cria o destino de `/dev/shm` se for symlink.


### 7.2 Entrar em chroot

```bash
./20-chroot-prep/02-enter-chroot.sh
```

Ele verificará se os pseudo-sistemas estão montados e chamará:

```bash
chroot "$LFS" /usr/bin/env -i \
  HOME=/root \
  TERM="$TERM" \
  PS1='(lfs-chroot)\u:\w\$ ' \
  PATH=/usr/bin:/usr/sbin:/bin:/sbin \
  /bin/bash --login
```

Agora você está dentro do chroot, com `/` apontando para o antigo `$LFS`.


## 8. Construindo o sistema “final” dentro do chroot

Dentro do chroot, os scripts deste pacote esperam que você crie os scripts
do “sistema final” em:

```text
/build-scripts/20-system-final/*.sh
```

Exemplos de scripts típicos nessa fase (que você mesmo pode implementar):

- `01-kernel-headers-final.sh`
- `02-glibc-final.sh`
- `03-toolchain-final.sh`
- `10-sysvinit.sh` ou systemd equivalente
- `20-kernel-build.sh`
- `30-grub-install.sh`
- etc.

Cada script deve ser auto-contido (configure/make/make install, etc.), assumindo
que está rodando **dentro do chroot** e como root.

### 8.1 Orquestrando essas etapas: build-all-chroot.sh

Ainda dentro do chroot:

```bash
cd /build-scripts
./build-all-chroot.sh
```

Este script é muito parecido com o `build-all.sh`, mas:

- procura scripts em `20-system-final/*.sh`;
- registra estado em:
  - `/var/lib/lfs-build-state-chroot`
  - `/var/log/lfs-build-logs-chroot`
- oferece as mesmas opções:
  - `--list`, `--status`, `--from`, `--to`, `--only`, `--force`, `--no-color`

Exemplos:

- Listar etapas definidas:
  ```bash
  ./build-all-chroot.sh --list
  ```

- Ver status:
  ```bash
  ./build-all-chroot.sh --status
  ```

- Rodar só uma etapa:
  ```bash
  ./build-all-chroot.sh --only 20-kernel-build
  ```

- Retomar de um ponto em diante:
  ```bash
  ./build-all-chroot.sh --from 10-sysvinit
  ```


## 9. Configurações finais (alto nível)

Alguns arquivos de configuração que você precisará criar/ajustar dentro do chroot:

- `/etc/fstab`
- `/etc/hostname`
- `/etc/hosts`
- `/etc/resolv.conf`
- scripts de init em `/etc/rc.d` (para SysVinit) ou unidades systemd
- rede (`/etc/sysconfig/ifconfig.eth0` ou similar, dependendo do modelo)


### 9.1 Exemplo muito simplificado de /etc/fstab

```fstab
# <file system>  <mount point>  <type>  <options>         <dump> <pass>
/dev/sda1        /              ext4    defaults          1      1
proc             /proc          proc    nosuid,noexec     0      0
sysfs            /sys           sysfs   nosuid,noexec     0      0
devpts           /dev/pts       devpts  gid=5,mode=620    0      0
tmpfs            /run           tmpfs   defaults          0      0
devtmpfs         /dev           devtmpfs mode=0755,nosuid 0      0
```

Ajuste de acordo com o layout do seu disco.


## 10. Fluxo resumido de construção do zero

1. No host (root):
   - Defina `LFS` e prepare partição, formato e mount.
   - Rode `00-setup-env.sh`.

2. Troque para `lfs`:
   - Configure `.bash_profile` e `.bashrc`.
   - Rode `build-all.sh` para construir toolchain + temporary tools.
   - Rode `sanity-check.sh` para validar.

3. Volte para root no host:
   - Rode `20-chroot-prep/01-mount-virtualfs.sh`.
   - Rode `20-chroot-prep/02-enter-chroot.sh` para entrar no chroot.

4. Dentro do chroot (root):
   - Crie scripts em `20-system-final/` para o sistema final.
   - Use `build-all-chroot.sh` para orquestrar essas etapas.

5. Configure o sistema:
   - Ajuste `/etc/*` (fstab, hostname, rede, init).
   - Compile e instale o kernel.
   - Instale e configure o bootloader (ex.: GRUB).

Depois disso, o seu sistema LFS estará pronto para bootar diretamente
sem depender do host original.
