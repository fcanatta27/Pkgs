#!/usr/bin/env bash
#
# Bash-5.3 (ferramenta temporária) - LFS 6.4

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${SCRIPT_DIR}/common.sh"

STEP_ID="bash-5.3-temp"

PKG_NAME="bash-5.3"
PKG_TARBALL="${PKG_NAME}.tar.gz"
BASH_URL_DEFAULT="https://ftp.gnu.org/gnu/bash/${PKG_TARBALL}"
: "${BASH_SRC_URL:=${BASH_URL_DEFAULT}}"

if [ ! -f "${LFS_SRCDIR}/${PKG_TARBALL}" ]; then
    echo "Baixando ${PKG_TARBALL}..."
    curl -L -C - -o "${LFS_SRCDIR}/${PKG_TARBALL}" "${BASH_SRC_URL}"
fi

cd "${LFS_WORKDIR}"
rm -rf "${PKG_NAME}"
tar -xf "${LFS_SRCDIR}/${PKG_TARBALL}"
cd "${PKG_NAME}"

./configure --prefix=/usr                        \
            --build="$(sh support/config.guess)" \
            --host="${LFS_TGT}"                  \
            --without-bash-malloc

make

reset_destdir
make DESTDIR="${LFS_DESTDIR}" install

mkdir -p "${LFS_DESTDIR}/bin"
ln -sv /usr/bin/bash "${LFS_DESTDIR}/bin/sh"

register_installed_files "${STEP_ID}"
sync_destdir_to_rootfs

echo "Bash-5.3 (temporário) instalado em ${LFS_ROOTFS}."
