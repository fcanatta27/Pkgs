# Manutenção a Longo Prazo do 3bLinux

Este guia cobre como manter o sistema **seguro, atualizado e estável**.

## Atualizações
```bash
pkg -Syu
```

Boas práticas:
- Atualizar primeiro em VM
- Revisar Buildfiles alterados
- Manter changelog

## Segurança contínua
- Revisar `/etc/sysctl.d`
- Atualizar kernel periodicamente
- Revisar serviços ativos em `/etc/init.d`

## Backups
Estratégias recomendadas:
- rsync incremental
- snapshots Btrfs (se usado)
- backup de:
  - /etc
  - /home
  - /var/packages

## Logs
- Verificar `/var/log/messages`
- Confirmar rotação de logs
- Monitorar erros recorrentes

## Auditoria
- Checar permissões
- Revisar usuários e grupos
- Validar sudoers
