# Etapa 3 – Chroot (Capítulo 8 do LFS)

Nesta fase, o sistema passa a ser construído **de dentro dele mesmo**.

## Entrada no chroot
```bash
lfs-chroot
```

## Wrappers importantes
- `lfs-chroot-setup`
- `lfs-chroot-build`
- `lfs-sanity-post-ch8`

## Sanity-check
O build **não avança** se:
- `/bin/sh` não aponta para bash
- `cc` não aponta para gcc
- libs críticas não resolvem

Código de saída:
- `0`: OK
- `2`: erro crítico (build travado)
