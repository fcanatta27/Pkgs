# Tornando o Xorg totalmente funcional no 3bLinux

Este documento descreve **tudo que é necessário** para que o Xorg funcione
de forma confiável no 3bLinux.

## Pacotes obrigatórios

```bash
pkg -i mesa
pkg -i xorg-server
pkg -i xinit
pkg -i xauth
```

Opcional (recomendado):
```bash
pkg -i dbus
```

## Permissões

Arquivo:
```
/etc/X11/Xwrapper.config
```

Configuração usada:
```ini
allowed_users=anybody
needs_root_rights=yes
```

Isso permite rodar `startx` como usuário normal.

## Fluxo de inicialização

1. Usuário executa:
   ```bash
   startx
   ```

2. `startx` chama:
   ```
   /etc/X11/xinit/xinitrc
   ```

3. `xinitrc` carrega ambiente e chama `~/.xinitrc`

4. `~/.xinitrc`:
   - inicia dbus (se disponível)
   - executa `openbox-session`

5. Openbox chama:
   ```
   ~/.config/openbox/autostart
   ```

6. São iniciados:
   - picom
   - polybar
   - wallpaper
   - sessão gráfica

## Verificação rápida

Após `startx`, valide:

```bash
echo $DISPLAY
glxinfo | grep "OpenGL renderer"
ps aux | grep Xorg
```

Se esses comandos funcionarem, o Xorg está corretamente configurado.
