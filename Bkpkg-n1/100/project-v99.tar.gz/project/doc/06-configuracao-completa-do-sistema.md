# Configuração Completa do Sistema

Este guia explica **todos os arquivos em /etc**.

## Principais áreas
- `/etc/sysconfig` – rede, console, energia
- `/etc/sysctl.d` – hardening e perfis
- `/etc/init.d` – serviços SysV
- `/etc/profile.d` – ambiente do usuário
- `/etc/vim` e `/etc/bash`

## Perfis
- Desktop
- Notebook
- VM

## Serviços
- network
- ntp
- syslog
- power-profile

Tudo foi projetado para:
- ser simples
- ser auditável
- não esconder mágica
