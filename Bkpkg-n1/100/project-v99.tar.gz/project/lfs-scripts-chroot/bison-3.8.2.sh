#!/usr/bin/env bash
#
# Bison-3.8.2 (Capítulo 8 - dentro do chroot)
#
# Este script deve ser executado como root dentro do chroot LFS.
#

set -euo pipefail

PKG_NAME="bison-3.8.2"
TARBALL="${PKG_NAME}.tar.xz"
SRC_DIR="/sources"

cd "${SRC_DIR}"
rm -rf "${PKG_NAME}"
tar -xf "${TARBALL}"
cd "${PKG_NAME}"

./configure --prefix=/usr             --docdir=/usr/share/doc/bison-3.8.2

make

if [ "${LFS_SKIP_TESTS:-0}" != "1" ]; then
    make check
fi

make install

echo "Bison-3.8.2 instalado com sucesso."
