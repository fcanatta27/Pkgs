#!/bin/bash
# 40-kernel-bootloader/run-all.sh - Orquestra scripts desta etapa
#
# Executa todos os scripts 0*.sh neste diretório (exceto este run-all.sh),
# em ordem lexicográfica, registrando logs individuais em /logs-40-kernel-bootloader/.
#
set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
LOGDIR=/logs-40-kernel-bootloader
mkdir -pv "$LOGDIR"

echo ">>> [40-kernel-bootloader] Iniciando run-all.sh em $HERE"
echo ">>> [40-kernel-bootloader] Logs individuais: $LOGDIR/"

shopt -s nullglob
scripts=( "$HERE"/0*.sh )
shopt -u nullglob

if [ ${#scripts[@]} -eq 0 ]; then
  echo "[40-kernel-bootloader] Nenhum script 0*.sh encontrado em $HERE."
  exit 0
fi

idx=0
total=${#scripts[@]}

for script in "${scripts[@]}"; do
  base=$(basename "$script")
  if [ "$base" = "run-all.sh" ]; then
    continue
  fi
  if [ ! -x "$script" ]; then
    echo "[40-kernel-bootloader] Pulando $base (não executável)."
    continue
  fi
  ((idx++))
  logfile="$LOGDIR/$base.log"
  echo ">>> [40-kernel-bootloader] [$idx/$total] Executando $base (log: $logfile)"
  if bash "$script" 2>&1 | tee "$logfile"; then
    echo "[40-kernel-bootloader] $base concluído com sucesso."
  else
    echo "[40-kernel-bootloader] ERRO ao executar $base (veja $logfile)."
    exit 1
  fi
done

echo ">>> [40-kernel-bootloader] run-all.sh concluído."
