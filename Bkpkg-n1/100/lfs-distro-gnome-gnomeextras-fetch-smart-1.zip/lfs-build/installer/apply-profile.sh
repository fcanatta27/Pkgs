#!/bin/bash
# apply-profile.sh - Aplica perfil (notebook/desktop) e mostra sanity pós-perfil
#
# Este script é chamado pelo instalador após a cópia do sistema base.
# Ele delega a escolha/aplicação de perfil para lfs-install-profile.sh e,
# em seguida, apresenta ao usuário um resumo do sanity pós-perfil.
#
set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
TOP=$(cd "$HERE/.." && pwd)

LFS_INSTALL_PROFILE="${TOP}/lfs/bin/lfs-install-profile.sh"
SANITY_LOG="/var/log/post-profile-sanity.log"
PROFILE_LOG="/var/log/profile-install.log"

have_cmd() {
  command -v "$1" >/dev/null 2>&1
}

run_profile() {
  echo "[INSTALLER] Aplicando perfil automático via $LFS_INSTALL_PROFILE ..."

  if [ ! -x "$LFS_INSTALL_PROFILE" ]; then
    echo "[INSTALLER] ERRO: script de perfil não encontrado: $LFS_INSTALL_PROFILE" >&2
    return 1
  fi

  # Executa o wrapper de perfil; ele próprio detecta notebook/desktop.
  if ! "$LFS_INSTALL_PROFILE" 2>&1 | tee "$PROFILE_LOG"; then
    echo "[INSTALLER] Aviso: lfs-install-profile.sh retornou código diferente de zero."
    return 1
  fi

  # Após o perfil, espera-se que o sanity pós-perfil já tenha sido executado
  # (ex.: por hooks de perfil) e escrito em $SANITY_LOG. Se não existir, apenas avisa.
  if [ ! -f "$SANITY_LOG" ]; then
    echo "[INSTALLER] Aviso: log de sanity pós-perfil não encontrado em $SANITY_LOG."
  fi

  return 0
}

extract_status_summary() {
  local log="$SANITY_LOG"
  if [ ! -f "$log" ]; then
    echo "Log de sanity não encontrado."
    return 0
  fi

  echo "Resumo do sanity pós-perfil:"
  echo

  # Exemplo de parsing simples: pegar linhas com palavras-chave relevantes
  grep -E "AUDIO|ÁUDIO|BATERIA|BATTERY|GNOME|FIREFOX" "$log" || {
    echo "(nenhuma linha de status específica encontrada; veja o log completo em $log)"
  }
}

show_ui_summary() {
  local text="$1"

  if have_cmd whiptail; then
    whiptail --title "Sanity pós-perfil" --msgbox "$text" 20 80 || true
  elif have_cmd dialog; then
    dialog --title "Sanity pós-perfil" --msgbox "$text" 20 80 || true
  else
    echo "===== SANITY PÓS-PERFIL ====="
    echo "$text"
    echo "============================="
  fi
}

main() {
  echo "[INSTALLER] Iniciando aplicação de perfil (notebook/desktop)."

  if ! run_profile; then
    echo "[INSTALLER] Perfil aplicado com erros. Verifique $PROFILE_LOG."
  fi

  # Monta texto de resumo para UI
  summary=$(extract_status_summary || true)

  # Garante que sempre mostre algo
  if [ -z "$summary" ]; then
    summary="Resumo de sanity não disponível. Verifique os logs em:\n  $PROFILE_LOG\n  $SANITY_LOG"
  fi

  show_ui_summary "$summary"

  echo "[INSTALLER] apply-profile.sh concluído."
}

main "$@"
