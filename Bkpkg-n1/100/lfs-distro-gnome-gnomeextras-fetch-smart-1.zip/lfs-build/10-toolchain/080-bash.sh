
#!/bin/bash
# 080-bash.sh - Bash-5.3 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls bash-5.3*.tar.* bash-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Bash não encontrado em $LFS/sources"
  exit 1
fi

rm -rf bash-src
mkdir -v bash-src
tar -xf "$tarball" -C bash-src --strip-components=1
cd bash-src

./configure --prefix=/usr                                      --build=$(sh support/config.guess)                 --host=$LFS_TGT                                    --without-bash-malloc

make
make DESTDIR=$LFS install

mkdir -pv $LFS/bin
ln -sv bash $LFS/bin/sh || true

cd "$LFS/sources"
rm -rf bash-src

echo "Bash-5.3 instalado temporariamente em $LFS/usr e linkado como $LFS/bin/sh."
