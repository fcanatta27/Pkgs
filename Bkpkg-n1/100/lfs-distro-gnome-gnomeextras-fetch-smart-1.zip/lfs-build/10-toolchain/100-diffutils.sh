
#!/bin/bash
# 100-diffutils.sh - Diffutils-3.12 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls diffutils-3.12*.tar.* diffutils-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Diffutils não encontrado em $LFS/sources"
  exit 1
fi

rm -rf diffutils-src
mkdir -v diffutils-src
tar -xf "$tarball" -C diffutils-src --strip-components=1
cd diffutils-src

./configure         --prefix=/usr         --host=$LFS_TGT         --build=$(build-aux/config.guess)

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf diffutils-src

echo "Diffutils instalado temporariamente em $LFS/usr."
