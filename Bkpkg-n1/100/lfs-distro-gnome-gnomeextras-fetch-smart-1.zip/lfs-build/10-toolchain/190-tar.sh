
#!/bin/bash
# 190-tar.sh - Tar-1.35 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls tar-1.35*.tar.* tar-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Tar não encontrado em $LFS/sources"
  exit 1
fi

rm -rf tar-src
mkdir -v tar-src
tar -xf "$tarball" -C tar-src --strip-components=1
cd tar-src

./configure         --prefix=/usr         --host=$LFS_TGT         --build=$(build-aux/config.guess)

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf tar-src

echo "Tar instalado temporariamente em $LFS/usr."
