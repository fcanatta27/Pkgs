
#!/bin/bash
# 200-xz.sh - Xz-5.8.x (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls xz-5.8*.tar.* xz-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Xz não encontrado em $LFS/sources"
  exit 1
fi

rm -rf xz-src
mkdir -v xz-src
tar -xf "$tarball" -C xz-src --strip-components=1
cd xz-src

./configure         --prefix=/usr         --host=$LFS_TGT         --build=$(build-aux/config.guess)         --disable-static         --docdir=/usr/share/doc/xz-temp

make
make DESTDIR=$LFS install

rm -f $LFS/usr/lib/liblzma.la || true

cd "$LFS/sources"
rm -rf xz-src

echo "Xz instalado temporariamente em $LFS/usr."
