
#!/bin/bash
# 050-libstdc++-from-gcc-15.2.0.sh - Libstdc++ a partir do GCC-15.2.0

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

gcc_tar=$(ls gcc-15.2.0*.tar.* gcc-15.2*.tar.* gcc-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$gcc_tar" ]; then
  echo "Tarball do GCC não encontrado em $LFS/sources"
  exit 1
fi

rm -rf gcc-libstdc++-src
mkdir -v gcc-libstdc++-src
tar -xf "$gcc_tar" -C gcc-libstdc++-src --strip-components=1
cd gcc-libstdc++-src

mkdir -v build
cd build

../libstdc++-v3/configure              --host=$LFS_TGT                    --build=$(../config.guess)         --prefix=/usr                      --disable-multilib                 --disable-nls                      --disable-libstdcxx-pch            --with-gxx-include-dir=/tools/$LFS_TGT/include/c++/15.2.0

make
make DESTDIR=$LFS install

rm -f "$LFS/usr/lib/libstdc++.la" "$LFS/usr/lib/libsupc++.la" 2>/dev/null || true

cd "$LFS/sources"
rm -rf gcc-libstdc++-src

echo "Libstdc++ (GCC-15.2.0) instalada em $LFS/usr."
