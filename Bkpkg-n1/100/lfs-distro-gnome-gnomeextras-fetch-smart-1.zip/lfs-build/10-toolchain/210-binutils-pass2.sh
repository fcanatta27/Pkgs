
#!/bin/bash
# 210-binutils-pass2.sh - Binutils-2.45.1 (Pass 2) - temporary tools

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls binutils-2.45.1*.tar.* binutils-2.45*.tar.* binutils-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Binutils não encontrado em $LFS/sources"
  exit 1
fi

rm -rf binutils-pass2-src
mkdir -v binutils-pass2-src
tar -xf "$tarball" -C binutils-pass2-src --strip-components=1
cd binutils-pass2-src

sed -i '6031s/$add_dir//' ltmain.sh || true

mkdir -v build
cd build

../configure         --prefix=/usr         --build=$(../config.guess)         --host=$LFS_TGT         --disable-nls         --enable-shared         --enable-gprofng=no         --enable-64-bit-bfd

make
make DESTDIR=$LFS install

rm -f $LFS/usr/lib/libbfd.a $LFS/usr/lib/libctf.a $LFS/usr/lib/libctf-nobfd.a $LFS/usr/lib/libiberty.a 2>/dev/null || true

cd "$LFS/sources"
rm -rf binutils-pass2-src

echo "Binutils-2.45.1 (Pass 2) instalado temporariamente em $LFS/usr."
