# LFS Distro Build Tree

Esta árvore contém todos os scripts e configurações usados para construir a
distro baseada em LFS:

- `00-config/` – ambiente de build, download de fontes, sanity da toolchain:
  - `env.sh` – define `LFS`, `LFS_TGT`, ajusta `PATH` e cria `/mnt/lfs/{sources,tools}`.
  - `fetch_sources.sh` – baixa os tarballs listados em `packages.list` para `$LFS/sources`.
  - `check-toolchain.sh` – sanity simples (compila e executa um programa C de teste).
- `10-toolchain/` – scripts para cross-toolchain e toolchain temporária (passes de Binutils, GCC, Glibc, headers, etc.).
  - `run-all.sh` – driver que executa todos os passos em ordem; opção `--sanity` roda `00-config/check-toolchain.sh` ao final.
- `20-chroot/`, `30-system/`, ... – fases subsequentes (temporários, sistema final, etc.).
- `lfs/doc/` – documentação:
  - `HOWTO-BUILD-DISTRO.md` – fluxo completo de construção (host → chroot → sistema → ISO/instalador).
  - `TOOLCHAIN-REBUILD-HOWTO.md` – detalhes do rebuild da toolchain e uso do driver `10-toolchain/run-all.sh`.
- `installer/` – scripts usados pelo instalador (modo texto/gráfico) para aplicar perfis e pós-sanity.

Fluxo típico de uso (resumido):

1. Preparar ambiente do host e apontar `LFS` (ex.: `/mnt/lfs`).
2. `cd 00-config && source env.sh`
3. `./fetch_sources.sh` (ou `./fetch_sources.sh --dry-run` para validar lista).
4. `cd ../10-toolchain && ./run-all.sh --sanity`
5. Prosseguir para chroot e Cap. 8 conforme documentado em `lfs/doc/HOWTO-BUILD-DISTRO.md`.

Consulte os documentos em `lfs/doc/` para o guia detalhado e exemplos de uso em CI.
