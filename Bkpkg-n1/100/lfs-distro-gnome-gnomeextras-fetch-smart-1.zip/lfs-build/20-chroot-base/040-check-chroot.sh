
#!/bin/bash
# 040-check-chroot.sh - Sanity-check básico dentro do chroot LFS.
#
# Verifica:
#  - /bin/sh
#  - /usr/bin/env
#  - /usr/bin/vi ou /usr/bin/vim
#  - Presença de /usr/bin/gcc, /usr/bin/ld (quando já instalados).
#  - Interpreter de /bin/bash não apontando mais para /tools.

set -euo pipefail

RED="\033[1;31m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
BLUE="\033[1;34m"
RESET="\033[0m"

PASS_COUNT=0
WARN_COUNT=0
FAIL_COUNT=0

pass() { echo -e "${GREEN}[OK]${RESET} $*"; PASS_COUNT=$((PASS_COUNT+1)); }
warn() { echo -e "${YELLOW}[WARN]${RESET} $*"; WARN_COUNT=$((WARN_COUNT+1)); }
fail() { echo -e "${RED}[FAIL]${RESET} $*"; FAIL_COUNT=$((FAIL_COUNT+1)); }
info() { echo -e "${BLUE}[INFO]${RESET} $*"; }

info "Sanity-check dentro do chroot (root=/)..."

# /bin/sh
if [ -x /bin/sh ]; then
  pass "/bin/sh existe e é executável."
  if [ -L /bin/sh ]; then
    target=$(readlink -f /bin/sh 2>/dev/null || readlink /bin/sh)
    info "/bin/sh é link para: $target"
    case "$target" in
      *bash)
        pass "/bin/sh aponta para bash (ok)."
        ;;
      *)
        warn "/bin/sh não aponta para bash; verifique se isso é intencional."
        ;;
    esac
  fi
else
  fail "/bin/sh NÃO existe ou não é executável."
fi

# /usr/bin/env
if [ -x /usr/bin/env ]; then
  pass "/usr/bin/env existe e é executável."
else
  fail "/usr/bin/env NÃO encontrado (coreutils incompleto?)."
fi

# /usr/bin/vi ou /usr/bin/vim
if [ -x /usr/bin/vi ]; then
  pass "/usr/bin/vi encontrado."
elif [ -x /usr/bin/vim ]; then
  pass "/usr/bin/vim encontrado (sem link vi)."
else
  warn "Nenhum editor de texto padrão encontrado (/usr/bin/vi ou /usr/bin/vim)."
fi

# GCC e binutils
if command -v gcc >/dev/null 2>&1; then
  pass "gcc encontrado em $(command -v gcc)."
else
  warn "gcc não encontrado no chroot (talvez GCC final ainda não tenha sido instalado)."
fi

if command -v ld >/dev/null 2>&1; then
  pass "ld (binutils) encontrado em $(command -v ld)."
else
  warn "ld não encontrado no chroot (talvez Binutils final ainda não tenha sido instalado)."
fi

# Interpreter de /bin/bash
if [ -x /bin/bash ] && command -v readelf >/dev/null 2>&1; then
  info "Verificando interpreter dinâmico de /bin/bash..."
  interp=$(readelf -l /bin/bash 2>/dev/null | grep 'Requesting program interpreter' || true)
  if [ -n "$interp" ]; then
    info "Interpreter: $interp"
    case "$interp" in
      *tools*)
        warn "Interpreter de /bin/bash ainda aponta para /tools – toolchain final pode não estar ajustada."
        ;;
      *)
        pass "Interpreter de /bin/bash não aponta para /tools."
        ;;
    esac
  else
    warn "Não foi possível obter informação de interpreter de /bin/bash via readelf."
  fi
else
  warn "/bin/bash ou readelf não disponíveis para checar interpreter."
fi

echo
echo "========== RESUMO DO SANITY-CHECK (CHROOT) =========="
echo "Passou : $PASS_COUNT"
echo "Avisos : $WARN_COUNT"
echo "Falhas : $FAIL_COUNT"

if [ "$FAIL_COUNT" -gt 0 ]; then
  echo
  echo "[RESULTADO] Existem falhas dentro do chroot que precisam ser corrigidas."
  exit 1
else
  echo
  echo "[RESULTADO] Nenhuma falha crítica no chroot. Avisos podem exigir revisão manual."
  exit 0
fi
