
# Hardening Notebook

## sysctl
kernel.kptr_restrict=2
kernel.dmesg_restrict=1
fs.protected_symlinks=1
fs.protected_hardlinks=1

## Serviços
systemctl enable bluetooth acpid auditd
