
# Guia de Build – Projeto LFS Automatizado

Este documento descreve a estrutura do projeto de automação LFS, a ordem recomendada
de execução, pré‑requisitos, exemplos de comandos (host e dentro do chroot) e um resumo
detalhado dos pacotes principais construídos pelos scripts.

O objetivo é permitir que você reconstrua o sistema LFS completo (toolchain, sistema
final, kernel e bootloader) de forma reprodutível, organizada e parcialmente automatizada.

> IMPORTANTE: Este guia assume que você está seguindo a filosofia do livro
> **Linux From Scratch (edição systemd)** com versões próximas às usadas aqui
> (GCC 15.2.x, Glibc 2.42, Linux 6.16.x, Systemd 25x, etc.).
> Ajustes podem ser necessários se você mudar versões de forma significativa.

---

## 1. Visão geral da árvore do projeto

Estrutura lógica dos diretórios sob `lfs-build/`:

- `00-config/`
  - Scripts de configuração, ambiente e sanity-check da toolchain.
- `10-toolchain/`
  - Construção da toolchain temporária completa (cross + temporária) e ferramentas
    temporárias do Capítulo 6.
- `20-chroot-base/`
  - Scripts para montar os sistemas de arquivos virtuais, entrar no chroot e
    configurar a base do sistema (Capítulo 7).
- `30-system/`
  - Scripts de instalação dos pacotes do Capítulo 8 (sistema básico), incluindo
    os extras adicionados (grep, coreutils final, shadow, inetutils, iproute2,
    systemd, etc.).
- `40-kernel-bootloader/`
  - Scripts para compilar o kernel e configurar o bootloader (Capítulo 10).
- `lfs/doc/README.md`
  - Este manual de operação.

---

## 2. Pré‑requisitos de host

Antes de começar, você precisa de:

1. Um sistema Linux host com:
   - Compilador C/C++ funcional (GCC ou Clang).
   - Ferramentas padrão: `bash`, `binutils`, `bison`, `coreutils`, `diffutils`,
     `findutils`, `gawk`, `grep`, `gzip`, `m4`, `make`, `patch`, `perl`, `python`,
     `sed`, `tar`, `texinfo`, `xz`, etc.
   - Ferramentas de rede (`wget`, `curl`) para baixar os fontes.

2. Uma partição dedicada para o LFS:
   - Ex.: `/dev/sdXN`, montada em `/mnt/lfs` no host.

3. Variáveis básicas no host (exemplo):
   ```bash
   export LFS=/mnt/lfs
   ```

4. Permissões de root ou `sudo` para:
   - Criar partições / sistemas de arquivos.
   - Montar / desmontar.
   - Usar `chroot`.

---

## 3. Ordem recomendada de execução (alto nível)

### 3.1. No host – preparação inicial

1. **Exportar `LFS` e montar a partição**:
   ```bash
   export LFS=/mnt/lfs
   sudo mount /dev/sdXN "$LFS"
   ```

2. **Clonar / extrair o projeto** em algum diretório de trabalho:
   ```bash
   cd ~
   tar -xf lfs-build-complete-final.tar.gz   # ou unzip do .zip
   cd lfs-build
   ```

3. **Configurar ambiente a partir do projeto**:
   ```bash
   cd lfs-build
   source 00-config/env.sh
   ```

4. **(Opcional) Baixar fontes com script de fetch** (caso exista/esteja configurado):
   ```bash
   bash 00-config/fetch_sources.sh
   ```

### 3.2. Construção da toolchain (host dentro de `$LFS`)

1. **Rodar os scripts de toolchain**:
   ```bash
   cd lfs-build
   source 00-config/env.sh
   cd 10-toolchain
   bash run-all.sh
   ```
   Isso executa todos os scripts numerados `010-*.sh`, `020-*.sh`, ..., construindo:
   - Binutils e GCC cross (Passo 1);
   - Linux API Headers;
   - Glibc 2.42;
   - Libstdc++;
   - Binutils e GCC Passo 2;
   - Ferramentas temporárias (Capítulo 6).

2. **Rodar sanity-check da toolchain (host)**:
   ```bash
   cd lfs-build
   source 00-config/env.sh
   bash 00-config/check-toolchain.sh
   ```

   - Se houver falhas (`[FAIL]`), corrija antes de prosseguir.
   - Avisos (`[WARN]`) indicam algo a revisar, mas que nem sempre é fatal.

### 3.3. Entrando no chroot e base do sistema (Cap. 7)

1. **Montar pseudo‑FSs e entrar no chroot**:
   ```bash
   cd lfs-build
   source 00-config/env.sh
   bash 20-chroot-base/000-enter-chroot.sh
   ```

   Isso monta:
   - `/dev`, `/dev/pts`, `/proc`, `/sys`, `/run` dentro de `$LFS`;
   - Entra em chroot com `HOME=/root`, `TERM=$TERM`, `PATH=/usr/bin:/usr/sbin`.

2. **Dentro do chroot – rodar base do sistema**:
   ```bash
   cd /20-chroot-base
   bash run-all.sh
   ```

   Isso executa, na ordem:
   - `010-create-base-dirs.sh` – hierarquia de diretórios + symlinks `/bin`, `/sbin`, `/lib`, `/lib64` (se aplicável).
   - `020-create-essential-files.sh` – `/etc/passwd`, `/etc/group`, arquivos de log em `/var/log`.
   - `030-basic-config.sh` – `/etc/hosts`, `/etc/issue` básicos.

3. **Sanity-check dentro do chroot**:
   ```bash
   bash /20-chroot-base/040-check-chroot.sh
   ```

   Este script valida:
   - `/bin/sh` (de preferência link para `bash`);
   - `/usr/bin/env` (coreutils);
   - `/usr/bin/vi` ou `/usr/bin/vim` (editor);
   - `gcc` e `ld` (se já instalados);
   - interpreter de `/bin/bash` (não deve apontar para `/tools`).

### 3.4. Capítulo 8 – sistema básico (scripts em `30-system/`)

1. **Ainda dentro do chroot**:
   ```bash
   cd /30-system
   bash run-all.sh
   ```

   Ele executa os scripts numerados na ordem, instalando os pacotes básicos:
   - man-pages, zlib, e2fsprogs, less, vim, bzip2, readline, bc, flex, bison,
     util-linux, grep, coreutils final, shadow, inetutils, iproute2, systemd, etc.

2. **Após instalar systemd**:
   - Verifique novamente `/20-chroot-base/040-check-chroot.sh`.
   - Ajuste `fstab`, hostname, timezone, locale, usuários adicionais, etc.

### 3.5. Kernel e bootloader (Capítulo 10, `40-kernel-bootloader/`)

1. **Dentro do chroot**:
   ```bash
   cd /40-kernel-bootloader
   bash run-all.sh
   ```

   Este script compila o kernel (com uma configuração base) e instala o bootloader
   (por exemplo, GRUB) no disco.

2. Ajuste manualmente, se necessário:
   - `/boot/grub/grub.cfg` (ou equivalente);
   - Opções de kernel;
   - Initramfs (se você optar por usar).

---

## 4. Mapa de dependências – scripts de `30-system`

Abaixo um mapa simplificado de dependências lógicas entre os scripts do diretório
`30-system/` (Cap. 8). Não é um grafo completo, mas a sequência foi pensada para
evitar dependências faltando.

Ordem atual (numeração dos scripts):

1. `010-man-pages.sh`
2. `020-zlib.sh`
3. `030-e2fsprogs.sh`
4. `040-less.sh`
5. `050-vim.sh`
6. `060-bzip2.sh`
7. `070-readline.sh`
8. `080-bc.sh`
9. `090-flex.sh`
10. `100-bison.sh`
11. `110-util-linux.sh`
12. `120-grep.sh`
13. `130-coreutils.sh`
14. `140-shadow.sh`
15. `150-inetutils.sh`
16. `160-iproute2.sh`
17. `170-systemd.sh`

### 4.1. Relações principais

- `010-man-pages.sh` – sem dependências fortes além de um sistema funcional básico.
- `020-zlib.sh` – requerido por vários pacotes (incluindo util-linux, e2fsprogs já usa).
- `030-e2fsprogs.sh` – depende de `zlib` (por isso vem após 020).
- `040-less.sh` – depende apenas de toolchain e termcap/ncurses (ncurses temporário já está presente).
- `050-vim.sh` – idem, usa ncurses e toolchain.

- `060-bzip2.sh` – compressão bzip2, usada por vários pacotes, mas sem dependências fortes além de libc.
- `070-readline.sh` – depende de `ncurses` e é usado por `bash` e outras ferramentas interativas.
- `080-bc.sh` – precisa da toolchain e da libc; útil para cálculos, mas sem grandes dependências.

- `090-flex.sh` – gerador de scanners; usado por várias libs e compiladores.
- `100-bison.sh` – gerador de parsers; similar papel de dependência.

Esses dois (flex/bison) normalmente vêm antes de pacotes que geram código a partir
de gramáticas (como algumas libs e ferramentas avançadas).

- `110-util-linux.sh` – depende de zlib, readline, etc. Fornece várias ferramentas
  centrais (mount, fdisk, hwclock, etc.), importantes antes de finalizar o sistema.

- `120-grep.sh` – utilitário de busca de texto, depende apenas da toolchain e libc.
- `130-coreutils.sh` – utilitários centrais (`ls`, `cp`, `mv`, `rm`, etc.).
  - Depende basicamente de Glibc e de um ambiente estável de `/usr`.
  - Deve vir **antes** de `shadow`, pois `shadow` começa a manipular usuários e
    senhas usando programas de sistema que contam com `coreutils`.

- `140-shadow.sh` – depende de:
  - `/etc/passwd` e `/etc/group` (criados em `20-chroot-base`);
  - ferramentas já presentes (coreutils, sed, etc.).
  - Após esta etapa, o sistema passa a usar shadow passwords (`/etc/shadow` e `/etc/gshadow`).

- `150-inetutils.sh` – fornece ferramentas de rede básicas (`ftp`, `telnet` client,
  `ping`, etc. dependendo da configuração). Requer apenas stack de rede funcional
  no kernel e libc.

- `160-iproute2.sh` – conjuntos de ferramentas modernas de rede (`ip`, etc.);
  depende da interface de rede do kernel e libc, mas não de inetutils.

- `170-systemd.sh` – init system e gerenciador de serviços.
  - Depende fortemente de:
    - `util-linux`
    - `coreutils`
    - Ferramentas básicas (`grep`, `sed`, etc.)
    - Toolchain final e libc estáveis.
  - Deve ser um dos últimos pacotes do capítulo 8.

---

## 5. Resumo detalhado por pacote (scripts de 30-system)

A seguir um resumo do que cada script faz e pontos importantes:

### 5.1. `010-man-pages.sh` – Man-pages

Instala a coleção principal de manpages do sistema:

- Copia páginas de manual para `/usr/share/man`.
- Não possui testes complexos.
- Base das documentações do sistema.

### 5.2. `020-zlib.sh` – Zlib

- Biblioteca de compressão amplamente usada.
- Instala em `/usr` e remove eventuais bibliotecas estáticas, se configurado assim.
- Usada por `e2fsprogs`, `util-linux` e muitos outros.

### 5.3. `030-e2fsprogs.sh` – e2fsprogs

- Ferramentas para sistemas de arquivos ext2/3/4:
  - `mkfs.ext4`, `fsck.ext4`, `tune2fs`, etc.
- Build em subdiretório `build/`, com opções típicas do LFS.
- Executa `make check` (não fatal se falhar).
- Instala bibliotecas e binários centrais.

### 5.4. `040-less.sh` – Less

- Paginador de texto (`less`), usado por man, etc.
- Configura e instala em `/usr`.

### 5.5. `050-vim.sh` – Vim

- Editor de texto avançado.
- Configurado sem GUI e sem X:
  - `--enable-multibyte`, `--enable-terminal`, `--without-x`.
- Instala em `/usr`, e cria link `vi -> vim`.

### 5.6. `060-bzip2.sh` – Bzip2

- Ferramentas `bzip2`, `bunzip2`, `bzcat` e biblioteca `libbz2`.
- Ajusta `Makefile` para instalar manpages no lugar correto.
- Instala as libs em `/usr` e copia `bzip2` para `/bin` com links para `bunzip2` e `bzcat`.

### 5.7. `070-readline.sh` – Readline

- Biblioteca de edição de linha de comando usada por `bash` e outros programas.
- Aplica ajustes em `Makefile.in` e `support/shlib-install` quando necessário.
- Configura com `--disable-static` e `--with-curses`.
- Instala libs em `/usr/lib` e documentação em `/usr/share/doc/readline-<versao>`.

### 5.8. `080-bc.sh` – bc

- Calculadora de precisão arbitrária (`bc`).
- Usa `./configure --prefix=/usr -G -O3 -r` quando disponível.
- Caso a versão do pacote seja muito diferente (sem `configure`), o script emite
  um aviso para ajuste manual.

### 5.9. `090-flex.sh` – Flex

- Gerador de scanners (substituto moderno do `lex`).
- Configura com:
  - `--prefix=/usr`
  - `--docdir=/usr/share/doc/flex`
- Roda `make check` (não fatal) e instala.
- Cria `lex -> flex` em `/usr/bin`.

### 5.10. `100-bison.sh` – Bison

- Gerador de parsers (equivalente ao `yacc`).
- Configura com `--prefix=/usr` e `--docdir=/usr/share/doc/bison-<versao>`.
- Roda `make check` (não fatal) e instala.

### 5.11. `110-util-linux.sh` – Util-linux

- Conjunto grande de ferramentas do sistema:
  - `mount`, `umount`, `fdisk`, `hwclock`, `kill`, etc.
- Build em diretório `build/` com opções típicas do LFS:
  - Desabilita utilitários que serão substituídos ou não desejados:
    - `chfn`, `chsh`, `login`, `nologin`, `su`, `setpriv`, `runuser`, etc.
  - Desabilita suporte a `python` e `systemd` nesta fase.
- Instala em `/usr`.

### 5.12. `120-grep.sh` – Grep

- Implementação GNU `grep`.
- Configurado com `--prefix=/usr` e `--disable-static`.
- Roda `make check` quando possível e instala em `/usr/bin`.

### 5.13. `130-coreutils.sh` – Coreutils final

- Utilitários essenciais (`ls`, `cp`, `mv`, `rm`, `ln`, etc.).
- Aplica patch de i18n se encontrado em `/sources` (opcional).
- Configura com:
  - `--prefix=/usr`
  - `--enable-no-install-program=kill,uptime` (para evitar duplicatas com outros pacotes).
- Roda `make`, testes (não fatais) e instala.

Após a instalação:

- Move binários essenciais de `/usr/bin` para `/bin`:
  - `cat chgrp chmod chown cp date dd df echo false ln ls mkdir mknod mv pwd rm rmdir stty sync true uname`
- Move `chroot` para `/usr/sbin` e corrige sua manpage para seção 8.

### 5.14. `140-shadow.sh` – Shadow

- Ferramentas para gerenciar usuários e senhas de forma segura:
  - `useradd`, `usermod`, `passwd`, etc.
- Configura com:
  - `--prefix=/usr`
  - `--sysconfdir=/etc`
  - `--with-group-name-max-length=32`
- Ajusta `etc/login.defs` para usar `ENCRYPT_METHOD SHA512` e
  configura `SHA_CRYPT_MIN/MAX_ROUNDS`.

Após a instalação:

- Remove `groups` e `uptime` de `/usr/bin` (mantidos via coreutils).
- Converte para shadow passwords se necessário:
  - `pwconv` (gera `/etc/shadow`)
  - `grpconv` (gera `/etc/gshadow`)
- Lembra o usuário de definir senha para root com `passwd root`.

### 5.15. `150-inetutils.sh` – Inetutils

- Ferramentas de rede básicas (telnet, ftp client, ping, etc. dependendo da versão).
- Configura com:
  - `--prefix=/usr`
  - `--localstatedir=/var`
  - `--disable-logger --disable-whois --disable-servers`
- Roda `make check` (não fatal) e instala em `/usr`.

### 5.16. `160-iproute2.sh` – IPRoute2

- Ferramentas modernas de rede (`ip`, `ss`, etc.).
- Remove suporte ao `arpd` (que depende de Berkeley DB):
  - `sed -i /ARPD/d Makefile`
  - Remove manpage `arpd.8`, se presente.
- Compila com `make NETNS_RUN_DIR=/run/netns` e instala com
  `make SBINDIR=/usr/sbin install`.

### 5.17. `170-systemd.sh` – Systemd

- Sistema de init e gerenciador de serviços padrão do LFS (edição systemd).
- Assume dependências satisfeitas (util-linux, coreutils, zlib, libcap, etc.).
- Ajusta regras udev padrão (`50-udev-default.rules.in`) para usar grupos adequados.
- Build com Meson em diretório `build/`:
  - `--prefix=/usr`
  - `--buildtype=release`
  - Diversos `-D` para desativar componentes não usados no LFS (firstboot, sysusers,
    sysupdate, ukify, homed, manpages geradas, etc.).
  - `-D nobody-group=nogroup`
  - `-D docdir=/usr/share/doc/systemd`

Pós‑build:

- Roda `ninja test` de forma não fatal (testes podem falhar no chroot).
- `ninja install` instala systemd, udev, libs, unidades e configs.
- Se presente, instala manpages a partir de `systemd-man-pages-*.tar.*` em `/usr/share/man`.
- Garante `/etc/os-release` e `/etc/machine-id` mínimos:
  - `echo 'NAME="Linux From Scratch"' > /etc/os-release` (se não existir)
  - `systemd-machine-id-setup` (se `machine-id` estiver vazio).
- Executa `systemctl preset-all` (não fatal) para aplicar presets padrão.

---

## 6. Dicas finais de uso e depuração

1. **Sempre acompanhe os logs**:
   - `10-toolchain/run-all.sh`, `20-chroot-base/run-all.sh` e `30-system/run-all.sh`
     tipicamente registram saída em diretórios de log (`logs/` ou `/logs-chroot`).

2. **Em caso de erro em um pacote**:
   - Leia o log do pacote (por ex.: `/logs-chroot/080-bc.log`).
   - Corrija o problema (patch, dependência faltando, versão incompatível).
   - Rode novamente apenas o script daquele pacote.

3. **Sanity-checks**:
   - Host: `bash 00-config/check-toolchain.sh`
   - Chroot: `bash /20-chroot-base/040-check-chroot.sh`

4. **Backups frequentes**:
   - Considere tirar snapshot da partição LFS (via `dd`, `btrfs snapshot`, `lvm snapshot`
     ou similar) antes de passos grandes (Cap. 8 e kernel/bootloader).

---

Com este manual e os scripts fornecidos, você tem uma base sólida para construir
e reconstruir seu sistema LFS automatizado com toolchain moderna, systemd e um conjunto
coeso de ferramentas de usuário e de administração.
