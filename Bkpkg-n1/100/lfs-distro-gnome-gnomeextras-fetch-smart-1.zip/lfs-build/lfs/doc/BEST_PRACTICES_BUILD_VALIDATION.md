
# Best Practices – Validação de Builds Pesados

## Gettext
Verificar binários:
msgfmt --version
xgettext --version

## Perl
perl -V
perl -e 'print "Perl OK\n"'

## Python
python3 --version
python3 - <<EOF
import ssl,hashlib;print(ssl.OPENSSL_VERSION,hashlib.sha256(b"x").hexdigest())
EOF

## OpenSSL
openssl version -a
openssl rand -hex 16
