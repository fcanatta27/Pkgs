# 30-system-CRITICAL-PACKAGES.md

Este documento destaca alguns pacotes críticos do Capítulo 8/30-system e
como interpretar os logs e sanity-checks associados.

Pacotes focados aqui:

- 030-e2fsprogs.sh
- 170-systemd.sh
- 190-shadow.sh
- 210-util-linux.sh

---

## 030-e2fsprogs.sh – E2fsprogs (ext2/3/4)

**Função:** ferramentas para criação, checagem e ajuste de filesystems ext.

**Pontos de atenção no build:**

- Falhas em testes relacionados a `e2fsck`, `mke2fs` ou `tune2fs`
- Mensagens envolvendo incompatibilidades de versão de libcom_err ou libblkid

**Sanity pós-build (script já inclui):**

Após `make install`, o script roda um sanity rápido:

- verifica se `e2fsck` está no PATH
- verifica se `tune2fs` está no PATH

Exemplo de sucesso:

```text
[SANITY] Verificando e2fsck e tune2fs...
```

Se algum comando não for encontrado, será emitido `[WARN]`. Nesse caso:

- verifique se `/usr/sbin` ou `/sbin` estão no PATH do chroot
- cheque o log de build de `030-e2fsprogs.sh` em `logs-30-system` (se configurado)

---

## 170-systemd.sh – Systemd

**Função:** PID 1 e infraestrutura de serviços.

**Pontos de atenção no build:**

- Falhas em `ninja` (se usado) ou `meson` nas fases finais
- Erros de detecção de kernel headers ou bibliotecas de baixo nível

**Sanity pós-build (script já inclui):**

Depois da instalação, o script executa um bloco de sanity:

- checa se `systemctl` está no PATH
- valida se existe `/lib/systemd/system` ou `/usr/lib/systemd/system`

Exemplo de saída saudável:

```text
[SANITY] Verificando systemd básico...
```

Se o script imprimir `[WARN]` para `systemctl` ou diretório de units:

- confira se `/usr/bin` e `/usr/sbin` estão corretamente montados/chrootados
- verifique opções de `--prefix` e `--libdir` usadas na configuração do systemd

---

## 190-shadow.sh – Shadow (autenticação)

**Função:** fornece `passwd`, `login`, `useradd`, etc.

**Build:**

O script de build:

- busca `shadow-*.tar.*` em `/sources`
- configura com `--prefix=/usr --sysconfdir=/etc`
- roda `make`, `make check || true`, `make install`

**Sanity pós-build (no script):**

Após instalar, o script verifica a presença dos binários principais no PATH:

- `passwd`
- `useradd`
- `userdel`
- `groupadd`
- `groupdel`
- `login`

Para cada um, se não estiver visível:

```text
[WARN] <bin> não encontrado no PATH após instalação do shadow.
```

Isso pode indicar:

- PATH incompleto (`/usr/bin` ou `/usr/sbin` faltando)
- instalação em um prefix diferente do esperado
- erro silencioso em `make install` (veja o log de build)

Além disso, é altamente recomendado revisar manualmente:

- `/etc/login.defs`
- `/etc/passwd`
- `/etc/shadow`

para garantir que as políticas de senha e contas estão de acordo com o uso pretendido.

---

## 210-util-linux.sh – Util-linux

**Função:** conjunto de ferramentas essenciais (fdisk, mount, lsblk, etc.).

**Build:**

O script:

- busca `util-linux-*.tar.*` em `/sources`
- configura com `--prefix=/usr --sysconfdir=/etc`
- desabilita algumas ferramentas que você já fornece via outros pacotes (login, su, etc.)
- roda `make`, `make check || true`, `make install`

**Sanity pós-build (no script):**

Após instalar, verifica a presença de alguns binários chave:

- `fdisk`
- `lsblk`
- `mount`
- `umount`
- `swapon`

Se algum não estiver visível:

```text
[WARN] <bin> não encontrado no PATH após instalação do util-linux.
```

Isso sugere:

- instalação fora de `/usr/bin`/`/usr/sbin`
- PATH incorreto
- falha parcial em `make install`

---

## Boas práticas gerais para pacotes críticos

1. **Sempre ler o log de build completo**
   - Use os logs gerados pelos `run-all.sh` (por exemplo, `logs-30-system`) ou
     redirecione manualmente stdout/stderr dos scripts.
2. **Verificar a versão dos binários**
   - `e2fsck -V`, `systemctl --version`, `passwd --version`, `fdisk --version`.
3. **Validar em ambiente real**
   - e2fsprogs: criar um filesystem de teste em um loop device e rodar `fsck`.
   - systemd: bootar a máquina, checar `journalctl`, `systemctl status`.
   - shadow: criar usuário de teste, testar login e troca de senha.
   - util-linux: testar `lsblk`, `mount`, `fdisk -l` em discos reais.

Estes pacotes são considerados “críticos” porque qualquer problema neles tende a
quebrar o sistema de forma global (boot, login, filesystem). Trate seus logs e
sanity-checks como gate obrigatório antes de considerar a build do sistema “confiável”.
## linux-firmware – firmware para hardware gráfico / Wi-Fi

Embora não seja um pacote "de userspace" tradicional, o `linux-firmware` é
crítico para que diversos hardwares funcionem corretamente (Wi-Fi, Bluetooth,
GPUs, etc.).

**Checks recomendados após rodar `230-linux-firmware.sh`:**

- Verificar se `/lib/firmware` não está vazio:

  ```bash
  ls -A /lib/firmware | head
  ```

- Em máquinas físicas, confirmar que o hardware esperado aparece com firmware
  carregado, por exemplo:

  ```bash
  dmesg | grep -i firmware || true
  lspci -k | grep -A3 -Ei 'vga|3d|wifi|wireless'
  ```

- Em casos de Wi-Fi/placas gráficas específicas, validar se não há mensagens
  de erro em `dmesg` do tipo "missing firmware" para os dispositivos em uso.

Falhas de firmware normalmente não impedem o boot, mas resultam em ausência de
rede sem fio, aceleração gráfica, áudio HDMI etc., tornando importante revisar
logs de `dmesg` em hardware real.
