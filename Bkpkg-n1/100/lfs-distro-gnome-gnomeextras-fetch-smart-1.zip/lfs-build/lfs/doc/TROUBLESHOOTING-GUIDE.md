
# Guia de Troubleshooting da Distro LFS (scripts automáticos)

Este documento descreve **problemas comuns** em cada fase da build e como
diagnosticar/corrigir usando os scripts fornecidos no projeto.

## 1. Preparação do host

### Problema: Falta de ferramentas básicas (gcc, make, etc.)

**Sintoma:** scripts em `10-toolchain/` falham com erros de comando não encontrado,
ou `configure: error: C compiler cannot create executables`.

**Causas prováveis:**
- Toolchain do host incompleta ou quebrada.
- `PATH` errado (por exemplo, somente `/usr/local/bin`).

**Mitigação / solução:**
- No host, rode algo como:
  ```bash
  gcc --version
  make --version
  ld --version
  ```
- Instale o grupo "Development Tools" (em distros como Fedora) ou equivalente.
- Verifique se `/usr/bin` está no PATH e que você não está usando um compilador exótico.

### Problema: `LFS` não definido ou apontando para o lugar errado

**Sintoma:** scripts criam diretórios em caminhos estranhos, ou builds falham porque
não encontram `/mnt/lfs`.

**Mitigação:**
- Antes de rodar qualquer script host:
  ```bash
  export LFS=/mnt/lfs
  mkdir -pv $LFS
  ```
- Verifique com `echo $LFS` e `df -h $LFS` se o filesystem está realmente montado.

---

## 2. Toolchain temporária (`10-toolchain`)

### Problema: Falhas no build do Binutils/GCC cross

**Sintoma:** `configure` ou `make` param em scripts como `010-binutils-pass1.sh`, `020-gcc-pass1.sh`.

**Causas:**
- Versão do host GCC muito antiga ou com patches agressivos.
- Falta de headers (kernel headers, glibc headers).

**Mitigação:**
- Verificar logs em algo como `/logs-host/10-toolchain-*.log` (conforme nome dos scripts).
- Checar se o diretório de fontes (`/sources`) contém os tarballs corretos, sem corrupção:
  ```bash
  cd /sources
  md5sum <tarball>
  tar -tf <tarball> | head
  ```
- Em caso de erro de `linker`, confirme se o `ld` usado é o do host correto (`which ld`).

### Problema: `sanity-check` da toolchain falha

**Sintoma:** comando de sanity-check (script inteligente criado anteriormente) acusa
linkagem para bibliotecas do host ou mostra `not found` em libs.

**Mitigação:**
- Releia o log do sanity-check em `/logs-host/...`.
- Confirme se `ldd` em binários aponta para `$LFS` e não para `/usr/lib` do host.
- Se necessário, refaça a fase `10-toolchain` após limpar `$LFS/tools`.

---

## 3. Entrada no chroot e `20-chroot-base`

### Problema: Não consegue entrar no chroot

**Sintoma:** `chroot: failed to run command '/usr/bin/env': No such file or directory`.

**Causas:**
- Bind mounts (`/dev`, `/proc`, `/sys`, `/run`) não feitos.
- Diretório raiz do LFS incompleto (`/usr/bin/env` não existe).

**Mitigação:**
- Verifique se todos os mounts foram feitos conforme instruções do `HOWTO-BUILD-DISTRO.md`.
- Confira se o `20-chroot-base/run-all.sh` foi executado sem falhas.

### Problema: scripts em `20-chroot-base` quebram por falta de dependências

**Sintoma:** `configure: error: required library not found`.

**Mitigação:**
- Veja logs em `/logs-chroot/20-chroot-*.log`.
- Verifique se a ordem dos scripts respeita as dependências do LFS.
- Se faltar um pacote, adicione-o em `30-system` ou como `.pkg` do `lpkg`.

---

## 4. `30-system` (Capítulo 8 + extras + GNOME)

### Problema: `30-system/run-all.sh` falha no meio

**Sintoma:** um script específico em `30-system/` retorna status != 0.

**Mitigação:**
- Verifique o log específico (geralmente em `/logs-chroot/30-system/<script>.log`).
- Rode o script isoladamente:
  ```bash
  cd /30-system
  bash 0NN-pacote.sh
  ```
- Corrija dependências ausentes (por exemplo, libs de X, Wayland, GTK).

### Problema: scripts GNOME (800+ e 900+) falham com Meson

**Sintoma:** `meson setup` falha por falta de pacotes de desenvolvimento.

**Mitigação:**
- Instale dev-libs faltantes via `lpkg` (glib, gtk, pango, etc.) conforme já configurado.
- Cheque se `pkg-config` encontra as libs (`pkg-config --cflags gtk4`).
- Se necessário, force fallback `./configure` nos scripts (já há fallback com `|| true`, mas revise caso queira builds estritos).

### Problema: `999-gnome-full.sh` passa, mas GNOME não sobe

**Sintoma:** tela preta, ou volta para TTY, ou GDM não aparece.

**Mitigação:**
- Rode o sanity-check pós-perfil:
  ```bash
  cd /50-config
  bash 090-post-profile-sanity-check.sh
  ```
- Verifique:
  - `systemctl status gdm.service`
  - `journalctl -b -u gdm`
  - Presença de drivers gráficos (Mesa, drivers específicos).

---

## 5. Kernel e bootloader (`40-kernel-bootloader`)

### Problema: Kernel não boota

**Sintoma:** panic no boot, initramfs não encontra rootfs, etc.

**Mitigação:**
- Confirme que o script `010-kernel-build.sh` usou uma `.config` adequada:
  - `/boot/config-linux` ou `config-$(uname -r)` de uma distro estável.
- Certifique-se de que:
  - drivers do sistema de arquivos root (ext4, xfs ...) estão builtin ou no initramfs.
  - drivers de storage (SATA, NVMe) também estão disponíveis.

### Problema: GRUB não lista corretamente a distro

**Mitigação:**
- Veja `40-kernel-bootloader/020-grub-install-config.sh`.
- Verifique `grub.cfg` gerado em `/boot/grub/grub.cfg`.
- Cheque se a partição root, UUID, etc., estão corretos.

---

## 6. `50-config` (perfis e sanity-check)

### Problema: Perfil notebook/desktop não se aplica completamente

**Sintoma:** serviços não habilitados, GDM não inicia, áudio não funciona.

**Mitigação:**
- Reexecute o perfil apropriado:
  ```bash
  cd /50-config
  bash 020-profile-notebook-gnome.sh   # notebook
  bash 021-profile-desktop-gnome.sh    # desktop
  ```
- Em seguida, rode o sanity-check:
  ```bash
  bash 090-post-profile-sanity-check.sh
  ```
- Analise o log em `/var/log/post-profile-sanity.log` para dicas específicas.

### Problema: Áudio mudo

**Sintoma:** sem som, mas PipeWire parece rodar.

**Mitigação:**
- Verifique se `alsa-lib` e `alsa-utils` foram instalados (scripts 560 e 561).
- Use `alsamixer` para ajustar volumes e saídas (`F6` para selecionar placa).
- Cheque `pavucontrol` para garantir que o dispositivo de saída correto está selecionado.
- Rode novamente o sanity-check e veja a seção de áudio.

### Problema: Bateria não aparece

**Sintoma:** GNOME não mostra bateria, ou `upower -e` não lista baterias.

**Mitigação:**
- Verifique se `upower.service` está habilitado:
  ```bash
  systemctl status upower.service
  ```
- Verifique se o hardware realmente expõe ACPI/bateria (em desktops, normalmente não).

### Problema: GNOME não inicia no boot

**Sintoma:** sistema vai para multi-user.target, sem GUI.

**Mitigação:**
- Verifique se o perfil desktop/notebook rodou com sucesso.
- Confirme:
  ```bash
  systemctl get-default
  systemctl status gdm.service
  ```
- Se o default não for `graphical.target`, corrija:
  ```bash
  systemctl set-default graphical.target
  ```

### Problema: Firefox não é navegador padrão

**Sintoma:** cliques em links em apps não abrem o Firefox.

**Mitigação:**
- Certifique-se de que os scripts `995/996` e `997-firefox-defaults.sh` rodaram.
- Rode novamente:
  ```bash
  cd /30-system
  bash 997-firefox-defaults.sh
  ```
- Confira `mimeapps.list`:
  ```bash
  grep -E 'text/html|x-scheme-handler/http' /etc/xdg/mimeapps.list
  ```
- Para um usuário específico, use:
  ```bash
  gio mime text/html firefox.desktop
  gio mime x-scheme-handler/http firefox.desktop
  gio mime x-scheme-handler/https firefox.desktop
  ```

---

## 7. ISO, installer e pós-instalação

### Problema: ISO não boota

**Sintoma:** BIOS/UEFI ignora a ISO ou entra em prompt rescue.

**Mitigação:**
- Revise o script `lfs/iso/make-iso.sh` e confirme que:
  - o kernel e initrd foram incluídos corretamente,
  - a árvore de boot (EFI ou BIOS) está correta.
- Teste a ISO em uma VM (QEMU/VirtualBox) antes de gravar em mídia física.

### Problema: Instalador falha na cópia de arquivos

**Sintoma:** scripts do instalador falham ao copiar rootfs ou ao gerar fstab.

**Mitigação:**
- Cheque logs do instalador (geralmente em `/var/log/installer.log` ou similar).
- Verifique se as partições foram montadas corretamente antes da cópia.

---

## 8. lpkg e criação de pacotes

### Problema: `lpkg install` não encontra um pacote

**Sintoma:** `lpkg: pacote X não encontrado`.

**Mitigação:**
- Verifique se existe um `.pkg` correspondente em `lfs/pkg/repos/...`.
- Confirme o nome (`NAME=` dentro do `.pkg`) e o nome usado no comando (`lpkg install NAME`).
- Confirme se o tarball esperado (`TARBALL=...`) está em `/sources`.

### Problema: `lpkg remove` não remove todos os arquivos

**Sintoma:** arquivos sobrando após remoção.

**Mitigação:**
- Veja o manifest em `/var/lib/lpkg/manifests/<pacote>.files`.
- Se o pacote instalou arquivos fora dos diretórios rastreados (por exemplo, `/home`, `/tmp`),
  considere ajustar o script de BUILD para manter-se em `/usr`, `/etc`, `/var`, `/opt` etc.

---

## 9. Dicas gerais

- Sempre que ajustar um script, rode apenas aquele script isoladamente e veja o log.
- Use `set -x` temporariamente dentro de um script específico se precisar de mais detalhes.
- Guarde uma VM "limpa" para testar builds do zero periodicamente.
- Use o `HOWTO-BUILD-DISTRO.md` como linha mestra e este guia como apoio para debugging.


---

## 10. Wrapper de perfil automático

Para simplificar a escolha entre perfil **notebook** e **desktop**, use:

```bash
lfs/bin/lfs-install-profile.sh
```

Ele vai:
- detectar automaticamente se há bateria/ACPI e escolher o perfil certo;
- rodar o script correspondente:
  - `50-config/020-profile-notebook-gnome.sh` ou
  - `50-config/021-profile-desktop-gnome.sh`;
- executar o sanity-check pós-perfil:
  - `50-config/090-post-profile-sanity-check.sh`;
- exibir um resumo direto no terminal e registrar tudo em:
  - `/var/log/lfs-install-profile.log`
  - `/var/log/post-profile-sanity.log`.

Você pode forçar um modo específico com:

```bash
lfs/bin/lfs-install-profile.sh --force-notebook
lfs/bin/lfs-install-profile.sh --force-desktop
```

E desabilitar o sanity-check, se desejar, com:

```bash
lfs/bin/lfs-install-profile.sh --no-sanity-check
```
