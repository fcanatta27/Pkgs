
# TOOLCHAIN-REBUILD-HOWTO.md

Este documento explica como **reconstruir a toolchain temporária/cross** usando o
driver inteligente de `10-toolchain/run-all.sh`, como interpretar os logs e como
encaixar isso em pipelines de CI.

---

## 1. Conceito geral

A pasta `10-toolchain/` contém todos os scripts de construção da toolchain:

- Binutils pass1/pass2 (cross e temporário)
- GCC pass1/pass2
- Linux API headers
- Glibc temporária
- Libstdc++ a partir do GCC

O driver `10-toolchain/run-all.sh` orquestra esses scripts em ordem, com:

- logs dedicados em `/logs-10-toolchain/`
- status por script (`OK`/`FAIL`/`NOVO`) em `/logs-10-toolchain/status/`
- suporte a **resume** (não reexecuta scripts já OK)
- suporte a **execução parcial** (`--start-from`, `--only`)

---

## 2. Uso básico – build completo

Dentro do chroot (ou numa etapa preparada de build), rode:

```bash
cd /10-toolchain
./run-all.sh
```

Isso irá:

1. Listar todos os scripts `0*.sh` em `10-toolchain/` (exceto o próprio `run-all.sh`)
2. Verificar o status de cada script:
   - `OK`  → já foi executado com sucesso anteriormente
   - `FAIL` → falhou em uma execução anterior
   - `NOVO` → ainda não foi executado
3. Rodar **apenas** os scripts com status `NOVO` ou marcados como `FAIL` (no caso de rebuild limpo, todos serão NOVO)
4. Registrar logs em:

   ```text
   /logs-10-toolchain/<script>.log
   /logs-10-toolchain/status/<script>.ok
   /logs-10-toolchain/status/<script>.fail
   ```

No final, você verá algo como:

```text
>>> [10-toolchain] Build da toolchain concluído.
>>> [10-toolchain] Use './run-all.sh --list' para ver o status de cada script.
```

---

## 3. Listar status da toolchain

Para ver rapidamente o status de cada etapa:

```bash
cd /10-toolchain
./run-all.sh --list
```

Saída típica:

```text
Scripts em 10-toolchain (com status):
  010-binutils-pass1.sh          OK
  020-gcc-pass1.sh               OK
  030-linux-headers.sh           OK
  040-glibc-temp.sh              OK
  050-libstdc++-from-gcc-15.2.0.sh OK
  210-binutils-pass2.sh          OK
  220-gcc-pass2.sh               OK
```

Interpretação:

- `OK`: etapa concluída com sucesso; log correspondente em `/logs-10-toolchain/<script>.log`
- `FAIL`: última tentativa falhou; ver o log para entender a causa
- `NOVO`: script ainda não foi executado

---

## 4. Resume de builds interrompidos

Se você interromper a build (por exemplo, problema de energia ou necessidade de reboot),
basta rodar novamente:

```bash
cd /10-toolchain
./run-all.sh
```

O driver irá:

- pular scripts com status `OK`
- executar apenas os scripts ainda marcados como `NOVO` ou `FAIL`

Isso permite continuar de onde parou sem rodar tudo do zero.

Se, por algum motivo, você quiser **reconstruir toda a toolchain do zero**, use:

```bash
cd /10-toolchain
./run-all.sh --clean-status
./run-all.sh
```

`--clean-status` remove todos os `.ok` e `.fail`, fazendo com que todos os scripts
sejam tratados como novos.

---

## 5. Retry de pacotes individuais

Se um script específico falhar (por exemplo, `220-gcc-pass2.sh`), você pode:

1. Inspecionar o log:

   ```bash
   less /logs-10-toolchain/220-gcc-pass2.sh.log
   ```

2. Ajustar o problema (flags, patches, espaço em disco, etc.)

3. Rerodar apenas aquele script:

   ```bash
   cd /10-toolchain
   ./run-all.sh --only 220-gcc-pass2.sh
   ```

Isso executa somente esse script, sem mexer no restante.

Se o script passar, o driver sobrescreve o `.fail` com um `.ok` em:

```text
/logs-10-toolchain/status/220-gcc-pass2.sh.ok
```

---

## 6. Execução a partir de um ponto (start-from)

Se você quiser executar a partir de um certo ponto (por exemplo, recomeçar do GCC pass2
em diante), use:

```bash
cd /10-toolchain
./run-all.sh --start-from 220-gcc-pass2.sh
```

O driver irá:

- pular scripts cujo nome é lexicograficamente **anterior** a `220-gcc-pass2.sh`
- executar a partir dele em diante (respeitando status OK/FAIL/NOVO)

Exemplo de uso típico:

- Você reconstruiu a toolchain até `binutils-pass2`, mas quer refazer apenas a parte do GCC:

  ```bash
  ./run-all.sh --clean-status
  ./run-all.sh --start-from 220-gcc-pass2.sh
  ```

---

## 7. Interpretação dos logs

Cada script tem um log dedicado:

```text
/logs-10-toolchain/010-binutils-pass1.sh.log
/logs-10-toolchain/020-gcc-pass1.sh.log
...
```

Em caso de erro, o `run-all.sh` imprime:

```text
[10-toolchain] ERRO ao executar 220-gcc-pass2.sh (veja /logs-10-toolchain/220-gcc-pass2.sh.log).
```

Ao abrir o log, foque em:

- as últimas 50–100 linhas (erros de compilação/link geralmente aparecem no final)
- erros de configure (`configure: error:`)
- erros de `make` (`*** [target] Error 1`)
- problemas de caminho (`No such file or directory` para headers/libs)

Dicas gerais:

- Verifique se `/mnt/lfs`, `/sources` e o chroot estão montados corretamente
- Verifique se a versão dos tarballs bate com a esperada nos scripts (por ex.: `binutils-2.45.1`)
- Certifique-se de que variáveis importantes como `LFS_TGT`, `LFS` e `PATH`
  foram exportadas corretamente antes de entrar no chroot (conforme HOWTO principal).

---

## 8. Integração com CI (pré-chroot)

### 8.1. Etapa típica em CI

Num pipeline CI, faz sentido rodar `10-toolchain/run-all.sh` **antes** de montar o chroot final,
para garantir que a toolchain está saudável.

Pseudo-fluxo:

```bash
# 1. Preparar ambiente de build (host)
#  - instalar toolchain mínima (gcc, make, etc.)
#  - preparar /mnt/lfs, /sources, etc.

cd lfs-build/10-toolchain

# 2. Limpar status, garantir rebuild completo
./run-all.sh --clean-status

# 3. Dry-run (opcional, se você tiver um modo de simulação)
#   (para a toolchain, geralmente vamos direto)

# 4. Build real
./run-all.sh

# 5. Arquivar logs
tar czf logs-10-toolchain.tar.gz /logs-10-toolchain
```

No CI, você pode:

- tratar falha do `run-all.sh` como falha da pipeline;
- salvar `/logs-10-toolchain` como artefato para inspeção posterior;
- só seguir para montagem de chroot/raiz do sistema se a toolchain estiver 100% OK.

### 8.2. Exemplo minimalista de job CI (pseudo-YAML)

```yaml
jobs:
  build-toolchain:
    stage: toolchain
    script:
      - cd lfs-build/10-toolchain
      - ./run-all.sh --clean-status
      - ./run-all.sh
    artifacts:
      when: always
      paths:
        - /logs-10-toolchain
```

Adapte conforme seu provedor (GitHub Actions, GitLab CI, etc.), usando a mesma lógica.

---

## 9. Quando reconstruir a toolchain

Alguns eventos típicos que justificam rebuild completo:

- upgrade grande de versão do GCC ou Binutils
- mudança do target (por exemplo, cross-compilação para outra arquitetura)
- corrupção suspeita de headers ou libs em `/usr` ou `/tools` (dependendo da fase)
- mudança de flags globais de compilação (por exemplo, políticas de hardening agressivas)

Regra de ouro: se a base estiver instável (GCC/Binutils/GLibc), é mais barato reconstruir
a toolchain inteira do que tentar “patches” parciais.

---

Este HOWTO deve ser lido em conjunto com:
- `HOWTO-BUILD-DISTRO.md` (fluxo geral)
- `LEGACY-FULL-UPGRADE-WORKFLOW.md` (para pacotes legacy)
- `30-system-order.md` (ordem do Cap. 8)
## Sanity automático da toolchain com check-toolchain.sh

O driver `10-toolchain/run-all.sh` possui um modo de sanity integrado que
executa o script `00-config/check-toolchain.sh` ao final de todos os passos.

Uso recomendado ao reconstruir a toolchain:

```bash
cd /lfs-build/10-toolchain
./run-all.sh --sanity
```

Isso faz com que, depois de todos os passes (Binutils/GCC, headers, Glibc, etc.),
o sistema compile e execute um pequeno programa C de teste, verificando:

- se `gcc` está no PATH e consegue compilar um programa mínimo;
- se o binário gerado executa corretamente (`toolchain_ok`);
- opcionalmente, as dependências dinâmicas via `ldd` (quando disponível).

Em pipelines de CI, recomenda-se tratar a sequência:

```bash
cd /lfs-build/10-toolchain
./run-all.sh
./run-all.sh --sanity
```

como gate obrigatório antes de prosseguir para o chroot e para o Cap. 8. Isso
garante que a toolchain básica está funcional antes de investir tempo nas
fases seguintes.
