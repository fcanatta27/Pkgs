
#!/bin/bash
set -euo pipefail
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
. "$SCRIPT_DIR/ui-lib.sh"
LOG=/install.log
exec > >(tee -a "$LOG") 2>&1
HOSTNAME_DEFAULT="lfs-dev"
step_welcome(){ ui_msg "Bem-vindo ao instalador da LFS Distro."; }
step_timezone(){ ln -sf /usr/share/zoneinfo/America/Sao_Paulo /etc/localtime || true; }
step_hostname(){ local h; ui_input "Hostname" h || h="$HOSTNAME_DEFAULT"; echo "$h" > /etc/hostname; }
step_user(){ local u; ui_input "Usuário padrão" u || u="dev"; id "$u" >/dev/null 2>&1 || useradd -m -G wheel,audio,video,input "$u"; passwd "$u" || true; }
step_profiles(){ local c; ui_menu "Perfil" c base "Base" server "Server" desktop "Desktop" notebook "Notebook" wm "WM"; case "$c" in desktop|notebook|wm) systemctl set-default graphical.target||true;; *) systemctl set-default multi-user.target||true;; esac; }
step_systemd_core(){ systemctl enable systemd-networkd systemd-resolved systemd-timesyncd || true; }
step_grub(){ local d; ui_input "Disco p/ GRUB (ex: /dev/sda)" d || return 0; [ -b "$d" ] && grub-install "$d" && grub-mkconfig -o /boot/grub/grub.cfg || true; }
step_finish(){ ui_msg "Instalação básica concluída."; }
step_welcome; step_timezone; step_hostname; step_user; step_systemd_core; step_profiles; step_grub; step_finish
