
#!/bin/bash
set -euo pipefail
_ui_has_dialog() { command -v dialog >/dev/null 2>&1; }
_ui_has_whiptail() { command -v whiptail >/dev/null 2>&1; }
ui_msg() { echo "==> $1"; read -r -p "ENTER para continuar... " _; }
ui_yesno() { read -r -p "$1 [s/N] " ans; [[ "$ans" =~ ^[sSyY]$ ]]; }
ui_input() { local r; read -r -p "$1: " r; printf -v "$2" '%s' "$r"; }
ui_menu() { echo "$1"; shift; local __var="$1"; shift; while [ "$#" -gt 0 ]; do t="$1"; d="$2"; shift 2; echo "$t) $d"; done; read -r -p "Escolha: " r; printf -v "$__var" '%s' "$r"; }
