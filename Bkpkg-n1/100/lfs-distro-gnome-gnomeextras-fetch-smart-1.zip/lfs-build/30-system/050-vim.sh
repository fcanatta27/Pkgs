
#!/bin/bash
# 050-vim.sh - Vim (editor de texto, Cap. 8-style)

set -euo pipefail

cd /sources

tarball=$(ls vim-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do vim não encontrado em /sources."
  exit 0
fi

rm -rf vim-src
mkdir -v vim-src
tar -xf "$tarball" -C vim-src --strip-components=1
cd vim-src

./configure         --prefix=/usr         --with-features=normal         --enable-multibyte         --enable-gui=no         --without-x         --disable-netbeans         --enable-terminal

make
make install

ln -sv vim /usr/bin/vi || true

cd /sources
rm -rf vim-src

echo "[OK] Vim instalado em /usr/bin (linkado como vi)."
