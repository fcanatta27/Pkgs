
#!/bin/bash
# 470-libtool.sh - Libtool

set -euo pipefail

cd /sources

tarball=$(ls libtool-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do libtool não encontrado em /sources."
  exit 0
fi

rm -rf libtool-src
mkdir -v libtool-src
tar -xf "$tarball" -C libtool-src --strip-components=1
cd libtool-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf libtool-src

echo "[OK] Libtool instalado em /usr."
