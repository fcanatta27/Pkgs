
#!/bin/bash
# 290-xz.sh - XZ Utils

set -euo pipefail

cd /sources

tarball=$(ls xz-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do xz não encontrado em /sources."
  exit 0
fi

rm -rf xz-src
mkdir -v xz-src
tar -xf "$tarball" -C xz-src --strip-components=1
cd xz-src

./configure \
    --prefix=/usr \
    --disable-static \
    --docdir=/usr/share/doc/xz

make
make check || true
make install

cd /sources
rm -rf xz-src

echo "[OK] XZ Utils instaladas em /usr."
