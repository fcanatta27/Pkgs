
#!/bin/bash
# 200-kbd.sh - Kbd (console keymaps, loadkeys, etc.)

set -euo pipefail

cd /sources

tarball=$(ls kbd-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do kbd não encontrado em /sources."
  exit 0
fi

rm -rf kbd-src
mkdir -v kbd-src
tar -xf "$tarball" -C kbd-src --strip-components=1
cd kbd-src

# Remover documentação em formatos não desejados, se houver
sed -i 's/resizecons.8 //' docs/man/man8/Makefile.in 2>/dev/null || true

./configure \
    --prefix=/usr \
    --disable-vlock

make
make check || true
make install

# Copiar keymaps importantes
mkdir -pv /usr/share/kbd/keymaps
# Os keymaps específicos dependem da versão, então não forçamos cópia manual aqui.

cd /sources
rm -rf kbd-src

echo "[OK] Kbd instalado em /usr."
