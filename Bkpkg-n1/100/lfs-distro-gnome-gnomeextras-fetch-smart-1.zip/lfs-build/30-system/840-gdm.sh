#!/bin/bash
set -euo pipefail
cd /sources
tarball=$(ls gdm-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] gdm não encontrado."
  exit 0
fi
rm -rf gdm-src
mkdir -v gdm-src
tar -xf "$tarball" -C gdm-src --strip-components=1
cd gdm-src
if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr --sysconfdir=/etc --localstatedir=/var --buildtype=release || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var || true
  make || true
  make check || true
  make install || true
fi
if command -v systemctl >/dev/null 2>&1; then
  systemctl enable gdm.service || true
fi
cd /sources
rm -rf gdm-src
echo "[OK] gdm instalado."
