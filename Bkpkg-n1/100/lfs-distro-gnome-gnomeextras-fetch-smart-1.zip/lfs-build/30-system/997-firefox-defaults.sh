#!/bin/bash
# 997-firefox-defaults.sh - Configura Firefox como navegador padrão no GNOME
#
# - Ajusta handlers (http/https, text/html) via gio mime, se disponível
# - Cria/atualiza mimeapps.list em /etc/xdg (sistema) e em /etc/skel/.config
# - Garante entrada firefox.desktop ou firefox-bin.desktop existente
#
# Assumimos que o Firefox (build ou bin) já está instalado e que existe
# um arquivo .desktop chamado firefox.desktop em /usr/share/applications.

set -euo pipefail

DESKTOP_ID="firefox.desktop"
SYSTEM_MIMEAPPS="/etc/xdg/mimeapps.list"
SKEL_DIR="/etc/skel"
SKEL_MIMEAPPS="${SKEL_DIR}/.config/mimeapps.list"

# 1) Verificar se o .desktop existe
if [ ! -f "/usr/share/applications/${DESKTOP_ID}" ]; then
  echo "[FIREFOX-DEFAULTS] /usr/share/applications/${DESKTOP_ID} não encontrado."
  echo "                    Certifique-se de que o Firefox já foi instalado."
  exit 0
fi

# 2) Configurar via gio mime (se disponível)
if command -v gio >/dev/null 2>&1; then
  echo "[FIREFOX-DEFAULTS] Configurando handlers via gio mime..."
  gio mime text/html "${DESKTOP_ID}" || true
  gio mime x-scheme-handler/http "${DESKTOP_ID}" || true
  gio mime x-scheme-handler/https "${DESKTOP_ID}" || true
fi

# Helper para garantir seção e chave em mimeapps.list
ensure_mimeapps_default() {
  local file="$1"
  local mime="$2"
  local desktop="$3"

  mkdir -pv "$(dirname "$file")"
  touch "$file"

  if ! grep -q "^\[Default Applications\]" "$file"; then
    printf "\n[Default Applications]\n" >> "$file"
  fi

  # Se chave já existe, substitui; senão, adiciona
  if grep -q "^${mime}=" "$file"; then
    sed -i "s|^${mime}=.*|${mime}=${desktop};|" "$file"
  else
    # Garante que estamos na seção correta (append simples)
    printf "%s=%s;\n" "$mime" "$desktop" >> "$file"
  fi
}

# 3) mimeapps.list de sistema
echo "[FIREFOX-DEFAULTS] Atualizando ${SYSTEM_MIMEAPPS}..."
ensure_mimeapps_default "$SYSTEM_MIMEAPPS" "text/html" "$DESKTOP_ID"
ensure_mimeapps_default "$SYSTEM_MIMEAPPS" "x-scheme-handler/http" "$DESKTOP_ID"
ensure_mimeapps_default "$SYSTEM_MIMEAPPS" "x-scheme-handler/https" "$DESKTOP_ID"

# 4) mimeapps.list do /etc/skel (para novos usuários)
echo "[FIREFOX-DEFAULTS] Atualizando ${SKEL_MIMEAPPS} para novos usuários..."
ensure_mimeapps_default "$SKEL_MIMEAPPS" "text/html" "$DESKTOP_ID"
ensure_mimeapps_default "$SKEL_MIMEAPPS" "x-scheme-handler/http" "$DESKTOP_ID"
ensure_mimeapps_default "$SKEL_MIMEAPPS" "x-scheme-handler/https" "$DESKTOP_ID"

echo "[FIREFOX-DEFAULTS] Firefox configurado como navegador padrão (nível sistema + skel)."
echo "                    Usuários existentes podem ajustar com 'gio mime' se quiserem."
