
#!/bin/bash
# 270-gawk.sh - Gawk

set -euo pipefail

cd /sources

tarball=$(ls gawk-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gawk não encontrado em /sources."
  exit 0
fi

rm -rf gawk-src
mkdir -v gawk-src
tar -xf "$tarball" -C gawk-src --strip-components=1
cd gawk-src

./configure \
    --prefix=/usr \
    --disable-static

make
make check || true
make install

# Instalar exemplos/documentação se existirem
if [ -d doc ]; then
  mkdir -pv /usr/share/doc/gawk
  cp -v doc/* /usr/share/doc/gawk/ 2>/dev/null || true
fi

cd /sources
rm -rf gawk-src

echo "[OK] Gawk instalado em /usr."
