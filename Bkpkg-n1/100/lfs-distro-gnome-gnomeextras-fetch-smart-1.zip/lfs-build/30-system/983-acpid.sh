#!/bin/bash
# 983-acpid.sh - ACPI daemon (botão de power, tampa do notebook, etc.)

set -euo pipefail

cd /sources

tarball=$(ls acpid-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do acpid não encontrado em /sources."
  exit 0
fi

rm -rf acpid-src
mkdir -v acpid-src
tar -xf "$tarball" -C acpid-src --strip-components=1
cd acpid-src

./configure \
    --prefix=/usr \
    --sysconfdir=/etc || true

make || true
make install || true

# Instalações típicas criam /etc/acpi; aqui apenas garantimos a pasta
mkdir -pv /etc/acpi

if command -v systemctl >/dev/null 2>&1; then
  systemctl enable acpid.service || true
fi

cd /sources
rm -rf acpid-src

echo "[OK] acpid instalado (se build OK)."
