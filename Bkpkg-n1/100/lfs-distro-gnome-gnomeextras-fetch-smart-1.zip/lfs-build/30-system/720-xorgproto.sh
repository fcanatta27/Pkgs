
#!/bin/bash
# 720-xorgproto.sh - Xorg Protocol Headers

set -euo pipefail

cd /sources

tarball=$(ls xorgproto-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do xorgproto não encontrado em /sources."
  exit 0
fi

rm -rf xorgproto-src
mkdir -v xorgproto-src
tar -xf "$tarball" -C xorgproto-src --strip-components=1
cd xorgproto-src

./configure --prefix=/usr || true
make || true
make install || true

cd /sources
rm -rf xorgproto-src

echo "[OK] xorgproto instalado (se build OK)."
