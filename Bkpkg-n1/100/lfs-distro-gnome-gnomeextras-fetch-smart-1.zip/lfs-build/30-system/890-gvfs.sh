#!/bin/bash
# 890-gvfs.sh - GVFS (Virtual File System do GNOME)

set -euo pipefail

cd /sources

tarball=$(ls gvfs-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gvfs não encontrado em /sources."
  exit 0
fi

rm -rf gvfs-src
mkdir -v gvfs-src
tar -xf "$tarball" -C gvfs-src --strip-components=1
cd gvfs-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --sysconfdir=/etc \
      --localstatedir=/var \
      --buildtype=release || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure \
      --prefix=/usr \
      --sysconfdir=/etc \
      --localstatedir=/var || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf gvfs-src

echo "[OK] GVFS instalado (se build OK)."
