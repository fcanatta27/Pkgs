#!/bin/bash
# 026-gcc-final.sh - GCC final (Cap. 8)
#
# Este script constrói e instala a versão final do GCC em /usr,
# substituindo o GCC temporário da toolchain. Assume que as dependências
# (mpfr, gmp, mpc, zlib, etc.) já estão presentes em /usr.
#
set -euo pipefail

cd /sources

tarball=$(ls gcc-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gcc não encontrado em /sources."
  exit 0
fi

rm -rf gcc-src
mkdir -v gcc-src
tar -xf "$tarball" -C gcc-src --strip-components=1
cd gcc-src

# Se os tarballs de mpfr, gmp e mpc estiverem em /sources, integre-os ao source tree
for dep in mpfr gmp mpc; do
  dep_tar=$(ls /sources/${dep}-*.tar.* 2>/dev/null | head -n1 || true)
  if [ -n "$dep_tar" ] && [ ! -d "$dep" ]; then
    echo "[INFO] Integrando $dep ao source tree do GCC..."
    tar -xf "$dep_tar"
    dep_dir=$(basename "$dep_tar" | sed -E 's/\.tar\..*$//')
    mv -v "$dep_dir" "$dep"
  fi
done

mkdir -v build
cd build

../configure \
  --prefix=/usr \
  --enable-languages=c,c++ \
  --disable-multilib \
  --enable-default-pie \
  --enable-default-ssp \
  --enable-host-shared \
  --enable-linker-build-id \
  --with-system-zlib

make

# Testes (podem ser bem demorados)
make -k check || true

make install

# Garantir que o compilador padrão seja /usr/bin/cc -> gcc
if [ -x /usr/bin/gcc ]; then
  ln -svf gcc /usr/bin/cc
fi

# Ajustes simples de libs (evitar libs estáticas desnecessárias)
find /usr/lib/gcc -name "libgcc.a" -type f -print || true

cd /sources
rm -rf gcc-src

echo "[OK] GCC final instalado em /usr."
