
#!/bin/bash
# 190-psmisc.sh - Psmisc (killall, fuser, etc.)

set -euo pipefail

cd /sources

tarball=$(ls psmisc-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do psmisc não encontrado em /sources."
  exit 0
fi

rm -rf psmisc-src
mkdir -v psmisc-src
tar -xf "$tarball" -C psmisc-src --strip-components=1
cd psmisc-src

./configure --prefix=/usr
make
make check || true
make install

cd /sources
rm -rf psmisc-src

echo "[OK] Psmisc instalado em /usr."
