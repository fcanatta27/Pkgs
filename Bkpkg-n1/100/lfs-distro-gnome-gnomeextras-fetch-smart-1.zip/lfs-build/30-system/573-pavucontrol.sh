#!/bin/bash
# 573-pavucontrol.sh - Pavucontrol (controle de volume para Pulse/PipeWire)

set -euo pipefail

cd /sources

tarball=$(ls pavucontrol-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do pavucontrol não encontrado em /sources."
  exit 0
fi

rm -rf pavucontrol-src
mkdir -v pavucontrol-src
tar -xf "$tarball" -C pavucontrol-src --strip-components=1
cd pavucontrol-src

./configure --prefix=/usr || true

make || true
make check || true
make install || true

cd /sources
rm -rf pavucontrol-src

echo "[OK] pavucontrol instalado (se build OK)."
