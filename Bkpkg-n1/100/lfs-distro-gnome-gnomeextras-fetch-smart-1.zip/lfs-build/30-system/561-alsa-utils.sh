#!/bin/bash
# 561-alsa-utils.sh - ALSA utilities (alsamixer, speaker-test, etc.)

set -euo pipefail

cd /sources

tarball=$(ls alsa-utils-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do alsa-utils não encontrado em /sources."
  exit 0
fi

rm -rf alsa-utils-src
mkdir -v alsa-utils-src
tar -xf "$tarball" -C alsa-utils-src --strip-components=1
cd alsa-utils-src

./configure \
    --prefix=/usr \
    --disable-static \
    --with-alsa-lib=/usr || true

make || true
make check || true
make install || true

cd /sources
rm -rf alsa-utils-src

echo "[OK] alsa-utils instalado (se build OK)."
