#!/bin/bash
# 999-gnome-full.sh - Meta-script para instalar toda a stack GNOME (scripts 800+).
#
# Deve ser executado dentro do chroot, após as dependências básicas do sistema
# (Wayland, GTK, etc.) já estarem presentes.
#
# Ele simplesmente percorre todos os scripts 8??-*.sh e 9??-*.sh de 30-system
# em ordem numérica e executa um por um (exceto ele mesmo).

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
LOGDIR=/logs-chroot/30-system-gnome
mkdir -pv "$LOGDIR"

shopt -s nullglob

scripts=( "$HERE"/8??-*.sh "$HERE"/9??-*.sh )

if [ ${#scripts[@]} -eq 0 ]; then
  echo "[GNOME-FULL] Nenhum script 8xx/9xx encontrado em $HERE."
  exit 0
fi

for script in "${scripts[@]}"; do
  base=$(basename "$script")
  # Pula o próprio meta-script
  [[ "$base" == "999-gnome-full.sh" ]] && continue
  echo ">>> [GNOME-FULL] Executando $base"
  bash "$script" 2>&1 | tee "$LOGDIR/$base.log"
done

echo "[GNOME-FULL] Stack GNOME (scripts 800+) executada."
