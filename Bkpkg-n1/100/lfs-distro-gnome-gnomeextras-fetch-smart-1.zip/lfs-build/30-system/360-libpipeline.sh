
#!/bin/bash
# 360-libpipeline.sh - Libpipeline

set -euo pipefail

cd /sources

tarball=$(ls libpipeline-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do libpipeline não encontrado em /sources."
  exit 0
fi

rm -rf libpipeline-src
mkdir -v libpipeline-src
tar -xf "$tarball" -C libpipeline-src --strip-components=1
cd libpipeline-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf libpipeline-src

echo "[OK] Libpipeline instalada em /usr."
