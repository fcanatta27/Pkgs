
#!/bin/bash
# 090-flex.sh - Flex (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls flex-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do flex não encontrado em /sources."
  exit 0
fi

rm -rf flex-src
mkdir -v flex-src
tar -xf "$tarball" -C flex-src --strip-components=1
cd flex-src

./configure     --prefix=/usr     --docdir=/usr/share/doc/flex

make
make check || true
make install

ln -sv flex /usr/bin/lex 2>/dev/null || true

cd /sources
rm -rf flex-src

echo "[OK] Flex instalado em /usr (lex -> flex)."
