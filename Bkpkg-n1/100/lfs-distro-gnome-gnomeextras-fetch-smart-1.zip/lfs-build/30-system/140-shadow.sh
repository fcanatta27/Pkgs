
#!/bin/bash
# 140-shadow.sh - Shadow (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls shadow-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do shadow não encontrado em /sources."
  exit 0
fi

rm -rf shadow-src
mkdir -v shadow-src
tar -xf "$tarball" -C shadow-src --strip-components=1
cd shadow-src

# Desabilitar instalação de 'groups' (já provido por coreutils) e manpages duplicadas
if [ -f etc/login.defs ]; then
  # garantir que senhas SHA512 e rodízio por padrão (ajuste básico)
  sed -i 's/^#\\?ENCRYPT_METHOD.*/ENCRYPT_METHOD SHA512/' etc/login.defs
  sed -i 's/^#\\?SHA_CRYPT_MIN_ROUNDS.*/SHA_CRYPT_MIN_ROUNDS 5000/' etc/login.defs
  sed -i 's/^#\\?SHA_CRYPT_MAX_ROUNDS.*/SHA_CRYPT_MAX_ROUNDS 5000/' etc/login.defs
fi

./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --with-group-name-max-length=32

make
make install

# Remover programas/manpages que conflitam com coreutils ou já foram instalados
rm -f /usr/bin/{groups,uptime} 2>/dev/null || true
rm -f /usr/share/man/man1/{groups.1,uptime.1} 2>/dev/null || true

# Habilitar shadow passwords se ainda não estiverem
if [ -f /etc/passwd ] && [ ! -f /etc/shadow ]; then
  pwconv
fi

if [ -f /etc/group ] && [ ! -f /etc/gshadow ]; then
  grpconv
fi

echo "[INFO] Lembre-se de definir senha para root com: passwd root"

cd /sources
rm -rf shadow-src

echo "[OK] Shadow instalado e conversão para shadow executada (se necessário)."
