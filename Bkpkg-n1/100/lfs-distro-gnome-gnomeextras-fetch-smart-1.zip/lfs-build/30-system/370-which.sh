
#!/bin/bash
# 370-which.sh - Which

set -euo pipefail

cd /sources

tarball=$(ls which-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do which não encontrado em /sources."
  exit 0
fi

rm -rf which-src
mkdir -v which-src
tar -xf "$tarball" -C which-src --strip-components=1
cd which-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf which-src

echo "[OK] Which instalado em /usr."
