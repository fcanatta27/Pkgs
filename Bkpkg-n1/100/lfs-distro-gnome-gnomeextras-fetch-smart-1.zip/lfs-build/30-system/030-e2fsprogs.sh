
#!/bin/bash
# 030-e2fsprogs.sh - E2fsprogs (ferramentas de filesystem ext2/3/4)

set -euo pipefail

cd /sources

tarball=$(ls e2fsprogs-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do e2fsprogs não encontrado em /sources."
  exit 0
fi

rm -rf e2fsprogs-src
mkdir -v e2fsprogs-src
tar -xf "$tarball" -C e2fsprogs-src --strip-components=1
cd e2fsprogs-src

mkdir -v build
cd build

../configure         --prefix=/usr         --sysconfdir=/etc         --enable-elf-shlibs         --disable-libblkid         --disable-libuuid         --disable-uuidd         --disable-fsck

make
make check || true
make install

make install-libs

cd /sources
rm -rf e2fsprogs-src

echo "[OK] E2fsprogs instalado."

# SANITY-CHECK: verificar binários e2fsprogs básicos
echo "[SANITY] Verificando e2fsck e tune2fs..."
if ! command -v e2fsck >/dev/null 2>&1; then
  echo "[WARN] e2fsck não encontrado no PATH após instalação do e2fsprogs."
fi
if ! command -v tune2fs >/dev/null 2>&1; then
  echo "[WARN] tune2fs não encontrado no PATH após instalação do e2fsprogs."
fi

