
#!/bin/bash
# 500-pkgconf.sh - pkgconf (implementação moderna de pkg-config)

set -euo pipefail

cd /sources

tarball=$(ls pkgconf-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do pkgconf não encontrado em /sources."
  exit 0
fi

rm -rf pkgconf-src
mkdir -v pkgconf-src
tar -xf "$tarball" -C pkgconf-src --strip-components=1
cd pkgconf-src

./configure \
    --prefix=/usr \
    --with-pkgconfigdir=/usr/lib/pkgconfig

make
make check || true
make install

# Compatibilidade: pkg-config -> pkgconf
if [ ! -e /usr/bin/pkg-config ]; then
  ln -sv pkgconf /usr/bin/pkg-config
fi

cd /sources
rm -rf pkgconf-src

echo "[OK] pkgconf instalado em /usr (pkg-config compatível)."
