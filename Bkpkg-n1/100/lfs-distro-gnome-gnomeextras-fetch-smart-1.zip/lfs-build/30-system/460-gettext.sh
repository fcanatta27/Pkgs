
#!/bin/bash
# 460-gettext.sh - Gettext

set -euo pipefail

cd /sources

tarball=$(ls gettext-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gettext não encontrado em /sources."
  exit 0
fi

rm -rf gettext-src
mkdir -v gettext-src
tar -xf "$tarball" -C gettext-src --strip-components=1
cd gettext-src

./configure \
    --prefix=/usr \
    --disable-static \
    --docdir=/usr/share/doc/gettext

make
make check || true
make install

cd /sources
rm -rf gettext-src

echo "[OK] Gettext instalado em /usr."
