#!/bin/bash
# 580-gstreamer.sh - GStreamer core

set -euo pipefail

cd /sources

tarball=$(ls gstreamer-1.*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gstreamer não encontrado em /sources."
  exit 0
fi

rm -rf gstreamer-src
mkdir -v gstreamer-src
tar -xf "$tarball" -C gstreamer-src --strip-components=1
cd gstreamer-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --buildtype=release || true

  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf gstreamer-src

echo "[OK] GStreamer core instalado (se build OK)."
