
#!/bin/bash
# 310-patch.sh - Patch

set -euo pipefail

cd /sources

tarball=$(ls patch-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do patch não encontrado em /sources."
  exit 0
fi

rm -rf patch-src
mkdir -v patch-src
tar -xf "$tarball" -C patch-src --strip-components=1
cd patch-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf patch-src

echo "[OK] Patch instalado em /usr."
