#!/bin/bash
# 900-gnome-settings-daemon.sh - GNOME Settings Daemon

set -euo pipefail

cd /sources

tarball=$(ls gnome-settings-daemon-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gnome-settings-daemon não encontrado em /sources."
  exit 0
fi

rm -rf gsd-src
mkdir -v gsd-src
tar -xf "$tarball" -C gsd-src --strip-components=1
cd gsd-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --sysconfdir=/etc \
      --buildtype=release || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure \
      --prefix=/usr \
      --sysconfdir=/etc || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf gsd-src

echo "[OK] GNOME Settings Daemon instalado (se build OK)."
