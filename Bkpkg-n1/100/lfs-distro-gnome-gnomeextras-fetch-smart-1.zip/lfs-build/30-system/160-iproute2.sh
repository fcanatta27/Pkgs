
#!/bin/bash
# 160-iproute2.sh - IPRoute2 (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls iproute2-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do iproute2 não encontrado em /sources."
  exit 0
fi

rm -rf iproute2-src
mkdir -v iproute2-src
tar -xf "$tarball" -C iproute2-src --strip-components=1
cd iproute2-src

# Não construir arpd (depende de Berkeley DB) e remover manpage correspondente, se existirem
sed -i /ARPD/d Makefile 2>/dev/null || true
rm -f man/man8/arpd.8 2>/dev/null || true

make NETNS_RUN_DIR=/run/netns
make SBINDIR=/usr/sbin install

cd /sources
rm -rf iproute2-src

echo "[OK] IPRoute2 instalado em /usr/sbin."
