
#!/bin/bash
# 700-wayland.sh - Wayland core

set -euo pipefail

cd /sources

tarball=$(ls wayland-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do wayland não encontrado em /sources."
  exit 0
fi

rm -rf wayland-src
mkdir -v wayland-src
tar -xf "$tarball" -C wayland-src --strip-components=1
cd wayland-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  :
fi

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf wayland-src

echo "[OK] Wayland instalado (se build OK)."
