
#!/bin/bash
# 350-iana-etc.sh - Iana-Etc (protocols, services DB)

set -euo pipefail

cd /sources

tarball=$(ls iana-etc-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do iana-etc não encontrado em /sources."
  exit 0
fi

rm -rf iana-etc-src
mkdir -v iana-etc-src
tar -xf "$tarball" -C iana-etc-src --strip-components=1
cd iana-etc-src

make
make install

cd /sources
rm -rf iana-etc-src

echo "[OK] Iana-Etc instalado (protocols, services em /etc)."
