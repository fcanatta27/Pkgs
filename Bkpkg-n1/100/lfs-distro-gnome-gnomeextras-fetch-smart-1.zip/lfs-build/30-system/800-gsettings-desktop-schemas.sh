#!/bin/bash
set -euo pipefail
cd /sources
tarball=$(ls gsettings-desktop-schemas-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] gsettings-desktop-schemas não encontrado."
  exit 0
fi
rm -rf gsettings-desktop-schemas-src
mkdir -v gsettings-desktop-schemas-src
tar -xf "$tarball" -C gsettings-desktop-schemas-src --strip-components=1
cd gsettings-desktop-schemas-src
if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr --buildtype=release || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi
cd /sources
rm -rf gsettings-desktop-schemas-src
echo "[OK] gsettings-desktop-schemas instalado."
