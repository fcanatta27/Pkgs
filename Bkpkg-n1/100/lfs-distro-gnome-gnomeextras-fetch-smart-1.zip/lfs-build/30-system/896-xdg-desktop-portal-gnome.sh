#!/bin/bash
# 896-xdg-desktop-portal-gnome.sh - Backend GNOME para xdg-desktop-portal
set -euo pipefail

cd /sources

tarball=$(ls xdg-desktop-portal-gnome-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] xdg-desktop-portal-gnome: tarball xdg-desktop-portal-gnome-*.tar.* não encontrado em /sources."
  exit 0
fi

rm -rf xdg-desktop-portal-gnome-src
mkdir -v xdg-desktop-portal-gnome-src
tar -xf "$tarball" -C xdg-desktop-portal-gnome-src --strip-components=1
cd xdg-desktop-portal-gnome-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr --sysconfdir=/etc --buildtype=release || true
  ninja -C build || true
  ninja -C build test || true
  ninja -C build install || true
else
  ./configure --prefix=/usr --sysconfdir=/etc || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf xdg-desktop-portal-gnome-src

echo "[OK] xdg-desktop-portal-gnome instalado (se build OK)."
