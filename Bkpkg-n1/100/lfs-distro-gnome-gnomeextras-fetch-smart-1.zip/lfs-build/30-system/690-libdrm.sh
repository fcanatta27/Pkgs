
#!/bin/bash
# 690-libdrm.sh - libdrm (dependência de Mesa)

set -euo pipefail

cd /sources

tarball=$(ls libdrm-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do libdrm não encontrado em /sources."
  exit 0
fi

rm -rf libdrm-src
mkdir -v libdrm-src
tar -xf "$tarball" -C libdrm-src --strip-components=1
cd libdrm-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf libdrm-src

echo "[OK] libdrm instalado (se build OK)."
