#!/bin/bash
# 021-profile-desktop-gnome.sh - Perfil Desktop + GNOME + Firefox
#
# Similar ao perfil de notebook, mas sem foco em bateria.
#
set -euo pipefail

LOG=/var/log/profile-desktop-gnome.log
mkdir -pv "$(dirname "$LOG")" >/dev/null 2>&1 || true
touch "$LOG" 2>/dev/null || true

log() {
  echo "$1"
  printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG" 2>/dev/null || true
}

have_systemctl() {
  command -v systemctl >/dev/null 2>&1
}

enable_if_exists() {
  local unit="$1"
  if have_systemctl && systemctl list-unit-files | grep -q "^${unit}"; then
    log "[PROFILE-DESKTOP] Habilitando unidade systemd: $unit"
    systemctl enable "$unit" || log "[WARN] Falha ao habilitar $unit (verifique manualmente)."
  else
    log "[PROFILE-DESKTOP] Unidade não encontrada (não habilitada): $unit"
  fi
}

main() {
  log "========================================================"
  log "[PROFILE-DESKTOP] Aplicando perfil Desktop + GNOME + Firefox"

  if ! have_systemctl; then
    log "[ERRO] systemctl não encontrado. Perfil requer systemd dentro do chroot."
    exit 1
  fi

  # 1) Serviços essenciais de desktop
  enable_if_exists "NetworkManager.service"
  enable_if_exists "NetworkManager-wait-online.service"
  enable_if_exists "systemd-logind.service"
  enable_if_exists "bluetooth.service"

  # 2) Display manager + GNOME
  enable_if_exists "gdm.service"
  enable_if_exists "graphical.target"

  # 3) Áudio
  enable_if_exists "pipewire.service"
  enable_if_exists "pipewire-pulse.service"
  enable_if_exists "wireplumber.service"
  enable_if_exists "pulseaudio.service"
  enable_if_exists "alsa-restore.service"

  # 4) Firefox default em /etc/xdg (igual notebook)
  if [ -d /etc/xdg ]; then
    mkdir -pv /etc/xdg >/dev/null 2>&1 || true
    if [ -f /usr/share/applications/firefox.desktop ]; then
      log "[PROFILE-DESKTOP] Configurando Firefox como navegador padrão (mimeapps.list em /etc/xdg)."
      cat > /etc/xdg/mimeapps.list << 'EOF'
[Default Applications]
text/html=firefox.desktop
x-scheme-handler/http=firefox.desktop
x-scheme-handler/https=firefox.desktop
x-scheme-handler/about=firefox.desktop
x-scheme-handler/unknown=firefox.desktop
EOF
    else:
      log "[PROFILE-DESKTOP] firefox.desktop não encontrado; pulei ajuste de mimeapps.list."
    fi
  else
    log "[PROFILE-DESKTOP] /etc/xdg não existe; pulei ajuste de mimeapps.list."
  fi

  log "[PROFILE-DESKTOP] Perfil Desktop + GNOME + Firefox aplicado."
}

main "$@"
