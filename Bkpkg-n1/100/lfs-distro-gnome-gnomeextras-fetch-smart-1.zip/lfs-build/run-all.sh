#!/bin/bash
# lfs-build/run-all.sh - Orquestra scripts desta etapa
#
# Executa todos os scripts 0*.sh neste diretório (exceto este run-all.sh),
# em ordem lexicográfica, registrando logs individuais em /logs-lfs-build/.
#
set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
LOGDIR=/logs-lfs-build
mkdir -pv "$LOGDIR"

echo ">>> [lfs-build] Iniciando run-all.sh em $HERE"
echo ">>> [lfs-build] Logs individuais: $LOGDIR/"

shopt -s nullglob
scripts=( "$HERE"/0*.sh )
shopt -u nullglob

if [ ${#scripts[@]} -eq 0 ]; then
  echo "[lfs-build] Nenhum script 0*.sh encontrado em $HERE."
  exit 0
fi

idx=0
total=${#scripts[@]}

for script in "${scripts[@]}"; do
  base=$(basename "$script")
  if [ "$base" = "run-all.sh" ]; then
    continue
  fi
  if [ ! -x "$script" ]; then
    echo "[lfs-build] Pulando $base (não executável)."
    continue
  fi
  ((idx++))
  logfile="$LOGDIR/$base.log"
  echo ">>> [lfs-build] [$idx/$total] Executando $base (log: $logfile)"
  if bash "$script" 2>&1 | tee "$logfile"; then
    echo "[lfs-build] $base concluído com sucesso."
  else
    echo "[lfs-build] ERRO ao executar $base (veja $logfile)."
    exit 1
  fi
done

echo ">>> [lfs-build] run-all.sh concluído."
