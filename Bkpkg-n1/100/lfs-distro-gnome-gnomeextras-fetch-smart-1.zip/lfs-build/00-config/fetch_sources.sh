#!/bin/bash
# fetch_sources.sh - Baixa tarballs listados em packages.list para $LFS/sources
#
# Funcionalidades:
#   - Lê 00-config/packages.list (URLs e opcionalmente SHA256)
#   - Ignora linhas vazias e comentários
#   - Faz download apenas se o arquivo ainda não existe ou se o SHA256 não confere
#   - Permite direcionar o destino com --target-dir DIR (default: $LFS/sources ou ./sources)
#   - Mostra progresso e contador
#   - Suporte a modo dry-run (--dry-run) para apenas listar o que seria baixado
#   - Usa curl -fL por padrão, com fallback para wget se disponível
#
set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

if [ -f "$HERE/env.sh" ]; then
  # shellcheck source=/dev/null
  . "$HERE/env.sh"
fi

LIST="$HERE/packages.list"
DRY_RUN=0
TARGET_DIR=""

usage() {
  cat << EOF
Uso: ${0##*/} [opções]

Opções:
  --dry-run           Apenas lista o que seria baixado, sem baixar
  --target-dir DIR    Diretório de destino (default: $LFS/sources ou ./sources se LFS não definido)
  -h, --help          Mostra esta ajuda
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run)
      DRY_RUN=1
      shift
      ;;
    --target-dir)
      TARGET_DIR="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[ERRO] Opção desconhecida: $1" >&2
      usage
      exit 1
      ;;
  esac
done

if [ -z "${TARGET_DIR}" ]; then
  if [ -n "${LFS:-}" ]; then
    TARGET_DIR="$LFS/sources"
  else
    TARGET_DIR="$HERE/../sources"
  fi
fi

mkdir -p "$TARGET_DIR"

if [ ! -f "$LIST" ]; then
  echo "[ERRO] Lista de pacotes não encontrada: $LIST" >&2
  exit 1
fi

# Escolha de ferramenta de download
DL_TOOL=""
if command -v curl >/dev/null 2>&1; then
  DL_TOOL="curl"
elif command -v wget >/dev/null 2>&1; then
  DL_TOOL="wget"
else
  echo "[ERRO] Nem curl nem wget encontrados. Instale um dos dois." >&2
  exit 1
fi

echo "[INFO] Usando diretório de destino: $TARGET_DIR"
echo "[INFO] Usando ferramenta de download: $DL_TOOL"
echo "[INFO] Lendo lista de pacotes em: $LIST"

total=0
to_download=0

while IFS= read -r line || [ -n "$line" ]; do
  # Remove comentários inline
  line="${line%%#*}"
  line="$(echo "$line" | xargs || true)"
  [ -z "$line" ] && continue

  total=$((total+1))

  # Formato suportado:
  # URL
  # URL SHA256
  url=$(printf '%s
' "$line" | awk '{print $1}')
  sha=$(printf '%s
' "$line" | awk '{print $2}')

  case "$url" in
    http://*|https://*|ftp://*)
      ;;
    *)
      echo "[WARN] Linha $total não parece conter URL válida, ignorando: $url"
      continue
      ;;
  esac

  filename=${url##*/}
  dest="$TARGET_DIR/$filename"

  need_download=0

  if [ ! -f "$dest" ]; then
    need_download=1
  elif [ -n "$sha" ]; then
    got=$(sha256sum "$dest" | awk '{print $1}')
    if [ "$got" != "$sha" ]; then
      echo "[WARN] SHA256 divergente para $dest (esperado $sha, obtido $got), refazendo download."
      need_download=1
    else
      echo "[OK] Em cache e SHA256 confere: $filename"
    fi
  else
    echo "[OK] Em cache (sem SHA256 para checar): $filename"
  fi

  if [ "$need_download" -eq 0 ]; then
    continue
  fi

  to_download=$((to_download+1))
  if [ "$DRY_RUN" -eq 1 ]; then
    if [ -n "$sha" ]; then
      echo "[DRY-RUN] Baixaria: $url -> $dest (SHA256=$sha)"
    else
      echo "[DRY-RUN] Baixaria: $url -> $dest"
    fi
    continue
  fi

  echo "[INFO] [$to_download] Baixando: $url"
  tmp="$dest.part"
  rm -f "$tmp"

  if [ "$DL_TOOL" = "curl" ]; then
    if ! curl -fL -o "$tmp" "$url"; then
      echo "[ERRO] Falha ao baixar (curl): $url" >&2
      rm -f "$tmp"
      exit 1
    fi
  else
    if ! wget -O "$tmp" "$url"; then
      echo "[ERRO] Falha ao baixar (wget): $url" >&2
      rm -f "$tmp"
      exit 1
    fi
  fi

  if [ -n "$sha" ]; then
    got=$(sha256sum "$tmp" | awk '{print $1}')
    if [ "$got" != "$sha" ]; then
      echo "[ERRO] SHA256 incorreta para $filename (esperado $sha, obtido $got)." >&2
      rm -f "$tmp"
      exit 1
    fi
  fi

  mv "$tmp" "$dest"
  echo "[OK] Download concluído: $filename"

done < "$LIST"

if [ "$DRY_RUN" -eq 1 ]; then
  echo "[INFO] Dry-run concluído. Arquivos a baixar: $to_download"
else
  echo "[INFO] Download de fontes concluído. Arquivos baixados/refeitos: $to_download"
fi
