#!/bin/bash
# env.sh - Ambiente padrão para build LFS desta distro
#
# Fonte este arquivo ANTES de rodar os scripts de build, por exemplo:
#
#   source 00-config/env.sh
#
# Ele define:
#   - LFS (raiz do build)
#   - LFS_TGT (triplo do target)
#   - PATH priorizando toolchain temporária e binários do host necessários
#   - diretórios básicos (sources, tools, etc.)
#
set -euo pipefail

# Permitir override de LFS; caso contrário, usar /mnt/lfs
LFS=${LFS:-/mnt/lfs}
export LFS

# Detectar target padrão se não definido (útil para x86_64)
if [ -z "${LFS_TGT:-}" ]; then
  LFS_TGT=$(uname -m)-lfs-linux-gnu
fi
export LFS_TGT

export LC_ALL=POSIX

# PATH padrão: ferramentas temporárias e /usr/bin do host
PATH="$LFS/tools/bin:/usr/bin:/bin"
export PATH

# Criar diretórios básicos se não existirem
mkdir -pv "$LFS"/{sources,tools}
chmod -v a+wt "$LFS/sources"

# Link simbólico padrão usado no livro LFS
ln -sv "$LFS/tools" /tools 2>/dev/null || true

echo "Ambiente configurado:"
echo "  LFS=$LFS"
echo "  LFS_TGT=$LFS_TGT"
echo "  PATH=$PATH"
