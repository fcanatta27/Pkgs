#!/bin/bash
# 020-profile-notebook-gnome.sh - Perfil Notebook + GNOME + Firefox
#
# Este script deve ser executado dentro do chroot, após:
#  - 30-system/run-all.sh (base + systemd + GNOME core + áudio)
#  - Kernel + bootloader já configurados
#
# Objetivo:
#  - Habilitar serviços típicos de notebook (energia, rede, bluetooth)
#  - Garantir sessão GNOME (gdm/mutter/gnome-shell) ativa
#  - Integrar Firefox como navegador padrão
#  - Ajustar power-management (upower, acpid) para notebook
#
set -euo pipefail

LOG=/var/log/profile-notebook-gnome.log
mkdir -pv "$(dirname "$LOG")" >/dev/null 2>&1 || true
touch "$LOG" 2>/dev/null || true

log() {
  echo "$1"
  printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG" 2>/dev/null || true
}

have_systemctl() {
  command -v systemctl >/dev/null 2>&1
}

enable_if_exists() {
  local unit="$1"
  if have_systemctl && systemctl list-unit-files | grep -q "^${unit}"; then
    log "[PROFILE-NOTEBOOK] Habilitando unidade systemd: $unit"
    systemctl enable "$unit" || log "[WARN] Falha ao habilitar $unit (verifique manualmente)."
  else
    log "[PROFILE-NOTEBOOK] Unidade não encontrada (não habilitada): $unit"
  fi
}

main() {
  log "========================================================"
  log "[PROFILE-NOTEBOOK] Aplicando perfil Notebook + GNOME + Firefox"

  if ! have_systemctl; then
    log "[ERRO] systemctl não encontrado. Perfil requer systemd dentro do chroot."
    exit 1
  fi

  # 1) Serviços essenciais de notebook
  log "[PROFILE-NOTEBOOK] Habilitando serviços padrão de notebook..."

  enable_if_exists "NetworkManager.service"
  enable_if_exists "NetworkManager-wait-online.service"
  enable_if_exists "bluetooth.service"
  enable_if_exists "upower.service"
  enable_if_exists "acpid.service"
  enable_if_exists "systemd-logind.service"
  enable_if_exists "ModemManager.service"

  # 2) Display manager + GNOME
  log "[PROFILE-NOTEBOOK] Configurando GNOME + GDM..."

  enable_if_exists "gdm.service"
  enable_if_exists "graphical.target"

  # 3) Áudio (PipeWire / PulseAudio conforme stack)
  log "[PROFILE-NOTEBOOK] Verificando serviços de áudio..."

  enable_if_exists "pipewire.service"
  enable_if_exists "pipewire-pulse.service"
  enable_if_exists "wireplumber.service"
  # Fallback: se estiver usando PulseAudio clássico
  enable_if_exists "pulseaudio.service"
  enable_if_exists "alsa-restore.service"

  # 4) Firefox como navegador padrão (em nível de sistema)
  #    Aqui garantimos defaults em /etc/skel para novos usuários.
  if [ -d /etc/xdg ]; then
    mkdir -pv /etc/xdg >/dev/null 2>&1 || true
    if [ -f /usr/share/applications/firefox.desktop ]; then
      log "[PROFILE-NOTEBOOK] Configurando Firefox como navegador padrão (mimeapps.list em /etc/xdg)."
      mkdir -pv /etc/xdg >/dev/null 2>&1
      cat > /etc/xdg/mimeapps.list << 'EOF'
[Default Applications]
text/html=firefox.desktop
x-scheme-handler/http=firefox.desktop
x-scheme-handler/https=firefox.desktop
x-scheme-handler/about=firefox.desktop
x-scheme-handler/unknown=firefox.desktop
EOF
    else
      log "[PROFILE-NOTEBOOK] firefox.desktop não encontrado; pulei ajuste de mimeapps.list."
    fi
  else
    log "[PROFILE-NOTEBOOK] /etc/xdg não existe; pulei ajuste de mimeapps.list."
  fi

  # 5) Ajustes simples de TLP ou powertop, se existirem (não obrigatórios)
  if command -v tlp >/dev/null 2>&1; then
    enable_if_exists "tlp.service"
  fi

  log "[PROFILE-NOTEBOOK] Perfil Notebook + GNOME + Firefox aplicado."
}

main "$@"
