
#!/bin/bash
# 540-perl.sh - Perl

set -euo pipefail

cd /sources

tarball=$(ls perl-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do perl não encontrado em /sources."
  exit 0
fi

rm -rf perl-src
mkdir -v perl-src
tar -xf "$tarball" -C perl-src --strip-components=1
cd perl-src

sh Configure -des \
    -Dprefix=/usr \
    -Dvendorprefix=/usr \
    -Dprivlib=/usr/lib/perl5/core_perl \
    -Darchlib=/usr/lib/perl5/core_perl \
    -Dsitelib=/usr/lib/perl5/site_perl \
    -Dsitearch=/usr/lib/perl5/site_perl \
    -Dvendorlib=/usr/lib/perl5/vendor_perl \
    -Dvendorarch=/usr/lib/perl5/vendor_perl

make
make test || true
make install

cd /sources
rm -rf perl-src

echo "[OK] Perl instalado em /usr."
