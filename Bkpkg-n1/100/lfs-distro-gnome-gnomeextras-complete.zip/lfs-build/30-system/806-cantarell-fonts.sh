#!/bin/bash
# 806-cantarell-fonts.sh - Fontes Cantarell (padrão do GNOME)
set -euo pipefail

cd /sources

tarball=$(ls cantarell-fonts-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] cantarell-fonts: tarball cantarell-fonts-*.tar.* não encontrado em /sources."
  exit 0
fi

rm -rf cantarell-fonts-src
mkdir -v cantarell-fonts-src
tar -xf "$tarball" -C cantarell-fonts-src --strip-components=1
cd cantarell-fonts-src

# A maioria das distros instala diretamente os .ttf em /usr/share/fonts
install -vd /usr/share/fonts/cantarell
find . -type f -name '*.ttf' -exec install -v -m644 '{}' /usr/share/fonts/cantarell/ \; || true

# Atualiza cache de fonts, se fc-cache existir
if command -v fc-cache >/dev/null 2>&1; then
  fc-cache -v
fi

cd /sources
rm -rf cantarell-fonts-src

echo "[OK] cantarell-fonts instalado (se build OK)."
