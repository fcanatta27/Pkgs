#!/bin/bash
# 995-firefox-147.0.1.sh - Build completo do Firefox 147.0.1 a partir do código-fonte
#
# Requisitos (já devem estar disponíveis no sistema):
#  - toolchain C/C++ moderna (gcc/clang compatíveis)
#  - python3 + pip, rust, nodejs, yasm, pkg-config, etc.
#  - bibliotecas de sistema comuns (libX11, libffi, libjpeg, libpng, etc.)
#
# Este script supõe um tarball do tipo:
#   firefox-147.0.1.source.tar.*
# ou similar em /sources.

set -euo pipefail

cd /sources

tarball=$(ls firefox-147.0.1*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[ERRO] Tarball firefox-147.0.1*.tar.* não encontrado em /sources."
  exit 1
fi

echo "[FIREFOX] Usando tarball: $tarball"

rm -rf firefox-147.0.1-src
mkdir -v firefox-147.0.1-src
tar -xf "$tarball" -C firefox-147.0.1-src --strip-components=1
cd firefox-147.0.1-src

# Criar .mozconfig com opções razoáveis para uma build de sistema
cat > .mozconfig << 'EOF'
ac_add_options --prefix=/usr
ac_add_options --enable-release
ac_add_options --enable-application=browser
ac_add_options --disable-debug
ac_add_options --disable-tests
ac_add_options --disable-crashreporter
ac_add_options --disable-updater
ac_add_options --enable-system-ffi
ac_add_options --enable-system-pixman
ac_add_options --with-system-zlib
ac_add_options --with-system-bz2
ac_add_options --with-system-jpeg
ac_add_options --with-system-png
ac_add_options --with-system-libvpx
ac_add_options --with-system-icu
ac_add_options --enable-system-ffi
ac_add_options --enable-default-toolkit=cairo-gtk3
ac_add_options --without-wasm-sandboxed-libraries

mk_add_options MOZ_OBJDIR=@TOPSRCDIR@/obj-firefox
EOF

# Garante que mach seja executável
chmod +x ./mach || true

jobs=$(nproc || echo 1)

echo "[FIREFOX] Configurando build..."
./mach configure

echo "[FIREFOX] Compilando com ${jobs} jobs..."
./mach build -j"${jobs}"

echo "[FIREFOX] Instalando em /usr..."
./mach install

# Instalar ícone e .desktop se não existirem
if [ -d /usr/share/applications ]; then
  if [ ! -f /usr/share/applications/firefox.desktop ]; then
    cat > /usr/share/applications/firefox.desktop << 'EOF'
[Desktop Entry]
Name=Firefox
GenericName=Web Browser
Comment=Browse the Web
Exec=firefox %u
Terminal=false
Type=Application
Icon=firefox
Categories=Network;WebBrowser;
MimeType=text/html;text/xml;application/xhtml+xml;x-scheme-handler/http;x-scheme-handler/https;
EOF
  fi
fi

echo "[FIREFOX] Build e instalação do Firefox 147.0.1 concluídas (salvo erros acima)."
