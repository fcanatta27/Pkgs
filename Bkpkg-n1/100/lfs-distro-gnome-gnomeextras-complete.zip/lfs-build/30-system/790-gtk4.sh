
#!/bin/bash
# 790-gtk4.sh - GTK4

set -euo pipefail

cd /sources

tarball=$(ls gtk-4*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gtk4 não encontrado em /sources."
  exit 0
fi

rm -rf gtk4-src
mkdir -v gtk4-src
tar -xf "$tarball" -C gtk4-src --strip-components=1
cd gtk4-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf gtk4-src

echo "[OK] GTK4 instalado (se build OK)."
