
#!/bin/bash
# 750-pango.sh - Pango

set -euo pipefail

cd /sources

tarball=$(ls pango-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do pango não encontrado em /sources."
  exit 0
fi

rm -rf pango-src
mkdir -v pango-src
tar -xf "$tarball" -C pango-src --strip-components=1
cd pango-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf pango-src

echo "[OK] Pango instalado (se build OK)."
