#!/bin/bash
# 570-pipewire.sh - PipeWire (servidor de áudio/vídeo moderno)

set -euo pipefail

cd /sources

tarball=$(ls pipewire-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do pipewire não encontrado em /sources."
  exit 0
fi

rm -rf pipewire-src
mkdir -v pipewire-src
tar -xf "$tarball" -C pipewire-src --strip-components=1
cd pipewire-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --libdir=/usr/lib \
      --sysconfdir=/etc \
      --localstatedir=/var \
      --buildtype=release \
      -Dsession-managers=[] || true

  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure \
      --prefix=/usr \
      --sysconfdir=/etc \
      --localstatedir=/var || true
  make || true
  make check || true
  make install || true
fi

# Habilitar serviços PipeWire para usuários (depende de systemd)
if command -v systemctl >/dev/null 2>&1; then
  # Serviços de sistema (se existirem)
  systemctl enable pipewire.service 2>/dev/null || true
  systemctl enable pipewire-pulse.service 2>/dev/null || true
fi

cd /sources
rm -rf pipewire-src

echo "[OK] PipeWire instalado (se build OK)."
