
#!/bin/bash
# 170-systemd.sh - Systemd (Cap. 8 estilo LFS systemd)
#
# ATENÇÃO: este script assume que todas as dependências de systemd já foram
# satisfeitas (incluindo util-linux, zlib, libcap, etc.) e que você está
# seguindo o livro LFS/systemd.

set -euo pipefail

cd /sources

tarball=$(ls systemd-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do systemd não encontrado em /sources."
  exit 0
fi

rm -rf systemd-src
mkdir -v systemd-src
tar -xf "$tarball" -C systemd-src --strip-components=1
cd systemd-src

# Ajustar regras udev padrão para grupos mais adequados (baseado em LFS)
if [ -f rules.d/50-udev-default.rules.in ]; then
  sed -e 's/GROUP=\"render\"/GROUP=\"video\"/' \
      -e 's/GROUP=\"sgx\", //'               \
      -i rules.d/50-udev-default.rules.in
fi

mkdir -p build
cd build

# Nota: algumas opções podem variar conforme a versão do systemd.
# Este conjunto é inspirado no LFS systemd atual, mas genérico o suficiente.
meson setup ..                 \
      --prefix=/usr            \
      --buildtype=release      \
      -D default-dnssec=no     \
      -D firstboot=false       \
      -D install-tests=false   \
      -D ldconfig=false        \
      -D sysusers=false        \
      -D rpmmacrosdir=no       \
      -D homed=disabled        \
      -D man=disabled          \
      -D mode=release          \
      -D pamconfdir=no         \
      -D dev-kvm-mode=0660     \
      -D nobody-group=nogroup  \
      -D sysupdate=disabled    \
      -D ukify=disabled        \
      -D docdir=/usr/share/doc/systemd

ninja

# Testes opcionais: requerem /etc/os-release mínimo
if [ ! -f /etc/os-release ]; then
  echo 'NAME="Linux From Scratch"' > /etc/os-release
fi

# Os testes podem falhar em chroot; executamos de forma não fatal
ninja test || true

ninja install

# Manpages pré-geradas, se o tarball systemd-man-pages-* estiver presente
man_tar=$(ls ../../systemd-man-pages-*.tar.* 2>/dev/null | head -n1 || true)
if [ -n "$man_tar" ]; then
  echo "[INFO] Instalando manpages do systemd a partir de $man_tar"
  mkdir -p /usr/share/man
  tar -xf "$man_tar"          \
      --no-same-owner         \
      --strip-components=1    \
      -C /usr/share/man
fi

# machine-id para journald e outros componentes
if [ ! -s /etc/machine-id ]; then
  systemd-machine-id-setup
fi

# Preset de unidades padrão
systemctl preset-all || true

cd /sources
rm -rf systemd-src

echo "[OK] Systemd instalado. Lembre-se de configurar serviços, fstab e kernel conforme o livro LFS."

# SANITY-CHECK SYSTEMD
echo "[SANITY] Verificando systemd básico..."
if ! command -v systemctl >/dev/null 2>&1; then
  echo "[WARN] systemctl não encontrado no PATH; verifique /usr/bin e /sbin."
fi
if [ ! -d /lib/systemd/system ] && [ ! -d /usr/lib/systemd/system ]; then
  echo "[WARN] Diretório de units do systemd não encontrado."
fi

