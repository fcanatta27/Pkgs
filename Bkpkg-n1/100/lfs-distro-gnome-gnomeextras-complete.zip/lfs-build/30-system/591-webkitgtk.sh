#!/bin/bash
# 591-webkitgtk.sh - WebKitGTK (engine Web para GNOME apps)
#
# OBS: este pacote é pesado e sensível a versões de dependências (GTK, libsoup, harfbuzz, etc.).
# O script segue um fluxo genérico com Meson/CMake; ajuste conforme necessário para a versão usada.

set -euo pipefail

cd /sources

tarball=$(ls webkitgtk-*.tar.* webkitgtk-*.tar.xz webkitgtk-*.tar.bz2 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do webkitgtk não encontrado em /sources."
  exit 0
fi

rm -rf webkitgtk-src
mkdir -v webkitgtk-src
tar -xf "$tarball" -C webkitgtk-src --strip-components=1
cd webkitgtk-src

if command -v cmake >/dev/null 2>&1; then
  mkdir -pv build
  cd build
  cmake .. \
      -DCMAKE_INSTALL_PREFIX=/usr \
      -DCMAKE_BUILD_TYPE=Release || true
  make || true
  make test || true
  make install || true
else
  echo "[WARN] cmake não encontrado; ajuste o script para o método de build da sua versão do WebKitGTK."
fi

cd /sources
rm -rf webkitgtk-src

echo "[OK] webkitgtk step concluído (verifique logs para confirmar build real)."
