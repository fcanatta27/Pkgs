#!/bin/bash
# 984-tlp.sh - TLP (otimizador de energia para notebooks)
# OBS: TLP é opcional; se não estiver em /sources, o script apenas faz SKIP.

set -euo pipefail

cd /sources

tarball=$(ls tlp-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do TLP não encontrado em /sources."
  exit 0
fi

rm -rf tlp-src
mkdir -v tlp-src
tar -xf "$tarball" -C tlp-src --strip-components=1
cd tlp-src

# Muitos builds de TLP são basicamente "make install" com DESTDIR ou similar
# Aqui usamos um padrão genérico:
if [ -f Makefile ] || [ -f makefile ]; then
  make || true
  make install || true
else
  # Se for apenas um conjunto de scripts, instale manualmente
  install -Dm755 tlp /usr/bin/tlp || true
fi

if command -v systemctl >/dev/null 2>&1; then
  systemctl enable tlp.service || true
fi

cd /sources
rm -rf tlp-src

echo "[OK] TLP instalado (se build OK)."
