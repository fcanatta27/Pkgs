#!/bin/bash
set -euo pipefail
cd /sources
t=$(ls attr.sh-*.tar.* 2>/dev/null|head -n1)||exit 0
rm -rf src; mkdir src
tar -xf "$t" -C src --strip-components=1
cd src
./configure --prefix=/usr || true
make || true
make check || true
make install || true
