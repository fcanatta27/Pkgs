
#!/bin/bash
# 480-autoconf.sh - Autoconf

set -euo pipefail

cd /sources

tarball=$(ls autoconf-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do autoconf não encontrado em /sources."
  exit 0
fi

rm -rf autoconf-src
mkdir -v autoconf-src
tar -xf "$tarball" -C autoconf-src --strip-components=1
cd autoconf-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf autoconf-src

echo "[OK] Autoconf instalado em /usr."
