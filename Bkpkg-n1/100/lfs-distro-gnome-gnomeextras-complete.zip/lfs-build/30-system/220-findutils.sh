
#!/bin/bash
# 220-findutils.sh - Findutils final

set -euo pipefail

cd /sources

tarball=$(ls findutils-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do findutils não encontrado em /sources."
  exit 0
fi

rm -rf findutils-src
mkdir -v findutils-src
tar -xf "$tarball" -C findutils-src --strip-components=1
cd findutils-src

./configure \
    --prefix=/usr \
    --localstatedir=/var/lib/locate

make
make check || true
make install

cd /sources
rm -rf findutils-src

echo "[OK] Findutils instalado em /usr."
