
#!/bin/bash
# 390-fontconfig.sh - Fontconfig

set -euo pipefail

cd /sources

tarball=$(ls fontconfig-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do fontconfig não encontrado em /sources."
  exit 0
fi

rm -rf fontconfig-src
mkdir -v fontconfig-src
tar -xf "$tarball" -C fontconfig-src --strip-components=1
cd fontconfig-src

./configure \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --disable-static

make
make check || true
make install

# Atualizar cache de fontes se diretórios existirem
if command -v fc-cache >/dev/null 2>&1; then
  fc-cache -f
fi

cd /sources
rm -rf fontconfig-src

echo "[OK] Fontconfig instalado em /usr."
