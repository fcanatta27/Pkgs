
#!/bin/bash
# 330-texinfo.sh - Texinfo

set -euo pipefail

cd /sources

tarball=$(ls texinfo-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do texinfo não encontrado em /sources."
  exit 0
fi

rm -rf texinfo-src
mkdir -v texinfo-src
tar -xf "$tarball" -C texinfo-src --strip-components=1
cd texinfo-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf texinfo-src

echo "[OK] Texinfo instalado em /usr."
