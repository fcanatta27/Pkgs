
#!/bin/bash
# 070-readline.sh - Readline (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls readline-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do readline não encontrado em /sources."
  exit 0
fi

rm -rf readline-src
mkdir -v readline-src
tar -xf "$tarball" -C readline-src --strip-components=1
cd readline-src

sed -i '/MV.*old/d' Makefile.in 2>/dev/null || true
sed -i '/{OLDSUFF}/c:' support/shlib-install 2>/dev/null || true

pkgver=$(echo "${tarball##*/}" | sed 's/readline-\(.*\)\.tar.*/\1/')

./configure     --prefix=/usr     --disable-static     --with-curses     --docdir=/usr/share/doc/readline-"$pkgver"

make SHLIB_LIBS="-lncursesw"
make install

chmod -v 755 /usr/lib/lib{readline,history}.so* 2>/dev/null || true

if ls doc/*.{ps,pdf,html,dvi} >/dev/null 2>&1; then
  install -v -m644 doc/*.{ps,pdf,html,dvi} /usr/share/doc/readline-"$pkgver" || true
fi

cd /sources
rm -rf readline-src

echo "[OK] Readline instalada em /usr."
