
#!/bin/bash
# 760-cairo.sh - Cairo

set -euo pipefail

cd /sources

tarball=$(ls cairo-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do cairo não encontrado em /sources."
  exit 0
fi

rm -rf cairo-src
mkdir -v cairo-src
tar -xf "$tarball" -C cairo-src --strip-components=1
cd cairo-src

./configure \
    --prefix=/usr \
    --disable-static || true

make || true
make check || true
make install || true

cd /sources
rm -rf cairo-src

echo "[OK] Cairo instalado (se build OK)."
