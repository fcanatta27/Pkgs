
#!/bin/bash
# 110-util-linux.sh - Util-linux (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls util-linux-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do util-linux não encontrado em /sources."
  exit 0
fi

rm -rf util-linux-src
mkdir -v util-linux-src
tar -xf "$tarball" -C util-linux-src --strip-components=1
cd util-linux-src

mkdir -v build
cd build

pkgver=$(echo "${tarball##*/}" | sed 's/util-linux-\(.*\)\.tar.*/\1/')

../configure     ADJTIME_PATH=/var/lib/hwclock/adjtime     --docdir=/usr/share/doc/util-linux-"$pkgver"     --disable-chfn-chsh     --disable-login     --disable-nologin     --disable-su     --disable-setpriv     --disable-runuser     --disable-pylibmount     --disable-static     --without-python     --without-systemd     --without-systemdsystemunitdir

make
make install

cd /sources
rm -rf util-linux-src

echo "[OK] Util-linux instalado em /usr."
