#!/bin/bash
# 574-libogg.sh - libogg (container de áudio Ogg)

set -euo pipefail

cd /sources

tarball=$(ls libogg-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do libogg não encontrado em /sources."
  exit 0
fi

rm -rf libogg-src
mkdir -v libogg-src
tar -xf "$tarball" -C libogg-src --strip-components=1
cd libogg-src

./configure --prefix=/usr --disable-static || true

make || true
make check || true
make install || true

cd /sources
rm -rf libogg-src

echo "[OK] libogg instalado (se build OK)."
