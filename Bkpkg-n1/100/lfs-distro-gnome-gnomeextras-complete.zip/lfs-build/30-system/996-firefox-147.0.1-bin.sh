#!/bin/bash
# 996-firefox-147.0.1-bin.sh - Instalação do Firefox 147.0.1 a partir de binário oficial
#
# Espera um tarball do tipo:
#   firefox-147.0.1.tar.bz2
# (ou firefox-147.0.1.tar.* equivalente) em /sources, no formato binário da Mozilla.
#
# Instala em /opt/firefox-147.0.1 e cria symlink em /usr/bin/firefox,
# além de um .desktop file.

set -euo pipefail

cd /sources

tarball=$(ls firefox-147.0.1*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[ERRO] Tarball binário firefox-147.0.1*.tar.* não encontrado em /sources."
  exit 1
fi

echo "[FIREFOX-BIN] Usando tarball: $tarball"

install_dir=/opt/firefox-147.0.1

rm -rf "$install_dir"
mkdir -pv "$install_dir"
tar -xf "$tarball" -C "$install_dir" --strip-components=1

# Symlink em /usr/bin
mkdir -pv /usr/bin
if [ -L /usr/bin/firefox ] || [ -f /usr/bin/firefox ]; then
  rm -f /usr/bin/firefox
fi
ln -sv "$install_dir/firefox" /usr/bin/firefox

# .desktop
mkdir -pv /usr/share/applications
cat > /usr/share/applications/firefox.desktop << 'EOF'
[Desktop Entry]
Name=Firefox (bin)
GenericName=Web Browser
Comment=Browse the Web
Exec=firefox %u
Terminal=false
Type=Application
Icon=firefox
Categories=Network;WebBrowser;
MimeType=text/html;text/xml;application/xhtml+xml;x-scheme-handler/http;x-scheme-handler/https;
EOF

# Ícones (se houver dentro do tarball, já devem ter sido extraídos; caso contrário,
# o sistema pode usar o ícone padrão do tema).
echo "[FIREFOX-BIN] Firefox 147.0.1 binário instalado em $install_dir."
echo "              Symlink /usr/bin/firefox criado e .desktop instalado."
