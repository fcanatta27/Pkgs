#!/bin/bash
# 30-system/run-all.sh - Orquestra scripts desta etapa
#
# Executa todos os scripts 0*.sh neste diretório (exceto este run-all.sh),
# em ordem lexicográfica, registrando logs individuais em /logs-30-system/.
# Opcionalmente, roda 999-post-check.sh ao final (--post-check).
#
set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
LOGDIR=/logs-30-system
mkdir -pv "$LOGDIR"

POST_CHECK=0

usage() {
  cat << EOF
Uso: ${0##*/} [opções]

Opções:
  --post-check   Após executar todos os scripts, roda 999-post-check.sh
  -h, --help     Mostra esta ajuda
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --post-check)
      POST_CHECK=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[30-system] Opção desconhecida: $1" >&2
      usage
      exit 1
      ;;
  esac
done

echo ">>> [30-system] Iniciando run-all.sh em $HERE"
echo ">>> [30-system] Logs individuais: $LOGDIR/"
echo ">>> [30-system] post-check habilitado: $POST_CHECK"

shopt -s nullglob
scripts=( "$HERE"/0*.sh )
shopt -u nullglob

if [ ${#scripts[@]} -eq 0 ]; then
  echo "[30-system] Nenhum script 0*.sh encontrado em $HERE."
  exit 0
fi

idx=0
total=${#scripts[@]}

for script in "${scripts[@]}"; do
  base=$(basename "$script")
  if [ "$base" = "run-all.sh" ]; then
    continue
  fi
  if [ ! -x "$script" ]; then
    echo "[30-system] Pulando $base (não executável)."
    continue
  fi
  ((idx++))
  logfile="$LOGDIR/$base.log"
  echo ">>> [30-system] [$idx/$total] Executando $base (log: $logfile)"
  if bash "$script" 2>&1 | tee "$logfile"; then
    echo "[30-system] $base concluído com sucesso."
  else
    echo "[30-system] ERRO ao executar $base (veja $logfile)."
    exit 1
  fi
done

echo ">>> [30-system] run-all.sh concluído."

if [ $POST_CHECK -eq 1 ]; then
  if [ -x "$HERE/999-post-check.sh" ]; then
    echo ">>> [30-system] Executando sanity consolidado pós-30-system (999-post-check.sh)..."
    if ! "$HERE/999-post-check.sh"; then
      echo "[30-system] Aviso: 999-post-check.sh retornou código diferente de zero."
    fi
  else
    echo "[30-system] post-check habilitado, mas 999-post-check.sh não encontrado ou não executável."
  fi
fi

echo ">>> [30-system] Fim."
