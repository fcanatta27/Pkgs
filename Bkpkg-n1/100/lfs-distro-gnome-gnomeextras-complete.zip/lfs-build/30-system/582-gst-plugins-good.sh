#!/bin/bash
# 582-gst-plugins-good.sh - GStreamer good plugins

set -euo pipefail

cd /sources

tarball=$(ls gst-plugins-good-1.*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gst-plugins-good não encontrado em /sources."
  exit 0
fi

rm -rf gst-plugins-good-src
mkdir -v gst-plugins-good-src
tar -xf "$tarball" -C gst-plugins-good-src --strip-components=1
cd gst-plugins-good-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --buildtype=release || true

  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf gst-plugins-good-src

echo "[OK] gst-plugins-good instalado (se build OK)."
