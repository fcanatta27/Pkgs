
#!/bin/bash
# 550-openssl.sh - OpenSSL

set -euo pipefail

cd /sources

tarball=$(ls openssl-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do openssl não encontrado em /sources."
  exit 0
fi

rm -rf openssl-src
mkdir -v openssl-src
tar -xf "$tarball" -C openssl-src --strip-components=1
cd openssl-src

./Configure \
    --prefix=/usr \
    --openssldir=/etc/ssl \
    shared \
    zlib-dynamic \
    linux-x86_64

make
make test || true
make install

# Ajustar permissões do diretório de configuração
chmod -v 755 /etc/ssl

cd /sources
rm -rf openssl-src

echo "[OK] OpenSSL instalado em /usr."
