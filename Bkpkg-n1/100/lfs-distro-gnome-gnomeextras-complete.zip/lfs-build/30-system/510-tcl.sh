
#!/bin/bash
# 510-tcl.sh - Tcl

set -euo pipefail

cd /sources

tarball=$(ls tcl*-src.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do Tcl não encontrado em /sources."
  exit 0
fi

rm -rf tcl-src
mkdir -v tcl-src
tar -xf "$tarball" -C tcl-src --strip-components=1
cd tcl-src

cd unix

./configure \
    --prefix=/usr \
    --enable-threads

make
make test || true
make install

# link tclsh
ln -svf tclsh* /usr/bin/tclsh

cd /sources
rm -rf tcl-src

echo "[OK] Tcl instalado em /usr."
