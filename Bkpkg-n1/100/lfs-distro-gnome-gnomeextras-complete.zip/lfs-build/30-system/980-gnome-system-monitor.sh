#!/bin/bash
# 980-gnome-system-monitor.sh - Monitor do sistema GNOME

set -euo pipefail

cd /sources

tarball=$(ls gnome-system-monitor-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gnome-system-monitor não encontrado em /sources."
  exit 0
fi

rm -rf gnome-system-monitor-src
mkdir -v gnome-system-monitor-src
tar -xf "$tarball" -C gnome-system-monitor-src --strip-components=1
cd gnome-system-monitor-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build \
      --prefix=/usr \
      --buildtype=release || true
  ninja -C build
  ninja -C build test || true
  ninja -C build install
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf gnome-system-monitor-src

echo "[OK] GNOME System Monitor instalado (se build OK)."
