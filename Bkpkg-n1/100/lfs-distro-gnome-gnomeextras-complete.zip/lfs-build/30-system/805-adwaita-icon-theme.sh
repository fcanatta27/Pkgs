#!/bin/bash
# 805-adwaita-icon-theme.sh - Tema de ícones Adwaita (GNOME)
set -euo pipefail

cd /sources

tarball=$(ls adwaita-icon-theme-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] adwaita-icon-theme: tarball adwaita-icon-theme-*.tar.* não encontrado em /sources."
  exit 0
fi

rm -rf adwaita-icon-theme-src
mkdir -v adwaita-icon-theme-src
tar -xf "$tarball" -C adwaita-icon-theme-src --strip-components=1
cd adwaita-icon-theme-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr --buildtype=release || true
  ninja -C build || true
  ninja -C build test || true
  ninja -C build install || true
else
  ./configure --prefix=/usr || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf adwaita-icon-theme-src

echo "[OK] adwaita-icon-theme instalado (se build OK)."
