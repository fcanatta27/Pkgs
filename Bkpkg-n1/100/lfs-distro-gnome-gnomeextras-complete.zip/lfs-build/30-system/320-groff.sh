
#!/bin/bash
# 320-groff.sh - Groff

set -euo pipefail

cd /sources

tarball=$(ls groff-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do groff não encontrado em /sources."
  exit 0
fi

rm -rf groff-src
mkdir -v groff-src
tar -xf "$tarball" -C groff-src --strip-components=1
cd groff-src

PAGE=A4 \
./configure \
    --prefix=/usr

make
make install

cd /sources
rm -rf groff-src

echo "[OK] Groff instalado em /usr."
