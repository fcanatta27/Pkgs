
#!/bin/bash
# 180-procps-ng.sh - Procps-ng (ps, top, free, etc.)

set -euo pipefail

cd /sources

tarball=$(ls procps-ng-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do procps-ng não encontrado em /sources."
  exit 0
fi

rm -rf procps-ng-src
mkdir -v procps-ng-src
tar -xf "$tarball" -C procps-ng-src --strip-components=1
cd procps-ng-src

./configure \
    --prefix=/usr \
    --docdir=/usr/share/doc/procps-ng \
    --disable-static \
    --disable-kill

make
make check || true
make install

cd /sources
rm -rf procps-ng-src

echo "[OK] Procps-ng instalado em /usr."
