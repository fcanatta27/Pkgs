
#!/bin/bash
# 240-gzip.sh - Gzip

set -euo pipefail

cd /sources

tarball=$(ls gzip-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do gzip não encontrado em /sources."
  exit 0
fi

rm -rf gzip-src
mkdir -v gzip-src
tar -xf "$tarball" -C gzip-src --strip-components=1
cd gzip-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf gzip-src

echo "[OK] Gzip instalado em /usr."
