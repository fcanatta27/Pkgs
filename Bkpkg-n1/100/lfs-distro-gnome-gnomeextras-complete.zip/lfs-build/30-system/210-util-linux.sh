#!/bin/bash
    # 210-util-linux.sh - Util-linux (conjunto de ferramentas essenciais)

    set -euo pipefail

    cd /sources

    tarball=$(ls util-linux-*.tar.* 2>/dev/null | head -n1 || true)
    if [ -z "$tarball" ]; then
      echo "[SKIP] Tarball de util-linux não encontrado em /sources."
      exit 0
    fi

    rm -rf util-linux-src
    mkdir -v util-linux-src
    tar -xf "$tarball" -C util-linux-src --strip-components=1
    cd util-linux-src

    ./configure       --prefix=/usr       --sysconfdir=/etc       --disable-chfn-chsh       --disable-login       --disable-nologin       --disable-su       --disable-setpriv       --disable-runuser       --without-python

    make
    make check || true
    make install

    # SANITY-CHECK: comandos principais de util-linux
    echo "[SANITY] Verificando comandos util-linux..."

    for bin in fdisk lsblk mount umount swapon; do
      if ! command -v "$bin" >/dev/null 2>&1; then
        echo "[WARN] $bin não encontrado no PATH após instalação do util-linux."
      fi
    done

    cd /sources
    rm -rf util-linux-src

    echo "[OK] Util-linux instalado em /usr."
