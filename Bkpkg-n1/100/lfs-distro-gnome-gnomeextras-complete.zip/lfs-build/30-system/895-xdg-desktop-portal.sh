#!/bin/bash
# 895-xdg-desktop-portal.sh - Portal base (screencast, file chooser, sandbox)
set -euo pipefail

cd /sources

tarball=$(ls xdg-desktop-portal-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] xdg-desktop-portal: tarball xdg-desktop-portal-*.tar.* não encontrado em /sources."
  exit 0
fi

rm -rf xdg-desktop-portal-src
mkdir -v xdg-desktop-portal-src
tar -xf "$tarball" -C xdg-desktop-portal-src --strip-components=1
cd xdg-desktop-portal-src

if command -v meson >/dev/null 2>&1 && command -v ninja >/dev/null 2>&1; then
  meson setup build --prefix=/usr --sysconfdir=/etc --buildtype=release || true
  ninja -C build || true
  ninja -C build test || true
  ninja -C build install || true
else
  ./configure --prefix=/usr --sysconfdir=/etc || true
  make || true
  make check || true
  make install || true
fi

cd /sources
rm -rf xdg-desktop-portal-src

echo "[OK] xdg-desktop-portal instalado (se build OK)."
