
#!/bin/bash
# 120-grep.sh - Grep (Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls grep-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do grep não encontrado em /sources."
  exit 0
fi

rm -rf grep-src
mkdir -v grep-src
tar -xf "$tarball" -C grep-src --strip-components=1
cd grep-src

./configure \
    --prefix=/usr \
    --disable-static

make
make check || true
make install

cd /sources
rm -rf grep-src

echo "[OK] Grep instalado em /usr."
