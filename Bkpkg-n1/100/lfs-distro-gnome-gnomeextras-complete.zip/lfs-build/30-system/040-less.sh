
#!/bin/bash
# 040-less.sh - Less (pager, Cap. 8)

set -euo pipefail

cd /sources

tarball=$(ls less-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do less não encontrado em /sources."
  exit 0
fi

rm -rf less-src
mkdir -v less-src
tar -xf "$tarball" -C less-src --strip-components=1
cd less-src

./configure --prefix=/usr --sysconfdir=/etc
make
make install

cd /sources
rm -rf less-src

echo "[OK] Less instalado em /usr/bin."
