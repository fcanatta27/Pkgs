
#!/bin/bash
# 260-sed.sh - Sed final

set -euo pipefail

cd /sources

tarball=$(ls sed-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do sed não encontrado em /sources."
  exit 0
fi

rm -rf sed-src
mkdir -v sed-src
tar -xf "$tarball" -C sed-src --strip-components=1
cd sed-src

./configure --prefix=/usr

make
make check || true
make install

cd /sources
rm -rf sed-src

echo "[OK] Sed instalado em /usr."
