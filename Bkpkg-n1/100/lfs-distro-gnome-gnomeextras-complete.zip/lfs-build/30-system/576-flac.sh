#!/bin/bash
# 576-flac.sh - FLAC (codec de áudio sem perdas)

set -euo pipefail

cd /sources

tarball=$(ls flac-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "[SKIP] Tarball do flac não encontrado em /sources."
  exit 0
fi

rm -rf flac-src
mkdir -v flac-src
tar -xf "$tarball" -C flac-src --strip-components=1
cd flac-src

./configure --prefix=/usr --disable-static || true

make || true
make check || true
make install || true

cd /sources
rm -rf flac-src

echo "[OK] flac instalado (se build OK)."
