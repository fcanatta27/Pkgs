
#!/bin/bash
set -e
ldconfig || true
systemctl daemon-reexec || true
echo "Sistema LFS pronto."
