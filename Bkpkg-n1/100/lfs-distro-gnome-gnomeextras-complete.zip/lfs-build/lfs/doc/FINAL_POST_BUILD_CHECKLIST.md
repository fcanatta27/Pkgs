
# Checklist Final Pós-Build – LFS Distro

## Timezone
ln -sf /usr/share/zoneinfo/America/Sao_Paulo /etc/localtime

## Locale
Editar /etc/locale.gen e rodar locale-gen

## Systemd
systemctl enable systemd-networkd systemd-resolved systemd-timesyncd gdm
systemctl set-default graphical.target

## Usuário
useradd -m -G wheel,audio,video,input dev

## GRUB
grub-install /dev/sdX
grub-mkconfig -o /boot/grub/grub.cfg
