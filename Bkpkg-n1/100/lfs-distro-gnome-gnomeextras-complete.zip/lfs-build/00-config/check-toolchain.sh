#!/bin/bash
# check-toolchain.sh - Sanity-check inteligente da toolchain LFS
#
# Modos de operação:
#   --basic     : compila e executa um programa C mínimo (default)
#   --full      : basic + inspeção de linker, libc e caminhos (readelf/ldd)
#   --log FILE  : grava saída também em FILE
#
# Saída:
#   - Código 0 se todos os checks do modo escolhido passaram
#   - Código != 0 se algum check crítico falhar
#
set -euo pipefail

MODE="basic"
LOGFILE=""

usage() {
  cat << EOF
Uso: ${0##*/} [opções]

Opções:
  --basic         Executa apenas o sanity mínimo (compilação + execução)
  --full          Executa sanity completo (inclui inspeção via readelf/ldd)
  --log FILE      Grava saída também em FILE
  -h, --help      Mostra esta ajuda
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --basic)
      MODE="basic"
      shift
      ;;
    --full)
      MODE="full"
      shift
      ;;
    --log)
      LOGFILE="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[ERRO] Opção desconhecida: $1" >&2
      usage
      exit 1
      ;;
  esac
done

# Se LOGFILE foi definido, redirecionamos tudo para tee
if [ -n "$LOGFILE" ]; then
  mkdir -p "$(dirname "$LOGFILE")"
  exec > >(tee -a "$LOGFILE") 2>&1
fi

TMPDIR=${TMPDIR:-/tmp}
TEST_C="$TMPDIR/toolchain-test.c"
TEST_BIN="$TMPDIR/toolchain-test"

cat > "$TEST_C" << 'EOF'
#include <stdio.h>
int main(void) {
    printf("toolchain_ok\n");
    return 0;
}
EOF

echo "[INFO] Modo de sanity: $MODE"
echo "[INFO] Compilando programa de teste com gcc..."

if ! command -v gcc >/dev/null 2>&1; then
  echo "[ERRO] gcc não encontrado no PATH." >&2
  exit 1
fi

if ! echo 'int main(){}' | gcc -xc - -o /dev/null 2>/dev/null; then
  echo "[ERRO] gcc falhou ao compilar um programa mínimo." >&2
  exit 1
fi

gcc -Wall -Werror "$TEST_C" -o "$TEST_BIN"

echo "[INFO] Executando programa de teste..."
if ! out="$("$TEST_BIN")"; then
  echo "[ERRO] Falha ao executar o binário de teste." >&2
  exit 1
fi

if [ "$out" != "toolchain_ok" ]; then
  echo "[ERRO] Saída inesperada do binário de teste: '$out'." >&2
  exit 1
fi

echo "[OK] Sanity básico da toolchain (compilação + execução) passou."

if [ "$MODE" = "full" ]; then
  echo "[INFO] Executando sanity estendido (linker/libc/caminhos)..."

  if command -v readelf >/dev/null 2>&1; then
    echo "[INFO] readelf -l do binário de teste:"
    readelf -l "$TEST_BIN" | sed -n '1,80p'
  else
    echo "[WARN] readelf não encontrado; pulando inspeção ELF detalhada."
  fi

  if command -v ldd >/dev/null 2>&1; then
    echo "[INFO] ldd do binário de teste:"
    ldd "$TEST_BIN" || true
  else
    echo "[WARN] ldd não encontrado; pulando inspeção de libs dinâmicas."
  fi

  # Heurísticas leves de sanity de caminhos: alerta se aparecer algo muito "host-like"
  echo "[INFO] Heurística de caminhos da toolchain:"
  if command -v gcc >/dev/null 2>&1; then
    gcc -print-search-dirs | sed -n '1,40p'
  fi

  if (command -v readelf >/dev/null 2>&1) && readelf -l "$TEST_BIN" 2>/dev/null | grep -q "/usr/lib"; then
    echo "[WARN] Caminhos /usr/lib encontrados no ELF; verifique se não está vazando libs do host."
  fi
fi

rm -f "$TEST_C" "$TEST_BIN"

echo "[OK] Toolchain C básica parece funcional para o modo '$MODE'."

exit 0
