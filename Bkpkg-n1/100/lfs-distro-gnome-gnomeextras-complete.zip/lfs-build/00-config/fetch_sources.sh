#!/bin/bash
# fetch_sources.sh - Baixa tarballs listados em packages.list para $LFS/sources
#
# Funcionalidades:
#   - Lê 00-config/packages.list (URLs ou caminhos relativos)
#   - Ignora linhas vazias e comentários
#   - Faz download apenas se o arquivo ainda não existe
#   - Mostra progresso e contador
#   - Valida retornos do wget/curl
#   - Suporte a modo dry-run (--dry-run) para apenas listar o que seria baixado
#
set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
# env.sh deve definir LFS e possivelmente outras variáveis de ambiente
if [ -f "$HERE/env.sh" ]; then
  # shellcheck disable=SC1090
  source "$HERE/env.sh"
fi

LIST="$HERE/packages.list"

if [ ! -f "$LIST" ]; then
  echo "[ERRO] Lista de pacotes não encontrada: $LIST" >&2
  exit 1
fi

if [ -z "${LFS:-}" ]; then
  echo "[ERRO] Variável LFS não definida. Verifique env.sh." >&2
  exit 1
fi

SRCDIR="$LFS/sources"
mkdir -pv "$SRCDIR"

DRY_RUN=0

usage() {
  cat << EOF
Uso: ${0##*/} [opções]

Opções:
  --dry-run   Apenas mostra o que seria baixado, sem baixar de fato
  -h, --help  Mostra esta ajuda
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run)
      DRY_RUN=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[ERRO] Opção desconhecida: $1" >&2
      usage
      exit 1
      ;;
  esac
done

echo "[INFO] Usando lista: $LIST"
echo "[INFO] Destino dos tarballs: $SRCDIR"
echo "[INFO] Modo dry-run: $DRY_RUN"

# Escolhe ferramenta de download: wget ou curl
DL_CMD=""
if command -v wget >/dev/null 2>&1; then
  DL_CMD="wget -c"
elif command -v curl >/dev/null 2>&1; then
  DL_CMD="curl -L -O"
else
  echo "[ERRO] Nenhuma ferramenta de download encontrada (wget ou curl)." >&2
  exit 1
fi

total=0
to_download=0

# Contar entradas válidas
while read -r url; do
  [[ -z "$url" ]] && continue
  [[ "$url" =~ ^# ]] && continue
  total=$((total + 1))
done < "$LIST"

echo "[INFO] Total de entradas na lista: $total"

idx=0
while read -r url; do
  # Ignora linhas vazias e comentários
  [[ -z "$url" ]] && continue
  [[ "$url" =~ ^# ]] && continue

  idx=$((idx + 1))

  file=$(basename "$url")
  dest="$SRCDIR/$file"

  if [ -f "$dest" ]; then
    echo "[$idx/$total] [OK] Já existe: $dest"
    continue
  fi

  to_download=$((to_download + 1))
  echo "[$idx/$total] [DL] Precisa baixar: $url -> $dest"

  if [ "$DRY_RUN" -eq 1 ]; then
    continue
  fi

  (
    cd "$SRCDIR"
    echo "[CMD] $DL_CMD "$url""
    if ! $DL_CMD "$url"; then
      echo "[ERRO] Falha ao baixar: $url" >&2
      exit 1
    fi
  )

done < "$LIST"

if [ "$DRY_RUN" -eq 1 ]; then
  echo "[INFO] Dry-run concluído. Arquivos a baixar: $to_download"
else
  echo "[INFO] Download de fontes concluído. Arquivos baixados (novos): $to_download"
fi
