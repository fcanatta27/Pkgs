
#!/bin/bash
# 170-patch.sh - Patch-2.8 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls patch-2.8*.tar.* patch-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Patch não encontrado em $LFS/sources"
  exit 1
fi

rm -rf patch-src
mkdir -v patch-src
tar -xf "$tarball" -C patch-src --strip-components=1
cd patch-src

./configure         --prefix=/usr         --host=$LFS_TGT         --build=$(build-aux/config.guess)

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf patch-src

echo "Patch instalado temporariamente em $LFS/usr."
