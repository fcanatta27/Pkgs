
#!/bin/bash
# 040-glibc-2.42.sh - Glibc-2.42 para o sysroot $LFS

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

glibc_tar=$(ls glibc-2.42*.tar.* glibc-*.tar.* 2>/dev/null | head -n1 || true)
patch_file=$(ls glibc-2.42-fhs-1.patch* 2>/dev/null | head -n1 || true)

if [ -z "$glibc_tar" ]; then
  echo "Tarball do Glibc-2.42 não encontrado em $LFS/sources"
  exit 1
fi

rm -rf glibc-2.42-src
mkdir -v glibc-2.42-src
tar -xf "$glibc_tar" -C glibc-2.42-src --strip-components=1
cd glibc-2.42-src

case $(uname -m) in
  i?86)
    mkdir -pv "$LFS/lib"
    ln -sfv ld-linux.so.2 "$LFS/lib/ld-lsb.so.3"
  ;;
  x86_64)
    mkdir -pv "$LFS/lib64"
    ln -sfv ../lib/ld-linux-x86-64.so.2 "$LFS/lib64/ld-linux-x86-64.so.2"
    ln -sfv ../lib/ld-linux-x86-64.so.2 "$LFS/lib64/ld-lsb-x86-64.so.3"
  ;;
esac

if [ -n "${patch_file:-}" ] && [ -f "$patch_file" ]; then
  patch -Np1 -i "../$patch_file"
else
  echo "[AVISO] Patch glibc-2.42-fhs-1.patch não encontrado; prosseguindo sem aplicar."
fi

mkdir -v build
cd build

echo "rootsbindir=/usr/sbin" > configparms

../configure                                   --prefix=/usr                              --host=$LFS_TGT                            --build=$(../scripts/config.guess)         --disable-nscd                             libc_cv_slibdir=/usr/lib                  --enable-kernel=5.4

make
make DESTDIR=$LFS install

sed '/RTLDLIST=/s@/usr@@g' -i "$LFS/usr/bin/ldd"

cd "$LFS/sources"
rm -rf glibc-2.42-src

echo "Glibc-2.42 instalada em $LFS."
