
#!/bin/bash
# 110-file.sh - File-5.46 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls file-5.46*.tar.* file-5.*.tar.* file-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do File não encontrado em $LFS/sources"
  exit 1
fi

rm -rf file-src
mkdir -v file-src
tar -xf "$tarball" -C file-src --strip-components=1
cd file-src

./configure         --prefix=/usr         --host=$LFS_TGT         --build=$(./config.guess)

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf file-src

echo "File instalado temporariamente em $LFS/usr."
