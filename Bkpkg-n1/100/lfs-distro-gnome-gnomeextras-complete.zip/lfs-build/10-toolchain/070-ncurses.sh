
#!/bin/bash
# 070-ncurses.sh - Ncurses-6.6 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls ncurses-6.6*.tar.* ncurses-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Ncurses não encontrado em $LFS/sources"
  exit 1
fi

rm -rf ncurses-src
mkdir -v ncurses-src
tar -xf "$tarball" -C ncurses-src --strip-components=1
cd ncurses-src

# Build do tic para o host
mkdir -v build
pushd build
  ../configure --prefix=$LFS/tools AWK=gawk
  make -C include
  make -C progs tic
  install -v progs/tic $LFS/tools/bin
popd

# Build principal para o target
./configure --prefix=/usr                                --host=$LFS_TGT                              --build=$(./config.guess)                    --mandir=/usr/share/man                      --with-manpage-format=normal                 --with-shared                                --without-normal                             --with-cxx-shared                            --without-debug                              --without-ada                                --disable-stripping                          AWK=gawk

make
make DESTDIR=$LFS install

ln -sv libncursesw.so $LFS/usr/lib/libncurses.so
sed -e 's/^#if.*XOPEN.*$/#if 1/'         -i $LFS/usr/include/curses.h

cd "$LFS/sources"
rm -rf ncurses-src

echo "Ncurses-6.6 instalado temporariamente em $LFS/usr e tic em $LFS/tools/bin."
