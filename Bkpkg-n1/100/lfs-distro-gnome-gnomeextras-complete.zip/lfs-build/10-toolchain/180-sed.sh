
#!/bin/bash
# 180-sed.sh - Sed-4.9 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls sed-4.9*.tar.* sed-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do Sed não encontrado em $LFS/sources"
  exit 1
fi

rm -rf sed-src
mkdir -v sed-src
tar -xf "$tarball" -C sed-src --strip-components=1
cd sed-src

./configure         --prefix=/usr         --host=$LFS_TGT         --build=$(./build-aux/config.guess)

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf sed-src

echo "Sed instalado temporariamente em $LFS/usr."
