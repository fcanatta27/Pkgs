
#!/bin/bash
# 060-m4.sh - M4-1.4.20 (temporary tool)

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT_DIR=$(cd "$HERE/.." && pwd)
source "$ROOT_DIR/00-config/env.sh"

cd "$LFS/sources"

tarball=$(ls m4-1.4.20*.tar.* m4-*.tar.* 2>/dev/null | head -n1 || true)
if [ -z "$tarball" ]; then
  echo "Tarball do M4 não encontrado em $LFS/sources"
  exit 1
fi

rm -rf m4-src
mkdir -v m4-src
tar -xf "$tarball" -C m4-src --strip-components=1
cd m4-src

./configure --prefix=/usr                   --host=$LFS_TGT                 --build=$(build-aux/config.guess)

make
make DESTDIR=$LFS install

cd "$LFS/sources"
rm -rf m4-src

echo "M4-1.4.20 instalado temporariamente em $LFS/usr."
