#!/bin/bash
# 20-chroot-base/run-all.sh - Orquestra scripts desta etapa
#
# Executa todos os scripts 0*.sh neste diretório (exceto este run-all.sh),
# em ordem lexicográfica, registrando logs individuais em /logs-20-chroot-base/.
#
set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
LOGDIR=/logs-20-chroot-base
mkdir -pv "$LOGDIR"

echo ">>> [20-chroot-base] Iniciando run-all.sh em $HERE"
echo ">>> [20-chroot-base] Logs individuais: $LOGDIR/"

shopt -s nullglob
scripts=( "$HERE"/0*.sh )
shopt -u nullglob

if [ ${#scripts[@]} -eq 0 ]; then
  echo "[20-chroot-base] Nenhum script 0*.sh encontrado em $HERE."
  exit 0
fi

idx=0
total=${#scripts[@]}

for script in "${scripts[@]}"; do
  base=$(basename "$script")
  if [ "$base" = "run-all.sh" ]; then
    continue
  fi
  if [ ! -x "$script" ]; then
    echo "[20-chroot-base] Pulando $base (não executável)."
    continue
  fi
  ((idx++))
  logfile="$LOGDIR/$base.log"
  echo ">>> [20-chroot-base] [$idx/$total] Executando $base (log: $logfile)"
  if bash "$script" 2>&1 | tee "$logfile"; then
    echo "[20-chroot-base] $base concluído com sucesso."
  else
    echo "[20-chroot-base] ERRO ao executar $base (veja $logfile)."
    exit 1
  fi
done

echo ">>> [20-chroot-base] run-all.sh concluído."
