# Tutorial – Construir o 3bLinux do zero com o kit

Este tutorial explica, passo a passo, como usar o kit 3bLinux para construir um sistema a partir do zero,
usando:

- `rootfs/` como base;
- scripts de construção em `packages/`;
- ferramentas em `tools/`.

## 1. Conceito: o que é o kit 3bLinux?

O kit 3bLinux é composto por:

- um **rootfs modelo** (`rootfs/`) – estrutura mínima de sistema de arquivos;
- uma **coleção de scripts de build** (`packages/*/build-*.sh`) – um por pacote;
- um conjunto de **ferramentas bk-*** em `tools/` que coordenam:
  - build,
  - empacotamento,
  - índice de repositório,
  - atualização,
  - ISO,
  - instalação, etc.

A ideia é:

1. Você constrói binários com `tools/bk-build-wrapper` usando os scripts em `packages/`.
2. O `bk` gera pacotes e índices (para repositório).
3. O rootfs é preenchido com os pacotes instalados.
4. Em cima disso, você gera ISO e instala.

## 2. Preparando a máquina de build

Requisitos mínimos na **máquina hospedeira** (que vai compilar o 3bLinux):

- Linux com:
  - `gcc`, `g++`, `make`, `binutils`
  - `bash`, `coreutils`, `grep`, `sed`, `awk`
  - `tar`, `gzip`, `bzip2`, `xz`, `curl` ou `wget`
- espaço em disco suficiente (recomendo pelo menos 20–30 GB).
- permissões de sudo (caso vá instalar diretamente numa partição real).

Baixe e extraia o kit:

```sh
tar xvf 3bLinux-sysvinit-initramfs-kit-1.0.15.tar.gz
cd 3bLinux-sysvinit-initramfs-kit-v19-update-upstream-build-modern
```

(Os nomes exatos podem mudar; use o diretório extraído.)

## 3. Entendendo o fluxo de build com o bk

Ferramentas principais (em `tools/`):

- `bk-build-wrapper`  
  Invoca os scripts em `packages/` para construir e empacotar um programa.

- `bk-update`, `bk-upstream`  
  Gerenciam repositório (índices, canais `stable/testing`, assinaturas, etc.).

- `bk-initramfs`  
  Monta/atualiza o initramfs a partir do rootfs.

- `bk-mkiso`  
  Gera ISO inicializável (junto com `xorriso`/`grub-mkrescue`).

- `bk-install`  
  Script de instalação para copiar rootfs e configurar boot em disco real.

### 3.1. Estrutura de um build de pacote

Cada pacote possui:

```text
packages/<nome-versao>/
  build-<nome-versao>.sh
```

O `bk-build-wrapper` faz algo como:

1. Cria um diretório temporário `/tmp/<nome>-build`.
2. Baixa o tarball original do software.
3. Compila e instala em `PKG_ROOT=/tmp/<nome>-build/pkgroot`.
4. Monta um pacote (`.bk` ou similar) usando o conteúdo de `PKG_ROOT`.
5. Atualiza o índice do repositório local.

Você, como usuário, basicamente chama:

```sh
tools/bk-build-wrapper <nome-versao>
```

Por exemplo:

```sh
tools/bk-build-wrapper coreutils-9.9
tools/bk-build-wrapper glibc-2.40
tools/bk-build-wrapper bash-5.2.37
```

## 4. Construindo a base do sistema

### 4.1. Ordem recomendada (conceito)

Uma ordem típica:

1. Toolchain mínima: `binutils`, `gcc`, `glibc`, `linux-headers`, `m4`, `autoconf`, `automake`, `libtool`, etc.
2. Core do sistema: `bash`, `coreutils`, `sed`, `grep`, `gawk`, `findutils`, `tar`, `gzip`, `bzip2`, `xz`, `diffutils`, etc.
3. Gerenciamento de usuários: `shadow`, `util-linux`, `e2fsprogs`, `procps-ng`, etc.
4. Rede: `iproute2`, `net-tools`, `wireless-tools`, `dhcpcd`, `openssh`, etc.
5. Serviços do sistema: `sysklogd`, `sysvinit`, `udev`, `dbus`, `ntp`, etc.

Grande parte disso já está mapeada nos scripts em `packages/`.

### 4.2. Exemplo prático

```sh
# Dentro do diretório raiz do kit
cd 3bLinux-sysvinit-initramfs-kit-1.0.15

# Toolchain autotools (meta)
tools/bk-build-wrapper autotools-1.0

# Alguns componentes base
tools/bk-build-wrapper coreutils-9.9
tools/bk-build-wrapper findutils-4.10.0
tools/bk-build-wrapper procps-ng-4.0.5
tools/bk-build-wrapper e2fsprogs-1.47.3
tools/bk-build-wrapper iproute2-6.18.0
tools/bk-build-wrapper sysklogd-2.7.2
```

À medida que os pacotes vão sendo construídos, o bk atualiza:

- repositório local (por exemplo em `repo/` ou `pkgs/`);
- metadados de índice de versões.

## 5. Instalando pacotes no rootfs

Existem duas abordagens:

1. **Durante o build**, o `bk` já sabe onde “instalar” (via chroot/imagem).
2. **Manual**, usando chroot, por exemplo:

   - montar o rootfs em algum lugar (ex.: `/mnt/3blroot`);
   - usar scripts do bk para extrair pacotes nesse rootfs.

A maneira recomendada no kit é usar os próprios scripts do bk conforme definidos na documentação interna. Em geral, eles:

- montam o rootfs em um diretório temporário;
- extraem os pacotes lá;
- atualizam índice e metadados.

Se você quiser experimentar manualmente, pode:

```sh
# supondo que tenha um pacote gerado em repo/
mkdir -p /mnt/3blroot
# (montar uma partição ou usar um diretório comum)
tar xf meu-pacote.bk -C /mnt/3blroot
```

Mas o fluxo pensado é usar sempre os caminhos do bk.

## 6. Construindo o perfil workstation

Depois de ter a base:

1. Construa os componentes de desktop (Xorg, Mesa, GTK, etc.) via scripts em `packages/`.
2. Execute:

```sh
sudo tools/bk-postinstall-workstation
```

Esse script:

- chama os `bk-build-wrapper` críticos do desktop;
- ajusta alternativas (`bk-update-alternatives apply-default`);
- roda `bk-reparo` para atualizar caches e verificar init/boot;
- deixa o sistema pronto para `init 5` → login gráfico via LightDM.

## 7. Regenerando initramfs e kernel

Depois de instalar/atualizar pacotes de base, use:

- `bk-initramfs` – para recriar initramfs com:

  - kernel atual,
  - busybox (ou outros binários),
  - scripts de init.

## 8. Resumo

O fluxo “do zero” é:

1. Preparar máquina de build.
2. Usar `tools/bk-build-wrapper` para construir toolchain e base.
3. Preencher rootfs com os pacotes.
4. Ajustar configs em `rootfs/etc`.
5. Gerar initramfs e kernel.
6. Gerar ISO (`bk-mkiso`).
7. Instalar com `bk-install`.
8. Rodar `bk-postinstall-workstation`.

Detalhes de ISO, servidor de repo, depuração etc. são cobertos em tutoriais específicos em `docs/`.
