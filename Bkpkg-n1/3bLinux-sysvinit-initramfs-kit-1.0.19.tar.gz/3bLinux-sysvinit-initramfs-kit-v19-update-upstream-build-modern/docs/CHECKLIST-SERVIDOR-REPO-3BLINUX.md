# CHECKLIST – Validação do servidor de repositório 3bLinux (nginx)

Este checklist ajuda a confirmar que o seu servidor de repositório 3bLinux
está corretamente configurado e pronto para uso pelos clientes.

## 1. Estrutura em disco

Depois de rodar:

```sh
sudo bk-setup-repo-nginx-server --release 1.0 --owner www-data:www-data
```

Verifique:

```sh
ls -R /srv/www/3bLinux/1.0
```

Você deve ver:

```text
/srv/www/3bLinux/1.0/stable/
 /srv/www/3bLinux/1.0/testing/
 /srv/www/3bLinux/1.0/keys/
```

Permissões:

```sh
ls -ld /srv/www/3bLinux/1.0/*
```

- Dono/grupo devem bater com o usuário do nginx (ex.: `www-data`).

## 2. Configuração do nginx

1. Copie o template do kit:

   ```sh
   sudo cp docs/nginx-3blinux-repo.conf /etc/nginx/sites-available/3blinux-repo.conf
   ```

2. Habilite o site:

   ```sh
   cd /etc/nginx/sites-enabled
   sudo ln -s ../sites-available/3blinux-repo.conf .
   ```

3. Teste a configuração:

   ```sh
   sudo nginx -t
   ```

4. Recarregue o nginx:

   ```sh
   sudo systemctl reload nginx
   ```

5. Teste no próprio servidor:

   ```sh
   curl -v http://localhost:8080/3bLinux/1.0/
   ```

   Deve listar `stable/`, `testing/`, `keys/` (autoindex).

## 3. Publicando pacotes e INDEX.v1

Na máquina builder (onde você usa o kit 3bLinux):

1. Gere alguns pacotes com o `bk` (via `tools/bk-build-wrapper`).
2. Rode:

   ```sh
   tools/bk-sync-repo-server \
     --release 1.0 \
     --repo-root "$HOME/repos/3bLinux" \
     --remote-base "user@seu-servidor:/srv/www/3bLinux" \
     --channels stable,testing
   ```

   Isso deve:

   - copiar pacotes do store local (`/var/3bLinux` por padrão) para `<repo-root>/1.0/<channel>/pkgs/`;
   - chamar `tools/bk-publish-repo` para gerar `INDEX.v1`;
   - publicar tudo via rsync para `/srv/www/3bLinux/1.0/<channel>/`.

3. Verifique no servidor:

   ```sh
   ls /srv/www/3bLinux/1.0/stable
   ```

   Deve conter:

   - `INDEX.v1`
   - pacotes `.bk` (ou extensão definida no kit)
   - eventualmente arquivos de assinatura (`.asc`), se você ativou GPG.

## 4. Testando INDEX.v1 e assinatura

### 4.1. Via HTTP (curl/wget)

```sh
curl http://seu-servidor:8080/3bLinux/1.0/stable/INDEX.v1
```

- Deve retornar o conteúdo do índice (texto).

Se você habilitou assinatura GPG em `bk-publish-repo`:

```sh
curl http://seu-servidor:8080/3bLinux/1.0/stable/INDEX.v1.asc
```

- Deve retornar o arquivo de assinatura.

No cliente, importe a chave pública do repo e verifique:

```sh
gpg --keyserver keyserver.ubuntu.com --recv-keys <KEYID>   # se necessário
curl http://seu-servidor:8080/3bLinux/1.0/stable/INDEX.v1 -o INDEX.v1
curl http://seu-servidor:8080/3bLinux/1.0/stable/INDEX.v1.asc -o INDEX.v1.asc
gpg --verify INDEX.v1.asc INDEX.v1
```

### 4.2. Conferir download de pacote

Escolha um pacote qualquer listado em `INDEX.v1`:

```sh
curl -O http://seu-servidor:8080/3bLinux/1.0/stable/nome-do-pacote.bk
```

Calcule hash local:

```sh
sha256sum nome-do-pacote.bk
```

Compare com o hash registrado em `INDEX.v1`.

## 5. Teste via cliente 3bLinux

No cliente 3bLinux, ajuste a origem do repo (via `bk-upstream` ou arquivo de config):

- stable → `http://seu-servidor:8080/3bLinux/1.0/stable`
- testing → `http://seu-servidor:8080/3bLinux/1.0/testing`

Depois:

```sh
sudo bk-update
```

Verifique:

- se o cliente consegue baixar `INDEX.v1`;
- se baixa novos pacotes quando for o caso;
- se snapshots/rollback funcionam (conforme design do `bk-update`).

## 6. Resumo

Checklist completo:

- [ ] /srv/www/3bLinux/<release>/{stable,testing,keys} existem, com dono/grupo corretos.
- [ ] Config nginx ativa (`nginx -t` OK, `systemctl reload nginx` OK).
- [ ] Autoindex em `http://servidor:8080/3bLinux/<release>/` mostra stable/testing/keys.
- [ ] `bk-sync-repo-server` publica pacotes e `INDEX.v1` sem erros.
- [ ] `curl http://servidor:8080/.../INDEX.v1` retorna conteúdo válido.
- [ ] Assinatura GPG (se usada) é verificada com sucesso.
- [ ] Cliente 3bLinux consegue usar `bk-update` apontando para esse servidor.
