# 3bLinux 1.0 – Versões de Componentes

Esta tabela lista as versões congeladas dos principais componentes que compõem o release 1.0.
Ela serve como referência para reprodutibilidade e debug.

> OBS: Alguns componentes internos (como o kernel) podem variar conforme o ambiente de build.
> Aqui listamos o conjunto mínimo garantido pelo kit e pelos scripts de construção.

| Componente      | Versão     | Observações                                    |
|-----------------|-----------:|-----------------------------------------------|
| bk              | interno    | Gerenciador de pacotes próprio do 3bLinux     |
| bk-update       | interno    | Atualizador com canais stable/testing + rollback |
| bk-initramfs    | interno    | Geração de initramfs padrão 3bLinux           |
| bk-upstream     | interno    | Descoberta de versões upstream                |
| init-reparo     | interno    | Auto‑reparo de init/fstab/inittab/initramfs   |
| kmod            | 34.2       | Módulos de kernel                             |
| findutils       | 4.10.0     | `find`, `xargs`, etc.                         |
| iproute2        | 6.18.0     | Ferramentas de rede modernas (`ip`, etc.)     |
| kbd             | 2.9.0      | Mapas de teclado                              |
| libpipeline     | 1.5.8      | Biblioteca de encadeamento de comandos        |
| tar             | 1.35       | Utilitário de arquivamento                    |
| vim             | 9.1.2031   | Editor de texto padrão                        |
| MarkupSafe      | 3.0.3      | Biblioteca Python (segurança de templates)    |
| Jinja2          | 3.1.6      | Engine de templates Python                    |
| dbus            | 1.16.x     | Barramento de mensagens do sistema            |
| procps-ng       | 4.0.5      | `ps`, `top`, etc.                             |
| e2fsprogs       | 1.47.3     | Ferramentas para ext2/3/4                     |
| sysklogd        | 2.7.2      | Sistema de logs clássico (syslog/klogd)       |
| tzdata          | 2025a      | Banco de timezones IANA                       |
| gpgme           | 2.0.1      | Biblioteca de integração com GnuPG            |
| make-ca         | 1.16.1     | Gestão de certificados raiz do sistema        |
| GnuPG           | 2.5.16     | Criptografia e assinaturas                    |
| iptables        | 1.8.11     | Firewall em modo legado (`iptables`/`ip6tables`) |
| Linux-PAM       | 1.7.1      | Autenticação pluggable                        |
| liboauth        | 1.0.3      | OAuth para aplicações que precisem            |

Pacotes adicionais podem ser construídos a partir de `packages/` usando o `bk` e integrados
ao repositório 3bLinux 1.0 (canais `stable` e `testing`) seguindo o formato de índice `INDEX.v1`.
