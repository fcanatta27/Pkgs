## Pacotes recomendados para o ambiente Live/Builder (para ISO e instalação)

Para que `bk-install` e `tools/bk-mkiso` funcionem no ambiente live/builder, é recomendado ter os seguintes programas:
- `rsync`
- `dosfstools`
- `parted`
- `xorriso`
- `grub` (inclui `grub-mkrescue`)
- Ferramentas de filesystem opcionais: `btrfs-progs`, `xfsprogs`, `reiserfsprogs`

Scripts de build correspondentes foram adicionados em `packages/`:
- `packages/rsync-3.4.1/`
- `packages/dosfstools-4.2/`
- `packages/parted-3.6/`
- `packages/xorriso-1.5.6/`
- `packages/grub-2.12/`
- `packages/btrfs-progs-6.17.1/`
- `packages/sudo-1.9.17p2/`
- `packages/xfsprogs-6.18.0/`
- `packages/reiserfsprogs-3.6.27/`

# 3bLinux 1.0 – Instalação Rápida

Este documento descreve a instalação padrão do **3bLinux 1.0** usando o instalador `bk-install`.

## Pré-requisitos

- Boot a partir da mídia de instalação (ISO ou pendrive) baseada neste kit.
- Acesso root no ambiente live (normalmente você já estará como root).
- Um disco livre ou partições preparadas para receber o sistema.

## Gerar uma ISO de instalação (opcional)

Para gerar uma ISO bootável a partir do kit 1.0, use o script:

```bash
./tools/bk-mkiso --kernel /caminho/vmlinuz --initramfs /caminho/initramfs.img --out ./3bLinux-1.0.iso
```

Requisitos no host de build:
- `grub-mkrescue` (grub2)
- `xorriso`
- `rsync`

A ISO resultante inclui o kit em `/kit/`. Após bootar (dependendo do seu initramfs/live),
execute:

```bash
cd /kit
./bk-install
```

## Passo 1 – Conferir o ambiente

No ambiente live:

```bash
pwd
ls
```

Verifique se o diretório do kit está presente, por exemplo:

```bash
cd 3bLinux-sysvinit-initramfs-kit-v19-update-upstream-build-modern
```

Dentro dele, você deve ver os scripts `bk`, `bk-update`, `bk-initramfs`, `init-reparo`, `bk-install`, `packages/` e `rootfs/`.

## Passo 2 – Rodar o instalador

Ainda dentro do diretório do kit, execute:

```bash
./bk-install
```

O instalador irá:

1. Verificar se você é root.
2. Listar os discos detectados (por exemplo `/dev/sda`, `/dev/nvme0n1`).
3. Pedir para você escolher:
   - **Modo 1** – Usar o disco inteiro (APAGA TUDO).
   - **Modo 2** – Usar partição existente (você já particionou manualmente).
4. Criar ou reutilizar partições:
   - Em UEFI, modo automático cria:
     - `ESP` (partição EFI) + `root` (ext4).
   - Em BIOS/Legacy, modo automático cria:
     - Uma única partição `root` (ext4).
5. Formatar as partições conforme sua escolha.

## Passo 3 – Cópia do sistema base

Depois da etapa de partições, o `bk-install` irá:

- Montar a partição raiz em `/mnt/3blinux`.
- (Se houver ESP) montar a partição EFI em `/mnt/3blinux/boot/efi`.
- Copiar o conteúdo de `rootfs/` deste kit para o novo sistema.

## Passo 4 – fstab, bk-update e init-reparo

O instalador automaticamente:

- Gera o arquivo `/etc/fstab` no sistema instalado, usando os UUIDs das partições.
- Cria `/etc/bk-update.conf` com o repositório 1.0 (canal `stable` por padrão).
- Monta `dev`, `proc`, `sys` e `run` no chroot.
- Executa `init-reparo --apply` dentro do novo sistema para validar/corrigir:
  - `/etc/fstab`
  - `/etc/inittab`
  - Estrutura de `/etc/init.d` e `/etc/rc*.d`
  - Scripts de boot essenciais

## Passo 5 – Initramfs e GRUB

Dentro do chroot, o `bk-install` tenta:

- Rodar `bk-initramfs` para gerar o initramfs padrão 3bLinux.
- Instalar o GRUB:
  - Em UEFI:
    - `grub-install --target=x86_64-efi --efi-directory=/boot/efi --bootloader-id=3bLinux`
  - Em BIOS/Legacy:
    - `grub-install --target=i386-pc <DISCO>`

Em seguida, ele tenta gerar `/boot/grub/grub.cfg` com:

```bash
grub-mkconfig -o /boot/grub/grub.cfg
```

Se algum desses passos falhar (por exemplo, se `grub-install` não estiver instalado dentro do sistema), o instalador não interrompe todo o processo, mas avisa que será necessário corrigir manualmente.

## Passo 6 – Finalização

Ao final, você verá um resumo similar a:

```text
Instalação 3bLinux 1.0 concluída.
Disco:      /dev/sda
Root:       /dev/sda2
ESP (UEFI): /dev/sda1
Root mount: /mnt/3blinux
```

Agora você pode:

1. Desmontar os sistemas de arquivos (se ainda não estiverem).
2. Remover a mídia de instalação.
3. Rebootar a máquina.

## Recuperação rápida

Se o sistema não bootar de primeira:

1. Boote novamente com a mídia de instalação.
2. Monte a partição raiz:
   ```bash
   mount /dev/sdXn /mnt
   ```
3. Execute o reparo:
   ```bash
   chroot /mnt /init-reparo --apply
   ```
4. Ajuste o GRUB se necessário:
   ```bash
   chroot /mnt grub-install /dev/sdX
   chroot /mnt grub-mkconfig -o /boot/grub/grub.cfg
   ```

Depois disso, tente bootar novamente a partir do disco.

---
Para detalhes avançados e tunning, consulte os outros arquivos em `docs/` e os scripts em `packages/` e `rootfs/etc/`.
