# Tutorial completo – Construindo sua distro 3bLinux do zero com o kit bk

Este documento explica, passo a passo, como:

- montar um ambiente de build;
- compilar os pacotes com os scripts em `packages/` usando o `bk`;
- montar um rootfs e gerar initramfs;
- gerar uma ISO de instalação com `bk-mkiso`;
- instalar em uma máquina/VM com `bk-install`;
- criar e manter um repositório (stable/testing) em um servidor caseiro;
- publicar atualizações de pacotes e atualizar suas máquinas 3bLinux.

O foco é **línea de comando**, ambiente técnico, e controle total.

---

## 1. Conceitos do kit 3bLinux + bk

Antes de começar, vale clarear os blocos principais:

- `bk` – gerenciador de pacotes:
  - cria pacotes `.bk` a partir de um diretório (`bk package`);
  - instala, remove, lista pacotes;
  - trabalha com repositório HTTP (índice `INDEX.v1`).

- `packages/` – scripts de construção:
  - cada subdiretório é um pacote (`nome-versão`);
  - dentro dele existe um `build-*.sh` que:
    - baixa o tarball upstream;
    - compila;
    - instala em um `PKG_ROOT`;
    - gera um `.bk` com `bk package`.

- `rootfs/` – sistema base:
  - contém `/etc`, `/bin`, `/sbin`, etc.;
  - inclui init SysV, scripts de boot, configs e o `init-reparo`.

- `bk-install` – instalador:
  - prepara disco/partições;
  - copia o `rootfs/`;
  - configura fstab, hostname, timezone;
  - chama `init-reparo`, `bk-initramfs` e instala GRUB.

- `tools/bk-mkiso` – gerador de ISO:
  - pega um kernel + initramfs;
  - embute o kit em `/kit/`;
  - gera ISO bootável (BIOS+UEFI) via `grub-mkrescue`.

- `tools/bk-publish-repo` (que você vai usar):
  - gera/atualiza `INDEX.v1` a partir de um diretório com pacotes `.bk`;
  - opcionalmente assina com GPG e envia via `rsync` para o servidor.

---

## 2. Ambiente de build

Você precisa de uma máquina (ou VM) de build com:

- Linux x86_64;
- compilers (gcc, g++, make);
- `curl` ou `wget`;
- `tar`, `xz`, `zstd`;
- `grub-mkrescue`, `xorriso` (para gerar ISO);
- `rsync` (para copiar o kit e publicar repositório).

Passos básicos:

```bash
mkdir -p ~/3blinux-build
cd ~/3blinux-build

# copie ou baixe o tarball do kit 1.0.2
tar -xzf 3bLinux-sysvinit-initramfs-kit-1.0.2.tar.gz
cd 3bLinux-sysvinit-initramfs-kit-v19-update-upstream-build-modern
```

Aqui você tem:

- `bk`, `bk-update`, `bk-initramfs`;
- `rootfs/`;
- `packages/`;
- `docs/`;
- `tools/`.

Recomenda-se:

```bash
export PATH="$PWD:$PATH"
```

Assim, `bk`, `bk-install`, `bk-update`, etc. ficam no seu PATH.

---

## 3. Construindo pacotes com `bk` a partir de `packages/`

Cada pacote segue o padrão:

```text
packages/<nome-versao>/
  build-<nome>-<versao>.sh
```

Exemplo para `rsync`:

```bash
cd packages/rsync-3.4.1
./build-rsync-3.4.1.sh
```

O script irá:

1. Criar um diretório de build em `/tmp/rsync-3.4.1-build`.
2. Baixar o tarball upstream.
3. Extrair e compilar.
4. Instalar em `PKG_ROOT` (diretório temporário).
5. Gerar um pacote `.bk` (ex.: `rsync-3.4.1.bk`) usando `bk package`.

Repita isso para todos os pacotes que deseja disponibilizar no repositório:

```bash
for d in packages/*; do
  if [ -x "$d"/build-*.sh ]; then
    ( cd "$d" && ./build-*.sh )
  fi
done
```

Os pacotes `.bk` normalmente ficarão em algum diretório de saída (por exemplo `pkgs/` ou o próprio diretório atual, dependendo do seu layout do `bk`).

Consulte também `packages/DEPENDENCIAS-3bLinux-1.0.2.md` para ter uma visão aproximada de dependências entre os pacotes.

---

## 4. Montando um rootfs e gerando initramfs

Há duas maneiras típicas:

1. Usar o `rootfs/` fornecido pelo kit como base, e instalar pacotes adicionais via `bk` dentro dele.
2. Construir um rootfs “limpo” em outro diretório (ex.: `chroot/`) e instalar tudo via `bk`.

### 4.1. Usando o rootfs do kit

O `rootfs/` já é um sistema mínimamente funcional, com:

- init SysV;
- `init-reparo`;
- `/etc` configurado.

Você pode, por exemplo:

```bash
# criar um rootfs de trabalho
mkdir -p ~/3bl-rootfs
cp -a rootfs/. ~/3bl-rootfs/

# entrar com chroot (como root)
sudo mount --bind /dev  ~/3bl-rootfs/dev
sudo mount --bind /proc ~/3bl-rootfs/proc
sudo mount --bind /sys  ~/3bl-rootfs/sys
sudo chroot ~/3bl-rootfs /bin/bash
```

Dentro do chroot:

```bash
# configure /etc/bk-update.conf se necessário
bk list           # ver pacotes
bk install ...    # instalar pacotes .bk do seu repositório
bk-initramfs      # gerar initramfs padrão 3bLinux
exit
```

Depois:

```bash
sudo umount ~/3bl-rootfs/dev ~/3bl-rootfs/proc ~/3bl-rootfs/sys
```

O `initramfs` gerado será usado tanto para testes quanto na ISO.

---

## 5. Gerando a ISO de instalação com `bk-mkiso`

Com kernel e initramfs prontos (podem ser do próprio rootfs ou de outro build), você usa:

```bash
./tools/bk-mkiso --kernel /boot/vmlinuz --initramfs /boot/initramfs.img --out ./3bLinux-1.0.2.iso
```

O `bk-mkiso`:

- autodetecta kernel/initramfs se você não passar `--kernel/--initramfs`;
- copia o kit para dentro da ISO em `/kit/`;
- gera `boot/grub/grub.cfg` com uma entrada de boot para o instalador;
- opcionalmente, se você passar `--make-squashfs` e tiver `mksquashfs`, gera `/live/rootfs.squashfs`.

Depois de gerar a ISO, você pode:

- testá-la em uma VM (QEMU/VirtualBox);
- gravar em pendrive (`dd` ou `cp` para `/dev/sdX` com cuidado).

---

## 6. Instalando a distro em uma máquina/VM com `bk-install`

Boot pela ISO que você criou → cairá no ambiente live (definido pelo seu initramfs/rootfs).

Dentro do ambiente live:

```bash
cd /kit
./bk-install
```

Em modo interativo, ele irá:

1. Listar discos.
2. Perguntar se usa disco inteiro ou partição existente.
3. Criar/formatar partições (em modo disco inteiro).
4. Montar o destino em `/mnt/3blinux`.
5. Copiar o `rootfs/` para o destino.
6. Gerar `/etc/fstab` com UUIDs.
7. Configurar `/etc/hostname`, `/etc/timezone`, `/etc/bk-update.conf`.
8. Fazer chroot e:
   - rodar `init-reparo --apply`;
   - rodar `bk-initramfs` (se disponível);
   - instalar GRUB (UEFI/BIOS).

Você também pode usar o modo não-interativo:

```bash
./bk-install --noninteractive --disk /dev/sda --mode whole-disk --format yes \
  --hostname meu-server --timezone America/Sao_Paulo \
  --channel stable --repo-baseurl https://meu.servidor/3bLinux/1.0
```

---

## 7. Criando um servidor caseiro para o repositório 3bLinux

A ideia é simples:

- ter um servidor (pode ser um PC velho, um Raspberry Pi, uma VM);
- instalar um servidor HTTP leve (ex.: `nginx` ou `lighttpd`);
- expor um diretório que conterá:

  ```text
  /srv/www/3bLinux/1.0/stable/
    INDEX.v1
    INDEX.v1.asc   (opcional, assinatura GPG)
    pkgs/*.bk.tar.zst

  /srv/www/3bLinux/1.0/testing/
    INDEX.v1
    INDEX.v1.asc
    pkgs/*.bk.tar.zst
  ```

Exemplo de estrutura no servidor:

```bash
sudo mkdir -p /srv/www/3bLinux/1.0/{stable,testing}/pkgs
```

No `nginx` (exemplo), você apontaria um `location` para `/srv/www`.

No lado do cliente 3bLinux, `bk-update.conf` deve apontar para:

```bash
BK_REPO_BASEURL="http://meu-servidor.local/3bLinux/1.0"
BK_REPO_CHANNEL="stable"
BK_REPO_URLS="${BK_REPO_BASEURL}/${BK_REPO_CHANNEL}"
```

---

## 8. Publicando pacotes no repositório com script (bk-publish-repo)

O fluxo recomendado:

1. Você constrói pacotes `.bk` na máquina de build.
2. Copia esses pacotes para um diretório local de repo.
3. Roda o script `tools/bk-publish-repo` (criado neste kit) para:
   - gerar/atualizar `INDEX.v1`;
   - opcionalmente assinar com GPG;
   - enviar via `rsync` para o servidor.

Exemplo (lado do builder):

```bash
mkdir -p ~/repos/3bLinux/1.0/stable/pkgs
cp *.bk ~/repos/3bLinux/1.0/stable/pkgs/

./tools/bk-publish-repo --repo-dir ~/repos/3bLinux/1.0/stable --channel stable \
  --remote user@meu-servidor.local:/srv/www/3bLinux/1.0/stable
```

Após rodar, no diretório `~/repos/3bLinux/1.0/stable` você terá:

- `INDEX.v1` (índice com metadados dos pacotes)
- `INDEX.v1.asc` (se GPG estiver configurado)
- diretório `pkgs/` com todos os `.bk`

O script cuida de:

- calcular `sha256` e tamanho dos arquivos;
- escrever um formato simples (legível) para `INDEX.v1`;
- chamar `gpg --detach-sign` se você definir `BK_REPO_SIGN_KEY`.

---

## 9. Mantendo sua distro atualizada

Depois que as máquinas 3bLinux estiverem apontadas para o seu repositório:

- para atualizar pacotes no repo:
  1. reconstruir os pacotes atualizados com os scripts em `packages/`;
  2. copiar para o diretório `pkgs/` do canal adequado (`stable` ou `testing`);
  3. rodar novamente `bk-publish-repo` para regenerar `INDEX.v1` e sincronizar.

- nos clientes 3bLinux:
  - rode `bk-update` periodicamente (pode por em cron ou `rc.local`/script próprio).

Você pode também:

- separar:
  - `testing`: onde você primeiro joga novos pacotes;
  - `stable`: onde você promove apenas o que já testou em VMs / máquinas de teste.

---

## 10. Resumo do fluxo completo

1. **Ambiente de build**: configurar toolchain + ferramentas.
2. **Construir pacotes** com `packages/*/build-*.sh`.
3. **Montar repositório**:
   - organizar `3bLinux/1.0/{stable,testing}/pkgs`;
   - rodar `tools/bk-publish-repo`.
4. **Gerar rootfs/initramfs**:
   - usar `rootfs/` + `bk-initramfs`.
5. **Gerar ISO** com `tools/bk-mkiso`.
6. **Instalar em máquina/VM** com `bk-install`.
7. **Apontar bk-update.conf** para o repositório caseiro.
8. **Manter**:
   - reconstruir pacotes quando necessário;
   - republicar com `bk-publish-repo`;
   - atualizar clientes com `bk-update`.

Seguindo esses passos, você tem uma distro 3bLinux 100% sua:
- com build a partir de código fonte;
- repositório próprio;
- controle total sobre updates e canais.
