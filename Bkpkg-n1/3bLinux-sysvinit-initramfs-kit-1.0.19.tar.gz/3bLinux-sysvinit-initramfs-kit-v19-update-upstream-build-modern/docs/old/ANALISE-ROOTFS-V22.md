# Análise da pasta rootfs (bundle v22)

## Escopo
Avaliação e correções aplicadas em `rootfs/` para garantir boot SysVinit funcional e autorreparável.

## Achados principais no v21 (antes)
1. **`rootfs/etc/init.d/init-reparo` e `init-reparo` com caractere `\` na primeira linha**
   - Isso quebra o shebang e impede execução correta.
2. **Boot em runlevel S sem montagem explícita de pseudo-filesystems**
   - `rcS` executava links em `/etc/rcS.d`, mas não assegurava `/proc`, `/sys`, `/dev/pts`, `/run`, etc.
3. **Conjunto mínimo de init scripts incompleto**
   - Não existiam scripts para: montagem de pseudo-FS, fsck básico, montagem de fstab, swap, hostname e sysctl.
4. **Automação de reparo no boot parcialmente implementada**
   - Havia integração SysV (`S01init-reparo`), mas faltavam garantias de “auto-fix” do próprio esqueleto de init.

## Correções e melhorias aplicadas no v22

### 1) Correção do shebang (bug real)
- Removido o caractere `\` da primeira linha em:
  - `init-reparo`
  - `rootfs/etc/init.d/init-reparo`

### 2) `rcS` funcional (montagens + ordem + robustez)
Atualizado `rootfs/etc/init.d/rcS` para:
- Montar pseudo-filesystems essenciais antes dos scripts (`/proc`, `/sys`, `/dev/pts`, `/run`, `/tmp`).
- Rodar scripts na ordem lexicográfica de `/etc/rcS.d/S*`.
- Tratar ausência de scripts de forma segura.

### 3) Scripts SysV adicionados em `rootfs/etc/init.d`
Incluídos scripts “mínimos necessários” para um boot coerente:
- `mountvirtfs` (monta `/proc`, `/sys`, `/dev/pts`, `/run`, `/tmp`)
- `checkfs` (fsck não-destrutivo: roda somente quando apropriado)
- `mountfs` (mount -a, evitando pseudo-fs)
- `swap` (swapon -a)
- `hostname` (aplica `/etc/hostname` se existir)
- `sysctl` (aplica `/etc/sysctl.conf` se existir)
- `urandom` (seed básico se `/var/lib/random-seed` existir)

### 4) Runlevel S atualizado (links em `rcS.d`)
Recriada a árvore `rootfs/etc/rcS.d` com ordem segura:
- `S00mountvirtfs`
- `S01init-reparo`
- `S02checkfs`
- `S03mountfs`
- `S04hwclock`
- `S05swap`
- `S06udev`
- `S10sysctl`
- `S20hostname`
- `S99local`

### 5) `init-reparo` agora repara o próprio init no boot
No `init-reparo` foi adicionado o bloco de correção do init SysV:
- `fix_init_system()` cria e/ou corrige:
  - `/etc/init.d/rcS` e `/etc/init.d/rc`
  - diretórios `/etc/rcS.d` e `/etc/rc0.d`…`/etc/rc6.d`
  - `inittab` mínimo (se ausente)
  - scripts mínimos (`mountvirtfs`, `mountfs`, `checkfs`, `swap`, `hostname`, `sysctl`, `urandom`)
  - links mínimos em `/etc/rcS.d`
- Modo `--boot` executa `fix_init_system` automaticamente.

## Resultado esperado
- Boot SysVinit funcional mesmo em cenários com arquivos ausentes/corrompidos no init.
- `init-reparo` roda em todo boot e restaura o esqueleto mínimo do init quando necessário.

## Limitações conscientes (para evitar comportamento perigoso)
- `checkfs` não força reparos agressivos em discos; roda de forma conservadora.
- Não é configurado networking, serviços adicionais (sshd, logging completo, etc.) porque dependem do conjunto de pacotes instalados e política do sistema.

