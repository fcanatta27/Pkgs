# Tutorial – Desenvolvimento de pacotes no 3bLinux (stable vs desenvolvimento)

Este tutorial explica como:

- desenvolver novas versões de pacotes no 3bLinux;
- trabalhar com versões de desenvolvimento;
- promover uma versão para estável (`stable`);
- usar canais `stable`/`testing` do repositório.

## 1. Conceito de pacote no 3bLinux

Cada pacote é descrito por um script de build:

```text
packages/<nome-versao>/
  build-<nome-versao>.sh
```

O script:

- baixa o código-fonte (tarball);
- compila;
- instala em `PKG_ROOT` (staging);
- o `bk` empacota o resultado e atualiza o repositório.

Exemplo:

```sh
tools/bk-build-wrapper ffmpeg-7.0
```

## 2. Criando uma nova versão de pacote

Suponha que você queira passar de `foo-1.0` para `foo-1.1`.

### 2.1. Passo 1: copiar a receita atual

```sh
cd packages
cp -a foo-1.0 foo-1.1
cd foo-1.1
mv build-foo-1.0.sh build-foo-1.1.sh
```

Edite o script:

- atualize variáveis:

  ```sh
  NAME="foo"
  VER="1.1"
  TARBALL_NAME="foo-1.1.tar.xz"
  URL="https://exemplo.org/foo/foo-1.1.tar.xz"
  ```

### 2.2. Ajuste de opções de build

Revise:

- flags de `./configure` ou `meson`/`cmake`;
- dependências no cabeçalho (comentário).

Inclua no começo uma lista de dependências:

```sh
# Dependências (resumo):
#   bar >= 2.0
#   baz
#   pkg-config
#   openssl (opcional)
```

Isso serve tanto como documentação quanto para você checar se o ambiente tem tudo que precisa.

### 2.3. Build em ambiente de teste

Use uma VM ou chroot:

```sh
tools/bk-build-wrapper foo-1.1
```

Verifique:

- log de build;
- se o pacote foi instalado corretamente no staging (`/tmp/foo-build/pkgroot`).

Se tudo OK, o pacote será empacotado e, dependendo da configuração, colocado em `testing`.

## 3. Canais stable/testing

O repositório 3bLinux separa:

- `stable` – apenas versões consolidadas;
- `testing` – versões novas/experimentais.

Durante desenvolvimento de pacotes:

- direcione os builds (ou a cópia de pacotes) para `testing/`.
- teste em máquinas de desenvolvimento.

### 3.1. Processo típico de promoção

1. Desenvolver e testar `foo-1.1` em `testing`.
2. Quando estiver satisfatório:

   - copiar o pacote e atualizar o índice de `stable/`.

3. Atualizar os clientes que usam canal `stable`.

## 4. Critérios para promover para estável

Antes de promover:

- o pacote compila sem erros;
- instala sem sobrescrever arquivos inesperados;
- passa em testes básicos (ex.: roda `foo --version`, `foo --help`, workflows principais);
- não quebra dependentes (ex.: se `foo` é biblioteca, teste programas que usam `foo`).

## 5. Política de versionamento

Sugestão:

- usar o versionamento original do upstream (ex.: `2.14.1`);
- adicionar `-1`, `-2` para revisões do pacote 3bLinux:

  - `foo-2.14.1-1.bk` – primeira versão empacotada;
  - `foo-2.14.1-2.bk` – correções de build/config no 3bLinux.

## 6. Desenvolvimento iterativo

Durante desenvolvimento:

- use `testing` para atualizações frequentes;
- mantenha changelog ou notas em `docs/` ou `docs/old/`;
- se quebrar o sistema, use snapshots/rollback de `bk-update`.

## 7. Ferramentas auxiliares

- `ldd` – para ver dependências de bibliotecas compartilhadas:

  ```sh
  ldd /usr/bin/foo
  ```

- `pkg-config` – para checar presença de libs:

  ```sh
  pkg-config --libs --cflags glib-2.0
  ```

- `strace` – para depurar problemas em tempo de execução.

Essas ferramentas ajudam a ajustar scripts de build (veja também o tutorial de diagnóstico).

## 8. Resumo

Fluxo de desenvolvimento:

1. Copiar uma receita existente (`packages/foo-1.0` → `foo-1.1`).
2. Atualizar script (URL, versão, flags).
3. Build em ambiente de teste (`testing`).
4. Testar funcionalmente em uma VM.
5. Promover para `stable` quando estiver maduro.
6. Atualizar documentação, se necessário.

Este processo garante que a distro mantenha um ciclo de vida claro entre **desenvolvimento** e **estabilidade**.
