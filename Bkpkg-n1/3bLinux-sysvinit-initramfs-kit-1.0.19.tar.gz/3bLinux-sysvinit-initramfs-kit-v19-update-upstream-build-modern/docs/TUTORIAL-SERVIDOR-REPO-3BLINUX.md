# Tutorial – Servidor caseiro de repositório binário 3bLinux

Este tutorial explica como:

1. montar um servidor caseiro para hospedar o repositório binário do 3bLinux;
2. configurar o 3bLinux cliente para fazer updates a partir deste servidor;
3. entender o fluxo de atualização (`bk-update`, `bk-upstream`, índices, canais stable/testing).

## 1. Conceito de repositório no 3bLinux

O repositório 3bLinux é um diretório (no disco ou via HTTP) contendo:

- pacotes binários produzidos pelos scripts em `packages/` + `bk-build-wrapper`;
- índices versionados (ex.: `INDEX.v1`, `INDEX-testing.v1`);
- metadados (datas, assinaturas, canal stable/testing, etc.).

Ferramentas:

- `bk-build-wrapper` – constrói pacotes e atualiza o repositório local.
- `bk-update` – usa o índice remoto para:
  - baixar pacotes novos;
  - aplicar updates;
  - manter histórico/rollback (snapshots).
- `bk-upstream` – gerencia origem/URL do repositório (upstream) e canais.

## 2. Estrutura de um repositório simples

Suponha um repositório em:

```text
/var/www/3blinux-repo/
```

Estrutura típica:

```text
3blinux-repo/
  stable/
    INDEX.v1
    pkg-foo-1.0-1.bk
    pkg-bar-2.0-1.bk
    ...
  testing/
    INDEX.v1
    pkg-foo-1.1-0.bk
    ...
  keys/
    repo.pub
    repo.asc
```

O servidor HTTP expõe isso em:

```text
http://meu-servidor:8080/3blinux-repo/
```

Os clientes configuram `bk-update` / `bk-upstream` para usar essa URL.

## 3. Montando o servidor caseiro

### 3.1. Escolha do servidor HTTP

Opções simples:

- `nginx`
- `lighttpd`
- `apache`
- `python3 -m http.server` (para testes)

Para uso caseiro, você pode começar com algo simples, como `nginx` ou até um script Python.

### 3.2. Exemplo com nginx

Instale nginx na máquina que será o servidor:

```sh
sudo apt install nginx   # em distros baseadas em Debian
```

Crie o diretório do repo:

```sh
sudo mkdir -p /var/www/3blinux-repo/{stable,testing,keys}
sudo chown -R $USER:$USER /var/www/3blinux-repo
```

Configure um host simples em `/etc/nginx/sites-available/3blinux-repo`:

```nginx
server {
    listen 8080;
    server_name _;

    root /var/www/3blinux-repo;
    autoindex on;
}
```

Ative:

```sh
sudo ln -s /etc/nginx/sites-available/3blinux-repo /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

Agora, o repositório estará visível em:

```text
http://<ip-do-servidor>:8080/
```

## 4. Alimentando o repositório com pacotes

No kit 3bLinux (máquina de build), configure o diretório local de saída de pacotes para apontar para:

```text
/var/www/3blinux-repo/stable
```

ou para um diretório local que depois você sincronize com o servidor (via rsync, scp, etc.).

### 4.1. Método simples – sincronizar via rsync

Suponha que os pacotes e índices sejam gerados em:

```text
/home/builder/3bl-repo-local/stable
/home/builder/3bl-repo-local/testing
```

Você pode subir para o servidor:

```sh
rsync -avz /home/builder/3bl-repo-local/stable/ \
    meuuser@meu-servidor:/var/www/3blinux-repo/stable/

rsync -avz /home/builder/3bl-repo-local/testing/ \
    meuuser@meu-servidor:/var/www/3blinux-repo/testing/
```

## 5. Configurando o 3bLinux cliente

No 3bLinux instalado, `bk-upstream` e `bk-update` usam arquivos de configuração (por exemplo, em `/etc/bk/` – o caminho exato depende da implementação).

Um exemplo conceitual de configuração:

```ini
[upstream]
stable = http://meu-servidor:8080/3blinux-repo/stable
testing = http://meu-servidor:8080/3blinux-repo/testing

[channel]
current = stable
```

Com isso:

- `bk-update` buscará `INDEX.v1` em:

  ```text
  http://meu-servidor:8080/3blinux-repo/stable/INDEX.v1
  ```

- e comparará com os pacotes instalados no sistema.

### 5.1. Mudando de canal (stable/testing)

Você pode ter um comando (ou editar o arquivo) para mudar de:

- `current = stable` → `current = testing`

Ou um script `bk-channel` que troque entre eles.

## 6. Fluxo de atualização no cliente

No cliente 3bLinux:

```sh
# atualizar lista de pacotes e aplicar updates
sudo bk-update
```

O que ele deve fazer:

1. Baixar `INDEX.v1` do canal atual.
2. Comparar versões com o que está instalado.
3. Baixar os `.bk` necessários.
4. Aplicar a atualização (instalar pacotes no rootfs).
5. Registrar um snapshot para rollback (se implementado).

### 6.1. Rollback / snapshots

O `bk-update` pode manter:

- diretórios de snapshots (ex.: `/var/lib/bk/snapshots/N/`),
- ou metadados que permitem reverter para um estado anterior.

O fluxo conceitual:

- Antes de aplicar update, cria snapshot (N).
- Se algo quebra, você chama:

  ```sh
  sudo bk-update --rollback N
  ```

## 7. Boas práticas de servidor

- Mantenha `stable` apenas com pacotes testados.
- Use `testing` para pacotes novos / experimentais.
- Assine índices e/ou pacotes com GPG:

  - mantenha `repo.pub` em `keys/`.
  - `bk-update` pode validar assinatura antes de aplicar updates.

- Use HTTPS quando possível.

## 8. Resumo

Para ter um servidor caseiro funcional:

1. Crie `/var/www/3blinux-repo/{stable,testing,keys}`.
2. Configure um servidor HTTP (ex.: nginx em porta 8080).
3. Gere pacotes e índices com o kit 3bLinux e sincronize com esse diretório.
4. No 3bLinux cliente, aponte `bk-upstream` para as URLs:
   - `http://servidor:8080/3blinux-repo/stable`
   - `http://servidor:8080/3blinux-repo/testing`
5. Use `bk-update` para atualizar, com snapshots para rollback.

Assim, você passa a ter um **repositório centralizado** de binários 3bLinux em casa, que pode servir várias máquinas.
