# Análise técnica do bundle 3bLinux 1.0.16 (projeto e prontidão desktop)

Este documento resume uma análise técnica do kit 3bLinux (bundle 1.0.16), focando em:

- estrutura do projeto (rootfs, packages, tools);
- cadeia de boot (GRUB → initramfs → sysvinit);
- desktop (Xorg, LightDM, GTK, caches/alternatives);
- repositório binário (INDEX.v1, stable/testing, publicação);
- gaps técnicos comuns e o que foi ajustado no bundle 1.0.17.

> Observação: esta análise é estática (leitura de scripts e estrutura). Testes reais dependem do ambiente (kernel/VM/hardware).

---

## 1. Layout do projeto

Diretórios principais:

- `rootfs/`: base do sistema instalado (configs em `/etc`, init scripts, skel).
- `packages/`: receitas de build por pacote (`build-*.sh`) consumidas pelo `tools/bk-build-wrapper`.
- `tools/`: utilitários do kit (build-wrapper, publish repo, mkiso, pós-instalação etc.).
- `docs/`: documentação atual; `docs/old/` contém históricos.

Pontos positivos:

- separação clara entre rootfs e recipes de build;
- wrapper de build (`bk-build-wrapper`) padroniza staging em `PKG_ROOT` e empacotamento.

---

## 2. Cadeia de boot (modo técnico)

Componentes-chave no bundle:

- `bk-initramfs`: utilitário para gerar/atualizar initramfs.
- `rootfs/etc/inittab`: define runlevels e ações.
- `rootfs/etc/init.d/*`: scripts sysvinit (dbus, udev, ntpd, lightdm, etc.)
- `bk-reparo`: utilitário de correção automática e “health check” de init/desktop.

O fluxo esperado:

1) GRUB carrega kernel + initramfs.
2) initramfs monta root real e chama `/sbin/init`.
3) sysvinit lê `/etc/inittab` e executa rc scripts.
4) runlevel 3 (texto) ou runlevel 5 (gráfico) sobe serviços conforme configurado.

---

## 3. Desktop stack (o que precisa existir no rootfs)

Para um desktop “funcional” tecnicamente, o rootfs precisa ter:

- `/etc/inittab` com runlevel gráfico e serviços:
  - dbus, alsa, ntpd, lightdm
- scripts init em `/etc/init.d/` para serviços acima
- configs de LightDM em `/etc/lightdm/`
- configs Xorg globais em `/etc/X11/` (xinitrc e eventuais xorg.conf.d)
- skeleton do usuário em `/etc/skel/`:
  - `.xinitrc`, `.Xresources`, configs GTK

No 1.0.16, o rootfs já tinha scripts de init e skel com `.xinitrc`.
No 1.0.17 foram adicionados/ajustados:

- `/etc/X11/xinit/xinitrc` (com chamada prévia a `/bk-reparo`)
- `/etc/X11/xorg.conf.d/00-keyboard.conf` (layout default “us”, editável)
- `/etc/lightdm/lightdm.conf` e `/etc/lightdm/users.conf`
- criação/garantia de diretórios comuns:
  - `/usr/share/xsessions`, `/usr/share/applications`, `/usr/share/icons`, `/usr/share/themes`, `/usr/share/fonts`

---

## 4. Repositório binário (publicação e sync)

Ferramenta existente:

- `tools/bk-publish-repo`: gera `INDEX.v1`, faz hash SHA256 por pacote e publica via rsync.
  - suporta assinatura GPG opcional via `BK_REPO_SIGN_KEY`.

Melhoria adicionada no 1.0.17:

- `tools/bk-sync-repo-server`: wrapper “end-to-end” para:
  - coletar pacotes do store local (padrão `/var/3bLinux`);
  - montar a estrutura do repo local em `<repo-root>/<release>/<channel>/pkgs/`;
  - publicar stable/testing automaticamente no servidor remoto;
  - criar diretórios remotos via ssh antes do rsync;
  - chamar `bk-publish-repo` para cada canal.

---

## 5. Bugs e riscos típicos encontrados (e mitigação)

### 5.1. Acessibilidade de ferramentas
No 1.0.16, vários utilitários `bk-*` estavam no diretório raiz do projeto, e não em `tools/`.
Isso pode confundir o uso “padrão” (tudo em `tools/`).

Mitigação no 1.0.17:
- foram adicionados wrappers em `tools/` que chamam os scripts do diretório raiz:
  - `tools/bk-update`, `tools/bk-upstream`, `tools/bk-reparo`, `tools/bk-initramfs`, `tools/bk-install`.

### 5.2. Desktop sem configs globais X11/LightDM
Mesmo com pacotes construídos, faltavam diretórios globais em `/etc` para X11/LightDM.

Mitigação no 1.0.17:
- adicionados `/etc/X11/*` e `/etc/lightdm/*`.

### 5.3. Sintaxe de shell
Foi validada sintaxe bash (`bash -n`) para scripts críticos (bk-update, upstream, reparo, install, initramfs e publish/sync repo).
Sem erros de sintaxe detectados.

---

## 6. Próximos passos técnicos (para “entregar um sistema completo”)

Mesmo com o kit bem estruturado, o “completo” depende de:

1) pipeline de build reproduzível:
   - toolchain correta
   - ordem de build definida
   - logs e checks

2) ISO e instalação:
   - `bk-mkiso` testado em QEMU
   - `bk-install` validado em disco real e em UEFI/BIOS

3) desktop:
   - garantir `.desktop` em `/usr/share/xsessions/` para openbox/fluxbox/i3/twm
   - garantir que LightDM encontra sessões
   - garantir drivers de vídeo e input (xorg-drivers + input drivers)

4) repositório:
   - política de promoção testing → stable
   - chaves e assinatura obrigatória (se for requisito)
   - snapshots e rollback (no cliente) testados

Este kit entrega a base para tudo isso; o passo final é sempre “testar em VM e consolidar defaults”.

---
