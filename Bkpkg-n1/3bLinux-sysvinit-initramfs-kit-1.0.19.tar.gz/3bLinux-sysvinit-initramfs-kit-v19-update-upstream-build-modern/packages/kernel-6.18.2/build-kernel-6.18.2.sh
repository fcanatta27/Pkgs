#!/usr/bin/env bash
\
#!/usr/bin/env bash
#
# build-kernel-6.18.2.sh
#
# Script de construção REAL do kernel Linux 6.18.2 para 3bLinux.
# Padrão de build:
#   - usa /tmp como diretório de compilação
#   - instala em PKG_ROOT via INSTALL_MOD_PATH
#   - empacota com bk em /var/3bLinux como "kernel-6.18.2"
#
set -euo pipefail

KVER="6.18.2"
KNAME="linux-${KVER}"
TARBALL_NAME="${KNAME}.tar.xz"
URL="https://cdn.kernel.org/pub/linux/kernel/v6.x/${TARBALL_NAME}"

BUILD_ROOT="/tmp/kernel-${KVER}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${KNAME}"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="kernel-${KVER}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"

die() { echo "Erro: $*" >&2; exit 1; }
info() { echo "[build-kernel-${KVER}] $*"; }

check_requirements() {
  command -v make >/dev/null 2>&1 || die "make não encontrado."
  command -v tar  >/dev/null 2>&1 || die "tar não encontrado."
  command -v xz   >/dev/null 2>&1 || die "xz não encontrado."
  command -v bk   >/dev/null 2>&1 || die "bk não encontrado."

  command -v gcc >/dev/null 2>&1 || die "gcc não encontrado."
}

prepare_dirs() {
  info "Limpando e preparando ${BUILD_ROOT}"
  rm -rf "${BUILD_ROOT}"
  mkdir -p "${BUILD_ROOT}" "${PKG_ROOT}"
}

download_kernel() {
  info "Baixando ${URL}"
  if [ -f "${TARBALL}" ]; then
    info "Tarball já existe em ${TARBALL}, reutilizando."
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L -o "${TARBALL}" "${URL}"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "${TARBALL}" "${URL}"
  else
    die "precisa de curl ou wget para baixar o kernel."
  fi
}

extract_kernel() {
  info "Extraindo kernel em ${BUILD_ROOT}"
  tar -xJf "${TARBALL}" -C "${BUILD_ROOT}"
  [ -d "${SRC_DIR}" ] || die "SRC_DIR não encontrado: ${SRC_DIR}"
}

configure_kernel() {
  info "Configurando kernel"
  cd "${SRC_DIR}"

  if [ -f "/etc/kernel-6.18.2.config" ]; then
    info "Usando /etc/kernel-6.18.2.config"
    cp /etc/kernel-6.18.2.config .config
    yes "" | make oldconfig
  else
    info "Usando defconfig generico"
    make defconfig
  fi
}

build_kernel() {
  info "Compilando kernel (JOBS=${JOBS})"
  cd "${SRC_DIR}"
  make -j"${JOBS}"
  info "Compilando módulos"
  make -j"${JOBS}" modules
}

install_into_pkgroot() {
  info "Instalando em PKG_ROOT=${PKG_ROOT}"
  cd "${SRC_DIR}"

  mkdir -p "${PKG_ROOT}/boot"
  local kimage
  kimage="arch/$(uname -m)/boot/bzImage"
  if [ -f "${kimage}" ]; then
    cp "${kimage}" "${PKG_ROOT}/boot/vmlinuz-3blinux-${KVER}"
  else
    # fallback genérico: pode variar por arquitetura
    local found
    found=$(find . -maxdepth 3 -name "bzImage" | head -n1 || true)
    [ -n "${found}" ] || die "imagem do kernel (bzImage) não encontrada."
    cp "${found}" "${PKG_ROOT}/boot/vmlinuz-3blinux-${KVER}"
  fi

  make modules_install INSTALL_MOD_PATH="${PKG_ROOT}"

  # Arquivo de release simples
  echo "3bLinux kernel ${KVER}" > "${PKG_ROOT}/boot/3blinux-${KVER}.release"
}

package_with_bk() {
  info "Empacotando com bk: ${PKG_NAME}"
  bk package "${PKG_NAME}" "${PKG_ROOT}"
  bk info "${PKG_NAME}" || true
  info "Pacote criado. Instalação típica:"
  echo "  sudo bk install ${PKG_NAME}"
}

main() {
  check_requirements
  prepare_dirs
  download_kernel
  extract_kernel
  configure_kernel
  build_kernel
  install_into_pkgroot
  package_with_bk
}

main "$@"