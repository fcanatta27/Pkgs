#!/usr/bin/env bash
set -euo pipefail

NAME="rust"
VER="1.92.0"
ARCH="${ARCH:-x86_64-unknown-linux-gnu}"
URL="https://static.rust-lang.org/dist/rust-${VER}-${ARCH}.tar.xz"
TARBALL_NAME="rust-${VER}-${ARCH}.tar.xz"

BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/usr}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[rust] ERRO: %s
' "$*" >&2; exit 1; }
info(){ printf '[rust] %s
' "$*"; }

fetch(){
  local out="$1"
  if have curl; then curl -L --fail --retry 3 -o "$out" "$URL"
  else wget -O "$out" "$URL"
  fi
}

main(){
  (have curl || have wget) || die "curl ou wget necessário"
  have tar || die "tar não encontrado"

  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"

  info "Baixando: $URL"
  fetch "${BUILD_ROOT}/${TARBALL_NAME}"
  tar -xf "${BUILD_ROOT}/${TARBALL_NAME}" -C "$SRC_DIR" --strip-components=1
  cd "$SRC_DIR"

  info "Instalando em staging"
  ./install.sh --prefix="$PREFIX" --destdir="$PKG_ROOT"

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
