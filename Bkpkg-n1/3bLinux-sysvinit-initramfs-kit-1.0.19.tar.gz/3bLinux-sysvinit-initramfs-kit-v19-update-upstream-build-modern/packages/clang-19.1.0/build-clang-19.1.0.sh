#!/usr/bin/env bash
set -euo pipefail
# clang (meta) - fornecido pelo build do LLVM (este pacote apenas padroniza o nome).
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
exec "${ROOT_DIR}/packages/llvm-19.1.0/build-llvm-19.1.0.sh" "$@"
