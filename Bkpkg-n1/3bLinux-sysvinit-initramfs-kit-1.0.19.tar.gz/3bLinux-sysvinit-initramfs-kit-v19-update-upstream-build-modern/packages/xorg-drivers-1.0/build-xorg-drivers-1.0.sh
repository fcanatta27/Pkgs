#!/usr/bin/env bash
set -euo pipefail
SCRIPT_NAME="${0##*/}"

# xorg-drivers (meta) - constrói um conjunto essencial de drivers Xorg.
# Inclui:
#  - xf86-video-fbdev
#  - xf86-video-vesa
#
# Obs: Para teclado/mouse modernos, prefira xf86-input-libinput + libinput (não incluso aqui).
#
PREFIX="${PREFIX:-/usr}"
SYSCONFDIR="${SYSCONFDIR:-/etc}"
LOCALSTATEDIR="${LOCALSTATEDIR:-/var}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[xorg-drivers] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[xorg-drivers] %s\n' "$*"; }

need(){
  have tar || die "tar nao encontrado"
  (have curl || have wget) || die "curl ou wget necessario"
  have make || die "make nao encontrado"
  (have gcc || have cc) || die "gcc/cc nao encontrado"
  have pkg-config || die "pkg-config nao encontrado"
}

fetch(){
  local url="$1" out="$2"
  if have curl; then curl -L --fail --retry 3 -o "$out" "$url"
  else wget -O "$out" "$url"
  fi
}

build_one(){
  local name="$1" ver="$2" subdir="$3"
  local tarname="${name}-${ver}.tar.xz"
  local url="https://xorg.freedesktop.org/releases/individual/${subdir}/${tarname}"
  local w="/tmp/${name}-${ver}-build"
  rm -rf "$w"
  mkdir -p "$w/src" "$w/pkg"
  info "Baixando $url"
  fetch "$url" "$w/$tarname"
  tar -xf "$w/$tarname" -C "$w/src" --strip-components=1
  pushd "$w/src" >/dev/null
  ./configure --prefix="$PREFIX" --sysconfdir="$SYSCONFDIR" --localstatedir="$LOCALSTATEDIR" --disable-static
  make
  make DESTDIR="$w/pkg" install
  cp -a "$w/pkg/"* /
  popd >/dev/null
}

main(){
  need
  build_one xf86-video-fbdev 0.5.1 driver
  build_one xf86-video-vesa 2.6.0 driver
  info "Concluido."
}
main "$@"
