#!/usr/bin/env bash
set -euo pipefail

NAME="llvm"
VER="19.1.0"

LLVM_URL="https://github.com/llvm/llvm-project/releases/download/llvmorg-19.1.0/llvm-19.1.0.src.tar.xz"
CLANG_URL="https://github.com/llvm/llvm-project/releases/download/llvmorg-19.1.0/clang-19.1.0.src.tar.xz"

# Dependências (resumo):
#  - cmake, ninja, python3
#  - gcc/cc, binutils
#  - zlib (recomendado), libxml2 (recomendado), libedit (opcional)

BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/usr}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[llvm] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[llvm] %s\n' "$*"; }

fetch(){
  local url="$1" out="$2"
  if have curl; then curl -L --fail --retry 3 -o "$out" "$url"
  else wget -O "$out" "$url"
  fi
}

main(){
  have tar || die "tar não encontrado"
  (have curl || have wget) || die "curl ou wget necessário"
  have cmake || die "cmake não encontrado"
  have python3 || die "python3 não encontrado (necessário no build do LLVM)"
  have ninja || die "ninja não encontrado (recomendado e usado aqui)"
  (have gcc || have cc) || die "gcc/cc não encontrado"

  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"

  info "Baixando LLVM"
  fetch "$LLVM_URL" "${BUILD_ROOT}/llvm.tar.xz"
  tar -xf "${BUILD_ROOT}/llvm.tar.xz" -C "$SRC_DIR" --strip-components=1

  info "Baixando Clang"
  fetch "$CLANG_URL" "${BUILD_ROOT}/clang.tar.xz"
  mkdir -p "${SRC_DIR}/tools/clang"
  tar -xf "${BUILD_ROOT}/clang.tar.xz" -C "${SRC_DIR}/tools/clang" --strip-components=1

  info "Configurando (cmake+ninja)"
  cmake -S "$SRC_DIR" -B "${BUILD_ROOT}/build" \
    -G Ninja \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX="$PREFIX" \
    -DLLVM_ENABLE_PROJECTS="clang" \
    -DLLVM_TARGETS_TO_BUILD="X86;AArch64" \
    -DLLVM_ENABLE_TERMINFO=OFF

  info "Compilando"
  ninja -C "${BUILD_ROOT}/build" -j "$JOBS"

  info "Instalando em DESTDIR: $PKG_ROOT"
  DESTDIR="$PKG_ROOT" ninja -C "${BUILD_ROOT}/build" install

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
