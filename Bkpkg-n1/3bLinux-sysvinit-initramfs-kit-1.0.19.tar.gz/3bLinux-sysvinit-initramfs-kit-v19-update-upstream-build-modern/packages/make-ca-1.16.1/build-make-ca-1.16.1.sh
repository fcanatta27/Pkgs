#!/usr/bin/env bash
#
# build-make-ca-1.16.1.sh
#
# Build real do make-ca-1.16.1 para 3bLinux (formato bk).
# Baseado em BLFS make-ca-1.16.1.
#
set -euo pipefail

VER="1.16.1"
NAME="make-ca-${VER}"
TARBALL_NAME="${NAME}.tar.gz"
URL="https://github.com/lfs-book/make-ca/archive/v${VER}/${TARBALL_NAME}"

BUILD_ROOT="/tmp/make-ca-${VER}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="make-ca-${VER}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 1)}"

die() { echo "[build-make-ca-${VER}] Erro: $*" >&2; exit 1; }
info() { echo "[build-make-ca-${VER}] $*"; }

check_requirements() {
  command -v tar  >/dev/null 2>&1 || die "tar não encontrado."
  command -v gzip >/dev/null 2>&1 || die "gzip não encontrado."
  command -v make >/dev/null 2>&1 || die "make não encontrado."
  command -v bk   >/dev/null 2>&1 || die "bk não encontrado."
}

prepare_dirs() {
  info "Preparando diretórios em ${BUILD_ROOT}"
  rm -rf "${BUILD_ROOT}"
  mkdir -p "${BUILD_ROOT}" "${PKG_ROOT}"
}

download_source() {
  info "Baixando ${URL}"
  if [ -f "${TARBALL}" ]; then
    info "Tarball já presente, reutilizando."
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -L -o "${TARBALL}" "${URL}"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "${TARBALL}" "${URL}"
  else
    die "precisa de curl ou wget."
  fi
}

extract_source() {
  info "Extraindo fonte ${TARBALL_NAME}"
  tar -xzf "${TARBALL}" -C "${BUILD_ROOT}"
  [ -d "${SRC_DIR}" ] || die "SRC_DIR não encontrado: ${SRC_DIR}"
}

install_script() {
  info "Instalando make-ca em PKG_ROOT=${PKG_ROOT}"
  cd "${SRC_DIR}"
  # O Makefile já instala o script em /usr/sbin/make-ca e arquivos auxiliares.
  make DESTDIR="${PKG_ROOT}" install

  # Diretório para certificados locais, conforme BLFS.
  install -vdm755 "${PKG_ROOT}/etc/ssl/local"
}

create_docs_and_cron() {
  mkdir -p "${PKG_ROOT}/usr/share/doc/${PKG_NAME}" "${PKG_ROOT}/etc/cron.weekly"
  cat > "${PKG_ROOT}/usr/share/doc/${PKG_NAME}/README.make-ca" << 'DOC'
O make-ca é responsável por gerar e manter o store de certificados do sistema.

Após instalar o pacote com "bk install make-ca-1.16.1", execute como root:

  /usr/sbin/make-ca -g

para gerar os stores iniciais em /etc/ssl e /etc/pki.

Opcionalmente, configure uma tarefa semanal (exemplo em /etc/cron.weekly/update-pki.sh):

  #!/bin/bash
  /usr/sbin/make-ca -g
DOC

  cat > "${PKG_ROOT}/etc/cron.weekly/update-pki.sh" << 'EOFCRON'
#!/bin/bash
/usr/sbin/make-ca -g
EOFCRON
  chmod 754 "${PKG_ROOT}/etc/cron.weekly/update-pki.sh"
}

package_with_bk() {
  info "Empacotando com bk: ${PKG_NAME}"
  bk package "${PKG_NAME}" "${PKG_ROOT}"
  bk info "${PKG_NAME}" || true
  info "Instale com: sudo bk install ${PKG_NAME}"
}

main() {
  check_requirements
  prepare_dirs
  download_source
  extract_source
  install_script
  create_docs_and_cron
  package_with_bk
}

main "$@"
