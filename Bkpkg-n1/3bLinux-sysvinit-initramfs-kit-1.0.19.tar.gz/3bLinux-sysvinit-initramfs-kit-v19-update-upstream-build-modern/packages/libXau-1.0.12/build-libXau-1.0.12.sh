#!/usr/bin/env bash
set -euo pipefail

NAME="libXau-1.0.12"
VER="1.0.12"
TARBALL_NAME="libXau-1.0.12.tar.xz"
URL="https://xorg.freedesktop.org/archive/individual/lib/libXau-1.0.12.tar.xz"

SCRIPT_NAME="${0##*/}"
BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkg"

# Dependências principais (sugestão):
# xorgproto; util-macros; pkg-config

# Prefix alvo (raiz do sistema em build chroot):
PREFIX="${PREFIX:-/usr}"
SYSCONFDIR="${SYSCONFDIR:-/etc}"
LOCALSTATEDIR="${LOCALSTATEDIR:-/var}"

color(){ local c="$1"; shift; case "$c" in red) printf '\033[1;31m%s\033[0m\n' "$*";; yellow) printf '\033[1;33m%s\033[0m\n' "$*";; blue) printf '\033[1;34m%s\033[0m\n' "$*";; *) printf '%s\n' "$*";; esac; }
info(){ color blue "[bk] $*"; }
warn(){ color yellow "[bk] AVISO: $*"; }
die(){ color red "[bk] ERRO: $*"; exit 1; }

have(){ command -v "$1" >/dev/null 2>&1; }

need_tools() {
  have tar || die "tar não encontrado"
  (have curl || have wget) || die "curl ou wget é necessário para download"
  have make || die "make não encontrado"
  (have gcc || have cc) || die "compiler (gcc/cc) não encontrado"
  have pkg-config || warn "pkg-config não encontrado (alguns pacotes podem falhar)"
}

fetch() {
  local out="$1"
  info "Baixando: $URL"
  if have curl; then
    curl -L --fail --retry 3 --retry-delay 1 -o "$out" "$URL"
  else
    wget -O "$out" "$URL"
  fi
}

extract_src() {
  local tarball="$1"
  info "Extraindo: $tarball"
  rm -rf "$SRC_DIR"
  mkdir -p "$SRC_DIR"
  tar -xf "$tarball" -C "$SRC_DIR" --strip-components=1
}

prepare() {
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT"
}

do_install_root() {
  info "Instalando em DESTDIR: $PKG_ROOT"
}

finalize() {
  info "Instalado em: $PKG_ROOT"
  info "Dica: se o seu bk tiver um empacotador, aponte-o para: $PKG_ROOT"
}

main() {
  need_tools
  prepare
  local tarball="${BUILD_ROOT}/${TARBALL_NAME}"
  fetch "$tarball"
  extract_src "$tarball"
  cd "$SRC_DIR"

  info "Configurando (autotools)"
  ./configure \
    --prefix="$PREFIX" \
    --sysconfdir="$SYSCONFDIR" \
    --localstatedir="$LOCALSTATEDIR" \

  info "Compilando"
  make 
  do_install_root
  make DESTDIR="$PKG_ROOT" install

  finalize
}

main "$@"
