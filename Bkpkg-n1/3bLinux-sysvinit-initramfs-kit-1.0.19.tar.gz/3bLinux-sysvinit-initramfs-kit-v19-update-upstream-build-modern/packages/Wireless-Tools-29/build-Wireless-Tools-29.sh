#!/usr/bin/env bash
set -euo pipefail

NAME="wireless_tools"
VER="29"
URL="https://hewlettpackard.github.io/wireless-tools/wireless_tools.29.tar.gz"
TARBALL_NAME="wireless_tools.29.tar.gz"

# Dependências:
#  - kernel headers; libc
#  - make; gcc/cc

BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/usr}"
SYSCONFDIR="${SYSCONFDIR:-/etc}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[wireless_tools] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[wireless_tools] %s\n' "$*"; }

fetch(){
  local out="$1"
  if have curl; then curl -L --fail --retry 3 -o "$out" "$URL"
  else wget -O "$out" "$URL"
  fi
}

main(){
  have tar || die "tar não encontrado"
  (have curl || have wget) || die "curl ou wget necessário"
  have make || die "make não encontrado"
  (have gcc || have cc) || die "gcc/cc não encontrado"

  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"
  fetch "${BUILD_ROOT}/${TARBALL_NAME}"
  tar -xf "${BUILD_ROOT}/${TARBALL_NAME}" -C "$SRC_DIR" --strip-components=1
  cd "$SRC_DIR"

  # Alguns sistemas precisam de ajustes em CFLAGS. Mantemos padrão.
  info "Compilando"
  make -j"$JOBS"

  info "Instalando em DESTDIR: $PKG_ROOT"
  make DESTDIR="$PKG_ROOT" PREFIX="$PREFIX" install

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
