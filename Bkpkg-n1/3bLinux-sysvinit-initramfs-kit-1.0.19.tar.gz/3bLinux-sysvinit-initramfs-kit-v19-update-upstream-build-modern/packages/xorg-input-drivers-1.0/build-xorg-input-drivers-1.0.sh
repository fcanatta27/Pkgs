#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
for p in xf86-input-libinput-1.6.0 xf86-input-evdev-2.10.6; do
  "${ROOT_DIR}/tools/bk-build-wrapper" "$p"
done
