#!/usr/bin/env bash
set -euo pipefail

NAME="firefox-bin"
VER="${VER:-128.8.0esr}"
LOCALE="${LOCALE:-pt-BR}"
ARCH="${ARCH:-linux-x86_64}"

BASE_URL="https://ftp.mozilla.org/pub/firefox/releases/${VER}/${ARCH}/${LOCALE}/firefox-${VER}.tar.bz2"

# Dependências (runtime):
#  - glibc, libstdc++, gtk3 stack, dbus, alsa (dependendo do uso), mesa/opengl
#  - fontes (ex. noto-fonts)

BUILD_ROOT="/tmp/${NAME}-build"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/opt}"
INSTALL_DIR="${INSTALL_DIR:-${PREFIX}/firefox}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[firefox-bin] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[firefox-bin] %s\n' "$*"; }

fetch(){
  local out="$1"
  if have curl; then curl -L --fail --retry 3 -o "$out" "$BASE_URL"
  else wget -O "$out" "$BASE_URL"
  fi
}

main(){
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT"

  (have curl || have wget) || die "curl ou wget necessário"
  have tar || die "tar não encontrado"

  info "Baixando: $BASE_URL"
  fetch "${BUILD_ROOT}/firefox.tar.bz2"

  info "Extraindo"
  mkdir -p "${BUILD_ROOT}/src"
  tar -xjf "${BUILD_ROOT}/firefox.tar.bz2" -C "${BUILD_ROOT}/src"

  info "Instalando em staging"
  mkdir -p "${PKG_ROOT}${INSTALL_DIR%/*}"
  rm -rf "${PKG_ROOT}${INSTALL_DIR}"
  mv "${BUILD_ROOT}/src/firefox" "${PKG_ROOT}${INSTALL_DIR}"

  # wrapper em /usr/bin para facilitar
  mkdir -p "${PKG_ROOT}/usr/bin"
  cat > "${PKG_ROOT}/usr/bin/firefox" <<EOF
#!/usr/bin/env sh
exec "${INSTALL_DIR}/firefox" "\$@"
EOF
  chmod 0755 "${PKG_ROOT}/usr/bin/firefox"

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
