#!/usr/bin/env bash
set -euo pipefail

NAME="ffmpeg"
VER="7.0"

URL="https://ffmpeg.org/releases/ffmpeg-${VER}.tar.xz"
TARBALL_NAME="ffmpeg-${VER}.tar.xz"

BUILD_ROOT="/tmp/${NAME}-build"
SRC_DIR="${BUILD_ROOT}/src"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

PREFIX="${PREFIX:-/usr}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[ffmpeg] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[ffmpeg] %s\n' "$*"; }

fetch(){
  local out="$1"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 -o "$out" "$URL"
  else
    wget -O "$out" "$URL"
  fi
}

main(){
  (have curl || have wget) || die "curl ou wget necessário"
  command -v tar >/dev/null 2>&1 || die "tar não encontrado"
  command -v make >/dev/null 2>&1 || die "make não encontrado"
  (command -v gcc >/dev/null 2>&1 || command -v cc >/dev/null 2>&1) || die "gcc/cc não encontrado"

  rm -rf "$BUILD_ROOT"
  mkdir -p "$SRC_DIR" "$PKG_ROOT"

  info "Baixando: $URL"
  fetch "${BUILD_ROOT}/${TARBALL_NAME}"
  tar -xf "${BUILD_ROOT}/${TARBALL_NAME}" -C "$SRC_DIR" --strip-components=1
  cd "$SRC_DIR"

  info "Configurando"
  ./configure     --prefix="$PREFIX"     --enable-gpl     --enable-version3     --enable-shared     --disable-static     --enable-libx264     --enable-libx265     --enable-libmp3lame     --enable-libass || die "configure falhou"

  info "Compilando"
  make -j"$JOBS"

  info "Instalando em staging"
  make DESTDIR="$PKG_ROOT" install

  info "Staging pronto: $PKG_ROOT (use tools/bk-build-wrapper para empacotar via bk)"
}
main "$@"
