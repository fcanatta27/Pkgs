#!/usr/bin/env bash
set -euo pipefail

# 3blinux-workstation - meta pacote para construir o perfil workstation 1.0
# Este script NÃO constrói nada direto, apenas orquestra chamadas ao bk-build-wrapper
# em uma ordem razoável de dependências.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
BK="${ROOT_DIR}/tools/bk-build-wrapper"

run() {
  echo "[3blinux-workstation] >>> $*"
  "$BK" "$@"
}

echo "[3blinux-workstation] Iniciando build do perfil workstation..."

# 1) Base Xorg
run xorg-server || true
run xorg-drivers || true
run xorg-fonts || true
run xbitmaps-1.1.3 || true
run xorg-input-drivers-1.0 || true
run xcb-utilities-1.0 || true
run xorg-applications-1.0 || true
run xinit || true
run xterm || true
run twm || true
run xclock-1.1.1 || true

# 2) OpenGL / Mesa
run libdrm-2.4.125 || true
run libxshmfence-1.3.3 || true
run glu-9.0.3 || true
run wayland-1.23.0 || true
run wayland-protocols-1.40 || true
run Mesa-25.3.1 || true

# 3) Toolkits GTK / libs GUI
run glib-2.86.3 || true
run cairo-1.18.2 || true
run harfbuzz-10.4.0 || true
run fribidi-1.0.16 || true
run pango-1.57.0 || true
run gdk-pixbuf-2.44.4 || true
run atk-2.38.0 || true
run at-spi2-core-2.58.3 || true
run libepoxy-1.5.10 || true
run gtk2-2.24.33 || true
run gtk3-3.24.51 || true
run GTK-4.20.3 || true
run Gtkmm-3.24.10 || true
run Gtkmm-4.20.0 || true
run libnotify-0.8.8 || true
run startup-notification-0.12 || true
run libcanberra-0.30 || true

# 4) Web / browser
run firefox-bin-128.8.0esr || true
run WebKitGTK-2.50.4 || true

# 5) Áudio (ALSA) + GStreamer
run alsa-lib-1.2.15.3 || true
run alsa-utils-1.2.15.2 || true
run alsa-tools-1.2.15 || true
run alsa-firmware-1.2.4 || true

run gstreamer-1.26.10 || true
run gst-plugins-base-1.26.10 || true
run gst-plugins-good-1.26.10 || true
run gst-plugins-bad-1.26.10 || true
run gst-plugins-ugly-1.26.10 || true
run gst-libav-1.26.10 || true
run LAME-3.100 || true
run mpg123-1.33.4 || true

# 6) Vídeo / codecs / player
run x264-20250815 || true
run x265-4.1 || true
run libass-0.17.4 || true
run ffmpeg-7.0 || true
run mpv-0.41.0 || true
run dvd+rw-tools-7.1 || true
run SDL3-3.4.0 || true

# 7) Fonts / ícones / tema
run dejavu-fonts-2.37 || true
run liberation-fonts-2.1.5 || true
run Hack-fonts-3.003 || true
run nerd-fonts-3.3.0 || true
run awesome-fonts-6.5.2 || true
run Adwaita-fonts-0.303 || true
run adwaita-icon-theme-49.0 || true
run adwaita-theme-1.0 || true

# 8) Sessão gráfica / WMs / utilitários
run lightdm-1.32.0 || true
run openbox-3.6.1 || true
run Fluxbox-1.3.7 || true
run i3-4.23 || true
run feh-3.11.2 || true
run rxvt-unicode-9.31 || true
run xdg-utils-1.2.1 || true

echo "[3blinux-workstation] Build do perfil workstation concluído (verifique erros acima, se houver)."
