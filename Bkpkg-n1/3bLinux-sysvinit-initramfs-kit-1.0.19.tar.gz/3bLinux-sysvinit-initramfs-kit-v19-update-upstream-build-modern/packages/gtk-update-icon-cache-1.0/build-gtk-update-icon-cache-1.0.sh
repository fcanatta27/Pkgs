#!/usr/bin/env bash
set -euo pipefail

# Este pacote é um meta-helper para garantir que a ferramenta gtk-update-icon-cache
# (fornecida pelos pacotes GTK) esteja disponível no sistema via bk.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

# Tentamos garantir gtk3 e gtk4 instalados via bk
"${ROOT_DIR}/tools/bk-build-wrapper" gtk3-3.24.51 || true
"${ROOT_DIR}/tools/bk-build-wrapper" GTK-4.20.3 || true

if command -v gtk-update-icon-cache >/dev/null 2>&1; then
  echo "[gtk-update-icon-cache] gtk-update-icon-cache já está disponível no sistema."
else
  echo "[gtk-update-icon-cache] AVISO: gtk-update-icon-cache não foi encontrado após build de GTK."
fi

echo "[gtk-update-icon-cache] Nada para instalar diretamente; este pacote é apenas um meta-helper."
