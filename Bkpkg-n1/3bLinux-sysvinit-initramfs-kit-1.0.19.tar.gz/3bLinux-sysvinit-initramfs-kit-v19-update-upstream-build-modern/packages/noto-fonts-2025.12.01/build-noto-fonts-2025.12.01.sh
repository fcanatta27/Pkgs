#!/usr/bin/env bash
set -euo pipefail
#
# build-noto-fonts-2025.12.01.sh
#
# Instala Noto Fonts (TTF variável) a partir da release mensal do projeto notofonts.
# Fonte: tag noto-monthly-release-2025.12.01 (GitHub).
#
# Nota: o tarball do GitHub é muito grande. Este script instala um subconjunto razoável:
#  - full/variable-ttf/*.ttf  (quando presente)
#
# Dependências: tar, gzip/xz, curl/wget, fontconfig (opcional p/ fc-cache).
#
VER="2025.12.01"
TAG="noto-monthly-release-${VER}"
URL="https://github.com/notofonts/notofonts.github.io/archive/refs/tags/${TAG}.tar.gz"

PREFIX="${PREFIX:-/usr}"
DESTDIR="${DESTDIR:-/}"
FONTDIR="${FONTDIR:-${PREFIX}/share/fonts/noto}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[noto-fonts] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[noto-fonts] %s\n' "$*"; }

fetch(){
  local out="$1"
  if have curl; then curl -L --fail --retry 3 -o "$out" "$URL"
  else wget -O "$out" "$URL"
  fi
}

main(){
  have tar || die "tar nao encontrado"
  (have curl || have wget) || die "curl ou wget necessario"

  local w="/tmp/noto-fonts-${VER}-build"
  rm -rf "$w"
  mkdir -p "$w/src"
  info "Baixando ${URL}"
  fetch "$w/src.tgz"
  tar -xf "$w/src.tgz" -C "$w/src" --strip-components=1

  local src=""
  if [ -d "$w/src/full/variable-ttf" ]; then
    src="$w/src/full/variable-ttf"
  elif [ -d "$w/src/full/ttf" ]; then
    src="$w/src/full/ttf"
  else
    src="$(find "$w/src" -maxdepth 4 -type d \( -name 'variable-ttf' -o -name 'ttf' \) | head -n1 || true)"
  fi
  [ -n "$src" ] || die "nao achei pasta de fontes TTF dentro do tarball"

  info "Instalando fontes em: ${DESTDIR%/}${FONTDIR}"
  mkdir -p "${DESTDIR%/}${FONTDIR}"
  find "$src" -type f -name '*.ttf' -print0 | xargs -0 -I{} install -m 0644 "{}" "${DESTDIR%/}${FONTDIR}/"

  if have fc-cache; then
    info "Atualizando cache de fontes (fc-cache -f)"
    fc-cache -f || true
  else
    info "fc-cache nao encontrado (ok)."
  fi
  info "Concluido."
}
main "$@"
