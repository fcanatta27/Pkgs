#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
for p in xclock-1.1.1 xterm-406; do
  "${ROOT_DIR}/tools/bk-build-wrapper" "$p"
done
