#!/usr/bin/env bash
set -euo pipefail
# gtk (meta) - alias para gtk3
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
exec "${ROOT_DIR}/packages/gtk3-3.24.51/build-gtk3-3.24.51.sh" "$@"
