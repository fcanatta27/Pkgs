#!/usr/bin/env bash
#
# build-expat-2.6.2.sh
#
# Build real do expat 2.6.2 (libexpat) para 3bLinux, padrão bk.
# Dependência típica: dbus, bibliotecas que precisam de XML.
#
set -euo pipefail

VER="2.6.2"
NAME="expat-${VER}"
TARBALL_NAME="${NAME}.tar.xz"
URL="https://github.com/libexpat/libexpat/releases/download/R_2_6_2/${TARBALL_NAME}"

BUILD_ROOT="/tmp/${NAME}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"

PKG_NAME="${NAME}.bk"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"

info()  { printf "[build-expat] %s\n" "$*"; }
die()   { printf "[build-expat] ERRO: %s\n" "$*" >&2; exit 1; }

have() { command -v "$1" >/dev/null 2>&1; }

check_requirements() {
  have bk || die "bk não encontrado no PATH."
  have tar || die "tar não encontrado."
  have curl || have wget || die "curl ou wget é necessário para download."
  have make || die "make não encontrado."
  have gcc || have cc || die "compiler (gcc/cc) não encontrado."
}

prepare_dirs() {
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT"
}

download_source() {
  info "Baixando: $URL"
  if have curl; then
    curl -L --fail --retry 3 -o "$TARBALL" "$URL"
  else
    wget -O "$TARBALL" "$URL"
  fi
  [ -s "$TARBALL" ] || die "Download falhou: $TARBALL"
}

extract_source() {
  info "Extraindo: $TARBALL_NAME"
  cd "$BUILD_ROOT"
  tar -xJf "$TARBALL"
  [ -d "$SRC_DIR" ] || die "Diretório fonte não encontrado: $SRC_DIR"
}

configure_build() {
  info "Configurando"
  cd "$SRC_DIR"
  ./configure --prefix=/usr --disable-static
}

build_pkg() {
  info "Compilando (JOBS=$JOBS)"
  cd "$SRC_DIR"
  make -j"$JOBS"
}

install_into_pkgroot() {
  info "Instalando em PKG_ROOT=$PKG_ROOT"
  cd "$SRC_DIR"
  make DESTDIR="$PKG_ROOT" install

  # Ajustes comuns de doc
  install -vd "$PKG_ROOT/usr/share/doc/${NAME}"
  cp -v README* doc/* "$PKG_ROOT/usr/share/doc/${NAME}" 2>/dev/null || true
}

package_with_bk() {
  info "Empacotando com bk: $PKG_NAME"
  bk package "$PKG_NAME" "$PKG_ROOT"
  bk info "$PKG_NAME" || true
  info "Instale com: sudo bk install $PKG_NAME"
}

main() {
  check_requirements
  prepare_dirs
  download_source
  extract_source
  configure_build
  build_pkg
  install_into_pkgroot
  package_with_bk
}

main "$@"
