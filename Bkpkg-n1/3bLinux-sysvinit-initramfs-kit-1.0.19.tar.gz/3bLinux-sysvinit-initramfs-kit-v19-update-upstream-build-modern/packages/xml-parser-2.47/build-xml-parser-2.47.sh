#!/usr/bin/env bash
#
# build-xml-parser-2.47.sh
#
# Módulo Perl XML::Parser 2.47 para 3bLinux, padrão bk.
#
set -euo pipefail

VER="2.47"
NAME="XML-Parser-${VER}"
TARBALL_NAME="${NAME}.tar.gz"
URL="https://cpan.metacpan.org/authors/id/T/TO/TODDR/${TARBALL_NAME}"

BUILD_ROOT="/tmp/xml-parser-${VER}-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"
PKG_ROOT="${BUILD_ROOT}/pkg-root"

PKG_NAME="perl-xml-parser-${VER}"

die(){ echo "Erro: $*" >&2; exit 1; }
info(){ echo "[build-xml-parser] $*"; }

check_requirements(){
  for p in perl make tar gzip bk; do
    command -v "$p" >/dev/null 2>&1 || die "$p não encontrado."
  done
}

prepare_dirs(){
  info "Preparando $BUILD_ROOT"
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT"
}

download_source(){
  info "Baixando $URL"
  if [ -f "$TARBALL" ]; then info "Tarball já presente."; return; fi
  if command -v curl >/dev/null 2>&1; then curl -L -o "$TARBALL" "$URL"
  elif command -v wget >/dev/null 2>&1; then wget -O "$TARBALL" "$URL"
  else die "precisa de curl ou wget."; fi
}

extract_source(){
  info "Extraindo fonte"
  tar -xzf "$TARBALL" -C "$BUILD_ROOT"
  [ -d "$SRC_DIR" ] || die "SRC_DIR não encontrado: $SRC_DIR"
}

build_xmlparser(){
  info "Executando perl Makefile.PL"
  cd "$SRC_DIR"
  perl Makefile.PL \
    PREFIX=/usr \
    INSTALLDIRS=vendor || die "Makefile.PL falhou."

  make
}

install_into_pkgroot(){
  info "Instalando em PKG_ROOT=$PKG_ROOT"
  cd "$SRC_DIR"
  make DESTDIR="$PKG_ROOT" install
}

package_with_bk(){
  info "Empacotando com bk: $PKG_NAME"
  bk package "$PKG_NAME" "$PKG_ROOT"
  bk info "$PKG_NAME" || true
}

main(){
  check_requirements
  prepare_dirs
  download_source
  extract_source
  build_xmlparser
  install_into_pkgroot
  package_with_bk
}
main "$@"
