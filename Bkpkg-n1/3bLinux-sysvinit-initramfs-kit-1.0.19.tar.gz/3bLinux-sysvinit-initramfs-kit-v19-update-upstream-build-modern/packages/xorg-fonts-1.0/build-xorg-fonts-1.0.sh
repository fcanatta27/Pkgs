#!/usr/bin/env bash
set -euo pipefail
SCRIPT_NAME="${0##*/}"

# xorg-fonts (meta) - instala um conjunto minimo e funcional de fontes bitmap do Xorg.
# Lista (pode ajustar):
#  - encodings
#  - font-util
#  - font-alias
#  - font-misc-misc
#  - font-cursor-misc
#
# Fontes no Xorg: https://www.x.org/releases/individual/font/  (também existe /archive/)
#
# Dependências:
#  - xorgproto, util-macros, pkg-config
#  - mkfontscale/mkfontdir (font-util instala), bdftopcf (opcional) e gzip/bzip2/xz
#
PREFIX="${PREFIX:-/usr}"
SYSCONFDIR="${SYSCONFDIR:-/etc}"
LOCALSTATEDIR="${LOCALSTATEDIR:-/var}"

have(){ command -v "$1" >/dev/null 2>&1; }
die(){ printf '[xorg-fonts] ERRO: %s\n' "$*" >&2; exit 1; }
info(){ printf '[xorg-fonts] %s\n' "$*"; }

need(){
  have tar || die "tar nao encontrado"
  (have curl || have wget) || die "curl ou wget necessario"
  have make || die "make nao encontrado"
  (have gcc || have cc) || die "gcc/cc nao encontrado"
  have pkg-config || die "pkg-config nao encontrado"
}

fetch(){
  local url="$1" out="$2"
  if have curl; then curl -L --fail --retry 3 -o "$out" "$url"
  else wget -O "$out" "$url"
  fi
}

build_one(){
  local name="$1" ver="$2" base="$3"
  local tarname="${name}-${ver}.tar.xz"
  local url="${base}/${tarname}"
  local w="/tmp/${name}-${ver}-build"
  rm -rf "$w"
  mkdir -p "$w/src" "$w/pkg"
  info "Baixando $url"
  fetch "$url" "$w/$tarname"
  tar -xf "$w/$tarname" -C "$w/src" --strip-components=1
  pushd "$w/src" >/dev/null
  ./configure --prefix="$PREFIX" --sysconfdir="$SYSCONFDIR" --localstatedir="$LOCALSTATEDIR" --disable-static
  make
  make DESTDIR="$w/pkg" install
  cp -a "$w/pkg/"* /
  popd >/dev/null
}

main(){
  need
  local BASE="https://xorg.freedesktop.org/releases/individual/font"
  build_one encodings 1.1.0 "$BASE"
  build_one font-util 1.4.1 "$BASE"
  build_one font-alias 1.0.5 "$BASE"
  build_one font-misc-misc 1.1.3 "$BASE"
  build_one font-cursor-misc 1.0.4 "$BASE"
  info "Concluido. Atualize cache de fontes (fontconfig) se aplicavel."
}
main "$@"
