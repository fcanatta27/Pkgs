#!/usr/bin/env bash
#
# build-parted-3.6.sh
#
# Build real do parted 3.6 para 3bLinux, padrão bk.
# Requer libs de suporte (libuuid, readline, etc.) conforme ambiente.

set -euo pipefail

VER="3.6"
NAME="parted-3.6"
TARBALL_NAME="parted-3.6.tar.xz"
URL="https://ftp.gnu.org/gnu/parted/parted-3.6.tar.xz"

BUILD_ROOT="/tmp/parted-3.6-build"
TARBALL="${BUILD_ROOT}/${TARBALL_NAME}"
SRC_DIR="${BUILD_ROOT}/${NAME}"

PKG_NAME="parted-3.6.bk"
PKG_ROOT="${BUILD_ROOT}/pkgroot"

JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"
FETCH="${FETCH:-curl -L --fail --retry 3 -o}"



info()  { printf "[build-parted] %s\n" "$*"; }
die()   { printf "[build-parted] ERRO: %s\n" "$*" >&2; exit 1; }

have() { command -v "$1" >/dev/null 2>&1; }

check_requirements() {
  have bk || die "bk não encontrado no PATH."
  have tar || die "tar não encontrado."
  have ${FETCH%% *} || true
  have curl || have wget || die "curl ou wget é necessário para download."
  have make || die "make não encontrado."
  have gcc || have cc || die "compiler (gcc/cc) não encontrado."
}

prepare_dirs() {
  rm -rf "$BUILD_ROOT"
  mkdir -p "$BUILD_ROOT" "$PKG_ROOT"
}

download_source() {
  info "Baixando: $URL"
  if have curl; then
    curl -L --fail --retry 3 -o "$TARBALL" "$URL"
  else
    wget -O "$TARBALL" "$URL"
  fi
  [ -s "$TARBALL" ] || die "Download falhou: $TARBALL"
}

extract_source() {
  info "Extraindo: $TARBALL_NAME"
  cd "$BUILD_ROOT"
  case "$TARBALL_NAME" in
    *.tar.gz|*.tgz)  tar -xzf "$TARBALL" ;;
    *.tar.xz)        tar -xJf "$TARBALL" ;;
    *.tar.bz2)       tar -xjf "$TARBALL" ;;
    *.tar.zst)       tar --zstd -xf "$TARBALL" ;;
    *) die "Formato de tarball não suportado: $TARBALL_NAME" ;;
  esac
  [ -d "$SRC_DIR" ] || die "Diretório fonte não encontrado: $SRC_DIR"
}

configure_build() {
  info "Configurando"
  cd "$SRC_DIR"
  ./configure --prefix=/usr --disable-static
}

build_pkg() {
  info "Compilando (JOBS=$JOBS)"
  cd "$SRC_DIR"
  make -j"$JOBS"
}

install_into_pkgroot() {
  info "Instalando em PKG_ROOT=$PKG_ROOT"
  cd "$SRC_DIR"
  make DESTDIR="$PKG_ROOT" install
}

package_with_bk() {
  info "Empacotando com bk: $PKG_NAME"
  bk package "$PKG_NAME" "$PKG_ROOT"
  bk info "$PKG_NAME" || true
  info "Instale com: sudo bk install $PKG_NAME"
}

main() {
  check_requirements
  prepare_dirs
  download_source
  extract_source
  configure_build
  build_pkg
  install_into_pkgroot
  package_with_bk
}

main "$@"
