# 3bLinux – Kit de construção de distro (1.0.19)

O **3bLinux** é um kit de construção de sistema baseado em Linux com foco em:

- boot clássico com **sysvinit** + **initramfs** enxuto;
- conjunto de ferramentas `bk-*` para:
  - compilar, empacotar e versionar programas;
  - montar um **repositório binário** próprio;
  - atualizar o sistema via `bk-update`;
- **rootfs** mínimo, limpo e legível, pensado para estudo, personalização e produção;
- suporte a perfil **workstation** (Xorg, LightDM, GTK, WebKitGTK, áudio, fontes, WMs, temas, etc.).

Este repositório não é apenas uma distro pronta – é um **kit de construção** para você:

- entender todos os componentes;
- montar seu próprio sistema;
- manter atualizações e releases estáveis;
- rodar um servidor de repositório para múltiplas máquinas 3bLinux.

## Estrutura geral do kit

Principais diretórios:

- `rootfs/`  
  Sistema de arquivos raiz do 3bLinux:
  - `/etc` – configs de sistema (inittab, fstab, profile, bash, serviços, etc.);
  - `/bin`, `/sbin`, `/usr/*` – ferramentas básicas;
  - scripts de init e integração com initramfs.

- `packages/`  
  Scripts de construção (`build-*.sh`) organizados por pacote, no padrão do `bk-build-wrapper`:
  - criam staging em `/tmp/<nome>-build/pkgroot`;
  - depois são empacotados pelo `bk`.

- `tools/`  
  Ferramentas principais do kit, incluindo:
  - `bk-build-wrapper` – envoltório para criar pacotes a partir de `packages/`;
  - `bk-update`, `bk-upstream` – atualização e gerenciamento de repositório;
- `tools/bk-sync-repo-server` – sincroniza/publica repositório (stable/testing) para servidor via rsync.

  - `bk-mkiso`, `bk-install`, `bk-postinstall-workstation`;
  - `bk-update-alternatives`, `bk-reparo`, `bk-initramfs`, etc.

- `docs/`  
  Documentação do projeto.
  - `docs/old/` – tutoriais e análises geradas em iterações anteriores (histórico);
  - novos tutoriais e guias ficam diretamente em `docs/`.

## Fluxo de uso típico

1. **Preparar ambiente de build** (em uma máquina hospedeira):
   - instalar toolchain básica (gcc, make, etc.)
   - adaptar variáveis de ambiente conforme necessário.

2. **Construir rootfs e pacotes base** usando `packages/` + `tools/bk-build-wrapper`.

3. **Gerar initramfs e kernel**:
   - ajustar scripts de `bk-initramfs`, `bk-update`, etc.

4. **Gerar ISO de instalação** com `bk-mkiso` / `bk-mkiso` + `xorriso/grub-mkrescue`.

5. **Instalar o sistema** usando `bk-install`.

6. **Rodar pós-instalação workstation** com:
   - `bk-postinstall-workstation`
   - alternar para `init 5` e usar LightDM + ambiente gráfico.

7. **Montar e manter repositório binário**:
   - usar `bk-update`, `bk-upstream`, `bk-update-alternatives`, `bk-reparo`;
   - definir canais `stable`/`testing` e versão dos índices.

## Documentação

A documentação viva do 3bLinux está em:

- `docs/` – tutoriais atuais:
  - construção do sistema do zero;
  - criação de ISO;
  - servidor de repositório e atualização;
  - desenvolvimento de programas e empacotamento;
  - init, initramfs, GRUB e scripts de inicialização;
  - diagnóstico e depuração.

- `docs/old/` – histórico:
  - análises e tutoriais iterativos;
  - anotações e versões anteriores de textos.

Veja especialmente:

- `docs/TUTORIAL-CONSTRUIR-3BLINUX-DO-ZERO.md`
- `docs/TUTORIAL-CRIAR-ISO-3BLINUX.md`
- `docs/TUTORIAL-SERVIDOR-REPO-3BLINUX.md`
- `docs/TUTORIAL-FUNCIONAMENTO-MANUTENCAO-3BLINUX.md`
- `docs/TUTORIAL-DESENVOLVIMENTO-PACOTES-3BLINUX.md`
- `docs/TUTORIAL-SCRIPTS-BK-3BLINUX.md`
- `docs/TUTORIAL-INIT-GRUB-INITRAMFS-3BLINUX.md`
- `docs/TUTORIAL-FERRAMENTAS-3BLINUX.md`
- `docs/TUTORIAL-DIAGNOSTICO-DEPURACAO-3BLINUX.md`

## Objetivo do projeto

O objetivo do 3bLinux é ser:

- um laboratório educacional avançado de sistema Linux;
- um kit reproduzível para montar sua própria distro;
- uma base enxuta mas extensível para workstation.

Você é livre para:

- adaptar scripts de construção;
- personalizar init, initramfs, GRUB, layout de rootfs;
- criar seus próprios perfis de sistema (server, workstation, minimal, etc.).

Para detalhes passo a passo, consulte os tutoriais em `docs/`.

- tools/bk-promote-to-stable – promove pacotes de testing para stable.
