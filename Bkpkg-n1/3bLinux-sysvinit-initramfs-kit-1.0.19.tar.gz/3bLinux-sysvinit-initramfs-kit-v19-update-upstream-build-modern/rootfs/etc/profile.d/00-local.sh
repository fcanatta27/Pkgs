# /etc/profile.d/00-local.sh
# Use este arquivo para customizações locais de ambiente.

# Exemplo:
# export EDITOR=vim
