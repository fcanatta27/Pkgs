# /etc/profile.d/bash-global.sh - garante /etc/bash.bashrc em shells bash interativos

if [ -n "$BASH_VERSION" ]; then
  # Apenas shells interativos
  case "$-" in
    *i*)
      if [ -f /etc/bash.bashrc ]; then
        . /etc/bash.bashrc
      fi
      ;;
  esac
fi
