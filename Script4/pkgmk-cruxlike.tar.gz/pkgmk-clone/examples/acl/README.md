Exemplo: acl (usando o Pkgfile fornecido)

Este port baixa e compila o ACL.
Uso (a partir deste diretório):
  ../../pkgmk build
  ../../pkgmk package
  ../../pkgmk install -r ./rootfs

Requisitos típicos:
  - toolchain (gcc, make)
  - utilitários: tar, xz (para .tar.xz), curl ou wget
  - dependência indicada no cabeçalho: attr (instale no seu sistema)
