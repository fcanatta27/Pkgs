# pkgmk-clone (CRUX-like) — Tutorial completo

Este projeto fornece um `pkgmk` **prático e utilizável** (em **bash**) inspirado no CRUX Linux, com suporte a convenções comuns de ports, incluindo:

- Execução de **Pkgfiles reais** (arrays `source=(...)`, `md5sums=(...)`, funções `build()` e `package()`).
- **Download / verificação / extração / patches / build / pacote**.
- **footprint** (gerar e checar).
- **gendigest** (gerar MD5 automaticamente e atualizar o `Pkgfile`).
- **stripping** de binários ELF (por padrão; pode desativar).
- **split libs** (opcional, por lista declarativa).
- **patches por convenção** (`patches/` e `*.patch/*.diff`).

> Nota: isto não é o `pkgmk` oficial do CRUX, mas é propositalmente próximo nas ideias e no fluxo. O objetivo é ser útil para ports e estudos.

---

## 1) Conceitos: port, Pkgfile e diretórios

### O que é um “port”
Um **port** é um diretório que contém pelo menos um `Pkgfile`, e opcionalmente:
- `footprint` — lista ordenada dos paths que o pacote instalará.
- `patches/` — patches aplicados automaticamente (opcional).
- `libsplit` — lista dos arquivos que devem ir de `/usr/lib` para `/lib` (opcional).

### Estrutura de diretórios que o pkgmk usa
Ao rodar, o `pkgmk` cria por padrão:

- `.work/distfiles/` — arquivos baixados (tarballs, etc.)
- `.work/src/` — fonte extraída
- `.work/pkg/` — staging do pacote (o conteúdo final “instalável”)
- `.work/packages/` — pacote gerado (`.tar.gz`)
- `.work/logs/` — logs (`fetch.log`, `extract.log`, `compile.log`, etc.)

Você pode mudar o workdir com `PKGMK_WORKDIR=/caminho`.

---

## 2) Como um Pkgfile funciona

### Variáveis principais
- `name` (obrigatório)
- `version` (obrigatório)
- `release` (opcional; default `1`)
- `source=( ... )` (recomendado) — URLs ou caminhos locais relativos ao port
- `md5sums=( ... )` (opcional) — hashes MD5 na mesma ordem do `source`

### Funções
- `build()` (obrigatória) — compila e instala no `$PKG` (staging)
- `package()` (opcional) — etapa adicional para ajustar o conteúdo do `$PKG` antes de empacotar

### Variáveis de ambiente exportadas para o Pkgfile
- `WORK`, `DIST`, `SRC`, `PKG`, `OUT`, `PORTDIR`
- `SRCDIR` (detectado: preferencialmente `$SRC/$name-$version`, senão heurística)

---

## 3) Comandos e opções

### Comandos principais
- `pkgmk build` — fluxo completo (default)
- `pkgmk fetch`
- `pkgmk verify`
- `pkgmk extract`
- `pkgmk patches` — aplica patches por convenção
- `pkgmk compile`
- `pkgmk package`
- `pkgmk install -r <rootdir>`
- `pkgmk clean`

### Helpers estilo CRUX
- `pkgmk footprint` — gera `./footprint` baseado no `$PKG`
- `pkgmk checkfootprint` — compara `./footprint` com a saída atual (mostra diff)
- `pkgmk gendigest` — calcula MD5 dos distfiles e **atualiza o `Pkgfile`**
- `pkgmk diff` — alias para `checkfootprint`

### Opções
- `-p, --pkgfile FILE` — usar outro Pkgfile
- `-f, --force` — força re-download/re-extração/rebuild
- `-j N` — exporta `MAKEFLAGS=-jN`
- `-r, --root DIR` — root de instalação para `install`
- `--no-strip` — desabilita stripping ELF
- `--split-libs` — habilita split libs (ver seção)
- `--update-digest` — durante `build`, roda o equivalente a `gendigest`
- `--mkfootprint` — durante `build`, gera `./footprint`
- `--check-footprint` — durante `build`, verifica `./footprint` (falha se divergir)

---

## 4) Patches por convenção

Se existir:

- `patches/series` — lista de patches (um por linha, comentários com `#`)
- Caso contrário: todos os `patches/*.patch` / `patches/*.diff` em ordem alfabética
- Caso ainda não exista: `*.patch` / `*.diff` no diretório do port, em ordem alfabética

Aplicação:
- é feita em `$SRCDIR`
- usa `patch -p1`
- pode ser desativada via `PKGMK_AUTOPATCH=0`

---

## 5) footprint (gerar e checar)

### Gerar
Depois que seu build estiver correto:

```bash
pkgmk footprint
```

Isso escreve um arquivo `footprint` no diretório do port, com uma lista ordenada de paths (diretórios terminam com `/`).

### Checar
Para validar se o conteúdo do pacote continua igual:

```bash
pkgmk checkfootprint
```

Se houver diferença, o `pkgmk` imprime um `diff -u` e retorna código de erro.

---

## 6) gendigest (MD5 automático)

Para evitar digitar hashes manualmente:

```bash
pkgmk gendigest
```

- baixa os `source` em `.work/distfiles`
- calcula o MD5 de cada distfile
- atualiza o bloco `md5sums=(...)` no seu `Pkgfile`
  - se não existir, ele cria e insere após `source`, quando possível

---

## 7) Stripping (padrão)

Por padrão, o `pkgmk` tenta reduzir tamanho do pacote fazendo strip de objetos ELF (binários e `.so*`), se `strip` e `file` existirem.

Para desabilitar:

```bash
pkgmk build --no-strip
```

Ou:

```bash
PKGMK_NOSTRIP=1 pkgmk build
```

---

## 8) Split /lib vs /usr/lib (opcional)

O split é **opt-in** (não roda por padrão), pois depende do que sua distro considera “essencial em /lib”.

Habilitar:

```bash
pkgmk build --split-libs
```

Você define os arquivos que devem mover de `/usr/lib` para `/lib` de duas formas:

### A) Arquivo `libsplit`
No diretório do port, crie um arquivo `libsplit` contendo um path por linha, por exemplo:

```text
usr/lib/libfoo.so.1
usr/lib/libbar.so.2
```

### B) Array `splitlib=(...)` no Pkgfile
Exemplo:

```bash
splitlib=(
  usr/lib/libfoo.so.1
)
```

O `pkgmk` move o arquivo para `/lib/...` e cria um symlink de volta em `/usr/lib/...`.

---

## 9) Exemplo de fluxo típico

```bash
pkgmk gendigest
pkgmk build --mkfootprint
pkgmk checkfootprint
pkgmk install -r ./rootfs
```

---

## 10) Troubleshooting

- **Falha no `patch -p1`**: verifique se o patch foi gerado com base no root do source; se precisar, desative autopatch e aplique manualmente no `build()`.
- **`md5 mismatch`**: o distfile mudou; rode `pkgmk gendigest` e revise se o upstream é confiável.
- **`SRCDIR` errado**: alguns sources extraem múltiplos diretórios. Nesse caso, faça `cd` explícito dentro do `build()` no `Pkgfile`.
- **Dependências**: este clone não resolve dependências automaticamente; você precisa ter toolchain e deps instaladas no ambiente.

