# pkgmk-clone (CRUX-like)

Um `pkgmk` inspirado no CRUX Linux, feito para rodar **Pkgfiles reais** em **bash**, com convenções úteis para ports.

## Uso rápido

Dentro do diretório do port:

```bash
/path/para/pkgmk build
```

Instalar em uma root “imagem” (sem root):

```bash
/path/para/pkgmk install -r ./rootfs
```

## Recursos principais

- `source=(...)` / `md5sums=(...)` (arrays) e `build()`/`package()`
- `footprint`, `checkfootprint` (com diff)
- `gendigest` (atualiza `md5sums` no Pkgfile)
- autopatches por convenção (`patches/`)
- stripping ELF (padrão; pode desativar)
- split libs opt-in via `libsplit`/`splitlib` + `--split-libs`

Consulte `TUTORIAL.md` para detalhes completos.
