LFSCTL Final Package
---------------------
This folder contains all scripts with full formatting and ready to be copied to /usr/bin.
Includes: lfsctl, bootstrap.sh, build.sh, install.sh, uninstall.sh, update.sh, dependency.sh, sandbox.sh, utils.sh, log.sh, lfsctl_completion.sh.
