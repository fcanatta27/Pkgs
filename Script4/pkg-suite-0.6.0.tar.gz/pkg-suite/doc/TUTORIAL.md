# pkg-suite 0.6.0 — Tutorial (prt-get + pkgutils-like em bash)

Este pacote fornece:
- `pkg` (prt-get-like): navegação/instalação a partir de ports tree local
- `pkgadd`, `pkgrm`, `pkginfo` (pkgutils-like): instalação/remoção/consulta de pacotes binários

## 1) Estrutura e requisitos

Requisitos mínimos:
- bash 4+
- tar, gzip
- find, awk, sed, grep, sort
- (opcional) sha256sum ou shasum

O banco de pacotes instalados segue o layout CRUX-like:
- `/var/lib/pkg/db/<name>#<version>-<release>.files`
- `/var/lib/pkg/db/<name>#<version>-<release>.info`
- upgrades podem salvar rejeitados em `/var/lib/pkg/rejected/<id>-<timestamp>/...`

## 2) Instalação local (sem root)

Você pode testar em um diretório root alternativo:

```bash
export ROOT="$PWD/rootfs"
mkdir -p "$ROOT"
./bin/pkgadd --root "$ROOT" ./foo#1.0-1.pkg.tar.gz
./bin/pkginfo --root "$ROOT" -i
./bin/pkgrm --root "$ROOT" foo
```

## 3) pkgadd

Instala um pacote `.pkg.tar.gz`.

- instalar:
```bash
pkgadd pacote.pkg.tar.gz
```

- upgrade (remove versão anterior do mesmo name e salva rejeitados):
```bash
pkgadd -u pacote.pkg.tar.gz
```

- forçar overwrite:
```bash
pkgadd -f pacote.pkg.tar.gz
```

- root alternativo:
```bash
pkgadd -r ./rootfs pacote.pkg.tar.gz
```

Config:
- `/etc/pkgadd.conf` (exemplo em `etc/pkgadd.conf.example`)

## 4) pkgrm

Remove um pacote instalado.

- remover por name:
```bash
pkgrm openssl
```

- remover por ID exato:
```bash
pkgrm openssl#3.0.0-1
```

- salvar rejeitados (modo upgrade):
```bash
pkgrm --save-rejected openssl
```

## 5) pkginfo

- listar instalados:
```bash
pkginfo -i
```

- listar arquivos de um pacote:
```bash
pkginfo -l openssl
```

- descobrir dono de um caminho:
```bash
pkginfo -f /usr/bin/openssl
```

- mostrar metadados:
```bash
pkginfo -s openssl
```

## 6) pkg (prt-get-like)

O `pkg` opera sobre uma ports tree local (como no CRUX), lendo `Pkgfile`.

Config padrão:
- `/etc/pkg.conf`
- `~/.config/pkg/pkg.conf`

Exemplo de config em `etc/pkg.conf.example`.

### Cache (prt-cache-like)

- construir cache:
```bash
pkg cache
```

- atualizar incrementalmente:
```bash
pkg cache --update
```

### Descoberta e consulta

- listar ports:
```bash
pkg list
```

- buscar:
```bash
pkg search ssl
```

- info:
```bash
pkg info openssl
pkg path openssl
```

- README:
```bash
pkg readme openssl
```

### Instalar / atualizar

`pkg install` chama `pkgmk build` no diretório do port e depois `pkgadd`.

```bash
pkg install openssl
pkg update openssl
```

### sysup (upgrade do que está instalado)

`pkg sysup` compara IDs instalados (`name#version-release`) com o que está disponível na ports tree.
Se houver diferença, ele executa `pkg update <port>`.

```bash
pkg sysup
```

### Locks (exclusões persistentes no sysup)

Arquivo: `~/.cache/pkg/locks`

- exato:
```bash
pkg lock openssl
```

- glob:
```bash
pkg lock 'openssl*'
pkg lock 'glob:lib*'
```

- regex:
```bash
pkg lock 're:^lib.*'
```

- listar/remover:
```bash
pkg locks
pkg unlock 'openssl*'
```

### fsearch / dsearch (via .footprint)

- agrupado por port:
```bash
pkg fsearch libssl
pkg dsearch usr/lib
```

- regex/fixed:
```bash
pkg fsearch 'libssl\.so\.' --regex
pkg fsearch libssl --fixed
```

- contagem:
```bash
pkg fsearch lib --count
```

- modo flat:
```bash
pkg fsearch libssl --flat
```

## 7) Integração com pkgmk

Este pacote inclui apenas um wrapper `bin/pkgmk`. Para uso real, coloque o seu `pkgmk-cruxlike` como:
- `bin/pkgmk-real` (executável), ou
- instale `pkgmk` no PATH e ajuste `PKGMK=/caminho/pkgmk` no ambiente/config.

Exemplo:
```bash
cp /caminho/do/pkgmk-cruxlike ./bin/pkgmk-real
chmod +x ./bin/pkgmk-real
```

## 8) Observações de compatibilidade

- O CRUX real possui nuances adicionais (scripts de install, triggers, políticas de perms, etc.).
  Este pacote replica a lógica essencial com foco em segurança e previsibilidade em bash.
