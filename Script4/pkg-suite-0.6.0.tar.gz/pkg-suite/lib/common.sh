# Common helpers for pkg-suite
msg() { printf '%s\n' "$*"; }
err() { printf 'ERROR: %s\n' "$*" >&2; }
die() { err "$*"; exit 1; }

# Color output (TTY-aware)
_color_init() {
  if [[ -t 1 ]] && [[ "${NO_COLOR:-}" != "1" ]] && [[ "${PKG_NOCOLOR:-}" != "1" ]]; then
    C_BOLD=$'\033[1m'; C_DIM=$'\033[2m'; C_RED=$'\033[31m'; C_GRN=$'\033[32m'
    C_YLW=$'\033[33m'; C_BLU=$'\033[34m'; C_MAG=$'\033[35m'; C_CYN=$'\033[36m'
    C_RST=$'\033[0m'
  else
    C_BOLD=""; C_DIM=""; C_RED=""; C_GRN=""; C_YLW=""; C_BLU=""; C_MAG=""; C_CYN=""; C_RST=""
  fi
}
_color_init

step() { printf '%s=======>%s %s\n' "$C_GRN" "$C_RST" "$*"; }
note() { printf '%s===>%s %s\n' "$C_CYN" "$C_RST" "$*"; }
warn() { printf '%sWARNING:%s %s\n' "$C_YLW" "$C_RST" "$*" >&2; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || die "Missing required command: $1"; }

abspath() { python3 - <<'PY' "$1"
import os,sys
print(os.path.abspath(sys.argv[1]))
PY
}

# Read simple key=value config files
# - ignores blank lines and comments (# ...)
# - preserves as shell-safe values by exporting VAR=VALUE literally
load_kv_config() {
  local f="$1"
  [[ -f "$f" ]] || return 0
  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ -z "$line" ]] && continue
    [[ "$line" =~ ^[[:space:]]*# ]] && continue
    if [[ "$line" =~ ^[[:space:]]*([A-Za-z_][A-Za-z0-9_]*)=(.*)$ ]]; then
      local k="${BASH_REMATCH[1]}"
      local v="${BASH_REMATCH[2]}"
      # strip surrounding whitespace
      v="${v#"${v%%[![:space:]]*}"}"
      v="${v%"${v##*[![:space:]]}"}"
      # remove optional surrounding quotes
      if [[ "$v" =~ ^\"(.*)\"$ ]]; then v="${BASH_REMATCH[1]}"; fi
      if [[ "$v" =~ ^\'(.*)\'$ ]]; then v="${BASH_REMATCH[1]}"; fi
      export "$k=$v"
    fi
  done < "$f"
}

# Advisory lock using mkdir
with_lock() {
  local lockdir="$1"; shift
  local tries=80
  while ! mkdir "$lockdir" 2>/dev/null; do
    ((tries--)) || die "Could not acquire lock: $lockdir"
    sleep 0.1
  done
  trap 'rmdir "$lockdir" 2>/dev/null || true' EXIT
  "$@"
}

sha256_file() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}'
  else shasum -a 256 "$1" | awk '{print $1}'; fi
}
