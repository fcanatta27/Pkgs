# pkginfo (bash) — Tutorial e Referência

Este pacote entrega uma reimplementação em **Bash** do comando **`pkginfo`** do **pkgutils (CRUX)**, baseada no comportamento observado no código-fonte original (pkgutils 5.40).

## 1. O que o `pkginfo` faz

O `pkginfo` fornece quatro modos (mutuamente exclusivos):

1. **Listar pacotes instalados** (`-i/--installed`)
2. **Listar arquivos de um pacote instalado OU de um arquivo de pacote** (`-l/--list`)
3. **Encontrar o(s) dono(s) de arquivos por padrão regex** (`-o/--owner`)
4. **Gerar um “footprint” de um arquivo de pacote** (`-f/--footprint`)

Todos os modos (exceto `--footprint`) leem o banco local de pacotes do CRUX em:

- `<root>/var/lib/pkg/db`

## 2. Instalação e execução

Estrutura do pacote:

- `bin/pkginfo` — o executável
- `lib/pkgutils_common.sh` — rotinas comuns (leitura do DB, validações)

### Executar sem instalar

```bash
./bin/pkginfo -h
```

### Instalar localmente (exemplo)

```bash
sudo install -Dm755 bin/pkginfo /usr/local/bin/pkginfo
sudo install -Dm755 lib/pkgutils_common.sh /usr/local/lib/pkgutils_common.sh
```

Observação: no script, o `pkginfo` procura `../lib/pkgutils_common.sh` relativo ao executável. Se você instalar em diretórios separados, ajuste a linha `source` no `bin/pkginfo` ou mantenha a mesma estrutura.

## 3. Dependências

Para replicar as funcionalidades do original, este `pkginfo` (bash) usa comandos externos:

- `bsdtar` (libarchive) — para listar e “footprint” de pacotes (`-l` com arquivo e `-f`)
- `grep` — para o modo `--owner`
- `sed` — para normalização de listagens

## 4. Banco de dados (formato)

O arquivo `<root>/var/lib/pkg/db` é um arquivo texto com registros, cada registro contendo:

1. Nome do pacote
2. Versão (string)
3. Lista de arquivos (um por linha, sem `/` inicial)
4. Linha em branco terminando o registro

Exemplo (simplificado):

```
foo
1.0-1
usr/bin/foo
usr/share/doc/foo/README

bar
2.3-4
usr/bin/bar

```

## 5. Comandos e exemplos

### 5.1 Ajuda e versão

```bash
pkginfo -h
pkginfo -v
```

### 5.2 Listar pacotes instalados

```bash
pkginfo -i
```

Saída (formato):

```
<nome> <versao>
```

### 5.3 Listar arquivos de um pacote instalado

```bash
pkginfo -l bash
```

Se `bash` existir no DB, imprime a lista de arquivos registrados para esse pacote.

### 5.4 Listar arquivos contidos em um arquivo de pacote

```bash
pkginfo -l ./foo-1.0-1.pkg.tar.xz
```

Este modo usa `bsdtar -tf`.

### 5.5 Encontrar dono(s) de arquivos por regex

O modo owner recebe um **regex ERE** (equivalente ao `grep -E`). O comportamento do original casa o padrão contra o caminho **com `/` inicial**.

Exemplos:

```bash
# Quem instala /usr/bin/ls?
pkginfo -o '^/usr/bin/ls$'

# Quem instala qualquer coisa em /etc?
pkginfo -o '^/etc/'

# Quem instala arquivos .pc (pkg-config)?
pkginfo -o '\\.pc$'
```

Saída (tabela):

```
Package  File
...
```

### 5.6 Footprint de um pacote

```bash
pkginfo -f ./foo-1.0-1.pkg.tar.xz
```

O footprint no original inclui:

- permissões
- usuário/grupo
- caminho
- marcações especiais
  - symlink: `-> alvo`
  - arquivo vazio: `(EMPTY)`

Nesta implementação em bash, as informações são derivadas de `bsdtar -tvf`. Por limitações do formato de saída do `bsdtar` entre versões/ambientes, pode haver pequenas diferenças em casos de hardlinks e campos não padronizados.

## 6. Root alternativo

Se você estiver inspecionando uma instalação montada em outro diretório:

```bash
pkginfo -r /mnt/cruxroot -i
pkginfo -r /mnt/cruxroot -o '^/usr/lib/'
```

## 7. Compatibilidade e limites conhecidos

- O `pkginfo` original usa leitura via libarchive e obtém UID/GID resolvendo para nomes (`getpwuid/getgrgid`).
- Em bash, o modo `--footprint` é aproximado via `bsdtar` e imprime o campo `user/group` como fornecido por ele.
- Para uso real em CRUX, recomenda-se instalar `libarchive` e garantir que `bsdtar` esteja disponível.

