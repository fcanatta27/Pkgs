#!/usr/bin/env bash
set -euo pipefail

PKGUTILS_VERSION="5.40-bash1"

# Defaults (CRUX-compatible)
: "${PKGUTILS_ROOT:=/}"
: "${PKGUTILS_DB_REL:=var/lib/pkg/db}"

_die() { echo "${0##*/}: $*" >&2; exit 1; }

# Normalize root to remove trailing slashes except for '/'
_norm_root() {
  local r="$1"
  [[ -z "$r" ]] && r="/"
  # remove trailing slashes
  while [[ "$r" != "/" && "$r" == */ ]]; do r="${r%/}"; done
  echo "$r"
}

_db_path() {
  local root
  root="$(_norm_root "${1:-$PKGUTILS_ROOT}")"
  echo "$root/$PKGUTILS_DB_REL"
}

# Read CRUX pkgutils db into arrays:
# PKG_NAMES[i], PKG_VERS[i], PKG_FILES[i] (newline-delimited files)
# DB format: name\nversion\nfile\nfile\n\n...
_db_read() {
  local root db
  root="$(_norm_root "${1:-$PKGUTILS_ROOT}")"
  db="$(_db_path "$root")"
  [[ -r "$db" ]] || _die "could not open $db"

  PKG_NAMES=()
  PKG_VERS=()
  PKG_FILES=()

  local name ver line files
  name=""; ver=""; files=""

  # shellcheck disable=SC2162
  while IFS= read -r line || [[ -n "$line" ]]; do
    if [[ -z "$name" ]]; then
      name="$line"
      continue
    fi
    if [[ -z "$ver" ]]; then
      ver="$line"
      continue
    fi

    if [[ -z "$line" ]]; then
      # end of record
      if [[ -n "$name" ]]; then
        PKG_NAMES+=("$name")
        PKG_VERS+=("$ver")
        PKG_FILES+=("$files")
      fi
      name=""; ver=""; files=""
    else
      files+="$line"$'\n'
    fi
  done < "$db"

  # If file doesn't end with blank line, flush last record (pkgutils ignores empty files list)
  if [[ -n "$name" && -n "$files" ]]; then
    PKG_NAMES+=("$name")
    PKG_VERS+=("$ver")
    PKG_FILES+=("$files")
  fi
}

_find_pkg_index() {
  local want="$1" i
  for i in "${!PKG_NAMES[@]}"; do
    [[ "${PKG_NAMES[$i]}" == "$want" ]] && { echo "$i"; return 0; }
  done
  return 1
}

_require_cmd() {
  command -v "$1" >/dev/null 2>&1 || _die "required command '$1' not found"
}
