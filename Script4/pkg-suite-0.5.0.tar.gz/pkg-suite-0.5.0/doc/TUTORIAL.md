# pkg — um “prt-get” em bash (CRUX-like)

Este projeto entrega um utilitário chamado **`pkg`** (shell script **bash**) inspirado no **`prt-get`** do CRUX: ele opera no modelo **ports tree local + pkgmk + pkgadd/pkgdel/pkginfo**.

Escopo (deliberado): manter o comportamento “clássico” do CRUX — sem virar um resolvedor de dependências por versão, sem transações e sem daemon.

---

## 1) Conteúdo do pacote

- `bin/pkg` — o “prt-get” em bash
- `bin/pkgmk` — `pkgmk-cruxlike` incluído (para builds consistentes)
- `etc/pkg.conf.example` — exemplo completo de configuração (compatível com prt-get.conf)
- `doc/TUTORIAL.md` — este documento

Sugestão de instalação local:

```bash
tar -xzf pkg-suite-*.tar.gz
cd pkg-suite
export PATH="$PWD/bin:$PATH"
```

---

## 2) Configuração (prt-get.conf compatível)

O `pkg` procura config nesta ordem:

1. `PKG_CONF=/caminho/arquivo.conf`
2. `/etc/prt-get.conf`
3. `/etc/pkg.conf`
4. `~/.config/pkg.conf`
5. `./pkg.conf`

O formato é o mesmo do `prt-get.conf`: **uma opção por linha**, como `chave valor`.

### 2.1 prtdir (com precedência e allow-list)

`prtdir` define onde procurar ports (não é recursivo). A **ordem importa**: se o mesmo port existir em duas coleções, vale o primeiro `prtdir` encontrado (precedência). citeturn1view0

Formato simples:

```conf
prtdir /usr/ports/core
prtdir /usr/ports/opt
```

Formato com allow-list (recurso do prt-get): citeturn1view0

```conf
prtdir /home/user/myports:bash,prt-get
prtdir /usr/ports/opt
prtdir /usr/ports/contrib
prtdir /home/user/myports
```

Neste exemplo, **apenas** `bash` e `prt-get` são “visíveis” no primeiro `prtdir`, garantindo precedência sobre o restante.

### 2.2 cachefile / prt-cache-like

O `pkg` implementa um cache estilo `prt-cache` e suporta `cachefile` como no prt-get: citeturn1view0

```conf
cachefile /var/lib/pkg/prt-get.cache
```

Se você definir `cachefile`, o diretório pai também é usado para:
- locks persistentes (`locks`)
- índices auxiliares (ex.: footprints)

### 2.3 logging (prt-get-like)

As opções do prt-get para logging são suportadas: citeturn1view0

```conf
writelog enabled
logmode overwrite         # ou append
logfile /tmp/pkg/%n.log   # %n = port, %p = diretório do port
rmlog_on_success no
```

Além disso, você pode forçar logging por execução usando `--log`.

### 2.4 readme (prt-get-like)

O prt-get pode indicar pacotes com `README` durante install/update. citeturn1view0

```conf
readme compact    # ou verbose / disabled
```

### 2.5 runscripts (prt-get-like)

```conf
runscripts yes
```

Quando `yes`, executa automaticamente `pre-install`/`post-install` se existirem no port.

### 2.6 Overriding via linha de comando (prt-get-like)

Como no prt-get, você pode alterar config “on the fly”: citeturn1view0

- `--no-std-config`
- `--config-set="key value"`
- `--config-append="key value"`
- `--config-prepend="key value"`

Exemplos:

```bash
pkg update bash --no-std-config --config-set="prtdir /mnt/ports"
pkg install vim --config-prepend="prtdir /tmp/tempports"
pkg install foo --config-append="readme compact"
```

---

## 3) Comandos principais (prt-get-like)

### 3.1 install / update / grpinst

- `pkg install <port...>`: instala ports (continua mesmo se um falhar)
- `pkg update <port...>`: rebuild + reinstala (se instalado; senão vira install)
- `pkg grpinst <port...>`: para no primeiro erro (útil para “lotes”)

Modo teste:

```bash
pkg install nano --test
```

### 3.2 depinst / depends / quickdep

- `pkg depends <port...>`: lista deps (best-effort; lê cabeçalhos tipo `Depends on:`)
- `pkg quickdep <port...>`: deps em uma linha
- `pkg depinst <port...>`: instala fechamento de deps (best-effort)

Observação: no CRUX as dependências podem ser incompletas/ausentes. O comportamento segue esse espírito.

### 3.3 sysup / diff / current

- `pkg diff`: mostra instalados com versão diferente no ports tree (best-effort)
- `pkg sysup`: atualiza todos os “outdated” (respeita locks)
- `pkg current <port>`: versão instalada (best-effort)

### 3.4 list / search / info / path / readme / isinst

- `pkg list [glob]`
- `pkg search <expr>`
- `pkg info <port>`
- `pkg path <port>`
- `pkg readme <port>`
- `pkg isinst <port>`

---

## 4) Cache e buscas em footprint

### 4.1 cache (prt-cache-like)

```bash
pkg cache
pkg cache --update   # incremental por mtime
```

### 4.2 fsearch / dsearch

Usa `.footprint` para encontrar arquivos/diretórios fornecidos por ports.

Agrupado por port (padrão):

```bash
pkg fsearch libssl
pkg dsearch usr/lib
```

Modos:

- `--flat` (uma linha por ocorrência)
- `--count` (port + número de hits)
- `--fixed` / `--regex`

---

## 5) Locks (exclusões persistentes no sysup)

Arquivos lock ficam em `~/.cache/pkg/locks` (ou no diretório do `cachefile`).

### 5.1 lock / unlock / locks

```bash
pkg lock openssl
pkg unlock openssl
pkg locks
```

### 5.2 lock patterns (glob/regex)

- exato: `openssl`
- glob: `openssl*` (ou `glob:openssl*`)
- regex: `re:^lib.*` (bash regex)

---

## 6) Clusters (grpinst a partir de lista)

```bash
pkg grpinst @meu.cluster
```

Formato do arquivo:
- 1 port por linha
- comentários `#` suportados

---

## 7) Atualização das árvores de ports

O `pkg updateports` tenta atualizar coleções git (`git pull --ff-only`) quando aplicável.

Em sistemas CRUX típicos, você também pode usar o comando `ports -u` conforme sua configuração local.


\
---

# pkgutils-bash (pkgadd/pkgrm/pkginfo)

Este pacote inclui implementações em bash de **pkgadd**, **pkgrm** e **pkginfo** (modelo CRUX/pkgutils).

## Visão geral do layout (CRUX-like)

- Banco de dados: `/var/lib/pkg/db/`  
  Um arquivo por pacote instalado, com o nome `pkgname#versao-release` e a lista de caminhos instalados.
- Rejeitados no upgrade: `/var/lib/pkg/rejected/<pkgid>/...`  
  Quando `pkgadd -u` encontra regra `UPGRADE ... NO`, o arquivo novo é salvo aqui e o arquivo existente é preservado.

A política de *keep/reject* para upgrades é governada por **/etc/pkgadd.conf**. citeturn2search0

## Configuração (/etc/pkgadd.conf)

Copie o exemplo:

```bash
install -Dm644 etc/pkgadd.conf.example /etc/pkgadd.conf
```

Formato:

```
UPGRADE  ^etc/.*$  NO
UPGRADE  ^etc/X11/.*$  YES
```

Regras mais abaixo têm maior prioridade. citeturn2search0

## pkgadd

Instalar:

```bash
pkgadd bash#5.2.37-1.pkg.tar.gz
```

Upgrade (com regras UPGRADE e rejeitados):

```bash
pkgadd -u bash#5.2.38-1.pkg.tar.gz
```

Forçar overwrite (ignora pkgadd.conf):

```bash
pkgadd -uf bash#5.2.38-1.pkg.tar.gz
```

Instalar em root alternativo (útil para chroot/teste):

```bash
pkgadd -r /mnt/pkgroot bash#5.2.37-1.pkg.tar.gz
```

## pkgrm

Remover por nome:

```bash
pkgrm bash
```

Ou por identificador exato:

```bash
pkgrm bash#5.2.37-1
```

Root alternativo:

```bash
pkgrm -r /mnt/pkgroot bash
```

## pkginfo

Listar instalados:

```bash
pkginfo -i
```

Listar arquivos de um pacote:

```bash
pkginfo -l bash
```

Encontrar “dono” de um arquivo (caminho relativo, sem / inicial):

```bash
pkginfo -f usr/bin/bash
```

Consultar versão instalada:

```bash
pkginfo -q bash
```

## Integração com `pkg` (prt-get-like)

O comando `pkg` deste pacote **prioriza** os binários `pkgadd/pkgrm/pkginfo` que estejam na mesma pasta do script.
Isso permite rodar tudo “portável” (ex.: em um chroot) sem depender do pkgutils do host.

