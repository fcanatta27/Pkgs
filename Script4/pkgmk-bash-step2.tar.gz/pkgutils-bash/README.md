# pkgmk (Bash) — passo 2

Este pacote contém o `pkgmk` em Bash (como no pkgutils-5.40), com a mesma lógica/estrutura do original, apenas com o placeholder de versão resolvido.

## Conteúdo
- `bin/pkgmk` — script
- `conf/pkgmk.conf` — configuração padrão
- `man/man8/pkgmk.8` — manual
- `man/man5/pkgmk.conf.5` — manual

## Execução rápida
Dentro de um diretório que contenha um `Pkgfile`:

```bash
./bin/pkgmk -h
./bin/pkgmk -d
./bin/pkgmk
```

Para usar um arquivo de configuração alternativo:

```bash
./bin/pkgmk -cf /caminho/pkgmk.conf
```
