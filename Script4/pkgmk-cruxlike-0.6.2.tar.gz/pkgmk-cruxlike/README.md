# pkgmk-clone (CRUX-like)

Um `pkgmk` inspirado no CRUX Linux, feito para rodar **Pkgfiles reais** em **bash**, com convenções úteis para ports.

## Uso rápido

Dentro do diretório do port:

```bash
/path/para/pkgmk build
```

Instalar em uma root “imagem” (sem root):

```bash
/path/para/pkgmk install -r ./rootfs
```

## Recursos principais

- `source=(...)` / `md5sums=(...)` (arrays) e `build()`/`package()`
- `.footprint`, `check.footprint` (com diff)
- `gendigest` (atualiza `md5sums` no Pkgfile)
- autopatches por convenção (`patches/`)
- stripping ELF (padrão; pode desativar)
- split libs opt-in via `libsplit`/`splitlib` + `--split-libs`

Consulte `TUTORIAL.md` para detalhes completos.


## Novidades CRUX-like (extensões)

- Flags compatíveis: `-uf`, `-cf`, `-if`, `-m`, `-d`, `-i`, `-u`, `-f`, `-c`.
- `.md5sum` é gerado automaticamente após o download dos `source=()`.
- Suporte opcional a `.signature` via `signify` (flags `-cs`, `-is`, `-us`, `-rs`, `-sk`).
- Footprint com metadados: habilite `PKGMK_FOOTPRINT_META=yes` para gerar/validar `.footprint.meta`.
- Manifesto de auditoria (externo ao tarball): `pkgmk --manifest`/`-gm` cria `./.manifest` e um arquivo `<pacote>.manifest` ao lado do pacote.
- Convenção de patches: `patches/*.patch|*.diff` e `*.patch|*.diff` no diretório do port; níveis `-p0/-p1/-p2` detectados por sufixo `.p0.`/`.p1.`/`.p2.`.
