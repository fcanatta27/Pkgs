# pkgm — Gerenciador simples de pacotes (POSIX sh)

`pkgm` é um gerenciador de pacotes **source-based** que constrói em diretório temporário e gera um **pacote binário** em cache, com **registro/instalação/desinstalação** e **resolução de dependências com detecção de ciclos**.

O foco é ser **simples, limpo e funcional**, sem dependência de linguagens externas além de utilitários comuns do Linux.

## Visão geral

- **Build**: resolve dependências → baixa fontes (com cache) → verifica `md5` → extrai → aplica patches → executa hooks → compila e instala em `DESTDIR=$PKG` → empacota em `tar.gz` no cache → registra artefato.
- **Install**: descompacta o pacote do cache em `--root` (por padrão `/`) e registra lista de arquivos instalados.
- **Uninstall**: remove arquivos registrados (em ordem reversa) e tenta limpar diretórios vazios.

> Observação importante: scripts de pacote **devem** evitar escrever diretamente em `/usr`, `/etc`, etc. A etapa `build` deve produzir tudo dentro de `$PKG` (DESTDIR). Se um script contiver comandos que alteram o host, o `pkgm` emite um aviso.

## Requisitos

- Shell POSIX (`/bin/sh`)
- `tar`, `md5sum`, `patch`, `find`, `sed`, `awk`
- **Downloader**: `curl` ou `wget`
- Opcional: `unzip` (se algum source for `.zip`)
- Opcional: `tac` (para desinstalação em ordem reversa; se não existir, a remoção ainda ocorre, mas pode deixar diretórios vazios)

## Instalação

1. Copie `pkgm` para um diretório no seu `PATH`, por exemplo:

```sh
sudo install -m 0755 bin/pkgm /usr/local/bin/pkgm
```

2. Garanta permissões para escrever no cache/DB/logs (por padrão em `/var/*`), ou aponte para diretórios no seu home:

```sh
export CACHE_DIR="$HOME/.cache/pkgm"
export DB_DIR="$HOME/.local/share/pkgm"
export LOG_DIR="$HOME/.local/state/pkgm"
```

## Layout de pacotes

Cada pacote é um diretório com:

```
<PKGS_DIR>/<categoria>/<nome>/
  build
  patches/*.patch          (opcional)
  hook/pre-build           (opcional)
  hook/post-build          (opcional)
  hook/pre-configure       (opcional)
  hook/post-configure      (opcional)
  hook/pre-install         (opcional)
  hook/post-install        (opcional)
  hook/pre-uninstall       (opcional)
  hook/post-uninstall      (opcional)
```

O arquivo `build` é um script `sh` que inclui variáveis simples no topo:

```sh
source=https://example.com/foo-1.2.3.tar.xz
checksums=0123456789abcdef0123456789abcdef   # md5
depends="bar baz"                            # dependências (nomes de pacotes)
main_bin=/usr/bin/foo                        # opcional (verificação)
```

E depois executa o processo de build/install em `DESTDIR=$PKG`:

```sh
./configure --prefix=/usr
make -j"$JOBS"
make DESTDIR="$PKG" install
```

### Patches

Se existirem arquivos em `patches/*.patch`, o `pkgm` aplica automaticamente com:

```sh
patch -p1 < patchfile.patch
```

### Hooks

Hooks são scripts executáveis no diretório `hook/`. O `pkgm` exporta:

- `PKG` — DESTDIR para instalação
- `WORKDIR` — diretório de trabalho (em cache)
- `SRCDIR` — diretório do source extraído
- `JOBS` — sugestão de paralelismo

## Comandos

### `pkgm list`

Lista pacotes disponíveis (categoria/nome) dentro de `PKGS_DIR`.

### `pkgm info <pkg>`

Mostra metadados: source, md5, deps, versão e status (construído/instalado).

### `pkgm graph <pkg>`

Mostra a árvore de dependências com marcação de ciclo (se existir).

### `pkgm fetch <pkg...>`

Baixa e verifica apenas os sources (cache em `CACHE_DIR/sources`).

### `pkgm build <pkg...>`

- Resolve dependências, detecta ciclos e define ordem de build.
- Cria diretório de trabalho em `CACHE_DIR/work/<pkg>`.
- `PKG` é `CACHE_DIR/work/<pkg>/pkg`.
- Empacota artefato em `CACHE_DIR/pkgs/<pkg>-<ver>.tar.gz`.
- Registra artefato em `DB_DIR/artifacts/<pkg>/`.

Exemplo:

```sh
pkgm build binutils
```

Dry-run:

```sh
pkgm --dry-run build binutils
```

### `pkgm install <pkg...>`

Instala o pacote do cache em `--root` (padrão `/`) e registra:

- `DB_DIR/installed/<pkg>/files` (lista de arquivos)
- `DB_DIR/installed/<pkg>/meta` (metadados)

Exemplo:

```sh
sudo pkgm install binutils
```

Instalar em uma raiz alternativa (teste/chroot):

```sh
pkgm --root /mnt/rootfs install binutils
```

### `pkgm uninstall <pkg...>`

Remove os arquivos registrados e limpa o registro.

Exemplo:

```sh
sudo pkgm uninstall binutils
```

### `pkgm clean [pkg|all]`

Remove diretórios de trabalho em cache.

## Logs

- Logs completos em arquivo: `LOG_DIR/<pkg>.<timestamp>.log`
- Logs em etapas no stderr com cor (se terminal suportar ANSI).

Exemplos de mensagens (formato aproximado):

- `🏭 [pkg] WORK: /var/cache/pkgm/work/pkg → DEST: /var/cache/pkgm/work/pkg/pkg`
- `❌ Script não encontrado: ...`
- `❌ Binário principal não encontrado em DESTDIR`
- `✅ [pkg] Binário: /usr/bin/foo`
- `[pkg] INSTALADO com sucesso! ✔️`

## Resolução de dependências e ciclos

A resolução usa DFS com estados (unseen/visiting/done). Se um ciclo for encontrado, a execução termina com erro indicando o caminho do ciclo.

## Diagnóstico e correções comuns

1. **Falha de download**  
   Verifique `source=` e conectividade. Confirme se `curl`/`wget` existe.

2. **MD5 inválido**  
   O arquivo no upstream pode ter mudado. Atualize `checksums=` no `build` para o novo md5.

3. **Script escreve fora de \$PKG**  
   Mova ações pós-instalação (links, ajustes em `/usr`, etc.) para `hook/post-install` (na etapa `install`) ou crie um pacote separado de “fixups”.

4. **Permissões (cache/DB/log)**  
   Ajuste `CACHE_DIR`, `DB_DIR`, `LOG_DIR` para diretórios no seu home ou use sudo.

## Exemplo de pacotes incluídos

Este repositório inclui exemplos em `repo/core/` (binutils e gcc). Eles vieram de scripts anexados e usam `PKG` como DESTDIR.

## Licença

MIT. Veja `LICENSE`.
