# pkgmk-clone (inspirado no CRUX) — Tutorial completo

Este projeto entrega:

1. **`pkgmk` (clone em shell POSIX)**: um utilitário no estilo do *ports system* do CRUX para **baixar**, **verificar**, **extrair**, **compilar** e **empacotar** um software descrito por um `Pkgfile`.
2. **Um tutorial** explicando o fluxo, as variáveis, as funções e os comandos.

> Aviso: isto é um clone **educacional**, não o `pkgmk` oficial do CRUX. A compatibilidade é “inspirada”, não byte‑a‑byte.

---

## 1) Conceito: o que é um “port”

Um **port** é um diretório contendo um arquivo `Pkgfile` (e opcionalmente patches/arquivos auxiliares).  
O `Pkgfile` define **metadados** (nome/versão/etc.), **fontes** (URLs) e **funções** (`build()` e opcionalmente `package()`).

Fluxo clássico:

1. **fetch**: baixa os *sources*
2. **verify**: confere checksum (md5)
3. **extract**: descompacta para a área de trabalho
4. **compile**: roda `build()`
5. **package**: cria um tarball instalável com o conteúdo do `$PKG`

---

## 2) Estrutura de diretórios

Ao rodar o `pkgmk`, estes diretórios são criados (por padrão, relativos ao diretório do port):

- `.sources/`  
  Arquivos baixados (ex.: `foo-1.0.tar.gz`)
- `.work/`  
  Área temporária de trabalho:
  - `.work/src/` — código-fonte extraído
  - `.work/pkg/` — *staging* do pacote (DESTDIR)
  - `.work/logs/` — logs (`build.log`, `package.log`)
- `.packages/`  
  Saída final:
  - `.packages/<name>-<version>-<release>.tar.gz`

Você pode sobrescrever tudo por variáveis de ambiente:

- `PKGMK_ROOT` (diretório do port)
- `PKGMK_WORK`
- `PKGMK_SOURCES`
- `PKGMK_PKGDEST`

---

## 3) Instalação do pkgmk-clone

Dentro do repositório extraído:

```sh
chmod +x pkgmk
# (opcional) instalar no PATH do usuário:
mkdir -p "$HOME/.local/bin"
cp -f pkgmk "$HOME/.local/bin/pkgmk"
```

---

## 4) Interface do `Pkgfile`

### Campos obrigatórios

No mínimo:

```sh
name=hello
version=1.0
release=1
source="https://example/hello-1.0.tar.gz"
md5sums="d41d8cd98f00b204e9800998ecf8427e"

build() {
  # comandos de build e instalação no DESTDIR
}
```

Campos:

- `name`: nome do pacote
- `version`: versão
- `release`: release (inteiro)
- `source`: uma ou mais URLs (ver seção sobre múltiplas fontes)
- `md5sums`: md5 correspondente a cada source

### Funções

#### `build()`

Executa a compilação e deve instalar arquivos em `$PKG` (*staging* do pacote).  
Padrão recomendado: `make DESTDIR="$PKG" install`, ou instalação manual via `install(1)`.

Variáveis disponíveis:

- `PORTDIR` — diretório do port (onde está o `Pkgfile`)
- `SRC` — diretório com o fonte extraído (`.work/src`)
- `PKG` — diretório de staging (`.work/pkg`)
- `name`, `version`, `release`
- `MAKEFLAGS` — contém `-jN` se você usar `-j N`

#### `package()` (opcional)

Se definido, é executado após `build()`. Use quando você precisa rearranjar arquivos no `$PKG` (ex.: mover docs, limpar artefatos, etc.).  
Se não existir, o `pkgmk` apenas empacota o que estiver em `$PKG`.

---

## 5) Comandos disponíveis

O `pkgmk` aceita uma **ação** e opções.

### Ação padrão: `build`

```sh
pkgmk build
# ou simplesmente:
pkgmk
```

Executa: `fetch -> verify -> extract -> compile -> package`.

### `fetch`

Baixa as fontes para `.sources/`:

```sh
pkgmk fetch
```

Requer `curl` ou `wget`.

### `verify`

Verifica os MD5 definidos em `md5sums`.

```sh
pkgmk verify
```

Para desabilitar a verificação:

```sh
pkgmk -n verify
# ou:
PKGMK_NOCHECKSUM=1 pkgmk verify
```

### `extract`

Extrai os arquivos em `.work/src/`:

```sh
pkgmk extract
```

Suporta: `.tar.gz`, `.tgz`, `.tar.bz2`, `.tar.xz`, `.zip`.

### `compile`

Executa somente a função `build()`:

```sh
pkgmk compile
```

Gera log em `.work/logs/build.log`.

### `package`

Executa `package()` (se existir) e cria o tarball final:

```sh
pkgmk package
```

Saída: `.packages/<name>-<version>-<release>.tar.gz`

### `install`

Instala o pacote em um diretório raiz (imagem) **sem root**:

```sh
pkgmk install -r ./rootfs
```

Por padrão, usa `./rootfs` no diretório do port.

### `clean`

Remove `.work/`:

```sh
pkgmk clean
```

---

## 6) Opções importantes

- `-C <dir>`: aponta para o diretório do port (onde está o `Pkgfile`)
- `-j <n>`: define `MAKEFLAGS=-j<n>` durante o `build()`
- `-k`: não remove a área de trabalho (útil para debugar)
- `-q`: modo mais silencioso
- `-n`: desliga checksum

---

## 7) Exemplo completo (port “hello”)

Veja o diretório `examples/hello/` incluído no pacote.

### Rodar

```sh
cd examples/hello
../../pkgmk build
ls -lh ../../.packages
```

### Instalar em rootfs (sem root)

```sh
../../pkgmk install -r ./rootfs
find ./rootfs -maxdepth 3 -type f
```

---

## 8) Boas práticas de empacotamento

- Sempre instale em `$PKG`, nunca diretamente no sistema.
- Use `install -Dm 755 ...` e `install -Dm 644 ...` para permissões corretas.
- Preserve hierarquia padrão:
  - binários: `/usr/bin`
  - libs: `/usr/lib`
  - headers: `/usr/include`
  - docs: `/usr/share/doc/<name>`
- Gere logs e mantenha `-k` durante desenvolvimento.

---

## 9) Limitações do clone

- O `Pkgfile` original do CRUX usa recursos de `bash` (arrays). Este clone é **bash (compatível com Pkgfiles do CRUX, incluindo arrays)** e portanto adota um subconjunto:
  - Preferencialmente declare `source="url1 url2"` e `md5sums="md51 md52"`.
  - Se quiser, pode usar `sources_list` e `md5sums_list` com linhas separadas (um por linha).
- Não implementa dependências (dep tree), assinatura GPG, split packages, etc.
- Empacota em `.tar.gz` simples (conteúdo do `$PKG`), não em formato `pkg.tar.xz` com metadata avançada.

---

## 10) Diagnóstico rápido

- **Erro “Pkgfile not found”**: você não está no diretório certo, use `-C`.
- **MD5 mismatch**: a fonte mudou; atualize o checksum ou desative com `-n`.
- **Pacote vazio**: seu `build()` não instalou nada em `$PKG`.
- **Falha em download**: instale `curl` ou `wget`.

---

## 11) Referência rápida (cheat sheet)

```sh
# pipeline completo
pkgmk

# somente baixar
pkgmk fetch

# verificar md5
pkgmk verify

# extrair
pkgmk extract

# compilar (build())
pkgmk -j 8 compile

# empacotar
pkgmk package

# instalar em rootfs
pkgmk install -r ./rootfs

# limpar workdir
pkgmk clean
```
