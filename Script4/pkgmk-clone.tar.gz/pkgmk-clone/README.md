pkgmk-clone (CRUX-inspired)
- pkgmk: POSIX sh clone (educational)
- TUTORIAL.md: full tutorial in Portuguese
- examples/hello: sample port

Quick test:
  cd examples/hello
  ../../pkgmk build
  ../../pkgmk install -r ./rootfs
