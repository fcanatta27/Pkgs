# lfs-scripts + pkg (ports + binpkgs) — tutorial completo

Este diretório adapta o `lfs-scripts` para usar o **`pkg`** (do bundle `pkg_project`) como gerenciador de pacotes,
no lugar do fluxo original baseado em **pkgutils/pkgmk + prt-get**.

## O que foi feito nesta adaptação

- O binário `pkg` foi adicionado em `files/pkg` (copie para o sistema em `/usr/bin/pkg`).
- A árvore de ports original (`ports/`, formato CRUX) foi **auto-convertida** para `ports-pkg/` (formato `pkg`).
  - A conversão preserva as funções de build existentes (ex.: `bootstrap_build()` e `pkg_build()`), e injeta um `build()`
    “wrapper” compatível.
  - Compatibilidade: durante o build, `pkg` exporta `PKG="$DESTDIR"` para não quebrar Pkgfiles que fazem `make DESTDIR=$PKG`.
- Alguns ports “core” foram atualizados para versões mais recentes (ver seção “Atualizações aplicadas”).

## 1) Instalação do `pkg` no host (antes do chroot)

No host (seu sistema atual), copie o binário:

```sh
install -m 0755 files/pkg /usr/bin/pkg
```

Crie um arquivo de configuração (recomendado):

```sh
cat > /etc/pkg.conf << 'EOF'
# onde ficam os ports (use o caminho absoluto do seu checkout do lfs-scripts)
PKG_PORTS=/caminho/absoluto/para/lfs-scripts/ports-pkg

# estado e cache
PKG_ROOT=/var/lib/pkg
PKG_CACHE=/var/cache/pkg

# sysroot alvo: para o host, normalmente "/"
PKG_SYSROOT=/
EOF
```

Teste:

```sh
pkg --help
pkg search gcc
```

## 2) Conceitos (modelo do pkg)

- `pkg build <nome>`: compila o port e gera um binpkg no cache
- `pkg install <nome>`: resolve dependências, compila e instala a partir do binpkg
- `pkg upgrade <nome>` / `pkg upgrade-all`: atualiza se a versão do port ou o “build hash” mudou
- `pkg remove <nome>`: remove arquivos registrados daquele pacote
- `pkg revdep`: varredura básica de “missing shared libs” com opção `--rebuild`

Diretórios padrão:

- Banco (instalados): `/var/lib/pkg/db/<pkgname>`
- Logs: `/var/lib/pkg/log/<pkg>-<ver>-<rel>.log`
- Cache (fontes/binários/work): `/var/cache/pkg/{sources,binpkgs,work}`

## 3) Usando `ports-pkg/` no lugar de `ports/`

A árvore `ports-pkg/` mantém a mesma hierarquia de categorias do repositório original:

```text
ports-pkg/core/<pacote>/Pkgfile
ports-pkg/contrib/<pacote>/Pkgfile
```

Exemplo:

```sh
pkg --ports ./ports-pkg search openssl
pkg --ports ./ports-pkg install openssl
```

## 4) Bootstrap do LFS

O `bootstrap.sh` original permanece como referência e ainda descreve o fluxo de 4 estágios.
Nesta adaptação, o foco do `pkg` é assumir o gerenciamento de pacotes **no sistema final** (ports + deps + upgrade/revdep).

Recomendação prática:

1. Rode o **stage 1** do bootstrap (toolchain temporária) conforme `bootstrap.sh`.
2. A partir do **stage 2/3**, dentro do chroot, instale e mantenha o sistema com `pkg` usando `ports-pkg/`.

### 4.1 Copiando ports e o `pkg` para o sysroot do LFS

Assumindo que seu sysroot do LFS está em `/mnt/lfs`:

```sh
# copie a árvore de ports adaptada
rsync -a --delete ./ports-pkg/ /mnt/lfs/usr/ports-pkg/

# instale o pkg dentro do sysroot
install -m 0755 ./files/pkg /mnt/lfs/usr/bin/pkg

# crie o /etc/pkg.conf no sysroot
cat > /mnt/lfs/etc/pkg.conf << 'EOF'
PKG_PORTS=/usr/ports-pkg
PKG_ROOT=/var/lib/pkg
PKG_CACHE=/var/cache/pkg
PKG_SYSROOT=/
EOF
```

### 4.2 Instalando pacotes dentro do chroot

Depois de montar `/dev`, `/proc`, `/sys` etc (como no README) e entrar no chroot:

```sh
pkg install bash
pkg install coreutils
pkg install openssl
```

Para instalar um conjunto:

```sh
for p in zlib xz bzip2 ncurses readline perl python openssl curl; do
  pkg install "$p"
done
```

## 5) Atualização e manutenção pós-instalação

- Atualizar tudo que está instalado:

```sh
pkg upgrade-all
```

- Rebuild completo:

```sh
pkg rebuild-all
```

- Checagem de bibliotecas faltando:

```sh
pkg revdep
pkg revdep --rebuild
```

## 6) Atualizações aplicadas (best-effort)

Os ports abaixo foram atualizados para versões mais recentes e amplamente referenciadas em upstream:

- `binutils`: 2.45.1
- `gcc`: 15.2.0
- `linux-headers`: 6.18.2
- `openssl`: 3.5.4
- `python`: 3.14.2
- `coreutils`: 9.9

Observação importante: alguns ports (ex.: `glibc`) carregam patches específicos de uma versão anterior.
Atualizá-los “no automático” pode quebrar o build (patch não aplica). Para esses casos:
1) atualize o `version=...`, 2) revise/remova patches, 3) teste build.

## 7) Como criar/ajustar ports

Você pode criar um novo port no estilo `pkg` com:

```sh
pkg create-port core meu-pacote
```

No `Pkgfile`, mantenha sempre a instalação via `DESTDIR` (ou `PKG`, por compatibilidade):

```sh
pkg_build() {
  ./configure --prefix=/usr
  make
  make DESTDIR="$PKG" install
}
```
