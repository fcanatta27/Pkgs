Bundle gerado (2025-12-30)

Conteúdo:
- pkg_project/: gerenciador pkg (ports + binpkgs) com correções (mkdirp multi-args + compat PKG=DESTDIR)
- lfs-scripts-master/: lfs-scripts original + integração com pkg:
  - files/pkg (binário pkg)
  - ports-pkg/ (ports convertidos do formato CRUX para o formato do pkg)
  - docs/PKG_TUTORIAL.md (tutorial detalhado)
  - README.md ajustado para referências ao pkg

Notas:
- A conversão para ports-pkg é automática. Revise ports complexos (especialmente os que têm patches dependentes de versão).
- Foram atualizados alguns ports core para versões mais recentes (ver docs/PKG_TUTORIAL.md).
