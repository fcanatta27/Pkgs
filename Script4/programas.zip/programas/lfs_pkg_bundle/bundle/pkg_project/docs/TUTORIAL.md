# pkg — gerenciador de pacotes por ports (x86_64-linux-musl)

Este repositório entrega:

- `bin/pkg`: gerenciador em POSIX `sh` para **ports + binpkgs**
- `ports/`: árvore de ports no formato `categoria/pacote/Pkgfile`
- `docs/`: documentação e exemplos

## 1) Conceitos e diretórios

### 1.1 Variáveis principais

Você configura via `/etc/pkg.conf` (recomendado) ou variáveis de ambiente:

- `PKG_TARGET` (default: `x86_64-linux-musl`)
- `PKG_SYSROOT` (default: `/`) — raiz do sistema alvo
- `PKG_PORTS` (default: `/var/ports`) — árvore de ports
- `PKG_PORTS_GIT` — diretório git para `pkg sync` (pode ser o próprio `PKG_PORTS`)
- `PKG_ROOT` (default: `/var/lib/pkg`) — banco/estado
- `PKG_CACHE` (default: `/var/cache/pkg`) — cache de fontes, binários e workdir
- `PKG_COMPRESS` (`xz`, `gz`, `zst`) — formato de binpkg
- `PKG_JOBS` — paralelismo (padrão: `nproc`)

### 1.2 Estado interno

- DB de instalados: `$PKG_DB/<pkgname>`
- Logs: `$PKG_LOG/<pkgname>-<ver>-<rel>.log`
- Cache de fontes: `$PKG_SRCCACHE/<pkgname>/...`
- Cache de binários: `$PKG_BINPKG/<pkg>-<ver>-<rel>.<arch>.tar.*`

## 2) Instalação do `pkg`

1. Coloque `bin/pkg` no PATH (ex.: `/usr/bin/pkg`).
2. Crie `/etc/pkg.conf` conforme seu layout.

Exemplo de `/etc/pkg.conf`:

```sh
PKG_TARGET=x86_64-linux-musl
PKG_SYSROOT=/
PKG_PORTS=/var/ports
PKG_PORTS_GIT=/var/ports
PKG_ROOT=/var/lib/pkg
PKG_CACHE=/var/cache/pkg
PKG_COMPRESS=xz
```

## 3) Estrutura de ports

Um port é um diretório:

```
ports/<categoria>/<pkgname>/Pkgfile
```

Exemplo:

```
ports/core/musl/Pkgfile
```

### 3.1 Pkgfile (campos)

Um `Pkgfile` define variáveis e a função `build()`:

- `pkgname`, `pkgver`, `pkgrel`
- `pkgdesc`, `url`, `license`
- `depends` (runtime) e `makedepends` (build)
- `source` (URLs) + `sha256sums` **ou** `md5sums`
- `build()` deve instalar **sempre em `DESTDIR`** (já exportado pelo `pkg`)

O `pkg`:
- cria um workdir limpo
- baixa fontes para `SRC_DIR`
- descompacta em `BUILD_DIR`
- executa `build()` dentro de `BUILD_DIR`
- coleta lista de arquivos instalados em `DESTDIR`
- empacota em binpkg e instala no sistema (sysroot)

## 4) Comandos principais

### 4.1 Sincronizar ports (git)

```sh
pkg sync
```

Requer que `PKG_PORTS` seja um repositório git ou que `PKG_PORTS_GIT` aponte para um.

### 4.2 Buscar ports

```sh
pkg search gcc
pkg search core
```

### 4.3 Construir (sem instalar)

```sh
pkg build musl
```

Gera um binpkg no cache.

### 4.4 Instalar com dependências

```sh
pkg install musl
pkg install gcc
```

O `pkg` resolve dependências (detecção de ciclo), faz build em ordem topológica e instala sempre a partir do binpkg gerado.

### 4.5 Upgrade “inteligente”

```sh
pkg upgrade gcc
pkg upgrade-all
```

Critérios:
- se `pkgver` do port for maior que o instalado: recompila e instala
- se o **hash do Pkgfile/deps/checksums** mudou: recompila
- se dependências diretas foram instaladas/atualizadas após o pacote: recompila

### 4.6 Remover

```sh
pkg remove binutils
```

Remove somente arquivos registrados do pacote (não remove diretórios).

### 4.7 Rebuild total (sistema)

```sh
pkg rebuild-all
```

Percorre o banco e recompila/reinstala tudo, respeitando dependências port-a-port.

### 4.8 Revdep (broken linkage)

```sh
pkg revdep
pkg revdep --all
pkg revdep --rebuild
```

- Varre binários e `.so` em prefixos comuns sob `PKG_SYSROOT`
- Detecta `ldd ... not found`
- Mapeia arquivo -> pacote pelo DB e lista pacotes quebrados
- `--rebuild` recompila os pacotes detectados (dica: instale antes o port do provedor da lib ausente)

## 5) Dry-run, logs e auditoria

### 5.1 Dry-run

```sh
pkg --dry-run install gcc
```

Mostra comandos sem executá-los.

### 5.2 Logs

Cada build gera:

```
$PKG_LOG/<pkg>-<ver>-<rel>.log
```

## 6) Fontes: cache, esquemas e checksums

O `pkg` aceita (no campo `source`):

- `https://...` / `http://...` / `ftp://...` (via `curl -L`)
- `git+https://...#commit=<sha>` (ou `#tag=<tag>`, `#branch=<branch>`) — gera snapshot tar.xz
- `rsync://...` ou `host::module/path` (via `rsync`)
- `dir:/caminho/absoluto` (diretório ou arquivo local)

Cache:
- se já existe em `$PKG_SRCCACHE/<pkgname>/`, não baixa novamente

Verificação:
- compara sha256 (ou md5) conforme definido no `Pkgfile`
- se não bater: apaga e baixa novamente; se ainda não bater: erro

## 7) Criar um port novo

```sh
pkg create-port core meu-pacote
```

Gera um skeleton em `ports/core/meu-pacote/Pkgfile`.

## 8) Fluxos recomendados

### 8.1 Atualização completa do sistema

```sh
pkg sync
pkg upgrade-all
pkg revdep
```

### 8.2 Build e instalação isolada com diagnóstico

```sh
pkg build binutils
pkg install binutils
pkg revdep --all
```

## 9) Observações importantes

- O `pkg` assume que o **toolchain** para `PKG_TARGET` já está no PATH (ex.: `x86_64-linux-musl-gcc`).
- Ports de *bootstrap* (linux-headers/musl/binutils/gcc) geralmente exigem fases. Os Pkgfiles fornecidos aqui são um ponto de partida realista, mas podem exigir ajustes para o seu layout (sysroot, headers, paths) conforme sua toolchain.

