# pkg_project

Este bundle contém um protótipo funcional do `pkg` + ports exemplo.

Conteúdo:
- bin/pkg
- docs/TUTORIAL.md
- ports/core/*

Ajustes necessários antes de usar de fato:
1. Preencher `sha256sums` em cada Pkgfile.
2. Ajustar paths de sysroot e seu layout em `/etc/pkg.conf`.
3. Validar os Pkgfiles de bootstrap (linux-headers/musl/binutils/gcc) no seu ambiente.

