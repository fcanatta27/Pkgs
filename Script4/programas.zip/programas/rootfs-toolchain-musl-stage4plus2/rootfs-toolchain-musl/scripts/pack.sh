#!/bin/sh
# pack.sh - Create compressed tarballs of the rootfs by stage/profile.
# POSIX /bin/sh only.
#
# Examples:
#   ROOTFS=/mnt/rootfs OUTDIR=./artifacts ./scripts/pack.sh base
#   ROOTFS=/mnt/rootfs OUTDIR=./artifacts ./scripts/pack.sh full
#   ROOTFS=/mnt/rootfs OUTDIR=./artifacts ./scripts/pack.sh stage3
#
# Notes:
# - 'base' excludes build dirs, sources, logs/states, and /tools.
# - 'full' packs everything under ROOTFS.
# - 'stageN' packs the base + includes state/log dirs for that stage.

set -eu

ROOTFS=${ROOTFS:-/mnt/rootfs}
OUTDIR=${OUTDIR:-./artifacts}
NAME_PREFIX=${NAME_PREFIX:-rootfs}
COMPRESS=${COMPRESS:-gz}   # gz|xz|none
DATE_TAG=${DATE_TAG:-$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)}

msg(){ printf '%s
' "$*" >&2; }
die(){ msg "ERROR: $*"; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing command: $1"; }

need tar
[ -d "$ROOTFS" ] || die "ROOTFS not found: $ROOTFS"
mkdir -p "$OUTDIR"

tar_cmd() {
  # args: outfile excludes...
  out=$1; shift
  # use numeric owner for portability
  tar -C "$ROOTFS" --numeric-owner --xattrs --xattrs-include='*' -cf "$out" "$@" .
}

compress_file() {
  f=$1
  case "$COMPRESS" in
    gz) need gzip; gzip -9 "$f"; echo "$f.gz" ;;
    xz) need xz; xz -9 -T0 "$f"; echo "$f.xz" ;;
    none) echo "$f" ;;
    *) die "unknown COMPRESS: $COMPRESS" ;;
  esac
}

make_excludes_base() {
  cat <<'EOF'
--exclude=./sources
--exclude=./build-*
--exclude=./logs-*
--exclude=./state-*
--exclude=./var/cache/revdep
--exclude=./tools
EOF
}

profile=${1:-help}

case "$profile" in
  base)
    out="$OUTDIR/${NAME_PREFIX}-base-$DATE_TAG.tar"
    # shellcheck disable=SC2046
    tar -C "$ROOTFS" --numeric-owner -cf "$out" $(make_excludes_base) .
    final=$(compress_file "$out")
    msg "Wrote: $final"
    ;;
  full)
    out="$OUTDIR/${NAME_PREFIX}-full-$DATE_TAG.tar"
    tar -C "$ROOTFS" --numeric-owner -cf "$out" .
    final=$(compress_file "$out")
    msg "Wrote: $final"
    ;;
  stage0|stage1|stage2|stage3|stage4)
    out="$OUTDIR/${NAME_PREFIX}-${profile}-$DATE_TAG.tar"
    # include base but keep stage state/log for requested stage
    excl=$(make_excludes_base | grep -v "./logs-${profile#stage}" 2>/dev/null || true)
    # easiest: exclude base set, then re-include desired logs/state by not excluding them:
    # we implement by excluding all logs/state EXCEPT ones matching stage.
    # So: exclude logs-* and state-* but add exceptions by packing them separately.
    tmpdir="$OUTDIR/.packtmp.$$"
    rm -rf "$tmpdir"
    mkdir -p "$tmpdir"
    tar -C "$ROOTFS" --numeric-owner -cf "$tmpdir/base.tar" $(make_excludes_base) .
    tar -C "$ROOTFS" --numeric-owner -cf "$tmpdir/extra.tar" "./logs-${profile#stage}" "./state-${profile#stage}" 2>/dev/null || :
    tar -C "$tmpdir" -cf "$out" base.tar extra.tar
    rm -rf "$tmpdir"
    final=$(compress_file "$out")
    msg "Wrote: $final"
    ;;
  help|-h|--help)
    cat <<EOF
Usage: $0 {base|full|stage0|stage1|stage2|stage3|stage4}
Env:
  ROOTFS=/mnt/rootfs
  OUTDIR=./artifacts
  NAME_PREFIX=rootfs
  COMPRESS=gz|xz|none
EOF
    ;;
  *)
    die "unknown profile: $profile"
    ;;
esac
