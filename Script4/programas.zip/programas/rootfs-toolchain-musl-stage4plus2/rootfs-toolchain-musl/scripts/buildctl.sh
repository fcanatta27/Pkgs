#!/bin/sh
# buildctl.sh - POSIX helpers: markers, logs, install manifests, and a colored progress UI.

# Configuration (can be overridden by caller)
: "${COLOR:=auto}"
: "${STATE_DIR:=}"
: "${LOG_DIR:=}"
: "${PKGDB_DIR:=}"

is_tty() { [ -t 1 ] && [ -t 2 ]; }

use_color() {
  case "$COLOR" in
    always) return 0 ;;
    never) return 1 ;;
    auto) is_tty ;;
    *) is_tty ;;
  esac
}

c_reset='' c_bold='' c_dim='' c_red='' c_green='' c_yellow='' c_blue='' c_magenta='' c_cyan=''
if use_color; then
  c_reset='\033[0m'
  c_bold='\033[1m'
  c_dim='\033[2m'
  c_red='\033[31m'
  c_green='\033[32m'
  c_yellow='\033[33m'
  c_blue='\033[34m'
  c_magenta='\033[35m'
  c_cyan='\033[36m'
fi

msg() { printf '%s\n' "$*" >&2; }
info() { msg "${c_cyan}INFO${c_reset}  $*"; }
warn() { msg "${c_yellow}WARN${c_reset}  $*"; }
err() { msg "${c_red}ERROR${c_reset} $*"; }
die() { err "$*"; exit 1; }

ensure_dir() { [ -d "$1" ] || mkdir -p "$1"; }

marker_has() { [ -n "$STATE_DIR" ] && [ -f "$STATE_DIR/$1.ok" ]; }
marker_set() { [ -n "$STATE_DIR" ] || return 0; ensure_dir "$STATE_DIR"; : >"$STATE_DIR/$1.ok"; }

# progress_bar CURRENT TOTAL "label"
progress_bar() {
  cur=$1 total=$2 label=$3
  if [ "$total" -le 0 ]; then
    msg "==> $label"
    return 0
  fi
  pct=$(( (cur * 100) / total ))
  msg "${c_bold}==>${c_reset} [$cur/$total] (${pct}%) $label"
}

run_logged() { # run_logged STEP CMD...
  step=$1; shift
  if [ -n "$LOG_DIR" ]; then
    ensure_dir "$LOG_DIR"
    log="$LOG_DIR/$step.log"
    ( set -eu; "$@" ) >"$log" 2>&1
  else
    "$@"
  fi
}

# Install manifest helpers (for source installs without a package manager).
# These are intended to be used *inside chroot* (where /usr exists).
# They record which files were added by an install so later removal is possible.
#
# Usage inside chroot:
#   pkg_begin <name>
#   make install
#   pkg_end <name>
#
pkg_begin() {
  name=$1
  [ -n "$PKGDB_DIR" ] || return 0
  ensure_dir "$PKGDB_DIR/manifests"
  snap="$PKGDB_DIR/.snap.$name"
  # Focus on common install roots. Keep it reasonably fast.
  ( find /bin /sbin /lib /usr -xdev \( -type f -o -type l \) 2>/dev/null | sort ) >"$snap"
}

pkg_end() {
  name=$1
  [ -n "$PKGDB_DIR" ] || return 0
  snap="$PKGDB_DIR/.snap.$name"
  out="$PKGDB_DIR/manifests/$name.list"
  [ -f "$snap" ] || return 0
  ( find /bin /sbin /lib /usr -xdev \( -type f -o -type l \) 2>/dev/null | sort ) >"$snap.new"
  # New files only
  comm -13 "$snap" "$snap.new" >"$out" 2>/dev/null || :
  rm -f "$snap" "$snap.new"
}


status_line() { # status_line CUR TOTAL LABEL
  progress_bar "$1" "$2" "$3"
}
