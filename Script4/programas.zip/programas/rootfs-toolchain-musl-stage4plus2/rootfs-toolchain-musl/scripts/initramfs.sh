#!/bin/sh
# initramfs.sh - Minimal but capable initramfs generator (no dracut).
# POSIX /bin/sh only.
#
# Generates an initramfs cpio (optionally compressed) using files from ROOTFS.
#
# Typical use:
#   ROOTFS=/mnt/rootfs OUTDIR=/mnt/rootfs/boot INITRAMFS_NAME=initramfs.img \
#   KVER=6.x.y ROOTDEV=/dev/sda2 FS=ext4 ./scripts/initramfs.sh build
#
# This script is intended for Stage3/Stage4 workflows where you want a flexible boot.
#
# Limitations:
# - A real-world initramfs often needs distro-specific logic. This stays compact and explicit.

set -eu

ROOTFS=${ROOTFS:-/mnt/rootfs}
OUTDIR=${OUTDIR:-$ROOTFS/boot}
WORKDIR=${WORKDIR:-$ROOTFS/build-initramfs}
INITRAMFS_NAME=${INITRAMFS_NAME:-initramfs.cpio.gz}

# Kernel version whose modules we should include (optional but recommended)
KVER=${KVER:-}

# Root device and filesystem (used by init)
ROOTDEV=${ROOTDEV:-/dev/sda2}
FS=${FS:-ext4}

# Compression: none|gzip|xz
COMPRESS=${COMPRESS:-gzip}

# Busybox source inside ROOTFS
BUSYBOX_BIN=${BUSYBOX_BIN:-/bin/busybox}

# Extra binaries to include (space-separated paths inside ROOTFS)
EXTRA_BINS=${EXTRA_BINS:-"/bin/sh /bin/mount /bin/umount /sbin/modprobe /sbin/switch_root"}

# Extra kernel modules (space-separated, without .ko suffix). Optional.
# Examples: "ext4 vfat nvme ahci xhci_pci usb_storage usbhid virtio_pci virtio_blk virtio_scsi"
MODULES=${MODULES:-"ext4 vfat nvme ahci xhci_pci ehci_pci uhci_hcd usb_storage usbhid virtio_pci virtio_blk virtio_scsi"}

# Library search paths inside ROOTFS for dependency copying
LIB_PATHS=${LIB_PATHS:-"/lib /usr/lib"}

msg(){ printf '%s\n' "$*" >&2; }
die(){ msg "ERROR: $*"; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing command: $1"; }

ensure(){ [ -d "$1" ] || mkdir -p "$1"; }

# Copy a file from ROOTFS into initramfs tree preserving directories
copy_in() {
  src=$1
  dst_root=$2
  [ -e "$ROOTFS$src" ] || return 0
  d=$(dirname "$dst_root$src")
  ensure "$d"
  cp -a "$ROOTFS$src" "$dst_root$src"
}

# Detect NEEDED libs for an ELF file in ROOTFS using readelf
needed_libs() {
  f=$1
  # readelf output is stable enough; we extract 'Shared library: [name]'
  readelf -d "$ROOTFS$f" 2>/dev/null | awk -F'[][]' '/Shared library: \[/{print $2}'
}

find_lib() {
  name=$1
  for p in $LIB_PATHS; do
    if [ -e "$ROOTFS$p/$name" ]; then
      printf '%s/%s\n' "$p" "$name"
      return 0
    fi
  done
  return 1
}

copy_deps_recursive() {
  f=$1
  out=$2
  # Copy loader and libc as well if referenced
  for lib in $(needed_libs "$f"); do
    path=$(find_lib "$lib" || :)
    [ -n "$path" ] || continue
    if [ ! -e "$out$path" ]; then
      copy_in "$path" "$out"
      # recurse if the lib itself has deps
      copy_deps_recursive "$path" "$out" || :
    fi
  done
}

write_init() {
  out=$1
  ensure "$out/initramfs"
  cat >"$out/init" <<EOF
#!/bin/sh
# initramfs init (busybox)

export PATH=/bin:/sbin:/usr/bin:/usr/sbin

mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev 2>/dev/null || mount -t tmpfs tmpfs /dev
mkdir -p /dev/pts
mount -t devpts devpts /dev/pts

echo "initramfs: loading modules..."
for m in $MODULES; do
  modprobe "\$m" 2>/dev/null || :
done

echo "initramfs: waiting for root device $ROOTDEV ..."
i=0
while [ ! -e "$ROOTDEV" ] && [ "\$i" -lt 30 ]; do
  sleep 1
  i=\$((i+1))
done

mkdir -p /newroot
mount -t $FS -o ro "$ROOTDEV" /newroot || mount -t $FS "$ROOTDEV" /newroot || {
  echo "initramfs: failed to mount root ($ROOTDEV) as $FS"
  exec sh
}

echo "initramfs: switching to real root..."
exec switch_root /newroot /sbin/init
EOF
  chmod 0755 "$out/init"
}

copy_modules() {
  out=$1
  [ -n "$KVER" ] || return 0
  moddir="/lib/modules/$KVER"
  [ -d "$ROOTFS$moddir" ] || die "modules directory not found in ROOTFS: $moddir (set KVER)"
  ensure "$out$moddir"
  # Copy module tree; for compactness you may prune later
  cp -a "$ROOTFS$moddir" "$out/lib/modules/"
}

build_initramfs() {
  need awk
  need readelf
  need find
  need cpio
  ensure "$OUTDIR" "$WORKDIR"
  out="$WORKDIR/tree"
  rm -rf "$out"
  ensure "$out"

  # Minimal directories
  ensure "$out/bin" "$out/sbin" "$out/proc" "$out/sys" "$out/dev" "$out/usr/bin" "$out/usr/sbin" "$out/lib" "$out/usr/lib"

  # Busybox
  [ -x "$ROOTFS$BUSYBOX_BIN" ] || die "busybox not found/executable in ROOTFS: $BUSYBOX_BIN"
  copy_in "$BUSYBOX_BIN" "$out"
  # Ensure common applets
  for app in sh mount umount mkdir mknod ln cp mv rm cat echo dmesg modprobe switch_root sleep; do
    if [ ! -e "$out/bin/$app" ] && [ ! -e "$out/sbin/$app" ]; then
      ln -s busybox "$out/bin/$app" 2>/dev/null || :
    fi
  done

  # Extra binaries
  for b in $EXTRA_BINS; do
    [ -e "$ROOTFS$b" ] || continue
    copy_in "$b" "$out"
    copy_deps_recursive "$b" "$out" || :
  done

  # Copy musl loader if present
  if [ -e "$ROOTFS/lib/ld-musl-x86_64.so.1" ]; then
    copy_in "/lib/ld-musl-x86_64.so.1" "$out"
  fi

  # Copy modules (optional)
  copy_modules "$out"

  # Create init
  write_init "$out"

  # Pack
  img="$OUTDIR/$INITRAMFS_NAME"
  tmp="$WORKDIR/initramfs.cpio"
  ( cd "$out" && find . -print0 | cpio -0 -H newc -o ) >"$tmp"

  case "$COMPRESS" in
    none)
      mv "$tmp" "$img"
      ;;
    gzip)
      need gzip
      gzip -c "$tmp" >"$img"
      rm -f "$tmp"
      ;;
    xz)
      need xz
      xz -c "$tmp" >"$img"
      rm -f "$tmp"
      ;;
    *)
      die "unknown COMPRESS: $COMPRESS (none|gzip|xz)"
      ;;
  esac

  msg "initramfs generated: $img"
}

usage() {
  cat <<EOF
Usage:
  $0 build

Env (most important):
  ROOTFS=/mnt/rootfs
  OUTDIR=/mnt/rootfs/boot
  INITRAMFS_NAME=initramfs.cpio.gz
  KVER=6.x.y
  ROOTDEV=/dev/sda2
  FS=ext4
  COMPRESS=gzip|xz|none
  MODULES="ext4 ..."

EOF
}

cmd=${1:-help}
case "$cmd" in
  build) build_initramfs ;;
  -h|--help|help) usage ;;
  *) die "unknown command: $cmd" ;;
esac
