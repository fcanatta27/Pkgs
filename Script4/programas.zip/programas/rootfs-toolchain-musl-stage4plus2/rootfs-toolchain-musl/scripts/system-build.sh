#!/bin/sh
# system-build.sh - Orchestrate Stage0..Stage4 with progress UI, manifests, packing and ISO.
# POSIX /bin/sh only.

set -eu

ROOTFS=${ROOTFS:-/mnt/rootfs}
JOBS=${JOBS:-1}

SCRIPTS_DIR=${SCRIPTS_DIR:-./scripts}

# Default pipeline
PIPELINE=${PIPELINE:-"stage0 stage1 stage2 stage3 stage4"}

# Option: remove build directories after successful stages (0/1)
CLEAN_AFTER=${CLEAN_AFTER:-0}

# UI
COLOR=${COLOR:-auto}

msg(){ printf '%s\n' "$*" >&2; }
die(){ msg "ERROR: $*"; exit 1; }

need(){ command -v "$1" >/dev/null 2>&1 || die "missing command: $1"; }

. "$SCRIPTS_DIR/buildctl.sh"

stage_script() {
  st=$1
  case "$st" in
    stage0) echo "./build.sh" ;;
    stage1) echo "$SCRIPTS_DIR/stage1.sh" ;;
    stage2) echo "$SCRIPTS_DIR/stage2.sh" ;;
    stage3) echo "$SCRIPTS_DIR/stage3.sh" ;;
    stage4) echo "$SCRIPTS_DIR/stage4.sh" ;;
    *) die "unknown stage: $st" ;;
  esac
}

stage_cmd() {
  st=$1
  case "$st" in
    stage0) echo "all" ;;
    *) echo "all" ;;
  esac
}

host_doctor() {
  # Real checks (host-side) for tools used by orchestration.
  need sh
  need tar
  need gzip
  need awk
  need mount
  need umount
  need chroot
  need find
  need sort
  need comm
  msg "Host doctor: OK"
}

run_one() {
  st=$1
  script=$(stage_script "$st")
  [ -x "$script" ] || die "stage script not executable: $script"

  msg ""
  msg "===== Running $st ====="

  # Export environment common to all scripts
  export ROOTFS JOBS COLOR

  if [ "$st" = "stage0" ]; then
    "$script" "$(stage_cmd "$st")"
  else
    "$script" "$(stage_cmd "$st")"
  fi

  if [ "$CLEAN_AFTER" = "1" ]; then
    clean_builddirs "$st"
  fi
}

run_pipeline() {
  host_doctor
  set -- $PIPELINE
  total=$#
  cur=0
  for st in $PIPELINE; do
    cur=$((cur+1))
    status_line "$cur" "$total" "$st"
    run_one "$st"
  done
  status_line "$total" "$total" "done"
  msg "Pipeline complete."
}

status() {
  msg "ROOTFS=$ROOTFS"
  for st in stage0 stage1 stage2 stage3 stage4; do
    case "$st" in
      stage0) sd="$ROOTFS/build-toolchain/state" ;;
      stage1) sd="$ROOTFS/state-stage1" ;;
      stage2) sd="$ROOTFS/state-stage2" ;;
      stage3) sd="$ROOTFS/state-stage3" ;;
      stage4) sd="$ROOTFS/state-stage4" ;;
    esac
    if [ -d "$sd" ]; then
      donec=$(ls -1 "$sd" 2>/dev/null | wc -l | tr -d ' ')
      msg "$st: markers=$donec dir=$sd"
    else
      msg "$st: (no state dir)"
    fi
  done
  if [ -d "$ROOTFS/var/lib/stage-build/manifests" ]; then
    msg "manifests: $ROOTFS/var/lib/stage-build/manifests"
  fi
}

clean_builddirs() {
  st=${1:-all}
  case "$st" in
    stage0|all) rm -rf "$ROOTFS/build-toolchain" ;;
  esac
  case "$st" in
    stage1|all) rm -rf "$ROOTFS/build-stage1" ;;
  esac
  case "$st" in
    stage2|all) rm -rf "$ROOTFS/build-stage2" ;;
  esac
  case "$st" in
    stage3|all) rm -rf "$ROOTFS/build-stage3" "$ROOTFS/build-initramfs" ;;
  esac
  case "$st" in
    stage4|all) rm -rf "$ROOTFS/build-stage4" ;;
  esac
  msg "Cleaned build dirs for: $st"
}

remove_toolchain() {
  [ -d "$ROOTFS/tools" ] || { msg "No toolchain dir: $ROOTFS/tools"; return 0; }
  msg "Removing toolchain: $ROOTFS/tools"
  rm -rf "$ROOTFS/tools"
}

remove_pkg() {
  name=$1
  mdir="$ROOTFS/var/lib/stage-build/manifests"
  list="$mdir/$name.list"
  [ -f "$list" ] || die "manifest not found: $list"
  msg "Removing files listed in: $list"
  while IFS= read -r p; do
    [ -n "$p" ] || continue
    case "$p" in
      /*) : ;;
      *) continue ;;
    esac
    # safety: only remove under /bin,/sbin,/lib,/usr
    case "$p" in
      /bin/*|/sbin/*|/lib/*|/usr/*) rm -f "$ROOTFS$p" 2>/dev/null || : ;;
      *) : ;;
    esac
  done <"$list"
  rm -f "$list"
  msg "Removed package: $name"
}

pack() {
  profile=${1:-base}
  OUTDIR=${OUTDIR:-./artifacts}
  export ROOTFS OUTDIR
  "$SCRIPTS_DIR/pack.sh" "$profile"
}

mkiso() {
  ISO_OUT=${ISO_OUT:-./artifacts/rootfs.iso}
  export ROOTFS ISO_OUT
  "$SCRIPTS_DIR/mkiso.sh" build
}

usage() {
  cat <<EOF
Usage: $0 <command>

Commands:
  build                 Run PIPELINE (default: "$PIPELINE")
  status                Show stage markers/manifests
  doctor                Host tool checks
  clean-builddirs [st]   Remove build dirs (st=stage0..stage4|all)
  remove-toolchain       Remove /tools from ROOTFS
  remove-pkg <name>      Remove a package installed with manifest tracking
  pack [profile]         Create tarball: base|full|stage0..stage4
  mkiso                  Create ISO (requires host tools; optional)

Env:
  ROOTFS=/mnt/rootfs
  JOBS=4
  PIPELINE="stage0 stage1 stage2 stage3 stage4"
  CLEAN_AFTER=0|1
  OUTDIR=./artifacts
  ISO_OUT=./artifacts/rootfs.iso
EOF
}

cmd=${1:-build}
case "$cmd" in
  build) run_pipeline ;;
  status) status ;;
  doctor) host_doctor ;;
  clean-builddirs) clean_builddirs "${2:-all}" ;;
  remove-toolchain) remove_toolchain ;;
  remove-pkg) [ $# -ge 2 ] || die "remove-pkg requires a name"; remove_pkg "$2" ;;
  pack) pack "${2:-base}" ;;
  mkiso) mkiso ;;
  -h|--help|help) usage ;;
  *) usage; die "unknown command: $cmd" ;;
esac
