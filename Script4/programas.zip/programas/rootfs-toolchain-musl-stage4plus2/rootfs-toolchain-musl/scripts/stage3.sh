#!/bin/sh
# stage3.sh - Build the final system (Stage3) inside ROOTFS (musl x86_64).
# POSIX /bin/sh only. Resumable via markers; per-step logs.
#
# Scope: a compact but complete base suitable to build further software:
# - init: runit
# - base: filesystem layout, configs, users skeleton
# - networking: iproute2 + dhcpcd
# - wifi: iw + wpa_supplicant (+ deps)
# - kernel: Linux + modules install
# - boot: GRUB UEFI (optional; requires ESP mounted)
# - apps: vim + w3m (ncurses-based)
# - health: revdep scan

set -eu

###############################################################################
# Configuration (edit here or override via environment)
###############################################################################

ROOTFS=${ROOTFS:-/mnt/rootfs}
SRCDIR=${SRCDIR:-$ROOTFS/sources}
BUILDDIR=${BUILDDIR:-$ROOTFS/build-stage3}
STATE=${STATE:-$ROOTFS/state-stage3}
LOGDIR=${LOGDIR:-$ROOTFS/logs-stage3}

JOBS=${JOBS:-1}

# Tooling
CHROOT_RUN=${CHROOT_RUN:-./scripts/chroot-run.sh}
PATH_IN_CHROOT=${PATH_IN_CHROOT:-/usr/bin:/bin:/usr/sbin:/sbin:/tools/bin}

# Enable/disable feature bundles
ENABLE_WIFI=${ENABLE_WIFI:-1}
ENABLE_AUDIO=${ENABLE_AUDIO:-1}
ENABLE_VIDEO_MIN=${ENABLE_VIDEO_MIN:-1}
ENABLE_GRUB_UEFI=${ENABLE_GRUB_UEFI:-1}

# Kernel
LINUX_VER=${LINUX_VER:-6.18.2}
KERNEL_ARCH=${KERNEL_ARCH:-x86_64}
KERNEL_DEFCONFIG=${KERNEL_DEFCONFIG:-defconfig}
# If set, points to a kernel .config file on the host (will be bind-mounted if you add it)
KERNEL_CONFIG_FILE=${KERNEL_CONFIG_FILE:-}

# Boot/UEFI (you must mount ESP at $ESP_MOUNT inside ROOTFS)
ESP_MOUNT=${ESP_MOUNT:-/boot/efi}
GRUB_EFI_TARGET=${GRUB_EFI_TARGET:-x86_64-efi}
GRUB_EFI_DIR=${GRUB_EFI_DIR:-EFI}
GRUB_BOOTLOADER_ID=${GRUB_BOOTLOADER_ID:-MUSLROOT}
# If empty, stage3 will skip grub-install and only build+install grub binaries.
GRUB_DISK=${GRUB_DISK:-}

# System identity
HOSTNAME=${HOSTNAME:-muslbox}
TZ=${TZ:-UTC}
LOCALE=${LOCALE:-C}

# Build flags (safe defaults)
CFLAGS_BASE=${CFLAGS_BASE:--O2 -pipe}
CFLAGS_HARDEN=${CFLAGS_HARDEN:--fstack-protector-strong -D_FORTIFY_SOURCE=2}
CFLAGS=${CFLAGS:-$CFLAGS_BASE $CFLAGS_HARDEN}
CXXFLAGS=${CXXFLAGS:-$CFLAGS}
LDFLAGS=${LDFLAGS:--Wl,-z,relro -Wl,-z,now}

# Versions (adjust to your tarballs)
RUNIT_VER=${RUNIT_VER:-2.1.2}
E2FSPROGS_VER=${E2FSPROGS_VER:-1.47.2}
KMOD_VER=${KMOD_VER:-34}
EUDEV_VER=${EUDEV_VER:-3.2.14}
IPROUTE2_VER=${IPROUTE2_VER:-6.16.0}
DHCPCD_VER=${DHCPCD_VER:-10.2.4}
OPENSSL_VER=${OPENSSL_VER:-3.5.2}
ZLIB_VER=${ZLIB_VER:-1.3.1}
LIBNL_VER=${LIBNL_VER:-3.11.0}
IW_VER=${IW_VER:-6.9}
WPA_SUPP_VER=${WPA_SUPP_VER:-2.11}
ALSA_LIB_VER=${ALSA_LIB_VER:-1.2.14}
ALSA_UTILS_VER=${ALSA_UTILS_VER:-1.2.14}
NCURSES_VER=${NCURSES_VER:-6.5}
VIM_VER=${VIM_VER:-9.1.1200}
W3M_VER=${W3M_VER:-0.5.3}
GRUB_VER=${GRUB_VER:-2.12}
EFIBOOTMGR_VER=${EFIBOOTMGR_VER:-18}
DOSFSTOOLS_VER=${DOSFSTOOLS_VER:-4.2}
MTOOLS_VER=${MTOOLS_VER:-4.0.48}
CPIO_VER=${CPIO_VER:-2.15}
IPUTILS_VER=${IPUTILS_VER:-20240905}
PROCPS_VER=${PROCPS_VER:-4.0.5}
PSMISC_VER=${PSMISC_VER:-23.7}
KBD_VER=${KBD_VER:-2.6.4}
TZDATA_VER=${TZDATA_VER:-2025b}

# Optional features
ENABLE_INITRAMFS=${ENABLE_INITRAMFS:-0}  # 1 to generate initramfs after kernel install
INITRAMFS_NAME=${INITRAMFS_NAME:-initramfs.cpio.gz}
ROOTDEV=${ROOTDEV:-/dev/sda2}
ROOTFS_TYPE=${ROOTFS_TYPE:-ext4}
INITRAMFS_COMPRESS=${INITRAMFS_COMPRESS:-gzip} # gzip|xz|none
TRACK_INSTALLS=${TRACK_INSTALLS:-1} # 1 to record install manifests under /var/lib/stage-build

###############################################################################
# Helpers
###############################################################################

umask 022

msg(){ printf '%s\n' "$*" >&2; }
die(){ msg "ERROR: $*"; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing command: $1"; }
ensure(){ [ -d "$1" ] || mkdir -p "$1"; }

# locate tarball by common extensions
find_tb() {
  name=$1 ver=$2
  for ext in tar.xz tar.gz tgz tar.bz2 tar; do
    p="$SRCDIR/$name-$ver.$ext"
    [ -f "$p" ] && { printf '%s\n' "$p"; return 0; }
  done
  return 1
}

# run a command string inside chroot with binds for /sources and /build
chrun(){
  ROOTFS="$ROOTFS" PATH_IN_CHROOT="$PATH_IN_CHROOT" \
  BIND_MOUNTS="${BIND_MOUNTS:-$SRCDIR:/sources $BUILDDIR:/build}" \
  BIND_RO_MOUNTS="${BIND_RO_MOUNTS:-}" \
  "$CHROOT_RUN" run "$1"
}

# Progress UI using buildctl.sh
. ./scripts/buildctl.sh
STATE_DIR=$STATE
LOG_DIR=$LOGDIR

step_do() { # step_do INDEX TOTAL NAME FUNC
  i=$1 total=$2 name=$3 fn=$4
  if marker_has "$name"; then
    status_line "$i" "$total" "$name (skip)"
    return 0
  fi
  status_line "$i" "$total" "$name"
  run_logged "$name" "$fn"
  marker_set "$name"
}

###############################################################################
# Steps (host-side wrappers; heavy work happens inside chroot)
###############################################################################

s00_prep(){
  need tar
  need "$CHROOT_RUN"
  ensure "$BUILDDIR" "$STATE" "$LOGDIR"
  ensure "$ROOTFS/etc" "$ROOTFS/var" "$ROOTFS/usr" "$ROOTFS/boot"
}

s10_layout_configs(){
  # Minimal filesystem layout and baseline configs
  ensure "$ROOTFS/etc" "$ROOTFS/etc/runit" "$ROOTFS/etc/runit/runsvdir" \
         "$ROOTFS/etc/runit/runsvdir/default" "$ROOTFS/etc/service" \
         "$ROOTFS/var/log" "$ROOTFS/var/lib" "$ROOTFS/root" "$ROOTFS/home" \
         "$ROOTFS/tmp" "$ROOTFS/var/tmp" "$ROOTFS/run" "$ROOTFS/dev" \
         "$ROOTFS/proc" "$ROOTFS/sys" "$ROOTFS/mnt"
  chmod 1777 "$ROOTFS/tmp" "$ROOTFS/var/tmp" || :

  # /etc files
  {
    printf '%s\n' "$HOSTNAME"
  } >"$ROOTFS/etc/hostname"

  {
    printf '%s\n' "127.0.0.1\tlocalhost"
    printf '%s\n' "::1\tlocalhost"
    printf '%s\n' "127.0.1.1\t$HOSTNAME"
  } >"$ROOTFS/etc/hosts"

  {
    printf '%s\n' "nameserver 1.1.1.1"
    printf '%s\n' "nameserver 8.8.8.8"
  } >"$ROOTFS/etc/resolv.conf"

  {
    printf '%s\n' "# <fs> <mountpoint> <type> <opts> <dump> <pass>"
    printf '%s\n' "proc /proc proc nosuid,noexec,nodev 0 0"
    printf '%s\n' "sysfs /sys sysfs nosuid,noexec,nodev 0 0"
    printf '%s\n' "devtmpfs /dev devtmpfs nosuid 0 0"
    printf '%s\n' "tmpfs /run tmpfs nosuid,nodev,mode=0755 0 0"
  } >"$ROOTFS/etc/fstab"

  # Timezone placeholder
  ensure "$ROOTFS/etc"
  printf '%s\n' "$TZ" >"$ROOTFS/etc/timezone"

  # rc.local (optional)
  ensure "$ROOTFS/etc"
  {
    printf '%s\n' '#!/bin/sh'
    printf '%s\n' '# local startup commands'
    printf '%s\n' 'exit 0'
  } >"$ROOTFS/etc/rc.local"
  chmod 0755 "$ROOTFS/etc/rc.local" || :

  # Install revdep helper into the target (GPL-licensed; see LICENSES/)
  if [ -f ./scripts/revdep.sh ]; then
    mkdir -p "$ROOTFS/usr/sbin"
    cp ./scripts/revdep.sh "$ROOTFS/usr/sbin/revdep.sh"
    chmod 0755 "$ROOTFS/usr/sbin/revdep.sh" || :
  fi

  # Install revdep helper into the target (GPL-licensed file; see LICENSES/)
  if [ -f ./scripts/revdep.sh ]; then
    mkdir -p \"$ROOTFS/usr/sbin\"
    cp ./scripts/revdep.sh \"$ROOTFS/usr/sbin/revdep.sh\"
    chmod 0755 \"$ROOTFS/usr/sbin/revdep.sh\" || :
  fi
}

s20_build_base_pkgs(){
  # Builds inside chroot: zlib, openssl, e2fsprogs, kmod, eudev
  ztb=$(find_tb zlib "$ZLIB_VER") || die "missing zlib-$ZLIB_VER"
  otb=$(find_tb openssl "$OPENSSL_VER") || die "missing openssl-$OPENSSL_VER"
  etb=$(find_tb e2fsprogs "$E2FSPROGS_VER") || die "missing e2fsprogs-$E2FSPROGS_VER"
  ktb=$(find_tb kmod "$KMOD_VER") || die "missing kmod-$KMOD_VER"
  utb=$(find_tb eudev "$EUDEV_VER") || die "missing eudev-$EUDEV_VER"

  chrun "
set -eu
cd /build
export CFLAGS='$CFLAGS'
export CXXFLAGS='$CXXFLAGS'
export LDFLAGS='$LDFLAGS'

# zlib
rm -rf zlib-$ZLIB_VER
tar -xf /sources/$(basename "$ztb")
cd zlib-$ZLIB_VER
./configure --prefix=/usr
make -j$JOBS
make install
cd /build

# openssl (static+shared)
rm -rf openssl-$OPENSSL_VER
tar -xf /sources/$(basename "$otb")
cd openssl-$OPENSSL_VER
./Configure linux-x86_64 --prefix=/usr --openssldir=/etc/ssl shared no-ssl3 no-comp
make -j$JOBS
make install_sw install_ssldirs
cd /build

# e2fsprogs
rm -rf e2fsprogs-$E2FSPROGS_VER e2fsprogs-build
tar -xf /sources/$(basename "$etb")
mkdir -p e2fsprogs-build
cd e2fsprogs-build
../e2fsprogs-$E2FSPROGS_VER/configure --prefix=/usr --sysconfdir=/etc --enable-elf-shlibs
make -j$JOBS
make install
cd /build

# kmod
rm -rf kmod-$KMOD_VER kmod-build
tar -xf /sources/$(basename "$ktb")
mkdir -p kmod-build
cd kmod-build
../kmod-$KMOD_VER/configure --prefix=/usr --sysconfdir=/etc --with-xz --with-zlib
make -j$JOBS
make install
# convenience symlinks
ln -sf ../bin/kmod /usr/sbin/depmod
ln -sf ../bin/kmod /usr/sbin/insmod
ln -sf ../bin/kmod /usr/sbin/lsmod
ln -sf ../bin/kmod /usr/sbin/modinfo
ln -sf ../bin/kmod /usr/sbin/modprobe
ln -sf ../bin/kmod /usr/sbin/rmmod
cd /build

# eudev (device manager)
rm -rf eudev-$EUDEV_VER eudev-build
tar -xf /sources/$(basename "$utb")
mkdir -p eudev-build
cd eudev-build
../eudev-$EUDEV_VER/configure --prefix=/usr --sysconfdir=/etc --sbindir=/usr/sbin --libdir=/usr/lib --enable-manpages=no
make -j$JOBS
make install
# minimal udev rules dir
mkdir -p /etc/udev/rules.d /usr/lib/udev/rules.d
"
}

s30_runit(){
  rtb=$(find_tb runit "$RUNIT_VER") || die "missing runit-$RUNIT_VER"
  chrun "
set -eu
cd /build
rm -rf runit-$RUNIT_VER
tar -xf /sources/$(basename "$rtb")
cd runit-$RUNIT_VER
# runit uses its own build system; ensure compiler flags are respected where possible
make -j$JOBS
make install
# Ensure /sbin/init exists
ln -sf /sbin/runit-init /sbin/init
# Basic runit stage scripts
mkdir -p /etc/runit
cat > /etc/runit/1 <<'S1'
#!/bin/sh
PATH=/usr/bin:/bin:/usr/sbin:/sbin
mount -t proc proc /proc 2>/dev/null || :
mount -t sysfs sysfs /sys 2>/dev/null || :
mount -t devtmpfs devtmpfs /dev 2>/dev/null || :
mkdir -p /dev/pts
mount -t devpts devpts /dev/pts 2>/dev/null || :
mkdir -p /run
# start udev
if command -v udevd >/dev/null 2>&1; then
  udevd --daemon 2>/dev/null || :
  udevadm trigger --type=subsystems --action=add 2>/dev/null || :
  udevadm trigger --type=devices --action=add 2>/dev/null || :
  udevadm settle 2>/dev/null || :
fi
# local hooks
[ -x /etc/rc.local ] && /etc/rc.local || :
exit 0
S1
chmod 0755 /etc/runit/1

cat > /etc/runit/2 <<'S2'
#!/bin/sh
PATH=/usr/bin:/bin:/usr/sbin:/sbin
# runsvdir will manage services in /etc/service
exec runsvdir -P /etc/service
S2
chmod 0755 /etc/runit/2

cat > /etc/runit/3 <<'S3'
#!/bin/sh
PATH=/usr/bin:/bin:/usr/sbin:/sbin
# shutdown sequence
sync
umount -a -r 2>/dev/null || :
exit 0
S3
chmod 0755 /etc/runit/3
"
}

s40_network(){
  itb=$(find_tb iproute2 "$IPROUTE2_VER") || die "missing iproute2-$IPROUTE2_VER"
  dtb=$(find_tb dhcpcd "$DHCPCD_VER") || die "missing dhcpcd-$DHCPCD_VER"

  chrun "
set -eu
cd /build
export CFLAGS='$CFLAGS'
export LDFLAGS='$LDFLAGS'

# iproute2
rm -rf iproute2-$IPROUTE2_VER
tar -xf /sources/$(basename "$itb")
cd iproute2-$IPROUTE2_VER
# keep it minimal; disable manpages if missing tools
make -j$JOBS
make SBINDIR=/usr/sbin PREFIX=/usr install
cd /build

# dhcpcd
rm -rf dhcpcd-$DHCPCD_VER
tar -xf /sources/$(basename "$dtb")
cd dhcpcd-$DHCPCD_VER
./configure --prefix=/usr --sysconfdir=/etc --dbdir=/var/lib/dhcpcd
make -j$JOBS
make install

# runit service: dhcpcd (interface auto)
mkdir -p /etc/service/dhcpcd
cat > /etc/service/dhcpcd/run <<'R'
#!/bin/sh
exec dhcpcd -B -q
R
chmod 0755 /etc/service/dhcpcd/run
"
}


s45_essentials(){
  ctb=$(find_tb cpio "$CPIO_VER") || die "missing cpio-$CPIO_VER"
  ptb=$(find_tb procps-ng "$PROCPS_VER") || die "missing procps-ng-$PROCPS_VER"
  psb=$(find_tb psmisc "$PSMISC_VER") || die "missing psmisc-$PSMISC_VER"
  itb=$(find_tb iputils "$IPUTILS_VER") || die "missing iputils-$IPUTILS_VER"
  ktb=$(find_tb kbd "$KBD_VER") || die "missing kbd-$KBD_VER"
  ttb=$(find_tb tzdata "$TZDATA_VER") || die "missing tzdata-$TZDATA_VER"

  chrun "
set -eu
cd /build
export CFLAGS='$CFLAGS'
export LDFLAGS='$LDFLAGS'

pkg_begin(){ [ '$TRACK_INSTALLS' -eq 1 ] || return 0; mkdir -p /var/lib/stage-build/manifests; ( find /bin /sbin /lib /usr -xdev \( -type f -o -type l \) 2>/dev/null | sort ) > /var/lib/stage-build/.snap.\$1; }
pkg_end(){ [ '$TRACK_INSTALLS' -eq 1 ] || return 0; ( find /bin /sbin /lib /usr -xdev \( -type f -o -type l \) 2>/dev/null | sort ) > /var/lib/stage-build/.snap.\$1.new; comm -13 /var/lib/stage-build/.snap.\$1 /var/lib/stage-build/.snap.\$1.new > /var/lib/stage-build/manifests/\$1.list 2>/dev/null || :; rm -f /var/lib/stage-build/.snap.\$1 /var/lib/stage-build/.snap.\$1.new; }

# cpio (needed for initramfs workflows)
pkg_begin cpio
rm -rf cpio-$CPIO_VER
tar -xf /sources/$(basename "$ctb")
cd cpio-$CPIO_VER
./configure --prefix=/usr
make -j$JOBS
make install
pkg_end cpio
cd /build

# procps-ng (ps/top/etc)
pkg_begin procps-ng
rm -rf procps-ng-$PROCPS_VER
tar -xf /sources/$(basename "$ptb")
cd procps-ng-$PROCPS_VER
./configure --prefix=/usr --disable-nls --without-systemd
make -j$JOBS
make install
pkg_end procps-ng
cd /build

# psmisc (killall/pstree)
pkg_begin psmisc
rm -rf psmisc-$PSMISC_VER
tar -xf /sources/$(basename "$psb")
cd psmisc-$PSMISC_VER
./configure --prefix=/usr
make -j$JOBS
make install
pkg_end psmisc
cd /build

# iputils (ping/tracepath)
pkg_begin iputils
rm -rf iputils-$IPUTILS_VER
tar -xf /sources/$(basename "$itb")
cd iputils-$IPUTILS_VER
# iputils uses makefile; keep minimal and avoid capabilities
make -j$JOBS USE_IDN=no USE_CRYPTO=no
make SBINDIR=/usr/sbin install
pkg_end iputils
cd /build

# kbd (loadkeys/setfont)
pkg_begin kbd
rm -rf kbd-$KBD_VER
tar -xf /sources/$(basename "$ktb")
cd kbd-$KBD_VER
./configure --prefix=/usr --disable-nls
make -j$JOBS
make install
pkg_end kbd
cd /build

# tzdata (timezones)
pkg_begin tzdata
rm -rf tzdata-$TZDATA_VER
tar -xf /sources/$(basename "$ttb")
cd tzdata-$TZDATA_VER
# install zoneinfo
mkdir -p /usr/share/zoneinfo
cp -a zoneinfo/* /usr/share/zoneinfo/ 2>/dev/null || cp -a * /usr/share/zoneinfo/ 2>/dev/null || :
# default timezone (UTC)
ln -sf /usr/share/zoneinfo/UTC /etc/localtime
printf '%s
' 'UTC' > /etc/timezone 2>/dev/null || :
pkg_end tzdata

# runit service: syslogd/klogd (busybox)
mkdir -p /etc/service/syslog
cat > /etc/service/syslog/run <<'R'
#!/bin/sh
exec 2>&1
mkdir -p /var/log
# busybox syslogd/klogd
( syslogd -n -O /var/log/messages ) &
exec klogd -n
R
chmod 0755 /etc/service/syslog/run

"
}


s50_wifi(){
  [ "$ENABLE_WIFI" -eq 1 ] || return 0
  ltb=$(find_tb libnl "$LIBNL_VER") || die "missing libnl-$LIBNL_VER"
  itb=$(find_tb iw "$IW_VER") || die "missing iw-$IW_VER"
  wtb=$(find_tb wpa_supplicant "$WPA_SUPP_VER") || die "missing wpa_supplicant-$WPA_SUPP_VER"

  chrun "
set -eu
cd /build
export CFLAGS='$CFLAGS'
export LDFLAGS='$LDFLAGS'

# libnl
rm -rf libnl-$LIBNL_VER libnl-build
tar -xf /sources/$(basename "$ltb")
mkdir -p libnl-build
cd libnl-build
../libnl-$LIBNL_VER/configure --prefix=/usr --sysconfdir=/etc
make -j$JOBS
make install
cd /build

# iw
rm -rf iw-$IW_VER
tar -xf /sources/$(basename "$itb")
cd iw-$IW_VER
make -j$JOBS
make PREFIX=/usr install
cd /build

# wpa_supplicant
rm -rf wpa_supplicant-$WPA_SUPP_VER
tar -xf /sources/$(basename "$wtb")
cd wpa_supplicant-$WPA_SUPP_VER/wpa_supplicant
cp -f defconfig .config
# enable nl80211 and openssl
sed -i 's/^#\(CONFIG_CTRL_IFACE\)=y/\1=y/' .config || :
printf '%s\n' 'CONFIG_CTRL_IFACE=y' >> .config
printf '%s\n' 'CONFIG_CTRL_IFACE_DBUS_NEW=y' >> .config
printf '%s\n' 'CONFIG_CTRL_IFACE_DBUS_INTRO=y' >> .config
printf '%s\n' 'CONFIG_TLS=openssl' >> .config
printf '%s\n' 'CONFIG_DRIVER_NL80211=y' >> .config
make -j$JOBS
install -m 0755 wpa_supplicant /usr/sbin/wpa_supplicant
install -m 0755 wpa_cli /usr/sbin/wpa_cli
mkdir -p /etc/wpa_supplicant
[ -f /etc/wpa_supplicant/wpa_supplicant.conf ] || cat > /etc/wpa_supplicant/wpa_supplicant.conf <<'C'
ctrl_interface=/run/wpa_supplicant
update_config=1
C

# runit service: wpa_supplicant (interface wlan0 by default)
mkdir -p /etc/service/wpa_supplicant
cat > /etc/service/wpa_supplicant/run <<'R'
#!/bin/sh
IFACE=${IFACE:-wlan0}
exec wpa_supplicant -i "$IFACE" -c /etc/wpa_supplicant/wpa_supplicant.conf
R
chmod 0755 /etc/service/wpa_supplicant/run
"
}

s60_audio(){
  [ "$ENABLE_AUDIO" -eq 1 ] || return 0
  ltb=$(find_tb alsa-lib "$ALSA_LIB_VER") || die "missing alsa-lib-$ALSA_LIB_VER"
  utb=$(find_tb alsa-utils "$ALSA_UTILS_VER") || die "missing alsa-utils-$ALSA_UTILS_VER"

  chrun "
set -eu
cd /build
export CFLAGS='$CFLAGS'
export LDFLAGS='$LDFLAGS'

# alsa-lib
rm -rf alsa-lib-$ALSA_LIB_VER alsa-lib-build
tar -xf /sources/$(basename "$ltb")
mkdir -p alsa-lib-build
cd alsa-lib-build
../alsa-lib-$ALSA_LIB_VER/configure --prefix=/usr --sysconfdir=/etc
make -j$JOBS
make install
cd /build

# alsa-utils (minimal)
rm -rf alsa-utils-$ALSA_UTILS_VER alsa-utils-build
tar -xf /sources/$(basename "$utb")
mkdir -p alsa-utils-build
cd alsa-utils-build
../alsa-utils-$ALSA_UTILS_VER/configure --prefix=/usr --sysconfdir=/etc --disable-alsaconf --disable-bat
make -j$JOBS
make install
"
}

s70_apps(){
  ntb=$(find_tb ncurses "$NCURSES_VER") || die "missing ncurses-$NCURSES_VER"
  vtb=$(find_tb vim "$VIM_VER") || die "missing vim-$VIM_VER"
  wtb=$(find_tb w3m "$W3M_VER") || die "missing w3m-$W3M_VER"

  chrun "
set -eu
cd /build
export CFLAGS='$CFLAGS'
export LDFLAGS='$LDFLAGS'

# ncurses (wide)
rm -rf ncurses-$NCURSES_VER ncurses-build
tar -xf /sources/$(basename "$ntb")
mkdir -p ncurses-build
cd ncurses-build
../ncurses-$NCURSES_VER/configure --prefix=/usr --with-shared --with-normal --without-debug --enable-widec --with-termlib
make -j$JOBS
make install
# symlinks for common names
ln -sf libncursesw.so /usr/lib/libncurses.so 2>/dev/null || :
ln -sf libtinfo.so /usr/lib/libtinfo.so 2>/dev/null || :
cd /build

# vim
rm -rf vim-$VIM_VER
tar -xf /sources/$(basename "$vtb")
cd vim-$VIM_VER
./configure --prefix=/usr --with-tlib=ncursesw --enable-multibyte --with-features=normal
make -j$JOBS
make install
cd /build

# w3m
rm -rf w3m-$W3M_VER
tar -xf /sources/$(basename "$wtb")
cd w3m-$W3M_VER
./configure --prefix=/usr --disable-image
make -j$JOBS
make install
"
}

s80_kernel(){
  ktb=$(find_tb linux "$LINUX_VER") || die "missing linux-$LINUX_VER"
  chrun "
set -eu
cd /build
rm -rf linux-$LINUX_VER
tar -xf /sources/$(basename "$ktb")
cd linux-$LINUX_VER
# Configure
if [ -n '$KERNEL_CONFIG_FILE' ] && [ -f /sources/$(basename "$KERNEL_CONFIG_FILE") ]; then
  cp -f /sources/$(basename "$KERNEL_CONFIG_FILE") .config
  make olddefconfig
else
  make $KERNEL_DEFCONFIG
fi
make -j$JOBS
make modules_install
make install
# Ensure initramfs is not required by default; user can add later
"
}


s85_initramfs(){
  [ "$ENABLE_INITRAMFS" -eq 1 ] || return 0
  # Determine kernel version if not set by env (use latest under /lib/modules)
  kver="${KVER:-}"
  if [ -z "$kver" ]; then
    if [ -d "$ROOTFS/lib/modules" ]; then
      kver=$(ls -1 "$ROOTFS/lib/modules" 2>/dev/null | sort | tail -n 1 || :)
    fi
  fi
  [ -n "$kver" ] || die "cannot determine KVER; set KVER=... (needs $ROOTFS/lib/modules/<kver>)"

  # Host-side generation (requires host cpio + compressor).
  ROOTFS="$ROOTFS" OUTDIR="$ROOTFS/boot" INITRAMFS_NAME="$INITRAMFS_NAME" \
    KVER="$kver" ROOTDEV="$ROOTDEV" FS="$ROOTFS_TYPE" COMPRESS="$INITRAMFS_COMPRESS" \
    ./scripts/initramfs.sh build
}


s90_grub_uefi(){
  [ "$ENABLE_GRUB_UEFI" -eq 1 ] || return 0
  gtb=$(find_tb grub "$GRUB_VER") || die "missing grub-$GRUB_VER"
  etb=$(find_tb efibootmgr "$EFIBOOTMGR_VER") || die "missing efibootmgr-$EFIBOOTMGR_VER"
  dtb=$(find_tb dosfstools "$DOSFSTOOLS_VER") || die "missing dosfstools-$DOSFSTOOLS_VER"
  mtb=$(find_tb mtools "$MTOOLS_VER") || die "missing mtools-$MTOOLS_VER"

  chrun "
set -eu
cd /build
export CFLAGS='$CFLAGS'
export LDFLAGS='$LDFLAGS'

# dosfstools
rm -rf dosfstools-$DOSFSTOOLS_VER
tar -xf /sources/$(basename "$dtb")
cd dosfstools-$DOSFSTOOLS_VER
make -j$JOBS
make PREFIX=/usr install
cd /build

# mtools
rm -rf mtools-$MTOOLS_VER
tar -xf /sources/$(basename "$mtb")
cd mtools-$MTOOLS_VER
./configure --prefix=/usr
make -j$JOBS
make install
cd /build

# efibootmgr
rm -rf efibootmgr-$EFIBOOTMGR_VER
tar -xf /sources/$(basename "$etb")
cd efibootmgr-$EFIBOOTMGR_VER
make -j$JOBS
make install PREFIX=/usr
cd /build

# grub (UEFI)
rm -rf grub-$GRUB_VER grub-build
tar -xf /sources/$(basename "$gtb")
mkdir -p grub-build
cd grub-build
../grub-$GRUB_VER/configure --prefix=/usr --sysconfdir=/etc --disable-werror --with-platform=efi --target=$GRUB_EFI_TARGET
make -j$JOBS
make install

# Install to ESP only if user provided GRUB_DISK and ESP is mounted
if [ -n '$GRUB_DISK' ] && [ -d '$ESP_MOUNT' ]; then
  grub-install --target=$GRUB_EFI_TARGET --efi-directory=$ESP_MOUNT --bootloader-id=$GRUB_BOOTLOADER_ID --recheck $GRUB_DISK
fi

# Minimal grub.cfg placeholder
mkdir -p /boot/grub
cat > /boot/grub/grub.cfg <<'CFG'
set timeout=3
set default=0
menuentry "musl root" {
  echo "Edit /boot/grub/grub.cfg to set root and kernel params"
  linux /boot/vmlinuz root=/dev/sda2 ro
}
CFG
"
}

s95_revdep(){
  # Run revdep inside chroot (non-fatal by default)
  chrun "
set -eu
if [ -x /usr/sbin/revdep.sh ]; then
  /usr/sbin/revdep.sh --root / --no-color || :
fi
"
}

s99_smoke(){
  chrun "
set -eu
printf '%s\n' 'Stage3 smoke:'
uname -a || :
command -v runsvdir >/dev/null
command -v ip >/dev/null
command -v vim >/dev/null
command -v w3m >/dev/null
"
}

###############################################################################
# Main plan
###############################################################################

# Steps list (stable IDs)
STEPS="00_prep 10_layout_configs 20_build_base_pkgs 30_runit 40_network 45_essentials"
[ "$ENABLE_WIFI" -eq 1 ] && STEPS="$STEPS 50_wifi"
[ "$ENABLE_AUDIO" -eq 1 ] && STEPS="$STEPS 60_audio"
STEPS="$STEPS 70_apps 80_kernel"
[ "$ENABLE_INITRAMFS" -eq 1 ] && STEPS="$STEPS 85_initramfs"
[ "$ENABLE_GRUB_UEFI" -eq 1 ] && STEPS="$STEPS 90_grub_uefi"
STEPS="$STEPS 99_smoke"

# Ensure state/log dirs exist
ensure "$STATE" "$LOGDIR" "$BUILDDIR"

# Dispatch map
run_step_by_name() {
  name=$1
  case "$name" in
    00_prep) s00_prep ;;
    10_layout_configs) s10_layout_configs ;;
    20_build_base_pkgs) s20_build_base_pkgs ;;
    30_runit) s30_runit ;;
    40_network) s40_network ;;
    45_essentials) s45_essentials ;;
    50_wifi) s50_wifi ;;
    60_audio) s60_audio ;;
    70_apps) s70_apps ;;
    80_kernel) s80_kernel ;;
    85_initramfs) s85_initramfs ;;
    90_grub_uefi) s90_grub_uefi ;;
    95_revdep) s95_revdep ;;
    99_smoke) s99_smoke ;;
    *) die "unknown step: $name" ;;
  esac
}

cmd=${1:-all}
case "$cmd" in
  all)
    # count
    total=0
    for _ in $STEPS; do total=$((total+1)); done
    i=0
    for step in $STEPS; do
      i=$((i+1))
      step_do "$i" "$total" "$step" run_step_by_name "$step"
    done
    ;;
  list)
    printf '%s\n' $STEPS
    ;;
  step)
    [ $# -ge 2 ] || die "usage: $0 step <name>"
    run_step_by_name "$2"
    ;;
  *)
    die "usage: $0 {all|list|step <name>}"
    ;;
esac