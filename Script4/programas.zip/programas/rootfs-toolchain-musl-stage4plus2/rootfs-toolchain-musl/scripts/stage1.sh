#!/bin/sh
# rootfs-toolchain-musl: Stage1 builder
# Builds a compact "stage1" userland into $ROOTFS using the temporary toolchain in $TOOLS.
# POSIX /bin/sh only.

set -eu

###############################################################################
# Configuration (edit here or override via environment)
###############################################################################

ROOTFS=${ROOTFS:-/mnt/rootfs}
TOOLS=${TOOLS:-$ROOTFS/tools}

# Target triple must match toolchain build.sh
TARGET=${TARGET:-x86_64-linux-musl}

# Where sources and build dirs live
SRCDIR=${SRCDIR:-$ROOTFS/sources}
BUILDDIR=${BUILDDIR:-$ROOTFS/build-stage1}
STATE=${STATE:-$ROOTFS/state-stage1}
LOGDIR=${LOGDIR:-$ROOTFS/logs-stage1}

# Install prefix inside ROOTFS (stage1 is meant to become the base for stage2)
PREFIX=${PREFIX:-/usr}
SYSCONFDIR=${SYSCONFDIR:-/etc}
LOCALSTATEDIR=${LOCALSTATEDIR:-/var}

# Toolchain sysroot (from build.sh)
SYSROOT=${SYSROOT:-$TOOLS/$TARGET}

# Parallelism
JOBS=${JOBS:-1}

# Build flags (safe defaults)
CFLAGS_BASE=${CFLAGS_BASE:--O2 -pipe}
# For hardening, keep portable and avoid exotic flags that might break bootstrap.
CFLAGS_HARDEN=${CFLAGS_HARDEN:--fstack-protector-strong -D_FORTIFY_SOURCE=2}
CFLAGS=${CFLAGS:-$CFLAGS_BASE $CFLAGS_HARDEN}
CXXFLAGS=${CXXFLAGS:-$CFLAGS}
# Conservative link hardening; can be disabled if your linker rejects them.
LDFLAGS=${LDFLAGS:--Wl,-z,relro -Wl,-z,now}

# Package versions (edit here to pin)
MUSL_VER=${MUSL_VER:-1.2.5}
BUSYBOX_VER=${BUSYBOX_VER:-1.37.0}
NCURSES_VER=${NCURSES_VER:-6.5}
READLINE_VER=${READLINE_VER:-8.2.13}
BASH_VER=${BASH_VER:-5.2.37}
MAKE_VER=${MAKE_VER:-4.4.1}
M4_VER=${M4_VER:-1.4.19}
SED_VER=${SED_VER:-4.9}
GREP_VER=${GREP_VER:-3.11}
GAWK_VER=${GAWK_VER:-5.3.0}
FINDUTILS_VER=${FINDUTILS_VER:-4.10.0}
DIFFUTILS_VER=${DIFFUTILS_VER:-3.10}
PATCH_VER=${PATCH_VER:-2.7.6}
XZ_VER=${XZ_VER:-5.6.2}
BZIP2_VER=${BZIP2_VER:-1.0.8}
GZIP_VER=${GZIP_VER:-1.13}
ZLIB_VER=${ZLIB_VER:-1.3.1}
FILE_VER=${FILE_VER:-5.45}
PKGCONF_VER=${PKGCONF_VER:-2.3.0}

###############################################################################
# Helpers
###############################################################################

umask 022

msg() { printf '%s\n' "$*" >&2; }
die() { msg "ERROR: $*"; exit 1; }

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"
}

ensure_dir() { [ -d "$1" ] || mkdir -p "$1"; }

# portable rm -rf wrapper without relying on rm '--'
rm_rf() {
  [ $# -ge 1 ] || return 0
  for p in "$@"; do
    [ -e "$p" ] || continue
    case $p in
      -*) rm -rf "./$p" ;;
      *)  rm -rf "$p" ;;
    esac
  done
}

state_has() { [ -f "$STATE/$1.ok" ]; }
state_mark() { : >"$STATE/$1.ok"; }

run_step() {
  step=$1
  shift
  ensure_dir "$LOGDIR"
  log="$LOGDIR/$step.log"
  msg "==> $step"
  msg "    log: $log"
  (
    set -eu
    "$@"
  ) >"$log" 2>&1
}

# Extract tarball safely without pipefail.
extract_tarball() {
  tb=$1
  [ -f "$tb" ] || die "tarball not found: $tb"
  ensure_dir "$BUILDDIR"
  tmp="$BUILDDIR/.tmp-extract.$$"
  rm_rf "$tmp"
  ensure_dir "$tmp"
  outtar="$tmp/archive.tar"
  case $tb in
    *.tar.gz|*.tgz)
      need_cmd gzip
      gzip -dc "$tb" >"$outtar" || die "gzip failed: $tb"
      ;;
    *.tar.xz)
      need_cmd xz
      xz -dc "$tb" >"$outtar" || die "xz failed: $tb"
      ;;
    *.tar.bz2)
      need_cmd bzip2
      bzip2 -dc "$tb" >"$outtar" || die "bzip2 failed: $tb"
      ;;
    *.tar)
      outtar="$tb"
      ;;
    *)
      die "unsupported tarball: $tb"
      ;;
  esac
  tar -xf "$outtar" -C "$BUILDDIR" || die "tar extract failed: $tb"
  rm_rf "$tmp"
}

# return first matching tarball path for pkg name and version
tb_find() {
  name=$1
  ver=$2
  for ext in tar.xz tar.gz tgz tar.bz2 tar; do
    p="$SRCDIR/$name-$ver.$ext"
    [ -f "$p" ] && { printf '%s\n' "$p"; return 0; }
  done
  return 1
}

# Configure environment for cross build into ROOTFS
setup_env() {
  # Prefer the temporary toolchain
  export PATH="$TOOLS/bin:$PATH"

  # Use the cross tools explicitly
  export CC="${CC:-$TARGET-gcc}"
  export CXX="${CXX:-$TARGET-g++}"
  export AR="${AR:-$TARGET-ar}"
  export AS="${AS:-$TARGET-as}"
  export LD="${LD:-$TARGET-ld}"
  export NM="${NM:-$TARGET-nm}"
  export OBJCOPY="${OBJCOPY:-$TARGET-objcopy}"
  export OBJDUMP="${OBJDUMP:-$TARGET-objdump}"
  export RANLIB="${RANLIB:-$TARGET-ranlib}"
  export READELF="${READELF:-$TARGET-readelf}"
  export STRIP="${STRIP:-$TARGET-strip}"

  # Sysrooted compilation
  export CFLAGS="$CFLAGS --sysroot=$SYSROOT"
  export CXXFLAGS="$CXXFLAGS --sysroot=$SYSROOT"
  export LDFLAGS="$LDFLAGS --sysroot=$SYSROOT"
}

# Make sure rootfs directory skeleton exists
prepare_rootfs_layout() {
  ensure_dir "$ROOTFS"
  ensure_dir "$ROOTFS$PREFIX"
  ensure_dir "$ROOTFS$PREFIX/bin"
  ensure_dir "$ROOTFS$PREFIX/sbin"
  ensure_dir "$ROOTFS$PREFIX/lib"
  ensure_dir "$ROOTFS$PREFIX/include"
  ensure_dir "$ROOTFS$PREFIX/share"
  ensure_dir "$ROOTFS/bin"
  ensure_dir "$ROOTFS/sbin"
  ensure_dir "$ROOTFS/lib"
  ensure_dir "$ROOTFS/usr"
  ensure_dir "$ROOTFS/etc"
  ensure_dir "$ROOTFS/var"
  ensure_dir "$ROOTFS/tmp"
  ensure_dir "$ROOTFS/root"
  ensure_dir "$ROOTFS/home"
  chmod 1777 "$ROOTFS/tmp" 2>/dev/null || :
}

# Strip binaries (best-effort)
strip_rootfs() {
  # Avoid stripping ld-musl or libs that might be needed for debugging stage2.
  # Best-effort only; ignore failures.
  find "$ROOTFS$PREFIX/bin" "$ROOTFS$PREFIX/sbin" "$ROOTFS/bin" "$ROOTFS/sbin" 2>/dev/null \
    -type f -exec "$STRIP" --strip-all {} \; 2>/dev/null || :
}

###############################################################################
# Package build functions
###############################################################################

build_musl() {
  # Install musl runtime + headers into ROOTFS (not the toolchain sysroot).
  tb=$(tb_find musl "$MUSL_VER") || die "missing musl-$MUSL_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/musl-$MUSL_VER"
  cd "$d"
  # syslibdir=/lib to place ld-musl and libc where dynamic linker expects.
  ./configure \
    --prefix="$PREFIX" \
    --syslibdir=/lib \
    --includedir="$PREFIX/include" \
    --host="$TARGET"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_zlib() {
  tb=$(tb_find zlib "$ZLIB_VER") || die "missing zlib-$ZLIB_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/zlib-$ZLIB_VER"
  cd "$d"
  CHOST="$TARGET" ./configure --prefix="$PREFIX"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_xz() {
  tb=$(tb_find xz "$XZ_VER") || die "missing xz-$XZ_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/xz-$XZ_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX" --disable-static --enable-shared
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_bzip2() {
  tb=$(tb_find bzip2 "$BZIP2_VER") || die "missing bzip2-$BZIP2_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/bzip2-$BZIP2_VER"
  cd "$d"
  make -j "$JOBS" CC="$CC" AR="$AR" RANLIB="$RANLIB" CFLAGS="$CFLAGS"
  make PREFIX="$PREFIX" DESTDIR="$ROOTFS" install
}

build_gzip() {
  tb=$(tb_find gzip "$GZIP_VER") || die "missing gzip-$GZIP_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/gzip-$GZIP_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_pkgconf() {
  tb=$(tb_find pkgconf "$PKGCONF_VER") || die "missing pkgconf-$PKGCONF_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/pkgconf-$PKGCONF_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX" --with-system-libdir="$PREFIX/lib" --with-system-includedir="$PREFIX/include"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
  # Provide pkg-config compatibility symlink
  ln -sf pkgconf "$ROOTFS$PREFIX/bin/pkg-config"
}

build_make() {
  tb=$(tb_find make "$MAKE_VER") || die "missing make-$MAKE_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/make-$MAKE_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_m4() {
  tb=$(tb_find m4 "$M4_VER") || die "missing m4-$M4_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/m4-$M4_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_sed() {
  tb=$(tb_find sed "$SED_VER") || die "missing sed-$SED_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/sed-$SED_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_grep() {
  tb=$(tb_find grep "$GREP_VER") || die "missing grep-$GREP_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/grep-$GREP_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_gawk() {
  tb=$(tb_find gawk "$GAWK_VER") || die "missing gawk-$GAWK_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/gawk-$GAWK_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_findutils() {
  tb=$(tb_find findutils "$FINDUTILS_VER") || die "missing findutils-$FINDUTILS_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/findutils-$FINDUTILS_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_diffutils() {
  tb=$(tb_find diffutils "$DIFFUTILS_VER") || die "missing diffutils-$DIFFUTILS_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/diffutils-$DIFFUTILS_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_patch() {
  tb=$(tb_find patch "$PATCH_VER") || die "missing patch-$PATCH_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/patch-$PATCH_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

build_ncurses() {
  tb=$(tb_find ncurses "$NCURSES_VER") || die "missing ncurses-$NCURSES_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/ncurses-$NCURSES_VER"
  cd "$d"
  # Keep it small: widec, shared only
  ./configure \
    --host="$TARGET" \
    --prefix="$PREFIX" \
    --mandir="$PREFIX/share/man" \
    --with-shared \
    --without-debug \
    --without-ada \
    --enable-widec \
    --enable-pc-files \
    --with-pkg-config-libdir="$PREFIX/lib/pkgconfig"
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
  # Ensure classic soname symlink for libncurses
  ln -sf libncursesw.so "$ROOTFS$PREFIX/lib/libncurses.so" 2>/dev/null || :
}

build_readline() {
  tb=$(tb_find readline "$READLINE_VER") || die "missing readline-$READLINE_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/readline-$READLINE_VER"
  cd "$d"
  # readline's build system uses its own makefiles; configure is present.
  ./configure --host="$TARGET" --prefix="$PREFIX" --with-curses
  make -j "$JOBS" SHLIB_LIBS="-lncursesw"
  make DESTDIR="$ROOTFS" install
}

build_bash() {
  tb=$(tb_find bash "$BASH_VER") || die "missing bash-$BASH_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/bash-$BASH_VER"
  cd "$d"
  ./configure --host="$TARGET" --prefix="$PREFIX" --with-curses --without-bash-malloc
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
  ln -sf bash "$ROOTFS$PREFIX/bin/sh"
  # Provide /bin/sh for early scripts
  ln -sf "$PREFIX/bin/bash" "$ROOTFS/bin/sh"
}

build_busybox() {
  tb=$(tb_find busybox "$BUSYBOX_VER") || die "missing busybox-$BUSYBOX_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/busybox-$BUSYBOX_VER"
  cd "$d"
  make distclean
  make defconfig
  # keep it minimal but usable: enable tar, xz, gzip, bzip2 support via external tools.
  # Use sed in-place is not POSIX; so edit via temporary file.
  cfg=".config"
  tmp="$BUILDDIR/.bbcfg.$$"
  rm_rf "$tmp"
  : >"$tmp"
  while IFS= read -r line; do
    case $line in
      "# CONFIG_STATIC is not set") printf '%s\n' "CONFIG_STATIC=n" >>"$tmp" ;;
      "CONFIG_STATIC="*)         printf '%s\n' "CONFIG_STATIC=n" >>"$tmp" ;;
      *)                         printf '%s\n' "$line" >>"$tmp" ;;
    esac
  done <"$cfg"
  mv "$tmp" "$cfg"
  # Build and install
  make -j "$JOBS" CC="$CC" CFLAGS="$CFLAGS" LDFLAGS="$LDFLAGS"
  make CONFIG_PREFIX="$ROOTFS" install
}

build_file() {
  tb=$(tb_find file "$FILE_VER") || die "missing file-$FILE_VER tarball in $SRCDIR"
  extract_tarball "$tb"
  d="$BUILDDIR/file-$FILE_VER"
  cd "$d"
  # Use bundled libmagic, link with zlib where available
  ./configure --host="$TARGET" --prefix="$PREFIX" --disable-static --enable-shared
  make -j "$JOBS"
  make DESTDIR="$ROOTFS" install
}

###############################################################################
# Verification
###############################################################################

verify_stage1() {
  # Verify expected interpreter on a few key binaries (no chroot required)
  for p in "$ROOTFS$PREFIX/bin/bash" "$ROOTFS$PREFIX/bin/make" "$ROOTFS$PREFIX/bin/sed"; do
    [ -x "$p" ] || continue
    "$READELF" -l "$p" 2>/dev/null | grep -q 'Requesting program interpreter: /lib/ld-musl-x86_64\.so\.1' || \
      die "unexpected dynamic linker for $p (expected musl /lib/ld-musl-x86_64.so.1)"
  done

  # If we are root and chroot exists, run an execution test inside rootfs
  if command -v chroot >/dev/null 2>&1 && [ "$(id -u 2>/dev/null || echo 1)" = "0" ]; then
    msg "==> chroot smoke test"
    chroot "$ROOTFS" /bin/sh -c '
      set -eu
      [ -x /usr/bin/bash ] || [ -x /bin/busybox ] || exit 1
      /usr/bin/bash -lc "echo stage1-ok; command -v make; command -v sed; command -v grep; command -v awk" >/dev/null
    ' || die "chroot smoke test failed"
  else
    msg "==> skipping chroot execution test (need root + chroot)"
  fi
}

###############################################################################
# Main
###############################################################################

main() {
  need_cmd tar
  need_cmd make
  need_cmd grep
  ensure_dir "$SRCDIR"
  ensure_dir "$BUILDDIR"
  ensure_dir "$STATE"
  ensure_dir "$LOGDIR"

  [ -d "$TOOLS/bin" ] || die "toolchain not found: $TOOLS/bin (run build.sh first)"
  [ -d "$SYSROOT" ] || die "toolchain sysroot not found: $SYSROOT"

  setup_env
  prepare_rootfs_layout

  # Build order: musl first so we can run installed binaries in chroot later.
  if ! state_has musl; then run_step musl build_musl; state_mark musl; fi
  if ! state_has zlib; then run_step zlib build_zlib; state_mark zlib; fi
  if ! state_has xz; then run_step xz build_xz; state_mark xz; fi
  if ! state_has bzip2; then run_step bzip2 build_bzip2; state_mark bzip2; fi
  if ! state_has gzip; then run_step gzip build_gzip; state_mark gzip; fi
  if ! state_has pkgconf; then run_step pkgconf build_pkgconf; state_mark pkgconf; fi

  if ! state_has ncurses; then run_step ncurses build_ncurses; state_mark ncurses; fi
  if ! state_has readline; then run_step readline build_readline; state_mark readline; fi
  if ! state_has bash; then run_step bash build_bash; state_mark bash; fi

  if ! state_has make; then run_step make build_make; state_mark make; fi
  if ! state_has m4; then run_step m4 build_m4; state_mark m4; fi
  if ! state_has sed; then run_step sed build_sed; state_mark sed; fi
  if ! state_has grep; then run_step grep build_grep; state_mark grep; fi
  if ! state_has gawk; then run_step gawk build_gawk; state_mark gawk; fi
  if ! state_has findutils; then run_step findutils build_findutils; state_mark findutils; fi
  if ! state_has diffutils; then run_step diffutils build_diffutils; state_mark diffutils; fi
  if ! state_has patch; then run_step patch build_patch; state_mark patch; fi
  if ! state_has file; then run_step file build_file; state_mark file; fi

  if ! state_has busybox; then run_step busybox build_busybox; state_mark busybox; fi

  if ! state_has verify; then run_step verify verify_stage1; state_mark verify; fi

  msg "==> stage1 complete"
  msg "Installed into: $ROOTFS"
  msg "Logs: $LOGDIR"
  msg "State: $STATE"
}

main "$@"
