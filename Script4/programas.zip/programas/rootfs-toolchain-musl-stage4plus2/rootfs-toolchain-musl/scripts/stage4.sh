#!/bin/sh
# stage4.sh - Build Stage4: developer tools + Wayland desktop stack (no full DE).
# POSIX /bin/sh only. Retomada por markers, logs por etapa, manifests opcionais.
#
# This stage is intentionally modular and avoids unnecessary bloat. Use variables
# to enable/disable heavier components.

set -eu

###############################################################################
# Configuração (edite aqui ou sobrescreva via ambiente)
###############################################################################

ROOTFS=${ROOTFS:-/mnt/rootfs}

SRCDIR=${SRCDIR:-$ROOTFS/sources}
BUILDDIR=${BUILDDIR:-$ROOTFS/build-stage4}
STATE_DIR=${STATE_DIR:-$ROOTFS/state-stage4}
LOG_DIR=${LOG_DIR:-$ROOTFS/logs-stage4}
PKGDB_DIR=${PKGDB_DIR:-$ROOTFS/var/lib/stage-build}

JOBS=${JOBS:-1}

TARGET=${TARGET:-x86_64-linux-musl}

# Helper de chroot (host-side)
CHROOT_RUN=${CHROOT_RUN:-./scripts/chroot-run.sh}

# Bind mounts opcionais: "/host:/dentro"
BIND_MOUNTS=${BIND_MOUNTS:-"$SRCDIR:/sources $BUILDDIR:/build"}
BIND_RO_MOUNTS=${BIND_RO_MOUNTS:-}

# Tracking de installs (manifests para remoção posterior)
: "${TRACK_INSTALLS:=1}"

# Flags seguras (sem agressividade excessiva)
CFLAGS_BASE=${CFLAGS_BASE:--O2 -pipe}
CFLAGS_HARDEN=${CFLAGS_HARDEN:--fstack-protector-strong -D_FORTIFY_SOURCE=2}
CFLAGS=${CFLAGS:-$CFLAGS_BASE $CFLAGS_HARDEN}
CXXFLAGS=${CXXFLAGS:-$CFLAGS}
LDFLAGS=${LDFLAGS:--Wl,-z,relro -Wl,-z,now}

# Componentes de "dev toolchain"
ENABLE_CURL=${ENABLE_CURL:-1}
ENABLE_WGET=${ENABLE_WGET:-1}
ENABLE_GIT=${ENABLE_GIT:-1}
ENABLE_PYTHON=${ENABLE_PYTHON:-1}
ENABLE_CMAKE=${ENABLE_CMAKE:-1}
ENABLE_MESON=${ENABLE_MESON:-1}
ENABLE_NINJA=${ENABLE_NINJA:-1}
ENABLE_CCACHE=${ENABLE_CCACHE:-1}
ENABLE_LLVM=${ENABLE_LLVM:-1}

# Wayland stack (sem desktop environment completo)
ENABLE_WAYLAND_STACK=${ENABLE_WAYLAND_STACK:-1}
ENABLE_MESA=${ENABLE_MESA:-1}
ENABLE_CAGE=${ENABLE_CAGE:-1}      # compositor simples (wlroots)
ENABLE_FOOT=${ENABLE_FOOT:-1}      # terminal Wayland simples

# Desktop/Wayland extras
ENABLE_SWAY=${ENABLE_SWAY:-1}
ENABLE_WAYLAND_UTILS=${ENABLE_WAYLAND_UTILS:-1}   # grim/slurp/wl-clipboard/wayland-utils
ENABLE_FFMPEG=${ENABLE_FFMPEG:-1}
ENABLE_XWAYLAND=${ENABLE_XWAYLAND:-0}              # pesado; habilite apenas se precisar apps X11
ENABLE_PALEMOON=${ENABLE_PALEMOON:-0}              # experimental em musl; veja README
ENABLE_DBUS=${ENABLE_DBUS:-1}
ENABLE_FONTS_MIN=${ENABLE_FONTS_MIN:-1}            # fontconfig+freetype + set mínimo de fontes

# Essenciais para um desktop Wayland utilizável (sem DE completo)
ENABLE_FONTS_EXTRA=${ENABLE_FONTS_EXTRA:-1}        # DejaVu/Noto/JetBrainsMono/NerdFonts/FontAwesome (+ substitutos livres)
ENABLE_PIPEWIRE=${ENABLE_PIPEWIRE:-1}
ENABLE_WIREPLUMBER=${ENABLE_WIREPLUMBER:-1}
ENABLE_XDG_PORTAL=${ENABLE_XDG_PORTAL:-1}          # xdg-desktop-portal
ENABLE_XDG_PORTAL_WLR=${ENABLE_XDG_PORTAL_WLR:-1}  # xdg-desktop-portal-wlr
ENABLE_SWAY_EXTRAS=${ENABLE_SWAY_EXTRAS:-1}        # swayidle/swaybg/swaylock already; add grim/slurp/wl-clipboard etc.

# Font sets (livres). Observação: fontes proprietárias (Times New Roman, Courier New)
# não são distribuíveis; o Stage4 instala substitutos livres equivalentes.
ENABLE_FONTS_PROPRIETARY_PLACEHOLDERS=${ENABLE_FONTS_PROPRIETARY_PLACEHOLDERS:-1}

# PipeWire stack
ENABLE_RTKIT=${ENABLE_RTKIT:-0}                    # opcional (prioridade RT). Requer tarball.

# Mesa / gallium drivers (mantém enxuto por default)
MESA_GALLIUM=${MESA_GALLIUM:-iris,radeonsi,nouveau,virgl,svga,llvmpipe}
MESA_DRI=${MESA_DRI:-i965}
MESA_VULKAN=${MESA_VULKAN:-}
MESA_PLATFORMS=${MESA_PLATFORMS:-wayland}

###############################################################################
# Versões (atualize conforme seus tarballs em $SRCDIR)
###############################################################################

CURL_VER=${CURL_VER:-8.12.1}
WGET_VER=${WGET_VER:-1.21.4}
GIT_VER=${GIT_VER:-2.48.1}

# Deps comuns
EXPAT_VER=${EXPAT_VER:-2.6.4}
PCRE2_VER=${PCRE2_VER:-10.45}
LIBFFI_VER=${LIBFFI_VER:-3.4.6}
SQLITE_VER=${SQLITE_VER:-3.49.0}

# Python + build tooling
PYTHON_VER=${PYTHON_VER:-3.13.1}
CMAKE_VER=${CMAKE_VER:-3.31.6}
MESON_VER=${MESON_VER:-1.6.1}
NINJA_VER=${NINJA_VER:-1.12.1}
CCACHE_VER=${CCACHE_VER:-4.10.2}

# LLVM
LLVM_VER=${LLVM_VER:-19.1.7}

# Wayland stack
WAYLAND_VER=${WAYLAND_VER:-1.23.1}
WAYLAND_PROTOCOLS_VER=${WAYLAND_PROTOCOLS_VER:-1.37}
LIBDRM_VER=${LIBDRM_VER:-2.4.124}
XKBCOMMON_VER=${XKBCOMMON_VER:-1.7.0}
XKEYBOARD_CONFIG_VER=${XKEYBOARD_CONFIG_VER:-2.43}
PIXMAN_VER=${PIXMAN_VER:-0.46.2}
SEATD_VER=${SEATD_VER:-0.9.1}
LIBEVDEV_VER=${LIBEVDEV_VER:-1.13.4}
MTDEV_VER=${MTDEV_VER:-1.1.7}
LIBINPUT_VER=${LIBINPUT_VER:-1.26.2}
MESA_VER=${MESA_VER:-24.3.3}
WLROOTS_VER=${WLROOTS_VER:-0.18.2}
CAGE_VER=${CAGE_VER:-0.1.5}
FOOT_VER=${FOOT_VER:-1.20.2}

# Sway + Wayland utils + deps
SWAY_VER=${SWAY_VER:-1.11}
SWAYBG_VER=${SWAYBG_VER:-1.2.1}
SWAYIDLE_VER=${SWAYIDLE_VER:-1.8.0}
SWAYLOCK_VER=${SWAYLOCK_VER:-1.8.2}
GRIM_VER=${GRIM_VER:-1.4.1}
SLURP_VER=${SLURP_VER:-1.5.0}
WL_CLIPBOARD_VER=${WL_CLIPBOARD_VER:-2.2.1}
WAYLAND_UTILS_VER=${WAYLAND_UTILS_VER:-1.2.0}
WOFI_VER=${WOFI_VER:-1.4.1}  # opcional; launcher leve (wlroots)

# GUI deps
JSONC_VER=${JSONC_VER:-0.18}
CAIRO_VER=${CAIRO_VER:-1.18.4}
GLIB_VER=${GLIB_VER:-2.84.4}
DBUS_VER=${DBUS_VER:-1.14.10}
PANGO_VER=${PANGO_VER:-1.56.4}
GDK_PIXBUF_VER=${GDK_PIXBUF_VER:-2.44.3}
LIBPNG_VER=${LIBPNG_VER:-1.6.50}
FREETYPE_VER=${FREETYPE_VER:-2.14.1}
FONTCONFIG_VER=${FONTCONFIG_VER:-2.16.2}
HARFBUZZ_VER=${HARFBUZZ_VER:-10.4.0}
FRIBIDI_VER=${FRIBIDI_VER:-1.0.16}
LIBJPEG_TURBO_VER=${LIBJPEG_TURBO_VER:-3.1.1}

# X11/XCB (needed by sway for some features; Xwayland optional)
XORGPROTO_VER=${XORGPROTO_VER:-2024.1}
LIBXAU_VER=${LIBXAU_VER:-1.0.12}
LIBXDMCP_VER=${LIBXDMCP_VER:-1.1.5}
XCB_PROTO_VER=${XCB_PROTO_VER:-1.17.0}
LIBXCB_VER=${LIBXCB_VER:-1.17.0}
XCB_UTIL_VER=${XCB_UTIL_VER:-0.4.1}
XCB_UTIL_WM_VER=${XCB_UTIL_WM_VER:-0.4.2}
XCB_UTIL_XRM_VER=${XCB_UTIL_XRM_VER:-1.3}

# FFmpeg
FFMPEG_VER=${FFMPEG_VER:-7.1.1}
NASM_VER=${NASM_VER:-2.16.03}

# PipeWire + portals
ALSA_LIB_VER=${ALSA_LIB_VER:-1.2.14}
LIBCAP_VER=${LIBCAP_VER:-2.73}
PIPEWIRE_VER=${PIPEWIRE_VER:-1.4.9}
WIREPLUMBER_VER=${WIREPLUMBER_VER:-0.5.13}
LUA_VER=${LUA_VER:-5.4.7}
GSTREAMER_VER=${GSTREAMER_VER:-1.26.6}
GST_PLUGINS_BASE_VER=${GST_PLUGINS_BASE_VER:-1.26.6}
JSON_GLIB_VER=${JSON_GLIB_VER:-1.10.6}
LIBXML2_VER=${LIBXML2_VER:-2.13.8}
FUSE3_VER=${FUSE3_VER:-3.17.1}
LIBGUDEV_VER=${LIBGUDEV_VER:-238}
XDG_DESKTOP_PORTAL_VER=${XDG_DESKTOP_PORTAL_VER:-1.20.3}
XDG_DESKTOP_PORTAL_WLR_VER=${XDG_DESKTOP_PORTAL_WLR_VER:-0.7.1}
RTKIT_VER=${RTKIT_VER:-0.13}

# Fonts (tarballs expected in /sources)
DEJAVU_FONTS_VER=${DEJAVU_FONTS_VER:-2.37}
NOTO_FONTS_VER=${NOTO_FONTS_VER:-20201206}
NOTO_EMOJI_VER=${NOTO_EMOJI_VER:-2.047}
JETBRAINS_MONO_VER=${JETBRAINS_MONO_VER:-2.304}
FONT_AWESOME_VER=${FONT_AWESOME_VER:-6.7.2}
NERDFONTS_VER=${NERDFONTS_VER:-3.3.0}
LIBERATION_FONTS_VER=${LIBERATION_FONTS_VER:-2.1.5}
TEXGYRE_FONTS_VER=${TEXGYRE_FONTS_VER:-2.005}

# Pale Moon (experimental; requires python2.7 + autoconf2.13 + yasm)
PALEMOON_VER=${PALEMOON_VER:-33.8.0}  # ajuste conforme seu tarball

###############################################################################
# UI / helpers
###############################################################################

. ./scripts/buildctl.sh

need_cmd() { command -v "$1" >/dev/null 2>&1 || die "missing command: $1"; }

tb_find() {
  name=$1 ver=$2
  for ext in tar.xz tar.gz tgz tar.bz2 tar; do
    p="$SRCDIR/$name-$ver.$ext"
    [ -f "$p" ] && { printf '%s\n' "$p"; return 0; }
  done
  return 1
}

chrun() {
  ROOTFS="$ROOTFS" BIND_MOUNTS="$BIND_MOUNTS" BIND_RO_MOUNTS="$BIND_RO_MOUNTS" \
    "$CHROOT_RUN" run "$1"
}

host_sanity() {
  need_cmd sh
  need_cmd tar
  need_cmd gzip
  need_cmd awk
  need_cmd mount
  need_cmd umount
  need_cmd chroot
  [ -x "$CHROOT_RUN" ] || die "missing CHROOT_RUN: $CHROOT_RUN"
  mkdir -p "$SRCDIR" "$BUILDDIR" "$STATE_DIR" "$LOG_DIR"
  mkdir -p "$PKGDB_DIR/manifests"
}

###############################################################################
# Chroot build templates
###############################################################################

ch_export_flags='export CFLAGS="'"$CFLAGS"'" CXXFLAGS="'"$CXXFLAGS"'" LDFLAGS="'"$LDFLAGS"'"'

ch_prep_pkg() {
  # name ver tarball_basename
  name=$1; ver=$2; tbbase=$3
  cat <<EOF
set -eu
$ch_export_flags
cd /build
rm -rf "$name-$ver" "$name-build"
tar -xf "/sources/$tbbase"
EOF
}

ch_manifest_snap() {
  [ "$TRACK_INSTALLS" = "1" ] || return 0
  # within chroot: snapshot filesystem before install
  name=$1
  cat <<EOF
set -eu
mkdir -p /var/lib/stage-build/manifests
( find /bin /sbin /lib /usr -xdev \( -type f -o -type l \) 2>/dev/null | sort ) > "/var/lib/stage-build/.snap.$name"
EOF
}

ch_manifest_commit() {
  [ "$TRACK_INSTALLS" = "1" ] || return 0
  name=$1
  cat <<EOF
set -eu
snap="/var/lib/stage-build/.snap.$name"
out="/var/lib/stage-build/manifests/$name.list"
[ -f "\$snap" ] || exit 0
( find /bin /sbin /lib /usr -xdev \( -type f -o -type l \) 2>/dev/null | sort ) > "\$snap.new"
comm -13 "\$snap" "\$snap.new" > "\$out" 2>/dev/null || :
rm -f "\$snap" "\$snap.new"
EOF
}

###############################################################################
# Steps
###############################################################################

TOTAL_STEPS=24

step_00_sanity() {
  host_sanity
  msg "Stage4 enabled: curl=$ENABLE_CURL wget=$ENABLE_WGET git=$ENABLE_GIT python=$ENABLE_PYTHON cmake=$ENABLE_CMAKE meson=$ENABLE_MESON ninja=$ENABLE_NINJA ccache=$ENABLE_CCACHE llvm=$ENABLE_LLVM wayland=$ENABLE_WAYLAND_STACK mesa=$ENABLE_MESA"
}

step_05_deps_common() {
  # Build expat, pcre2, libffi, sqlite (needed by git/python/wayland)
  state_done stage4_05_deps_common && return 0

  expat=$(tb_find expat "$EXPAT_VER") || die "missing expat-$EXPAT_VER"
  pcre2=$(tb_find pcre2 "$PCRE2_VER") || die "missing pcre2-$PCRE2_VER"
  libffi=$(tb_find libffi "$LIBFFI_VER") || die "missing libffi-$LIBFFI_VER"
  sqlite=$(tb_find sqlite-autoconf "$SQLITE_VER" 2>/dev/null || true)
  [ -n "${sqlite:-}" ] || sqlite=$(tb_find sqlite "$SQLITE_VER" 2>/dev/null || true)

  # expat
  tbbase=$(basename "$expat")
  chrun "
$(ch_manifest_snap expat)
$(ch_prep_pkg expat "$EXPAT_VER" "$tbbase")
mkdir -p expat-build
cd expat-build
../expat-$EXPAT_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit expat)
"
  # pcre2
  tbbase=$(basename "$pcre2")
  chrun "
$(ch_manifest_snap pcre2)
$(ch_prep_pkg pcre2 "$PCRE2_VER" "$tbbase")
mkdir -p pcre2-build
cd pcre2-build
../pcre2-$PCRE2_VER/configure --prefix=/usr --disable-static --enable-pcre2-8
make -j$JOBS
make install
$(ch_manifest_commit pcre2)
"

  # libffi
  tbbase=$(basename "$libffi")
  chrun "
$(ch_manifest_snap libffi)
$(ch_prep_pkg libffi "$LIBFFI_VER" "$tbbase")
mkdir -p libffi-build
cd libffi-build
../libffi-$LIBFFI_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit libffi)
"

  # sqlite (optional but recommended for python)
  if [ -n "${sqlite:-}" ]; then
    tbbase=$(basename "$sqlite")
    chrun "
$(ch_manifest_snap sqlite)
set -eu
$ch_export_flags
cd /build
rm -rf sqlite-src sqlite-build
mkdir -p sqlite-src
cd sqlite-src
tar -xf /sources/$tbbase --strip-components=1
cd /build
mkdir -p sqlite-build
cd sqlite-build
../sqlite-src/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit sqlite)
"
  fi

  mark_done stage4_05_deps_common
}

step_10_curl() {
  [ "$ENABLE_CURL" = "1" ] || return 0
  state_done stage4_10_curl && return 0
  tb=$(tb_find curl "$CURL_VER") || die "missing curl-$CURL_VER"
  tbbase=$(basename "$tb")
  chrun "
$(ch_manifest_snap curl)
$(ch_prep_pkg curl "$CURL_VER" "$tbbase")
mkdir -p curl-build
cd curl-build
../curl-$CURL_VER/configure --prefix=/usr --with-openssl --disable-static --enable-ipv6
make -j$JOBS
make install
$(ch_manifest_commit curl)
"
  mark_done stage4_10_curl
}

step_11_wget() {
  [ "$ENABLE_WGET" = "1" ] || return 0
  state_done stage4_11_wget && return 0
  tb=$(tb_find wget "$WGET_VER") || die "missing wget-$WGET_VER"
  tbbase=$(basename "$tb")
  chrun "
$(ch_manifest_snap wget)
$(ch_prep_pkg wget "$WGET_VER" "$tbbase")
mkdir -p wget-build
cd wget-build
../wget-$WGET_VER/configure --prefix=/usr --with-ssl=openssl --disable-static --without-libpsl --without-included-regex
make -j$JOBS
make install
$(ch_manifest_commit wget)
"
  mark_done stage4_11_wget
}

step_12_git() {
  [ "$ENABLE_GIT" = "1" ] || return 0
  state_done stage4_12_git && return 0
  tb=$(tb_find git "$GIT_VER") || die "missing git-$GIT_VER"
  tbbase=$(basename "$tb")
  chrun "
$(ch_manifest_snap git)
$(ch_prep_pkg git "$GIT_VER" "$tbbase")
make -j$JOBS prefix=/usr NO_TCLTK=1 NO_GETTEXT=1 NO_PYTHON=1 \
  NEEDS_LIBICONV=0 USE_LIBPCRE2=1 USE_CURL=1
make prefix=/usr install
$(ch_manifest_commit git)
"
  mark_done stage4_12_git
}

step_20_python() {
  [ "$ENABLE_PYTHON" = "1" ] || return 0
  state_done stage4_20_python && return 0
  tb=$(tb_find Python "$PYTHON_VER" 2>/dev/null || true)
  [ -n "${tb:-}" ] || tb=$(tb_find python "$PYTHON_VER")
  tbbase=$(basename "$tb")
  chrun "
$(ch_manifest_snap python)
$(ch_prep_pkg Python "$PYTHON_VER" "$tbbase")
cd Python-$PYTHON_VER 2>/dev/null || cd python-$PYTHON_VER
./configure --prefix=/usr --enable-shared --with-ensurepip=install
make -j$JOBS
make install
# Ensure dynamic linker cache not required on musl
$(ch_manifest_commit python)
"
  mark_done stage4_20_python
}

step_21_cmake() {
  [ "$ENABLE_CMAKE" = "1" ] || return 0
  state_done stage4_21_cmake && return 0
  tb=$(tb_find cmake "$CMAKE_VER") || die "missing cmake-$CMAKE_VER"
  tbbase=$(basename "$tb")
  chrun "
$(ch_manifest_snap cmake)
$(ch_prep_pkg cmake "$CMAKE_VER" "$tbbase")
cd cmake-$CMAKE_VER
./bootstrap --prefix=/usr --parallel=$JOBS
make -j$JOBS
make install
$(ch_manifest_commit cmake)
"
  mark_done stage4_21_cmake
}

step_22_ninja() {
  [ "$ENABLE_NINJA" = "1" ] || return 0
  state_done stage4_22_ninja && return 0
  tb=$(tb_find ninja "$NINJA_VER") || die "missing ninja-$NINJA_VER"
  tbbase=$(basename "$tb")
  chrun "
$(ch_manifest_snap ninja)
$(ch_prep_pkg ninja "$NINJA_VER" "$tbbase")
cd ninja-$NINJA_VER
python3 configure.py --bootstrap
install -m 0755 ninja /usr/bin/ninja
$(ch_manifest_commit ninja)
"
  mark_done stage4_22_ninja
}

step_23_meson() {
  [ "$ENABLE_MESON" = "1" ] || return 0
  state_done stage4_23_meson && return 0
  tb=$(tb_find meson "$MESON_VER") || die "missing meson-$MESON_VER"
  tbbase=$(basename "$tb")
  chrun "
$(ch_manifest_snap meson)
$(ch_prep_pkg meson "$MESON_VER" "$tbbase")
cd meson-$MESON_VER
python3 setup.py build
python3 setup.py install --prefix=/usr --root=/
$(ch_manifest_commit meson)
"
  mark_done stage4_23_meson
}

step_24_ccache() {
  [ "$ENABLE_CCACHE" = "1" ] || return 0
  state_done stage4_24_ccache && return 0
  tb=$(tb_find ccache "$CCACHE_VER") || die "missing ccache-$CCACHE_VER"
  tbbase=$(basename "$tb")
  chrun "
$(ch_manifest_snap ccache)
$(ch_prep_pkg ccache "$CCACHE_VER" "$tbbase")
mkdir -p ccache-build
cd ccache-build
cmake -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr ../ccache-$CCACHE_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit ccache)
"
  mark_done stage4_24_ccache
}

step_30_llvm() {
  [ "$ENABLE_LLVM" = "1" ] || return 0
  state_done stage4_30_llvm && return 0
  tb=$(tb_find llvm-project "$LLVM_VER" 2>/dev/null || true)
  [ -n "${tb:-}" ] || tb=$(tb_find llvm "$LLVM_VER")
  tbbase=$(basename "$tb")
  chrun "
$(ch_manifest_snap llvm)
set -eu
$ch_export_flags
cd /build
rm -rf llvm-project-$LLVM_VER llvm-src llvm-build
mkdir -p llvm-src
tar -xf /sources/$tbbase -C /build
# Normalize source dir
if [ -d /build/llvm-project-$LLVM_VER ]; then
  mv /build/llvm-project-$LLVM_VER /build/llvm-src
elif [ -d /build/llvm-$LLVM_VER ]; then
  mv /build/llvm-$LLVM_VER /build/llvm-src
else
  # fallback: first directory
  d=$(cd /build && ls -1 | awk 'NR==1{print}')
  mv /build/$d /build/llvm-src
fi
mkdir -p /build/llvm-build
cd /build/llvm-build
cmake -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX=/usr \
  -DLLVM_ENABLE_PROJECTS=clang \
  -DLLVM_TARGETS_TO_BUILD=X86 \
  -DLLVM_ENABLE_RTTI=ON \
  -DLLVM_ENABLE_TERMINFO=ON \
  -DLLVM_ENABLE_ZLIB=ON \
  -DLLVM_ENABLE_LIBXML2=OFF \
  -DLLVM_ENABLE_ASSERTIONS=OFF \
  /build/llvm-src/llvm
ninja -j$JOBS
ninja install
$(ch_manifest_commit llvm)
"
  mark_done stage4_30_llvm
}

step_40_wayland_stack() {
  [ "$ENABLE_WAYLAND_STACK" = "1" ] || return 0
  state_done stage4_40_wayland_stack && return 0

  # Required tarballs
  wayland=$(tb_find wayland "$WAYLAND_VER") || die "missing wayland"
  wproto=$(tb_find wayland-protocols "$WAYLAND_PROTOCOLS_VER") || die "missing wayland-protocols"
  libdrm=$(tb_find libdrm "$LIBDRM_VER") || die "missing libdrm"
  xkb=$(tb_find libxkbcommon "$XKBCOMMON_VER") || die "missing libxkbcommon"
  xkcfg=$(tb_find xkeyboard-config "$XKEYBOARD_CONFIG_VER") || die "missing xkeyboard-config"
  pix=$(tb_find pixman "$PIXMAN_VER") || die "missing pixman"
  seatd=$(tb_find seatd "$SEATD_VER") || die "missing seatd"
  libev=$(tb_find libevdev "$LIBEVDEV_VER") || die "missing libevdev"
  mtdev=$(tb_find mtdev "$MTDEV_VER") || die "missing mtdev"
  libin=$(tb_find libinput "$LIBINPUT_VER") || die "missing libinput"
  wlroots=$(tb_find wlroots "$WLROOTS_VER") || die "missing wlroots"

  # Wayland
  chrun "
$(ch_manifest_snap wayland)
set -eu
$ch_export_flags
cd /build
rm -rf wayland-$WAYLAND_VER wayland-build
tar -xf /sources/$(basename "$wayland")
mkdir -p wayland-build
cd wayland-build
meson setup --prefix=/usr --buildtype=release -Ddocumentation=false ../wayland-$WAYLAND_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit wayland)
"
  # wayland-protocols
  chrun "
$(ch_manifest_snap wayland-protocols)
set -eu
$ch_export_flags
cd /build
rm -rf wayland-protocols-$WAYLAND_PROTOCOLS_VER wproto-build
tar -xf /sources/$(basename "$wproto")
mkdir -p wproto-build
cd wproto-build
meson setup --prefix=/usr --buildtype=release ../wayland-protocols-$WAYLAND_PROTOCOLS_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit wayland-protocols)
"
  # libdrm
  chrun "
$(ch_manifest_snap libdrm)
set -eu
$ch_export_flags
cd /build
rm -rf libdrm-$LIBDRM_VER libdrm-build
tar -xf /sources/$(basename "$libdrm")
mkdir -p libdrm-build
cd libdrm-build
meson setup --prefix=/usr --buildtype=release -Dudev=true ../libdrm-$LIBDRM_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit libdrm)
"
  # xkeyboard-config
  chrun "
$(ch_manifest_snap xkeyboard-config)
set -eu
$ch_export_flags
cd /build
rm -rf xkeyboard-config-$XKEYBOARD_CONFIG_VER xkcfg-build
tar -xf /sources/$(basename "$xkcfg")
mkdir -p xkcfg-build
cd xkcfg-build
meson setup --prefix=/usr --buildtype=release ../xkeyboard-config-$XKEYBOARD_CONFIG_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit xkeyboard-config)
"
  # libxkbcommon
  chrun "
$(ch_manifest_snap libxkbcommon)
set -eu
$ch_export_flags
cd /build
rm -rf libxkbcommon-$XKBCOMMON_VER xkb-build
tar -xf /sources/$(basename "$xkb")
mkdir -p xkb-build
cd xkb-build
meson setup --prefix=/usr --buildtype=release -Denable-docs=false -Denable-x11=false ../libxkbcommon-$XKBCOMMON_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit libxkbcommon)
"
  # pixman
  chrun "
$(ch_manifest_snap pixman)
set -eu
$ch_export_flags
cd /build
rm -rf pixman-$PIXMAN_VER pixman-build
tar -xf /sources/$(basename "$pix")
mkdir -p pixman-build
cd pixman-build
meson setup --prefix=/usr --buildtype=release ../pixman-$PIXMAN_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit pixman)
"
  # seatd
  chrun "
$(ch_manifest_snap seatd)
set -eu
$ch_export_flags
cd /build
rm -rf seatd-$SEATD_VER seatd-build
tar -xf /sources/$(basename "$seatd")
mkdir -p seatd-build
cd seatd-build
meson setup --prefix=/usr --buildtype=release -Dlogind=disabled ../seatd-$SEATD_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit seatd)
"
  # libevdev
  chrun "
$(ch_manifest_snap libevdev)
set -eu
$ch_export_flags
cd /build
rm -rf libevdev-$LIBEVDEV_VER libevdev-build
tar -xf /sources/$(basename "$libev")
mkdir -p libevdev-build
cd libevdev-build
meson setup --prefix=/usr --buildtype=release ../libevdev-$LIBEVDEV_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit libevdev)
"
  # mtdev (autotools)
  chrun "
$(ch_manifest_snap mtdev)
$(ch_prep_pkg mtdev "$MTDEV_VER" "$(basename "$mtdev")")
mkdir -p mtdev-build
cd mtdev-build
../mtdev-$MTDEV_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit mtdev)
"
  # libinput
  chrun "
$(ch_manifest_snap libinput)
set -eu
$ch_export_flags
cd /build
rm -rf libinput-$LIBINPUT_VER libinput-build
tar -xf /sources/$(basename "$libin")
mkdir -p libinput-build
cd libinput-build
meson setup --prefix=/usr --buildtype=release -Dtests=false -Ddocumentation=false ../libinput-$LIBINPUT_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit libinput)
"
  # wlroots
  chrun "
$(ch_manifest_snap wlroots)
set -eu
$ch_export_flags
cd /build
rm -rf wlroots-$WLROOTS_VER wlroots-build
tar -xf /sources/$(basename "$wlroots")
mkdir -p wlroots-build
cd wlroots-build
meson setup --prefix=/usr --buildtype=release \
  -Dexamples=false -Dwerror=false -Dlogind=disabled \
  ../wlroots-$WLROOTS_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit wlroots)
"


  # runit service for seatd (required for wlroots without logind)
  chrun "
set -eu
mkdir -p /etc/sv/seatd
cat > /etc/sv/seatd/run <<'EOF'
#!/bin/sh
exec 2>&1
exec /usr/bin/seatd -g video
EOF
chmod 0755 /etc/sv/seatd/run
mkdir -p /etc/service
[ -e /etc/service/seatd ] || ln -s /etc/sv/seatd /etc/service/seatd
# ensure runtime directories
mkdir -p /run/seatd
"
  mark_done stage4_40_wayland_stack

}

step_41_mesa() {
  [ "$ENABLE_WAYLAND_STACK" = "1" ] || return 0
  [ "$ENABLE_MESA" = "1" ] || return 0
  state_done stage4_41_mesa && return 0
  mesa=$(tb_find mesa "$MESA_VER") || die "missing mesa"
  chrun "
$(ch_manifest_snap mesa)
set -eu
$ch_export_flags
cd /build
rm -rf mesa-$MESA_VER mesa-build
tar -xf /sources/$(basename "$mesa")
mkdir -p mesa-build
cd mesa-build
meson setup --prefix=/usr --buildtype=release \
  -Dplatforms=$MESA_PLATFORMS \
  -Dgallium-drivers=$MESA_GALLIUM \
  -Dvulkan-drivers=$MESA_VULKAN \
  -Dgles1=disabled -Dgles2=enabled \
  -Dopengl=true \
  -Dllvm=enabled \
  -Dshared-glapi=enabled \
  -Dglx=disabled \
  -Degl=enabled \
  ../mesa-$MESA_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit mesa)
"
  mark_done stage4_41_mesa
}

step_42_cage() {
  [ "$ENABLE_WAYLAND_STACK" = "1" ] || return 0
  [ "$ENABLE_CAGE" = "1" ] || return 0
  state_done stage4_42_cage && return 0
  cage=$(tb_find cage "$CAGE_VER") || die "missing cage"
  chrun "
$(ch_manifest_snap cage)
set -eu
$ch_export_flags
cd /build
rm -rf cage-$CAGE_VER cage-build
tar -xf /sources/$(basename "$cage")
mkdir -p cage-build
cd cage-build
meson setup --prefix=/usr --buildtype=release ../cage-$CAGE_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit cage)
"
  mark_done stage4_42_cage
}

step_43_foot() {
  [ "$ENABLE_WAYLAND_STACK" = "1" ] || return 0
  [ "$ENABLE_FOOT" = "1" ] || return 0
  state_done stage4_43_foot && return 0
  foot=$(tb_find foot "$FOOT_VER") || die "missing foot"
  chrun "
$(ch_manifest_snap foot)
set -eu
$ch_export_flags
cd /build
rm -rf foot-$FOOT_VER foot-build
tar -xf /sources/$(basename "$foot")
mkdir -p foot-build
cd foot-build
meson setup --prefix=/usr --buildtype=release -Dterminfo=enabled -Ddocs=false ../foot-$FOOT_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit foot)
"
  mark_done stage4_43_foot
}

###############################################################################
# Stage4 extras: GUI deps + sway + wayland utils + ffmpeg + optional Xwayland
###############################################################################

step_35_gui_deps() {
  # json-c + stack de texto/render (freetype/fontconfig/harfbuzz/cairo/pango/gdk-pixbuf) e deps XCB
  state_done stage4_35_gui_deps && return 0

  jsonc=$(tb_find json-c "$JSONC_VER") || die "missing json-c-$JSONC_VER"
  libpng=$(tb_find libpng "$LIBPNG_VER") || die "missing libpng-$LIBPNG_VER"
  ft=$(tb_find freetype "$FREETYPE_VER") || die "missing freetype-$FREETYPE_VER"
  fc=$(tb_find fontconfig "$FONTCONFIG_VER") || die "missing fontconfig-$FONTCONFIG_VER"
  hb=$(tb_find harfbuzz "$HARFBUZZ_VER") || die "missing harfbuzz-$HARFBUZZ_VER"
  fr=$(tb_find fribidi "$FRIBIDI_VER" 2>/dev/null || true)
  jpg=$(tb_find libjpeg-turbo "$LIBJPEG_TURBO_VER" 2>/dev/null || true)
  glib=$(tb_find glib "$GLIB_VER") || die "missing glib-$GLIB_VER"
  cairo=$(tb_find cairo "$CAIRO_VER") || die "missing cairo-$CAIRO_VER"
  pango=$(tb_find pango "$PANGO_VER") || die "missing pango-$PANGO_VER"
  gdkpix=$(tb_find gdk-pixbuf "$GDK_PIXBUF_VER") || die "missing gdk-pixbuf-$GDK_PIXBUF_VER"

  # XCB stack (sway depende em muitas distros; mantém recursos e compatibilidade)
  xorgp=$(tb_find xorgproto "$XORGPROTO_VER") || die "missing xorgproto-$XORGPROTO_VER"
  xau=$(tb_find libXau "$LIBXAU_VER") || die "missing libXau-$LIBXAU_VER"
  xdmcp=$(tb_find libXdmcp "$LIBXDMCP_VER") || die "missing libXdmcp-$LIBXDMCP_VER"
  xcbp=$(tb_find xcb-proto "$XCB_PROTO_VER") || die "missing xcb-proto-$XCB_PROTO_VER"
  xcb=$(tb_find libxcb "$LIBXCB_VER") || die "missing libxcb-$LIBXCB_VER"
  xcu=$(tb_find xcb-util "$XCB_UTIL_VER") || die "missing xcb-util-$XCB_UTIL_VER"
  xcuwm=$(tb_find xcb-util-wm "$XCB_UTIL_WM_VER" 2>/dev/null || true)
  xcurm=$(tb_find xcb-util-xrm "$XCB_UTIL_XRM_VER" 2>/dev/null || true)

  chrun "
$(ch_manifest_snap json-c)
$(ch_prep_pkg json-c "$JSONC_VER" "$(basename "$jsonc")")
mkdir -p jsonc-build
cd jsonc-build
cmake -G Ninja -DCMAKE_INSTALL_PREFIX=/usr -DBUILD_SHARED_LIBS=ON -DBUILD_STATIC_LIBS=OFF ../json-c-$JSONC_VER
ninja -j$JOBS
ninja install
$(ch_manifest_commit json-c)
"

  chrun "
$(ch_manifest_snap xorgproto)
$(ch_prep_pkg xorgproto "$XORGPROTO_VER" "$(basename "$xorgp")")
meson setup --prefix=/usr --buildtype=release xorgproto-build ../xorgproto-$XORGPROTO_VER
ninja -C xorgproto-build -j$JOBS
ninja -C xorgproto-build install
$(ch_manifest_commit xorgproto)
"

  chrun "
$(ch_manifest_snap libXau)
$(ch_prep_pkg libXau "$LIBXAU_VER" "$(basename "$xau")")
mkdir -p xau-build
cd xau-build
../libXau-$LIBXAU_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit libXau)
"

  chrun "
$(ch_manifest_snap libXdmcp)
$(ch_prep_pkg libXdmcp "$LIBXDMCP_VER" "$(basename "$xdmcp")")
mkdir -p xdmcp-build
cd xdmcp-build
../libXdmcp-$LIBXDMCP_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit libXdmcp)
"

  chrun "
$(ch_manifest_snap xcb-proto)
$(ch_prep_pkg xcb-proto "$XCB_PROTO_VER" "$(basename "$xcbp")")
python3 -m pip --version >/dev/null 2>&1 || :
# xcb-proto usa python para gerar; use python3
mkdir -p xcb-proto-build
cd xcb-proto-build
../xcb-proto-$XCB_PROTO_VER/configure --prefix=/usr
make -j$JOBS
make install
$(ch_manifest_commit xcb-proto)
"

  chrun "
$(ch_manifest_snap libxcb)
$(ch_prep_pkg libxcb "$LIBXCB_VER" "$(basename "$xcb")")
mkdir -p xcb-build
cd xcb-build
../libxcb-$LIBXCB_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit libxcb)
"

  chrun "
$(ch_manifest_snap xcb-util)
$(ch_prep_pkg xcb-util "$XCB_UTIL_VER" "$(basename "$xcu")")
mkdir -p xcb-util-build
cd xcb-util-build
../xcb-util-$XCB_UTIL_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit xcb-util)
"

  if [ -n "${xcuwm:-}" ]; then
    chrun "
$(ch_manifest_snap xcb-util-wm)
$(ch_prep_pkg xcb-util-wm "$XCB_UTIL_WM_VER" "$(basename "$xcuwm")")
mkdir -p xcb-util-wm-build
cd xcb-util-wm-build
../xcb-util-wm-$XCB_UTIL_WM_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit xcb-util-wm)
"
  fi

  if [ -n "${xcurm:-}" ]; then
    chrun "
$(ch_manifest_snap xcb-util-xrm)
$(ch_prep_pkg xcb-util-xrm "$XCB_UTIL_XRM_VER" "$(basename "$xcurm")")
mkdir -p xcb-util-xrm-build
cd xcb-util-xrm-build
../xcb-util-xrm-$XCB_UTIL_XRM_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit xcb-util-xrm)
"
  fi

  chrun "
$(ch_manifest_snap libpng)
$(ch_prep_pkg libpng "$LIBPNG_VER" "$(basename "$libpng")")
mkdir -p libpng-build
cd libpng-build
../libpng-$LIBPNG_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit libpng)
"

  chrun "
$(ch_manifest_snap freetype)
$(ch_prep_pkg freetype "$FREETYPE_VER" "$(basename "$ft")")
mkdir -p freetype-build
cd freetype-build
../freetype-$FREETYPE_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit freetype)
"

  chrun "
$(ch_manifest_snap fontconfig)
$(ch_prep_pkg fontconfig "$FONTCONFIG_VER" "$(basename "$fc")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Ddoc=disabled fontconfig-build ../fontconfig-$FONTCONFIG_VER
ninja -C fontconfig-build -j$JOBS
ninja -C fontconfig-build install
$(ch_manifest_commit fontconfig)
"

  if [ -n "${fr:-}" ]; then
    chrun "
$(ch_manifest_snap fribidi)
$(ch_prep_pkg fribidi "$FRIBIDI_VER" "$(basename "$fr")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared fribidi-build ../fribidi-$FRIBIDI_VER
ninja -C fribidi-build -j$JOBS
ninja -C fribidi-build install
$(ch_manifest_commit fribidi)
"
  fi

  chrun "
$(ch_manifest_snap harfbuzz)
$(ch_prep_pkg harfbuzz "$HARFBUZZ_VER" "$(basename "$hb")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dintrospection=disabled harfbuzz-build ../harfbuzz-$HARFBUZZ_VER
ninja -C harfbuzz-build -j$JOBS
ninja -C harfbuzz-build install
$(ch_manifest_commit harfbuzz)
"

  if [ -n "${jpg:-}" ]; then
    chrun "
$(ch_manifest_snap libjpeg-turbo)
$(ch_prep_pkg libjpeg-turbo "$LIBJPEG_TURBO_VER" "$(basename "$jpg")")
cmake -G Ninja -DCMAKE_INSTALL_PREFIX=/usr -DENABLE_STATIC=OFF -DENABLE_SHARED=ON ../libjpeg-turbo-$LIBJPEG_TURBO_VER -B jpeg-build
ninja -C jpeg-build -j$JOBS
ninja -C jpeg-build install
$(ch_manifest_commit libjpeg-turbo)
"
  fi

  chrun "
$(ch_manifest_snap glib)
$(ch_prep_pkg glib "$GLIB_VER" "$(basename "$glib")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dintrospection=disabled -Dtests=false glib-build ../glib-$GLIB_VER
ninja -C glib-build -j$JOBS
ninja -C glib-build install
$(ch_manifest_commit glib)
"

  # cairo/pango/gdk-pixbuf
  chrun "
$(ch_manifest_snap cairo)
$(ch_prep_pkg cairo "$CAIRO_VER" "$(basename "$cairo")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dtests=disabled cairo-build ../cairo-$CAIRO_VER
ninja -C cairo-build -j$JOBS
ninja -C cairo-build install
$(ch_manifest_commit cairo)
"

  chrun "
$(ch_manifest_snap pango)
$(ch_prep_pkg pango "$PANGO_VER" "$(basename "$pango")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dintrospection=disabled -Dgtk_doc=false pango-build ../pango-$PANGO_VER
ninja -C pango-build -j$JOBS
ninja -C pango-build install
$(ch_manifest_commit pango)
"

  chrun "
$(ch_manifest_snap gdk-pixbuf)
$(ch_prep_pkg gdk-pixbuf "$GDK_PIXBUF_VER" "$(basename "$gdkpix")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dintrospection=disabled -Dman=false gdkpix-build ../gdk-pixbuf-$GDK_PIXBUF_VER
ninja -C gdkpix-build -j$JOBS
ninja -C gdkpix-build install
$(ch_manifest_commit gdk-pixbuf)
"

  # Minimal fonts/config
  if [ "$ENABLE_FONTS_MIN" = "1" ]; then
    chrun "
set -eu
mkdir -p /etc/fonts/conf.d /usr/share/fonts
fc-cache -r >/dev/null 2>&1 || :
"
  fi

  mark_done stage4_35_gui_deps
}


step_36_dbus() {
  [ "$ENABLE_DBUS" = "1" ] || return 0
  state_done stage4_36_dbus && return 0

  dbus=$(tb_find dbus "$DBUS_VER") || die "missing dbus-$DBUS_VER"

  chrun "
$(ch_manifest_snap dbus)
$(ch_prep_pkg dbus "$DBUS_VER" "$(basename "$dbus")")
mkdir -p dbus-build
cd dbus-build
../dbus-$DBUS_VER/configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --disable-static --disable-xml-docs --disable-doxygen-docs --disable-systemd
make -j$JOBS
make install
$(ch_manifest_commit dbus)
"

  # runit service
  chrun "
set -eu
mkdir -p /etc/sv/dbus /var/run/dbus
cat > /etc/sv/dbus/run <<'EOF'
#!/bin/sh
exec 2>&1
[ -d /var/run/dbus ] || mkdir -p /var/run/dbus
exec /usr/bin/dbus-daemon --system --nofork --nopidfile
EOF
chmod 0755 /etc/sv/dbus/run
mkdir -p /etc/service
[ -e /etc/service/dbus ] || ln -s /etc/sv/dbus /etc/service/dbus
"
  mark_done stage4_36_dbus
}

step_37_fonts_extra() {
  [ "$ENABLE_FONTS_EXTRA" = "1" ] || return 0
  state_done stage4_37_fonts_extra && return 0

  # Font tarballs expected in /sources. Many upstream releases are .zip;
  # to keep this project dependency-free, repack them into tar.*.
  dejavu=$(tb_find dejavu-fonts-ttf "$DEJAVU_FONTS_VER" 2>/dev/null || true)
  noto=$(tb_find noto-fonts "$NOTO_FONTS_VER" 2>/dev/null || true)
  noto_emoji=$(tb_find noto-emoji "$NOTO_EMOJI_VER" 2>/dev/null || true)
  jbmono=$(tb_find jetbrains-mono "$JETBRAINS_MONO_VER" 2>/dev/null || true)
  awesome=$(tb_find font-awesome "$FONT_AWESOME_VER" 2>/dev/null || true)
  nerd=$(tb_find nerdfonts "$NERDFONTS_VER" 2>/dev/null || true)
  liberation=$(tb_find liberation-fonts "$LIBERATION_FONTS_VER" 2>/dev/null || true)
  texgyre=$(tb_find tex-gyre "$TEXGYRE_FONTS_VER" 2>/dev/null || true)

  chrun "
set -eu
mkdir -p /usr/share/fonts /etc/fonts
mkdir -p /usr/share/fonts/truetype /usr/share/fonts/opentype
install_font_tar() {
  tb=\"\$1\" sub=\"\$2\"
  [ -n \"\$tb\" ] || return 0
  d=\"/usr/share/fonts/\$sub\"
  mkdir -p \"\$d\"
  tar -xf \"/sources/\$(basename \"\$tb\")\" -C \"\$d\" --strip-components=1 2>/dev/null || \\
    tar -xf \"/sources/\$(basename \"\$tb\")\" -C \"\$d\" 2>/dev/null || :
}

install_font_tar "${dejavu:-}" truetype/dejavu
install_font_tar "${noto:-}" truetype/noto
install_font_tar "${noto_emoji:-}" truetype/noto-emoji
install_font_tar "${jbmono:-}" truetype/jetbrains-mono
install_font_tar "${awesome:-}" truetype/font-awesome
install_font_tar "${nerd:-}" truetype/nerdfonts
install_font_tar "${liberation:-}" truetype/liberation
install_font_tar "${texgyre:-}" opentype/tex-gyre

if [ "$ENABLE_FONTS_PROPRIETARY_PLACEHOLDERS" = "1" ]; then
cat > /etc/fonts/local.conf <<'EOF'
<?xml version='1.0'?>
<!DOCTYPE fontconfig SYSTEM 'fonts.dtd'>
<fontconfig>
  <!-- Substitute common proprietary font names with free equivalents -->
  <alias>
    <family>Times New Roman</family>
    <prefer><family>Liberation Serif</family><family>TeX Gyre Termes</family></prefer>
  </alias>
  <alias>
    <family>Courier New</family>
    <prefer><family>Liberation Mono</family><family>DejaVu Sans Mono</family></prefer>
  </alias>
</fontconfig>
EOF
fi

fc-cache -f -v >/dev/null 2>&1 || fc-cache -f >/dev/null 2>&1 || :
"

  mark_done stage4_37_fonts_extra
}

step_38_pipewire_portals() {
  # PipeWire + WirePlumber + xdg-desktop-portal-wlr for screen sharing.
  # These are started in the user session (e.g. via sway config), not as
  # system-wide daemons.
  [ "$ENABLE_PIPEWIRE" = "1" ] || [ "$ENABLE_XDG_PORTAL" = "1" ] || [ "$ENABLE_XDG_PORTAL_WLR" = "1" ] || return 0
  state_done stage4_38_pipewire_portals && return 0

  # Core deps
  if [ "$ENABLE_PIPEWIRE" = "1" ]; then
    alsa=$(tb_find alsa-lib "$ALSA_LIB_VER" 2>/dev/null || true)
    libcap=$(tb_find libcap "$LIBCAP_VER" 2>/dev/null || true)
    pipewire=$(tb_find pipewire "$PIPEWIRE_VER" 2>/dev/null || true)
    wireplumber=$(tb_find wireplumber "$WIREPLUMBER_VER" 2>/dev/null || true)
    lua=$(tb_find lua "$LUA_VER" 2>/dev/null || true)

    # alsa-lib (only if missing)
    if [ -n "${alsa:-}" ]; then
      chrun "
$(ch_manifest_snap alsa-lib)
$(ch_prep_pkg alsa-lib "$ALSA_LIB_VER" "$(basename "$alsa")")
mkdir -p alsa-build
cd alsa-build
../alsa-lib-$ALSA_LIB_VER/configure --prefix=/usr --disable-static
make -j$JOBS
make install
$(ch_manifest_commit alsa-lib)
"
    fi

    if [ -n "${libcap:-}" ]; then
      chrun "
$(ch_manifest_snap libcap)
$(ch_prep_pkg libcap "$LIBCAP_VER" "$(basename "$libcap")")
make -j$JOBS prefix=/usr lib=lib
make prefix=/usr lib=lib install
$(ch_manifest_commit libcap)
"
    fi

    # Lua (wireplumber)
    if [ -n "${lua:-}" ]; then
      chrun "
$(ch_manifest_snap lua)
$(ch_prep_pkg lua "$LUA_VER" "$(basename "$lua")")
make -j$JOBS linux MYCFLAGS=\"$CFLAGS\" MYLDFLAGS=\"$LDFLAGS\"
make INSTALL_TOP=/usr INSTALL_MAN=/usr/share/man install
$(ch_manifest_commit lua)
"
    fi

    [ -n "${pipewire:-}" ] || die "missing pipewire-$PIPEWIRE_VER (required for portals)"
    chrun "
$(ch_manifest_snap pipewire)
$(ch_prep_pkg pipewire "$PIPEWIRE_VER" "$(basename "$pipewire")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared \
  -Ddocs=disabled -Dman=disabled -Dtests=false -Dexamples=false \
  -Dsystemd=disabled -Ddbus=enabled -Dalsa=enabled -Djack=disabled \
  -Dbluez5=disabled -Dgstreamer=disabled pipewire-build ../pipewire-$PIPEWIRE_VER
ninja -C pipewire-build -j$JOBS
ninja -C pipewire-build install
$(ch_manifest_commit pipewire)
"

    if [ "$ENABLE_WIREPLUMBER" = "1" ]; then
      [ -n "${wireplumber:-}" ] || die "missing wireplumber-$WIREPLUMBER_VER"
      chrun "
$(ch_manifest_snap wireplumber)
$(ch_prep_pkg wireplumber "$WIREPLUMBER_VER" "$(basename "$wireplumber")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared \
  -Dsystemd=disabled -Dtests=false -Ddocs=disabled wireplumber-build ../wireplumber-$WIREPLUMBER_VER
ninja -C wireplumber-build -j$JOBS
ninja -C wireplumber-build install
$(ch_manifest_commit wireplumber)
"
    fi
  fi

  # xdg-desktop-portal requires gstreamer + json-glib + fuse3 on many distros.
  if [ "$ENABLE_XDG_PORTAL" = "1" ]; then
    gst=$(tb_find gstreamer "$GSTREAMER_VER" 2>/dev/null || true)
    gstb=$(tb_find gst-plugins-base "$GST_PLUGINS_BASE_VER" 2>/dev/null || true)
    jsonglib=$(tb_find json-glib "$JSON_GLIB_VER" 2>/dev/null || true)
    libxml2=$(tb_find libxml2 "$LIBXML2_VER" 2>/dev/null || true)
    fuse3=$(tb_find fuse "$FUSE3_VER" 2>/dev/null || tb_find fuse3 "$FUSE3_VER" 2>/dev/null || true)
    libgudev=$(tb_find libgudev "$LIBGUDEV_VER" 2>/dev/null || true)
    xdp=$(tb_find xdg-desktop-portal "$XDG_DESKTOP_PORTAL_VER" 2>/dev/null || true)
    [ -n "${xdp:-}" ] || die "missing xdg-desktop-portal-$XDG_DESKTOP_PORTAL_VER"
    [ -n "${gst:-}" ] || die "missing gstreamer-$GSTREAMER_VER (required by xdg-desktop-portal)"
    [ -n "${gstb:-}" ] || die "missing gst-plugins-base-$GST_PLUGINS_BASE_VER (required by xdg-desktop-portal)"
    [ -n "${jsonglib:-}" ] || die "missing json-glib-$JSON_GLIB_VER"
    [ -n "${libxml2:-}" ] || die "missing libxml2-$LIBXML2_VER"
    [ -n "${fuse3:-}" ] || die "missing fuse3-$FUSE3_VER"
    [ -n "${libgudev:-}" ] || die "missing libgudev-$LIBGUDEV_VER"

    chrun "
$(ch_manifest_snap libxml2)
$(ch_prep_pkg libxml2 "$LIBXML2_VER" "$(basename "$libxml2")")
./configure --prefix=/usr --disable-static --without-python
make -j$JOBS
make install
$(ch_manifest_commit libxml2)
"

    chrun "
$(ch_manifest_snap json-glib)
$(ch_prep_pkg json-glib "$JSON_GLIB_VER" "$(basename "$jsonglib")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dtests=false jsonglib-build ../json-glib-$JSON_GLIB_VER
ninja -C jsonglib-build -j$JOBS
ninja -C jsonglib-build install
$(ch_manifest_commit json-glib)
"

    chrun "
$(ch_manifest_snap fuse3)
$(ch_prep_pkg fuse3 "$FUSE3_VER" "$(basename "$fuse3")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dexamples=false -Dtests=false fuse3-build ../fuse3-$FUSE3_VER
ninja -C fuse3-build -j$JOBS
ninja -C fuse3-build install
$(ch_manifest_commit fuse3)
"

    chrun "
$(ch_manifest_snap libgudev)
$(ch_prep_pkg libgudev "$LIBGUDEV_VER" "$(basename "$libgudev")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dintrospection=disabled libgudev-build ../libgudev-$LIBGUDEV_VER
ninja -C libgudev-build -j$JOBS
ninja -C libgudev-build install
$(ch_manifest_commit libgudev)
"

    chrun "
$(ch_manifest_snap gstreamer)
$(ch_prep_pkg gstreamer "$GSTREAMER_VER" "$(basename "$gst")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dtests=false -Dexamples=disabled gst-build ../gstreamer-$GSTREAMER_VER
ninja -C gst-build -j$JOBS
ninja -C gst-build install
$(ch_manifest_commit gstreamer)
"

    chrun "
$(ch_manifest_snap gst-plugins-base)
$(ch_prep_pkg gst-plugins-base "$GST_PLUGINS_BASE_VER" "$(basename "$gstb")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dtests=false -Dexamples=disabled gstb-build ../gst-plugins-base-$GST_PLUGINS_BASE_VER
ninja -C gstb-build -j$JOBS
ninja -C gstb-build install
$(ch_manifest_commit gst-plugins-base)
"

    chrun "
$(ch_manifest_snap xdg-desktop-portal)
$(ch_prep_pkg xdg-desktop-portal "$XDG_DESKTOP_PORTAL_VER" "$(basename "$xdp")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dtests=false xdp-build ../xdg-desktop-portal-$XDG_DESKTOP_PORTAL_VER
ninja -C xdp-build -j$JOBS
ninja -C xdp-build install
$(ch_manifest_commit xdg-desktop-portal)
"
  fi

  if [ "$ENABLE_XDG_PORTAL_WLR" = "1" ]; then
    xdpw=$(tb_find xdg-desktop-portal-wlr "$XDG_DESKTOP_PORTAL_WLR_VER" 2>/dev/null || true)
    [ -n "${xdpw:-}" ] || die "missing xdg-desktop-portal-wlr-$XDG_DESKTOP_PORTAL_WLR_VER"
    chrun "
$(ch_manifest_snap xdg-desktop-portal-wlr)
$(ch_prep_pkg xdg-desktop-portal-wlr "$XDG_DESKTOP_PORTAL_WLR_VER" "$(basename "$xdpw")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dlogind=disabled xdpw-build ../xdg-desktop-portal-wlr-$XDG_DESKTOP_PORTAL_WLR_VER
ninja -C xdpw-build -j$JOBS
ninja -C xdpw-build install
$(ch_manifest_commit xdg-desktop-portal-wlr)
"

    # Default config (system-wide). Users can override in ~/.config/...
    chrun "
set -eu
mkdir -p /etc/xdg/xdg-desktop-portal-wlr
cat > /etc/xdg/xdg-desktop-portal-wlr/config <<'EOF'
[screencast]
max_fps=30
chooser_type=simple
EOF
"
  fi

  # Helper to start user-session daemons from sway (or another compositor)
  chrun "
set -eu
cat > /usr/bin/wayland-session-init <<'EOF'
#!/bin/sh
# Start (once per login) common Wayland user daemons needed for a usable session.
# Safe to call from sway config (exec_always).

set -eu

# Ensure XDG_RUNTIME_DIR exists if logind isn't providing it.
if [ -z "${XDG_RUNTIME_DIR:-}" ]; then
  uid=$(id -u 2>/dev/null || echo 0)
  rd="/run/user/$uid"
  if [ ! -d "$rd" ]; then
    mkdir -p "$rd" 2>/dev/null || rd="/tmp/xdg-runtime-$uid"
    mkdir -p "$rd" 2>/dev/null || :
  fi
  chmod 0700 "$rd" 2>/dev/null || :
  export XDG_RUNTIME_DIR="$rd"
fi

# One-shot lock per session
lock="$XDG_RUNTIME_DIR/.wayland-session-init.done"
[ -f "$lock" ] && exit 0
: >"$lock" 2>/dev/null || :

export XDG_CURRENT_DESKTOP=${XDG_CURRENT_DESKTOP:-sway}
export MOZ_ENABLE_WAYLAND=${MOZ_ENABLE_WAYLAND:-1}

start_bg() {
  cmd=$1; shift
  command -v "$cmd" >/dev/null 2>&1 || return 0
  "$cmd" "$@" >/dev/null 2>&1 &
}

start_bg pipewire
start_bg wireplumber

# Portals: order matters (backend before dispatcher is usually fine; dispatcher will respawn backend on demand)
start_bg xdg-desktop-portal-wlr
start_bg xdg-desktop-portal

exit 0
EOF
chmod 0755 /usr/bin/wayland-session-init
"

  mark_done stage4_38_pipewire_portals
}
step_44_sway() {
  [ "$ENABLE_SWAY" = "1" ] || return 0
  state_done stage4_44_sway && return 0

  sway=$(tb_find sway "$SWAY_VER") || die "missing sway-$SWAY_VER"
  swaybg=$(tb_find swaybg "$SWAYBG_VER" 2>/dev/null || true)
  swayidle=$(tb_find swayidle "$SWAYIDLE_VER" 2>/dev/null || true)
  swaylock=$(tb_find swaylock "$SWAYLOCK_VER" 2>/dev/null || true)
  wofi=$(tb_find wofi "$WOFI_VER" 2>/dev/null || true)

  # Sway
  chrun "
$(ch_manifest_snap sway)
$(ch_prep_pkg sway "$SWAY_VER" "$(basename "$sway")")
meson setup --prefix=/usr --buildtype=release -Ddefault_library=shared -Dman-pages=disabled -Dzsh-completions=false -Dbash-completions=false sway-build ../sway-$SWAY_VER
ninja -C sway-build -j$JOBS
ninja -C sway-build install
$(ch_manifest_commit sway)
"

  # Optional companions
  if [ -n "${swaybg:-}" ]; then
    chrun "
$(ch_manifest_snap swaybg)
$(ch_prep_pkg swaybg "$SWAYBG_VER" "$(basename "$swaybg")")
meson setup --prefix=/usr --buildtype=release swaybg-build ../swaybg-$SWAYBG_VER
ninja -C swaybg-build -j$JOBS
ninja -C swaybg-build install
$(ch_manifest_commit swaybg)
"
  fi
  if [ -n "${swayidle:-}" ]; then
    chrun "
$(ch_manifest_snap swayidle)
$(ch_prep_pkg swayidle "$SWAYIDLE_VER" "$(basename "$swayidle")")
meson setup --prefix=/usr --buildtype=release swayidle-build ../swayidle-$SWAYIDLE_VER
ninja -C swayidle-build -j$JOBS
ninja -C swayidle-build install
$(ch_manifest_commit swayidle)
"
  fi
  if [ -n "${swaylock:-}" ]; then
    chrun "
$(ch_manifest_snap swaylock)
$(ch_prep_pkg swaylock "$SWAYLOCK_VER" "$(basename "$swaylock")")
meson setup --prefix=/usr --buildtype=release swaylock-build ../swaylock-$SWAYLOCK_VER
ninja -C swaylock-build -j$JOBS
ninja -C swaylock-build install
$(ch_manifest_commit swaylock)
"
  fi

  if [ -n "${wofi:-}" ]; then
    chrun "
$(ch_manifest_snap wofi)
$(ch_prep_pkg wofi "$WOFI_VER" "$(basename "$wofi")")
meson setup --prefix=/usr --buildtype=release wofi-build ../wofi-$WOFI_VER
ninja -C wofi-build -j$JOBS
ninja -C wofi-build install
$(ch_manifest_commit wofi)
"
  fi

  # Minimal config and environment
  chrun "
set -eu
mkdir -p /etc/sway /etc/profile.d
if [ ! -f /etc/sway/config ]; then
cat > /etc/sway/config <<'EOF'
# Minimal sway config
set \$mod Mod4
font pango:monospace 10

# Terminal
bindsym \$mod+Return exec foot

# Launcher (optional)
bindsym \$mod+d exec wofi --show drun 2>/dev/null || true

# Basic binds
bindsym \$mod+Shift+e exec 'swaymsg exit'

# Background (optional)
exec_always swaybg -c '#202020' 2>/dev/null || true

# Session services (PipeWire, portals...) if installed
exec_always wayland-session-init 2>/dev/null || true

# Input defaults
input * xkb_layout us
EOF
fi

cat > /etc/profile.d/wayland.sh <<'EOF'
# Wayland defaults
export MOZ_ENABLE_WAYLAND=1

# Many Wayland components rely on XDG_RUNTIME_DIR. On systems without logind,
# we create a per-user runtime dir on login.
if [ -z "${XDG_RUNTIME_DIR:-}" ]; then
  uid=$(id -u 2>/dev/null || echo 0)
  rd="/run/user/$uid"
  if [ ! -d "$rd" ]; then
    mkdir -p "$rd" 2>/dev/null || rd="/tmp/xdg-runtime-$uid"
    mkdir -p "$rd" 2>/dev/null || :
  fi
  chmod 0700 "$rd" 2>/dev/null || :
  export XDG_RUNTIME_DIR="$rd"
fi
EOF
"
  mark_done stage4_44_sway
}

step_45_wayland_utils() {
  [ "$ENABLE_WAYLAND_UTILS" = "1" ] || return 0
  state_done stage4_45_wayland_utils && return 0

  grim=$(tb_find grim "$GRIM_VER" 2>/dev/null || true)
  slurp=$(tb_find slurp "$SLURP_VER" 2>/dev/null || true)
  wlc=$(tb_find wl-clipboard "$WL_CLIPBOARD_VER" 2>/dev/null || true)
  wlu=$(tb_find wayland-utils "$WAYLAND_UTILS_VER" 2>/dev/null || true)

  if [ -n "${grim:-}" ]; then
    chrun "
$(ch_manifest_snap grim)
$(ch_prep_pkg grim "$GRIM_VER" "$(basename "$grim")")
meson setup --prefix=/usr --buildtype=release grim-build ../grim-$GRIM_VER
ninja -C grim-build -j$JOBS
ninja -C grim-build install
$(ch_manifest_commit grim)
"
  fi
  if [ -n "${slurp:-}" ]; then
    chrun "
$(ch_manifest_snap slurp)
$(ch_prep_pkg slurp "$SLURP_VER" "$(basename "$slurp")")
meson setup --prefix=/usr --buildtype=release slurp-build ../slurp-$SLURP_VER
ninja -C slurp-build -j$JOBS
ninja -C slurp-build install
$(ch_manifest_commit slurp)
"
  fi
  if [ -n "${wlc:-}" ]; then
    chrun "
$(ch_manifest_snap wl-clipboard)
$(ch_prep_pkg wl-clipboard "$WL_CLIPBOARD_VER" "$(basename "$wlc")")
meson setup --prefix=/usr --buildtype=release wlclip-build ../wl-clipboard-$WL_CLIPBOARD_VER
ninja -C wlclip-build -j$JOBS
ninja -C wlclip-build install
$(ch_manifest_commit wl-clipboard)
"
  fi
  if [ -n "${wlu:-}" ]; then
    chrun "
$(ch_manifest_snap wayland-utils)
$(ch_prep_pkg wayland-utils "$WAYLAND_UTILS_VER" "$(basename "$wlu")")
meson setup --prefix=/usr --buildtype=release wlu-build ../wayland-utils-$WAYLAND_UTILS_VER
ninja -C wlu-build -j$JOBS
ninja -C wlu-build install
$(ch_manifest_commit wayland-utils)
"
  fi

  mark_done stage4_45_wayland_utils
}

step_47_ffmpeg() {
  [ "$ENABLE_FFMPEG" = "1" ] || return 0
  state_done stage4_47_ffmpeg && return 0

  ff=$(tb_find ffmpeg "$FFMPEG_VER") || die "missing ffmpeg-$FFMPEG_VER"
  nasm=$(tb_find nasm "$NASM_VER") || die "missing nasm-$NASM_VER"

  # nasm
  chrun "
$(ch_manifest_snap nasm)
$(ch_prep_pkg nasm "$NASM_VER" "$(basename "$nasm")")
mkdir -p nasm-build
cd nasm-build
../nasm-$NASM_VER/configure --prefix=/usr
make -j$JOBS
make install
$(ch_manifest_commit nasm)
"

  # ffmpeg (base funcional, sem codecs externos pesados)
  chrun "
$(ch_manifest_snap ffmpeg)
$(ch_prep_pkg ffmpeg "$FFMPEG_VER" "$(basename "$ff")")
export PKG_CONFIG_PATH=/usr/lib/pkgconfig:/usr/share/pkgconfig
./configure --prefix=/usr --disable-static --enable-shared --disable-debug --enable-pic \\
  --enable-gpl --enable-version3 \\
  --enable-openssl \\
  --disable-doc
make -j$JOBS
make install
$(ch_manifest_commit ffmpeg)
"
  mark_done stage4_47_ffmpeg
}

step_50_palemoon() {
  [ "$ENABLE_PALEMOON" = "1" ] || return 0
  state_done stage4_50_palemoon && return 0

  die "Pale Moon em musl é experimental (upstream requer python2.7+autoconf2.13+yasm e não suporta musl oficialmente). Veja README; habilite apenas se você já tiver toolchain/patches e tarball apropriado."
}

step_90_revdep() {
  state_done stage4_90_revdep && return 0
  # Run revdep in chroot as a gate (exit 2 if problems)
  chrun "
set -eu
if [ -x /usr/sbin/revdep.sh ]; then
  /usr/sbin/revdep.sh --root / --strict || exit 2
fi
"
  mark_done stage4_90_revdep
}

step_99_verify() {
  state_done stage4_99_verify && return 0
  chrun "
set -eu
command -v curl >/dev/null || :
command -v git  >/dev/null || :
command -v python3 >/dev/null || :
command -v cmake >/dev/null || :
command -v meson >/dev/null || :
command -v ninja >/dev/null || :
command -v ccache >/dev/null || :
if [ '$ENABLE_WAYLAND_STACK' = '1' ]; then
  command -v wayland-scanner >/dev/null || :
  command -v cage >/dev/null || :
  command -v foot >/dev/null || :
fi
"
  mark_done stage4_99_verify
}

###############################################################################
# Main
###############################################################################

cmd=${1:-all}

case "$cmd" in
  all)
    run_step "00_sanity" step_00_sanity
    run_step "05_deps_common" step_05_deps_common
    run_step "10_curl" step_10_curl
    run_step "11_wget" step_11_wget
    run_step "12_git" step_12_git
    run_step "20_python" step_20_python
    run_step "21_cmake" step_21_cmake
    run_step "22_ninja" step_22_ninja
    run_step "23_meson" step_23_meson
    run_step "24_ccache" step_24_ccache
    run_step "30_llvm" step_30_llvm
    run_step "40_wayland_stack" step_40_wayland_stack
    run_step "41_mesa" step_41_mesa
    run_step "35_gui_deps" step_35_gui_deps
    run_step "36_dbus" step_36_dbus
    run_step "37_fonts_extra" step_37_fonts_extra
    run_step "38_pipewire_portals" step_38_pipewire_portals
    run_step "42_cage" step_42_cage
    run_step "43_foot" step_43_foot
    run_step "44_sway" step_44_sway
    run_step "45_wayland_utils" step_45_wayland_utils
    run_step "47_ffmpeg" step_47_ffmpeg
    run_step "50_palemoon" step_50_palemoon

    run_step "90_revdep" step_90_revdep
    run_step "99_verify" step_99_verify
    msg "Stage4 complete."
    ;;
  verify)
    run_step "90_revdep" step_90_revdep
    run_step "99_verify" step_99_verify
    ;;
  *)
    die "unknown command: $cmd"
    ;;
esac




