# Notas de implementação (como finalizar os templates)

Este repo vem com stages 2..6 como templates para manter o projeto enxuto e portátil.
Para transformá-lo numa distro completa, você irá:

1) Adicionar receitas base (bash, coreutils, util-linux, e2fsprogs, procps-ng, iproute2, dhcpcd/connman, etc.)
2) Em stage2/stage3, executar essas receitas dentro do chroot (ou via DESTDIR no rootfs).
3) Em stage4, compilar kernel e instalar GRUB (BIOS ou UEFI).
4) Em stage5, compilar Wayland stack e configurar seatd + sessão do sway.
5) Em stage6, criar a imagem com partições e copiar o rootfs final para ela.

## Recomendação prática
- Comece com boot em QEMU (BIOS/SeaBIOS), depois evolua para UEFI (OVMF).
- Para seatd + sway, garanta:
  - libinput + xkbcommon + fontconfig + pango + cairo
  - udev (eudev) ou equivalente para /dev e permissões
  - usuário não-root no login (agetty + login/Shadow) ou getty direto em tty.

## Por que templates?
Porque a compilação completa de um desktop moderno (mesa + wlroots + sway) depende de um conjunto grande de libs.
O framework de stages aqui já está pronto para você inserir esse conjunto, com cache, lockfile e manifests.
