#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/_common.sh"

PKG="zlib"
RECIPE_DEPS=()

recipe_main() {
  export_cross_env
  export_destdir_env
  local src; src="$(recipe_unpack "zlib")"
  recipe_apply_patches "${src}"

  pushd "${src}" >/dev/null
  # zlib tem configure próprio; use CC com sysroot
  CHOST="${TARGET_TRIPLET}" \
  CC="${CC}" \
  CFLAGS="${CFLAGS}" \
  ./configure --prefix=/usr
  make -j"${JOBS}"
  make install
  popd >/dev/null
}
