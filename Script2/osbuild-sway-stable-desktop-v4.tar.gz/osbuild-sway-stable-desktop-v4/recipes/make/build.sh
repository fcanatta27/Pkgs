#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/_common.sh"

PKG="make"
RECIPE_DEPS=()

recipe_main() {
  local stage="${1}"
  export_cross_env
  export_destdir_env

  local src; src="$(recipe_unpack "make")"
  recipe_apply_patches "${src}"

  local bld="$(pkg_work_builddir "make")"
  pushd "${src}" >/dev/null || true
  popd >/dev/null || true

  rm -rf "${bld}"; mkdir -p "${bld}"
  pushd "${bld}" >/dev/null
  # Configure
  "${src}/configure" --host="${TARGET_TRIPLET}" --build="$(gcc -dumpmachine)" --prefix=/usr 
  make -j"${JOBS}"
  make install
  popd >/dev/null
}
