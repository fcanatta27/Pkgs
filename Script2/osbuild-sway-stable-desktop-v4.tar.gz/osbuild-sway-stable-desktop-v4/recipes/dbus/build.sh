#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/_common.sh"

PKG="dbus"
RECIPE_DEPS=(expat)

recipe_main() {
  export_cross_env
  export_destdir_env

  local src; src="$(recipe_unpack "dbus")"
  recipe_apply_patches "${src}"
  local bld="$(pkg_work_builddir "dbus")"
  rm -rf "${bld}"; mkdir -p "${bld}"
  pushd "${bld}" >/dev/null
  "${src}/configure" --host="${TARGET_TRIPLET}" --build="$(gcc -dumpmachine)" --prefix=/usr --disable-static --without-x
  make -j"${JOBS}"
  make install
  popd >/dev/null
}
