#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/_common.sh"

PKG="seatd"
RECIPE_DEPS=(eudev)

recipe_main() {
  export_cross_env
  export_destdir_env
  need_cmd meson
  need_cmd ninja
  local src; src="$(recipe_unpack "seatd")"
  recipe_apply_patches "${src}"
  local bld="$(pkg_work_builddir "seatd")"
  rm -rf "${bld}"; mkdir -p "${bld}"
  pushd "${bld}" >/dev/null
  meson setup "${src}" --prefix=/usr --libdir=lib --buildtype=release -Dserver=enabled -Dlibseat=enabled -Dlibseat-logind=disabled -Dlibseat-seatd=enabled -Dlibseat-udev=enabled
  ninja -j"${JOBS}"
  DESTDIR="${DESTDIR}" ninja install
  popd >/dev/null
}
