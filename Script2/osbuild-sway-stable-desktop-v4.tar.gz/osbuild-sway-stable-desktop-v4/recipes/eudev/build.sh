#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/_common.sh"

PKG="eudev"
RECIPE_DEPS=()

recipe_main() {
  export_cross_env
  export_destdir_env

  local src; src="$(recipe_unpack "eudev")"
  recipe_apply_patches "${src}"

  local bld="$(pkg_work_builddir "eudev")"
  rm -rf "${bld}"; mkdir -p "${bld}"
  pushd "${bld}" >/dev/null
  # eudev usa autotools
  "${src}/configure" --host="${TARGET_TRIPLET}" --build="$(gcc -dumpmachine)" --prefix=/usr \
    --disable-static --enable-manpages=no
  make -j"${JOBS}"
  make install

  # Ensure libudev.so is available for consumers
  if [[ -f "${DESTDIR}/usr/lib/libudev.so" ]]; then :; fi
  popd >/dev/null

  # Minimal udev rules dir
  mkdir -p "${DESTDIR}/etc/udev/rules.d" "${DESTDIR}/lib/udev/rules.d"
}
