#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/_common.sh"

PKG="sysvinit"
RECIPE_DEPS=()

recipe_main() {
  export_cross_env
  export_destdir_env
  local src; src="$(recipe_unpack "sysvinit")"
  recipe_apply_patches "${src}"

  pushd "${src}" >/dev/null
  make -j"${JOBS}" CC="${CC}" ROOT="${DESTDIR}" PREFIX=/usr
  make ROOT="${DESTDIR}" PREFIX=/usr install
  popd >/dev/null
}
