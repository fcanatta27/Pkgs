#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/_common.sh"

PKG="busybox"
RECIPE_DEPS=()

recipe_main() {
  export_cross_env
  export_destdir_env
  local src; src="$(recipe_unpack "busybox")"
  recipe_apply_patches "${src}"

  pushd "${src}" >/dev/null
  make distclean || true
  make defconfig
  # Prefer applets in /bin
  sed -i 's|^CONFIG_PREFIX=.*|CONFIG_PREFIX="'"${DESTDIR}"'"|' .config || true
  # Build dynamic busybox for rootfs
  make -j"${JOBS}"
  make CONFIG_PREFIX="${DESTDIR}" install
  # Ensure /bin/sh
  ln -sf busybox "${DESTDIR}/bin/sh"
  popd >/dev/null
}
