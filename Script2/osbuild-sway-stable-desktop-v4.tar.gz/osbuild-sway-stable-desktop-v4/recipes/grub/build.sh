#!/usr/bin/env bash
set -euo pipefail
# Receita (template) para grub
# Implementar: configure/build/install com prefix e DESTDIR coerentes com stage.

echo "TODO: recipe grub"
