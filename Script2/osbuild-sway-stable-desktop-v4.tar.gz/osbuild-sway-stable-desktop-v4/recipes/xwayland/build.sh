#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/_common.sh"

PKG="xwayland"
RECIPE_DEPS=(
  xorgproto xtrans
  xcb_proto libXau libXdmcp libxcb
  libX11 libXext libXfixes libXdamage libXrender libXrandr libXi libXcursor libXinerama libXpresent
  libxshmfence libepoxy
  libpciaccess libxcvt libxkbfile libXfont2
  xcb_util xcb_util_wm xcb_util_image xcb_util_keysyms xcb_util_renderutil xcb_util_cursor
  pixman libdrm xkbcomp xkeyboard_config
)

recipe_main() {
  export_cross_env
  export_destdir_env
  need_cmd meson; need_cmd ninja; need_cmd python3

  local src; src="$(recipe_unpack "xwayland")"
  recipe_apply_patches "${src}"
  local bld="$(pkg_work_builddir "xwayland")"
  rm -rf "${bld}"; mkdir -p "${bld}"

  pushd "${bld}" >/dev/null
  # xwayland (xserver) options vary by release; keep conservative.
  meson setup "${src}" --prefix=/usr --libdir=lib --buildtype=release \
    -Dxwayland=true -Dglamor=true -Ddocs=false -Dipv6=true \
    -Dxdmcp=false -Dxcsecurity=false -Dxorg=false || \
  meson setup "${src}" --prefix=/usr --libdir=lib --buildtype=release
  ninja -j"${JOBS}"
  DESTDIR="${DESTDIR}" ninja install
  popd >/dev/null
}
