#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/_common.sh"

PKG="wlroots"
RECIPE_DEPS=(wayland wayland_protocols mesa libdrm xkbcommon libinput seatd)

recipe_main() {
  export_cross_env
  export_destdir_env
  need_cmd meson; need_cmd ninja
  local src; src="$(recipe_unpack "wlroots")"
  local bld="$(pkg_work_builddir "wlroots")"
  rm -rf "${bld}"; mkdir -p "${bld}"
  local xw="false"
  if [[ "${ENABLE_XWAYLAND:-0}" == "1" ]]; then xw="true"; fi
  pushd "${bld}" >/dev/null
  meson setup "${src}" --prefix=/usr --libdir=lib --buildtype=release \
    -Dexamples=false -Dxwayland="${xw}"
  ninja -j"${JOBS}"
  DESTDIR="${DESTDIR}" ninja install
  popd >/dev/null
}
