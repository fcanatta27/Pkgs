#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/_common.sh"

PKG="libXcursor"
RECIPE_DEPS=(xorgproto libXrender libXfixes)

recipe_main() {
  export_cross_env
  export_destdir_env

  local src; src="$(recipe_unpack "libXcursor")"
  recipe_apply_patches "${src}"
  local bld="$(pkg_work_builddir "libXcursor")"
  rm -rf "${bld}"; mkdir -p "${bld}"
  pushd "${bld}" >/dev/null
  "${src}/configure" --host="${TARGET_TRIPLET}" --build="$(gcc -dumpmachine)" --prefix=/usr 
  make -j"${JOBS}"
  make install
  popd >/dev/null
}
