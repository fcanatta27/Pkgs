#!/usr/bin/env bash
set -euo pipefail
# Common recipe pattern. Each recipe must define:
#   PKG="<name-in-lockfile>"
#   RECIPE_DEPS=(...)
#   recipe_main() { ... }
#
# Helpers from lib/common.sh + lib/build.sh are available in the environment.

recipe_unpack() {
  local pkg="$1"
  prepare_source "${pkg}"
  local top; top="$(autodetect_topdir "$(pkg_work_srcdir "${pkg}")")"
  echo "${top}"
}

recipe_apply_patches() {
  local dir="$1"
  local pdir="$(dirname "${BASH_SOURCE[1]}")/patches"
  if [[ -d "${pdir}" ]]; then
    log "Aplicando patches: ${pdir}"
    for p in "${pdir}"/*.patch; do
      [[ -f "$p" ]] || continue
      patch -d "${dir}" -p1 < "$p"
    done
  fi
}
