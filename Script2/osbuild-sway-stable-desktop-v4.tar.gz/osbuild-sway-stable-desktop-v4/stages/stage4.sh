#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
source "${REPO_ROOT}/lib/build.sh"

log "Stage4: kernel + initramfs + GRUB config"
rm -rf "${OUT_DIR}/stage4"
mkdir -p "${OUT_DIR}/stage4" "${OUT_DIR}/images" "${WORK_DIR}/stage4"

fetch_one linux_headers
fetch_one grub
# kernel source is linux_headers entry (same tarball). For clarity, reuse it.
KERNEL_TAR="$(pkg_tarball_path linux_headers)"
rm -rf "${WORK_DIR}/stage4/src"
mkdir -p "${WORK_DIR}/stage4/src"
extract_tarball "${KERNEL_TAR}" "${WORK_DIR}/stage4/src"
KDIR="$(find "${WORK_DIR}/stage4/src" -maxdepth 1 -type d -name 'linux-*' | head -n1)"
[[ -n "${KDIR}" ]] || die "Kernel source não encontrado"

need_cmd make

pushd "${KDIR}" >/dev/null
if [[ -f "${REPO_ROOT}/${KERNEL_CONFIG}" ]]; then
  cp "${REPO_ROOT}/${KERNEL_CONFIG}" .config
else
  make defconfig
fi
make -j"${JOBS}"
sudo make modules_install INSTALL_MOD_PATH="${ROOTFS_DIR}"
sudo make INSTALL_PATH="${ROOTFS_DIR}/boot" install
popd >/dev/null

# Initramfs minimal (busybox already in rootfs)
log "Gerando initramfs"
INITDIR="${WORK_DIR}/stage4/initramfs"
rm -rf "${INITDIR}"
mkdir -p "${INITDIR}"/{bin,sbin,etc,proc,sys,dev,newroot}
cp -a "${ROOTFS_DIR}/bin/busybox" "${INITDIR}/bin/"
ln -sf busybox "${INITDIR}/bin/sh"

cat >"${INITDIR}/init" <<'EOF'
#!/bin/sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev 2>/dev/null || true
echo "Initramfs: switching to real root..."
exec switch_root /newroot /sbin/init
EOF
chmod +x "${INITDIR}/init"

# Pack initramfs
pushd "${INITDIR}" >/dev/null
find . -print0 | cpio --null -ov --format=newc | zstd -T0 -19 -o "${ROOTFS_DIR}/boot/initramfs.zst"
popd >/dev/null

# GRUB config (root=/dev/vda1 em QEMU virtio)
sudo mkdir -p "${ROOTFS_DIR}/boot/grub"
sudo tee "${ROOTFS_DIR}/boot/grub/grub.cfg" >/dev/null <<'EOF'
set timeout=3
set default=0

menuentry "osbuild" {
  linux /boot/vmlinuz root=/dev/vda1 rw console=tty1
  initrd /boot/initramfs.zst
}
EOF

payload=$(cat <<EOF
{
  "stage": "stage4",
  "timestamp": "$(date -Iseconds)"
}
EOF
)
manifest_write "stage4" "${payload}"
# SHA manifest para integrity
write_sha_manifest "${OUT_DIR}/stage4" "${MANIFESTS_DIR}/stage4.sha256"
pack_stage "stage4" >/dev/null
log "Stage4 concluído"
