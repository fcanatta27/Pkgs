#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
source "${REPO_ROOT}/lib/build.sh"

log "Stage2: construir userland base no ROOTFS (DESTDIR) + preparar chroot"
rm -rf "${OUT_DIR}/stage2"
mkdir -p "${OUT_DIR}/stage2"

[[ -d "${ROOTFS_DIR}" ]] || die "Rode stage0 primeiro"
[[ -d "${TOOLS_DIR}/bin" ]] || die "Rode stage1 primeiro"
[[ -d "${SYSROOT_DIR}/usr" ]] || die "SYSROOT ausente; rode stage1"

# 1) Instalar glibc do SYSROOT para ROOTFS
log "Copiando sysroot (/usr) para rootfs"
sudo rsync -a "${SYSROOT_DIR}/usr/" "${ROOTFS_DIR}/usr/"
# loader/ld-linux e libs para /lib64 (glibc geralmente instala no sysroot/usr/lib; ajuste se necessário)
sudo mkdir -p "${ROOTFS_DIR}/lib64" "${ROOTFS_DIR}/lib"
if [[ -f "${SYSROOT_DIR}/lib64/ld-linux-x86-64.so.2" ]]; then
  sudo rsync -a "${SYSROOT_DIR}/lib64/" "${ROOTFS_DIR}/lib64/"
fi
# Fallback: procure loader no sysroot
ldpath="$(find "${SYSROOT_DIR}" -path "*ld-linux-x86-64.so.2" -type f | head -n1 || true)"
if [[ -n "${ldpath}" ]]; then
  sudo install -m 0755 "${ldpath}" "${ROOTFS_DIR}/lib64/ld-linux-x86-64.so.2"
fi

# 2) Copiar toolchain /tools para rootfs
sudo mkdir -p "${ROOTFS_DIR}/tools"
sudo rsync -a "${TOOLS_DIR}/" "${ROOTFS_DIR}/tools/"

# 3) Criar symlinks essenciais e PATH
sudo ln -sf usr/bin "${ROOTFS_DIR}/bin" || true
sudo ln -sf usr/sbin "${ROOTFS_DIR}/sbin" || true

cat <<'EOF' | sudo tee "${ROOTFS_DIR}/etc/profile" >/dev/null
export PATH=/tools/bin:/usr/bin:/usr/sbin:/bin:/sbin
EOF

# 4) Build base packages (DESTDIR -> ROOTFS)
# Observação: alguns pacotes podem exigir deps adicionais do host (bison, flex, perl, python, etc.)
log "Instalando opm (gerenciador de pacotes)"
sudo mkdir -p "${ROOTFS_DIR}/usr/sbin" "${ROOTFS_DIR}/var/lib/opm/db" "${ROOTFS_DIR}/var/cache/opm"
sudo install -m 0755 "${REPO_ROOT}/files/usr/sbin/opm" "${ROOTFS_DIR}/usr/sbin/opm"

log "Construindo base packages"
resolve_and_build "stage2" \
  shadow \
  zlib ncurses readline bash coreutils grep sed gawk findutils diffutils make util_linux e2fsprogs busybox

# 5) Garantir diretórios runtime
sudo mkdir -p "${ROOTFS_DIR}"/{dev,proc,sys,run,var/log,var/lib,var/run,tmp}
sudo chmod 1777 "${ROOTFS_DIR}/tmp"

payload=$(cat <<EOF
{
  "stage": "stage2",
  "timestamp": "$(date -Iseconds)",
  "rootfs_hash": "$(sudo bash -c "find '${ROOTFS_DIR}' -type f -print0 | sort -z | xargs -0 sha256sum 2>/dev/null | sha256sum | awk '{print $1}'" || echo "na")"
}
EOF
)
manifest_write "stage2" "${payload}"
# SHA manifest para integrity
write_sha_manifest "${OUT_DIR}/stage2" "${MANIFESTS_DIR}/stage2.sha256"
pack_stage "stage2" >/dev/null
log "Stage2 concluído"
