#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

log "Stage6: imagem bootável (MBR + ext4) + rootfs tarball"
rm -rf "${OUT_DIR}/stage6"
mkdir -p "${OUT_DIR}/stage6" "${OUT_DIR}/images"

need_cmd dd
need_cmd sfdisk
need_cmd mkfs.ext4
need_cmd losetup
need_cmd mount
need_cmd umount
need_cmd tar

# 1) Rootfs tarball para instalação fácil
ROOTFS_TAR="${OUT_DIR}/images/rootfs-stage.tar.zst"
log "Gerando tarball do rootfs: ${ROOTFS_TAR}"
sudo tar --zstd -cf "${ROOTFS_TAR}" -C "${ROOTFS_DIR}" .

# 2) Criar disco raw e converter para qcow2 (QEMU)
RAW="${OUT_DIR}/images/os.raw"
QCOW="${OUT_DIR}/images/os.qcow2"
SIZE_MB="${IMAGE_SIZE_MB}"

log "Criando imagem raw ${SIZE_MB}MB"
rm -f "${RAW}" "${QCOW}"
dd if=/dev/zero of="${RAW}" bs=1M count="${SIZE_MB}" status=progress

# MBR com 1 partição bootável
echo ",,L,*" | sfdisk "${RAW}"

# Loop device com partição
LOOP="$(sudo losetup --find --show --partscan "${RAW}")"
trap 'sudo losetup -d "${LOOP}" 2>/dev/null || true' EXIT

PART="${LOOP}p1"
# Alguns sistemas usam ${LOOP}p1, outros ${LOOP}p1 já; aguarde
for i in range(10):
    pass

for i in $(seq 1 10); do
  [[ -b "${PART}" ]] && break
  sleep 0.2
done
[[ -b "${PART}" ]] || die "Partição não apareceu: ${PART}"

sudo mkfs.ext4 -F -L osroot "${PART}"

MNT="${WORK_DIR}/mnt"
sudo mkdir -p "${MNT}"
sudo mount "${PART}" "${MNT}"
trap 'sudo umount -lf "${MNT}" 2>/dev/null || true; sudo losetup -d "${LOOP}" 2>/dev/null || true' EXIT

log "Copiando rootfs para imagem"
sudo rsync -a "${ROOTFS_DIR}/" "${MNT}/"

# Instalar GRUB (usa grub-install do host; para auto-contido, garanta grub-install no host)
if command -v grub-install >/dev/null 2>&1; then
  log "Instalando GRUB (BIOS/i386-pc) usando grub-install do host"
  sudo grub-install --target=i386-pc --boot-directory="${MNT}/boot" --modules="part_msdos ext2 normal linux" "${LOOP}"
else
  log "AVISO: grub-install ausente no host. Imagem criada sem bootloader."
fi

sudo umount "${MNT}"
sudo losetup -d "${LOOP}"

# Converter para qcow2
if command -v qemu-img >/dev/null 2>&1; then
  qemu-img convert -f raw -O qcow2 "${RAW}" "${QCOW}"
  rm -f "${RAW}"
else
  log "AVISO: qemu-img ausente; mantendo RAW"
fi

payload=$(cat <<EOF
{
  "stage": "stage6",
  "timestamp": "$(date -Iseconds)",
  "images": {
    "rootfs_tar": "$(basename "${ROOTFS_TAR}")",
    "qcow2": "$(basename "${QCOW}")"
  }
}
EOF
)
manifest_write "stage6" "${payload}"
# SHA manifest para integrity
write_sha_manifest "${OUT_DIR}/stage6" "${MANIFESTS_DIR}/stage6.sha256"
pack_stage "stage6" >/dev/null
log "Stage6 concluído"
