#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

log "Stage0: preparando rootfs e diretórios"
rm -rf "${OUT_DIR}/stage0"
mkdir -p "${OUT_DIR}/stage0"

# Rootfs skeleton
sudo mkdir -p "${ROOTFS_DIR}"/{bin,sbin,etc,proc,sys,dev,run,tmp,var,root,home} \
  "${ROOTFS_DIR}"/usr/{bin,sbin,lib,lib64,share} \
  "${ROOTFS_DIR}"/var/{log,lib,run,cache} \
  "${ROOTFS_DIR}"/etc/{init.d,rc.d}

sudo chmod 1777 "${ROOTFS_DIR}/tmp"

# Minimal passwd/group
if [[ ! -f "${ROOTFS_DIR}/etc/passwd" ]]; then
  cat <<'EOF' | sudo tee "${ROOTFS_DIR}/etc/passwd" >/dev/null
root:x:0:0:root:/root:/bin/bash
EOF
fi

if [[ ! -f "${ROOTFS_DIR}/etc/group" ]]; then
  cat <<'EOF' | sudo tee "${ROOTFS_DIR}/etc/group" >/dev/null
root:x:0:
users:x:100:
EOF
fi

# Placeholder configs
cat <<'EOF' | sudo tee "${ROOTFS_DIR}/etc/profile" >/dev/null
export PATH=/usr/bin:/usr/sbin:/bin:/sbin
EOF

# Stage artifacts
mkdir -p "${OUT_DIR}/stage0"
echo "rootfs=${ROOTFS_DIR}" > "${OUT_DIR}/stage0/paths.env"
echo "sysroot=${SYSROOT_DIR}" >> "${OUT_DIR}/stage0/paths.env"
echo "tools=${TOOLS_DIR}" >> "${OUT_DIR}/stage0/paths.env"

# Manifest
payload=$(cat <<EOF
{
  "stage": "stage0",
  "timestamp": "$(date -Iseconds)",
  "target_triplet": "${TARGET_TRIPLET}",
  "rootfs_hash": "$(sudo bash -c "find '${ROOTFS_DIR}' -type f -print0 | sort -z | xargs -0 sha256sum 2>/dev/null | sha256sum | awk '{print $1}'" || echo "na")"
}
EOF
)
manifest_write "stage0" "${payload}"
# SHA manifest para integrity
write_sha_manifest "${OUT_DIR}/stage0" "${MANIFESTS_DIR}/stage0.sha256"

pack_stage "stage0" >/dev/null
log "Stage0 concluído"
