#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
source "${REPO_ROOT}/lib/build.sh"

log "Stage3: SysVinit + configuração do sistema"
rm -rf "${OUT_DIR}/stage3"
mkdir -p "${OUT_DIR}/stage3"

[[ -d "${ROOTFS_DIR}/tools/bin" ]] || die "Rode stage2 primeiro"

# Build sysvinit
resolve_and_build "stage3" sysvinit

# Instalar scripts de init fornecidos pelo projeto
if [[ -d "${REPO_ROOT}/files" ]]; then
  log "Instalando arquivos do projeto (init scripts, functions)"
  sudo mkdir -p "${ROOTFS_DIR}/etc/init.d" "${ROOTFS_DIR}/etc/rc.d"
  sudo rsync -a "${REPO_ROOT}/files/etc/" "${ROOTFS_DIR}/etc/"
fi

# rc directories e symlinks
for rl in 0 1 2 3 4 5 6 S; do
  sudo mkdir -p "${ROOTFS_DIR}/etc/rc.d/rc${rl}.d"
done
# Start order (S -> udev; RL3 -> dbus, seatd)
sudo ln -sf ../init.d/udev "${ROOTFS_DIR}/etc/rc.d/rcS.d/S10udev"
# Halt scripts
sudo ln -sf ../init.d/halt "${ROOTFS_DIR}/etc/rc.d/rc0.d/S00halt"
sudo ln -sf ../init.d/halt "${ROOTFS_DIR}/etc/rc.d/rc6.d/S00halt"
sudo ln -sf ../init.d/dbus "${ROOTFS_DIR}/etc/rc.d/rc3.d/S20dbus"
sudo ln -sf ../init.d/seatd "${ROOTFS_DIR}/etc/rc.d/rc3.d/S30seatd"
# Stops
sudo ln -sf ../init.d/dbus "${ROOTFS_DIR}/etc/rc.d/rc0.d/K80dbus"
sudo ln -sf ../init.d/seatd "${ROOTFS_DIR}/etc/rc.d/rc0.d/K80seatd"
sudo ln -sf ../init.d/udev "${ROOTFS_DIR}/etc/rc.d/rc0.d/K90udev"


# Configs SysVinit
sudo tee "${ROOTFS_DIR}/etc/inittab" >/dev/null <<'EOF'
id:3:initdefault:
si::sysinit:/etc/rc.d/rc.sysinit
l0:0:wait:/etc/rc.d/rc 0
l1:1:wait:/etc/rc.d/rc 1
l2:2:wait:/etc/rc.d/rc 2
l3:3:wait:/etc/rc.d/rc 3
l4:4:wait:/etc/rc.d/rc 4
l5:5:wait:/etc/rc.d/rc 5
l6:6:wait:/etc/rc.d/rc 6
ca:12345:ctrlaltdel:/sbin/shutdown -t1 -a -r now
su:S:wait:/sbin/sulogin
1:2345:respawn:/sbin/agetty --autologin __AUTOLOGIN_USER__ 38400 __AUTOLOGIN_TTY__
EOF

# Aplicar valores de autologin no inittab (heredoc é literal)
sudo sed -i "s/__AUTOLOGIN_USER__/${AUTOLOGIN_USER}/g; s/__AUTOLOGIN_TTY__/${AUTOLOGIN_TTY}/g" "${ROOTFS_DIR}/etc/inittab"

sudo mkdir -p "${ROOTFS_DIR}/etc/rc.d" "${ROOTFS_DIR}/etc/init.d"
sudo tee "${ROOTFS_DIR}/etc/rc.d/rc.sysinit" >/dev/null <<'EOF'
#!/bin/sh
PATH=/usr/sbin:/usr/bin:/sbin:/bin

echo "== osbuild sysinit =="

# Mount kernel filesystems (best effort)
mount -t proc proc /proc 2>/dev/null || true
mount -t sysfs sysfs /sys 2>/dev/null || true
mount -t devtmpfs devtmpfs /dev 2>/dev/null || true
mount -t tmpfs tmpfs /run 2>/dev/null || true
mkdir -p /dev/pts /dev/shm
mount -t devpts devpts /dev/pts 2>/dev/null || true
mount -t tmpfs tmpfs /dev/shm 2>/dev/null || true

# Load keymaps if available (optional)
[ -x /usr/bin/loadkeys ] && /usr/bin/loadkeys 2>/dev/null || true

# Run rcS scripts
if [ -d /etc/rc.d/rcS.d ]; then
  for s in /etc/rc.d/rcS.d/S*; do
    [ -x "$s" ] && "$s" start
  done
fi

# fstab mounts
mount -a 2>/dev/null || true

echo "== sysinit done =="

EOF
sudo chmod +x "${ROOTFS_DIR}/etc/rc.d/rc.sysinit"

sudo tee "${ROOTFS_DIR}/etc/rc.d/rc" >/dev/null <<'EOF'
#!/bin/sh
# Minimal runlevel dispatcher with stop/start ordering
RUNLEVEL="$1"
[ -z "$RUNLEVEL" ] && exit 1

# Stop scripts (K*) then start scripts (S*)
if [ -d "/etc/rc.d/rc${RUNLEVEL}.d" ]; then
  for k in /etc/rc.d/rc${RUNLEVEL}.d/K*; do
    [ -x "$k" ] && "$k" stop
  done
  for s in /etc/rc.d/rc${RUNLEVEL}.d/S*; do
    [ -x "$s" ] && "$s" start
  done
fi

exit 0

EOF
sudo chmod +x "${ROOTFS_DIR}/etc/rc.d/rc"

# fstab + hostname
sudo tee "${ROOTFS_DIR}/etc/fstab" >/dev/null <<'EOF'
# <fs>   <mountpoint> <type> <opts> <dump> <pass>
proc     /proc        proc   nosuid,noexec,nodev 0 0
sysfs    /sys         sysfs  nosuid,noexec,nodev 0 0
devtmpfs /dev         devtmpfs mode=0755,nosuid 0 0
tmpfs    /run         tmpfs  mode=0755,nosuid,nodev 0 0
tmpfs    /tmp         tmpfs  mode=1777,strictatime,nodev,nosuid 0 0
EOF
sudo tee "${ROOTFS_DIR}/etc/hostname" >/dev/null <<'EOF'
osbuild
EOF


# Modelo de login: criar usuário não-root e autologin controlado
# Requer util-linux (agetty) e shadow (useradd/login). Se faltar, continuará com root.
if [[ "${AUTOLOGIN_ENABLE}" == "1" ]]; then
  # Garantir user/group básicos
  sudo tee -a "${ROOTFS_DIR}/etc/group" >/dev/null <<'EOF'
video:x:27:
input:x:28:
EOF
  # Criar usuário dentro do rootfs (via chroot) se possível
  if [[ -x "${ROOTFS_DIR}/usr/sbin/useradd" ]]; then
    mount_chroot_fs "${ROOTFS_DIR}"
    trap 'umount_chroot_fs "${ROOTFS_DIR}"' EXIT
    in_chroot "${ROOTFS_DIR}" /usr/sbin/useradd -m -s /bin/bash -G video,input,users "${AUTOLOGIN_USER}" || true
  fi
else
  # Remover autologin do inittab para exigir login
  sudo sed -i "s|/sbin/agetty --autologin .*|/sbin/getty 38400 tty1|" "${ROOTFS_DIR}/etc/inittab" || true
fi


payload=$(cat <<EOF
{
  "stage": "stage3",
  "timestamp": "$(date -Iseconds)"
}
EOF
)
manifest_write "stage3" "${payload}"
# SHA manifest para integrity
write_sha_manifest "${OUT_DIR}/stage3" "${MANIFESTS_DIR}/stage3.sha256"
pack_stage "stage3" >/dev/null
log "Stage3 concluído"


log "Verificações pós-stage3"
sudo test -x "${ROOTFS_DIR}/sbin/init" || die "sysvinit init ausente"
sudo test -x "${ROOTFS_DIR}/etc/rc.d/rc.sysinit" || die "rc.sysinit ausente"
sudo test -x "${ROOTFS_DIR}/etc/init.d/udev" || die "init udev ausente"
