#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
source "${REPO_ROOT}/lib/build.sh"

log "Stage5: Wayland stack + seatd + sway"
rm -rf "${OUT_DIR}/stage5"
mkdir -p "${OUT_DIR}/stage5"

host_prereqs_wayland

# Build a minimal set; mais deps podem ser necessários dependendo do host e versões.
XWAYLAND_PKGS=()
if [[ "${ENABLE_XWAYLAND}" == "1" ]]; then
  XWAYLAND_PKGS=(xorgproto xcb_proto libxau libxdmcp libxcb xwayland)
fi

resolve_and_build "stage5" \
  dbus curl \
  eudev dbus curl \

  libffi expat pcre2 libpng freetype fontconfig pixman cairo fribidi harfbuzz pango \
  wayland wayland_protocols xkbcommon libinput libdrm mesa seatd wlroots sway "${XWAYLAND_PKGS[@]}"

# seatd service start script (SysVinit)
sudo mkdir -p "${ROOTFS_DIR}/etc/rc.d/rc3.d" "${ROOTFS_DIR}/etc/init.d"
sudo tee "${ROOTFS_DIR}/etc/init.d/seatd" >/dev/null <<'EOF'
#!/bin/sh
case "$1" in
  start)
    echo "Starting seatd..."
    /usr/bin/seatd -g video -u root &
    ;;
  stop)
    killall seatd 2>/dev/null || true
    ;;
  *)
    echo "Usage: $0 {start|stop}"
    exit 1
    ;;
esac
exit 0
EOF
sudo chmod +x "${ROOTFS_DIR}/etc/init.d/seatd"
sudo ln -sf ../init.d/seatd "${ROOTFS_DIR}/etc/rc.d/rc3.d/S20seatd"

# Simple sway autostart for root on tty1 (pragmático; ideal é criar user e login)
sudo tee "${ROOTFS_DIR}/root/.profile" >/dev/null <<'EOF'
if [ -z "$WAYLAND_DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
  exec sway
fi
EOF

payload=$(cat <<EOF
{
  "stage": "stage5",
  "timestamp": "$(date -Iseconds)"
}
EOF
)
manifest_write "stage5" "${payload}"
# SHA manifest para integrity
write_sha_manifest "${OUT_DIR}/stage5" "${MANIFESTS_DIR}/stage5.sha256"
pack_stage "stage5" >/dev/null
log "Stage5 concluído"


log "Verificações pós-stage5"
sudo test -x "${ROOTFS_DIR}/usr/bin/sway" || die "sway não instalado"
sudo test -x "${ROOTFS_DIR}/usr/bin/seatd" || die "seatd não instalado"
sudo test -x "${ROOTFS_DIR}/etc/init.d/seatd" || die "init script seatd ausente"
