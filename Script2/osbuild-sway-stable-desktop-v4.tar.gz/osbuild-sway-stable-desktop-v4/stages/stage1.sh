#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

log "Stage1: toolchain temporário (binutils/gcc/glibc/headers)"
rm -rf "${OUT_DIR}/stage1"
mkdir -p "${OUT_DIR}/stage1" "${SYSROOT_DIR}" "${TOOLS_DIR}" "${WORK_DIR}/stage1"

need_cmd make
need_cmd gcc
need_cmd g++
need_cmd bison || true
need_cmd flex || true

# Fetch required sources (must be hashed in lockfile)
for p in binutils gcc linux_headers glibc; do
  fetch_one "$p"
done

# Helpers
srcdir() { echo "${WORK_DIR}/stage1/src/$1"; }
blddir() { echo "${WORK_DIR}/stage1/build/$1"; }
get_tar() {
  local name="$1"
  local line; line="$(lock_get "${name}")"
  local _n _v url sha; read -r _n _v url sha <<<"${line}"
  echo "${CACHE_DIR}/sources/$(basename "${url}")"
}

mkdir -p "${WORK_DIR}/stage1/src" "${WORK_DIR}/stage1/build"

# 1) binutils pass1
log "binutils pass1"
rm -rf "$(srcdir binutils)" "$(blddir binutils)"
extract_tarball "$(get_tar binutils)" "${WORK_DIR}/stage1/src"
# auto-detect extracted directory
BINUTILS_DIR="$(find "${WORK_DIR}/stage1/src" -maxdepth 1 -type d -name 'binutils-*' | head -n1)"
mkdir -p "$(blddir binutils)"
pushd "$(blddir binutils)" >/dev/null
"${BINUTILS_DIR}/configure" --prefix="${TOOLS_DIR}" --with-sysroot="${SYSROOT_DIR}" --target="${TARGET_TRIPLET}" --disable-nls --disable-werror
make -j"${JOBS}"
make install
popd >/dev/null

# 2) linux headers -> sysroot
log "linux headers"
rm -rf "$(srcdir linux_headers)"
extract_tarball "$(get_tar linux_headers)" "${WORK_DIR}/stage1/src"
LINUX_DIR="$(find "${WORK_DIR}/stage1/src" -maxdepth 1 -type d -name 'linux-*' | head -n1)"
pushd "${LINUX_DIR}" >/dev/null
make mrproper
make headers_install INSTALL_HDR_PATH="${SYSROOT_DIR}/usr"
popd >/dev/null

# 3) gcc pass1 (minimal)
log "gcc pass1"
rm -rf "$(blddir gcc1)"
GCC_TAR="$(get_tar gcc)"
extract_tarball "${GCC_TAR}" "${WORK_DIR}/stage1/src"
GCC_DIR="$(find "${WORK_DIR}/stage1/src" -maxdepth 1 -type d -name 'gcc-*' | head -n1)"

# Download GCC prerequisites if desired (gmp/mpfr/mpc/isl) - user can vendor them or use distro packages.
# Here we assume host provides them (simpler). If not, você pode adicionar receitas para embutir.
mkdir -p "$(blddir gcc1)"
pushd "$(blddir gcc1)" >/dev/null
"${GCC_DIR}/configure" \
  --target="${TARGET_TRIPLET}" \
  --prefix="${TOOLS_DIR}" \
  --with-sysroot="${SYSROOT_DIR}" \
  --disable-nls \
  --enable-languages=c,c++ \
  --without-headers \
  --disable-shared \
  --disable-multilib \
  --disable-threads \
  --disable-libatomic --disable-libgomp --disable-libquadmath --disable-libssp --disable-libvtv --disable-libstdcxx
make -j"${JOBS}" all-gcc
make install-gcc
popd >/dev/null

# 4) glibc bootstrap into sysroot
log "glibc bootstrap"
rm -rf "$(blddir glibc)"
extract_tarball "$(get_tar glibc)" "${WORK_DIR}/stage1/src"
GLIBC_DIR="$(find "${WORK_DIR}/stage1/src" -maxdepth 1 -type d -name 'glibc-*' | head -n1)"
mkdir -p "$(blddir glibc)"
pushd "$(blddir glibc)" >/dev/null
# Configure glibc for sysroot
# Note: glibc build é sensível; em algumas distros exige flags extras (kernel headers, python, etc).
CC="${TOOLS_DIR}/bin/${TARGET_TRIPLET}-gcc" \
"${GLIBC_DIR}/configure" \
  --prefix=/usr \
  --host="${TARGET_TRIPLET}" \
  --build="$(gcc -dumpmachine)" \
  --with-headers="${SYSROOT_DIR}/usr/include" \
  --disable-multilib \
  libc_cv_forced_unwind=yes \
  libc_cv_c_cleanup=yes
make -j"${JOBS}"
DESTDIR="${SYSROOT_DIR}" make install
popd >/dev/null

# 5) gcc pass2 (with glibc)
log "gcc pass2"
rm -rf "$(blddir gcc2)"
mkdir -p "$(blddir gcc2)"
pushd "$(blddir gcc2)" >/dev/null
"${GCC_DIR}/configure" \
  --target="${TARGET_TRIPLET}" \
  --prefix="${TOOLS_DIR}" \
  --with-sysroot="${SYSROOT_DIR}" \
  --disable-nls \
  --enable-languages=c,c++ \
  --disable-multilib \
  --enable-shared \
  --enable-threads=posix
make -j"${JOBS}"
make install
popd >/dev/null

# Basic sanity test
log "Sanity check toolchain"
cat >"${WORK_DIR}/stage1/hello.c" <<'EOF'
#include <stdio.h>
int main(){ puts("hello"); return 0; }
EOF
"${TOOLS_DIR}/bin/${TARGET_TRIPLET}-gcc" --sysroot="${SYSROOT_DIR}" "${WORK_DIR}/stage1/hello.c" -o "${WORK_DIR}/stage1/hello"
file "${WORK_DIR}/stage1/hello" | tee "${OUT_DIR}/stage1/sanity.txt"
# Verify loader in sysroot
if [[ ! -e "${SYSROOT_DIR}/lib64/ld-linux-x86-64.so.2" ]]; then
  found="$(find "${SYSROOT_DIR}" -name ld-linux-x86-64.so.2 -type f | head -n1 || true)"
  [[ -n "${found}" ]] || die "Loader glibc não encontrado no sysroot"
fi

mkdir -p "${OUT_DIR}/stage1"
cp -a "${TOOLS_DIR}" "${OUT_DIR}/stage1/tools"
cp -a "${SYSROOT_DIR}" "${OUT_DIR}/stage1/sysroot"

payload=$(cat <<EOF
{
  "stage": "stage1",
  "timestamp": "$(date -Iseconds)",
  "target_triplet": "${TARGET_TRIPLET}",
  "tools_hash": "$(hash_dir "${TOOLS_DIR}" 2>/dev/null || echo "na")",
  "sysroot_hash": "$(hash_dir "${SYSROOT_DIR}" 2>/dev/null || echo "na")"
}
EOF
)
manifest_write "stage1" "${payload}"
# SHA manifest para integrity
write_sha_manifest "${OUT_DIR}/stage1" "${MANIFESTS_DIR}/stage1.sha256"

pack_stage "stage1" >/dev/null
log "Stage1 concluído"
