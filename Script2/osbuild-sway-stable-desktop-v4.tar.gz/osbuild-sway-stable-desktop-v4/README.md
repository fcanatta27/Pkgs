# osbuild-sway: Pipeline de stages para construir um Linux desktop x86_64 (glibc + SysVinit + GRUB + Wayland/Sway + seatd)

Este projeto é um **esqueleto completo e automatizado** (stages) para construir um sistema operacional Linux desktop
para x86_64 com:

- glibc
- busybox (principalmente para initramfs/recuperação)
- sysvinit (boot userspace)
- grub (bootloader)
- Wayland stack + compositor **sway** (via wlroots)
- seatd (gerência de sessão/assentos sem systemd-logind)

## O que este projeto faz
- Implementa stages 0..6 com build real de base + SysVinit + kernel/initramfs + (Wayland/seatd/sway) e empacotamento.
- Gera **rootfs tarball** para instalação fácil e imagem **qcow2** para QEMU.

Limitações práticas:
- A stack gráfica (Mesa/wlroots/sway) pode requerer ajustes de dependências conforme versão e host.
- Não há como garantir ausência de falhas em todos os ambientes; os scripts registram logs e permitem retomar.

## Requisitos no host
Um Linux moderno com:
- bash, coreutils, tar, xz/zstd, patch, git (opcional), curl ou wget
- build deps típicas: gcc/g++, make, bison, flex, gawk, texinfo, perl, python3
- meson, ninja (para stack Wayland), pkg-config
- qemu-system-x86_64 (para testes)
- privilégios de root (apenas para bind-mounts e criação de imagem/loopback quando necessário)

Recomendado:
- ccache
- container (podman ou docker) para isolar o builder

## Uso rápido
1) Configure alvo:
```bash
cp config/targets/x86_64.conf.example config/targets/x86_64.conf
```

2) Fetch de fontes (offline build depois):
```bash
./osbuild.sh fetch
```

3) Rodar stages:
```bash
./osbuild.sh stage0
./osbuild.sh stage1
./osbuild.sh stage2
./osbuild.sh stage3
./osbuild.sh stage4
./osbuild.sh stage5
./osbuild.sh stage6
```

Ou tudo:
```bash
./osbuild.sh all
```

4) Boot em QEMU:
```bash
./osbuild.sh qemu
```

## Stages (visão geral)
- stage0: prepara rootfs, diretórios, mounts e ambiente para build.
- stage1: constrói toolchain temporário (binutils/gcc/glibc/headers) em sysroot.
- stage2: entra em chroot e constrói base userspace (bash/coreutils/etc).
- stage3: integra SysVinit + scripts + serviços básicos.
- stage4: kernel + initramfs + GRUB.
- stage5: stack gráfica Wayland + seatd + sway (+ deps).
- stage6: empacota imagem final (qcow2/iso) e artifacts.

## Empacotamento por stage
Cada stage gera:
- out/stageX/* (artifacts)
- manifests/stageX.json (inputs/flags/versions/hashes)
- dist/stageX-<timestamp>.tar.zst (artifact empacotado do stage)

## Estrutura de diretórios
- stages/: scripts de stage
- recipes/: receitas por pacote
- config/: configs e lockfile
- cache/sources/: tarballs
- work/: diretórios de build temporários
- out/: sysroot/rootfs/images
- dist/: pacotes dos stages
- manifests/: manifests dos stages

## Licença
MIT (veja LICENSE).

## Gerenciador de pacotes (opm)
Dentro do sistema gerado, existe um gerenciador simples POSIX sh:
- /usr/sbin/opm
Ele instala pacotes .tar.zst com metadados em .OPM.

Exemplos:
- opm list
- opm query <nome>
- opm install /path/pacote.tar.zst
- opm remove <nome>
- opm mkpkg <nome> <versao> <rootdir> <outpkg.tar.zst>
