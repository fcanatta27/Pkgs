#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
source "${REPO_ROOT}/lib/common.sh"
source "${REPO_ROOT}/lib/build.sh"

usage() {
  cat <<'EOF'
Uso: ./osbuild.sh <comando>

Comandos:
  doctor                 Checa prereqs e avisos comuns
  fetch                  Baixa e valida sources do lockfile
  lock-add <n> <v> <url> Ajuda a adicionar entrada (imprime sha256)
  stage0..stage6         Executa stage
  all                    Executa stage0..stage6
  dist                   Empacota todos stages existentes em dist/
  clean                  Remove work/ (não remove cache/sources)
  shell                  Abre shell dentro do chroot do rootfs (após stage2+)
  qemu                   Boot do artifact final (após stage6)

EOF
}

cmd="${1:-}"
shift || true

case "${cmd}" in
  ""|-h|--help) usage; exit 0 ;;

  verify)
    host_prereqs_base
    verify_lockfile_sha
    log "Verificando integrity de artifacts existentes (se presentes)"
    for s in stage0 stage1 stage2 stage3 stage4 stage5 stage6; do
      if [[ -f "${MANIFESTS_DIR}/${s}.sha256" && -d "${OUT_DIR}/${s}" ]]; then
        verify_sha_manifest "${OUT_DIR}/${s}" "${MANIFESTS_DIR}/${s}.sha256" && log "OK: ${s}" || die "Falha integrity: ${s}"
      fi
    done
    ;;

  check-toolchain)
    host_prereqs_base
    [[ -x "${TOOLS_DIR}/bin/${TARGET_TRIPLET}-gcc" ]] || die "Toolchain ausente. Rode stage1."
    log "Teste compilação/link (sysroot)"
    tmp="${WORK_DIR}/_tc"
    rm -rf "$tmp"; mkdir -p "$tmp"
    cat >"$tmp/t.c" <<'EOF'
#include <stdio.h>
int main(){ puts("toolchain-ok"); return 0; }
EOF
    "${TOOLS_DIR}/bin/${TARGET_TRIPLET}-gcc" --sysroot="${SYSROOT_DIR}" "$tmp/t.c" -o "$tmp/t"
    file "$tmp/t" | tee "$tmp/file.txt"
    readelf -l "$tmp/t" | grep -E 'interpreter|Requesting program interpreter' -n || true
    ;;

  doctor)
    host_prereqs_base
    log "Checando prereqs extras..."
    for c in bison flex gawk texinfo perl python3 pkg-config meson ninja; do
      if command -v "$c" >/dev/null 2>&1; then
        log "OK: $c"
      else
        log "AVISO: ausente: $c"
      fi
    done
    ;;

  fetch)
    host_prereqs_base
    while read -r name ver url sha; do
      [[ -z "${name}" ]] && continue
      [[ "${name:0:1}" == "#" ]] && continue
      fetch_one "${name}"
    done < <(awk 'NF>=4 && $1 !~ /^#/' "${LOCKFILE}")
    ;;
  lock-add)
    need_cmd curl || true
    need_cmd wget || true
    name="${1:?name}"; ver="${2:?version}"; url="${3:?url}"
    fn="${CACHE_DIR}/sources/$(basename "${url}")"
    if [[ ! -f "${fn}" ]]; then
      if command -v curl >/dev/null 2>&1; then
        curl -L --fail -o "${fn}" "${url}"
      else
        wget -O "${fn}" "${url}"
      fi
    fi
    sha="$(sha256sum "${fn}" | awk '{print $1}')"
    printf "%s %s %s %s\n" "${name}" "${ver}" "${url}" "${sha}"
    ;;
  stage0|stage1|stage2|stage3|stage4|stage5|stage6)
    host_prereqs_base
    "${REPO_ROOT}/stages/${cmd}.sh"
    ;;
  all)
    host_prereqs_base
    for s in stage0 stage1 stage2 stage3 stage4 stage5 stage6; do
      "${REPO_ROOT}/stages/${s}.sh"
    done
    ;;
  dist)
    for s in stage0 stage1 stage2 stage3 stage4 stage5 stage6; do
      if [[ -d "${OUT_DIR}/${s}" ]]; then
        pack_stage "${s}" >/dev/null
      fi
    done
    ;;
  clean)
    rm -rf "${WORK_DIR}"
    mkdir -p "${WORK_DIR}"
    ;;
  shell)
    [[ -d "${ROOTFS_DIR}" ]] || die "rootfs inexistente. Rode pelo menos stage0/2."
    mount_chroot_fs "${ROOTFS_DIR}"
    trap 'umount_chroot_fs "${ROOTFS_DIR}"' EXIT
    in_chroot "${ROOTFS_DIR}" /bin/bash || true
    ;;
  qemu)
    img="${OUT_DIR}/images/os.qcow2"
    [[ -f "${img}" ]] || die "Imagem não encontrada: ${img} (rode stage6)"
    need_cmd qemu-system-x86_64
    qemu-system-x86_64 -m 2048 -smp 2 \
      -drive file="${img}",format=qcow2,if=virtio \
      -net nic -net user \
      -serial mon:stdio
    ;;
  *)
    die "Comando desconhecido: ${cmd}"
    ;;
esac
