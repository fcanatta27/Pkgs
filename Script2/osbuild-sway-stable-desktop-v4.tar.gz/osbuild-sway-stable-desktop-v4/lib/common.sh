#!/usr/bin/env bash
set -euo pipefail

# shellcheck disable=SC2034

# Logging
log() { printf "[%s] %s\n" "$(date -Iseconds)" "$*" >&2; }
die() { log "ERRO: $*"; exit 1; }

# Repo root
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export REPO_ROOT

# Load target config
TARGET_CONF="${REPO_ROOT}/config/targets/x86_64.conf"
[[ -f "${TARGET_CONF}" ]] || die "Config alvo não encontrada: ${TARGET_CONF}. Copie de config/targets/x86_64.conf.example"
# shellcheck source=/dev/null
source "${TARGET_CONF}"

# Defaults (podem ser sobrescritos no target conf)
: "${ENABLE_XWAYLAND:=0}"
: "${AUTOLOGIN_USER:=user}"
: "${AUTOLOGIN_TTY:=tty1}"
: "${AUTOLOGIN_ENABLE:=1}"


mkdir -p "${OUT_DIR}" "${WORK_DIR}" "${CACHE_DIR}/sources" "${DIST_DIR}" "${MANIFESTS_DIR}"

# Ensure required commands exist
need_cmd() { command -v "$1" >/dev/null 2>&1 || die "Comando ausente: $1"; }

host_prereqs_base() {
  for c in bash awk sed grep tar xz sha256sum patch make gcc g++ ld autoconf automake libtool bison flex gperf; do
    need_cmd "$c"
  done
}

host_prereqs_wayland() {
  for c in meson ninja pkg-config python3; do
    need_cmd "$c"
  done
}

# Lockfile parsing
LOCKFILE="${REPO_ROOT}/config/packages.lock"

lock_get() {
  local name="$1"
  awk -v n="${name}" 'NF>=4 && $1==n {print $0}' "${LOCKFILE}" | head -n1
}

lock_fields() {
  local line="$1"
  # name version url sha256
  echo "${line}"
}

fetch_one() {
  local name="$1"
  local line; line="$(lock_get "${name}")" || true
  [[ -n "${line}" ]] || die "Pacote não encontrado no lockfile: ${name}"
  local _n _v url sha; read -r _n _v url sha <<<"${line}"
  [[ "${sha}" != "SHA256_TODO" ]] || die "SHA256_TODO para ${name}. Preencha em config/packages.lock"
  local fn="${CACHE_DIR}/sources/$(basename "${url}")"
  if [[ -f "${fn}" ]]; then
    log "Fonte já existe: ${fn}"
  else
    log "Baixando ${name} (${_v})"
    if command -v curl >/dev/null 2>&1; then
      curl -L --fail -o "${fn}.part" "${url}"
    elif command -v wget >/dev/null 2>&1; then
      wget -O "${fn}.part" "${url}"
    else
      die "Precisa de curl ou wget para baixar fontes"
    fi
    mv "${fn}.part" "${fn}"
  fi
  local got; got="$(sha256sum "${fn}" | awk '{print $1}')"
  [[ "${got}" == "${sha}" ]] || die "SHA256 inválido para ${fn}. Esperado ${sha}, obtido ${got}"
}

extract_tarball() {
  local tarpath="$1"
  local outdir="$2"
  mkdir -p "${outdir}"
  case "${tarpath}" in
    *.tar.xz) tar -xJf "${tarpath}" -C "${outdir}" ;;
    *.tar.gz|*.tgz) tar -xzf "${tarpath}" -C "${outdir}" ;;
    *.tar.bz2) tar -xjf "${tarpath}" -C "${outdir}" ;;
    *.tar.zst) tar --zstd -xf "${tarpath}" -C "${outdir}" ;;
    *) die "Formato de tarball não suportado: ${tarpath}" ;;
  esac
}

# Manifests
manifest_write() {
  local stage="$1"
  local outfile="${MANIFESTS_DIR}/${stage}.json"
  shift
  local payload="$1"
  printf "%s\n" "${payload}" > "${outfile}"
}

hash_dir() {
  local dir="$1"
  (cd "${dir}" && find . -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum | awk '{print $1}')
}

# Chroot helpers
mount_chroot_fs() {
  local root="$1"
  sudo mkdir -p "${root}/dev" "${root}/proc" "${root}/sys" "${root}/run"
  mountpoint -q "${root}/dev" || sudo mount --bind /dev "${root}/dev"
  mountpoint -q "${root}/proc" || sudo mount -t proc proc "${root}/proc"
  mountpoint -q "${root}/sys" || sudo mount -t sysfs sysfs "${root}/sys"
  mountpoint -q "${root}/run" || sudo mount -t tmpfs tmpfs "${root}/run" || true
}

umount_chroot_fs() {
  local root="$1"
  sudo umount -lf "${root}/run" 2>/dev/null || true
  sudo umount -lf "${root}/sys" 2>/dev/null || true
  sudo umount -lf "${root}/proc" 2>/dev/null || true
  sudo umount -lf "${root}/dev" 2>/dev/null || true
}

in_chroot() {
  local root="$1"; shift
  sudo chroot "${root}" /usr/bin/env -i \
    HOME=/root TERM="${TERM:-xterm}" PS1='(chroot) \u:\w\$ ' \
    PATH=/usr/bin:/usr/sbin:/bin:/sbin \
    "$@"
}

pack_stage() {
  local stage="$1"
  local srcdir="${OUT_DIR}/${stage}"
  [[ -d "${srcdir}" ]] || die "Sem artifacts para empacotar: ${srcdir}"
  local ts; ts="$(date +%Y%m%d-%H%M%S)"
  local out="${DIST_DIR}/${stage}-${ts}.tar.zst"
  tar --zstd -cf "${out}" -C "${OUT_DIR}" "${stage}"
  log "Empacotado: ${out}"
  echo "${out}"
}


verify_lockfile_sha() {
  # Ensure no SHA256_TODO for required packages
  local missing
  missing="$(awk 'NF>=4 && $4=="SHA256_TODO" && $1 !~ /^#/' "${LOCKFILE}" | head -n 20)"
  if [[ -n "${missing}" ]]; then
    die "Lockfile contém SHA256_TODO (exibindo até 20 linhas). Preencha antes do fetch/build:\n${missing}"
  fi
}

write_sha_manifest() {
  # write sha256 list for a directory into a manifest file
  local dir="$1" out="$2"
  (cd "${dir}" && find . -type f -print0 | sort -z | xargs -0 sha256sum) > "${out}"
}

verify_sha_manifest() {
  local dir="$1" manifest="$2"
  (cd "${dir}" && sha256sum -c "${manifest}") >/dev/null
}

