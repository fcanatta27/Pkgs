#!/usr/bin/env bash
set -euo pipefail

# Build framework for recipes
# This file is sourced by stages; relies on lib/common.sh being sourced first.

: "${REPO_ROOT:?}"
: "${WORK_DIR:?}"
: "${CACHE_DIR:?}"
: "${OUT_DIR:?}"
: "${ROOTFS_DIR:?}"
: "${SYSROOT_DIR:?}"
: "${TOOLS_DIR:?}"
: "${TARGET_TRIPLET:?}"
: "${JOBS:?}"

BUILD_STATE_DIR="${OUT_DIR}/state"
LOG_DIR="${OUT_DIR}/logs"
PKGDB_DIR="${OUT_DIR}/pkgdb"
mkdir -p "${PKGDB_DIR}"
mkdir -p "${BUILD_STATE_DIR}" "${LOG_DIR}"

# ---- Hashing / stamps ----
_file_sha256() { sha256sum "$1" | awk '{print $1}'; }

recipe_input_hash() {
  # Hash recipe script + optional config/patch dir + lockfile line for pkg
  local recipe="$1" pkg="$2"
  local h=""
  h+="$(_file_sha256 "${recipe}")"
  if [[ -d "$(dirname "${recipe}")/patches" ]]; then
    h+="$(hash_dir "$(dirname "${recipe}")/patches")"
  fi
  if [[ -d "$(dirname "${recipe}")/files" ]]; then
    h+="$(hash_dir "$(dirname "${recipe}")/files")"
  fi
  h+="$(echo "$(lock_get "${pkg}")" | sha256sum | awk '{print $1}')"
  echo "${h}" | sha256sum | awk '{print $1}'
}

stamp_path() { echo "${BUILD_STATE_DIR}/$1.$2.done"; } # pkg, stage
should_skip() {
  local pkg="$1" stage="$2" inp_hash="$3"
  local st; st="$(stamp_path "${pkg}" "${stage}")"
  [[ -f "${st}" ]] || return 1
  local prev; prev="$(cat "${st}")"
  [[ "${prev}" == "${inp_hash}" ]]
}

mark_done() {
  local pkg="$1" stage="$2" inp_hash="$3"
  echo "${inp_hash}" > "$(stamp_path "${pkg}" "${stage}")"
}

# ---- Source handling ----
pkg_tarball_path() {
  local name="$1"
  local line; line="$(lock_get "${name}")"
  local _n _v url sha; read -r _n _v url sha <<<"${line}"
  echo "${CACHE_DIR}/sources/$(basename "${url}")"
}

pkg_version() {
  local name="$1"
  local line; line="$(lock_get "${name}")"
  local _n _v url sha; read -r _n _v url sha <<<"${line}"
  echo "${_v}"
}

pkg_work_srcdir() {
  local name="$1"
  echo "${WORK_DIR}/src/${name}"
}

pkg_work_builddir() {
  local name="$1"
  echo "${WORK_DIR}/build/${name}"
}

prepare_source() {
  local name="$1"
  mkdir -p "${WORK_DIR}/src" "${WORK_DIR}/build"
  rm -rf "$(pkg_work_srcdir "${name}")"
  mkdir -p "$(pkg_work_srcdir "${name}")"
  extract_tarball "$(pkg_tarball_path "${name}")" "$(pkg_work_srcdir "${name}")"
}

autodetect_topdir() {
  local root="$1"
  find "${root}" -maxdepth 1 -mindepth 1 -type d | head -n1
}

# ---- Build backends ----
run_configure_make() {
  local src="$1" bld="$2"; shift 2
  rm -rf "${bld}"
  mkdir -p "${bld}"
  pushd "${bld}" >/dev/null
  "${src}/configure" "$@"
  make -j"${JOBS}"
  make install
  popd >/dev/null
}

run_meson_ninja() {
  local src="$1" bld="$2"; shift 2
  rm -rf "${bld}"
  mkdir -p "${bld}"
  pushd "${bld}" >/dev/null
  meson setup --prefix="${1}" "${src}" "${bld}" "${@:2}"
  ninja -j"${JOBS}"
  ninja install
  popd >/dev/null
}

# ---- Env helpers ----
export_cross_env() {
  # Use cross toolchain from TOOLS_DIR with SYSROOT_DIR as sysroot
  export PATH="${TOOLS_DIR}/bin:${PATH}"
  export CC="${TARGET_TRIPLET}-gcc --sysroot=${SYSROOT_DIR}"
  export CXX="${TARGET_TRIPLET}-g++ --sysroot=${SYSROOT_DIR}"
  export AR="${TARGET_TRIPLET}-ar"
  export AS="${TARGET_TRIPLET}-as"
  export LD="${TARGET_TRIPLET}-ld"
  export RANLIB="${TARGET_TRIPLET}-ranlib"
  export STRIP="${TARGET_TRIPLET}-strip"
  export PKG_CONFIG_SYSROOT_DIR="${SYSROOT_DIR}"
  export PKG_CONFIG_PATH="/usr/lib/pkgconfig:/usr/share/pkgconfig:/usr/lib64/pkgconfig"
  export CFLAGS="${CFLAGS}"
  export CXXFLAGS="${CXXFLAGS}"
  export LDFLAGS="${LDFLAGS}"
}

export_destdir_env() {
  # Install into ROOTFS_DIR via DESTDIR, but prefix remains /usr
  export DESTDIR="${ROOTFS_DIR}"
}

# ---- Recipe runner ----
run_recipe() {
  local stage="$1" pkg="$2"
  local recipe="${REPO_ROOT}/recipes/${pkg}/build.sh"
  [[ -f "${recipe}" ]] || die "Receita ausente: ${recipe}"

  local ih; ih="$(recipe_input_hash "${recipe}" "${pkg}")"
  if should_skip "${pkg}" "${stage}" "${ih}"; then
    log "SKIP ${pkg} (stage=${stage})"
    return 0
  fi

  log "BUILD ${pkg} (stage=${stage})"
  local logf="${LOG_DIR}/${stage}-${pkg}.log"
  (
    set -euo pipefail
    source "${recipe}"
    recipe_main "${stage}"
  ) > >(tee "${logf}") 2>&1

  # best-effort capture of installed files for pkgdb
  if [[ "${DESTDIR:-}" == "${ROOTFS_DIR}" ]]; then
    capture_pkg_files "${pkg}" || true
  fi
  mark_done "${pkg}" "${stage}" "${ih}"
  log "OK ${pkg}"
}

# Simple topological runner based on RECIPE_DEPS associative array (declared in recipes)
# Each recipe should set: RECIPE_DEPS=(dep1 dep2 ...)
resolve_and_build() {
  local stage="$1"; shift
  local pkgs=("$@")
  local built=()
  local visiting=()

  _in_list() { local x="$1"; shift; for i in "$@"; do [[ "$i" == "$x" ]] && return 0; done; return 1; }

  _dfs() {
    local p="$1"
    if _in_list "$p" "${built[@]}"; then return 0; fi
    if _in_list "$p" "${visiting[@]}"; then die "Ciclo de dependência detectado em ${p}"; fi
    visiting+=("$p")
    # load deps
    local recipe="${REPO_ROOT}/recipes/${p}/build.sh"
    [[ -f "${recipe}" ]] || die "Receita ausente: ${recipe}"
    # shellcheck disable=SC1090
    source "${recipe}"
    local deps=("${RECIPE_DEPS[@]:-}")
    for d in "${deps[@]}"; do
      _dfs "$d"
    done
    run_recipe "${stage}" "${p}"
    built+=("$p")
    # pop visiting
    visiting=("${visiting[@]:0:${#visiting[@]}-1}")
  }

  for p in "${pkgs[@]}"; do
    _dfs "$p"
  done
}


capture_pkg_files() {
  # Capture file list installed by pkg into ROOTFS_DIR for package manager usage.
  local pkg="$1"
  local list="${PKGDB_DIR}/${pkg}.files"
  # This assumes build installs directly into ROOTFS_DIR (DESTDIR).
  # We record all files under /usr, /bin, /sbin, /lib, /lib64 that are present after install and tag with pkg.
  # For strictness, recipes can optionally create ${WORK_DIR}/.pkgfiles during install; not implemented here.
  (cd "${ROOTFS_DIR}" && find usr bin sbin lib lib64 etc -type f -o -type l 2>/dev/null | sort) > "${list}" || true
}

