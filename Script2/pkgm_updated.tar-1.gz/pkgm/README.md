# pkgm — Gerenciador simples de pacotes (POSIX sh)

`pkgm` é um gerenciador de pacotes **source-based** que constrói em diretório temporário e gera um **pacote binário** em cache, com **registro/instalação/desinstalação** e **resolução de dependências com detecção de ciclos**.

O foco é ser **simples, limpo e funcional**, sem dependência de linguagens externas além de utilitários comuns do Linux.

## Visão geral

- **Build**: resolve dependências → baixa fontes (com cache) → verifica `md5` → extrai → aplica patches → executa hooks → compila e instala em `DESTDIR=$PKG` → empacota em `tar.gz` no cache → registra artefato.
- **Install**: descompacta o pacote do cache em `--root` (por padrão `/`) e registra lista de arquivos instalados.
- **Uninstall**: remove arquivos registrados (em ordem reversa) e tenta limpar diretórios vazios.

> Observação importante: scripts de pacote **devem** evitar escrever diretamente em `/usr`, `/etc`, etc. A etapa `build` deve produzir tudo dentro de `$PKG` (DESTDIR). Se um script contiver comandos que alteram o host, o `pkgm` emite um aviso.

## Requisitos

- Shell POSIX (`/bin/sh`)
- `tar`, `md5sum`, `patch`, `find`, `sed`, `awk`
- **Downloader**: `curl` ou `wget`
- Opcional: `unzip` (se algum source for `.zip`)
- Opcional: `tac` (para desinstalação em ordem reversa; se não existir, a remoção ainda ocorre, mas pode deixar diretórios vazios)

## Instalação

1. Copie `pkgm` para um diretório no seu `PATH`, por exemplo:

```sh
sudo install -m 0755 bin/pkgm /usr/local/bin/pkgm
```

2. Garanta permissões para escrever no cache/DB/logs (por padrão em `/var/*`), ou aponte para diretórios no seu home:

```sh
export CACHE_DIR="$HOME/.cache/pkgm"
export DB_DIR="$HOME/.local/share/pkgm"
export LOG_DIR="$HOME/.local/state/pkgm"
```


## Variáveis exportadas para scripts de pacote

Durante `build`, o `pkgm` executa o script `build` com as seguintes variáveis:

- `PKG`    DESTDIR para instalação (obrigatório; criado pelo `pkgm`)
- `WORKDIR` diretório de trabalho (cache/work)
- `SRCDIR`  diretório do código-fonte extraído
- `JOBS`    número de jobs sugerido

Variáveis opcionais:

- `STAGE`  controla “estágios” de compilação quando o pacote suporta (ex.: `core/gcc` e
  `core/binutils`). Valores típicos: `1`, `2`, `3`.

Exemplos:

```sh
STAGE=1 pkgm build core/binutils
STAGE=2 pkgm build core/gcc
```

## Layout de pacotes

Cada pacote é um diretório com:

```
<PKGS_DIR>/<categoria>/<nome>/
  build
  patches/*.patch          (opcional)
  hook/pre-build           (opcional)
  hook/post-build          (opcional)
  hook/pre-configure       (opcional)
  hook/post-configure      (opcional)
  hook/pre-install         (opcional)
  hook/post-install        (opcional)
  hook/pre-uninstall       (opcional)
  hook/post-uninstall      (opcional)
```

O arquivo `build` é um script `sh` que inclui variáveis simples no topo:

```sh
source=https://example.com/foo-1.2.3.tar.xz
checksums=0123456789abcdef0123456789abcdef   # md5
depends="bar baz"                            # dependências (nomes de pacotes)
main_bin=/usr/bin/foo                        # opcional (verificação)
```

E depois executa o processo de build/install em `DESTDIR=$PKG`:

```sh
./configure --prefix=/usr
make -j"$JOBS"
make DESTDIR="$PKG" install
```

### Patches

Se existirem arquivos em `patches/*.patch`, o `pkgm` aplica automaticamente com:

```sh
patch -p1 < patchfile.patch
```

### Hooks

Hooks são scripts executáveis no diretório `hook/`. O `pkgm` exporta:

- `PKG` — DESTDIR para instalação
- `WORKDIR` — diretório de trabalho (em cache)
- `SRCDIR` — diretório do source extraído
- `JOBS` — sugestão de paralelismo

## Comandos

Atalhos (comandos curtos):

- `pkgm b` = `build`
- `pkgm i` = `install`
- `pkgm u` = `uninstall`
- `pkgm f` = `fetch`
- `pkgm c` = `clean`
- `pkgm s` = `search`
- `pkgm r` = `rebuild`
- `pkgm up` = `upgrade`
- `pkgm l` = `list`
- `pkgm in` = `info`
- `pkgm g` = `graph`

### `pkgm list` (ou `pkgm l`)

Lista pacotes disponíveis (categoria/nome) dentro de `PKGS_DIR`.

### `pkgm search <termo>` (ou `pkgm s <termo>`)

Procura pacotes por nome. Se estiver instalado, aparece com marca:

- `[ ✔️ ] core/gcc`
- `[   ] core/binutils`

### `pkgm info <pkg>` (ou `pkgm in <pkg>`)

Mostra metadados: source, md5, deps, versão e status (construído/instalado).

### `pkgm graph <pkg>` (ou `pkgm g <pkg>`)

Mostra a árvore de dependências com detecção de ciclo.

### `pkgm fetch <pkg...>` (ou `pkgm f <pkg...>`)

Baixa as fontes para o cache e valida `md5` (sem extrair/compilar).

### `pkgm build <pkg...>` (ou `pkgm b <pkg...>`)

Resolve dependências, baixa, extrai, aplica patches, executa hooks e compila em `DESTDIR=$PKG`.
Ao final, cria um pacote binário `tar.gz` no cache e registra o artefato **sem instalar no /**.

Exemplo:

```sh
pkgm build core/binutils
```

### `pkgm install <pkg...>` (ou `pkgm i <pkg...>`)

Descompacta o artefato mais recente do cache em `--root` (default `/`) e registra a lista de arquivos instalados.

```sh
sudo pkgm install core/binutils
```

Instalar em uma raiz alternativa (teste/chroot):

```sh
pkgm --root /mnt/rootfs install core/binutils
```

### `pkgm uninstall <pkg...>` (ou `pkgm u <pkg...>`)

Remove os arquivos registrados e limpa o registro.

### `pkgm clean <pkg...|all>` (ou `pkgm c ...`)

Remove diretórios de trabalho em cache (`$CACHE_DIR/work`). Útil para garantir builds limpos.

### `pkgm sysclean [--purge]`

Limpeza do sistema do `pkgm`:

- limpa `workdir`
- remove locks órfãos (PID inexistente)
- remove logs antigos (30 dias)
- com `--purge`, remove também pacotes binários do cache não referenciados

### `pkgm rebuild [pkg...|--installed]` (ou `pkgm r ...`)

Reconstrói e reinstala na ordem correta (respeitando dependências).

- sem argumentos: reconstrói **todos os pacotes instalados**
- com lista de pacotes: reconstrói apenas o solicitado (e dependências)

### `pkgm upgrade [pkg...|--installed|--all]` (ou `pkgm up ...`)

Upgrade inteligente:

- compara a **versão instalada** com a **versão do repositório**
- reconstrói e reinstala apenas quando a versão do repositório for maior

Opções:
- `--installed` (padrão): somente instalados
- `--all`: todos os pacotes conhecidos (constrói/instala os não instalados também)


## Logs

- Logs completos em arquivo: `LOG_DIR/<pkg>.<timestamp>.log`
- Logs em etapas no stderr com cor (se terminal suportar ANSI).

Exemplos de mensagens (formato aproximado):

- `🏭 [pkg] WORK: /var/cache/pkgm/work/pkg → DEST: /var/cache/pkgm/work/pkg/pkg`
- `❌ Script não encontrado: ...`
- `❌ Binário principal não encontrado em DESTDIR`
- `✅ [pkg] Binário: /usr/bin/foo`
- `[pkg] INSTALADO com sucesso! ✔️`

## Resolução de dependências e ciclos

A resolução usa DFS com estados (unseen/visiting/done). Se um ciclo for encontrado, a execução termina com erro indicando o caminho do ciclo.

## Diagnóstico e correções comuns

1. **Falha de download**  
   Verifique `source=` e conectividade. Confirme se `curl`/`wget` existe.

2. **MD5 inválido**  
   O arquivo no upstream pode ter mudado. Atualize `checksums=` no `build` para o novo md5.

3. **Script escreve fora de \$PKG**  
   Mova ações pós-instalação (links, ajustes em `/usr`, etc.) para `hook/post-install` (na etapa `install`) ou crie um pacote separado de “fixups”.

4. **Permissões (cache/DB/log)**  
   Ajuste `CACHE_DIR`, `DB_DIR`, `LOG_DIR` para diretórios no seu home ou use sudo.

## Exemplo de pacotes incluídos

Este repositório inclui exemplos em `repo/core/` (binutils e gcc). Eles vieram de scripts anexados e usam `PKG` como DESTDIR.

## Licença

MIT. Veja `LICENSE`.
