Coloque aqui arquivos *.patch; eles serão aplicados em $SRC antes do configure. Ordem: lexicográfica.
