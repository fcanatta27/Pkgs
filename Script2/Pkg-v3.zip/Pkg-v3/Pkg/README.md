# pkg (POSIX) — Tutorial completo (Brasil)

Este projeto entrega um gerenciador de pacotes **minimalista e POSIX** chamado `pkg`, focado em:

- **Baixar e manter em cache** as fontes (source tarballs).
- **Verificar integridade** com `sha256sum`.
- **Extrair**, **construir** e **instalar via DESTDIR** (staging) de forma reproduzível.
- **Empacotar** a instalação em um `.tar.gz` com metadados (`.PKGINFO` e `.FILES`) e manter em cache.
- **Instalar/remover com registro** (database), permitindo **uninstall seguro** e **upgrade**.
- **Resolver dependências** com **detecção de ciclo** (falha segura).
- **Validar** (lint) o arquivo `build` antes de executar.

---

## 1) Instalação do `pkg`

Dentro do tarball deste projeto existe o arquivo executável:

- `pkg_puro/pkg`

Sugestão (instalação local do usuário):

```sh
mkdir -p "$HOME/.local/bin"
cp -f pkg_puro/pkg "$HOME/.local/bin/pkg"
chmod +x "$HOME/.local/bin/pkg"
```

Garanta que `~/.local/bin` está no seu `PATH`.

### Dependências de runtime

O `pkg` usa ferramentas comuns de sistema:

- `sh` (POSIX)
- `curl`
- `tar`
- `sha256sum`
- `find`, `awk`, `sed`, `sort`, `mkdir`, `rm`, `rmdir`

---

## 2) Conceitos: repositório, cache e banco (registro)

O `pkg` trabalha com três áreas principais:

- **Repo (build scripts)**: onde ficam os scripts `build` por pacote
- **Cache**: onde ficam **sources baixadas**, **pacotes binários gerados** e **logs**
- **DB (registro)**: onde fica o inventário de arquivos instalados e metadados

Por padrão (XDG):

- `PKG_REPO=$XDG_DATA_HOME/pkg/repo` (ou `~/.local/share/pkg/repo`)
- `PKG_CACHE=$XDG_CACHE_HOME/pkg` (ou `~/.cache/pkg`)
- `PKG_DB=$XDG_STATE_HOME/pkg/db` (ou `~/.local/state/pkg/db`)

Para ver os paths efetivos:

```sh
pkg paths
```

---

## 3) Layout do repositório

Estrutura padrão:

```
repo/
  <categoria>/
    <programa>/
      build
```

Exemplo:

```
repo/core/gcc/build
repo/core/gmp/build
repo/core/mpfr/build
repo/core/mpc/build
```

---

## 4) Contrato do arquivo `build` (o que o pkg exige)

O `build` é **shell POSIX**, executado com `/bin/sh`.

### Variáveis obrigatórias

Todo `build` **precisa definir**:

- `name`        (nome do pacote)
- `version`     (versão)
- `release`     (inteiro; default 1)
- `desc`        (descrição curta; opcional, mas recomendado)
- `source`      (URL do tarball)
- `checksums`   (**sha256** do tarball — 64 hex)
- `depends`     (lista de dependências, opcional)

### Convenção DESTDIR (obrigatória)

O `pkg` **rejeita** builds que não instalem no staging.

- O staging é o diretório apontado por: `PKG`
- A prefix (default) é: `PREFIX=/usr/local`

Seu `build` deve instalar usando algo como:

- `make DESTDIR="$PKG" install`
- `cmake --install ... --prefix "$PREFIX"` com `DESTDIR="$PKG"` (quando aplicável)
- etc.

O essencial: **os arquivos instalados precisam ir para dentro de `$PKG`**, não direto no sistema.

### Dependências

Formato aceito (obrigatório):

- `categoria/nome`

Exemplo:

```sh
depends="core/gmp core/mpfr core/mpc"
```

O `pkg` resolve dependências com DFS e:
- instala dependências faltantes automaticamente;
- detecta ciclos e falha com mensagem clara.

---

## 5) Comandos do pkg

### Ajuda e paths

```sh
pkg help
pkg paths
```

### Verificar integridade do build (lint/contrato)

Antes de executar um build, o `pkg` faz uma verificação automaticamente.
Você também pode chamar manualmente:

```sh
pkg verify core/gcc   # errado (faltou separar argumentos)
pkg verify core gcc   # correto
```

O `verify` rejeita, por exemplo:
- shebang bash (`#!/bin/bash`)
- `[[ ... ]]`, `function`, `local`, `declare`, `pipefail`
- ausência de variáveis obrigatórias
- ausência de referência a `$PKG` (indicador de instalação via DESTDIR)

### Baixar (cache) e verificar sha256

```sh
pkg fetch core gcc
```

### Gerar pacote binário no cache

```sh
pkg build core gcc
```

O output será o caminho do pacote gerado, por exemplo:

```
~/.cache/pkg/pkgs/core-gcc-15.2.0-1.tar.gz
```

### Instalar (com resolução de dependências)

```sh
pkg install core gcc
```

Notas:
- Se existir um pacote binário no cache, o `pkg` tenta **instalar do cache** (mais rápido).
- Para forçar build de source, use:

```sh
PKG_PREFER_SOURCE=1 pkg install core gcc
```

### Remover (uninstall com registro)

```sh
pkg remove core gcc
```

O `pkg` remove:
- arquivos registrados em `DB/.../FILES`
- diretórios vazios remanescentes (somente se estiverem vazios)

Ele recusa remover caminhos críticos como `/`, `/usr`, `/etc`, etc.

### Upgrade

```sh
pkg upgrade core gcc
```

- Se o pacote não estiver instalado: instala.
- Se a versão do repo for igual à instalada: não faz nada.
- Se for diferente: reinstala (respeitando dependências).

### Listar instalados

```sh
pkg list
```

### Ver plano de dependências

```sh
pkg deps core gcc
```

---

## 6) Pacotes incluídos (repo/core)

### GCC (última série estável no momento do empacotamento)

- GCC **15.2.0** (release anunciado em 2025-08-08) 
- Tarball: `gcc-15.2.0.tar.xz` (ftp.gnu.org) 
- SHA256 (computado localmente neste empacotamento): `438fd996826b0c82485a29da03a72d71d6e3541a83ec702df4271f6fe025d24e`

### Dependências para GCC

- GMP 6.3.0 (download oficial) 
- MPFR 4.2.2 (GNU) 
- MPC 1.3.1 (GNU) 

---

## 7) Dicas práticas e troubleshooting

### Ver logs de build

Os logs ficam em:

```
$PKG_CACHE/logs/
```

Exemplo:

```sh
ls -1 ~/.cache/pkg/logs | tail
```

### Ambiente / Root

Por padrão `PKG_ROOT=/` e o install copia para o sistema real.
Para instalar em um “root” alternativo (ex.: imagem/chroot):

```sh
PKG_ROOT=/caminho/para/root pkg install core gcc
```

### Recomendações de segurança

- Não execute `build` de fontes não confiáveis.
- Use `pkg verify` e revise o build antes de executar.
- Prefira repos versionados (git) para auditabilidade.

---

## 8) Como escrever um novo build (template)

Crie:

```
repo/<cat>/<name>/build
```

Exemplo mínimo:

```sh
name=hello
version=1.0.0
release=1
desc="Exemplo"
source="https://example.com/hello-1.0.0.tar.gz"
checksums="<sha256-aqui>"
depends=""

build() {
  cd "$SRC"
  ./configure --prefix="$PREFIX"
  make
}

package() {
  cd "$SRC"
  make DESTDIR="$PKG" install
}

build
package
```

---

## 9) Licença

MIT.


## Formato do arquivo build (API do pkg)

Este `pkg` suporta **dois formatos** de receita `build` (ambos POSIX):

### 1) Formato com funções (recomendado)
O arquivo `build` define metadados e as funções **obrigatórias**:

- `build()`    compila (use `$WORK` para out-of-tree)
- `package()`  instala em staging usando `DESTDIR="$PKG"`

Requisito: **não execute comandos fora de funções**, porque o `pkg` irá carregar (`. build`) o arquivo neste modo.

### 2) Formato linear executável
O arquivo `build` é um script POSIX (com ou sem funções) que é **executado** com `/bin/sh build`.

Requisitos:
- definir metadados no topo: `name`, `version`, `source`, `checksums` (sha256 64 hex), `depends` (opcional)
- no final do script, produzir uma instalação completa em staging usando `DESTDIR="$PKG"` (ou equivalente)

### Patches
Em ambos os formatos, você pode adicionar uma pasta `patches/` ao lado do `build` e aplicar patches a partir do próprio `build`
via `patch -d "$SRC" -p1 < patchfile`.

