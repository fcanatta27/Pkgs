Etapa 0 — Host e layout do projeto

Objetivo
Ter um ambiente de build previsível, logs, e um rootfs em partição montado em /mnt/rootfs.
Estrutura recomendada
Rootfs (partição): /mnt/rootfs
Fontes: /mnt/rootfs/sources
Build: /mnt/rootfs/build
Logs: /mnt/rootfs/logs
Toolchain temporária: /mnt/rootfs/tools
Regras operacionais
Tudo que for instalado no sistema alvo vai para /mnt/rootfs via DESTDIR=/mnt/rootfs (quando aplicável) ou via --prefix=/usr com sysroot.
Tudo que for ferramenta de build temporária vai para /mnt/rootfs/tools.
Mantenha logs por pacote (logs/<pacote>.{configure,make,install}.log).
Use um “manifest” por pacote (lista de arquivos instalados) para desinstalação e limpeza.

Etapa 1 — Toolchain temporária (bootstrap) em /mnt/rootfs/tools

Objetivo
Gerar um compilador/linker que não dependa do userland do host para produzir binários para o seu sysroot.
Ordem mínima (correta para glibc)
Binutils (pass 1) para target (cross)
GCC (pass 1) (C-only, sem libc ainda; “bootstrap compiler”)
Linux API Headers (apenas headers exportados)
Glibc (instalada no sysroot /mnt/rootfs)
Libstdc++ (do GCC) e/ou GCC (pass 2) com C/C++
Critérios de pronto
/mnt/rootfs/tools/bin/<target>-gcc compila um “hello world”.
Linka contra glibc no sysroot (não contra o host).
readelf -l no binário mostra o loader do sysroot (ex.: ld-linux-x86-64.so.2 dentro de /mnt/rootfs/lib64 conforme a arquitetura).
Observação: aqui você ainda não precisa “construir o sistema”. Só garantir toolchain/glibc no sysroot.

Etapa 2 — Ferramentas de build internas (para parar de depender do host)

Objetivo
Conseguir construir o “resto do sistema” usando ferramentas instaladas no próprio rootfs (mesmo sem boot), via chroot.
Pacotes típicos (ordem funcional)
zlib, xz, zstd, bzip2 (compressões usadas em builds)
bash (ou mksh, mas bash simplifica)
coreutils, diffutils, findutils, gawk, grep, sed, tar, gzip, make, patch, file
m4
pkgconf
gettext, texinfo (muitos projetos exigem)
perl (muitos builds clássicos)
python (cada vez mais necessário: meson, partes do llvm/mesa, etc.)
Critérios de pronto
Você consegue entrar em chroot /mnt/rootfs /usr/bin/env -i ... /bin/bash --login.
Dentro do chroot você consegue compilar e instalar pacotes sem chamar ferramentas do host.

Etapa 3 — Toolchain final (agora “nativa” do seu sistema)

Objetivo
Reconstruir binutils/gcc para o sistema final, com paths, specs e rpaths corretos, e sem dependência de /tools.
Ordem recomendada
binutils (final) instalado em /usr
gcc (final) em /usr com C/C++ (e outras linguagens se quiser)
Dependências clássicas: gmp, mpfr, mpc, isl (conforme configuração do GCC)
Revalidar glibc (opcional, mas comum quando quer máxima limpeza)
Remover gradualmente /mnt/rootfs/tools do PATH e, ao final, deletar /mnt/rootfs/tools
Critérios de pronto
which gcc dentro do chroot aponta para /usr/bin/gcc.
Binários compilados não referenciam /tools.
gcc -v e ld --verbose mostram sysroot e search paths coerentes.

Etapa 4 — Base do sistema + init completo (sem systemd)

Você quer “init funcional e completo”. Sem systemd, as combinações mais práticas hoje são:
Opção A (minimalista e moderna): runit + seatd
runit: supervisão simples, previsível.
mdev (BusyBox) ou eudev para gerenciamento de dispositivos.
Para Wayland sem logind: seatd funciona bem com wlroots/Wayland.
Opção B (mais “distro-like” sem systemd): OpenRC + eudev + elogind
OpenRC para init/serviços
eudev para udev
elogind para uma API compatível com logind (muitos desktops gostam)
Base de sistema (ordem típica)
util-linux (mount, fdisk, etc.)
shadow (users/groups), pam (se quiser login completo)
linux-pam (se usar), cracklib (opcional)
acl, attr, libcap
sysklogd ou rsyslog (logging)
procps-ng, psmisc
iproute2, iptables/nftables, dhcpcd ou NetworkManager (mais tarde)
openssl (muita coisa depende), ca-certificates
curl/wget, git (para desenvolvimento)
Editor: vim/neovim (opcional)

Critérios de pronto
Você tem um /etc/fstab, /etc/passwd, /etc/group, /etc/hosts, timezone/locale.
Você tem init scripts/serviços definidos (runit ou OpenRC).
Você consegue “simular boot” até certo ponto usando chroot + montagem de /proc /sys /dev.

Etapa 5 — Kernel, drivers e firmware (antes do primeiro boot “sério”)

Objetivo
Ter um kernel que reconheça storage, rede e GPU, e um userspace que consiga subir serviços e Wayland.
Ordem prática
linux-firmware (se você tiver hardware que exige firmware)
Compilar kernel (com:
storage: SATA/AHCI, NVMe, USB storage
filesystem: ext4 (e o que mais usar)
networking: drivers da sua NIC/Wi-Fi
GPU: DRM/KMS para Intel/AMD/NVIDIA (dependendo do caso)
devtmpfs habilitado é altamente recomendado
Instalar módulos em /lib/modules/<versão>
Preparar bootloader (GRUB ou outro) e initramfs (se necessário)
Critérios de pronto
/boot/vmlinuz-* existe
/lib/modules/* existe e depmod funciona
Firmware instalado quando necessário

Etapa 6 — Stack gráfica e Wayland (em camadas)

Camada 1: fundação gráfica
libdrm
mesa (OpenGL/EGL/GLES) com suporte ao seu hardware
wayland e wayland-protocols
libinput (teclado/mouse/touch)
xkbcommon
pixman, cairo (muito usado)
Camada 2: sessão/assentos
Sem logind: seatd (e configure permissões)
Com logind: elogind (exige mais integração)
Camada 3: compositor e utilitários
wlroots (base de vários compositores) e um compositor como:
sway (tiling) ou
wayfire (mais “desktop”), ou
weston (referência do Wayland)
Camada 4: apps e “dia a dia”
Terminal: foot, alacritty, kitty
Fontes: fontconfig, freetype, harfbuzz
Áudio: pipewire (+ wireplumber) ou pulseaudio
Rede: NetworkManager (se quiser conveniência)
Navegador: depois (dependências grandes)

Empacotamento e “etapas” de verdade
Como você quer desenvolver com calma antes de boot, recomendo formalizar cada etapa com:
Prefixo e sysroot claros (/tools temporário; /usr final)
Logs por pacote
Manifest de arquivos por pacote
Snapshots do rootfs (tar ou btrfs snapshot, se usar btrfs) ao final de cada etapa importante:
após toolchain temporária
após ferramentas internas/chroot
após toolchain final
após base+init
após kernel/modules
após Wayland

