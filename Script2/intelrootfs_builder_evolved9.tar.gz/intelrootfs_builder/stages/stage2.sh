#!/bin/sh
# Stage2: cria rootfs mínimo funcional (limpo) usando toolchain separada.
#
# Conteúdo:
#   - BusyBox (estático por padrão)
#   - /init mais completo
#   - /etc básico, /dev via devtmpfs, /proc, /sys
#
# Saída:
#   - $ROOTFS

set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$ROOT_DIR/scripts/common.sh"
. "$ROOT_DIR/build.conf"

OUT=$(abspath "$OUT")
ROOTFS=$(abspath "$ROOTFS")
SOURCES=$(abspath "$SOURCES")
WORKDIR=$(abspath "$WORKDIR")
DESTDIR_BASE=$(abspath "$DESTDIR_BASE")
LOGDIR=$(abspath "$LOGDIR")

TOOLCHAIN=$(abspath "$TOOLCHAIN")
SYSROOT=$(abspath "$SYSROOT")

mkdir_p "$OUT" "$ROOTFS" "$SOURCES" "$WORKDIR" "$DESTDIR_BASE" "$LOGDIR"

# Ensure toolchain exists
[ -d "$TOOLCHAIN/bin" ] || die "toolchain não encontrada em: $TOOLCHAIN (rode stage1)"
export PATH="$TOOLCHAIN/bin:$PATH"

# Triplets
if [ -z "${BUILD:-}" ]; then
  if command -v gcc >/dev/null 2>&1; then
    BUILD=$(gcc -dumpmachine)
  else
    BUILD=unknown-unknown-linux-gnu
  fi
fi
: "${TARGET:=$BUILD}"
: "${HOST:=$TARGET}"
export BUILD TARGET HOST

export ROOTFS SYSROOT TOOLS_PREFIX="$TOOLCHAIN"

build_pkg() {
  recipe=$1
  "$ROOT_DIR/scripts/builder.sh"     --recipe "$recipe"     --workdir "$WORKDIR"     --srcdir "$SOURCES"     --destdir "$DESTDIR_BASE"     --logdir "$LOGDIR"     --cachedir "$WORKDIR/cache/build"
}

merge_to() {
  srcdest=$1
  dest=$2
  "$ROOT_DIR/scripts/merge.sh" "$srcdest" "$dest"
}

build_and_merge() {
  recipe=$1
  target_tree=$2

  build_pkg "$recipe"

  pkg_name=
  pkg_ver=
  (
    . "$recipe"
    echo "$name" >"$WORKDIR/.pkgname.$$"
    echo "$version" >"$WORKDIR/.pkgver.$$"
  )
  pkg_name=$(cat "$WORKDIR/.pkgname.$$"); rm -f "$WORKDIR/.pkgname.$$"
  pkg_ver=$(cat "$WORKDIR/.pkgver.$$"); rm -f "$WORKDIR/.pkgver.$$"

  best=
  for d in "$DESTDIR_BASE/${pkg_name}-${pkg_ver}-"*; do
    [ -d "$d" ] || continue
    if [ -z "$best" ] || [ "$d" -nt "$best" ]; then
      best=$d
    fi
  done
  [ -n "$best" ] || die "não encontrei DESTDIR para ${pkg_name}-${pkg_ver}"
  merge_to "$best" "$target_tree"
}

# Rootfs skeleton
for d in bin sbin etc proc sys dev tmp run root usr/bin usr/sbin var/log; do
  mkdir_p "$ROOTFS/$d"
done
chmod 0755 "$ROOTFS"
chmod 1777 "$ROOTFS/tmp" || true

# Build BusyBox into ROOTFS (static by default)
export TOOLCHAIN_BINDIR="$TOOLCHAIN/bin"
: "${BUSYBOX_STATIC:=1}"
export BUSYBOX_STATIC
build_and_merge "$ROOT_DIR/recipes/busybox-1.36.1.recipe" "$ROOTFS"

# Base libs & utils (dinâmicos) no rootfs
# Observação: BusyBox pode continuar estático; os bins abaixo serão dinâmicos e
# as libs runtime serão copiadas do SYSROOT ao final (copy_deps.sh).
build_and_merge "$ROOT_DIR/recipes/zlib-1.3.1.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/bzip2-1.0.8.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/xz-5.6.4.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/gzip-1.14.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/tar-1.35.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/m4-1.4.19.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/bash-5.2.recipe" "$ROOTFS"
# Dev/build tools (úteis no sistema instalado)
build_and_merge "$ROOT_DIR/recipes/make-4.4.1.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/patch-2.7.6.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/rsync-3.4.1.recipe" "$ROOTFS"


# TLS/SSH/HTTP
build_and_merge "$ROOT_DIR/recipes/openssl-3.6.0.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/curl-8.17.0.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/openssh-9.9p2.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/dropbear-2025.87.recipe" "$ROOTFS"

# Kernel modules + net tools + discos
build_and_merge "$ROOT_DIR/recipes/kmod-34.1.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/iproute2-3.1.0.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/util-linux-2.41.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/e2fsprogs-1.47.3.recipe" "$ROOTFS"
build_and_merge "$ROOT_DIR/recipes/shadow-4.16.0.recipe" "$ROOTFS"

# Wrapper init para boot em disco real com fallback automático para o initramfs
mkdir_p "$ROOTFS/sbin"
cat >"$ROOTFS/sbin/init-fallback" <<'EOF'
#!/bin/sh
set -eu

# Executa init real do disco se existir; senão, roda minit do próprio sistema.
# Se init real falhar, cai para minit do initramfs montado em /run/initramfs.

log() { printf '%s\n' "[init-fallback] $*" > /dev/console 2>/dev/null || true; }

# Preferência:
# 1) /sbin/real-init (se você quiser um init diferente)
# 2) /sbin/init (minit/busybox/systemd)
# 3) fallback: /run/initramfs/sbin/minit (ou /run/initramfs/init)
try_exec() {
  x="$1"
  if [ -x "$x" ]; then
    log "exec $x"
    exec "$x"
  fi
}

try_exec /sbin/real-init
try_exec /sbin/init
try_exec /init

log "init do root real indisponível; tentando fallback para initramfs"
try_exec /run/initramfs/sbin/minit
try_exec /run/initramfs/init

log "fallback indisponível; entrando em shell"
exec /bin/sh
EOF
chmod +x "$ROOTFS/sbin/init-fallback"

# Garante /sbin/init (busybox)
if [ ! -x "$ROOTFS/sbin/init" ] && [ -x "$ROOTFS/bin/busybox" ]; then
  mkdir_p "$ROOTFS/sbin"
  ln -sf /bin/busybox "$ROOTFS/sbin/init" 2>/dev/null || true
fi

# Minimal /etc
if [ ! -f "$ROOTFS/etc/passwd" ]; then
  cat >"$ROOTFS/etc/passwd" <<'EOF'
root:x:0:0:root:/root:/bin/sh
EOF
fi

if [ ! -f "$ROOTFS/etc/group" ]; then
  cat >"$ROOTFS/etc/group" <<'EOF'
root:x:0:
EOF
fi
# Configurações de login (shadow)
if [ ! -f "$ROOTFS/etc/login.defs" ]; then
  cat >"$ROOTFS/etc/login.defs" <<'EOF'
MAIL_DIR        /var/mail
PASS_MAX_DAYS   99999
PASS_MIN_DAYS   0
PASS_MIN_LEN    8
PASS_WARN_AGE   7
UID_MIN         1000
UID_MAX         60000
GID_MIN         1000
GID_MAX         60000
CREATE_HOME     yes
UMASK           022
ENCRYPT_METHOD  SHA512
EOF
fi

mkdir_p "$ROOTFS/var/log" "$ROOTFS/var/mail" "$ROOTFS/var/spool/mail" "$ROOTFS/var/run"
touch "$ROOTFS/var/log/lastlog" "$ROOTFS/var/log/wtmp" "$ROOTFS/var/log/btmp" 2>/dev/null || true
chmod 664 "$ROOTFS/var/log/lastlog" "$ROOTFS/var/log/wtmp" 2>/dev/null || true
chmod 600 "$ROOTFS/var/log/btmp" 2>/dev/null || true

if [ ! -f "$ROOTFS/etc/shadow" ]; then
  cat >"$ROOTFS/etc/shadow" <<'EOF'
root:*:19793:0:99999:7:::
EOF
  chmod 600 "$ROOTFS/etc/shadow" 2>/dev/null || true
fi

if [ ! -f "$ROOTFS/etc/gshadow" ]; then
  cat >"$ROOTFS/etc/gshadow" <<'EOF'
root:*::
EOF
  chmod 600 "$ROOTFS/etc/gshadow" 2>/dev/null || true
fi

# Defaults de rede/identidade
if [ ! -f "$ROOTFS/etc/hosts" ]; then
  cat >"$ROOTFS/etc/hosts" <<'EOF'
127.0.0.1 localhost
::1 localhost
EOF
fi

if [ ! -f "$ROOTFS/etc/resolv.conf" ]; then
  cat >"$ROOTFS/etc/resolv.conf" <<'EOF'
# Ajuste conforme seu ambiente
nameserver 1.1.1.1
nameserver 8.8.8.8
EOF
fi

if [ ! -f "$ROOTFS/etc/nsswitch.conf" ]; then
  cat >"$ROOTFS/etc/nsswitch.conf" <<'EOF'
passwd: files
group:  files
shadow: files
hosts:  files dns
services: files
networks: files
protocols: files
rpc: files
ethers: files
EOF
fi

if [ ! -f "$ROOTFS/etc/securetty" ]; then
  cat >"$ROOTFS/etc/securetty" <<'EOF'
tty1
tty2
tty3
tty4
ttyS0
ttyS1
ttyAMA0
EOF
fi



if [ ! -f "$ROOTFS/etc/profile" ]; then
  cat >"$ROOTFS/etc/profile" <<'EOF'
export PATH=/bin:/sbin:/usr/bin:/usr/sbin
export PS1='(rootfs) \u@\h:\w\$ '
EOF
fi

if [ ! -f "$ROOTFS/etc/hostname" ]; then
  echo "rootfs" >"$ROOTFS/etc/hostname"
fi
if [ ! -f "$ROOTFS/etc/issue" ]; then
  cat >"$ROOTFS/etc/issue" <<'EOF'
intelrootfs (busybox) \n \\l
EOF
fi

if [ ! -f "$ROOTFS/etc/securetty" ]; then
  cat >"$ROOTFS/etc/securetty" <<'EOF'
tty1
tty2
tty3
tty4
ttyS0
EOF
fi

# init (busybox) configuration: getty em console local e serial
mkdir_p "$ROOTFS/etc/init.d"
if [ ! -f "$ROOTFS/etc/inittab" ]; then
  cat >"$ROOTFS/etc/inittab" <<'EOF'
::sysinit:/etc/init.d/rcS
::respawn:/sbin/getty -L 115200 ttyS0 vt102
tty1::respawn:/sbin/getty -L 38400 tty1 linux
::ctrlaltdel:/sbin/reboot
::shutdown:/bin/umount -a -r
EOF
fi

if [ ! -f "$ROOTFS/etc/init.d/rcS" ]; then
  cat >"$ROOTFS/etc/init.d/rcS" <<'EOF'
#!/bin/sh
set -eu

PATH=/bin:/sbin:/usr/bin:/usr/sbin

# Montagens padrões (se existir fstab)
if [ -f /etc/fstab ]; then
  mount -a 2>/dev/null || true
fi

# Ajustes de kernel básicos
[ -w /proc/sys/kernel/printk ] && echo "4 4 1 7" > /proc/sys/kernel/printk 2>/dev/null || true

# Rede (se busybox udhcpc existir e houver iface)
if command -v udhcpc >/dev/null 2>&1; then
  if ip link show eth0 >/dev/null 2>&1; then
    ip link set eth0 up 2>/dev/null || true
    udhcpc -i eth0 -q -t 3 -n 2>/dev/null || true
  fi
fi
EOF
  chmod +x "$ROOTFS/etc/init.d/rcS"
fi

if [ ! -f "$ROOTFS/etc/fstab" ]; then
  cat >"$ROOTFS/etc/fstab" <<'EOF'
proc  /proc proc  defaults 0 0
sysfs /sys  sysfs defaults 0 0
devtmpfs /dev devtmpfs defaults 0 0
tmpfs /tmp tmpfs defaults 0 0
EOF
fi

# /init: simples porém mais completo que stage1 anterior
cat >"$ROOTFS/init" <<'EOF'
#!/bin/sh
# /init = PID1 no initramfs (minit embutido)
# Objetivo:
#   1) montar /proc /sys /dev /run /tmp
#   2) tentar montar e fazer switch_root para o root real (root= no cmdline)
#   3) se falhar, continuar no initramfs e subir serviços mínimos

set -eu

log() { printf '%s
' "[initramfs] $*" > /dev/console 2>/dev/null || printf '%s
' "[initramfs] $*"; }

mkdir -p /proc /sys /dev /run /tmp /newroot
chmod 1777 /tmp 2>/dev/null || true

mountpoint -q /proc 2>/dev/null || mount -t proc proc /proc 2>/dev/null || true
mountpoint -q /sys  2>/dev/null || mount -t sysfs sys /sys 2>/dev/null || true
mountpoint -q /dev  2>/dev/null || mount -t devtmpfs dev /dev 2>/dev/null || true
mountpoint -q /run  2>/dev/null || mount -t tmpfs run /run 2>/dev/null || true

# Console básico
[ -c /dev/console ] || mknod -m 600 /dev/console c 5 1 2>/dev/null || true
[ -c /dev/null ]    || mknod -m 666 /dev/null    c 1 3 2>/dev/null || true

# hostname
if [ -f /etc/hostname ]; then
  hn=$(cat /etc/hostname 2>/dev/null || true)
  [ -n "$hn" ] && echo "$hn" > /proc/sys/kernel/hostname 2>/dev/null || true
fi

# Resolve root= (suporta /dev/xxx, UUID=, LABEL=; usa findfs/blkid se existir)
get_cmdline_kv() {
  key="$1"
  for x in $(cat /proc/cmdline 2>/dev/null || true); do
    case "$x" in
      "$key"=*) echo "${x#*=}"; return 0;;
    esac
  done
  return 1
}

rescue_mode() {
  for x in $(cat /proc/cmdline 2>/dev/null || true); do
    case "$x" in
      rescue=1|single=1|single|emergency) return 0 ;;
    esac
  done
  return 1
}

# Network boot: tenta DHCP (udhcpc) e monta nfsroot=SERVER:/path se presente.
net_if_up() {
  # escolhe primeira interface não-loopback
  IF=""
  if command -v ip >/dev/null 2>&1; then
    IF=$(ip -o link show 2>/dev/null | awk -F': ' '{print $2}' | grep -v '^lo$' | head -n1 || true)
    [ -n "$IF" ] && ip link set "$IF" up 2>/dev/null || true
  else
    # fallback com ifconfig (busybox)
    IF=$(ifconfig -a 2>/dev/null | awk '/^[a-zA-Z0-9]/ {print $1}' | sed 's/://g' | grep -v '^lo$' | head -n1 || true)
    [ -n "$IF" ] && ifconfig "$IF" up 2>/dev/null || true
  fi
  echo "$IF"
}

net_dhcp() {
  IF="$1"
  [ -n "$IF" ] || return 1
  if command -v udhcpc >/dev/null 2>&1; then
    udhcpc -i "$IF" -n -q -t 5 -T 2 2>/dev/null || true
    return 0
  fi
  return 1
}

mount_nfsroot() {
  nfsroot=$(get_cmdline_kv nfsroot 2>/dev/null || true)
  [ -n "$nfsroot" ] || return 1
  IF=$(net_if_up)
  net_dhcp "$IF" || true
  log "montando nfsroot=$nfsroot em /newroot"
  mkdir -p /newroot
  # opções conservadoras
  mount -t nfs -o nolock,ro "$nfsroot" /newroot 2>/dev/null || mount -t nfs "$nfsroot" /newroot 2>/dev/null || return 1
  mkdir -p /newroot/{proc,sys,dev,run,tmp} 2>/dev/null || true
  mount --move /proc /newroot/proc 2>/dev/null || true
  mount --move /sys  /newroot/sys  2>/dev/null || true
  mount --move /dev  /newroot/dev  2>/dev/null || true
  mount --move /run  /newroot/run  2>/dev/null || true
  mkdir -p /newroot/run/initramfs 2>/dev/null || true
  mount --bind / /newroot/run/initramfs 2>/dev/null || true
  newinit=/sbin/init-fallback
  [ -x "/newroot/sbin/init-fallback" ] || newinit=/sbin/init
  if command -v switch_root >/dev/null 2>&1; then
    log "network boot: switch_root -> $newinit"
    exec switch_root /newroot "$newinit"
  fi
  return 1
}

resolve_root() {
  r="$1"
  [ -n "$r" ] || return 1
  case "$r" in
    UUID=*|LABEL=*)
      if command -v findfs >/dev/null 2>&1; then
        findfs "$r" 2>/dev/null || true
      elif command -v blkid >/dev/null 2>&1; then
        # blkid -o device -t UUID=xxxx
        k="${r%%=*}"; v="${r#*=}"
        blkid -o device -t "$k=$v" 2>/dev/null | head -n1 || true
      else
        echo ""
      fi
      ;;
    /dev/*) echo "$r";;
    *) echo "$r";;
  esac
}

wait_for_block() {
  dev="$1"
  i=0
  while [ $i -lt 60 ]; do
    [ -b "$dev" ] && return 0
    i=$((i+1))
    sleep 0.1
  done
  return 1
}

try_switch_root() {
  root_spec=$(get_cmdline_kv root 2>/dev/null || true)
  [ -n "$root_spec" ] || return 1

  rootdev=$(resolve_root "$root_spec")
  [ -n "$rootdev" ] || rootdev="$root_spec"

  rootfstype=$(get_cmdline_kv rootfstype 2>/dev/null || true)
  rootflags=$(get_cmdline_kv rootflags 2>/dev/null || true)

  ro_rw=rw
  for x in $(cat /proc/cmdline 2>/dev/null || true); do
    [ "$x" = ro ] && ro_rw=ro
    [ "$x" = rw ] && ro_rw=rw
  done

  if [ -n "$rootdev" ] && [ "$rootdev" != "rootfs" ]; then
    log "root=($root_spec) -> $rootdev; aguardando device..."
    if wait_for_block "$rootdev"; then
      log "montando root real em /newroot"
      mkdir -p /newroot
      opts="$ro_rw"
      [ -n "$rootflags" ] && opts="$opts,$rootflags"
      if [ -n "$rootfstype" ]; then
        mount -t "$rootfstype" -o "$opts" "$rootdev" /newroot 2>/dev/null || return 1
      else
        mount -o "$opts" "$rootdev" /newroot 2>/dev/null || return 1
      fi

      # garante diretórios esperados
      mkdir -p /newroot/proc /newroot/sys /newroot/dev /newroot/run /newroot/tmp

      # move montagens para o novo root
      mount --move /proc /newroot/proc 2>/dev/null || true
      mount --move /sys  /newroot/sys  2>/dev/null || true
      mount --move /dev  /newroot/dev  2>/dev/null || true
      mount --move /run  /newroot/run  2>/dev/null || true

      # Disponibiliza initramfs para fallback em /run/initramfs
      mkdir -p /newroot/run/initramfs
      mount --bind / /newroot/run/initramfs 2>/dev/null || true

      # init no novo root: usa wrapper com fallback
      newinit=/sbin/init-fallback
      # Se o root real não tem wrapper, cai em /sbin/init ou /init
      if [ ! -x "/newroot/sbin/init-fallback" ]; then
        newinit=/sbin/init
        [ -x "/newroot/sbin/init" ] || newinit=/init
      fi

      if command -v switch_root >/dev/null 2>&1; then
        log "executando switch_root -> $newinit"
        exec switch_root /newroot "$newinit"
      elif command -v pivot_root >/dev/null 2>&1; then
        log "switch_root ausente; tentando pivot_root"
        mkdir -p /newroot/old_root
        pivot_root /newroot /newroot/old_root
        exec chroot . "$newinit"
      fi
    fi
  fi
  return 1
}

if rescue_mode; then
  log "rescue mode ativo (rescue=1). Não farei switch_root."
elif mount_nfsroot; then
  :
elif try_switch_root; then
  : # nunca volta
else
  log "sem root real (ou falha ao montar). Continuando no initramfs."
fi

# ======== minit (supervisor simples + svctl) ========

# PATH mínimo
export PATH=/usr/sbin:/usr/bin:/sbin:/bin


mkdir -p /etc/minit /etc/minit/services.d /run/minit /var/log

# mdev (se existir) para /dev dinâmico
if [ -x /sbin/mdev ]; then
  echo /sbin/mdev > /proc/sys/kernel/hotplug 2>/dev/null || true
  /sbin/mdev -s 2>/dev/null || true
fi

# Logger opcional
command -v syslogd >/dev/null 2>&1 && syslogd -n -O /var/log/messages 2>/dev/null &
command -v klogd   >/dev/null 2>&1 && klogd -n 2>/dev/null &

# getty básico (tty1) - pode ser sobrescrito por /etc/minit/services.d/getty/*
if [ ! -d /etc/minit/services.d/getty-tty1 ]; then
  mkdir -p /etc/minit/services.d/getty-tty1
  cat > /etc/minit/services.d/getty-tty1/run <<'EOR'
#!/bin/sh
exec /sbin/getty -L 115200 tty1 vt100
EOR
  chmod +x /etc/minit/services.d/getty-tty1/run
fi

# Helpers do supervisor
log2() { printf '%s
' "[minit] $*" > /dev/console 2>/dev/null || true; }

start_one() {
  name="$1"
  dir="/etc/minit/services.d/$name"
  run="$dir/run"
  down="$dir/down"
  sup="/run/minit/$name.sup"
  [ -x "$run" ] || return 0
  [ -f "$down" ] && return 0
  [ -f "$sup" ] && return 0

  (
    while :; do
      log2 "start $name"
      sh -c "$run" &
      child=$!
      echo "$child" > "/run/minit/$name.pid" 2>/dev/null || true
      wait "$child" || true
      rm -f "/run/minit/$name.pid" 2>/dev/null || true
      [ -f "$down" ] && break
      log2 "respawn $name (sleep 1)"
      sleep 1
    done
    log2 "stopped $name"
  ) &
  echo $! >"$sup" 2>/dev/null || true
}

stop_one() {
  name="$1"
  dir="/etc/minit/services.d/$name"
  sup="/run/minit/$name.sup"
  pidf="/run/minit/$name.pid"
  : > "$dir/down" 2>/dev/null || true
  if [ -f "$sup" ]; then
    spid=$(cat "$sup" 2>/dev/null || true)
    [ -n "$spid" ] && kill "$spid" 2>/dev/null || true
    rm -f "$sup" 2>/dev/null || true
  fi
  if [ -f "$pidf" ]; then
    cpid=$(cat "$pidf" 2>/dev/null || true)
    [ -n "$cpid" ] && kill "$cpid" 2>/dev/null || true
    rm -f "$pidf" 2>/dev/null || true
  fi
  rm -f "$dir/down" 2>/dev/null || true
}

# Controle via FIFO: /run/minit/ctl
mkdir -p /run/minit
CTL=/run/minit/ctl
[ -p "$CTL" ] || (rm -f "$CTL" 2>/dev/null || true; mkfifo "$CTL" 2>/dev/null || true)

# Listener de comandos (start/stop/restart/status)
(
  while IFS= read -r line; do
    set -- $line
    cmd=${1:-}; svc=${2:-all}
    case "$cmd" in
      start)
        if [ "$svc" = all ]; then
          for s in $(ls -1 /etc/minit/services.d 2>/dev/null || true); do
            rm -f "/etc/minit/services.d/$s/down" 2>/dev/null || true
            start_one "$s" || true
          done
        else
          rm -f "/etc/minit/services.d/$svc/down" 2>/dev/null || true
          start_one "$svc" || true
        fi
        ;;
      stop)
        if [ "$svc" = all ]; then
          for s in $(ls -1 /etc/minit/services.d 2>/dev/null || true); do
            stop_one "$s" || true
          done
        else
          stop_one "$svc" || true
        fi
        ;;
      restart)
        if [ "$svc" = all ]; then
          for s in $(ls -1 /etc/minit/services.d 2>/dev/null || true); do
            stop_one "$s" || true
            rm -f "/etc/minit/services.d/$s/down" 2>/dev/null || true
            start_one "$s" || true
          done
        else
          stop_one "$svc" || true
          rm -f "/etc/minit/services.d/$svc/down" 2>/dev/null || true
          start_one "$svc" || true
        fi
        ;;
      status)
        if [ "$svc" = all ]; then
          for s in $(ls -1 /etc/minit/services.d 2>/dev/null || true); do
            pidf="/run/minit/$s.pid"
            if [ -f "$pidf" ] && pid=$(cat "$pidf" 2>/dev/null || true) && [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
              echo "$s: running (pid $pid)" > /dev/console 2>/dev/null || true
            else
              echo "$s: stopped" > /dev/console 2>/dev/null || true
            fi
          done
        else
          pidf="/run/minit/$svc.pid"
          if [ -f "$pidf" ] && pid=$(cat "$pidf" 2>/dev/null || true) && [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            echo "$svc: running (pid $pid)" > /dev/console 2>/dev/null || true
          else
            echo "$svc: stopped" > /dev/console 2>/dev/null || true
          fi
        fi
        ;;
      *) : ;;
    esac
  done < "$CTL"
) &

# /sbin/svctl (cliente)
cat > /sbin/svctl <<'EOS'
#!/bin/sh
set -eu
CTL=/run/minit/ctl
cmd=${1:-}; svc=${2:-all}
usage() { echo "uso: svctl {start|stop|restart|status} [serviço|all]" >&2; exit 2; }
case "$cmd" in
  start|stop|restart|status) : ;;
  *) usage;;
esac
[ -p "$CTL" ] || { echo "svctl: fifo $CTL não existe" >&2; exit 1; }
printf '%s %s
' "$cmd" "$svc" > "$CTL"
EOS
chmod +x /sbin/svctl

start_all
log2 "minit: PID1 reaper loop"
while :; do
  wait 2>/dev/null || true
done

EOF
chmod +x "$ROOTFS/init"

# minit: supervisor simples (PID1) com start/stop/restart/respawn
mkdir_p "$ROOTFS/sbin" "$ROOTFS/etc/minit/services.d" "$ROOTFS/run/minit" "$ROOTFS/var/log"

cat >"$ROOTFS/sbin/minit" <<'EOF'
#!/bin/sh
# minit: init + supervisor minimalista (POSIX sh)
set -eu

LOG=/var/log/minit.log
mkdir -p /run/minit /var/log

log() { printf '%s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo date)" "$*" >>"$LOG" 2>/dev/null || true; }

# Reap + signal handling
trap 'log "SIGTERM recebido"; /sbin/svctl stop all || true; exit 0' TERM INT
trap 'log "SIGHUP recebido"; /sbin/svctl restart all || true' HUP

start_one() {
  name=$1
  dir="/etc/minit/services.d/$name"
  run="$dir/run"
  [ -x "$run" ] || return 0

  mkdir -p /run/minit
  down="/run/minit/down.$name"
  sup="/run/minit/supervisor.$name.pid"

  # já rodando?
  if [ -f "$sup" ] && kill -0 "$(cat "$sup" 2>/dev/null)" 2>/dev/null; then
    return 0
  fi

  (
    trap 'exit 0' TERM INT
    while [ ! -f "$down" ]; do
      log "start $name"
      "$run" &
      child=$!
      echo "$child" >"/run/minit/$name.pid" 2>/dev/null || true
      wait "$child" || true
      rm -f "/run/minit/$name.pid" 2>/dev/null || true
      [ -f "$down" ] && break
      log "respawn $name (sleep 1)"
      sleep 1
    done
    log "stopped $name"
  ) &
  echo $! >"$sup" 2>/dev/null || true
}

start_all() {
  for d in /etc/minit/services.d/*; do
    [ -d "$d" ] || continue
    start_one "$(basename "$d")"
  done
}

# Early: loopback + /dev/tty*
if command -v stty >/dev/null 2>&1 && [ -c /dev/console ]; then
  stty -F /dev/console 115200 2>/dev/null || true
fi

start_all
log "minit pronto; entrando em loop de reap()"

# PID1 precisa sempre reaper zombies
while :; do
  # wait sem args reaper qualquer filho que terminar
  wait 2>/dev/null || true
done
EOF
chmod +x "$ROOTFS/sbin/minit"

cat >"$ROOTFS/sbin/svctl" <<'EOF'
#!/bin/sh
# svctl: controla serviços do minit
set -eu

usage() {
  echo "uso: svctl {start|stop|restart|status} {all|NOME}" >&2
  exit 2
}

[ $# -ge 2 ] || usage
cmd=$1
name=$2

svc_dir=/etc/minit/services.d
run_dir=/run/minit

list_svcs() {
  for d in "$svc_dir"/*; do
    [ -d "$d" ] || continue
    echo "$(basename "$d")"
  done
}

do_start() {
  s=$1
  rm -f "$run_dir/down.$s" 2>/dev/null || true
  # sinaliza PID1 via HUP para reler? simples: tocar flag e sair.
  kill -HUP 1 2>/dev/null || true
}

do_stop() {
  s=$1
  : >"$run_dir/down.$s"
  # mata child se existir
  if [ -f "$run_dir/$s.pid" ]; then
    pid=$(cat "$run_dir/$s.pid" 2>/dev/null || true)
    [ -n "$pid" ] && kill "$pid" 2>/dev/null || true
  fi
  # mata supervisor
  if [ -f "$run_dir/supervisor.$s.pid" ]; then
    spid=$(cat "$run_dir/supervisor.$s.pid" 2>/dev/null || true)
    [ -n "$spid" ] && kill "$spid" 2>/dev/null || true
  fi
}

do_status() {
  s=$1
  if [ -f "$run_dir/$s.pid" ] && kill -0 "$(cat "$run_dir/$s.pid" 2>/dev/null)" 2>/dev/null; then
    echo "$s: running (pid $(cat "$run_dir/$s.pid"))"
  else
    echo "$s: stopped"
  fi
}

case "$cmd" in
  start)
    if [ "$name" = all ]; then for s in $(list_svcs); do do_start "$s"; done
    else do_start "$name"; fi
    ;;
  stop)
    if [ "$name" = all ]; then for s in $(list_svcs); do do_stop "$s"; done
    else do_stop "$name"; fi
    ;;
  restart)
    if [ "$name" = all ]; then for s in $(list_svcs); do do_stop "$s"; do_start "$s"; done
    else do_stop "$name"; do_start "$name"; fi
    ;;
  status)
    if [ "$name" = all ]; then for s in $(list_svcs); do do_status "$s"; done
    else do_status "$name"; fi
    ;;
  *) usage;;
esac
EOF
chmod +x "$ROOTFS/sbin/svctl"

# Serviços padrão (mínimos e seguros)
# 1) getty em tty1 (console local)
mkdir -p "$ROOTFS/etc/minit/services.d/getty-tty1"
cat >"$ROOTFS/etc/minit/services.d/getty-tty1/run" <<'EOF'
#!/bin/sh
exec /usr/sbin/agetty -L 115200 tty1 linux
EOF
chmod +x "$ROOTFS/etc/minit/services.d/getty-tty1/run"

# 2) loopback e DHCP (se udhcpc existir)
mkdir -p "$ROOTFS/etc/minit/services.d/net"
cat >"$ROOTFS/etc/minit/services.d/net/run" <<'EOF'
#!/bin/sh
set -eu
ip link set lo up 2>/dev/null || true
# tenta DHCP na primeira iface não-lo
IFACE=$(ip -o link 2>/dev/null | awk -F': ' '$2!="lo"{print $2; exit}')
[ -n "${IFACE:-}" ] || exec sleep 3600
ip link set "$IFACE" up 2>/dev/null || true
if command -v udhcpc >/dev/null 2>&1; then
  exec udhcpc -f -q -i "$IFACE"
fi
exec sleep 3600
EOF
chmod +x "$ROOTFS/etc/minit/services.d/net/run"

# 3) dropbear (SSH leve) - desabilitado por padrão
mkdir -p "$ROOTFS/etc/minit/services.d/dropbear"
cat >"$ROOTFS/etc/minit/services.d/dropbear/run" <<'EOF'
#!/bin/sh
set -eu
mkdir -p /etc/dropbear /var/run
# gera chaves se não existirem
[ -f /etc/dropbear/dropbear_ed25519_host_key ] || dropbearkey -t ed25519 -f /etc/dropbear/dropbear_ed25519_host_key >/dev/null 2>&1 || true
[ -f /etc/dropbear/dropbear_rsa_host_key ] || dropbearkey -t rsa -s 4096 -f /etc/dropbear/dropbear_rsa_host_key >/dev/null 2>&1 || true
exec dropbear -F -E -p 22
EOF
chmod +x "$ROOTFS/etc/minit/services.d/dropbear/run"
: >"$ROOTFS/run/minit/down.dropbear"

# 4) sshd (OpenSSH) - desabilitado por padrão
mkdir -p "$ROOTFS/etc/minit/services.d/sshd"
cat >"$ROOTFS/etc/minit/services.d/sshd/run" <<'EOF'
#!/bin/sh
set -eu
mkdir -p /var/empty /var/run/sshd
[ -f /etc/ssh/ssh_host_ed25519_key ] || ssh-keygen -A >/dev/null 2>&1 || true
exec /usr/sbin/sshd -D -e
EOF
chmod +x "$ROOTFS/etc/minit/services.d/sshd/run"
: >"$ROOTFS/run/minit/down.sshd"

# Kernel (opcional): build e entrega em $OUT/kernel (não entra no rootfs por padrão)
: "${ENABLE_KERNEL:=0}"
if [ "$ENABLE_KERNEL" = 1 ]; then
  KOUT="$OUT/kernel"
  mkdir_p "$KOUT"
  build_and_merge "$ROOT_DIR/recipes/linux-kernel-6.18.2.recipe" "$KOUT"
  # Opcional: copiar módulos para rootfs (útil para boot em disco)
  : "${KERNEL_TO_ROOTFS:=0}"
  if [ "$KERNEL_TO_ROOTFS" = 1 ]; then
    if [ -d "$KOUT/lib/modules" ]; then
      mkdir_p "$ROOTFS/lib"
      cp -a "$KOUT/lib/modules" "$ROOTFS/lib/" 2>/dev/null || true
    fi
  fi
fi

log "Stage2 OK"

# Serviços essenciais (root real): mount-all, sysctl, ssh keys
mkdir_p "$ROOTFS/etc/minit/services.d/mount-all"
cat >"$ROOTFS/etc/minit/services.d/mount-all/run" <<'EOF'
#!/bin/sh
set -eu
[ -f /etc/fstab ] || exit 0
mount -a 2>/dev/null || true
exit 0
EOF
chmod +x "$ROOTFS/etc/minit/services.d/mount-all/run"

mkdir_p "$ROOTFS/etc/minit/services.d/sysctl"
cat >"$ROOTFS/etc/minit/services.d/sysctl/run" <<'EOF'
#!/bin/sh
set -eu
[ -f /etc/sysctl.conf ] && sysctl -p /etc/sysctl.conf 2>/dev/null || true
exit 0
EOF
chmod +x "$ROOTFS/etc/minit/services.d/sysctl/run"

if [ ! -f "$ROOTFS/etc/sysctl.conf" ]; then
  cat >"$ROOTFS/etc/sysctl.conf" <<'EOF'
kernel.printk = 4 4 1 7
net.ipv4.ip_forward = 0
EOF
fi

mkdir_p "$ROOTFS/etc/minit/services.d/ssh-keys"
cat >"$ROOTFS/etc/minit/services.d/ssh-keys/run" <<'EOF'
#!/bin/sh
set -eu
if command -v ssh-keygen >/dev/null 2>&1; then
  mkdir -p /etc/ssh
  ssh-keygen -A 2>/dev/null || true
fi
exit 0
EOF
chmod +x "$ROOTFS/etc/minit/services.d/ssh-keys/run"

mkdir_p "$ROOTFS/etc/minit/services.d/dropbear-keys"
cat >"$ROOTFS/etc/minit/services.d/dropbear-keys/run" <<'EOF'
#!/bin/sh
set -eu
if command -v dropbearkey >/dev/null 2>&1; then
  mkdir -p /etc/dropbear
  [ -f /etc/dropbear/dropbear_rsa_host_key ] || dropbearkey -t rsa -f /etc/dropbear/dropbear_rsa_host_key 2>/dev/null || true
fi
exit 0
EOF
chmod +x "$ROOTFS/etc/minit/services.d/dropbear-keys/run"

# Serviços adicionais úteis
# modules: carrega módulos essenciais se /etc/modules existir
mkdir_p "$ROOTFS/etc/minit/services.d/modules"
cat >"$ROOTFS/etc/minit/services.d/modules/run" <<'EOF'
#!/bin/sh
set -eu
[ -f /etc/modules ] || exit 0
while IFS= read -r m; do
  case "$m" in ""|\#*) continue;; esac
  modprobe "$m" 2>/dev/null || true
done < /etc/modules
# serviço oneshot
exit 0
EOF
chmod +x "$ROOTFS/etc/minit/services.d/modules/run"

# fsck-root (oneshot) - somente se root real já montou e houver e2fsck
mkdir_p "$ROOTFS/etc/minit/services.d/fsck-root"
cat >"$ROOTFS/etc/minit/services.d/fsck-root/run" <<'EOF'
#!/bin/sh
set -eu
command -v e2fsck >/dev/null 2>&1 || exit 0
# Apenas exemplo: você pode especializar para /dev/root ou fstab
exit 0
EOF
chmod +x "$ROOTFS/etc/minit/services.d/fsck-root/run"

# local: executa /etc/rc.local se existir
mkdir_p "$ROOTFS/etc/minit/services.d/local"
cat >"$ROOTFS/etc/minit/services.d/local/run" <<'EOF'
#!/bin/sh
set -eu
[ -x /etc/rc.local ] || exit 0
exec /etc/rc.local
EOF
chmod +x "$ROOTFS/etc/minit/services.d/local/run"

# pkgm: gerenciador de programas pós-boot (instalação a partir de receitas)
mkdir_p "$ROOTFS/usr/sbin" "$ROOTFS/etc/pkgm/recipes" "$ROOTFS/var/cache/pkgm/sources" "$ROOTFS/var/cache/pkgm/pkgs" "$ROOTFS/var/lib/pkgm/db" "$ROOTFS/var/log/pkgm"
cat >"$ROOTFS/usr/sbin/pkgm" <<'PKGM_SCRIPT'
\
#!/bin/sh
set -eu

# ---------- cores ----------
is_tty() { [ -t 1 ]; }
color_on() { is_tty && [ -z "${NO_COLOR:-}" ]; }
c_reset=''; c_red=''; c_green=''; c_yellow=''; c_cyan=''; c_bold=''
if color_on; then
  c_reset='\033[0m'; c_red='\033[31m'; c_green='\033[32m'; c_yellow='\033[33m'; c_cyan='\033[36m'; c_bold='\033[1m'
fi
info() { printf '%s\n' "${c_cyan}${c_bold}[INFO]${c_reset} $*"; }
ok()   { printf '%s\n' "${c_green}${c_bold}[OK]${c_reset} $*"; }
warn() { printf '%s\n' "${c_yellow}${c_bold}[WARN]${c_reset} $*"; }
err()  { printf '%s\n' "${c_red}${c_bold}[ERR]${c_reset} $*" >&2; }
die()  { err "$*"; exit 1; }

# ---------- config ----------
: "${PKGM_ROOT:=/}"
: "${PKGM_SOURCES:=/var/cache/pkgm/sources}"
: "${PKGM_PKGCACHE:=/var/cache/pkgm/pkgs}"
: "${PKGM_DB:=/var/lib/pkgm/db}"
: "${PKGM_WORK:=/var/tmp/pkgm/work}"
: "${PKGM_LOGS:=/var/log/pkgm}"
: "${PKGM_LOCKS:=/run/pkgm/locks}"
: "${JOBS:=1}"
: "${DRY_RUN:=0}"
: "${PKGM_RECIPE_DIRS:=/etc/pkgm/recipes}"

need() { command -v "$1" >/dev/null 2>&1 || die "comando necessário ausente: $1"; }
need tar; need mkdir; need rm; need cp; need awk; need sed; need sha256sum; need gzip; need find

mkdir -p "$PKGM_SOURCES" "$PKGM_PKGCACHE" "$PKGM_DB" "$PKGM_WORK" "$PKGM_LOGS" "$PKGM_LOCKS" 2>/dev/null || true

run() {
  if [ "$DRY_RUN" = 1 ]; then info "dry-run: $*"; return 0; fi
  "$@"
}

fetch() {
  url=$1; out=$2
  if command -v curl >/dev/null 2>&1; then
    run curl -L --fail -o "$out" "$url"
  elif command -v wget >/dev/null 2>&1; then
    run wget -O "$out" "$url"
  else
    die "precisa de curl ou wget"
  fi
}

verify_sha256() {
  file=$1; want=$2
  got=$(sha256sum "$file" | awk '{print $1}')
  [ "$got" = "$want" ]
}

extract() {
  arc=$1; dest=$2
  mkdir -p "$dest"
  case "$arc" in
    *.tar.gz|*.tgz) run tar -xzf "$arc" -C "$dest" ;;
    *.tar.xz) run tar -xJf "$arc" -C "$dest" ;;
    *.tar.bz2) run tar -xjf "$arc" -C "$dest" ;;
    *.tar) run tar -xf "$arc" -C "$dest" ;;
    *) die "arquivo desconhecido: $arc" ;;
  esac
}

lock_acquire() {
  n="$1"
  ldir="$PKGM_LOCKS/$n.lock"
  i=0
  while ! mkdir "$ldir" 2>/dev/null; do
    i=$((i+1)); [ $i -gt 120 ] && die "lock timeout para $n"
    sleep 1
  done
  echo "$$" > "$ldir/pid" 2>/dev/null || true
}
lock_release() { rm -rf "$PKGM_LOCKS/$1.lock" 2>/dev/null || true; }

recipe_hash_file() { sha256sum "$1" | awk '{print $1}'; }

load_recipe() {
  recipe=$1
  [ -f "$recipe" ] || die "recipe não encontrada: $recipe"
  # shellcheck disable=SC1090
  . "$recipe"
  [ -n "${name:-}" ] || die "recipe sem name="
  [ -n "${version:-}" ] || die "recipe sem version="
  [ -n "${url:-}" ] || die "recipe sem url="
  [ -n "${sha256:-}" ] || die "recipe sem sha256="
  : "${depends:=}"
  RECIPE_HASH=$(recipe_hash_file "$recipe")
  command -v build >/dev/null 2>&1 || die "recipe sem build()"
  command -v install >/dev/null 2>&1 || die "recipe sem install()"
}

arg_to_recipe() {
  a="$1"
  case "$a" in
    */*.recipe) echo "$a"; return 0 ;;
    *.recipe) [ -f "$a" ] && { echo "$a"; return 0; } ;;
  esac
  find_recipe "$a"
}

# -------- deps (DFS) --------

visiting=""; visited=""

set_contains() { echo " $1 " | grep -q " $2 " ; }
set_add() { echo "$1 $2"; }

find_recipe() {
  n="$1"
  oldIFS=$IFS; IFS=':'
  for d in $PKGM_RECIPE_DIRS; do
    IFS=$oldIFS
    if [ -f "$d/$n.recipe" ]; then echo "$d/$n.recipe"; return 0; fi
    IFS=':'
  done
  IFS=$oldIFS
  die "não encontrei recipe: $n (PKGM_RECIPE_DIRS=$PKGM_RECIPE_DIRS)"
}

resolve_one() {
  recipe="$1"
  load_recipe "$recipe"
  n="$name"
  if set_contains "$visited" "$n"; then return 0; fi
  if set_contains "$visiting" "$n"; then die "ciclo detectado em dependências: $n"; fi
  visiting=$(set_add "$visiting" "$n")
  for d in $depends; do
    resolve_one "$(find_recipe "$d")"
  done
  visiting=$(echo "$visiting" | sed "s/ $n//g")
  visited=$(set_add "$visited" "$n")
  echo "$recipe" >> "$PKGM_WORK/.order.recipes"
}

resolve_all() {
  rm -f "$PKGM_WORK/.order.recipes" 2>/dev/null || true
  for a in "$@"; do
    r=$(arg_to_recipe "$a")
    resolve_one "$r"
  done
}

build_one() {
  recipe="$1"
  load_recipe "$recipe"
  n="$name"; v="$version"
  lock_acquire "$n"; trap 'lock_release "$n"' EXIT INT TERM

  log="$PKGM_LOGS/$n-$v.log"
  arc=$(basename "$url")
  src="$PKGM_SOURCES/$arc"
  [ -f "$src" ] || { info "baixando $url"; fetch "$url" "$src"; }
  if ! verify_sha256 "$src" "$sha256"; then
    warn "sha256 inválido; rebaixando $arc"
    run rm -f "$src"; fetch "$url" "$src"
    verify_sha256 "$src" "$sha256" || die "sha256 ainda inválido: $arc"
  fi

  pkgfile="$PKGM_PKGCACHE/$n-$v.$RECIPE_HASH.tar.gz"
  if [ -f "$pkgfile" ]; then
    ok "cache hit: $n-$v (pkg)"
    lock_release "$n"; trap - EXIT INT TERM
    return 0
  fi

  w="$PKGM_WORK/$n/$v"
  srcdir="$w/src"; blddir="$w/build"; dest="$w/dest"
  run rm -rf "$w"
  run mkdir -p "$srcdir" "$blddir" "$dest"
  extract "$src" "$srcdir"
  SRCDIR=""; for d in "$srcdir"/*; do [ -d "$d" ] && SRCDIR="$d" && break; done
  [ -n "$SRCDIR" ] || die "não achei src extraído para $n"
  export SRCDIR BUILDDIR="$blddir" PKG="$dest" DESTDIR="$dest" MAKEFLAGS="-j$JOBS"

  info "build $n-$v"
  ( cd "$blddir" && build ) >>"$log" 2>&1 || die "falha build: veja $log"
  ( cd "$blddir" && install ) >>"$log" 2>&1 || die "falha install: veja $log"

  info "empacotando $pkgfile"
  ( cd "$dest" && tar -czf "$pkgfile" . ) >>"$log" 2>&1 || die "falha empacotar: $pkgfile"
  ok "build OK: $n-$v"

  lock_release "$n"; trap - EXIT INT TERM
}

install_one() {
  recipe="$1"
  load_recipe "$recipe"
  n="$name"; v="$version"
  lock_acquire "$n"; trap 'lock_release "$n"' EXIT INT TERM

  pkgfile="$PKGM_PKGCACHE/$n-$v.$RECIPE_HASH.tar.gz"
  [ -f "$pkgfile" ] || build_one "$recipe"

  instdir="$PKGM_DB/$n/$v/$RECIPE_HASH"
  mkdir -p "$instdir"
  manifest="$instdir/manifest"
  meta="$instdir/meta"
  log="$PKGM_LOGS/$n-$v.log"

  tmp="$PKGM_WORK/$n-$v.files.$$"
  run rm -f "$tmp"
  tar -tzf "$pkgfile" > "$tmp"

  info "instalando $n-$v em $PKGM_ROOT"
  run tar -xzf "$pkgfile" -C "$PKGM_ROOT" >>"$log" 2>&1

  run rm -f "$manifest"
  while IFS= read -r f; do
    f=${f#./}; [ -n "$f" ] || continue
    echo "/$f" >> "$manifest"
  done < "$tmp"
  run rm -f "$tmp"

  srcsha=$(sha256sum "$src" | awk '{print $1}')
  {
    echo "name=$n"
    echo "version=$v"
    echo "recipe_hash=$RECIPE_HASH"
    echo "source_sha256=$srcsha"
    echo "installed_at=$(date 2>/dev/null || echo unknown)"
    echo "jobs=$JOBS"
  } > "$meta"

  ok "instalado: $n-$v"
  lock_release "$n"; trap - EXIT INT TERM
}

safe_rm() {
  p="$1"
  [ "$p" != "/" ] || return 1
  case "$p" in /etc|/etc/*|"") return 1 ;; esac
  return 0
}

remove_pkg() {
  n="$1"; v="${2:-}"
  [ -n "$n" ] || die "uso: remove <name> [version]"
  if [ -z "$v" ]; then
    v=$(ls -1 "$PKGM_DB/$n" 2>/dev/null | tail -n1 || true)
    [ -n "$v" ] || die "não instalado: $n"
  fi
  instdir="$PKGM_DB/$n/$v/$RECIPE_HASH"; manifest="$instdir/manifest"
  [ -f "$manifest" ] || die "manifest ausente: $manifest"
  lock_acquire "$n"; trap 'lock_release "$n"' EXIT INT TERM

  info "removendo $n-$v"
  awk '{a[NR]=$0} END{for(i=NR;i>=1;i--)print a[i]}' "$manifest" | while IFS= read -r p; do
    safe_rm "$p" || { warn "protegido: $p"; continue; }
    if [ -f "$p" ] || [ -L "$p" ]; then run rm -f "$p"; fi
  done

  # remove dirs vazios (best-effort)
  while IFS= read -r p; do
    d=$(dirname "$p")
    case "$d" in /|/etc|/etc/*) continue;; esac
    rmdir "$d" 2>/dev/null || true
  done < "$manifest"

  run rm -rf "$instdir"
  ok "removido: $n-$v"
  lock_release "$n"; trap - EXIT INT TERM
}

rebuild_all() {
  for n in $(ls -1 "$PKGM_DB" 2>/dev/null || true); do
    recipe=$(find_recipe "$n")
    build_one "$recipe"
    install_one "$recipe"
  done
}


cmd_search() {
  pat=${1:-}
  [ -n "$pat" ] || die "uso: search <pattern>"
  oldIFS=$IFS; IFS=':'
  for d in $PKGM_RECIPE_DIRS; do
    IFS=$oldIFS
    [ -d "$d" ] || continue
    for r in "$d"/*.recipe; do
      [ -f "$r" ] || continue
      # match filename or name/version fields
      bn=$(basename "$r")
      if echo "$bn" | grep -i -q "$pat"; then
        echo "$r"; continue
      fi
      n=$(awk -F= '/^name=/{print $2; exit}' "$r" 2>/dev/null || true)
      v=$(awk -F= '/^version=/{print $2; exit}' "$r" 2>/dev/null || true)
      if echo "$n $v" | grep -i -q "$pat"; then
        echo "$r"
      fi
    done
    IFS=':'
  done
  IFS=$oldIFS
}

cmd_info() {
  n="${1:-}"
  [ -n "$n" ] || die "uso: info <name>"
  echo "== recipe =="
  r=$(arg_to_recipe "$n")
  load_recipe "$r"
  echo "name=$name"
  echo "version=$version"
  echo "url=$url"
  echo "sha256=$sha256"
  echo "depends=$depends"
  echo "recipe_path=$r"
  echo ""
  echo "== instalado =="
  if [ -d "$PKGM_DB/$name" ]; then
    for vv in $(ls -1 "$PKGM_DB/$name" 2>/dev/null || true); do
      for bid in $(ls -1 "$PKGM_DB/$name/$vv" 2>/dev/null || true); do
        meta="$PKGM_DB/$name/$vv/$bid/meta"
        [ -f "$meta" ] && { echo "-- $vv/$bid"; cat "$meta"; echo ""; }
      done
    done
  else
    echo "não instalado"
  fi
}

cmd_verify() {
  n="${1:-all}"
  failures=0
  verify_one() {
    pkg="$1"
    [ -d "$PKGM_DB/$pkg" ] || { warn "não instalado: $pkg"; return 0; }
    for vv in $(ls -1 "$PKGM_DB/$pkg" 2>/dev/null || true); do
      for bid in $(ls -1 "$PKGM_DB/$pkg/$vv" 2>/dev/null || true); do
        manifest="$PKGM_DB/$pkg/$vv/$bid/manifest"
        [ -f "$manifest" ] || continue
        while IFS= read -r p; do
          case "$p" in ""|/etc|/etc/*|/) continue;; esac
          if [ ! -e "$PKGM_ROOT$p" ] && [ ! -e "$p" ]; then
            warn "missing: $pkg $vv $p"
            failures=$((failures+1))
          fi
        done < "$manifest"
      done
    done
  }
  if [ "$n" = all ]; then
    for pkg in $(ls -1 "$PKGM_DB" 2>/dev/null || true); do
      verify_one "$pkg"
    done
  else
    verify_one "$n"
  fi
  [ "$failures" -eq 0 ] && ok "verify: OK" || die "verify: $failures problemas encontrados"
}

cmd_bootstrap() {
  target="${1:-}"; shift || true
  [ -n "$target" ] || die "uso: bootstrap <target_root> [pkgs...]"
  mkdir -p "$target"
  # skeleton mínimo
  mkdir -p "$target"/{proc,sys,dev,run,tmp,usr/bin,usr/sbin,sbin,bin,etc,var,var/log,var/cache,var/lib,root,home} 2>/dev/null || true
  chmod 1777 "$target/tmp" 2>/dev/null || true
  # configs base
  [ -f "$target/etc/hosts" ] || printf '127.0.0.1 localhost\n::1 localhost\n' > "$target/etc/hosts"
  [ -f "$target/etc/resolv.conf" ] || printf 'nameserver 1.1.1.1\nnameserver 8.8.8.8\n' > "$target/etc/resolv.conf"
  [ -f "$target/etc/hostname" ] || echo "intelroot" > "$target/etc/hostname"
  [ -f "$target/etc/passwd" ] || printf 'root:x:0:0:root:/root:/bin/sh\n' > "$target/etc/passwd"
  [ -f "$target/etc/group" ] || printf 'root:x:0:\n' > "$target/etc/group"
  [ -f "$target/etc/shadow" ] || { printf 'root:*:19793:0:99999:7:::\n' > "$target/etc/shadow"; chmod 600 "$target/etc/shadow" 2>/dev/null || true; }
  [ -f "$target/etc/gshadow" ] || { printf 'root:*::\n' > "$target/etc/gshadow"; chmod 600 "$target/etc/gshadow" 2>/dev/null || true; }

  # pacotes padrão mínimos (pode sobrescrever passando lista)
  if [ $# -eq 0 ]; then
    set -- busybox zlib gzip tar kmod util-linux e2fsprogs iproute2 openssl curl dropbear
  fi

  info "bootstrap: instalando em $target: $*"
  # instala usando o próprio pkgm (mesmo processo) apontando PKGM_ROOT para target
  PKGM_ROOT="$target" PKGM_DB="$target/var/lib/pkgm/db" PKGM_SOURCES="$target/var/cache/pkgm/sources" \
  PKGM_PKGCACHE="$target/var/cache/pkgm/pkgs" PKGM_WORK="$target/var/tmp/pkgm/work" PKGM_LOGS="$target/var/log/pkgm" \
    "$0" install "$@"

  ok "bootstrap: pronto. Monte o target como root e use initramfs para switch_root."
}

usage() {
  cat >&2 <<'__USAGE__'
uso: pkgm [opções] <cmd> [args]

Comandos:
  install <nome...>
  build <nome...>
  remove <nome> [versão]
  search <pattern>
  info <name>
  verify [name|all]
  bootstrap <target_root> [pkgs...]
  rebuild-all
  env
  help

Atalhos:
  -i <nome...>   == install
  -b <nome...>   == build
  -r <nome>      == remove
  -s <pattern>   == search
  -p <name>      == info
  -v [name|all]  == verify
  -B <dir> [...] == bootstrap
  -n             == dry-run (DRY_RUN=1)

Exemplos:
  pkgm -i autoconf automake
  pkgm install curl
  DRY_RUN=1 pkgm install rsync

env vars:
  PKGM_RECIPE_DIRS=/etc/pkgm/recipes[:/outro/dir]
  DRY_RUN=1
  JOBS=N
__USAGE__
}

if [ $# -eq 0 ]; then usage; exit 2; fi

while [ $# -gt 0 ]; do
  case "$1" in
    -n) DRY_RUN=1; shift ;;
    -i) cmd=install; shift; break ;;
    -b) cmd=build; shift; break ;;
    -r) cmd=remove; shift; break ;;
    -s) cmd=search; shift; break ;;
    -p) cmd=info; shift; break ;;
    -v) cmd=verify; shift; break ;;
    -B) cmd=bootstrap; shift; break ;;
    --) shift; break ;;
    -h|--help) usage; exit 0 ;;
    *) break ;;
  esac
done

cmd=${cmd:-${1:-help}}
# se cmd veio do primeiro arg, consome
if [ "${1:-}" = "$cmd" ]; then shift || true; fi

case "$cmd" in
  build)
    [ $# -ge 1 ] || usage
    resolve_all "$@"
    while IFS= read -r r; do build_one "$r"; done < "$PKGM_WORK/.order.recipes"
    ;;
  install)
    [ $# -ge 1 ] || usage
    resolve_all "$@"
    while IFS= read -r r; do build_one "$r"; install_one "$r"; done < "$PKGM_WORK/.order.recipes"
    ;;
  remove)
    [ $# -ge 1 ] || usage
    remove_pkg "$1" "${2:-}"
    ;;
  rebuild-all) rebuild_all ;;
  search)
    [ $# -ge 1 ] || usage
    cmd_search "$1"
    ;;
  info)
    [ $# -ge 1 ] || usage
    cmd_info "$1"
    ;;
  verify)
    cmd_verify "${1:-all}"
    ;;
  bootstrap)
    [ $# -ge 1 ] || usage
    cmd_bootstrap "$@"
    ;;
  env)
    echo "PKGM_SOURCES=$PKGM_SOURCES"
    echo "PKGM_PKGCACHE=$PKGM_PKGCACHE"
    echo "PKGM_DB=$PKGM_DB"
    echo "PKGM_WORK=$PKGM_WORK"
    echo "PKGM_LOGS=$PKGM_LOGS"
    echo "PKGM_RECIPE_DIRS=$PKGM_RECIPE_DIRS"
    ;;
  help|*) usage ;;
esac

PKGM_SCRIPT
chmod +x "$ROOTFS/usr/sbin/pkgm"

# Disponibiliza também no initramfs (atalhos)
mkdir_p "$ROOTFS/sbin" "$ROOTFS/usr/bin"
ln -sf /usr/sbin/pkgm "$ROOTFS/sbin/pkgm" 2>/dev/null || true
ln -sf /usr/sbin/pkgm "$ROOTFS/usr/bin/pkgm" 2>/dev/null || true

# Copia as recipes do builder como base
cp -f "$ROOT_DIR/recipes"/*.recipe "$ROOTFS/etc/pkgm/recipes/" 2>/dev/null || true

# Copia dependências runtime (ld-linux e libs) do SYSROOT para o ROOTFS,
# evitando "sujar" o SYSROOT e mantendo o rootfs autocontido.
"$ROOT_DIR/scripts/copy_deps.sh" --rootfs "$ROOTFS" --sysroot "$SYSROOT"


