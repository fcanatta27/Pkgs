#!/bin/sh
# Stage3: gera initramfs automaticamente a partir do ROOTFS (sem dracut).
#
# Saídas:
#   - $OUT/initramfs.cpio.gz (padrão)
#   - $OUT/initramfs.cpio.xz (se xz disponível, opcional)
#   - $OUT/run-qemu-x86_64.sh (helper)

set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$ROOT_DIR/scripts/common.sh"
. "$ROOT_DIR/build.conf"

OUT=$(abspath "$OUT")
ROOTFS=$(abspath "$ROOTFS")
mkdir_p "$OUT"

[ -d "$ROOTFS" ] || die "ROOTFS não existe: $ROOTFS (rode stage2)"

need_cmd find
need_cmd cpio

log "Gerando initramfs (newc) de: $ROOTFS"

chmod 0755 "$ROOTFS" 2>/dev/null || true
chmod 1777 "$ROOTFS/tmp" 2>/dev/null || true

CPIO="$OUT/initramfs.cpio"
(
  cd "$ROOTFS"
  if cpio --help 2>/dev/null | grep -q -- '--null'; then
    find . -print0 | cpio --null -ov --format=newc
  else
    # fallback sem --null (nomes com espaços não suportados)
    find . -print | cpio -ov --format=newc
  fi
) >"$CPIO" 2>/dev/null || die "falha ao gerar cpio"

if command -v gzip >/dev/null 2>&1; then
  gzip -9 -c "$CPIO" >"$OUT/initramfs.cpio.gz"
  log "OK: $OUT/initramfs.cpio.gz"
else
  log "Aviso: gzip não encontrado; mantendo $CPIO"
fi

if command -v xz >/dev/null 2>&1; then
  xz -9 -c "$CPIO" >"$OUT/initramfs.cpio.xz" || true
  log "OK: $OUT/initramfs.cpio.xz"
fi

cat >"$OUT/run-qemu-x86_64.sh" <<'EOF'
#!/bin/sh
set -eu
KERNEL=${1:-}
INITRD=${2:-initramfs.cpio.gz}

if [ -z "$KERNEL" ]; then
  echo "Uso: $0 /caminho/para/bzImage [initramfs.cpio.gz]"
  exit 2
fi

exec qemu-system-x86_64 -m 512M   -kernel "$KERNEL"   -initrd "$INITRD"   -nographic   -append "console=ttyS0 panic=5"
EOF
chmod +x "$OUT/run-qemu-x86_64.sh"

log "Stage3 OK"
