#!/bin/sh
# Stage1: constrói toolchain temporária + sysroot (separados do rootfs final)
#
# Filosofia:
#   - Sem LFS/chroot.
#   - Nada do toolchain entra no ROOTFS.
#   - SYSROOT é apenas uma árvore para headers+glibc, usada pelo toolchain.
#
# Saídas:
#   - $TOOLCHAIN  : binutils + gcc (pass1 + pass2) para $TARGET
#   - $SYSROOT    : headers de kernel + glibc
#
# Observação:
#   - Removido GCC pass3 conforme solicitado (simplificação).

set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$ROOT_DIR/scripts/common.sh"
. "$ROOT_DIR/build.conf"

OUT=$(abspath "$OUT")
ROOTFS=$(abspath "$ROOTFS")
SOURCES=$(abspath "$SOURCES")
WORKDIR=$(abspath "$WORKDIR")
DESTDIR_BASE=$(abspath "$DESTDIR_BASE")
LOGDIR=$(abspath "$LOGDIR")

TOOLCHAIN=$(abspath "$TOOLCHAIN")
SYSROOT=$(abspath "$SYSROOT")

mkdir_p "$OUT" "$ROOTFS" "$SOURCES" "$WORKDIR" "$DESTDIR_BASE" "$LOGDIR" "$TOOLCHAIN" "$SYSROOT"

# Triplets
if [ -z "${BUILD:-}" ]; then
  if command -v gcc >/dev/null 2>&1; then
    BUILD=$(gcc -dumpmachine)
  else
    BUILD=unknown-unknown-linux-gnu
  fi
fi
: "${TARGET:=$BUILD}"
: "${HOST:=$TARGET}"

export BUILD TARGET HOST
export SYSROOT TOOLCHAIN
export TOOLS_PREFIX="$TOOLCHAIN"
export PATH="$TOOLCHAIN/bin:$PATH"

log "Stage1: BUILD=$BUILD TARGET=$TARGET"
log "Stage1: TOOLCHAIN=$TOOLCHAIN"
log "Stage1: SYSROOT=$SYSROOT"

build_pkg() {
  recipe=$1
  "$ROOT_DIR/scripts/builder.sh"     --recipe "$recipe"     --workdir "$WORKDIR"     --srcdir "$SOURCES"     --destdir "$DESTDIR_BASE"     --logdir "$LOGDIR"     --cachedir "$WORKDIR/cache/build"
}

merge_to() {
  srcdest=$1
  dest=$2
  "$ROOT_DIR/scripts/merge.sh" "$srcdest" "$dest"
}

# Helper: build recipe and merge its DESTDIR into a target tree
build_and_merge() {
  recipe=$1
  target_tree=$2

  # Run builder; find the latest DESTDIR for that recipe by reading the log output pattern is hard.
  # Instead, compute the cache key by reusing builder's key logic is non-trivial in POSIX.
  # We solve by letting builder create a predictable 'last' symlink per package via merge.sh convention.
  # Here: rely on DESTDIR_BASE containing only cached-keyed dirs and merge all matching package dirs.

  build_pkg "$recipe"

  # Determine NAME/VERSION from recipe (POSIX source in subshell)
  pkg_name=
  pkg_ver=
  (
    . "$recipe"
    echo "$name" >"$WORKDIR/.pkgname.$$"
    echo "$version" >"$WORKDIR/.pkgver.$$"
  )
  pkg_name=$(cat "$WORKDIR/.pkgname.$$"); rm -f "$WORKDIR/.pkgname.$$"
  pkg_ver=$(cat "$WORKDIR/.pkgver.$$"); rm -f "$WORKDIR/.pkgver.$$"

  # Usa link determinístico criado pelo builder
  latest="$DESTDIR_BASE/latest-${pkg_name}-${pkg_ver}"
  [ -L "$latest" ] || [ -d "$latest" ] || die "não encontrei link latest para ${pkg_name}-${pkg_ver} em $DESTDIR_BASE"
  merge_to "$latest" "$target_tree"
}

# Stage1 steps (simplificado e funcional)
#
# 1) Binutils pass1 -> TOOLCHAIN (assembler/linker cross/nativo isolado)
build_and_merge "$ROOT_DIR/recipes/binutils-2.45.1-pass1.recipe" "$TOOLCHAIN"

# 2) GCC pass1 -> TOOLCHAIN (compilador mínimo, sem libs/headers do target)
build_and_merge "$ROOT_DIR/recipes/gcc-15.2.0-pass1.recipe" "$TOOLCHAIN"

# 3) Linux headers -> SYSROOT
build_and_merge "$ROOT_DIR/recipes/linux-headers-6.18.2.recipe" "$SYSROOT"

# 4) glibc -> SYSROOT (instala libc e headers no sysroot)
build_and_merge "$ROOT_DIR/recipes/glibc-2.42.recipe" "$SYSROOT"

# 5) Binutils pass2 -> TOOLCHAIN (rebuild com sysroot disponível)
build_and_merge "$ROOT_DIR/recipes/binutils-2.45.1-pass2.recipe" "$TOOLCHAIN"

# 6) GCC pass2 -> TOOLCHAIN (compilador final do stage, usando sysroot)
build_and_merge "$ROOT_DIR/recipes/gcc-15.2.0-pass2.recipe" "$TOOLCHAIN"

log "Stage1 OK"
