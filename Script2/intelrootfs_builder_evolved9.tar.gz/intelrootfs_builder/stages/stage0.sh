#!/bin/sh
# Stage0: preparação do ambiente (rootfs final, diretórios e verificações)
# - NÃO cria toolchain aqui.
# - Mantém o rootfs limpo para o output final.

set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$ROOT_DIR/scripts/common.sh"

# shellcheck disable=SC1090
. "$ROOT_DIR/build.conf"

OUT=$(abspath "$OUT")
ROOTFS=$(abspath "$ROOTFS")
SOURCES=$(abspath "$SOURCES")
WORK=$(abspath "$WORK")
TOOLCHAIN=$(abspath "$TOOLCHAIN")
SYSROOT=$(abspath "$SYSROOT")

log "Stage0: preparando estrutura em: $OUT"

need_cmd sh
need_cmd tar
need_cmd make

# downloads: curl ou wget
if command -v curl >/dev/null 2>&1; then :; elif command -v wget >/dev/null 2>&1; then :; else
  die "precisa de curl ou wget no host"
fi

mkdir -p "$OUT" "$ROOTFS" "$SOURCES" "$WORK" "$TOOLCHAIN" "$SYSROOT"
mkdir -p "$WORK/logs" "$WORK/build" "$WORK/dest"

# Layout mínimo do rootfs final
mkdir -p   "$ROOTFS"/{bin,sbin,etc,proc,sys,dev,run,tmp,root,home,mnt}   "$ROOTFS"/usr/{bin,sbin,lib,libexec,share,include}   "$ROOTFS"/var/{log,run,tmp}   "$ROOTFS"/usr/local/{bin,sbin,lib,share,include}

chmod 0755 "$ROOTFS"
chmod 1777 "$ROOTFS/tmp" "$ROOTFS/var/tmp"

# Arquivos mínimos
[ -f "$ROOTFS/etc/passwd" ] || cat >"$ROOTFS/etc/passwd" <<'EOF'
root:x:0:0:root:/root:/bin/sh
EOF

[ -f "$ROOTFS/etc/group" ] || cat >"$ROOTFS/etc/group" <<'EOF'
root:x:0:
EOF

[ -f "$ROOTFS/etc/hostname" ] || echo "minimal" >"$ROOTFS/etc/hostname"

log "Stage0 OK"
