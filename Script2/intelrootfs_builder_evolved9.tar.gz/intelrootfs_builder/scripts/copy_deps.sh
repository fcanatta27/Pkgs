#!/bin/sh
# Copia libs runtime requeridas pelos binários do rootfs a partir do SYSROOT.
# POSIX sh; usa readelf para NEEDED e INTERP.
set -eu

usage() {
  echo "uso: $0 --rootfs DIR --sysroot DIR" >&2
  exit 2
}

ROOTFS=
SYSROOT=

while [ $# -gt 0 ]; do
  case "$1" in
    --rootfs) ROOTFS=$2; shift 2;;
    --sysroot) SYSROOT=$2; shift 2;;
    *) usage;;
  esac
done

[ -n "$ROOTFS" ] || usage
[ -n "$SYSROOT" ] || usage

need() { command -v "$1" >/dev/null 2>&1 || { echo "faltando comando: $1" >&2; exit 1; }; }
need readelf
need awk
need sort
need uniq
need cp
need mkdir

mkdir -p "$ROOTFS/lib" "$ROOTFS/lib64" "$ROOTFS/usr/lib" "$ROOTFS/usr/lib64" "$ROOTFS/var" "$ROOTFS/run"

# Coleta binários ELF
find_elf() {
  find "$ROOTFS" -type f \( -perm -001 -o -name "*.so*" \) 2>/dev/null |
  while IFS= read -r f; do
    # quick check: ELF magic
    dd if="$f" bs=4 count=1 2>/dev/null | grep -q $'\x7fELF' || continue
    echo "$f"
  done
}

# Extrai INTERP (ld-linux) e NEEDED
deps_tmp=$(mktemp)
interp_tmp=$(mktemp)
trap 'rm -f "$deps_tmp" "$interp_tmp"' EXIT

find_elf | while IFS= read -r elf; do
  readelf -d "$elf" 2>/dev/null | awk '/NEEDED/{gsub(/[][]/,"",$NF); print $NF}' >>"$deps_tmp" || true
  readelf -l "$elf" 2>/dev/null | awk '/Requesting program interpreter/{print $NF}' >>"$interp_tmp" || true
done

# Unique deps
sort -u "$deps_tmp" > "$deps_tmp.u"
sort -u "$interp_tmp" > "$interp_tmp.u"

copy_one() {
  base=$1
  # procura no sysroot (ordem comum)
  for d in "$SYSROOT/lib" "$SYSROOT/lib64" "$SYSROOT/usr/lib" "$SYSROOT/usr/lib64"; do
    [ -e "$d/$base" ] || continue
    # replica caminho equivalente no rootfs
    rel=${d#"$SYSROOT"}
    mkdir -p "$ROOTFS$rel"
    cp -a "$d/$base" "$ROOTFS$rel/$base"
    return 0
  done
  return 1
}

# Copia loader
while IFS= read -r interp; do
  # interp é caminho absoluto ex /lib64/ld-linux-x86-64.so.2
  base=$(basename "$interp")
  if ! copy_one "$base"; then
    echo "AVISO: não encontrei loader $base no SYSROOT" >&2
  fi
done < "$interp_tmp.u"

# Copia libs
while IFS= read -r lib; do
  if ! copy_one "$lib"; then
    echo "AVISO: não encontrei lib $lib no SYSROOT" >&2
  fi
done < "$deps_tmp.u"

# Linkers comuns
if [ -e "$ROOTFS/lib64/ld-linux-x86-64.so.2" ] && [ ! -e "$ROOTFS/lib/ld-linux-x86-64.so.2" ]; then
  mkdir -p "$ROOTFS/lib"
  ln -sf ../lib64/ld-linux-x86-64.so.2 "$ROOTFS/lib/ld-linux-x86-64.so.2" 2>/dev/null || true
fi
