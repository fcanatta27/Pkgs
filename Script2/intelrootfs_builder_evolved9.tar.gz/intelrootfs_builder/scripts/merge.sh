#!/bin/sh
# Merge a staged DESTDIR tree into the final ROOTFS.

set -eu

THIS_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
. "$THIS_DIR/common.sh"

usage() {
  cat >&2 <<'USAGE'
Uso:
  merge.sh --pkgroot DIR --rootfs DIR

Observações:
  - Copia tudo de PKGROOT/ para ROOTFS/, preservando permissões.
  - Requer rsync (recomendado) ou cp -a.
USAGE
}

PKGROOT=
ROOTFS=

while [ $# -gt 0 ]; do
  case "$1" in
    --pkgroot) PKGROOT=$2; shift 2 ;;
    --rootfs) ROOTFS=$2; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) die "argumento inválido: $1" ;;
  esac

done

[ -n "$PKGROOT" ] || { usage; die "--pkgroot é obrigatório"; }
[ -n "$ROOTFS" ] || { usage; die "--rootfs é obrigatório"; }

PKGROOT=$(abspath "$PKGROOT")
ROOTFS=$(abspath "$ROOTFS")

[ -d "$PKGROOT" ] || die "pkgroot não encontrado: $PKGROOT"
[ -d "$ROOTFS" ] || die "rootfs não encontrado: $ROOTFS"

if command -v rsync >/dev/null 2>&1; then
  rsync -aH --numeric-ids "$PKGROOT/" "$ROOTFS/"
else
  log "rsync não encontrado; usando cp -a (menos fiel)."
  (cd "$PKGROOT" && cp -a . "$ROOTFS")
fi
