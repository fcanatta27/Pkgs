#!/bin/sh
# Generic package builder for POSIX recipes.
#
# Goals:
#   - deterministic directory layout
#   - out-of-tree builds
#   - DESTDIR staging per package
#   - optional build cache (reuse DESTDIR tarballs)
#   - source cache with checksum verification

set -eu

THIS_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
. "$THIS_DIR/common.sh"

usage() {
  cat >&2 <<'USAGE'
Uso:
  builder.sh --recipe PATH --workdir DIR --srcdir DIR --destdir DIR [opções]

Obrigatório:
  --recipe    arquivo de receita (*.recipe)
  --workdir   diretório temporário de build (subdir por pacote)
  --srcdir    cache de fontes (tarballs)
  --destdir   diretório DESTDIR base (subdir por pacote)

Opções:
  --prefix PATH      prefixo de instalação (default: /usr)
  --jobs N           jobs para make -j (default: auto)
  --keep-build       não remove diretório de build após sucesso
  --no-checksums     não verifica sha256/md5 (não recomendado)
  --logdir DIR       diretório de logs (default: workdir/logs)
  --cachedir DIR     cache de build (default: workdir/cache/build)

Ambiente exportado para a receita:
  NAME VERSION URL
  SRCROOT WORKROOT BUILDROOT
  SRCDIR (diretório extraído)
  BUILDDIR (diretório de build temporário)
  PREFIX PKG (DESTDIR do pacote)
  JOBS MAKEFLAGS
  TARGET HOST BUILD
  ROOTFS SYSROOT TOOLS_PREFIX
USAGE
}

RECIPE=
WORKDIR=
SRCCACHE=
DESTBASE=
PREFIX=/usr
JOBS=
KEEP_BUILD=0
NO_CHECKSUMS=0
LOGDIR=
CACHEDIR=

while [ $# -gt 0 ]; do
  case "$1" in
    --recipe) RECIPE=$2; shift 2 ;;
    --workdir) WORKDIR=$2; shift 2 ;;
    --srcdir) SRCCACHE=$2; shift 2 ;;
    --destdir) DESTBASE=$2; shift 2 ;;
    --prefix) PREFIX=$2; shift 2 ;;
    --jobs) JOBS=$2; shift 2 ;;
    --keep-build) KEEP_BUILD=1; shift ;;
    --no-checksums) NO_CHECKSUMS=1; shift ;;
    --logdir) LOGDIR=$2; shift 2 ;;
    --cachedir) CACHEDIR=$2; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) die "argumento desconhecido: $1 (use --help)" ;;
  esac
done

[ -n "$RECIPE" ] || { usage; exit 2; }
[ -n "$WORKDIR" ] || { usage; exit 2; }
[ -n "$SRCCACHE" ] || { usage; exit 2; }
[ -n "$DESTBASE" ] || { usage; exit 2; }

need_cmd tar
need_cmd awk
need_cmd mkdir
need_cmd rm
need_cmd cp
need_cmd find

mkdir_p "$WORKDIR"
mkdir_p "$SRCCACHE"
mkdir_p "$DESTBASE"

if [ -z "$LOGDIR" ]; then
  LOGDIR="$WORKDIR/logs"
fi
mkdir_p "$LOGDIR"

if [ -z "$CACHEDIR" ]; then
  CACHEDIR="$WORKDIR/cache/build"
fi
mkdir_p "$CACHEDIR"

if [ -z "$JOBS" ]; then
  JOBS=$(cpus)
fi

# Load recipe in a subshell to avoid leaking variables.
(
  set -eu
  # shellcheck disable=SC1090
  . "$RECIPE"

  [ -n "${name:-}" ] || die "receita sem 'name=': $RECIPE"
  [ -n "${version:-}" ] || die "receita sem 'version=': $RECIPE"
  [ -n "${url:-}" ] || die "receita sem 'url=': $RECIPE"

  NAME=$name
  VERSION=$version
  URL=$url
  SHA256=${sha256:-}
  MD5=${md5:-}

  # Use the URL basename as the archive name (keeps predictable caching)
  ARC=$(basename "$URL")
  SRCFILE="$SRCCACHE/$ARC"

  # Source cache: download only if missing, but always verify if checksums are provided.
  if [ ! -f "$SRCFILE" ]; then
    fetch "$URL" "$SRCFILE"
  fi

  if [ "$NO_CHECKSUMS" -eq 0 ]; then
    if [ -n "$SHA256" ]; then
      if ! verify_checksum "$SRCFILE" sha256 "$SHA256"; then
        rm -f "$SRCFILE"
        fetch "$URL" "$SRCFILE"
        verify_checksum "$SRCFILE" sha256 "$SHA256" || die "checksum sha256 inválido após re-download: $ARC"
      fi
    elif [ -n "$MD5" ]; then
      if ! verify_checksum "$SRCFILE" md5 "$MD5"; then
        rm -f "$SRCFILE"
        fetch "$URL" "$SRCFILE"
        verify_checksum "$SRCFILE" md5 "$MD5" || die "checksum md5 inválido após re-download: $ARC"
      fi
    else
      die "receita sem sha256/md5: $RECIPE"
    fi
  fi

  # Identify build cache key (recipe hash + relevant env)
  need_cmd sha256sum
  RECIPE_HASH=$(sha256sum "$RECIPE" | awk '{print $1}')

  : "${TARGET:=}"
  : "${HOST:=}"
  : "${BUILD:=}"
  SIG="${NAME}|${VERSION}|${URL}|${RECIPE_HASH}|${TARGET}|${HOST}|${BUILD}|${PREFIX}"
  CACHE_KEY=$(printf '%s' "$SIG" | sha256sum | awk '{print $1}')
  CACHE_TAR="$CACHEDIR/${NAME}-${VERSION}-${CACHE_KEY}.tar.gz"

  WORKROOT="$WORKDIR/build/${NAME}-${VERSION}-${CACHE_KEY}"
  SRCROOT="$WORKROOT/src"
  BUILDROOT="$WORKROOT/build"
  PKGROOT="$DESTBASE/${NAME}-${VERSION}-${CACHE_KEY}"
  LATEST_LINK="$DESTBASE/latest-${NAME}-${VERSION}"

  LOGFILE="$LOGDIR/${NAME}-${VERSION}.log"

  mkdir_p "$SRCROOT"
  mkdir_p "$BUILDROOT"
  mkdir_p "$PKGROOT"

  export NAME VERSION URL
  export SRCROOT WORKROOT BUILDROOT
  export PREFIX
  export PKG="$PKGROOT"
  export JOBS
  export MAKEFLAGS="-j$JOBS"
  export TARGET HOST BUILD
  export ROOTFS=${ROOTFS:-}
  export SYSROOT=${SYSROOT:-}
  export TOOLS_PREFIX=${TOOLS_PREFIX:-}
  export DESTDIR="$PKGROOT"

  # If we have a build cache, reuse it and skip compilation.
  if [ -f "$CACHE_TAR" ]; then
    log "cache hit: $NAME-$VERSION" >>"$LOGFILE"
    rm -rf "$PKGROOT"
    mkdir_p "$PKGROOT"
    tar -xzf "$CACHE_TAR" -C "$PKGROOT" >>"$LOGFILE" 2>&1 || die "falha ao extrair cache: $CACHE_TAR"
    rm -f "$LATEST_LINK" 2>/dev/null || true
    ln -s "$PKGROOT" "$LATEST_LINK" 2>/dev/null || true
    log "OK (cache): $NAME-$VERSION (dest: $PKGROOT)" >>"$LOGFILE"
    exit 0
  fi

  # Extract sources (clean slate per key)
  rm -rf "$SRCROOT"/*
  extract "$SRCFILE" "$SRCROOT"

  # Locate extracted dir (first directory)
  SRCDIR=
  for d in "$SRCROOT"/*; do
    if [ -d "$d" ]; then
      SRCDIR=$d
      break
    fi
  done
  [ -n "$SRCDIR" ] || die "não encontrei diretório extraído em: $SRCROOT"

  # Build dir (clean per run)
  rm -rf "$BUILDROOT"/*
  BUILDDIR="$BUILDROOT"

  export SRCDIR BUILDDIR

  # Hooks
  if command -v pre_build >/dev/null 2>&1; then
    log "[$NAME] pre_build()" >>"$LOGFILE"
    (cd "$SRCDIR" && pre_build) >>"$LOGFILE" 2>&1 || die "falha em pre_build() (veja: $LOGFILE)"
  fi

  command -v build >/dev/null 2>&1 || die "receita sem build()"
  log "[$NAME] build()" >>"$LOGFILE"
  (cd "$BUILDDIR" && build) >>"$LOGFILE" 2>&1 || die "falha em build() (veja: $LOGFILE)"

  command -v install >/dev/null 2>&1 || die "receita sem install()"
  log "[$NAME] install()" >>"$LOGFILE"
  (cd "$BUILDDIR" && install) >>"$LOGFILE" 2>&1 || die "falha em install() (veja: $LOGFILE)"

  if command -v post_install >/dev/null 2>&1; then
    log "[$NAME] post_install()" >>"$LOGFILE"
    (cd "$BUILDDIR" && post_install) >>"$LOGFILE" 2>&1 || die "falha em post_install() (veja: $LOGFILE)"
  fi

  # Strip empty dirs
  find "$PKGROOT" -type d -empty -delete 2>/dev/null || true

  # Save build cache
  need_cmd gzip
  tar -czf "$CACHE_TAR" -C "$PKGROOT" . >>"$LOGFILE" 2>&1 || die "falha ao criar cache: $CACHE_TAR"

  rm -f "$LATEST_LINK" 2>/dev/null || true
  ln -s "$PKGROOT" "$LATEST_LINK" 2>/dev/null || true

  if [ "$KEEP_BUILD" -eq 0 ]; then
    rm -rf "$WORKROOT"
  fi

  log "OK: $NAME-$VERSION (dest: $PKGROOT)" >>"$LOGFILE"
)
