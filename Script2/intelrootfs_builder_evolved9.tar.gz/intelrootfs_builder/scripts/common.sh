#!/bin/sh
# POSIX common library for the build system.
#
# Conventions:
#   - build happens in a temporary build directory
#   - installation happens into $PKG (a DESTDIR staging directory)
#   - recipes are sourced; they must define: name, version, url and one of sha256/md5

set -eu

# Cores (ANSI) — habilitado apenas se stdout é TTY e NO_COLOR não está setado.
is_tty() { [ -t 1 ]; }
color_on() { is_tty && [ -z "${NO_COLOR:-}" ]; }

c_reset=''
c_red=''
c_green=''
c_yellow=''
c_blue=''
c_magenta=''
c_cyan=''
c_bold=''

if color_on; then
  c_reset='\033[0m'
  c_red='\033[31m'
  c_green='\033[32m'
  c_yellow='\033[33m'
  c_blue='\033[34m'
  c_magenta='\033[35m'
  c_cyan='\033[36m'
  c_bold='\033[1m'
fi

msg() { printf '%s\n' "$*"; }
info() { msg "${c_cyan}${c_bold}[INFO]${c_reset} $*"; }
ok() { msg "${c_green}${c_bold}[OK]${c_reset} $*"; }
warn() { msg "${c_yellow}${c_bold}[WARN]${c_reset} $*"; }
err() { msg "${c_red}${c_bold}[ERR]${c_reset} $*"; }


log() {
  printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2
}

die() {
  log "ERROR: $*"
  exit 1
}

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "comando ausente no host: $1"
}

cpus() {
  if command -v getconf >/dev/null 2>&1; then
    getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1
  elif [ -r /proc/cpuinfo ]; then
    awk '/^processor/{n++} END{print (n>0?n:1)}' /proc/cpuinfo 2>/dev/null || echo 1
  else
    echo 1
  fi
}

abspath() {
  # Resolve a path without requiring realpath.
  # Only handles existing paths; best effort.
  p=$1
  case "$p" in
    /*) printf '%s\n' "$p" ;;
    *) printf '%s\n' "$(pwd)/$p" ;;
  esac
}

mkdir_p() {
  d=$1
  [ -n "$d" ] || die "mkdir_p: path vazio"
  [ -d "$d" ] || mkdir -p "$d"
}

fetch() {
  url=$1
  out=$2

  mkdir_p "$(dirname "$out")"

  if [ -f "$out" ] && [ -s "$out" ]; then
    return 0
  fi

  if command -v curl >/dev/null 2>&1; then
    log "download: $url"
    curl -L --fail --retry 3 --connect-timeout 20 -o "$out" "$url" || die "falha no download: $url"
  elif command -v wget >/dev/null 2>&1; then
    log "download: $url"
    wget -O "$out" "$url" || die "falha no download: $url"
  else
    die "precisa de curl ou wget"
  fi
}

verify_checksum() {
  file=$1
  algo=$2
  expected=$3

  [ -f "$file" ] || die "arquivo não existe para checksum: $file"

  case "$algo" in
    sha256)
      need_cmd sha256sum
      got=$(sha256sum "$file" | awk '{print $1}')
      ;;
    md5)
      if command -v md5sum >/dev/null 2>&1; then
        got=$(md5sum "$file" | awk '{print $1}')
      elif command -v md5 >/dev/null 2>&1; then
        got=$(md5 -q "$file")
      else
        die "precisa de md5sum (ou md) para verificar md5"
      fi
      ;;
    *)
      die "algoritmo de checksum não suportado: $algo"
      ;;
  esac

  if [ "x$got" != "x$expected" ]; then
    die "checksum inválido ($algo) para $file: esperado=$expected obtido=$got"
  fi
}

extract() {
  arc=$1
  dst=$2

  mkdir_p "$dst"

  case "$arc" in
    *.tar.gz|*.tgz)
      tar -xzf "$arc" -C "$dst" ;;
    *.tar.xz)
      tar -xJf "$arc" -C "$dst" ;;
    *.tar.bz2)
      tar -xjf "$arc" -C "$dst" ;;
    *.tar.zst)
      need_cmd unzstd
      tar --use-compress-program=unzstd -xf "$arc" -C "$dst" ;;
    *)
      die "formato de tarball não reconhecido: $arc"
      ;;
  esac
}

run_in_log() {
  logfile=$1
  shift

  mkdir_p "$(dirname "$logfile")"
  # Use 'sh -c' to preserve POSIX; redirect both streams
  (
    "$@"
  ) >"$logfile" 2>&1
}
