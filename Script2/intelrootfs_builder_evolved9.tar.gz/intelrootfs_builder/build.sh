#!/bin/sh
# Runner
set -eu
ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
. "$ROOT_DIR/scripts/common.sh"

cmd=${1:-all}

case "$cmd" in
  stage0) "$ROOT_DIR/stages/stage0.sh" ;;
  stage1) "$ROOT_DIR/stages/stage1.sh" ;;
  stage2) "$ROOT_DIR/stages/stage2.sh" ;;
  stage3) "$ROOT_DIR/stages/stage3.sh" ;;
  all)
    "$ROOT_DIR/stages/stage0.sh"
    "$ROOT_DIR/stages/stage1.sh"
    "$ROOT_DIR/stages/stage2.sh"
    "$ROOT_DIR/stages/stage3.sh"
    ;;
  clean)
    . "$ROOT_DIR/build.conf"
    OUT=$(abspath "$OUT")
    rm -rf "$OUT"
    ;;
  *)
    die "comando inválido: $cmd (use: stage0|stage1|stage2|stage3|all|clean)"
    ;;
esac
