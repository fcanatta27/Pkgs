# intelrootfs_builder (simples, POSIX)

Este projeto constrói um **rootfs Linux mínimo e funcional** sem a complexidade do LFS/chroot, mantendo a **toolchain temporária separada** para não "sujar" o rootfs final.

## Estrutura de saídas

Por padrão (ver `build.conf`):

- `out/rootfs`     : rootfs final (limpo)
- `out/toolchain`  : toolchain temporária (binutils/gcc) separada
- `out/sysroot`    : sysroot separado (headers + glibc)
- `out/sources`    : cache de fontes (tarballs)
- `out/work/cache/build` : cache de builds (DESTDIR tar.gz por pacote + assinatura)
- `out/work/logs`  : logs de build por pacote

## Stages

- **stage0**: prepara diretórios e layout.
- **stage1**: constrói **toolchain temporária** e **sysroot** (fora do rootfs).
  - binutils 2.45.1 pass1 + pass2
  - gcc 15.2.0 pass1 + pass2 (**sem pass3**)
  - linux headers 6.18.2
  - glibc 2.42
- **stage2**: gera o **rootfs mínimo** (BusyBox + /init + /etc básico).

## Como usar

```sh
tar -xzf intelrootfs_builder_evolved.tar.gz
cd intelrootfs_builder
./build.sh all
```

Ou por etapas:

```sh
./build.sh stage0
./build.sh stage1
./build.sh stage2
```

Limpar tudo:

```sh
./build.sh clean
```

## Cache

### Cache de sources
Os tarballs ficam em `out/sources`. Se já existem, não são baixados novamente.
Se checksum falhar, o arquivo é removido e baixado outra vez.

### Cache de build
Após cada build, o conteúdo do DESTDIR é compactado em `out/work/cache/build/`.
Se o mesmo pacote (mesma receita + mesmas variáveis relevantes) for solicitado novamente,
o builder reutiliza o cache e pula compilação.

## Rootfs resultante
O rootfs (`out/rootfs`) é intencionalmente limpo: não contém toolchain.
Ele inclui BusyBox (estático por padrão) e um `/init` simples que monta `/proc`, `/sys`, `/dev` (devtmpfs) e entra em shell.

## Observações
- Este sistema visa simplicidade e previsibilidade, não um "distro completo".
- Para testes, gere initramfs a partir de `out/rootfs` e inicialize via QEMU com um kernel que você já possua.


## Stage3 (initramfs automático)

```sh
./build.sh stage3
```

Gera:
- `out/initramfs.cpio.gz` (padrão)
- `out/initramfs.cpio.xz` (se xz disponível)
- `out/run-qemu-x86_64.sh` helper

O sistema usa **busybox init** com `/etc/inittab` e `getty` em `tty1` e `ttyS0`.


## Serviços (minit) e console/getty

O `stage2` agora instala um init minimalista chamado **minit** (`/sbin/minit`), que roda como PID1 no initramfs e oferece:

- `start|stop|restart|status` via `svctl`
- respawn automático quando um serviço termina
- serviços declarativos em `/etc/minit/services.d/<nome>/run`
- flags de desativação via `/run/minit/down.<nome>`

Comandos:

```sh
svctl status all
svctl start dropbear
svctl stop dropbear
svctl restart net
```

Serviços padrão:

- `getty-tty1` (habilitado): console local em `tty1`
- `net` (habilitado): loopback + DHCP (via `udhcpc` se existir)
- `dropbear` (desabilitado por padrão)
- `sshd` (desabilitado por padrão)

## Utilitários adicionados no rootfs

Além do BusyBox, o `stage2` agora constrói e instala (com libs runtime copiadas do SYSROOT):

- zlib, bzip2, xz, gzip, tar
- m4, bash
- openssl
- curl
- openssh (cliente+servidor)
- dropbear
- kmod
- iproute2 (versão 3.1.0 por compatibilidade com o checksum disponível)
- util-linux (subset incluindo agetty/login/su)
- e2fsprogs

Observação: o sistema continua intencionalmente simples; os *flags* de configuração priorizam reduzir dependências.


## Stage2: devtools opcionais (Perl/Autotools/Python)

Por padrão, o stage2 gera um rootfs simples e funcional. Ferramentas mais pesadas (Perl/Autotools/Python) são **opcionais**
porque cross-compilação desses projetos pode ser frágil dependendo do host.

Para habilitar, rode:

```sh
export ENABLE_DEVTOOLS=1
./build.sh stage2
```

Se algum desses pacotes falhar no cross-build, a alternativa recomendada é compilar **nativamente** após o primeiro boot do sistema
(já com make/patch/rsync instalados).


## Boot em disco real com fallback para initramfs

O `/init` do initramfs agora tenta montar o **root real** (via `root=` no cmdline) e faz `switch_root`.
Se o init do disco falhar, o wrapper `/sbin/init-fallback` cai automaticamente para o init do initramfs exposto em `/run/initramfs`.

Exemplo de cmdline:
- `root=/dev/sda2 rootfstype=ext4 rw`
- `root=UUID=... rootfstype=ext4 rw`

## pkgm (gerenciador de programas pós-boot)

No sistema bootado, você pode instalar programas a partir de receitas em `/etc/pkgm/recipes`:

```sh
pkgm install /etc/pkgm/recipes/curl-8.17.0.recipe
pkgm remove curl
pkgm rebuild-all
```

Recursos:
- cache de sources: `/var/cache/pkgm/sources`
- cache de pacotes: `/var/cache/pkgm/pkgs`
- DB/manifests: `/var/lib/pkgm/db`
- logs: `/var/log/pkgm`
- deps + detecção de ciclo, lock por pacote, dry-run via `DRY_RUN=1`

## Kernel 6.18.2 (opcional)

Para tentar construir o kernel (requer dependências do host), rode:

```sh
export ENABLE_KERNEL=1
./build.sh stage2
```

Saída em `out/kernel/boot/` (ex.: `vmlinuz-6.18.2`).


## Devtools via pkgm

Autoconf/Automake/Libtool/Python/Perl agora são gerenciados pelo **pkgm** (pós-boot), para manter o builder mais simples.


## Shadow

O stage2 agora inclui **shadow** e cria configs mínimas em `/etc/login.defs`, `/etc/shadow`, `/etc/gshadow`.


## pkgm: instalar por nome (atalhos)

Agora o pkgm aceita nomes diretamente:

```sh
pkgm install autoconf
pkgm -i autoconf automake
pkgm -b curl
pkgm -r curl
DRY_RUN=1 pkgm -i rsync
```

O pkgm procura a receita em `PKGM_RECIPE_DIRS` (default: `/etc/pkgm/recipes`).


## Novos recursos: bootstrap, rescue e network boot

### pkgm bootstrap
Cria um root em um diretório (ex.: um disco montado em /mnt/target) e instala um conjunto base de pacotes:

```sh
pkgm bootstrap /mnt/target
# ou escolher pacotes:
pkgm bootstrap /mnt/target busybox zlib openssl curl dropbear iproute2
```

### initramfs rescue mode
Passe `rescue=1` no kernel cmdline para **não** fazer switch_root e permanecer no initramfs:

```
rescue=1
```

### initramfs network boot (NFS root)
Passe `nfsroot=SERVER:/path` (e opcionalmente `ip=dhcp`). O initramfs tentará DHCP (udhcpc) e montará o NFS como root:

```
nfsroot=192.168.1.10:/exports/root ip=dhcp
```

### pkgm verify
Verifica presença de arquivos conforme manifests (best-effort):

```sh
pkgm verify all
pkgm -v curl
```

### pkgm search / info
```sh
pkgm search ssh
pkgm info openssl
```
