#!/bin/sh
# Install miniLFS rootfs tarball onto a disk (or disk image) with UEFI + GRUB.
# WARNING: This will DESTROY data on the target device.
#
# Usage:
#   sudo ./scripts/install_uefi_disk.sh /dev/sdX out/rootfs-*.tar.xz
#
# Layout:
#   p1: EFI System Partition (FAT32) 512M
#   p2: Linux root (ext4) rest

set -eu

DEV="$1"
TARBALL="$2"

[ -b "$DEV" ] || { echo "Not a block device: $DEV" >&2; exit 1; }
[ -f "$TARBALL" ] || { echo "Missing tarball: $TARBALL" >&2; exit 1; }

for t in sgdisk mkfs.vfat mkfs.ext4 mount umount tar xz grub-install partprobe; do
  command -v "$t" >/dev/null 2>&1 || { echo "Missing tool: $t" >&2; exit 1; }
done

echo "About to wipe: $DEV"
echo "Press Ctrl+C now to abort."
sleep 3

sgdisk --zap-all "$DEV"
sgdisk -n 1:0:+512M -t 1:ef00 -c 1:"EFI" "$DEV"
sgdisk -n 2:0:0     -t 2:8300 -c 2:"root" "$DEV"
partprobe "$DEV" 2>/dev/null || true
sleep 1

EFI="${DEV}1"
ROOT="${DEV}2"

mkfs.vfat -F32 "$EFI"
mkfs.ext4 -F "$ROOT"

MNT=$(mktemp -d)
mount "$ROOT" "$MNT"
mkdir -p "$MNT/boot/efi"
mount "$EFI" "$MNT/boot/efi"

# Extract rootfs
xz -dc "$TARBALL" | tar -C "$MNT" -xpf -

# Install GRUB UEFI
grub-install   --target=x86_64-efi   --efi-directory="$MNT/boot/efi"   --boot-directory="$MNT/boot"   --removable   --recheck

umount "$MNT/boot/efi"
umount "$MNT"
rmdir "$MNT"

echo "Done. Edit /boot/grub/grub.cfg root=... and set up /etc/fstab as needed."
