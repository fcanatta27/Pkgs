# miniLFS-builder (x86_64, UEFI, glibc, BusyBox, SysVinit, GRUB, kernel)

This is a small, recipe-driven POSIX `sh` build system that builds a minimal Linux root filesystem **from source**
in phases and produces a **rootfs tarball**.

## What you get
- Toolchain prefix in `./tools/` (temporary)
- Root filesystem in `./rootfs/`
- Output tarball in `./out/rootfs-*.tar.xz`
- Optional disk installer: `scripts/install_uefi_disk.sh`

## Supported target
- x86_64
- UEFI (GRUB EFI)

## Host requirements
Typical packages/tools you will need (names vary by distro):
- gcc, g++, make, binutils, patch, sed, awk, grep
- bison, flex, perl, python3
- tar, xz, sha256sum
- curl or wget
- grub-install (if using `scripts/install_uefi_disk.sh`)
- sgdisk (gdisk), dosfstools, e2fsprogs (for the installer script)

## IMPORTANT: Fill in SHA256 values
Recipes contain `SHA256="__FILL_ME__"` placeholders.

Workflow:
1) `./build.sh init`
2) `./build.sh fetch`
3) Compute checksums (example): `sha256sum src/binutils-*.tar.xz`
4) Paste hashes into the matching `recipes/*.recipe`
5) Build:
   - `sudo ./build.sh toolchain`
   - `sudo ./build.sh base`
   - `sudo ./build.sh final`
   - `sudo ./build.sh tarball`

Or one-shot:
```sh
sudo ./build.sh all
```

## Install to disk (UEFI)
WARNING: wipes the target device.
```sh
sudo ./scripts/install_uefi_disk.sh /dev/sdX out/rootfs-*.tar.xz
```

After first boot, edit `/boot/grub/grub.cfg` (root=...) and `/etc/fstab` as needed.
