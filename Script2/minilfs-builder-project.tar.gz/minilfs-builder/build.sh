#!/bin/sh
# miniLFS builder (POSIX sh). Builds a minimal glibc + busybox + sysvinit + grub-uefi + kernel rootfs and packs a tarball.
#
# IMPORTANT:
# - This project is functional on a real Linux host with required build deps.
# - It does NOT ship prebuilt binaries.
#
# Usage:
#   ./build.sh init
#   ./build.sh fetch
#   sudo ./build.sh toolchain
#   sudo ./build.sh base
#   sudo ./build.sh final
#   sudo ./build.sh tarball
#   sudo ./build.sh all

set -eu

SELF_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

. "$SELF_DIR/lib/common.sh"
. "$SELF_DIR/lib/fetch.sh"
. "$SELF_DIR/lib/steps.sh"
. "$SELF_DIR/lib/chroot.sh"

. "$SELF_DIR/cfg/target.conf"
. "$SELF_DIR/cfg/versions.conf"
. "$SELF_DIR/cfg/mirrors.conf"

case "${ARCH:-}" in
  x86_64) : ;;
  *) die "ARCH must be x86_64 (got: ${ARCH:-})" ;;
esac

LOCKDIR="$STATEDIR/.lock"

usage() {
  cat <<EOF
Usage: $0 <command>

Commands:
  init        Create directories and baseline rootfs skeleton
  fetch       Download all sources (no build)
  toolchain   Build temporary toolchain in ./tools (host build)
  base        Install BusyBox + SysVinit into rootfs
  final       Build kernel + install grub userspace + write configs
  tarball     Create out/rootfs.tar.xz
  all         Run init, fetch, toolchain, base, final, tarball

  clean       Remove work dirs (keeps sources)
  distclean   Remove work dirs, tools, rootfs, state, logs, out (keeps sources)

Notes:
  - toolchain/base/final usually require root for mounts/chroot/ownership.
  - Fill in SHA256 values in recipes before building.
EOF
}

need_tools_host() {
  for t in tar make gcc g++ ld ar ranlib strip patch sed awk grep bison flex perl python3 xz; do
    have "$t" || die "missing host tool: $t"
  done
  (have curl || have wget) || die "need curl or wget"
  have sha256sum || die "need sha256sum"
  have chroot || die "need chroot"
  have mount || die "need mount"
}

mk_skel_rootfs() {
  mkd "$ROOTFS" "$WORKDIR" "$SRCDIR" "$OUTDIR" "$STATEDIR" "$LOGDIR" "$TOOLS"
  for d in bin sbin etc dev proc sys run tmp var var/log usr usr/bin usr/sbin usr/lib lib lib64 boot; do
    mkd "$ROOTFS/$d"
  done
  chmod 1777 "$ROOTFS/tmp" 2>/dev/null || true

  if [ ! -f "$ROOTFS/etc/passwd" ]; then
    cat >"$ROOTFS/etc/passwd" <<'EOF'
root:x:0:0:root:/root:/bin/sh
EOF
  fi
  if [ ! -f "$ROOTFS/etc/group" ]; then
    cat >"$ROOTFS/etc/group" <<'EOF'
root:x:0:
EOF
  fi
}

mirror_try() {
  _rel="$1"; _out="$2"
  for m in $MIRRORS; do
    _u="$m/$_rel"
    fetch_file "$_u" "$_out" && return 0 || true
  done
  return 1
}

run_recipe_step() {
  _pkg="$1"; _step="$2"
  _r="$SELF_DIR/recipes/$_pkg.recipe"
  [ -f "$_r" ] || die "missing recipe: $_pkg"
  # shellcheck disable=SC1090
  . "$_r"

  _log="$LOGDIR/$_pkg/$_step.log"
  mkd "$LOGDIR/$_pkg"

  if is_done "$_pkg" "$_step"; then
    info "skip $_pkg:$_step (done)"
    return 0
  fi

  info "run $_pkg:$_step"
  case "$_step" in
    fetch)    run_logged "$_log" sh -c "do_fetch" ;;
    verify)   run_logged "$_log" sh -c "do_verify" ;;
    extract)  run_logged "$_log" sh -c "do_extract" ;;
    build)    run_logged "$_log" sh -c "do_build" ;;
    install)  run_logged "$_log" sh -c "do_install" ;;
    *) die "unknown step: $_step" ;;
  esac

  mark_done "$_pkg" "$_step"
}

build_pkg() {
  _pkg="$1"
  _r="$SELF_DIR/recipes/$_pkg.recipe"
  [ -f "$_r" ] || die "missing recipe: $_pkg"
  # shellcheck disable=SC1090
  . "$_r"

  if [ "${DEPS:-}" ]; then
    for d in $DEPS; do
      build_pkg "$d"
    done
  fi

  run_recipe_step "$_pkg" fetch
  run_recipe_step "$_pkg" verify
  run_recipe_step "$_pkg" extract
  run_recipe_step "$_pkg" build
  run_recipe_step "$_pkg" install
}

cmd_init() { need_tools_host; mk_skel_rootfs; info "initialized"; }

cmd_fetch() {
  need_tools_host
  mk_skel_rootfs
  for p in linux binutils gmp mpfr mpc isl gcc glibc busybox sysvinit grub zlib; do
    clear_pkg "$p"
    run_recipe_step "$p" fetch
    run_recipe_step "$p" verify || die "verify failed for $p (fill SHA256)"
  done
  info "sources fetched + verified"
}

cmd_toolchain() {
  need_tools_host
  mk_skel_rootfs
  for p in binutils gmp mpfr mpc isl gcc zlib linux glibc; do
    build_pkg "$p"
  done
  info "toolchain built in: $TOOLS"
}

cmd_base() {
  need_tools_host
  mk_skel_rootfs
  for p in busybox sysvinit; do
    build_pkg "$p"
  done
  info "base installed in: $ROOTFS"
}

cmd_final() {
  need_tools_host
  mk_skel_rootfs
  build_pkg linux_kernel
  build_pkg grub

  mkd "$ROOTFS/etc/init.d" "$ROOTFS/etc/rc.d" "$ROOTFS/root" "$ROOTFS/boot/grub"

  if [ ! -f "$ROOTFS/etc/inittab" ]; then
    cat >"$ROOTFS/etc/inittab" <<'EOF'
::sysinit:/etc/init.d/rcS
tty1::respawn:/sbin/getty 38400 tty1
::ctrlaltdel:/sbin/reboot
::shutdown:/bin/umount -a -r
EOF
  fi

  if [ ! -x "$ROOTFS/etc/init.d/rcS" ]; then
    cat >"$ROOTFS/etc/init.d/rcS" <<'EOF'
#!/bin/sh
/bin/mount -t proc proc /proc 2>/dev/null || true
/bin/mount -t sysfs sysfs /sys 2>/dev/null || true
/bin/mount -t devtmpfs devtmpfs /dev 2>/dev/null || true
/bin/mkdir -p /dev/pts
/bin/mount -t devpts devpts /dev/pts 2>/dev/null || true
echo "miniLFS booted."
EOF
    chmod +x "$ROOTFS/etc/init.d/rcS"
  fi

  if [ ! -f "$ROOTFS/etc/fstab" ]; then
    cat >"$ROOTFS/etc/fstab" <<'EOF'
proc   /proc         proc    defaults 0 0
sysfs  /sys          sysfs   defaults 0 0
devpts /dev/pts      devpts  gid=5,mode=620 0 0
tmpfs  /run          tmpfs   defaults 0 0
EOF
  fi

  if [ ! -f "$ROOTFS/etc/profile" ]; then
    cat >"$ROOTFS/etc/profile" <<'EOF'
export PATH=/bin:/sbin:/usr/bin:/usr/sbin
export HOME=/root
export TERM=${TERM:-linux}
EOF
  fi

  if [ ! -f "$ROOTFS/boot/grub/grub.cfg" ]; then
    cat >"$ROOTFS/boot/grub/grub.cfg" <<'EOF'
set timeout=3
set default=0

menuentry "miniLFS" {
  linux /boot/vmlinuz root=/dev/sda2 ro quiet
}
EOF
  fi

  info "finalization complete"
}

cmd_tarball() {
  need_tools_host
  mk_skel_rootfs
  mkd "$OUTDIR"
  _ts=$(date -u '+%Y%m%d-%H%M%S' 2>/dev/null || date '+%Y%m%d-%H%M%S')
  _tar="$OUTDIR/rootfs-${ARCH}-${_ts}.tar"
  _xz="${_tar}.xz"
  info "packing tarball: $_xz"
  (cd "$ROOTFS" && tar --numeric-owner --xattrs --acls     --exclude='./proc' --exclude='./sys' --exclude='./dev/pts' --exclude='./run'     -cf "$_tar" .) || die "tar failed"
  xz -T0 -9e -f "$_tar" || die "xz failed"
  info "created: $_xz"
}

cmd_clean() { rmrf "work"; info "cleaned work/"; }
cmd_distclean() {
  rmrf "work"; rmrf "tools"; rmrf "rootfs"; rmrf "state"; rmrf "logs"; rmrf "out"
  info "distclean done (sources kept in src/)"
}

cmd_all() { cmd_init; cmd_fetch; cmd_toolchain; cmd_base; cmd_final; cmd_tarball; }

main() {
  [ $# -ge 1 ] || { usage; exit 1; }

  mkd "$STATEDIR"
  if ! lock_acquire "$LOCKDIR"; then
    die "another build seems running (lock: $LOCKDIR)"
  fi
  trap 'lock_release "$LOCKDIR"' EXIT INT TERM

  case "$1" in
    init) cmd_init ;;
    fetch) cmd_fetch ;;
    toolchain) cmd_toolchain ;;
    base) cmd_base ;;
    final) cmd_final ;;
    tarball) cmd_tarball ;;
    all) cmd_all ;;
    clean) cmd_clean ;;
    distclean) cmd_distclean ;;
    -h|--help|help) usage ;;
    *) usage; die "unknown command: $1" ;;
  esac
}

main "$@"
