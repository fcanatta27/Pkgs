#!/bin/sh
# Common helpers (POSIX sh). Intended to be sourced.

set -u

die() { printf '%s\n' "ERROR: $*" >&2; exit 1; }
warn() { printf '%s\n' "WARN:  $*" >&2; }
info() { printf '%s\n' "INFO:  $*" >&2; }

have() { command -v "$1" >/dev/null 2>&1; }

mkd() {
  for d in "$@"; do
    [ -d "$d" ] || mkdir -p "$d" || die "mkdir -p $d failed"
  done
}

# Simple lock using mkdir (atomic on POSIX filesystems)
lock_acquire() {
  _lk="$1"
  if mkdir "$_lk" 2>/dev/null; then
    : >"$_lk/pid"
    printf '%s\n' "$$" >"$_lk/pid"
    return 0
  fi
  return 1
}

lock_release() {
  _lk="$1"
  rm -f "$_lk/pid" 2>/dev/null || true
  rmdir "$_lk" 2>/dev/null || true
}

# Logging runner: run CMD... and capture stdout/stderr to log file
run_logged() {
  _log="$1"; shift
  mkd "$(dirname "$_log")"
  ( "$@" ) >"$_log" 2>&1
}

# Safer rm -rf guard (relative paths only)
rmrf() {
  _p="$1"
  [ -n "$_p" ] || die "rmrf: empty path"
  case "$_p" in
    /|/*) die "rmrf: refusing absolute path: $_p" ;;
  esac
  rm -rf "$_p"
}
