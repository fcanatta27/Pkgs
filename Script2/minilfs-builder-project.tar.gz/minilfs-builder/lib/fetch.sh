#!/bin/sh
# Fetch + verify helpers. Intended to be sourced.

set -u

fetch_file() {
  _url="$1"
  _out="$2"
  if [ -f "$_out" ]; then
    info "already have: $(basename "$_out")"
    return 0
  fi
  mkd "$(dirname "$_out")"

  if have curl; then
    info "download: $_url"
    curl -L --fail --retry 3 --connect-timeout 15 --max-time 0 -o "$_out.part" "$_url" || return 1
  elif have wget; then
    info "download: $_url"
    wget -O "$_out.part" "$_url" || return 1
  else
    die "need curl or wget"
  fi
  mv "$_out.part" "$_out" || return 1
}

sha256_verify() {
  _file="$1"
  _sha="$2"
  have sha256sum || die "need sha256sum"
  printf '%s  %s\n' "$_sha" "$_file" | sha256sum -c - >/dev/null 2>&1
}
