#!/bin/sh
# Step/stamp helpers. Intended to be sourced.

set -u

stamp_path() {
  _pkg="$1"; _step="$2"
  printf '%s/%s.%s.done\n' "$STATEDIR" "$_pkg" "$_step"
}

is_done() {
  _pkg="$1"; _step="$2"
  [ -f "$(stamp_path "$_pkg" "$_step")" ]
}

mark_done() {
  _pkg="$1"; _step="$2"
  mkd "$STATEDIR"
  : >"$(stamp_path "$_pkg" "$_step")"
}

clear_pkg() {
  _pkg="$1"
  rm -f "$STATEDIR/$_pkg".*.done 2>/dev/null || true
}
