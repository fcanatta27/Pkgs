#!/bin/sh
# Chroot helpers. Intended to be sourced.

set -u

mount_pseudos() {
  mkd "$ROOTFS/dev" "$ROOTFS/proc" "$ROOTFS/sys" "$ROOTFS/run"
  if mountpoint -q "$ROOTFS/dev" 2>/dev/null; then :; else
    if mount -t devtmpfs devtmpfs "$ROOTFS/dev" 2>/dev/null; then :; else
      mount --bind /dev "$ROOTFS/dev"
    fi
  fi
  mkd "$ROOTFS/dev/pts"
  mountpoint -q "$ROOTFS/dev/pts" 2>/dev/null || mount -t devpts devpts "$ROOTFS/dev/pts" 2>/dev/null || true
  mountpoint -q "$ROOTFS/proc" 2>/dev/null || mount -t proc proc "$ROOTFS/proc"
  mountpoint -q "$ROOTFS/sys" 2>/dev/null || mount -t sysfs sysfs "$ROOTFS/sys"
  mountpoint -q "$ROOTFS/run" 2>/dev/null || mount -t tmpfs tmpfs "$ROOTFS/run" 2>/dev/null || true
}

umount_pseudos() {
  for p in "$ROOTFS/dev/pts" "$ROOTFS/dev" "$ROOTFS/proc" "$ROOTFS/sys" "$ROOTFS/run"; do
    mountpoint -q "$p" 2>/dev/null && umount -l "$p" 2>/dev/null || true
  done
}

chroot_run() {
  mount_pseudos
  chroot "$ROOTFS" /usr/bin/env -i     HOME=/root TERM="${TERM:-linux}"     PATH=/bin:/sbin:/usr/bin:/usr/sbin     "$@"
}
